'use strict';
/* 크림스캐너 2.7 — 계정 연결
   쇼핑몰·크림 계정의 로그인 상태(ONLINE/OFFLINE)를 보고, 풀린 곳은 저장해 둔 아이디·비밀번호로 다시 로그인해요.
   아이디·비밀번호는 PIN으로 암호화(AES-GCM, PBKDF2 25만 회)해서 이 PC 크림스캐너 저장소에만 둬요.
   백업 파일·휴대폰 보내기·엑셀에는 들어가지 않아요. 보안문자·문자인증·간편로그인(네이버·카카오)은 자동으로 하지 않고 알려만 줘요. */

const ACCTS = [
  { k: 'musinsa', label: '무신사', check: 'https://www.musinsa.com/order/order-list' },
  { k: 'kream', label: '크림', check: 'https://kream.co.kr/my', login: 'https://kream.co.kr/login' },
  { k: 'kreamp', label: '크림 입점', check: 'https://partner.kream.co.kr', login: 'https://partner.kream.co.kr' },
  { k: 'zigzag', label: '지그재그' }, { k: 'gmarket', label: 'G마켓' },
  { k: 'abc', label: 'ABC마트 · 그랜드스테이지' }, { k: '11st', label: '11번가' }, { k: 'ssg', label: 'SSG · 신세계' },
  { k: 'lotte', label: '롯데ON' }, { k: '29cm', label: '29CM' }, { k: 'wconcept', label: 'W컨셉' },
  { k: 'rexmonde', label: '렉스몬드' }, { k: 'nike', label: '나이키' }, { k: 'ssf', label: 'SSF샵' },
  { k: '4910', label: '4910', check: 'https://4910.kr/mypage', login: 'https://4910.kr/login' }
];
const acctOf = k => { const A = ACCTS.find(a => a.k === k); if (!A) return null; const S = (typeof ORDER_SITES !== 'undefined' && ORDER_SITES.find(s => s.k === k)) || {}; return { ...A, check: A.check || S.url, login: A.login || A.check || S.url }; };

// 3.8.0: 같은 쇼핑몰의 다른 아이디 (예: 지그재그 아이디 여러 개)
//        아이디마다 로그인 저장 공간을 따로 써서 서로 안 섞여요. 설치 프로그램에서만 돼요(크림스캐너 확장은 저장 공간이 하나뿐).
let acctExtra = [];   // [{ k: 'zigzag~2', base: 'zigzag', n: 2 }]
const acctBase = k => String(k).split('~')[0];
const acctPart = k => String(k).includes('~') ? 'persist:shop-' + String(k).replace('~', '-') : undefined;
const acctMultiOk = k => !!(window.kcApp && window.__KC_APP) && !String(k).includes('~') && !['musinsa', 'kream', 'kreamp'].includes(k) && typeof ORDER_SITES !== 'undefined' && !!(ORDER_SITES.find(s => s.k === k) || {}).url;
function acctExtraApply() {
  if (!(window.kcApp && window.__KC_APP)) return;
  for (const x of acctExtra) {
    const B = ACCTS.find(a => a.k === x.base), BS = typeof ORDER_SITES !== 'undefined' && ORDER_SITES.find(s => s.k === x.base);
    if (!B || !BS) continue;
    const part = acctPart(x.k), label = `${B.label} #${x.n}`;
    if (!ACCTS.some(a => a.k === x.k)) { let i = ACCTS.map(a => acctBase(a.k)).lastIndexOf(x.base); ACCTS.splice(i + 1, 0, { k: x.k, label, base: x.base, part, check: B.check, login: B.login }); }
    if (!ORDER_SITES.some(s => s.k === x.k)) { let i = ORDER_SITES.map(s => acctBase(s.k)).lastIndexOf(x.base); const { detail, ...rest } = BS; ORDER_SITES.splice(i + 1, 0, { ...rest, detail, k: x.k, label, base: x.base, part, partner: BS.partner || BS.label }); }
  }
}
async function acctExtraAdd(base) {
  const ns = acctExtra.filter(x => x.base === base).map(x => x.n);
  if (ns.length >= 19) throw new Error('한 쇼핑몰에 아이디는 20개까지예요');
  let n = 2; while (ns.includes(n)) n++;
  const k = base + '~' + n;
  acctExtra.push({ k, base, n }); await store.set('acctExtra', acctExtra);
  acctExtraApply();
  // 주문 동기화 구매처에도 바로 켜 둬요
  try { if (typeof IS !== 'undefined') { const M = IS.ms; M.sites = M.sites || new Set((INV.opt.ordSites || ORD_DEFAULT).filter(q => ORDER_SITES.some(S => S.k === q))); M.sites.add(k); M.sites.add(base); INV.opt.ordSites = [...M.sites]; await invSave(); } } catch (e) {}
  return k;
}
async function acctExtraDel(k) {
  acctExtra = acctExtra.filter(x => x.k !== k); await store.set('acctExtra', acctExtra);
  let i = ACCTS.findIndex(a => a.k === k); if (i >= 0) ACCTS.splice(i, 1);
  i = ORDER_SITES.findIndex(s => s.k === k); if (i >= 0) ORDER_SITES.splice(i, 1);
  if (acctData && acctData[k]) { delete acctData[k]; await acctSeal(); }
  delete acctState[k]; await store.set('acctState', acctState);
  try { if (typeof IS !== 'undefined' && IS.ms.sites) { IS.ms.sites.delete(k); INV.opt.ordSites = [...IS.ms.sites]; await invSave(); } } catch (e) {}
  try { await window.kcApp.clearLogin({ domain: '', all: true, part: acctPart(k) }); } catch (e) {}   // 그 아이디 로그인 기록도 지워요
}

let acctVault = null;      // 저장된 암호문 { salt, iv, ct }
let acctKey = null;        // 풀린 열쇠 (이 화면이 열려 있는 동안만)
let acctData = null;       // 풀린 내용 { [k]: { id, pw, auto } }
let acctState = {};        // { [k]: { st: 'on'|'off'|'?', at, msg } }
const AC = { msg: '', edit: {}, show: {}, busy: new Set(), wait: 0 };

const b64 = u8 => btoa(String.fromCharCode(...new Uint8Array(u8)));
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function acctDerive(pin, salt) {
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(String(pin)), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
}
async function acctSeal() {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, acctKey, new TextEncoder().encode(JSON.stringify(acctData || {})));
  acctVault = { ...acctVault, iv: b64(iv), ct: b64(ct) };
  await store.set('acctVault', acctVault);
}
async function acctOpen(key) {
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(acctVault.iv) }, key, unb64(acctVault.ct));
  acctKey = key; acctData = JSON.parse(new TextDecoder().decode(pt));
}
async function acctCreate(pin, remember) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  acctVault = { salt: b64(salt), v: 1 };
  acctKey = await acctDerive(pin, salt); acctData = {};
  await acctSeal(); await acctRemember(remember);
}
async function acctUnlock(pin, remember) {
  const key = await acctDerive(pin, unb64(acctVault.salt));
  try { await acctOpen(key); } catch (e) { throw new Error('PIN이 맞지 않아요'); }
  await acctRemember(remember);
}
// 'PIN 기억': 자동 동기화(크림스캐너가 혼자 돌릴 때)에도 로그인하려면 열쇠를 이 PC에 둬야 해요
async function acctRemember(on) {
  if (on) await store.set('acctKey', b64(await crypto.subtle.exportKey('raw', acctKey)));
  else await store.set('acctKey', null);
}
async function acctInit() {
  acctExtra = await store.get('acctExtra', []); acctExtraApply();
  acctVault = await store.get('acctVault', null);
  acctState = await store.get('acctState', {});
  const raw = await store.get('acctKey', null);
  if (acctVault && raw) { try { await acctOpen(await crypto.subtle.importKey('raw', unb64(raw), 'AES-GCM', true, ['encrypt', 'decrypt'])); } catch (e) { acctKey = null; acctData = null; } }
}
const acctCreds = k => acctData && acctData[k] && acctData[k].id && acctData[k].pw ? acctData[k] : null;
const acctCanAuto = k => !!(acctCreds(k) && acctData[k].auto !== false);
async function acctSetState(k, st, msg) { acctState[k] = { st, at: Date.now(), msg: msg || '' }; await store.set('acctState', acctState); if (typeof renderSide === 'function') { try { renderSide(); } catch (e) {} } }

// 3.2: 로그인 상태 확인 — 설치 프로그램에서는 '보이지 않는 창'으로 바로 확인해요(작업 대기열을 안 기다리고, 여러 곳을 동시에).
//      크림스캐너 확장에서는 예전처럼 작업 창으로 확인해요.
const LOGIN_RE = /(log-?in|sign-?in|\/auth\b|\/auth\/|oauth|nid\.naver\.com|kauth\.kakao|accounts\.kakao|appleid\.apple|member\/login|memberlogin)/i;
const acctFast = () => !!(window.kcApp && window.kcApp.probe);
async function acctCheck(k) {
  const A = acctOf(k); if (!A || !A.check) return null;
  let s = null;
  if (acctFast()) { try { s = await window.kcApp.probe({ url: A.check, func: String(kcLoginState), part: A.part }); } catch (e) { s = null; } }
  else { const tabId = await srcNav(A.check); const [r] = await execT({ target: { tabId }, func: kcLoginState }, 30000); s = r && r.result; }
  if (!s) { await acctSetState(k, '?', '확인 못 함 — 사이트가 늦게 열려요'); return null; }
  await acctSetState(k, s.needLogin ? 'off' : 'on', '');
  return s;
}
async function waitTab(tabId, ms) {
  const end = Date.now() + (ms || 20000);
  await sleep(600);
  while (Date.now() < end) { const t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return null; if (t.status === 'complete') return t; await sleep(300); }
  return chrome.tabs.get(tabId).catch(() => null);
}
// 자동 로그인: 자기만의 창을 열어서 아이디·비밀번호를 넣고 로그인 → 화면이 넘어가면 바로 확인해요.
// 보안문자·인증이 뜨면 그 창을 앞으로 띄우고 멈춰요(직접 마무리).
async function acctLogin(k, o) {
  o = o || {};
  const A = acctOf(k), C = acctCreds(k);
  if (!A) return { ok: false, why: '모르는 사이트' };
  if (!C) return { ok: false, why: '저장된 아이디·비밀번호가 없어요' };
  const w = await chrome.windows.create(winOpts({ url: A.login, type: 'popup', width: 1100, height: 860, focused: !o.quiet, background: !!o.quiet && !!+S.bgWork, part: A.part }));
  const tabId = w.tabs[0].id; let keep = false;
  try { await chrome.tabs.update(tabId, { muted: true }); } catch (e) {}
  try {
    await waitTab(tabId, 20000);
    const [f] = await execT({ target: { tabId }, func: kcLoginFill, args: [C.id, C.pw], world: 'MAIN' }, 40000);
    const r = f && f.result;
    if (!r || !r.ok) {
      if (r && r.why === 'already') { await acctSetState(k, 'on'); return { ok: true }; }
      const why = r && r.why === 'captcha' ? '보안문자·인증이 떠서 직접 로그인해 주세요' : r && r.why === 'nopw' ? '아이디·비밀번호 입력칸을 못 찾았어요 (간편로그인만 되는 계정이면 \'직접 로그인\'을 쓰세요)' : '로그인 화면을 못 읽었어요';
      await acctSetState(k, 'off', why);
      if (r && r.why === 'captcha') { keep = true; try { await chrome.windows.update(w.id, { focused: true, state: 'normal' }); } catch (e) {} }
      return { ok: false, why, keepOpen: keep };
    }
    // 로그인 버튼을 누른 뒤 화면이 넘어갈 때까지 (최대 12초)
    const t0 = Date.now();
    while (Date.now() - t0 < 12000) { await sleep(700); const t = await chrome.tabs.get(tabId).catch(() => null); if (!t) break; if (!LOGIN_RE.test(t.url || '')) break; }
    const [m] = await execT({ target: { tabId }, func: kcLoginState }, 20000).catch(() => [null]);
    if (m && m.result && m.result.captcha && m.result.needLogin) {
      keep = true;
      await acctSetState(k, 'off', '추가 인증(보안문자·문자인증)이 필요해요 — 앞에 띄운 창에서 마무리해 주세요');
      try { await chrome.windows.update(w.id, { focused: true, state: 'normal' }); } catch (e) {}
      return { ok: false, why: '추가 인증이 필요해요', keepOpen: true };
    }
    const s = await acctCheck(k);
    if (s && !s.needLogin) return { ok: true };
    await acctSetState(k, 'off', '로그인이 안 됐어요 — 아이디·비밀번호를 확인해 주세요');
    return { ok: false, why: '로그인이 안 됐어요 (아이디·비밀번호 확인)' };
  } finally { if (!keep) { try { await chrome.windows.remove(w.id); } catch (e) {} } }
}

// ---------- 화면 ----------
// 3.2: 계정 카드 머리 색 (각 쇼핑몰 느낌의 색 — 로고는 쓰지 않아요)
const ACC_STYLE = {
  musinsa: { bg: 'linear-gradient(135deg,#0b0b0d,#2b2d33)', m: 'MSS', sub: 'Musinsa Account' },
  kream: { bg: 'linear-gradient(135deg,#ffffff,#eef0f3)', m: 'KRM', sub: 'Personal Account', lt: 1 },
  kreamp: { bg: 'linear-gradient(135deg,#2563eb,#60a5fa)', m: 'KRP', sub: 'Partner Account · 판매자 센터' },
  zigzag: { bg: 'linear-gradient(135deg,#ff2f86,#ff7bb3)', m: 'ZZ', sub: 'Zigzag Account' },
  coupang: { bg: 'linear-gradient(135deg,#e4312b,#f6862a)', m: 'CP', sub: 'Coupang Account' },
  gmarket: { bg: 'linear-gradient(135deg,#0f9d58,#43c97a)', m: 'G', sub: 'Gmarket Account' },
  abc: { bg: 'linear-gradient(135deg,#c81e1e,#f05252)', m: 'ABC', sub: 'ABC-MART · Grand Stage' },
  '11st': { bg: 'linear-gradient(135deg,#ff2d2d,#ff7a1a)', m: '11', sub: '11st Account' },
  ssg: { bg: 'linear-gradient(135deg,#ffcc00,#ffe066)', m: 'SSG', sub: 'SSG Account', lt: 1 },
  lotte: { bg: 'linear-gradient(135deg,#d6001c,#ff4560)', m: 'ON', sub: 'Lotte ON Account' },
  '29cm': { bg: 'linear-gradient(135deg,#111111,#3a3a3a)', m: '29', sub: '29CM Account' },
  wconcept: { bg: 'linear-gradient(135deg,#1f2937,#4b5563)', m: 'W', sub: 'W Concept Account' },
  rexmonde: { bg: 'linear-gradient(135deg,#1e3a8a,#3b82f6)', m: 'RX', sub: 'Rexmonde Account' },
  nike: { bg: 'linear-gradient(135deg,#f45d0c,#ff9a3c)', m: 'NK', sub: 'Nike Account' },
  ssf: { bg: 'linear-gradient(135deg,#0f766e,#14b8a6)', m: 'SSF', sub: 'SSF Shop Account' },
  '4910': { bg: 'linear-gradient(135deg,#111111,#3b4a12)', m: '4910', sub: '4910 Account · 카카오는 직접 로그인' },
  _: { bg: 'linear-gradient(135deg,#334155,#64748b)', m: '•', sub: '' }
};
function vAcct() {
  const locked = acctVault && !acctData, none = !acctVault;
  const pinBar = none
    ? `<div class="panel acct-pin"><h2>PIN 만들기</h2><p class="hint">아이디·비밀번호를 암호화할 PIN(숫자 4자리 이상)을 정해요. PIN은 어디에도 저장되지 않으니 잊지 않게 해 주세요(잊으면 계정 정보를 다시 넣어야 해요).</p>
       <div class="row-btns"><input type="password" inputmode="numeric" data-ak="pin" placeholder="PIN" style="max-width:160px"><input type="password" inputmode="numeric" data-ak="pin2" placeholder="PIN 한 번 더" style="max-width:160px">
       <label class="chk"><input type="checkbox" data-ak="remember" checked> 이 PC에서 PIN 기억 (자동 동기화 때도 자동 로그인)</label><button type="button" class="primary" data-ac="pinMake">만들기</button></div></div>`
    : locked
      ? `<div class="panel acct-pin"><h2>잠겨 있어요</h2><p class="hint">PIN을 넣으면 저장된 계정으로 자동 로그인할 수 있어요.</p>
         <div class="row-btns"><input type="password" inputmode="numeric" data-ak="pin" placeholder="PIN" style="max-width:160px"><label class="chk"><input type="checkbox" data-ak="remember" checked> 이 PC에서 PIN 기억</label><button type="button" class="primary" data-ac="pinOpen">열기</button></div></div>`
      : '';
  // 3.8.2: 같은 쇼핑몰의 다른 아이디는 따로 카드 대신, 원래 쇼핑몰 카드 안에 한 줄씩 보여줘요
  const subRow = A0 => {
    const A = acctOf(A0.k), k = A.k, st = acctState[k] || {}, C = (acctData && acctData[k]) || {}, E = AC.edit[k] || {}, dis = acctData ? '' : ' disabled', open = AC.open && AC.open[k];
    const n = (acctExtra.find(x => x.k === k) || {}).n, idTxt = E.id ?? C.id ?? '';
    const dot = st.st === 'on' ? '<span class="acct-st on">ON</span>' : st.st === 'off' ? '<span class="acct-st off">OFF</span>' : '<span class="acct-st">확인 전</span>';
    return `<div class="acct-sub${open ? ' open' : ''}">
      <div class="acct-sub-line"><b class="sub-n">#${n}</b><span class="sub-id" title="${esc(idTxt)}">${esc(idTxt || '아이디 없음')}</span>${dot}
        <button type="button" class="ghost tiny" data-ac="login" data-i="${k}"${AC.busy.has(k) ? ' disabled' : ''}>${AC.busy.has(k) ? '…' : '로그인'}</button><button type="button" class="ghost tiny" data-ac="subOpen" data-i="${k}" title="아이디·비밀번호 수정">${open ? '접기' : '수정'}</button></div>
      ${st.msg ? `<p class="small neg">${esc(st.msg)}</p>` : ''}
      ${open ? `<div class="acct-sub-edit">
        <input data-ak="id" data-i="${k}" value="${esc(idTxt)}" autocomplete="off" placeholder="#${n} 아이디(이메일)"${dis}>
        <span class="acct-pw"><input type="${AC.show[k] ? 'text' : 'password'}" data-ak="pw" data-i="${k}" value="${esc(E.pw ?? C.pw ?? '')}" autocomplete="new-password" placeholder="비밀번호"${dis}><button type="button" class="ghost" data-ac="eye" data-i="${k}"${dis}>${AC.show[k] ? '숨김' : '보기'}</button></span>
        <div class="row-btns"><label class="chk"><input type="checkbox" data-ak="auto" data-i="${k}"${(E.auto ?? C.auto) !== false ? ' checked' : ''}${dis}> 자동 로그인</label></div>
        <div class="row-btns"><button type="button" class="primary tiny" data-ac="save" data-i="${k}"${dis}>저장</button><button type="button" class="ghost tiny" data-ac="check" data-i="${k}"${AC.busy.has(k) ? ' disabled' : ''}>상태 확인</button><button type="button" class="ghost tiny" data-ac="open" data-i="${k}" title="카카오·네이버 간편로그인처럼 직접 로그인할 때">직접 로그인</button><button type="button" class="ghost tiny acct-del" data-ac="delId" data-i="${k}">${AC.delAsk === k ? '한 번 더 누르면 삭제' : '삭제'}</button></div>
      </div>` : ''}
    </div>`;
  };
  const cards = ACCTS.filter(A0 => !A0.part).map(A0 => {
    const A = acctOf(A0.k), st = acctState[A.k] || {}, C = (acctData && acctData[A.k]) || {}, E = AC.edit[A.k] || {};
    const pill = st.st === 'on' ? '<span class="acct-st on">● ONLINE</span>' : st.st === 'off' ? '<span class="acct-st off">● OFFLINE</span>' : '<span class="acct-st">● 확인 전</span>';
    const dis = acctData ? '' : ' disabled';
    const P0 = ACC_STYLE[acctBase(A.k)] || ACC_STYLE._, P = A.part ? { ...P0, sub: '다른 아이디 · 로그인 따로 저장' } : P0;
    return `<div class="acct-card${st.st === 'on' ? ' is-on' : st.st === 'off' ? ' is-off' : ''}">
      <div class="acct-head${P.lt ? ' lt' : ''}" style="--hd:${P.bg}"><div class="pf"><span class="pmark">${esc(P.m)}</span><div><b>${esc(A.label)}</b><small>${st.at ? `${new Date(st.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })} 확인` : P.sub}</small></div></div>${pill}</div>
      <div class="acct-body">
      ${st.msg ? `<p class="small neg">${esc(st.msg)}</p>` : ''}
      <label>아이디<input data-ak="id" data-i="${A.k}" value="${esc(E.id ?? C.id ?? '')}" autocomplete="off" placeholder="${esc(A.label)} 아이디"${dis}></label>
      <label>비밀번호<span class="acct-pw"><input type="${AC.show[A.k] ? 'text' : 'password'}" data-ak="pw" data-i="${A.k}" value="${esc(E.pw ?? C.pw ?? '')}" autocomplete="new-password" placeholder="비밀번호"${dis}><button type="button" class="ghost" data-ac="eye" data-i="${A.k}" title="보이기/숨기기"${dis}>${AC.show[A.k] ? '숨김' : '보기'}</button></span></label>
      <div class="row-btns"><label class="chk"><input type="checkbox" data-ak="auto" data-i="${A.k}"${(E.auto ?? C.auto) !== false ? ' checked' : ''}${dis}> 자동 로그인</label></div>
      <div class="row-btns acct-btns"><button type="button" class="ghost" data-ac="save" data-i="${A.k}"${dis}>저장</button><button type="button" class="ghost" data-ac="check" data-i="${A.k}"${AC.busy.has(A.k) ? ' disabled' : ''}>${AC.busy.has(A.k) ? '확인 중…' : '상태 확인'}</button><button type="button" class="ghost" data-ac="open" data-i="${A.k}" title="네이버·카카오 간편로그인처럼 직접 로그인할 때">직접 로그인</button>
        <button type="button" class="primary" data-ac="login" data-i="${A.k}"${AC.busy.has(A.k) ? ' disabled' : ''}>${acctCreds(A.k) ? '자동 로그인' : '로그인 창 열기'}</button>${C.id ? `<button type="button" class="ghost acct-del" data-ac="forget" data-i="${A.k}"${dis}>지우기</button>` : ''}</div>
      ${(() => { const subs = ACCTS.filter(a => a.base === A.k); if (!subs.length && !acctMultiOk(A.k)) return ''; const on = subs.filter(a => (acctState[a.k] || {}).st === 'on').length;
        return `<div class="acct-subs">${subs.length ? `<div class="acct-subs-head"><b>다른 아이디 ${subs.length}개</b><span class="small">ONLINE ${on} / ${subs.length}</span></div>${subs.map(subRow).join('')}` : ''}
          ${acctMultiOk(A.k) ? `<button type="button" class="ghost tiny" data-ac="addId" data-i="${A.k}">+ 다른 아이디 추가</button>` : ''}</div>`; })()}
    </div></div>`;
  }).join('');
  return `${xHead('계정 연결', '쇼핑몰·크림 계정을 저장해 두면, 주문 동기화 때 로그인이 풀린 곳은 자동으로 다시 로그인해요.', `<button type="button" class="primary" data-ac="checkAll"${AC.busy.size ? ' disabled' : ''}>전체 상태 확인</button>`)}
  ${AC.msg ? `<p class="iflash">${esc(AC.msg)}</p>` : ''}
  <div class="panel"><p class="hint"><b>안내:</b> 아이디·비밀번호는 PIN으로 암호화해서 <b>이 PC 크림스캐너에만</b> 저장돼요(백업 파일·휴대폰 보내기·엑셀에 안 들어가요). 보안문자·문자인증이 뜨거나 네이버·카카오 간편로그인만 쓰는 계정(크림 네이버 로그인 등)은 <b>'직접 로그인'</b>을 눌러 열린 창에서 한 번 로그인하고 창을 닫으면 돼요. 로그인은 계속 유지되고, 닫으면 상태를 자동으로 확인해요. ${acctData ? `<button type="button" class="ghost" data-ac="lock">지금 잠그기</button> <button type="button" class="ghost acct-del" data-ac="wipe">계정 정보 전부 지우기</button>` : ''}</p></div>
  ${pinBar}
  <div class="acct-grid">${cards}</div>`;
}
function renderAcct() { if (typeof xView !== 'undefined' && xView === 'acct') renderX(); }
async function acctAct(a, el) {
  const k = el.dataset.i, v = (s) => { const e = document.querySelector(`[data-ak="${s}"]`); return e ? (e.type === 'checkbox' ? e.checked : e.value) : ''; };
  const set = t => { AC.msg = t; renderAcct(); };
  switch (a) {
    case 'pinMake': { const p = v('pin'); if (!/^\d{4,}$/.test(p)) return set('PIN은 숫자 4자리 이상으로 해 주세요'); if (p !== v('pin2')) return set('두 PIN이 달라요'); await acctCreate(p, v('remember')); return set('PIN을 만들었어요. 이제 계정마다 아이디·비밀번호를 넣고 저장을 누르세요.'); }
    case 'pinOpen': try { await acctUnlock(v('pin'), v('remember')); return set('열었어요'); } catch (e) { return set(e.message); }
    case 'lock': acctKey = null; acctData = null; await store.set('acctKey', null); return set('잠갔어요 (자동 동기화 때 자동 로그인도 꺼져요)');
    case 'wipe': if (!AC.wipeAsk) { AC.wipeAsk = true; return set('한 번 더 누르면 저장된 계정 정보와 PIN이 전부 지워져요'); } AC.wipeAsk = false; acctVault = null; acctKey = null; acctData = null; await store.set('acctVault', null); await store.set('acctKey', null); return set('전부 지웠어요');
    case 'eye': AC.show[k] = !AC.show[k]; return renderAcct();
    case 'save': { if (!acctData) return set('먼저 PIN을 만들거나 열어 주세요'); const E = AC.edit[k] || {}, C = acctData[k] || {}; acctData[k] = { id: String(E.id ?? C.id ?? '').trim(), pw: String(E.pw ?? C.pw ?? ''), auto: (E.auto ?? C.auto) !== false }; delete AC.edit[k]; await acctSeal(); return set(`${acctOf(k).label} 계정을 저장했어요`); }
    case 'forget': { if (!acctData) return; delete acctData[k]; delete AC.edit[k]; await acctSeal(); return set(`${acctOf(k).label} 계정 정보를 지웠어요`); }
    case 'check': return acctDo(k, async () => { const s = await acctCheck(k); AC.msg = s ? `${acctOf(k).label}: ${s.needLogin ? 'OFFLINE (로그인 필요)' : 'ONLINE'}` : '확인 못 했어요'; });
    case 'checkAll': return acctCheckAll();
    case 'subOpen': AC.open = AC.open || {}; AC.open[k] = !AC.open[k]; return renderAcct();
    case 'addId': { const nk = await acctExtraAdd(k); AC.open = AC.open || {}; AC.open[nk] = true; return set(`${acctOf(nk).label} 칸을 만들었어요 — 아이디·비밀번호를 넣고 저장 → 자동 로그인 (또는 '직접 로그인'). 주문 동기화 구매처에도 켜 뒀어요.`); }
    case 'delId': { if (AC.delAsk !== k) { AC.delAsk = k; return renderAcct(); } AC.delAsk = null; const lb = acctOf(k).label; await acctExtraDel(k); return set(`${lb} 칸을 지웠어요 (이미 입고한 재고는 그대로예요)`); }
    case 'open': return acctOpenWin(k);
    case 'login': {
      if (!acctCreds(k)) return acctOpenWin(k);
      return acctDo(k, async () => { AC.msg = `${acctOf(k).label} 로그인 중…`; renderAcct(); const r = await acctLogin(k); AC.msg = r.ok ? `${acctOf(k).label} 로그인 완료` : `${acctOf(k).label}: ${r.why}`; });
    }
  }
}
// 3.2: 계정 작업은 사이트마다 따로 돌아요 — 다른 작업(주문 동기화 등)을 기다리지 않고, 버튼도 그 사이트 것만 잠깐 잠겨요.
//      (크림스캐너 확장은 작업 창을 같이 써서 예전처럼 차례대로)
async function acctDo(k, fn) {
  if (AC.busy.has(k)) return;
  if (!acctFast()) return acctRun(fn, `${acctOf(k).label} 계정`);
  AC.busy.add(k); renderAcct();
  try { await fn(); } catch (e) { AC.msg = '멈췄어요: ' + e.message; } finally { AC.busy.delete(k); renderAcct(); }
}
async function acctCheckAll() {
  if (!acctFast()) return acctRun(async () => { for (const A of ACCTS) { AC.msg = `${A.label} 확인 중…`; jobSay(AC.msg); renderAcct(); try { await acctCheck(A.k); } catch (e) { await acctSetState(A.k, '?', '확인 못 함'); } } acctSum(); }, '전체 계정 상태 확인');
  const q = ACCTS.filter(A => !AC.busy.has(A.k)); q.forEach(A => AC.busy.add(A.k)); AC.msg = '전체 확인 중… (4곳씩 동시에)'; renderAcct();
  await Promise.all(Array.from({ length: 4 }, async () => { while (q.length) { const A = q.shift(); try { await acctCheck(A.k); } catch (e) { await acctSetState(A.k, '?', '확인 못 함'); } AC.busy.delete(A.k); renderAcct(); } }));
  acctSum(); renderAcct();
}
function acctSum() { const off = ACCTS.filter(A => (acctState[A.k] || {}).st === 'off').map(A => A.label); AC.msg = off.length ? `로그인 필요: ${off.join(', ')}` : '전부 로그인돼 있어요'; if (typeof topStatus === 'function') topStatus(); }
// 직접 로그인: 창을 열어 두고, 로그인이 끝나 화면이 넘어가면 바로 확인 → 로그인됐으면 창을 알아서 닫아요. 직접 닫아도 바로 확인해요.
async function acctOpenWin(k) {
  const A = acctOf(k); let tab = null;
  // 3.4.6: 크림은 '직접 로그인'을 누르면 남아 있던(꼬인) 로그인 쿠키를 먼저 지우고 깨끗하게 다시 로그인해요
  if ((k === 'kream' || k === 'kreamp') && window.kcApp && window.kcApp.clearLogin && !(window.__KC_WHALE && window.__KC_WHALE.via === 'whale')) { try { await window.kcApp.clearLogin(k === 'kream' ? { domain: 'kream.co.kr', exact: true } : { domain: 'partner.kream.co.kr' }); } catch (e) {} }
  try { tab = await chrome.tabs.create(A.part ? { url: A.login, part: A.part } : { url: A.login }); } catch (e) { window.open(A.login, '_blank'); }
  AC.msg = `${A.label} 로그인 창을 열었어요. 로그인을 끝내면 자동으로 확인하고 창을 닫아요.`; renderAcct();
  if (!tab || !(tab.id > 0)) return;
  const t0 = Date.now(); let lastUrl = '', checking = false, closed = false;
  while (Date.now() - t0 < 20 * 60000) {
    await sleep(1000);
    const t = await chrome.tabs.get(tab.id).catch(() => null);
    if (!t) { closed = true; break; }
    const url = t.url || '';
    if (url !== lastUrl && !LOGIN_RE.test(url) && t.status === 'complete' && !checking && lastUrl) {
      checking = true;
      const s = await acctCheck(k).catch(() => null);
      checking = false;
      if (s && !s.needLogin) { try { if (t.windowId > 0) await chrome.windows.remove(t.windowId); } catch (e) {} AC.msg = `${A.label}: ONLINE — 로그인됐어요`; renderAcct(); if (typeof topStatus === 'function') topStatus(); return; }
    }
    lastUrl = url;
  }
  if (closed) return acctDo(k, async () => { const s = await acctCheck(k); AC.msg = s ? `${A.label}: ${s.needLogin ? 'OFFLINE — 아직 로그인이 안 됐어요' : 'ONLINE — 로그인됐어요'}` : '확인 못 했어요'; if (typeof topStatus === 'function') topStatus(); });
}
function acctRun(fn, label) {
  if (AC.wait) { AC.msg = '이미 계정 작업이 기다리는 중이에요.'; return renderAcct(); }
  AC.wait = 1;
  if (jobBusy) AC.msg = `앞의 작업(${jobNow || '작업'})이 끝나면 바로 시작해요. 기다리기 싫으면 위쪽 '중지'를 누르세요.`;
  renderAcct();
  return queueJob(async () => {
    AC.wait = 0; renderAcct();
    try { await fn(); } catch (e) { AC.msg = '멈췄어요: ' + e.message; } finally { if (typeof closeWork === 'function') await closeWork(); renderAcct(); }
  }, { label: label || '계정 연결', onSkip: () => { AC.wait = 0; AC.msg = '취소했어요'; renderAcct(); } });
}
function acctInput(el) {
  const k = el.dataset.i, f = el.dataset.ak; if (!k) return;
  AC.edit[k] = AC.edit[k] || {}; AC.edit[k][f] = el.type === 'checkbox' ? el.checked : el.value;
}
function acctBind() {
  const m = $('#xMain'); if (!m) return;
  m.addEventListener('click', e => { const el = e.target.closest('[data-ac]'); if (el) acctAct(el.dataset.ac, el).catch(err => { AC.msg = '오류: ' + err.message; renderAcct(); }); });
  m.addEventListener('input', e => { const el = e.target.closest('[data-ak]'); if (el) acctInput(el); });
  m.addEventListener('change', e => { const el = e.target.closest('[data-ak]'); if (el) acctInput(el); });
}

// 주문 동기화에서 씀: 로그인이 풀려 있으면(자동 로그인 켠 계정만) 다시 로그인하고 한 번 더 시도
async function acctEnsure(k, quiet) {
  if (!acctCanAuto(k)) return false;
  const r = await acctLogin(k, { quiet });
  return r.ok;
}
