// 툴바 아이콘을 누르면 '크림스캐너' 페이지를 열어요. 이미 열려 있으면 그 탭으로 이동해요.
async function openApp() {
  const url = chrome.runtime.getURL('app.html');
  const tabs = await chrome.tabs.query({});
  const found = tabs.find(t => (t.url || '').startsWith(url));
  if (found) {
    await chrome.tabs.update(found.id, { active: true });
    await chrome.windows.update(found.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
}
chrome.action.onClicked.addListener(() => { openApp(); });

// 가격 추적: 설정한 간격마다 '크림스캐너'를 뒤에서 열어 추적 중인 상품의 매입처를 다시 찾아요
chrome.alarms.onAlarm.addListener(a => {
  if (a.name === 'kc-track') chrome.tabs.create({ url: chrome.runtime.getURL('app.html?track=1'), active: false });
  // 구매처 주문 자동 동기화 (재고관리 → 구매처 주문 입고 → 자동 동기화)
  if (a.name === 'ks-orders') chrome.tabs.create({ url: chrome.runtime.getURL('app.html?orders=1'), active: false });
});
chrome.notifications.onClicked.addListener(() => { openApp(); });

// ---------- 3.7: 크림스캐너 프로그램과 연결 (크림 작업을 웨일에서 대신 해요) ----------
// 프로그램(127.0.0.1:47615)에 할 일을 물어보고, 크림 창 열기·읽기·매크로를 이 웨일(사장님 크림 로그인 그대로)에서 한 뒤 결과를 돌려줘요.
try { importScripts('content/find.js'); } catch (e) { console.error('[kc] find.js', e); }
const KC_BR = 'http://127.0.0.1:47615/kc';
let kcBrOn = false;
const kcSleep = ms => new Promise(r => setTimeout(r, ms));
const kcFn = n => (n && typeof self[n] === 'function') ? self[n] : null;
const KC_OWN = new Set();   // 이 연결이 연 창들 (닫을 때만 씀)
// 3.9.9: 창이 쌓이지 않게 — 연결이 연 창마다 마지막으로 쓴 시각을 적어 두고, 4분 넘게 안 쓴 창은 닫아요. 뒤에서 쓰는 창은 최대 3개.
const KC_USE = new Map();
const KC_BUSY = new Map();   // 3.10.13: 수집처럼 오래 걸리는 작업 중인 창은 절대 안 닫아요 (창 id → 진행 중 개수)
const kcTouch = id => { if (id && KC_OWN.has(id)) KC_USE.set(id, Date.now()); };
async function kcGc(keep) {
  const now = Date.now();
  for (const id of [...KC_OWN]) { if (id === keep || KC_BUSY.get(id)) continue; if (now - (KC_USE.get(id) || 0) > 4 * 60000) { KC_OWN.delete(id); KC_USE.delete(id); chrome.windows.remove(id).catch(() => {}); } }
  const live = [...KC_OWN].filter(id => id !== keep && !KC_BUSY.get(id)).sort((a, b) => (KC_USE.get(a) || 0) - (KC_USE.get(b) || 0));
  while (live.length > 2) { const id = live.shift(); KC_OWN.delete(id); KC_USE.delete(id); chrome.windows.remove(id).catch(() => {}); }
}
async function kcWaitTab(tabId, ms) {
  const end = Date.now() + (ms || 20000);
  while (Date.now() < end) { const t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return null; if (t.status === 'complete') return t; await kcSleep(300); }
  return chrome.tabs.get(tabId).catch(() => null);
}
// 뒤에서 할 때: 기본은 최소화한 창(화면에 안 보여요). 설정이 'corner'면 화면 구석의 작은 창.
let KC_BGMODE = 'min';
async function kcMakeWin(url, focused, bg, w, h, mode) {
  const m = mode || KC_BGMODE; let win;
  if (bg && !focused && m === 'min') {
    try { win = await chrome.windows.create({ url, type: 'normal', state: 'minimized' }); } catch (e) { win = null; }
  }
  if (!win) {
    const o = { url, type: 'popup', focused: !!focused, width: w || 1180, height: h || 900 };
    if (bg && !focused && m === 'min') o.focused = false;
    if (bg && !focused) { o.width = 520; o.height = 700; try { const cur = await chrome.windows.getLastFocused(); o.left = Math.max(0, (cur.left || 0) + (cur.width || 1600) - 540); o.top = Math.max(0, (cur.top || 0) + (cur.height || 900) - 720); } catch (e) {} }
    try { win = await chrome.windows.create(o); } catch (e) { delete o.left; delete o.top; win = await chrome.windows.create(o); }
    if (bg && !focused && m === 'min') { try { await chrome.windows.update(win.id, { state: 'minimized' }); } catch (e) {} }   // 최소화로 못 만들었으면 바로 최소화
  }
  KC_OWN.add(win.id); KC_USE.set(win.id, Date.now());
  if (bg && !focused) kcGc(win.id).catch(() => {});
  const tabId = (win.tabs && win.tabs[0] && win.tabs[0].id) || (await chrome.tabs.query({ windowId: win.id }))[0].id;
  try { await chrome.tabs.update(tabId, { muted: true }); } catch (e) {}
  return { winId: win.id, tabId };
}
const KC_OPS = {
  ping: async () => ({ ver: chrome.runtime.getManifest().version }),
  winCreate: a => kcMakeWin(a.url, a.focused, a.bg, a.width, a.height, a.mode),
  setMode: async a => { KC_BGMODE = a.mode === 'corner' ? 'corner' : 'min'; return KC_BGMODE; },
  winGet: async a => { const w = await chrome.windows.get(a.id); return { focused: w.focused, state: w.state }; },
  winUpdate: async a => {
    const o = {}; if (a.focused) { o.focused = true; o.state = 'normal'; } else if (a.state) o.state = a.state;
    await chrome.windows.update(a.id, o); return true;
  },
  winRemove: async a => { await chrome.windows.remove(a.id).catch(() => {}); KC_OWN.delete(a.id); return true; },
  tabGet: async a => { const t = await chrome.tabs.get(a.id); return { url: t.url || t.pendingUrl || '', status: t.status, windowId: t.windowId }; },
  tabUpdate: async a => { const o = {}; if (a.url) o.url = a.url; if (a.muted !== undefined && a.muted !== null) o.muted = !!a.muted; await chrome.tabs.update(a.id, o); return true; },
  tabReload: async a => { await chrome.tabs.reload(a.id, { bypassCache: !!a.bypassCache }); return true; },
  tabCreate: async a => { const t = await chrome.tabs.create({ url: a.url, active: true }); try { await chrome.windows.update(t.windowId, { focused: true }); } catch (e) {} return { tabId: t.id, winId: t.windowId }; },
  send: a => chrome.tabs.sendMessage(a.id, a.msg),
  exec: async a => {
    const fn = kcFn(a.name); if (!fn) throw new Error('웨일 확장에 없는 기능이에요: ' + a.name + ' (웨일 확장을 새로 고쳐 주세요)');
    const [r] = await chrome.scripting.executeScript({ target: { tabId: a.id }, func: fn, args: a.args || [], world: a.world === 'MAIN' ? 'MAIN' : 'ISOLATED' });
    return r ? r.result : null;
  },
  probe: async a => {
    const { winId, tabId } = await kcMakeWin(a.url, false, true, 1100, 800);
    try { await kcWaitTab(tabId, 15000); await kcSleep(900); const fn = kcFn(a.name); if (!fn) return null; const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: fn }); return r ? r.result : null; }
    finally { chrome.windows.remove(winId).catch(() => {}); KC_OWN.delete(winId); }
  },
  reload: async () => { setTimeout(() => chrome.runtime.reload(), 300); return true; }
};
async function kcHandle(c) {
  let out;
  try {
    const a = c.args || {};
    if (/^win/.test(c.op) && a.id) kcTouch(a.id);
    let busyWin = null;
    if (/^(tab|send|exec)/.test(c.op) && a.id) { try { const t = await chrome.tabs.get(a.id); kcTouch(t.windowId); if (c.op === 'send' || c.op === 'exec') { busyWin = t.windowId; KC_BUSY.set(busyWin, (KC_BUSY.get(busyWin) || 0) + 1); } } catch (e) {} }
    const f = KC_OPS[c.op]; if (!f) throw new Error('모르는 작업: ' + c.op);
    try { out = { id: c.id, ok: true, value: await f(a) }; }
    finally { if (busyWin != null) { const n = (KC_BUSY.get(busyWin) || 1) - 1; if (n > 0) KC_BUSY.set(busyWin, n); else KC_BUSY.delete(busyWin); kcTouch(busyWin); } }
    if (c.op === 'exec' && a.id) { try { const t = await chrome.tabs.get(a.id); kcTouch(t.windowId); } catch (e) {} }
  }
  catch (e) { out = { id: c.id, ok: false, error: String(e && e.message || e) }; }
  try { await fetch(KC_BR + '/result', { method: 'POST', body: JSON.stringify(out) }); } catch (e) {}
}
async function kcBridge() {
  if (kcBrOn) return; kcBrOn = true;
  const v = chrome.runtime.getManifest().version;
  try {
    for (;;) {
      let cmds;
      try { const r = await fetch(KC_BR + '/poll?v=' + v, { cache: 'no-store' }); if (!r.ok) break; cmds = await r.json(); }
      catch (e) { break; }   // 프로그램이 꺼져 있으면 멈추고, 알람이 30초마다 다시 깨워요
      try { await chrome.runtime.getPlatformInfo(); } catch (e) {}   // 웨일이 이 연결을 재우지 않게
      for (const c of cmds || []) kcHandle(c);
    }
  } finally { kcBrOn = false; }
}
chrome.alarms.create('kc-bridge', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'kc-bridge') { kcBridge(); kcGc().catch(() => {}); } });
chrome.windows.onRemoved.addListener(id => { KC_OWN.delete(id); KC_USE.delete(id); KC_BUSY.delete(id); });
chrome.runtime.onStartup.addListener(() => kcBridge());
chrome.runtime.onInstalled.addListener(() => kcBridge());
kcBridge();
