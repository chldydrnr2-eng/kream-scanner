// 크림 마이페이지(판매·구매·보관 내역)가 스스로 불러오는 응답을 옆에서 받아 적어요. 크림에 따로 요청을 보내지 않아요.
(() => {
  if (window.__kcMyHooked) return;
  window.__kcMyHooked = true;
  const RE = /api\.kream\.co\.kr\/api\/(o|m|seller|settlement|my|p\/my|v\d\/my)\//;
  const SKIP = /notification|banner|recommend|popup|event/;
  window.__kcMyCap = window.__kcMyCap || [];   // 3.10.22: 같은 화면(MAIN)에서도 읽을 수 있게 받아 적은 응답을 남겨 둬요
  const post = (url, data) => { try { window.__kcMyCap.push({ url: String(url), data, t: Date.now() }); if (window.__kcMyCap.length > 300) window.__kcMyCap.shift(); } catch (e) {} try { window.postMessage({ __kcmy: 1, url: String(url).replace(/([?&])request_key=[^&]*/, '$1'), data }, location.origin); } catch (e) {} };
  // 3.10.19: 크림 화면이 api.kream.co.kr에 보낼 때 쓰는 머리글(헤더)을 기억해 둬요 → 보관판매 내역을 화면과 똑같이 다시 읽을 때 써요
  const keepHdr = h => { try { const o = {}; if (!h) return; if (typeof h.forEach === 'function' && !Array.isArray(h)) h.forEach((v, k) => { o[k] = v; }); else if (Array.isArray(h)) h.forEach(([k, v]) => { o[k] = v; }); else Object.assign(o, h); delete o['content-length']; if (Object.keys(o).length) window.__kcMyHdr = o; } catch (e) {} };
  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    try { const u0 = typeof input === 'string' ? input : (input && input.url) || ''; if (/api\.kream\.co\.kr\/api\//.test(u0)) keepHdr((init && init.headers) || (input && input.headers)); } catch (e) {}
    const p = origFetch.call(window, input, init);
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || String(input);
      if (RE.test(url) && !SKIP.test(url)) p.then(r => r.clone().json().then(j => post(url, j)).catch(() => {})).catch(() => {});
    } catch (e) {}
    return p;
  };
  const X = XMLHttpRequest.prototype, open = X.open, send = X.send, setH = X.setRequestHeader;
  X.open = function (m, url) { this.__kcMy = String(url); this.__kcH = {}; return open.apply(this, arguments); };
  X.setRequestHeader = function (k, v) { try { if (this.__kcH) this.__kcH[k] = v; } catch (e) {} return setH.apply(this, arguments); };
  X.send = function () {
    try { if (this.__kcMy && /api\.kream\.co\.kr\/api\//.test(this.__kcMy)) keepHdr(this.__kcH); } catch (e) {}
    if (this.__kcMy && RE.test(this.__kcMy) && !SKIP.test(this.__kcMy)) this.addEventListener('load', () => { try { post(this.__kcMy, JSON.parse(this.responseText)); } catch (e) {} });
    return send.apply(this, arguments);
  };
})();
