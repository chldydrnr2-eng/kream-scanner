'use strict';
/* 킥스캔 본체 (3.1.1부터 자동 업데이트로 바뀌는 부분)
   웨일 확장 프로그램이 쓰던 chrome.* 기능(저장소·작업 창·사이트 읽기·알림·예약·업데이트)을 이 프로그램 안에서 해 줘요. */
module.exports = function (ctx) {
const { app, BrowserWindow, ipcMain, Notification, Tray, Menu, shell, session, nativeImage, webContents, net, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { BUNDLED, ROOT, VER, cmpVer } = ctx;
// 3.11.1: 새 KS 아이콘은 업데이트 폴더에 들어 있어요 — 있으면 그걸 창·알림·트레이 아이콘으로 써요
const ICON = (() => { try { const p = path.join(ROOT, 'icons', '256.png'); if (fs.existsSync(p)) return p; } catch (e) {} return ctx.ICON; })();
// 3.6.0: 브라우저 정보는 실제 엔진 버전에 맞춰요 (예전 설치본의 고정값 Chrome/130 대신)
const UA = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${String(process.versions.chrome || '130').split('.')[0]}.0.0.0 Safari/537.36`;
app.userAgentFallback = UA;
const PART = 'persist:shop';
// 3.8.0: 같은 쇼핑몰의 다른 아이디는 따로 저장 공간(persist:shop-zigzag-2 …)을 써요 — 로그인이 서로 안 섞이게
const PART_RE = /^persist:shop-[a-z0-9-]{1,40}$/;
const partOf = p => (typeof p === 'string' && PART_RE.test(p)) ? p : PART;
const prepped = new Set();
function prepShop(p) {
  p = partOf(p); const s = session.fromPartition(p);
  if (prepped.has(p)) return s; prepped.add(p);
  s.setUserAgent(DATA.__shopUA || UA, 'ko-KR,ko,en-US,en');
  s.setPermissionRequestHandler((wc, perm, cb) => cb(perm === 'notifications' ? false : perm === 'clipboard-sanitized-write'));
  keepLogins(s);
  if (p !== PART) { const l = DATA.__parts || (DATA.__parts = []); if (!l.includes(p)) { l.push(p); saveSoon(); } }
  return s;
}
// ---------- 3.0.1: 프로그램 안에서 업데이트 (화면·기능 파일만 바꾸는 작은 업데이트) ----------
// %APPDATA%\\KreamScanner\\app-update 에 더 새 버전이 있으면 그걸 써요. 설치 파일을 다시 받을 필요가 없어요.
const _cmpVerUnused = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
const UPD = () => path.join(app.getPath('userData'), 'app-update');

// 아주 작은 zip 풀기 (업데이트 파일 전용)
function unzip(buf) {
  const zlib = require('zlib'), out = [];
  let eocd = buf.length - 22; while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  if (eocd < 0) throw new Error('zip 파일이 아니에요');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip 목록이 깨졌어요');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), loff = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8');
    p += 46 + nlen + elen + clen;
    if (name.endsWith('/')) continue;
    const ds = loff + 30 + buf.readUInt16LE(loff + 26) + buf.readUInt16LE(loff + 28);
    const raw = buf.slice(ds, ds + csize);
    out.push({ name, data: method === 0 ? raw : zlib.inflateRawSync(raw) });
  }
  return out;
}
// 3.13.0: 업데이트 파일 서명 확인 — 우리 서명 키로 만든 파일만 깔려요 (저장소가 털려도 남의 코드가 안 깔리게)
const UPD_PUB = '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAmjG//MvS7hhsBZ5ULdg0JT35LLZD2BIy3h/5vDqe5ps=\n-----END PUBLIC KEY-----\n';
function updDigest(files, base) {
  const crypto = require('crypto');
  const lines = files.filter(f => f.name.startsWith(base) && f.name !== base + 'update.sig').map(f => f.name.slice(base.length) + '\0' + crypto.createHash('sha256').update(f.data).digest('hex')).sort();
  return Buffer.from(lines.join('\n'), 'utf8');
}
function updVerify(files, base) {
  const sf = files.find(f => f.name === base + 'update.sig');
  if (!sf) throw new Error('서명이 없는 업데이트 파일이라 설치하지 않았어요');
  let ok = false; try { ok = require('crypto').verify(null, updDigest(files, base), UPD_PUB, Buffer.from(sf.data.toString('utf8').trim(), 'base64')); } catch (e) { ok = false; }
  if (!ok) throw new Error('업데이트 파일 서명이 맞지 않아서 설치하지 않았어요 (파일이 바뀌었거나 공식 파일이 아니에요)');
}
function applyUpdate(bytes) {
  const files = unzip(Buffer.from(bytes));
  const vf = files.find(f => /(^|\/)version\.json$/.test(f.name)); if (!vf) throw new Error('킥스캔 업데이트 파일이 아니에요 (version.json 없음)');
  const base = vf.name.replace(/version\.json$/, '');
  const ver = JSON.parse(vf.data.toString('utf8')).version;
  if (!files.some(f => f.name === base + 'app.html')) throw new Error('업데이트 파일에 화면 파일이 없어요');
  if (cmpVer(ver, VER) <= 0) throw new Error(`이미 ${VER} 버전이에요 (업데이트 파일은 ${ver})`);
  updVerify(files, base);
  const tmp = UPD() + '.tmp'; fs.rmSync(tmp, { recursive: true, force: true });
  for (const f of files) {
    if (!f.name.startsWith(base)) continue;
    const rel = f.name.slice(base.length); if (!rel || rel.includes('..')) continue;
    const dst = path.join(tmp, rel); fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.writeFileSync(dst, f.data);
  }
  fs.rmSync(UPD(), { recursive: true, force: true }); fs.renameSync(tmp, UPD());
  return ver;
}


// ---------- 저장소 (chrome.storage.local 대신 JSON 파일) ----------
let DATA = {}, saveT = null;
const dataFile = () => path.join(app.getPath('userData'), 'kream-data.json');
function loadData() {
  for (const f of [dataFile(), dataFile() + '.bak']) {
    try { DATA = JSON.parse(fs.readFileSync(f, 'utf8')); return; } catch (e) {}
  }
  DATA = {};
}
function flush() {
  clearTimeout(saveT); saveT = null;
  const f = dataFile(), tmp = f + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(DATA));
    try { if (fs.existsSync(f)) fs.copyFileSync(f, f + '.bak'); } catch (e) {}
    fs.renameSync(tmp, f);
  } catch (e) { console.error('save failed', e); }
}
const saveSoon = () => { if (!saveT) saveT = setTimeout(flush, 400); };

// ---------- 창 ----------
let appWin = null, tray = null, quitting = false;
const appFile = () => path.join(ROOT, 'app.html');
const isAppUrl = u => /(^|\/)app\.html(\?|$)/.test(String(u)) || String(u).startsWith(pathToFileURL(appFile()).href);

function createAppWin(query, show) {
  const w = new BrowserWindow({
    width: 1480, height: 940, minWidth: 900, minHeight: 600, show: show !== false, icon: ICON, title: '킥스캔', autoHideMenuBar: true, backgroundColor: '#f3f4f2',
    webPreferences: { preload: path.join(ROOT, 'app-preload.js'), contextIsolation: false, sandbox: false, nodeIntegration: false, backgroundThrottling: false, additionalArguments: ['--kc-root=' + ROOT, '--kc-ver=' + VER] }
  });
  w.loadFile(appFile(), { search: query ? String(query).replace(/^\?/, '') : '' });
  w.webContents.setWindowOpenHandler(({ url }) => { openLink(url); return { action: 'deny' }; });
  w.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); openLink(url); } });
  return w;
}
function showMain() {
  if (!appWin || appWin.isDestroyed()) {
    appWin = createAppWin('', true);
    appWin.on('close', e => { if (!quitting) { e.preventDefault(); appWin.hide(); trayHint(); } });
  }
  if (appWin.isMinimized()) appWin.restore();
  appWin.show(); appWin.focus();
}
let hinted = false;
function trayHint() { if (hinted) return; hinted = true; notify('킥스캔는 계속 실행 중이에요', '오른쪽 아래 작업 표시줄의 킥스캔 아이콘에서 다시 열거나 종료할 수 있어요. 자동 동기화·가격 추적은 켜 둔 동안 돌아가요.'); }

// 쇼핑몰 창(작업 창 · 로그인 창): 로그인은 persist:shop 에 저장돼요
function shopWin(url, opts) {
  opts = opts || {}; const part = partOf(opts.part); prepShop(part);
  const w = new BrowserWindow({
    width: opts.width || 1180, height: opts.height || 900, show: !opts.background, icon: ICON, autoHideMenuBar: true, title: opts.title || '킥스캔',
    webPreferences: { partition: part, preload: path.join(ROOT, 'work-preload.js'), contextIsolation: true, sandbox: false, nodeIntegration: false, backgroundThrottling: false, additionalArguments: ['--kc-root=' + ROOT] }
  });
  if (opts.background) bgHide(w);
  else if (opts.focused === false) w.showInactive();
  w.webContents.setWindowOpenHandler(() => ({ action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, icon: ICON, webPreferences: { partition: part, sandbox: false, contextIsolation: true, nodeIntegration: false } } }));   // 3.34: 여는 창과 sandbox를 맞춰야 로그인 팝업(네이버 등)이 원래 창으로 결과를 돌려줘요
  const wcid = w.webContents.id;
  w.webContents.on('did-start-navigation', (e) => { if (e.isMainFrame && !e.isSameDocument) domReady.set(wcid, false); });
  w.webContents.on('dom-ready', () => { setTimeout(() => domReady.set(wcid, true), 1200); });   // 화면이 그려지면 '완료'로 봐요 (광고 로딩은 안 기다려요)
  w.on('closed', () => domReady.delete(wcid));
  // 3.4.4: 화면이 비어 있을 때 원인을 알 수 있게 응답 코드·실패 이유를 적어 둬요
  w.webContents.on('did-navigate', (e, u, code, st) => navInfo.set(wcid, { url: u, code, st }));
  w.webContents.on('did-fail-load', (e, code, desc, u, main) => { if (main && code !== -3) navInfo.set(wcid, { url: u, fail: code + ' ' + desc }); });
  w.on('closed', () => navInfo.delete(wcid));
  if (url) w.loadURL(url).catch(() => {});
  return w;
}
const domReady = new Map();
const navInfo = new Map();
// 3.4.1: 작업 창을 뒤에서 실행 — 창은 그대로 그려지게(사이트가 정상 동작하게) 모든 모니터 바깥에 두고, 작업 표시줄·포커스도 안 가져가요.
// 직접 봐야 할 때(확인 화면·보안문자 등) windows.update(focused) 가 오면 화면 가운데로 꺼내요.
function bgHide(w) {
  try {
    const ds = screen.getAllDisplays();
    const x = Math.max(...ds.map(d => d.bounds.x + d.bounds.width)) + 400, y = Math.min(...ds.map(d => d.bounds.y));
    w.__bg = true; w.setSkipTaskbar(true); w.setPosition(x, y); w.showInactive(); w.setPosition(x, y);
  } catch (e) { w.showInactive(); }
}
function bgShow(w) {
  if (!w.__bg) return;
  w.__bg = false; w.setSkipTaskbar(false);
  try { const d = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).workArea; const [bw, bh] = w.getSize(); w.setPosition(Math.round(d.x + (d.width - bw) / 2), Math.round(d.y + Math.max(0, (d.height - bh) / 2))); } catch (e) { w.center(); }
}
function openLink(url) {
  if (!/^https?:/i.test(url)) return;
  if (/claude\.ai|claude\.com|(^|\.)kakao\.com\//i.test(url)) return shell.openExternal(url);   // 휴대폰용 페이지는 원래 쓰던 브라우저로
  shopWin(url, { title: '킥스캔 — 브라우저' });
}

// ---------- 알림 ----------
function notify(title, body, onClick) {
  try { const n = new Notification({ title, body, icon: ICON }); n.on('click', onClick || showMain); n.show(); } catch (e) {}
}

// ---------- 예약 (chrome.alarms 대신) ----------
const timers = new Map();
function alarmFire(name) {
  if (name === 'kc-track') createAppWin('?track=1', false);
  if (name === 'ks-orders') createAppWin('?orders=1', false);
}
function alarmSchedule(name, a) {
  const old = timers.get(name); if (old) { clearTimeout(old.t); clearInterval(old.i); }
  const period = Math.max(1, +a.periodInMinutes || 0) * 60000, first = Math.max(1, +a.delayInMinutes || +a.periodInMinutes || 1) * 60000;
  const rec = { t: null, i: null };
  rec.t = setTimeout(() => { alarmFire(name); if (a.periodInMinutes) rec.i = setInterval(() => alarmFire(name), period); }, first);
  timers.set(name, rec);
}
function alarmsRestore() { for (const [n, a] of Object.entries(DATA.__alarms || {})) alarmSchedule(n, { ...a, delayInMinutes: a.periodInMinutes }); }

// ---------- 사이트 메시지 (chrome.tabs.sendMessage 대신) ----------
let msgSeq = 0; const waiting = new Map();
ipcMain.on('kc-reply', (e, id, resp) => { const w = waiting.get(id); if (w) { waiting.delete(id); w(resp); } });

const wcOf = id => { const wc = webContents.fromId(+id); if (!wc || wc.isDestroyed()) throw new Error('No tab with id: ' + id); return wc; };
const winOf = id => { const w = BrowserWindow.fromId(+id); if (!w || w.isDestroyed()) throw new Error('No window with id: ' + id); return w; };

const API = {
  storage: {
    get(keys) {
      if (keys == null) return { ...DATA, __alarms: undefined };
      if (typeof keys === 'string') return keys in DATA ? { [keys]: DATA[keys] } : {};
      if (Array.isArray(keys)) return Object.fromEntries(keys.filter(k => k in DATA).map(k => [k, DATA[k]]));
      return Object.fromEntries(Object.entries(keys).map(([k, d]) => [k, k in DATA ? DATA[k] : d]));
    },
    set(obj) { for (const [k, v] of Object.entries(obj || {})) { if (v === undefined) delete DATA[k]; else DATA[k] = v; } saveSoon(); return true; },
    remove(keys) { for (const k of [].concat(keys)) delete DATA[k]; saveSoon(); return true; }
  },
  windows: {
    create(o) { const w = shopWin(o.url, { width: o.width, height: o.height, focused: o.focused, background: !!o.background, part: o.part }); return { id: w.id, tabs: [{ id: w.webContents.id }] }; },
    get(id) { const w = winOf(id); return { id: w.id, focused: w.isFocused(), state: w.isMinimized() ? 'minimized' : 'normal', background: !!w.__bg }; },
    update(id, o) { const w = winOf(id); if (o && o.focused) bgShow(w); if (o && (o.state === 'normal' || o.focused)) { if (w.isMinimized()) w.restore(); if (!w.__bg) w.show(); } if (o && o.focused) w.focus(); return { id: w.id }; },
    remove(id) { const w = winOf(id); w.destroy(); return true; }
  },
  tabs: {
    get(id) { const wc = wcOf(id); const w = BrowserWindow.fromWebContents(wc); return { id: wc.id, url: wc.getURL(), status: !wc.isLoading() || domReady.get(wc.id) ? 'complete' : 'loading', windowId: w ? w.id : -1, active: true, nav: navInfo.get(wc.id) || null }; },
    update(id, o) { const wc = wcOf(id); if (o && o.url) wc.loadURL(o.url).catch(() => {}); if (o && o.muted !== undefined) wc.setAudioMuted(!!o.muted); return { id: wc.id }; },
    create(o) {
      const url = String(o && o.url || '');
      if (isAppUrl(url)) { const q = url.includes('?') ? url.slice(url.indexOf('?')) : ''; if (!q) { showMain(); return { id: appWin.webContents.id }; } const w = createAppWin(q, o.active !== false); return { id: w.webContents.id }; }
      if (/claude\.ai|claude\.com/i.test(url)) { shell.openExternal(url); return { id: -1 }; }
      const w = shopWin(url, { title: '킥스캔 — 브라우저', part: o && o.part }); return { id: w.webContents.id, windowId: w.id };
    },
    reload(id, o) { const wc = wcOf(id); domReady.set(wc.id, false); if (o && o.bypassCache) wc.reloadIgnoringCache(); else wc.reload(); return true; },
    query() { return BrowserWindow.getAllWindows().map(w => ({ id: w.webContents.id, url: w.webContents.getURL(), windowId: w.id })); },
    sendMessage(id, msg) {
      const wc = wcOf(id), mid = ++msgSeq;
      return new Promise((res, rej) => {
        const to = setTimeout(() => { waiting.delete(mid); rej(new Error('응답 없음')); }, 60000);
        waiting.set(mid, r => { clearTimeout(to); if (r && r.__kcNoListener) rej(new Error('Could not establish connection. Receiving end does not exist.')); else res(r); });
        wc.send('kc-msg', mid, msg);
      });
    }
  },
  scripting: {
    async executeScript(o) {
      const wc = wcOf(o.target && o.target.tabId);
      const code = `(${o.func}).apply(null, ${JSON.stringify(o.args || [])})`;
      // 3.1.1: wc.executeJavaScript는 페이지가 '다 불러질 때까지' 기다려서, 광고·추적 때문에 로딩이 안 끝나는 쇼핑몰(지그재그 등)에서 멈췄어요.
      //        mainFrame.executeJavaScript는 바로 실행돼요.
      const result = await wc.mainFrame.executeJavaScript(code, true);
      return [{ result: result === undefined ? null : result }];
    }
  },
  notifications: { create(id, o) { notify(o.title || '킥스캔', o.message || ''); return id; } },
  alarms: {
    create(name, a) { DATA.__alarms = { ...(DATA.__alarms || {}), [name]: { periodInMinutes: a.periodInMinutes, delayInMinutes: a.delayInMinutes } }; saveSoon(); alarmSchedule(name, a); return true; },
    clear(name) { const old = timers.get(name); if (old) { clearTimeout(old.t); clearInterval(old.i); timers.delete(name); } if (DATA.__alarms) { delete DATA.__alarms[name]; saveSoon(); } return true; }
  },
  app: {
    focusMain() { showMain(); return true; },
    info() { return { version: VER, bundled: app.getVersion(), updated: ROOT !== BUNDLED, platform: process.platform }; },
    // 3.13.0: 오류 보고서용 상태 (아이디·비밀번호·쿠키는 안 넣어요)
    diag() { const os = require('os'); const ago = t => t ? Math.round((Date.now() - t) / 1000) + '초 전' : '없음'; return { version: VER, bundled: app.getVersion(), updated: ROOT !== BUNDLED, electron: process.versions.electron, chrome: process.versions.chrome, os: `${process.platform} ${os.release()} ${process.arch}`, memMB: Math.round(process.memoryUsage().rss / 1048576), uptimeMin: Math.round(process.uptime() / 60), update: updState, whale: { via: kreamMode(), cdp: { on: cdpOpen(), browser: cdpBrowser(), err: CDP.lastErr || '', tabs: CDP.tabs.size }, connected: whaleConnected(), extVer: KB.ver, lastPoll: ago(KB.last), oldExtPoll: ago(KB.oldLast), noKeyPoll: ago(KB.noKey), queue: KB.q.length, pending: KB.pend.size } }; },
    applyUpdate(bytes) { const v = applyUpdate(bytes); setTimeout(() => { quitting = true; flush(); app.relaunch(); app.exit(0); }, 800); return v; },
    resetUpdate() { fs.rmSync(UPD(), { recursive: true, force: true }); setTimeout(() => { quitting = true; flush(); app.relaunch(); app.exit(0); }, 800); return app.getVersion(); }
  }
};
// ---------- 3.13.0: 로그인 · 라이선스 (license.json 이 있을 때만 켜져요 — 없으면 지금처럼 그냥 써요) ----------
// 3.33: 업데이트 폴더(ROOT)에는 license.json 이 없어요 — 설치 폴더(BUNDLED) · 사용자 폴더 순서로도 찾아요
const LIC_CFG = (() => { for (const d of [ROOT, BUNDLED, app.getPath('userData')]) { try { const j = JSON.parse(fs.readFileSync(path.join(d, 'license.json'), 'utf8')); if (j && j.url && j.anon) return j; } catch (e) {} } return null; })();
const LIC_FILE = () => path.join(app.getPath('userData'), 'license-session.json');
const LIC_GRACE = 72 * 3600e3;   // 인터넷이 안 될 때 마지막 확인 뒤 3일까지는 그대로 써요
let LIC = { on: !!LIC_CFG, state: LIC_CFG ? 'checking' : 'off', email: '', plan: '', expires: '', msg: '' };
let licSess = null, licAccess = '', licAccessExp = 0;
function licDevice() {
  const f = path.join(app.getPath('userData'), 'device-id.txt');
  try { const t = fs.readFileSync(f, 'utf8').trim(); if (/^[0-9a-f-]{36}$/.test(t)) return t; } catch (e) {}
  const t = require('crypto').randomUUID(); try { fs.writeFileSync(f, t); } catch (e) {} return t;
}
function licDeviceName() { const os = require('os'); return `${os.hostname()} (${process.platform === 'win32' ? 'Windows' : process.platform === 'darwin' ? 'Mac' : process.platform})`.slice(0, 80); }
function licLoad() {
  try {
    const raw = fs.readFileSync(LIC_FILE());
    const { safeStorage } = require('electron');
    const txt = raw[0] === 0x7b ? raw.toString('utf8') : safeStorage.decryptString(raw);
    licSess = JSON.parse(txt);
  } catch (e) { licSess = null; }
}
function licSave() {
  try {
    if (!licSess) { fs.rmSync(LIC_FILE(), { force: true }); return; }
    const { safeStorage } = require('electron'); const txt = JSON.stringify(licSess);
    fs.writeFileSync(LIC_FILE(), safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(txt) : txt);
  } catch (e) {}
}
async function licFetch(p, body, token) {
  const r = await net.fetch(LIC_CFG.url.replace(/\/$/, '') + p, { method: 'POST', headers: Object.assign({ apikey: LIC_CFG.anon, 'content-type': 'application/json' }, token ? { authorization: 'Bearer ' + token } : (/^eyJ/.test(LIC_CFG.anon) ? { authorization: 'Bearer ' + LIC_CFG.anon } : {})), body: JSON.stringify(body || {}) });
  let j = null; try { j = await r.json(); } catch (e) {}
  return { ok: r.ok, status: r.status, j };
}
const LIC_WHY = { login: '로그인이 필요해요', no_license: '이 계정에는 이용권이 없어요', expired: '이용 기간이 끝났어요', device_limit: '이용권으로 쓸 수 있는 PC 수를 넘었어요 — 다른 PC에서 \'이 PC 등록 해제\'를 하거나 문의해 주세요' };
function licSet(st, extra) { LIC = { ...LIC, state: st, ...(extra || {}) }; for (const w of BrowserWindow.getAllWindows()) { try { if (!w.isDestroyed() && w.webContents.getURL().startsWith('file:')) w.webContents.send('kc-lic', LIC); } catch (e) {} } return LIC; }
async function licTokens(r) {
  const j = r.j || {}; if (!r.ok || !j.access_token) return false;
  licAccess = j.access_token; licAccessExp = Date.now() + ((+j.expires_in || 3600) - 60) * 1000;
  licSess = { ...(licSess || {}), refresh: j.refresh_token, email: (j.user && j.user.email) || (licSess && licSess.email) || '' }; licSave(); return true;
}
async function licCheck() {
  if (!LIC_CFG) return licSet('off');
  if (!licSess || !licSess.refresh) return licSet('login', { msg: '' });
  try {
    if (!licAccess || Date.now() > licAccessExp) {
      const r = await licFetch('/auth/v1/token?grant_type=refresh_token', { refresh_token: licSess.refresh });
      if (!(await licTokens(r))) { if (r.status >= 400 && r.status < 500) { licSess = null; licSave(); return licSet('login', { msg: '다시 로그인해 주세요' }); } throw new Error('서버 응답 ' + r.status); }
    }
    const c = await licFetch('/rest/v1/rpc/ks_check', { p_device: licDevice(), p_name: licDeviceName() }, licAccess);
    if (!c.ok || !c.j) throw new Error('서버 응답 ' + c.status);
    const j = c.j;
    if (j.ok) { licSess.lastOk = Date.now(); licSess.plan = j.plan; licSess.expires = j.expires_at; licSave(); return licSet('ok', { email: licSess.email, plan: j.plan, expires: j.expires_at, msg: '' }); }
    return licSet(j.reason === 'login' ? 'login' : 'blocked', { email: licSess.email, plan: j.plan || '', expires: j.expires_at || '', msg: LIC_WHY[j.reason] || ('이용할 수 없어요 (' + j.reason + ')') });
  } catch (e) {
    // 인터넷이 안 되면: 마지막 확인이 3일 안이고 기간이 남았으면 그대로 써요
    const left = licSess && licSess.lastOk && Date.now() - licSess.lastOk < LIC_GRACE && (!licSess.expires || new Date(licSess.expires) > new Date());
    return licSet(left ? 'grace' : 'offline', { email: licSess.email || '', plan: licSess.plan || '', expires: licSess.expires || '', msg: left ? '인터넷 연결이 안 돼서 마지막 확인 기준으로 쓰고 있어요' : '이용권 확인이 안 돼요 — 인터넷 연결을 확인해 주세요 (' + (e.message || e) + ')' });
  }
}
const licOpen = () => !LIC.on || LIC.state === 'ok' || LIC.state === 'grace';
API.lic = {
  state() { return LIC; },
  async check() { return licCheck(); },
  async login(email, pw) {
    if (!LIC_CFG) return licSet('off');
    email = String(email || '').trim(); if (!email || !pw) return licSet('login', { msg: '이메일과 비밀번호를 넣어 주세요' });
    const r = await licFetch('/auth/v1/token?grant_type=password', { email, password: String(pw) });
    if (!(await licTokens(r))) return licSet('login', { msg: r.status === 400 ? '이메일 또는 비밀번호가 맞지 않아요' : '로그인 서버에 연결이 안 돼요 (' + r.status + ')' });
    licSess.email = email; licSave(); return licCheck();
  },
  async logout() { licSess = null; licAccess = ''; licSave(); return licSet(LIC_CFG ? 'login' : 'off', { email: '', plan: '', expires: '', msg: '' }); },
  async release() {   // 이 PC 등록 해제 (다른 PC로 옮길 때)
    if (!LIC_CFG || !licAccess) return false;
    try { await licFetch('/rest/v1/rpc/ks_release', { p_device: licDevice() }, licAccess); } catch (e) {}
    return API.lic.logout();
  },
  async resetPw(email) { if (!LIC_CFG) return false; const r = await licFetch('/auth/v1/recover', { email: String(email || '').trim() }); return r.ok; }
};
if (LIC_CFG) { app.whenReady().then(() => { licLoad(); licCheck(); setInterval(licCheck, 6 * 3600e3); }); }
// ---------- 3.33: 회원가입 · 이용권 결제 (토스페이먼츠 결제위젯) ----------
// license.json: { url, anon, tossClientKey, payPage?, payFn? } — tossClientKey 가 있어야 결제창이 켜져요.
// 결제 금액은 서버(ks-pay)가 정해요. 결제 창이 성공 페이지로 넘어오면 여기서 서버에 승인을 요청하고, 이용권을 다시 확인해요.
const PAY_PAGE = () => String((LIC_CFG && LIC_CFG.payPage) || 'https://chldydrnr2-eng.github.io/kream-scanner/pay/').replace(/\/?$/, '/');
const PAY_FN = () => (LIC_CFG && LIC_CFG.payFn) || (LIC_CFG.url.replace(/\/$/, '') + '/functions/v1/ks-pay');
async function licToken() {
  if (!LIC_CFG || !licSess || !licSess.refresh) return '';
  if (!licAccess || Date.now() > licAccessExp) { const r = await licFetch('/auth/v1/token?grant_type=refresh_token', { refresh_token: licSess.refresh }); if (!(await licTokens(r))) return ''; }
  return licAccess;
}
async function payCall(body) {
  const tok = await licToken(); if (!tok) return { ok: false, message: '로그인이 필요해요' };
  const r = await net.fetch(PAY_FN(), { method: 'POST', headers: { apikey: LIC_CFG.anon, authorization: 'Bearer ' + tok, 'content-type': 'application/json' }, body: JSON.stringify(body) });
  let j = null; try { j = await r.json(); } catch (e) {}
  return j || { ok: false, message: '결제 서버 응답이 없어요 (' + r.status + ')' };
}
let payWin = null;
Object.assign(API.lic, {
  payReady() { return !!(LIC_CFG && LIC_CFG.tossClientKey); },
  async orders() { return LIC_CFG ? payCall({ action: 'orders' }) : { ok: false }; },
  async signup(email, pw) {
    if (!LIC_CFG) return { ok: false, message: '로그인 서버가 설정돼 있지 않아요' };
    email = String(email || '').trim(); pw = String(pw || '');
    if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, message: '이메일 주소를 확인해 주세요' };
    if (pw.length < 8) return { ok: false, message: '비밀번호는 8자 이상으로 해 주세요' };
    const r = await licFetch('/auth/v1/signup', { email, password: pw });
    const j = r.j || {};
    if (!r.ok) return { ok: false, message: /already|registered|exists/i.test(JSON.stringify(j)) ? '이미 가입된 이메일이에요 — 로그인해 주세요' : (j.msg || j.error_description || j.message || ('가입에 실패했어요 (' + r.status + ')')) };
    if (j.access_token) { await licTokens(r); licSess.email = email; licSave(); return { ok: true, st: await licCheck() }; }
    return { ok: true, confirm: true, message: '가입 확인 메일을 보냈어요. 메일의 링크를 누른 다음 로그인해 주세요.' };
  },
  async pay(plan, days) {
    if (!API.lic.payReady()) return { ok: false, message: '결제 준비가 아직 안 됐어요' };
    if (payWin && !payWin.isDestroyed()) { payWin.focus(); return { ok: false, message: '결제 창이 이미 열려 있어요' }; }
    const p = await payCall({ action: 'prepare', plan, days });
    if (!p || !p.ok) return { ok: false, message: (p && p.message) || '주문을 만들지 못했어요' };
    const base = PAY_PAGE();
    return new Promise(resolve => {
      let done = false; const fin = r => { if (!done) { done = true; resolve(r); } };
      const wp = { partition: 'persist:kcpay', contextIsolation: true, sandbox: true, nodeIntegration: false };
      const w = payWin = new BrowserWindow({ parent: appWin && !appWin.isDestroyed() ? appWin : undefined, width: 560, height: 840, minWidth: 420, title: '킥스캔 이용권 결제', icon: ICON, autoHideMenuBar: true, backgroundColor: '#f4f5fb', webPreferences: wp });
      w.webContents.setWindowOpenHandler(() => ({ action: 'allow', overrideBrowserWindowOptions: { parent: w, width: 540, height: 780, autoHideMenuBar: true, webPreferences: wp } }));   // 카드사 인증 창
      const say = (t, d, ok) => w.webContents.executeJavaScript(`(()=>{const s=document.getElementById('s');if(s)s.style.display='none';const t=document.getElementById('t'),d=document.getElementById('d');if(t){t.textContent=${JSON.stringify(t)};t.style.color=${JSON.stringify(ok ? '#0b7a4d' : '#b4371f')}}if(d)d.textContent=${JSON.stringify(d)};})()`).catch(() => {});
      w.webContents.on('did-navigate', async (e, url) => {
        if (done || !url) return;
        if (url.startsWith(base + 'success.html')) {
          const u = new URL(url);
          let r; try { r = await payCall({ action: 'confirm', paymentKey: u.searchParams.get('paymentKey'), orderId: u.searchParams.get('orderId'), amount: +u.searchParams.get('amount') }); } catch (er) { r = { ok: false, message: er.message }; }
          if (r.ok && r.status === 'done') { await licCheck().catch(() => {}); await say('결제가 완료됐어요', '이용권이 반영됐어요. 이 창은 곧 닫혀요.', true); }
          else if (r.ok && r.status === 'waiting') await say('입금을 기다리고 있어요', `가상계좌에 입금하면 이용권이 자동으로 반영돼요.${r.account ? ' (계좌 ' + r.account + (r.due ? ', 기한 ' + String(r.due).slice(0, 16).replace('T', ' ') : '') + ')' : ''}`, true);
          else await say('결제를 확인하지 못했어요', (r.message || '') + ' — 카드 승인이 됐다면 판매자에게 문의해 주세요.', false);
          fin(r); setTimeout(() => { try { if (!w.isDestroyed()) w.close(); } catch (er) {} }, r.ok && r.status === 'done' ? 2500 : 15000);
        } else if (url.startsWith(base + 'fail.html')) {
          const u = new URL(url); fin({ ok: false, code: u.searchParams.get('code') || '', message: u.searchParams.get('message') || '결제가 끝나지 않았어요' });
        }
      });
      w.on('closed', () => { payWin = null; fin({ ok: false, cancel: true, message: '결제 창을 닫았어요' }); });
      w.loadURL(base + '?' + new URLSearchParams({ ck: LIC_CFG.tossClientKey, cust: p.customerKey, oid: p.orderId, amt: String(p.amount), name: p.orderName }).toString()).catch(() => {});
    });
  }
});

// 로그인 안 됐으면 크림·쇼핑몰 작업(창 열기·읽기·매크로)은 막아요. 저장소·업데이트·로그인 기능은 열어 둬요.
const LIC_FREE = new Set(['lic', 'app', 'storage']);
ipcMain.handle('kc', async (e, ns, method, args) => {
  if (!licOpen() && (!LIC_FREE.has(ns) || (ns === 'app' && ['probe', 'clearLogin', 'fixSite', 'setUA', 'setSsrStrip'].includes(method)))) throw new Error('로그인이 필요해요 — ' + (LIC.msg || '킥스캔 계정으로 로그인해 주세요'));
  const f = API[ns] && API[ns][method];
  if (!f) throw new Error(`지원하지 않는 기능: ${ns}.${method}`);
  return f.apply(API[ns], args || []);
});
ipcMain.on('kc-sync', (e, what) => { e.returnValue = what === 'root' ? ROOT : app.getVersion(); });

// ---------- 3.1: 자동 업데이트 (GitHub 릴리스) ----------
// 켤 때와 6시간마다 새 버전이 있는지 보고, 화면·기능 파일 업데이트는 혼자 받아서 바꿔요.
// 프로그램 뼈대(설치 파일)까지 바뀐 버전이면 설치 파일 받기 버튼을 띄워요.
const UPDATE_URL = process.env.KC_UPDATE_URL || 'https://raw.githubusercontent.com/chldydrnr2-eng/kream-scanner/main/updates/latest.json';
let updState = { state: 'idle', version: '', msg: '' };
function updBroadcast() { for (const w of BrowserWindow.getAllWindows()) { try { if (!w.isDestroyed() && w.webContents.getURL().startsWith('file:')) w.webContents.send('kc-update', updState); } catch (e) {} } }
async function checkUpdate(manual) {
  try {
    updState = { state: 'checking', version: VER, msg: '' }; if (manual) updBroadcast();
    // 3.10.27: raw 주소는 5분 정도 예전 내용을 줄 수 있어요 → GitHub에서 바로 읽고, 안 되면 raw로
    let j = null;
    if (!process.env.KC_UPDATE_URL) { try { const a = await net.fetch('https://api.github.com/repos/chldydrnr2-eng/kream-scanner/contents/updates/latest.json?ref=main&t=' + Date.now(), { cache: 'no-store', headers: { accept: 'application/vnd.github.raw+json', 'user-agent': 'KreamScanner' } }); if (a.ok) j = JSON.parse(await a.text()); } catch (e) { j = null; } }
    if (!j || !j.version) {
      const r = await net.fetch(UPDATE_URL + '?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) throw new Error('업데이트 정보를 못 받았어요 (' + r.status + ')');
      j = await r.json();
    }
    if (!j.version || cmpVer(j.version, VER) <= 0) { updState = { state: 'latest', version: VER, msg: '' }; if (manual) updBroadcast(); return updState; }
    if (j.shell && cmpVer(j.shell, app.getVersion()) > 0) { updState = { state: 'installer', version: j.version, url: j.installer, msg: j.notes || '', notes: Array.isArray(j.changes) ? j.changes : String(j.notes || '').split(/\s*·\s*/).filter(Boolean) }; updBroadcast(); return updState; }
    // 3.17.0: 받는 동안 몇 % 받았는지 화면에 보내요 (시작 화면의 필수 업데이트 막대)
    const notes = Array.isArray(j.changes) ? j.changes : String(j.notes || '').split(/\s*·\s*/).filter(Boolean);
    updState = { state: 'downloading', version: j.version, pct: 0, msg: j.notes || '', notes }; updBroadcast();
    const z = await net.fetch(j.appZip, { cache: 'no-store' });
    if (!z.ok) throw new Error('업데이트 파일을 못 받았어요 (' + z.status + ')');
    const total = +z.headers.get('content-length') || 0, parts = []; let got = 0, lastPct = -1;
    if (z.body && z.body.getReader) { const rd = z.body.getReader(); for (;;) { const { done, value } = await rd.read(); if (done) break; parts.push(Buffer.from(value)); got += value.length; const pct = total ? Math.min(99, Math.floor(got / total * 100)) : 50; if (pct >= lastPct + 4) { lastPct = pct; updState = { ...updState, pct }; updBroadcast(); } } }
    else parts.push(Buffer.from(await z.arrayBuffer()));
    const v = applyUpdate(Buffer.concat(parts));
    updState = { state: 'ready', version: v, msg: j.notes || '', notes, pct: 100 };
    updBroadcast();
    // 창이 안 보이면(트레이에서 도는 중) 하던 일이 없을 때 바로 다시 켜요
    if (!appWin || appWin.isDestroyed() || !appWin.isVisible()) setTimeout(() => restartForUpdate(), 3000);
    else notify('킥스캔 새 버전 ' + v, '업데이트를 받아 두었어요. 화면 위쪽 \'지금 다시 시작\'을 누르거나, 다음에 켤 때 적용돼요.');
    return updState;
  } catch (e) { updState = { state: 'error', version: VER, msg: String(e.message || e) }; if (manual) updBroadcast(); return updState; }
}
// 3.4.2: 로그인 유지 — 쇼핑몰이 '창 닫으면 지워지는 로그인 쿠키'를 주면, 프로그램을 껐다 켜거나(업데이트 재시작 포함) 할 때 로그인이 풀려요.
//        그런 쿠키를 30일짜리로 바꿔 저장해요 (크롬의 '로그인 상태 유지'와 같은 효과). 로그아웃하면 사이트가 지우는 대로 지워져요.
// 3.4.6: 값이 토큰(JWT)인 쿠키는 토큰 만료 시각까지만 저장해요 (만료된 크림 토큰이 남아서 크림이 빈 화면·오류를 주던 문제)
function jwtExp(v) {
  try { const m = decodeURIComponent(String(v || '')).match(/eyJ[\w-]+\.([\w-]+)\.[\w-]*/); if (!m) return 0; const j = JSON.parse(Buffer.from(m[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')); return +j.exp || 0; } catch (e) { return 0; }
}
const cookieUrl = c => (c.secure ? 'https://' : 'http://') + c.domain.replace(/^\./, '') + (c.path || '/');
function keepLogins(ses) {
  ses.cookies.on('changed', (e, c, cause, removed) => {
    if (removed || !c || !c.session || !c.domain) return;
    // 3.34: '로그아웃 표시' 값(false 등)은 오래 저장하지 않아요
    if (!c.value || /^(false|null|undefined|0)$/i.test(c.value)) return;
    try {
      const now = Math.floor(Date.now() / 1000), exp = jwtExp(c.value);
      if (exp && exp <= now) return;   // 이미 만료된 토큰은 오래 저장하지 않아요
      const d = { url: cookieUrl(c), name: c.name, value: c.value, path: c.path || '/', secure: !!c.secure, httpOnly: !!c.httpOnly, expirationDate: exp ? exp + 60 : now + 30 * 86400 };
      if (!c.hostOnly) d.domain = c.domain;
      if (c.sameSite && c.sameSite !== 'unspecified' && (c.sameSite !== 'no_restriction' || c.secure)) d.sameSite = c.sameSite;
      // 3.34: 저장하기 직전에 지금 값을 다시 봐요. 그사이 사이트가 새 값(예: 로그인 토큰)을 썼으면 옛 값으로 덮어쓰지 않아요.
      //       (예전엔 크림 로그인 직후 'false' 값이 늦게 다시 저장돼서 로그인 토큰을 지워 버렸어요 → 프로그램 안에서 크림 로그인이 안 되던 원인)
      ses.cookies.get({ url: d.url, name: c.name }).then(list => {
        const cur = list.find(x => x.name === c.name && x.domain === c.domain && (x.path || '/') === (c.path || '/'));
        if (!cur || !cur.session || cur.value !== c.value) return;
        return ses.cookies.set(d);
      }).catch(() => {});
    } catch (x) {}
  });
  // 켤 때: 이미 만료된 토큰 쿠키는 지워요 (사이트가 '로그인 풀림'으로 보고 다시 로그인하게)
  ses.cookies.get({}).then(list => { const now = Date.now() / 1000; for (const c of list) { const exp = jwtExp(c.value); if (exp && exp < now - 60) ses.cookies.remove(cookieUrl(c), c.name).catch(() => {}); } }).catch(() => {});
}
// 3.4.6: 다시 로그인하기 전에 그 사이트의 로그인 쿠키를 지워요 (꼬인 로그인 정리)
API.app.clearLogin = async o => {
  const ses = prepShop(o.part); const re = new RegExp(o.names || 'token|auth|session|strategy|ticketexpire', 'i'); let n = 0;
  for (const c of await ses.cookies.get({})) { const dm = c.domain.replace(/^\./, ''); if (o.exact ? dm !== o.domain : !dm.endsWith(o.domain)) continue; if (o.all || re.test(c.name)) { await ses.cookies.remove(cookieUrl(c), c.name).catch(() => {}); n++; } }
  return n;
};
function flushCookies() { try { return Promise.race([Promise.all([...new Set([PART, ...prepped])].map(p => session.fromPartition(p).cookies.flushStore().catch(() => {}))), new Promise(r => setTimeout(r, 1500))]); } catch (e) { return Promise.resolve(); } }
async function restartForUpdate() { quitting = true; flush(); await flushCookies(); app.relaunch({ args: process.argv.slice(1).filter(a => a !== '--hidden').concat(appWin && appWin.isVisible() ? [] : ['--hidden']) }); app.exit(0); }
// 3.2: 로그인 상태를 보이지 않는 창으로 바로 확인 (작업 창·대기열과 따로)
API.app.probe = async o => {
  prepShop(o.part); const w = new BrowserWindow({ show: false, width: 1200, height: 900, webPreferences: { partition: partOf(o.part), contextIsolation: true, sandbox: true, backgroundThrottling: false } });
  w.webContents.setAudioMuted(true);
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-prevent-unload', e => e.preventDefault());
  try {
    await new Promise(res => { const t = setTimeout(res, 15000); w.webContents.once('dom-ready', () => { clearTimeout(t); setTimeout(res, 900); }); w.loadURL(o.url).catch(() => res()); });
    return await Promise.race([w.webContents.mainFrame.executeJavaScript(`(${o.func})()`, true), new Promise(r => setTimeout(() => r(null), 15000))]);
  } catch (e) { return null; }
  finally { try { w.destroy(); } catch (e) {} }
};
// ---------- 3.7: 크림 작업은 웨일에서 (웨일 확장과 127.0.0.1로 연결) ----------
// 크림이 프로그램 안 브라우저의 로그인 요청을 막아서, 크림 화면 열기·읽기·매크로는 웨일(사장님 크림 로그인 그대로)에서 해요.
// 웨일 확장이 이 프로그램에 '할 일'을 물어보고(poll) 결과를 보내줘요(result). 창 번호는 1e9를 더해서 구분해요.
const RB = 1e9;
const KB = { q: [], waiters: [], pend: new Map(), seq: 0, last: 0, ver: '', port: 47615, launched: 0 };
// 3.13.0: 웨일 연결 암호 — 이 PC의 '크림스캐너 웨일 연결' 폴더에만 적어 두는 열쇠가 있어야 일을 주고받아요 (다른 확장이 끼어들지 못하게)
KB.token = (() => { const f = path.join(app.getPath('userData'), 'whale-key.txt'); try { const t = fs.readFileSync(f, 'utf8').trim(); if (/^[0-9a-f]{48}$/.test(t)) return t; } catch (e) {} const t = require('crypto').randomBytes(24).toString('hex'); try { fs.writeFileSync(f, t); } catch (e) {} return t; })();
KB.oldLast = 0; KB.oldReload = 0; KB.noKey = 0;
function kbWriteKey() { try { const d = extDir(); if (!fs.existsSync(path.join(d, 'manifest.json'))) return; const f = path.join(d, 'kc-token.json'); let cur = ''; try { cur = JSON.parse(fs.readFileSync(f, 'utf8')).k; } catch (e) {} if (cur !== KB.token) fs.writeFileSync(f, JSON.stringify({ k: KB.token })); } catch (e) {} }
const isKreamUrl = u => /^https?:\/\/([\w-]+\.)*kream\.co\.kr(\/|$|\?)/i.test(String(u || ''));
// 3.34: 크림 작업 방식 — cdp(기본: PC 브라우저를 킥스캔이 직접 조종) · whale(예전: 웨일·크롬 확장) · app(프로그램 안)
const kreamMode = () => ['cdp', 'whale', 'app'].includes(DATA.__kreamMode) ? DATA.__kreamMode : 'cdp';
const kreamViaWhale = () => kreamMode() !== 'app';
const isRemote = id => +id >= RB;
function kbFlush() {
  while (KB.waiters.length && KB.q.length) { const w = KB.waiters.shift(); clearTimeout(w.t); try { w.res.end(JSON.stringify(KB.q.splice(0))); } catch (e) {} }
}
function kbServer() {
  const srv = require('http').createServer((req, res) => {
    const origin = req.headers.origin || '', sfs = req.headers['sec-fetch-site'] || '';
    // 웨일 확장에서 온 요청만 받아요 (웹사이트가 보낸 요청은 막아요)
    if (!(/^chrome-extension:\/\//.test(origin) || (!origin && (!sfs || sfs === 'none')))) { res.writeHead(403); return res.end(); }
    if (origin) res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Content-Type', 'application/json');
    const u = req.url || '';
    const key = (u.match(/[?&]k=([0-9a-f]+)/) || [])[1] || '';
    if (key !== KB.token) {
      // 열쇠가 없거나 틀려요: 옛 버전 확장이면 새 파일로 다시 읽으라고만 하고, 다른 일은 안 줘요
      if (u.startsWith('/kc/poll')) {
        const v = (u.match(/[?&]v=([\w.]+)/) || [])[1] || ''; let mv = ''; try { mv = JSON.parse(fs.readFileSync(path.join(extDir(), 'manifest.json'), 'utf8')).version; } catch (e) {}
        KB.oldLast = Date.now(); if (v && mv && v === mv) KB.noKey = Date.now(); if (process.env.KC_DEBUG) console.error('[kb] nokey poll', v, mv, Date.now() - KB.oldReload);
        if (v && mv && v !== mv && Date.now() - KB.oldReload > 30000) { KB.oldReload = Date.now(); kbWriteKey(); return res.end(JSON.stringify([{ id: -1, op: 'reload', args: {} }])); }
        const t = setTimeout(() => { try { res.end('[]'); } catch (e) {} }, 20000); req.on('close', () => clearTimeout(t)); return;
      }
      return res.end('{}');
    }
    const fromB = uaBrowser(req.headers['user-agent']);
    if (fromB === 'whale') KB.sawWhale = Date.now();
    // 웨일을 골랐는데 최근에 웨일 이름표가 붙은 요청을 못 봤으면, 이름표만 보고 막지 않아요 (안전하게)
    const blockB = fromB && fromB !== curBrowser() && !(curBrowser() === 'whale' && fromB === 'chrome' && !(KB.sawWhale && Date.now() - KB.sawWhale < 120000));
    if (blockB) {
      KB.other = { b: fromB, t: Date.now() };
      if (u.startsWith('/kc/poll')) { const t = setTimeout(() => { try { res.end('[]'); } catch (e) {} }, 20000); req.on('close', () => clearTimeout(t)); return; }
      return res.end('{}');
    }
    if (u.startsWith('/kc/poll')) {
      KB.ever = true; if (!DATA.__extEver) { DATA.__extEver = Date.now(); saveSoon(); }
      KB.last = Date.now(); const v = (u.match(/[?&]v=([\w.]+)/) || [])[1]; if (v) KB.ver = v;
      if (KB.q.length) return res.end(JSON.stringify(KB.q.splice(0)));
      const w = { res, t: setTimeout(() => { KB.waiters = KB.waiters.filter(x => x !== w); KB.last = Date.now(); try { res.end('[]'); } catch (e) {} }, 20000) };
      KB.waiters.push(w); req.on('close', () => { clearTimeout(w.t); KB.waiters = KB.waiters.filter(x => x !== w); });
      return;
    }
    if (u.startsWith('/kc/result') && req.method === 'POST') {
      let b = ''; req.on('data', d => { b += d; if (b.length > 20e6) req.destroy(); });
      req.on('end', () => { try { const m = JSON.parse(b); const p = KB.pend.get(m.id); if (p) { KB.pend.delete(m.id); clearTimeout(p.t); m.ok ? p.res(m.value) : p.rej(new Error(m.error || '웨일 작업 실패')); } } catch (e) {} res.end('{}'); });
      return;
    }
    res.end('{}');
  });
  srv.on('error', e => console.error('웨일 연결 서버를 못 열었어요', e.message));
  srv.listen(KB.port, '127.0.0.1');
}
const whaleConnected = () => KB.waiters.length > 0 || Date.now() - KB.last < 25000;
// 3.16.0: 크롬도 지원 — 크림 작업을 할 브라우저(웨일/크롬)를 골라요
const BROWSERS = { whale: '웨일', chrome: '크롬' };
const curBrowser = () => DATA.__browser === 'chrome' ? 'chrome' : 'whale';
function browserPath(b) {
  const env = process.env, c = [];
  if (process.platform === 'darwin') c.push(b === 'chrome' ? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' : '/Applications/Naver Whale.app/Contents/MacOS/Naver Whale');
  for (const base of [env.ProgramFiles, env['ProgramFiles(x86)'], env.LOCALAPPDATA]) if (base) c.push(b === 'chrome' ? path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe') : path.join(base, 'Naver', 'Naver Whale', 'Application', 'whale.exe'));
  return c.find(f => { try { return fs.existsSync(f); } catch (e) { return false; } });
}
function whalePath() { return browserPath(curBrowser()); }
// 확장이 보낸 요청이 고른 브라우저에서 왔는지 (웨일은 이름표에 Whale이 들어 있어요)
const uaBrowser = ua => /Whale\//.test(String(ua || '')) ? 'whale' : /Chrome\//.test(String(ua || '')) ? 'chrome' : '';
async function ensureWhale() {
  if (whaleConnected()) return true;
  // 웨일이 꺼져 있으면 창 없이(백그라운드로) 켜요
  if (Date.now() - KB.launched > 60000) { const wp = whalePath(); if (wp) { try { require('child_process').spawn(wp, ['--no-startup-window'], { detached: true, stdio: 'ignore' }).unref(); KB.launched = Date.now(); } catch (e) {} } }
  for (let i = 0; i < 40 && !whaleConnected(); i++) await new Promise(r => setTimeout(r, 500));
  if (!whaleConnected() && Date.now() - KB.noKey < 60000) throw new Error(BROWSERS[curBrowser()] + ' 확장이 다른 폴더에서 올려져 있어서 연결 열쇠를 못 읽어요 — 설정 → \'연결 마법사\'에서 다시 올려 주세요');
  if (!whaleConnected()) { const bn = BROWSERS[curBrowser()]; if (KB.other && Date.now() - KB.other.t < 30000) throw new Error(`${BROWSERS[KB.other.b]}에 올린 확장이 연결하려고 해요. 크림 작업 브라우저를 ${BROWSERS[KB.other.b]}(으)로 바꾸거나 ${bn}에 확장을 올려 주세요 (설정 → 연결 마법사)`); throw new Error(`${bn}와(과) 연결이 안 돼요 — ${bn}을(를) 켜고 '킥스캔 연결' 확장이 켜져 있는지 확인해 주세요 (설정 → 연결 마법사)`); }
  return true;
}
// ---------- 3.34: 크림 작업은 PC에 깔린 브라우저(크롬 · 엣지 · 웨일)를 킥스캔이 직접 조종해요 (확장 설치 없음) ----------
// 크림 서버가 프로그램 안 브라우저의 '로그인한 요청'에는 10초 뒤 오류(500)를 줘요. 그래서 크림 일은 진짜 브라우저에서 해요.
// 킥스캔 전용 프로필(%APPDATA%\KreamScanner\kream-browser)로 브라우저를 켜고, 브라우저의 원격 조종 기능(DevTools 프로토콜, 이 PC 안 127.0.0.1)으로
// 창 열기 · 읽기 · 매크로를 해요. 예전 웨일 확장이 하던 일(winCreate · exec · send …)을 그대로 대신해요.
const CDPB = { chrome: '크롬', edge: '엣지', whale: '웨일' };
function cdpPath(b) {
  const env = process.env, c = [];
  if (process.platform === 'darwin') c.push({ chrome: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', edge: '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', whale: '/Applications/Naver Whale.app/Contents/MacOS/Naver Whale' }[b]);
  const rel = { chrome: ['Google', 'Chrome', 'Application', 'chrome.exe'], edge: ['Microsoft', 'Edge', 'Application', 'msedge.exe'], whale: ['Naver', 'Naver Whale', 'Application', 'whale.exe'] }[b];
  if (rel) for (const base of [env.ProgramFiles, env['ProgramFiles(x86)'], env.LOCALAPPDATA]) if (base) c.push(path.join(base, ...rel));
  if (process.platform === 'linux' && process.env.KC_CDP_EXE) c.unshift(process.env.KC_CDP_EXE);
  return c.find(f => { try { return f && fs.existsSync(f); } catch (e) { return false; } }) || '';
}
function cdpBrowser() {
  if (process.env.KC_CDP_EXE) return 'chrome';
  const want = DATA.__cdpB; if (want && CDPB[want] && cdpPath(want)) return want;
  return ['chrome', 'edge', 'whale'].find(b => cdpPath(b)) || '';
}
const cdpDir = () => process.env.KC_CDP_DIR || path.join(app.getPath('userData'), 'kream-browser');
const CDP = { ws: null, seq: 0, pend: new Map(), ready: null, tabs: new Map(), byTarget: new Map(), nid: 0, launchedAt: 0, ever: 0, lastErr: '' };
const cdpOpen = () => !!(CDP.ws && CDP.ws.readyState === 1);
function cdpSend(method, params, sessionId, ms) {
  return new Promise((res, rej) => {
    if (!cdpOpen()) return rej(new Error('브라우저 연결이 끊겼어요'));
    const id = ++CDP.seq, t = setTimeout(() => { CDP.pend.delete(id); rej(new Error('브라우저가 응답하지 않아요 (' + method + ')')); }, ms || 30000);
    CDP.pend.set(id, { res, rej, t });
    const m = { id, method, params: params || {} }; if (sessionId) m.sessionId = sessionId;
    CDP.ws.send(JSON.stringify(m));
  });
}
function cdpEvent(m) {
  const T = m.sessionId ? [...CDP.tabs.values()].find(x => x.sid === m.sessionId) : null;
  if (m.method === 'Target.detachedFromTarget' || m.method === 'Target.targetDestroyed') {
    const tid = m.params.targetId || (T && T.targetId); const id = CDP.byTarget.get(tid);
    if (m.method === 'Target.targetDestroyed' && id != null) { CDP.tabs.delete(id); CDP.byTarget.delete(tid); }
    return;
  }
  if (!T) return;
  const p = m.params || {};
  if (m.method === 'Page.frameNavigated' && !p.frame.parentId) { T.frameId = p.frame.id; T.url = p.frame.url; }
  else if (m.method === 'Page.frameStartedLoading' && (!T.frameId || p.frameId === T.frameId)) T.status = 'loading';
  else if (m.method === 'Page.loadEventFired') T.status = 'complete';
  else if (m.method === 'Page.navigatedWithinDocument' && (!T.frameId || p.frameId === T.frameId)) T.url = p.url;
  else if (m.method === 'Runtime.executionContextCreated') { const c = p.context; if (c.name === 'kc' && c.auxData && (!T.frameId || c.auxData.frameId === T.frameId)) T.kcCtx = c.id; }
  else if (m.method === 'Runtime.executionContextsCleared') T.kcCtx = 0;
  else if (m.method === 'Runtime.executionContextDestroyed' && p.executionContextId === T.kcCtx) T.kcCtx = 0;
}
// 브라우저가 이미 켜져 있으면(킥스캔을 다시 켠 경우) 그대로 붙고, 아니면 킥스캔 전용 프로필로 켜요
async function cdpConnectFile() {
  let txt = ''; try { txt = fs.readFileSync(path.join(cdpDir(), 'DevToolsActivePort'), 'utf8'); } catch (e) { return false; }
  const [port, wsPath] = txt.split(/\r?\n/); if (!+port || !wsPath) return false;
  return new Promise(res => {
    let ws; try { ws = new WebSocket(`ws://127.0.0.1:${+port}${wsPath}`); } catch (e) { return res(false); }
    const t = setTimeout(() => { try { ws.close(); } catch (e) {} res(false); }, 3000);
    ws.onopen = () => { clearTimeout(t); CDP.ws = ws; res(true); };
    ws.onerror = () => { clearTimeout(t); res(false); };
    ws.onclose = () => { if (CDP.ws === ws) { CDP.ws = null; for (const [, p] of CDP.pend) { clearTimeout(p.t); p.rej(new Error('브라우저가 닫혔어요')); } CDP.pend.clear(); CDP.tabs.clear(); CDP.byTarget.clear(); } };
    ws.onmessage = ev => {
      let m; try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : Buffer.from(ev.data).toString('utf8')); } catch (e) { return; }
      if (m.id) { const p = CDP.pend.get(m.id); if (!p) return; CDP.pend.delete(m.id); clearTimeout(p.t); m.error ? p.rej(new Error(m.error.message || '브라우저 오류')) : p.res(m.result || {}); return; }
      try { cdpEvent(m); } catch (e) {}
    };
  });
}
async function cdpStart() {
  if (cdpOpen()) return true;
  if (CDP.ready) return CDP.ready;
  CDP.ready = (async () => {
    if (await cdpConnectFile()) { await cdpAfterConnect(); return true; }
    const b = cdpBrowser(), exe = process.env.KC_CDP_EXE || cdpPath(b);
    if (!exe) throw new Error('크롬이나 엣지를 찾지 못했어요 — 크롬을 설치하거나, 설정 → 크림 작업에서 다른 방식을 골라 주세요');
    const dir = cdpDir(); fs.mkdirSync(dir, { recursive: true }); try { fs.unlinkSync(path.join(dir, 'DevToolsActivePort')); } catch (e) {}
    const args = ['--remote-debugging-port=0', '--user-data-dir=' + dir, '--no-first-run', '--no-default-browser-check', '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows', '--hide-crash-restore-bubble', '--mute-audio', '--window-size=1200,900'];
    if (process.env.KC_CDP_ARGS) args.push(...process.env.KC_CDP_ARGS.split(' ').filter(Boolean).map(decodeURIComponent));
    args.push('about:blank');
    require('child_process').spawn(exe, args, { detached: true, stdio: 'ignore' }).unref(); CDP.launchedAt = Date.now();
    for (let i = 0; i < 60; i++) { await new Promise(r => setTimeout(r, 250)); if (await cdpConnectFile()) { await cdpAfterConnect(true); return true; } }
    throw new Error((CDPB[b] || '브라우저') + '를 켜지 못했어요 — 이미 켜진 킥스캔 브라우저 창을 모두 닫고 다시 해 주세요');
  })();
  try { return await CDP.ready; } catch (e) { CDP.lastErr = e.message; throw e; } finally { CDP.ready = null; }
}
async function cdpAfterConnect(fresh) {
  CDP.ever = Date.now(); if (!DATA.__cdpEver) { DATA.__cdpEver = Date.now(); saveSoon(); }
  await cdpSend('Target.setDiscoverTargets', { discover: true }).catch(() => {});
  if (fresh) {   // 처음 켤 때 생긴 빈 창은 최소화해 둬요 (창을 다 닫으면 브라우저가 꺼져서, 하나는 남겨 둬요)
    try { const { targetInfos } = await cdpSend('Target.getTargets'); const t = targetInfos.find(x => x.type === 'page'); if (t) { const { windowId } = await cdpSend('Browser.getWindowForTarget', { targetId: t.targetId }); await cdpSend('Browser.setWindowBounds', { windowId, bounds: { windowState: 'minimized' } }); } } catch (e) {}
  }
}
// 크림 화면에 넣는 스크립트 (예전 확장의 content_scripts 와 같아요)
let CDP_SRC = null;
function cdpSources() {
  if (CDP_SRC) return CDP_SRC;
  const rd = f => { try { return fs.readFileSync(path.join(ROOT, 'content', f), 'utf8'); } catch (e) { return ''; } };
  const prod = "location.origin === 'https://kream.co.kr' && /^\\/products\\//.test(location.pathname)", my = "location.origin === 'https://kream.co.kr' && /^\\/my/.test(location.pathname)";
  const shim = "globalThis.chrome = globalThis.chrome || {}; if (!chrome.runtime || !chrome.runtime.__kc) chrome.runtime = { __kc: 1, onMessage: { addListener(f) { (globalThis.__kcMsgL = globalThis.__kcMsgL || []).push(f); } } };";
  CDP_SRC = {
    main: `if (${prod}) {\n${rd('hook.js')}\n}\nif (${my}) {\n${rd('hook-my.js')}\n}`,
    iso: `${shim}\nif (${prod}) {\n${rd('core.js')}\n${rd('bridge.js')}\n}\nif (${my}) {\n${rd('bridge-my.js')}\n}`
  };
  // find.js 안의 기능들 (이름으로 불러 써요)
  const vm = require('vm'), box = {}; try { vm.runInNewContext(rd('find.js'), box, { timeout: 2000 }); } catch (e) { console.error('[cdp] find.js', e.message); }
  CDP_SRC.fn = {}; for (const k of Object.keys(box)) if (typeof box[k] === 'function') CDP_SRC.fn[k] = box[k].toString();
  return CDP_SRC;
}
async function cdpAttach(targetId) {
  const { sessionId } = await cdpSend('Target.attachToTarget', { targetId, flatten: true });
  const id = ++CDP.nid; const T = { id, targetId, sid: sessionId, status: 'loading', url: '', frameId: '', kcCtx: 0, use: Date.now(), busy: 0, bg: false };
  CDP.tabs.set(id, T); CDP.byTarget.set(targetId, id);
  const S = cdpSources();
  await cdpSend('Page.enable', {}, sessionId); await cdpSend('Runtime.enable', {}, sessionId);
  await cdpSend('Page.addScriptToEvaluateOnNewDocument', { source: S.main }, sessionId);
  await cdpSend('Page.addScriptToEvaluateOnNewDocument', { source: S.iso, worldName: 'kc' }, sessionId);
  try { const { frameTree } = await cdpSend('Page.getFrameTree', {}, sessionId); T.frameId = frameTree.frame.id; T.url = frameTree.frame.url; } catch (e) {}
  return T;
}
const cdpTab = id => { const T = CDP.tabs.get(+id); if (!T) throw new Error('창이 이미 닫혔어요'); T.use = Date.now(); return T; };
async function cdpWin(T) { const { windowId } = await cdpSend('Browser.getWindowForTarget', { targetId: T.targetId }); return windowId; }
async function cdpNew(url, o) {
  await cdpStart();
  const bg = !!(o.bg && !o.focused);
  const { targetId } = await cdpSend('Target.createTarget', { url: 'about:blank', newWindow: true, background: bg, width: o.width || 1180, height: o.height || 900 });
  const T = await cdpAttach(targetId); T.bg = bg;
  if (bg) { try { await cdpSend('Browser.setWindowBounds', { windowId: await cdpWin(T), bounds: { windowState: 'minimized' } }); } catch (e) {} }
  else { try { await cdpSend('Target.activateTarget', { targetId }); } catch (e) {} }
  T.status = 'loading'; await cdpSend('Page.navigate', { url }, T.sid);
  cdpGc(T.id).catch(() => {});
  return T;
}
// 뒤에서 쓰는 창이 쌓이지 않게: 4분 넘게 안 쓴 창은 닫고, 뒤 창은 최대 3개 (예전 확장과 같아요)
async function cdpGc(keep) {
  const now = Date.now(), L = [...CDP.tabs.values()].filter(T => T.bg && T.id !== keep && !T.busy);
  for (const T of L) if (now - T.use > 4 * 60000) await cdpClose(T.id).catch(() => {});
  const live = [...CDP.tabs.values()].filter(T => T.bg && T.id !== keep && !T.busy).sort((a, b) => a.use - b.use);
  while (live.length > 2) await cdpClose(live.shift().id).catch(() => {});
}
async function cdpClose(id) {
  const T = CDP.tabs.get(+id); if (!T) return true;
  CDP.tabs.delete(T.id); CDP.byTarget.delete(T.targetId);
  // 마지막 창을 닫으면 브라우저가 꺼져요 → 그럴 땐 빈 화면으로 바꾸고 최소화해요
  try { const { targetInfos } = await cdpSend('Target.getTargets'); const pages = targetInfos.filter(x => x.type === 'page'); if (pages.length <= 1) { await cdpSend('Page.navigate', { url: 'about:blank' }, T.sid).catch(() => {}); await cdpSend('Browser.setWindowBounds', { windowId: await cdpWin(T), bounds: { windowState: 'minimized' } }).catch(() => {}); await cdpSend('Target.detachFromTarget', { sessionId: T.sid }).catch(() => {}); return true; } } catch (e) {}
  await cdpSend('Target.closeTarget', { targetId: T.targetId }).catch(() => {});
  return true;
}
async function cdpEval(T, expr, world, ms) {
  const p = { expression: expr, awaitPromise: true, returnByValue: true, userGesture: true };
  if (world !== 'MAIN') {
    if (!T.kcCtx) { try { const { executionContextId } = await cdpSend('Page.createIsolatedWorld', { frameId: T.frameId, worldName: 'kc' }, T.sid); T.kcCtx = executionContextId; await cdpSend('Runtime.evaluate', { expression: cdpSources().iso, contextId: executionContextId }, T.sid); } catch (e) {} }
    if (T.kcCtx) p.contextId = T.kcCtx;
  }
  const r = await cdpSend('Runtime.evaluate', p, T.sid, ms || 120000);
  if (r.exceptionDetails) throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description || r.exceptionDetails.text || '스크립트 오류').split('\n')[0]);
  return r.result ? r.result.value : undefined;
}
async function cdpWaitDoc(T, ms) { const end = Date.now() + (ms || 15000); while (Date.now() < end && T.status !== 'complete' && CDP.tabs.has(T.id)) await new Promise(r => setTimeout(r, 300)); }
const CDP_OPS = {
  ping: async () => ({ ver: 'cdp' }),
  setMode: async () => 'min',
  reload: async () => true,
  winCreate: async a => { const T = await cdpNew(a.url, a); return { winId: T.id, tabId: T.id }; },
  winGet: async a => { const T = cdpTab(a.id); let state = 'normal'; try { ({ bounds: { windowState: state } } = await cdpSend('Browser.getWindowBounds', { windowId: await cdpWin(T) })); } catch (e) {} return { focused: false, state }; },
  winUpdate: async a => { const T = cdpTab(a.id); const wid = await cdpWin(T); if (a.focused) { T.bg = false; await cdpSend('Browser.setWindowBounds', { windowId: wid, bounds: { windowState: 'normal' } }).catch(() => {}); await cdpSend('Target.activateTarget', { targetId: T.targetId }).catch(() => {}); } else if (a.state) await cdpSend('Browser.setWindowBounds', { windowId: wid, bounds: { windowState: a.state } }).catch(() => {}); return true; },
  winRemove: async a => cdpClose(a.id),
  tabGet: async a => { const T = cdpTab(a.id); return { url: T.url, status: T.status, windowId: T.id }; },
  tabUpdate: async a => { const T = cdpTab(a.id); if (a.url) { T.status = 'loading'; await cdpSend('Page.navigate', { url: a.url }, T.sid); } return true; },
  tabReload: async a => { const T = cdpTab(a.id); T.status = 'loading'; await cdpSend('Page.reload', { ignoreCache: !!a.bypassCache }, T.sid); return true; },
  tabCreate: async a => { const T = await cdpNew(a.url, { focused: true }); return { tabId: T.id, winId: T.id }; },
  send: async a => {
    const T = cdpTab(a.id);
    // 화면이 다 뜨기 전이면 연결 스크립트가 아직 없을 수 있어요 → 잠깐 기다려요 (확장의 '받는 쪽 없음'과 같은 효과)
    const expr = `new Promise(res => { const L = globalThis.__kcMsgL || []; if (!L.length) return res({ __kcNoRecv: 1 }); let done = false, async = false; const reply = v => { if (!done) { done = true; res(v === undefined ? null : v); } }; for (const f of L) { try { if (f(${JSON.stringify(a.msg)}, {}, reply) === true) async = true; } catch (e) {} } if (!async && !done) res(null); })`;
    for (let i = 0; ; i++) {
      const v = await cdpEval(T, expr, 'ISOLATED', 360000);
      if (!(v && v.__kcNoRecv)) return v;
      if (i >= 20) throw new Error('Could not establish connection. Receiving end does not exist.');
      await new Promise(r => setTimeout(r, 500)); T.kcCtx = 0;
    }
  },
  exec: async a => {
    const T = cdpTab(a.id), src = cdpSources().fn[a.name];
    if (!src) throw new Error('킥스캔에 없는 기능이에요: ' + a.name);
    return cdpEval(T, `(${src}).apply(null, ${JSON.stringify(a.args || [])})`, a.world === 'MAIN' ? 'MAIN' : 'ISOLATED');
  },
  probe: async a => {
    const T = await cdpNew(a.url, { bg: true, width: 1100, height: 800 });
    try { await cdpWaitDoc(T, 15000); await new Promise(r => setTimeout(r, 900)); const src = cdpSources().fn[a.name]; if (!src) return null; return await cdpEval(T, `(${src})()`, 'ISOLATED'); }
    finally { cdpClose(T.id).catch(() => {}); }
  }
};
async function cdpOp(op, args, ms) {
  const f = CDP_OPS[op]; if (!f) throw new Error('모르는 작업: ' + op);
  const a = args || {}; const T = a.id != null ? CDP.tabs.get(+a.id) : null;
  if (T && (op === 'send' || op === 'exec')) T.busy++;
  try {
    return await Promise.race([f(a), new Promise((_, rej) => setTimeout(() => rej(new Error('브라우저가 응답하지 않아요 (' + op + ')')), ms || 60000))]);
  } catch (e) { CDP.lastErr = e.message; throw e; }
  finally { if (T && (op === 'send' || op === 'exec')) { T.busy = Math.max(0, T.busy - 1); T.use = Date.now(); } }
}
setInterval(() => { if (cdpOpen()) cdpGc().catch(() => {}); }, 30000);
app.on('before-quit', () => { try { if (cdpOpen()) CDP.ws.send(JSON.stringify({ id: ++CDP.seq, method: 'Browser.close' })); } catch (e) {} });
function rcall(op, args, ms) {
  return new Promise((res, rej) => {
    const id = ++KB.seq;
    const t = setTimeout(() => { KB.pend.delete(id); KB.q = KB.q.filter(c => c.id !== id); rej(new Error('웨일이 응답하지 않아요 (' + op + ')')); }, ms || 60000);
    KB.pend.set(id, { res, rej, t }); KB.q.push({ id, op, args: args || {} }); kbFlush();
  });
}
async function rc(op, args, ms) { if (kreamMode() === 'cdp') return cdpOp(op, args, ms); await ensureWhale(); return rcall(op, args, ms); }
const fnName = f => (String(f || '').match(/^\s*(?:async\s+)?function\s*\*?\s*([\w$]+)/) || [])[1] || '';
// 기존 기능을 감싸서, 크림 주소·웨일 창이면 웨일로 보내요
{
  const W = { ...API.windows }, T = { ...API.tabs }, S = { ...API.scripting }, probe0 = API.app.probe;
  API.windows.create = async o => {
    if (!(o && isKreamUrl(o.url) && kreamViaWhale())) return W.create(o);
    const r = await rc('winCreate', { url: o.url, focused: !!o.focused, bg: !!o.background, width: o.width, height: o.height });
    return { id: RB + r.winId, tabs: [{ id: RB + r.tabId }], remote: true };
  };
  API.windows.get = async id => { if (!isRemote(id)) return W.get(id); const r = await rc('winGet', { id: id - RB }); return { id, focused: r.focused, state: r.state, remote: true }; };
  API.windows.update = async (id, o) => { if (!isRemote(id)) return W.update(id, o); await rc('winUpdate', { id: id - RB, focused: !!(o && o.focused), state: o && o.state }); return { id }; };
  API.windows.remove = async id => { if (!isRemote(id)) return W.remove(id); await rc('winRemove', { id: id - RB }); return true; };
  API.tabs.get = async id => { if (!isRemote(id)) return T.get(id); const r = await rc('tabGet', { id: id - RB }); return { id, url: r.url, status: r.status, windowId: RB + r.windowId, active: true, nav: null, remote: true }; };
  API.tabs.update = async (id, o) => { if (!isRemote(id)) return T.update(id, o); if (o && (o.url || o.muted !== undefined)) await rc('tabUpdate', { id: id - RB, url: o.url, muted: o.muted }); return { id }; };
  API.tabs.reload = async (id, o) => { if (!isRemote(id)) return T.reload(id, o); await rc('tabReload', { id: id - RB, bypassCache: !!(o && o.bypassCache) }); return true; };
  API.tabs.create = async o => {
    if (!(o && isKreamUrl(o.url) && kreamViaWhale())) return T.create(o);
    const r = await rc('tabCreate', { url: o.url });
    return { id: RB + r.tabId, windowId: RB + r.winId, remote: true };
  };
  API.tabs.sendMessage = async (id, msg) => { if (!isRemote(id)) return T.sendMessage(id, msg); return rc('send', { id: id - RB, msg }, 360000); };
  API.scripting.executeScript = async o => {
    const id = o.target && o.target.tabId;
    if (!isRemote(id)) return S.executeScript(o);
    const name = o.name || fnName(o.func);
    if (!name) throw new Error('웨일 창에서는 이름 있는 기능만 실행할 수 있어요');
    const r = await rc('exec', { id: id - RB, name, args: o.args || [], world: o.world || 'ISOLATED' }, 120000);
    return [{ result: r === undefined ? null : r }];
  };
  API.app.probe = async o => {
    if (!(o && isKreamUrl(o.url) && kreamViaWhale())) return probe0(o);
    try { return await rc('probe', { url: o.url, name: fnName(o.func) }, 40000); } catch (e) { return null; }
  };
  API.app.whale = async () => {
    if (kreamMode() === 'cdp') { const b = cdpBrowser(); return { via: 'cdp', browser: b, browserName: CDPB[b] || '브라우저', connected: cdpOpen(), ever: !!DATA.__cdpEver, have: { chrome: !!cdpPath('chrome'), edge: !!cdpPath('edge'), whale: !!cdpPath('whale') }, err: CDP.lastErr || '', folder: extDir() }; }
    const b = curBrowser(); return { via: kreamMode(), browser: b, browserName: BROWSERS[b], connected: whaleConnected(), ver: KB.ver, folder: extDir(), installed: !!whalePath(), have: { whale: !!browserPath('whale'), chrome: !!browserPath('chrome') }, ever: !!DATA.__extEver, other: KB.other && Date.now() - KB.other.t < 30000 ? BROWSERS[KB.other.b] : '', noKey: Date.now() - KB.noKey < 60000, oldExt: Date.now() - KB.oldLast < 30000 }; };
  API.app.browserSet = async b => {
    if (kreamMode() === 'cdp') { if (CDPB[b] && b !== cdpBrowser()) { DATA.__cdpB = b; saveSoon(); try { if (cdpOpen()) CDP.ws.close(); } catch (e) {} } return cdpBrowser(); }
    DATA.__browser = b === 'chrome' ? 'chrome' : 'whale'; DATA.__kreamMode = 'whale'; KB.last = 0; saveSoon(); return curBrowser(); };
  API.app.browserLaunch = async page => {
    if (kreamMode() === 'cdp') { if (page !== 'kream') return false; const T = await cdpNew('https://kream.co.kr/login', { focused: true }); try { const wid = await cdpWin(T); await cdpSend('Browser.setWindowBounds', { windowId: wid, bounds: { windowState: 'normal' } }); } catch (e) {} return true; }
    const b = curBrowser(), wp = browserPath(b); if (!wp) return false; const url = page === 'kream' ? 'https://kream.co.kr/login' : (b === 'chrome' ? 'chrome://extensions' : 'whale://extensions'); require('child_process').spawn(wp, [url], { detached: true, stdio: 'ignore' }).unref(); return true; };
  API.app.openExt = async u => { u = String(u || ''); if (!/^https:\/\/[^\s]+$/i.test(u)) throw new Error('https 주소만 열 수 있어요'); await shell.openExternal(u); return true; };   // 3.17.1 카카오 문의·이용권 구매는 평소 쓰는 브라우저로
  API.app.extPathCopy = async () => { copyExt(true); try { require('electron').clipboard.writeText(extDir()); } catch (e) {} return extDir(); };
  API.app.whaleSet = async via => { DATA.__kreamMode = ['cdp', 'whale', 'app'].includes(via) ? via : 'cdp'; saveSoon(); return kreamMode(); };
  API.app.whaleOpenFolder = async () => { copyExt(true); shell.openPath(extDir()); return extDir(); };
  API.app.whaleLaunch = async () => API.app.browserLaunch('extensions');
}
// 웨일 확장 파일을 '문서\크림스캐너 웨일 연결' 폴더에 두고, 새 버전이면 바꿔요 (웨일에 한 번만 '압축해제된 확장 프로그램'으로 올리면 돼요)
function extDir() { return process.env.KC_EXT_DIR || path.join(app.getPath('documents'), '크림스캐너 웨일 연결'); }
function copyExt(force) {
  try {
    const src = path.join(ROOT, 'whale-ext'); if (!fs.existsSync(path.join(src, 'manifest.json'))) return false;
    const dst = extDir(); const sv = JSON.parse(fs.readFileSync(path.join(src, 'manifest.json'), 'utf8')).version;
    let dv = ''; try { dv = JSON.parse(fs.readFileSync(path.join(dst, 'manifest.json'), 'utf8')).version; } catch (e) {}
    if (!force && dv === sv) return false;
    fs.mkdirSync(dst, { recursive: true }); fs.cpSync(src, dst, { recursive: true, force: true });
    // 3.34: 예전 버전이 넣어 둔 화면 파일은 지워요 (연결 확장에는 화면이 없어요)
    for (const f of ['app.html', 'app.css', 'app.js', 'xlsx.js', 'inv.js', 'auto.js', 'guide.js', 'buy.js', 'acct.js', 'abid.js', '사용법.txt', 'guide', 'fonts']) if (!fs.existsSync(path.join(src, f))) { try { fs.rmSync(path.join(dst, f), { recursive: true, force: true }); } catch (e) {} }
    kbWriteKey();
    return true;
  } catch (e) { console.error('웨일 확장 복사 실패', e); return false; }
}
// 웨일 확장이 옛 버전이면 새 파일로 다시 읽게 해요
kbWriteKey(); setInterval(kbWriteKey, 15000);
setInterval(() => { try { const mv = JSON.parse(fs.readFileSync(path.join(extDir(), 'manifest.json'), 'utf8')).version; if (KB.ver && mv && KB.ver !== mv && whaleConnected() && !KB.reloading) { KB.reloading = true; rcall('reload', {}, 5000).catch(() => {}).finally(() => setTimeout(() => { KB.reloading = false; }, 30000)); } } catch (e) {} }, 15000);
// 3.4.4: 사이트 화면이 비어서 나올 때 — 그 사이트의 서비스워커·캐시만 지워요 (로그인 쿠키는 그대로)
API.app.fixSite = async o => {
  const origin = typeof o === 'string' ? o : o && o.origin; const ses = prepShop(o && o.part);
  try { await ses.clearStorageData({ origin, storages: ['serviceworkers', 'cachestorage'] }); } catch (e) {}
  try { await ses.clearCache(); } catch (e) {}
  return true;
};
// 3.4.8: 쇼핑몰 창의 브라우저 정보(User-Agent)를 바꿔요 (빈 값이면 기본으로)
API.app.setUA = o => { const ua = (o && o.ua) || ''; if (ua) DATA.__shopUA = ua; else delete DATA.__shopUA; saveSoon(); for (const p of new Set([PART, ...prepped])) session.fromPartition(p).setUserAgent(ua || UA, 'ko-KR,ko,en-US,en'); return ua || UA; };
API.app.setSsrStrip = on => { DATA.__kreamSsrStrip = !!on; saveSoon(); return !!on; };
API.app.checkUpdate = () => checkUpdate(true);
API.app.updateState = () => updState;
API.app.restartNow = () => { setTimeout(restartForUpdate, 300); return true; };
API.app.openInstaller = url => { shell.openExternal(url || 'https://github.com/chldydrnr2-eng/kream-scanner/tree/main/updates'); return true; };

// ---------- 시작 ----------
app.on('second-instance', () => showMain());
app.on('activate', () => showMain());   // 맥: Dock 아이콘을 누르면 다시 열기
app.on('before-quit', () => { quitting = true; flush(); for (const p of new Set([PART, ...prepped])) try { session.fromPartition(p).cookies.flushStore(); } catch (e) {} });
app.on('window-all-closed', () => { /* 트레이에 남아요 */ });
app.whenReady().then(() => {
  loadData();
  const shop = prepShop(PART);
  for (const p of DATA.__parts || []) try { prepShop(p); } catch (e) {}   // 다른 아이디 저장 공간도 만료 토큰 정리·로그인 유지
  try { kbServer(); copyExt(false); } catch (e) {}
  // 3.4.9: 로그인한 상태로 크림 상품 화면을 열면 크림 서버가 10초 뒤 빈 오류(500)를 줘요(이 PC·계정에서 확인).
  //        상품 화면 '문서' 요청에만 로그인 쿠키를 빼서 화면은 정상으로 받고, 거래 내역 등은 화면이 로그인 정보로 따로 불러와요.
  shop.webRequest.onBeforeSendHeaders({ urls: ['https://kream.co.kr/products/*'] }, (d, cb) => {
    try {
      if (d.resourceType === 'mainFrame' && DATA.__kreamSsrStrip === true) {   // 3.5.0: 기본은 끔 (상품 화면도 로그인 상태로)
        const h = d.requestHeaders; const k = Object.keys(h).find(x => x.toLowerCase() === 'cookie');
        if (k) { const kept = h[k].split(/;\s*/).filter(c => !/^(_token\.|_refresh_token\.|strategy=|login_type=|ticketExpire=)/.test(c)); if (kept.length) h[k] = kept.join('; '); else delete h[k]; }
        return cb({ requestHeaders: h });
      }
    } catch (e) {}
    cb({});
  });
  try {
    tray = new Tray(nativeImage.createFromPath(ICON).resize({ width: 16, height: 16 }));
    tray.setToolTip('킥스캔');
    const menu = () => Menu.buildFromTemplate([
      { label: '킥스캔 열기', click: showMain },
      { label: 'Windows 시작할 때 실행', type: 'checkbox', checked: app.getLoginItemSettings().openAtLogin, click: it => app.setLoginItemSettings({ openAtLogin: it.checked, args: ['--hidden'] }) },
      { type: 'separator' },
      { label: '종료', click: () => { quitting = true; app.quit(); } }
    ]);
    tray.setContextMenu(menu()); tray.on('click', showMain);
  } catch (e) {}
  alarmsRestore();
  setTimeout(() => checkUpdate(false), 8000); setInterval(() => checkUpdate(false), 6 * 3600000);
  if (!process.argv.includes('--hidden')) showMain();
  else { appWin = createAppWin('', false); appWin.on('close', e => { if (!quitting) { e.preventDefault(); appWin.hide(); } }); }
});

};
