'use strict';
// 쇼핑몰 창: 확장 프로그램의 content script(크림 상품·마이페이지 응답 받아 적기)를 같은 방식으로 넣어요.
const { ipcRenderer, webFrame } = require('electron');
const fs = require('fs'), path = require('path');
// 3.4.3: 예전엔 폴더 경로 첫 글자를 잘라 먹어서(C:\… → :\…) 크림 수집 스크립트를 못 읽었어요 → 이 파일이 있는 폴더를 그대로 써요
const ROOT = __dirname || (process.argv.find(x => x.startsWith('--kc-root=')) || '').slice('--kc-root='.length);
const read = f => { try { return fs.readFileSync(path.join(ROOT, 'content', f), 'utf8'); } catch (e) { return ''; } };
const listeners = [];
const shim = { runtime: { onMessage: { addListener: fn => listeners.push(fn) } } };
const href = location.href;
const run = code => { try { new Function('chrome', code)(shim); } catch (e) { console.error('[kc]', e); } };
// 11/27: 쇼핑몰 알림(alert) 글을 적어 둬요 — 소싱 목록 창은 알림창을 끄니까(quiet) '검색결과가 없습니다'를 이걸로 알아봐요
webFrame.executeJavaScript(`(() => { const f = window.alert; window.alert = function (m) { try { window.__kcAlert = String(m == null ? '' : m).slice(0, 200); if (document.documentElement) document.documentElement.setAttribute('data-kc-alert', window.__kcAlert); } catch (e) {} return f.apply(this, arguments); }; })()`).catch(() => {});
if (/^https:\/\/kream\.co\.kr\/products\//.test(href)) { webFrame.executeJavaScript(read('hook.js')); run(read('core.js') + '\n' + read('bridge.js')); }
if (/^https:\/\/kream\.co\.kr\/my/.test(href)) { webFrame.executeJavaScript(read('hook-my.js')); run(read('bridge-my.js')); }
ipcRenderer.on('kc-msg', (e, id, msg) => {
  if (!listeners.length) return ipcRenderer.send('kc-reply', id, { __kcNoListener: 1 });
  let done = false; const send = r => { if (done) return; done = true; ipcRenderer.send('kc-reply', id, r); };
  let async = false;
  for (const fn of listeners) { try { if (fn(msg, {}, send) === true) async = true; } catch (err) { send({ error: String(err) }); } }
  if (!async) setTimeout(() => send(undefined), 50);
});
