'use strict';
// 킥스캔 화면(app.html)에 확장 프로그램용 chrome.* 기능을 똑같은 모양으로 넣어 줘요.
const { ipcRenderer } = require('electron');
const { pathToFileURL } = require('url');
const path = require('path');
const arg = n => (process.argv.find(x => x.startsWith('--' + n + '=')) || '').slice(n.length + 3);
const ROOT = arg('kc-root'), VER = arg('kc-ver');
// 3.36.6: 본체 오류를 손님이 읽을 말로 — "Error invoking remote method 'kc': Error: " 앞부분을 떼고, 인터넷 오류(net::ERR_…)는 한 문장으로 바꿔요
const cleanErr = e => {
  let m = String((e && e.message) || e || '').replace(/^Error invoking remote method '[^']*':\s*/, '').replace(/^(Type)?Error:\s*/, '');
  if (/net::ERR_|ERR_INTERNET|ERR_NAME_NOT_RESOLVED|fetch failed|Failed to fetch/i.test(m)) m = '인터넷 연결을 확인해 주세요';
  const er = new Error(m || '알 수 없는 오류가 났어요'); return er;
};
const call = (ns, m, ...a) => ipcRenderer.invoke('kc', ns, m, a).catch(e => { throw cleanErr(e); });
const noop = { addListener() {} };
window.__KC_APP = true;
window.kcApp = { info: () => call('app', 'info'), applyUpdate: b => call('app', 'applyUpdate', b), resetUpdate: () => call('app', 'resetUpdate'),
  checkUpdate: () => call('app', 'checkUpdate'), diag: () => call('app', 'diag'), updateState: () => call('app', 'updateState'), restartNow: () => call('app', 'restartNow'), probe: o => call('app', 'probe', o), fixSite: o => call('app', 'fixSite', o), clearLogin: o => call('app', 'clearLogin', o), setUA: o => call('app', 'setUA', o), setSsrStrip: o => call('app', 'setSsrStrip', o), whale: () => call('app', 'whale'), browserSet: b => call('app', 'browserSet', b), browserLaunch: p => call('app', 'browserLaunch', p), extPathCopy: () => call('app', 'extPathCopy'), openExt: u => call('app', 'openExt', u), whaleSet: v => call('app', 'whaleSet', v), whaleOpenFolder: () => call('app', 'whaleOpenFolder'), whaleLaunch: () => call('app', 'whaleLaunch'), openInstaller: u => call('app', 'openInstaller', u),
  onUpdate: fn => ipcRenderer.on('kc-update', (e, st) => fn(st)),
  // 개선판 1-11: 실행 편의 · 휴가 모드 · 긴급 정지
  ops: { get: () => call('app', 'opsGet'), set: o => call('app', 'opsSet', o), halt: () => call('app', 'opsHalt'), resume: () => call('app', 'opsResume'), vac: on => call('app', 'opsVac', on), idle: () => call('app', 'idle'), wins: () => call('app', 'opsWins'),
    busy: on => ipcRenderer.send('kc-busy', !!on), onChange: fn => ipcRenderer.on('kc-ops', (e, st) => fn(st)) },
  lic: { state: () => call('lic', 'state'), check: () => call('lic', 'check'), login: (e, p) => call('lic', 'login', e, p), pref: () => call('lic', 'pref'), setPref: p => call('lic', 'setPref', p), logout: () => call('lic', 'logout'), release: () => call('lic', 'release'), resetPw: e => call('lic', 'resetPw', e), releaseOthers: () => call('lic', 'releaseOthers'), shop: () => call('lic', 'shop'),signup: (e, p) => call('lic', 'signup', e, p), pay: (pl, d) => call('lic', 'pay', pl, d), payReady: () => call('lic', 'payReady'), orders: () => call('lic', 'orders'), snapPut: (k, d) => call('lic', 'snapPut', k, d), share: (f, a) => call('lic', 'share', f, a), snapState: () => call('lic', 'snapState'), snapClear: () => call('lic', 'snapClear'), onChange: fn => ipcRenderer.on('kc-lic', (e, st) => fn(st)) } };
window.chrome = {
  storage: { local: { get: k => call('storage', 'get', k === undefined ? null : k), set: o => call('storage', 'set', o), remove: k => call('storage', 'remove', k) }, onChanged: noop },
  scripting: { executeScript: o => call('scripting', 'executeScript', { target: o.target, args: o.args || [], world: o.world, func: String(o.func), name: (o.func && o.func.name) || '' }) },
  windows: { create: o => call('windows', 'create', o), get: id => call('windows', 'get', id), update: (id, o) => call('windows', 'update', id, o), remove: id => call('windows', 'remove', id) },
  tabs: { get: id => call('tabs', 'get', id), update: (id, o) => call('tabs', 'update', id, o), create: o => call('tabs', 'create', o), query: o => call('tabs', 'query', o), reload: (id, o) => call('tabs', 'reload', id, o || {}), sendMessage: (id, m) => call('tabs', 'sendMessage', id, m) },
  notifications: { create: (id, o) => call('notifications', 'create', id, o), onClicked: noop },
  alarms: { create: (n, a) => call('alarms', 'create', n, a), clear: n => call('alarms', 'clear', n), onAlarm: noop },
  runtime: { getManifest: () => ({ version: VER, name: '킥스캔' }), getURL: p => pathToFileURL(path.join(ROOT, p.split('?')[0])).href + (p.includes('?') ? p.slice(p.indexOf('?')) : ''), onMessage: noop, id: 'kream-scanner-app' }
};
