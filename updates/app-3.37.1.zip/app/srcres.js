// 소싱 결과 상자 (설계서 1-3-1 · 줍픽 PC 캡처 01·02·05~19·29·30번 구성) — 탭 · 필터 줄 · 필터 팝업 · 11열 표 · 확인 필요 · 상품 상세 패널 · 시세 차트 · 툴팁
// 데이터: store 'srcRows'(엔진이 채움) · 'srcCalc'(수익 계산 기준 + disc 할인) · 'srcRun'(실행 상태) · 'srcFilt'(필터·저장한 필터) · 'srcFav'(관심 상품)
// 계산은 src.js 순수 함수(srcCalcRow 등). 엔진은 renderSrcResult() 를 부르거나 'src:rows' 이벤트를 쏴요.
// renderSrcResult()                       — #srcResult 에 store srcRows/srcRun 으로 (실행 화면)
// renderSrcResult({ mount, rows, run, readonly }) — 소싱 이력 화면 등에서 지난 실행 결과를 같은 상자로 (readonly 면 다시 조회·확인 필요 고르기 같은 쓰기 동작을 숨겨요)
(() => {
  if (typeof document === 'undefined') return;
  const W = n => (n == null || isNaN(n)) ? '–' : Math.round(n).toLocaleString('ko-KR') + '원';
  const N = n => (n == null || isNaN(n)) ? '–' : Math.round(n).toLocaleString('ko-KR');
  const SG = n => (n == null || isNaN(n)) ? '–' : (n > 0 ? '+' : n < 0 ? '−' : '') + Math.abs(Math.round(n)).toLocaleString('ko-KR') + '원';
  const PC = n => n == null ? '–' : (Math.round(n * 10) / 10) + '%';
  const PCT = ch => (ch > 0 ? '+' : ch < 0 ? '−' : '') + Math.abs(Math.round(ch * 100)) + '%';
  const E = s => (typeof esc === 'function' ? esc(s) : String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])));
  const SELL = { kream: 'KREAM', poizon: 'POIZON' };
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  const env = () => ({ kFee: p => (typeof feeOf === 'function' ? feeOf(p) : Math.floor(p * 0.066)), pFee: p => (typeof pzFee === 'function' ? pzFee(p) : Math.floor(p * 0.1)),
    ship: typeof S !== 'undefined' ? (+S.ship || 0) : 0, pShip: 0, today: today() });
  // 엔진이 env 없이 불러도 수수료·발송비가 들어가게 감싸요
  const calcRow0 = srcCalcRow;
  srcCalcRow = (row, calc, e, opt) => calcRow0(row, calc, e || env(), opt);
  const hm = t => t ? new Date(t).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }) : '';
  const mdhm = t => { if (!t) return ''; const d = new Date(t); return `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const daysAgo = n => n == null ? '' : n <= 0 ? '오늘' : `${n}일 전`;
  const IC = {
    re: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M13 8a5 5 0 1 1-1.5-3.6M13 2.5v3h-3" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    fav: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 13.5S2.5 10.2 2.5 6.3A2.8 2.8 0 0 1 8 5a2.8 2.8 0 0 1 5.5 1.3c0 3.9-5.5 7.2-5.5 7.2Z" fill="var(--sr-fav,none)" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>',
    cp: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="5" y="5" width="8" height="8" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M3 10.5V4a1 1 0 0 1 1-1h6.5" fill="none" stroke="currentColor" stroke-width="1.3"/></svg>',
  };

  let LROWS = [], CALC = {}, LRUN = null, FL = { cur: {}, saved: [], seeded: false }, FAV = [], MYSZ = '';
  const INSTS = [], byHost = new Map();
  let PANEL = null;   // 열린 상세 패널: { I, id, all, trn:{kream,poizon}, ch:{kream,poizon}, fold:{buy,chart} }
  const cache = new Map();
  let ver = 0;   // 설정이 바뀌면 올려서 계산 캐시를 버려요
  const opt = () => ({ seller: FL.cur.seller || '', instant: !!FL.cur.instant });
  const calcOf = r => { const o = opt(), k = `${ver}|${r.at || 0}|${o.seller}|${o.instant ? 1 : 0}`, c = cache.get(r.id); if (c && c.k === k && c.r === r) return c.v; const v = srcCalcRow(r, CALC, env(), o); cache.set(r.id, { k, r, v }); return v; };
  const disc = () => CALC.disc || (CALC.disc = { on: { coupon: true, cart: true, grade: true, point: true, pay: true }, def: {}, sites: {} });
  async function saveCalc() { const cur = await store.get('srcCalc', {}); CALC = { ...cur, disc: disc() }; await store.set('srcCalc', CALC); ver++; }
  async function saveRows(ids) { await store.set('srcRows', LROWS); ver++; window.dispatchEvent(new CustomEvent('src:rows', { detail: { ids: ids || [], from: 'res' } })); }
  const saveFL = () => store.set('srcFilt', FL);
  function requote(ids, site) {
    if (typeof srcRequote === 'function') { try { srcRequote(ids, { site }); } catch (e) {} }
    else window.dispatchEvent(new CustomEvent('src:requote', { detail: { ids, site } }));
  }
  async function load() {
    LROWS = (await store.get('srcRows', [])) || []; if (!Array.isArray(LROWS)) LROWS = [];
    CALC = (await store.get('srcCalc', {})) || {};
    if (!CALC.disc) { const old = await store.get('srcDisc', null); if (old) CALC.disc = old; }   // 예전 'srcDisc'(11/20 판) 이어 쓰기
    LRUN = await store.get('srcRun', null);
    ver++;
  }
  const rowsOf = I => I.live ? LROWS : (I.rows || []);
  const runOf = I => I.live ? LRUN : I.run;
  const isOff = r => !!(r.offline || (r.buy || []).some(b => b && b.offline));
  const offN = r => (r.buy || []).filter(b => b && b.on !== false && b.price > 0).length;
  // 이 사이즈를 살 수 있는 매입처 수 (구매 계획 '외 N' = 가장 싼 곳 말고 더 있는 곳)
  const offersFor = (r, s) => (r.buy || []).filter(b => { if (!b || b.on === false || !(b.price > 0)) return false; const st = b.stock, by = st && st.by && Object.keys(st.by).length ? st.by : null; return by ? (+by[s] || 0) > 0 : st && st.total != null ? st.total > 0 : !!CALC.unknownStock; }).length;

  // ---------- 필터 (05~07번) ----------
  const NUMS = [['n30', '상품 30일 판매', '개 이상'], ['qty', '권장 수량', '개 이상'], ['won', '개당 수익', '원 이상'], ['rate', '수익률', '% 이상'], ['recMin', '권장 사이즈 판매', '개 이상'], ['recMax', '권장 사이즈 판매', '개 이하'], ['lastIn', '마지막 판매', '일 안'], ['maxBuy', '매입가', '원 이하']];
  const CHKS = [['noDown', '판매 감소 제외'], ['noDrop', '가격 하락 제외'], ['cash', '현금 수익만'], ['own', '보유 상품 제외'], ['fresh', '신규 수익 상품만'], ['noStock', '매입처 재고 많음 제외'], ['noBid', 'KREAM 판매 입찰 없음'], ['outside', '기준 밖 수익 후보만']];
  const SORTS = [['col', '표에서 고른 열'], ['monthly', '한 달 수익'], ['avg', '개당 수익'], ['rate', '수익률'], ['recN30', '권장 사이즈 판매'], ['room', '값 여유'], ['last', '마지막 판매'], ['buy', '매입가']];
  // 처음 한 번 넣어 두는 저장한 필터 (사용자가 지우거나 덮어쓸 수 있어요)
  const PRESETS = [['빠른 회전', { recMin: 10, lastIn: 3, noDown: true }], ['틈새', { recMax: 5, won: 10000 }], ['틈새 후보', { outside: true }], ['입찰 대기', { noBid: true }], ['공매도', { rate: 10, noDrop: true }]];
  const FKEYS = [...NUMS.map(x => x[0]), ...CHKS.map(x => x[0]), 'sort'];
  const fCount = f => NUMS.filter(([k]) => f[k] != null && f[k] !== '').length + CHKS.filter(([k]) => f[k]).length;
  const ownSet = () => { try { const ck = typeof codeKey === 'function' ? codeKey : s => String(s || '').replace(/[^A-Z0-9]/gi, '').toUpperCase(); return new Set((INV.items || []).map(x => ck(x.code)).filter(Boolean)); } catch (e) { return new Set(); } };
  function pass(r, C, f, own, run) {
    if (f.cat && (r.cat || '기타') !== f.cat) return false;
    const q = String(f.q || '').trim().toLowerCase();
    if (q && !`${r.name || ''} ${r.code || ''} ${r.brand || ''}`.toLowerCase().includes(q)) return false;
    const ge = (k, v) => f[k] == null || f[k] === '' || (v != null && v >= +f[k]), le = (k, v) => f[k] == null || f[k] === '' || (v != null && v <= +f[k]);
    if (!ge('n30', C.n30All) || !ge('qty', C.qty) || !ge('won', C.avg) || !ge('rate', C.rate) || !ge('recMin', C.recN30) || !le('recMax', C.recN30) || !le('lastIn', C.lastDays) || !le('maxBuy', C.buy)) return false;
    if (f.noDown && C.trend === '판매 감소') return false;
    if (f.noDrop && C.change != null && C.change < 0) return false;
    if (f.cash && !(C.cashAvg > 0)) return false;
    if (f.own && own) { const ck = typeof codeKey === 'function' ? codeKey(r.code) : String(r.code || '').replace(/[^A-Z0-9]/gi, '').toUpperCase(); if (own.has(ck)) return false; }
    if (f.fresh && !(r.firstAt && r.firstAt >= ((run && run.startedAt) || Date.now() - 864e5))) return false;
    if (f.noStock && C.stockTotal != null && C.stockTotal >= 100) return false;
    if (f.noBid && !C.noBid) return false;
    return true;
  }
  const SKV = { name: (r) => r.name || '', buy: (r, C) => C.buy, n30All: (r, C) => C.n30All, stock: (r, C) => C.stockTotal, recN30: (r, C) => C.recN30, change: (r, C) => C.change, qty: (r, C) => C.qty, avg: (r, C) => C.avg, rate: (r, C) => C.rate, monthly: (r, C) => C.monthly, room: (r, C) => C.room, last: (r, C) => C.lastDays == null ? null : -C.lastDays };
  function sorter(I) {
    const s = FL.cur.sort || 'monthly';
    const key = s === 'col' ? (I.sk || 'monthly') : s, dir = s === 'col' ? I.sd : (s === 'buy' ? 1 : -1);
    const f = SKV[key] || SKV.monthly;
    return (a, b) => { const va = f(a.r, a.C), vb = f(b.r, b.C); if (va == null && vb == null) return 0; if (va == null) return 1; if (vb == null) return -1; return (typeof va === 'string' ? va.localeCompare(vb) : va - vb) * dir; };
  }
  const inTab = (x, tab) => tab === 'check' ? !!x.r.need : tab === 'profit' ? !x.r.need && (FL.cur.outside ? x.C.outside : x.C.profitable) : tab === 'offline' ? !x.r.need && isOff(x.r) : true;

  // ---------- 상자 뼈대 ----------
  function inst(host, o) {
    let I = byHost.get(host);
    if (!I) { I = { idx: INSTS.length, host, live: true, rows: [], run: null, ro: false, tab: 'profit', sk: '', sd: -1, page: 0, shown: [], hid: 0 }; INSTS.push(I); byHost.set(host, I); }
    if (o) { I.live = !o.rows; I.rows = o.rows || []; I.run = o.run || null; I.ro = !!o.readonly; }
    return I;
  }
  function ensure(I) {
    if (!I.host || !I.host.isConnected) return false;
    if (I.root && I.host.contains(I.root)) return true;
    I.host.innerHTML = `<div class="sr-box" data-srinst="${I.idx}">
      <div class="sr-bar">
        <div class="sr-tabs" role="tablist" aria-label="결과 종류"></div><span class="sr-cnt"></span><span class="sr-sp"></span>
        <button type="button" class="sr-dd sr-cat" aria-haspopup="listbox"><span>품목</span><b>전체</b><i>▾</i></button>
        <button type="button" class="sr-dd sr-sel" aria-haspopup="listbox"><span>판매처</span><b>전체</b><i>▾</i></button>
        <label class="sr-inst" title="KREAM 은 지금 바로 팔 때 받는 값(구매 입찰 최고가)으로 계산해요"><input type="checkbox"><span>즉시 판매</span></label>
        <button type="button" class="sr-dd sr-fbtn" aria-haspopup="dialog">필터<b></b><i>▾</i></button>
        <label class="sr-srch"><input type="search" placeholder="상품명·품번" autocomplete="off" aria-label="상품명·품번 검색"></label>
      </div>
      <div class="sr-note"></div>
      <div class="sr-tw"><table class="sr-tbl"><thead></thead><tbody></tbody></table></div>
      <p class="sr-empty" hidden></p>
      <div class="sr-foot"></div></div>`;
    const R = I.root = I.host.querySelector('.sr-box'), q = s => R.querySelector(s);
    R.addEventListener('click', e => {
      const t = e.target.closest('[data-srtab]'); if (t) { if (t.disabled) return; I.tab = t.dataset.srtab; I.page = 0; return paint(I); }
      if (e.target.closest('.sr-cat')) return catMenu(I, e.target.closest('.sr-cat'));
      if (e.target.closest('.sr-sel')) return selMenu(I, e.target.closest('.sr-sel'));
      if (e.target.closest('.sr-fbtn')) return filtPop(I, e.target.closest('.sr-fbtn'));
      const th = e.target.closest('[data-srsk]');
      if (th) { const k = th.dataset.srsk; if (FL.cur.sort === 'col' && I.sk === k) I.sd = -I.sd; else { I.sk = k; I.sd = k === 'buy' || k === 'name' ? 1 : -1; } FL.cur.sort = 'col'; saveFL(); return paintAll(); }
      const pg = e.target.closest('[data-srpg]'); if (pg) { I.page = Math.max(0, I.page + +pg.dataset.srpg); return paint(I); }
      if (e.target.closest('[data-srre]')) { ver++; requote(I.shown.slice(0, 500)); paint(I); q('.sr-note').insertAdjacentHTML('beforeend', '<span class="sr-s">다시 확인을 요청했어요</span>'); return; }
      if (e.target.closest('tbody')) return rowsClick(I, e);
    });
    q('.sr-inst input').addEventListener('change', e => { FL.cur.instant = e.target.checked; saveFL(); paintAll(); });
    q('.sr-srch input').addEventListener('input', e => { FL.cur.q = e.target.value; I.page = 0; paintAll(); });
    return true;
  }

  // ---------- 그리기 ----------
  const PAGE = 100;
  function paintAll() { for (const I of INSTS) if (I.host && I.host.isConnected) paint(I); if (PANEL) paintDet(); filtSync(); }
  function paint(I) {
    if (!ensure(I)) return;
    const R = I.root, q = s => R.querySelector(s), rows = rowsOf(I), run = runOf(I), split = !!(PANEL && PANEL.I === I);
    const own = FL.cur.own ? ownSet() : null;
    const all = rows.filter(r => r && r.id).map(r => ({ r, C: calcOf(r) }));
    const n = { profit: 0, check: 0, offline: 0, all: all.length };
    for (const x of all) { if (inTab(x, 'profit')) n.profit++; if (x.r.need) n.check++; if (inTab(x, 'offline')) n.offline++; }
    if (I.tab === 'offline' && !n.offline) I.tab = 'profit';
    q('.sr-tabs').innerHTML = [['profit', '수익 상품'], ['check', '확인 필요'], ['offline', '오프라인에 있음'], ['all', '전체']]
      .map(([k, t]) => `<button type="button" role="tab" class="sr-tab" data-srtab="${k}" aria-selected="${I.tab === k}"${k === 'offline' && !n.offline ? ' disabled title="오프라인 매장 재고가 있는 상품이 없어요"' : ''}>${t}${k === 'check' && n.check ? '<i class="sr-dotw" aria-label="확인할 상품 있음"></i>' : ''}</button>`).join('');
    const tabRows = all.filter(x => inTab(x, I.tab));
    // 품목 · 판매처 · 즉시 판매 · 필터 · 검색
    if (FL.cur.cat && !tabRows.some(x => (x.r.cat || '기타') === FL.cur.cat)) FL.cur.cat = '';
    q('.sr-cat').hidden = !tabRows.length; q('.sr-cat b').textContent = FL.cur.cat || '전체';
    q('.sr-sel b').textContent = SELL[FL.cur.seller] || '전체';
    q('.sr-inst input').checked = !!FL.cur.instant;
    if (document.activeElement !== q('.sr-srch input')) q('.sr-srch input').value = FL.cur.q || '';
    const fc = fCount(FL.cur); q('.sr-fbtn b').textContent = fc ? ` ${fc}` : ''; q('.sr-fbtn').classList.toggle('on', !!fc);
    const list = tabRows.filter(x => pass(x.r, x.C, FL.cur, own, run)).sort(sorter(I));
    I.shown = list.map(x => x.r.id); I.hid = tabRows.length - list.length; I.tabN = tabRows.length;
    q('.sr-cnt').textContent = `${N(list.length)}개`;
    // 안내 줄
    const running = run && run.state === 'run', stopped = run && run.state === 'stop';
    const at = (run && (run.stoppedAt || run.endedAt)) || Math.max(0, ...rows.map(r => r.at || 0)) || null;
    const re = rows.length && !I.ro ? '<button type="button" class="sr-sm" data-srre>수익 상품 다시 확인</button>' : '';
    q('.sr-note').innerHTML = I.tab === 'check' ? `<span class="sr-warn">킥스캔이 같은 상품인지 · 어느 색인지 정하지 못한 상품이에요 — 사진으로 같은 상품 · 색을 고르면 그 판매처를 다시 조회해 수익 상품에 반영해요</span>${re}`
      : running ? `<span>수집 중이에요 — 재고 · 매입가는 수집 시점 기준이에요</span>${re}`
      : stopped && rows.length ? `<span class="sr-warn">이 실행은 마지막 재고 재확인 전에 중단됐어요 — 재고 · 매입가는 ${hm(at)} 기준이에요</span>${re}`
      : rows.length ? `<span>재고 · 매입가는 ${E(new Date(at || Date.now()).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }))} 수집 시점 기준이에요</span>${re}` : '';
    q('.sr-note').hidden = !q('.sr-note').innerHTML;
    // 표
    const em = q('.sr-empty'), tw = q('.sr-tw');
    if (!list.length) {
      tw.hidden = true; em.hidden = false; q('.sr-foot').innerHTML = '';
      em.textContent = !rows.length ? (running ? '수집 중이에요. 매입처 상품을 수집하는 대로 바로 표시돼요.' : I.ro ? '이 실행에는 결과가 없어요.' : '아직 결과가 없어요 — [지금 실행]을 누르면 수집되는 대로 여기에 채워져요.')
        : I.hid ? '필터에 맞는 상품이 없어요 — [필터]에서 조건을 줄여 보세요.' : running ? runWait(run, I.tab)
        : I.tab === 'check' ? '확인할 상품이 없어요.' : I.tab === 'offline' ? '오프라인 매장 재고가 있는 상품이 없어요.' : I.tab === 'profit' ? '아직 수익 상품이 없어요.' : '결과가 없어요.';
    } else {
      tw.hidden = false; em.hidden = true;
      const pages = Math.ceil(list.length / PAGE); if (I.page >= pages) I.page = pages - 1;
      const a = I.page * PAGE, b = Math.min(list.length, a + PAGE);
      q('.sr-tbl thead').innerHTML = I.tab === 'check' ? `<tr><th class="l sr-end">상품</th><th class="l" colspan="${split ? 4 : 9}">같은 상품 · 색 고르기 — 사진을 눌러요</th><th class="sr-end"></th></tr>` : head(I, split);
      q('.sr-tbl tbody').innerHTML = list.slice(a, b).map(x => x.r.need ? chkRow(x, I, split) : row(x, I, split)).join('');
      q('.sr-foot').innerHTML = `<span>${N(a + 1)}–${N(b)} / ${N(list.length)}</span>${pages > 1 ? `<button type="button" class="sr-ib" data-srpg="-1"${I.page ? '' : ' disabled'} aria-label="앞 쪽">‹</button><button type="button" class="sr-ib" data-srpg="1"${I.page < pages - 1 ? '' : ' disabled'} aria-label="다음 쪽">›</button>` : ''}`;
    }
    if (PANEL && PANEL.I === I && !rows.some(r => r.id === PANEL.id)) closeDet();
  }
  // 열 머리 (01번): 열 묶음 줄 + 정렬 표시 ⁝ · 상세 패널이 열리면 12번처럼 매입가·상품 30일 판매·재고·수익률을 빼요
  const COLS = [['name', '상품', 'l'], ['buy', '매입가', 'w'], ['n30All', '상품 30일 판매', 'w'], ['stock', '재고', 'w'], ['recN30', '권장 사이즈 판매<small>마지막 판매</small>'], ['change', '판매 추세'], ['qty', '권장 수량'], ['avg', '개당 수익'], ['rate', '수익률', 'w'], ['monthly', '한 달 수익']];
  function head(I, split) {
    const cur = FL.cur.sort === 'col' ? I.sk : (!FL.cur.sort || FL.cur.sort === 'monthly') ? 'monthly' : '';
    const mark = k => k === cur ? `<i class="sr-sm2 on">${FL.cur.sort === 'col' && I.sd > 0 ? '▲' : '▼'}</i>` : '<i class="sr-sm2">⁝</i>';
    const g = split ? '<tr class="sr-grp"><th colspan="2"></th><th colspan="3">구매 계획 · 권장 사이즈</th><th></th></tr>'
      : '<tr class="sr-grp"><th colspan="2"></th><th colspan="3">판매량 · 전 사이즈</th><th colspan="3">구매 계획 · 권장 사이즈</th><th colspan="3"></th></tr>';
    return g + `<tr>${COLS.filter(c => !(split && c[2] === 'w')).map(([k, t, c]) => `<th data-srsk="${k}" class="${c === 'l' ? 'l' : ''}${k === cur ? ' on' : ''}" title="눌러서 정렬"><span class="sr-th">${t.replace(/<small>.*$/, '')}${mark(k)}</span>${/<small>/.test(t) ? t.replace(/^.*(<small>)/, '$1') : ''}</th>`).join('')}${split ? '' : '<th class="sr-end"></th>'}</tr>`;
  }
  function row({ r, C }, I, split) {
    const b = C.offer, fav = FAV.includes(r.id), id = E(r.id);
    const sellers = C.sellers.length ? C.sellers : (C.sizes.find(s => s.best) ? [C.sizes.filter(s => s.best).sort((a, z) => z.best.profit - a.best.profit)[0].best.seller] : []);
    const nb = offN(r), cp = b && (b.coupon || srcBuyBase(b).page);
    // 재고: 권장 수량을 매입처 재고가 막은 사이즈가 있으면 주황 + 사이즈별
    const lowSz = C.rec.filter(s => s.stockKnown && s.stock <= s.q);
    const stockTxt = C.stockTotal == null ? (b ? '있음' : '–') : C.stockTotal >= 100 ? '100개+' : C.stockTotal > 0 ? `${N(C.stockTotal)}개` : '없음';
    const K = (r.kream && r.kream.sizes) || {};
    const plus = Object.values(K).some(k => k && k.n30More) ? '+' : '';
    const basis = sellers[0] ? SELL[sellers[0]] : C.sizes.some(s => s.per.kream) ? 'KREAM' : C.sizes.some(s => s.per.poizon) ? 'POIZON' : '';
    const recSub = C.lastDays == null ? '최근 판매 없음' : C.recN90 > C.recN30 ? `${daysAgo(C.lastDays)} · 90일 ${N(C.recN90)}개` : `마지막 판매 ${daysAgo(C.lastDays)}`;
    const ch = C.change, chp = ch != null && Math.round(ch * 100) !== 0;
    const c = [];
    c.push(`<td class="l sr-prod"><div class="sr-pc">${r.img ? `<img class="sr-img" src="${E(r.img)}" alt="" loading="lazy">` : '<span class="sr-img"></span>'}<div class="sr-pt"><b class="sr-nm" title="${E(r.name || r.code)}">${E(r.name || r.code)}</b>
      <span class="sr-s">${E([r.brand, r.code].filter(Boolean).join(' · '))}${b && b.url ? ` · <a href="${E(b.url)}" target="_blank" rel="noopener">구매 ↗</a>` : ''}${nb > 1 ? ` · <em class="sr-tag">${nb}곳 중 1위</em>` : ''}</span></div></div></td>`);
    if (!split) c.push(`<td><b class="sr-u" data-srtip="buy:${id}">${W(C.buy)}</b><span class="sr-s">${cp ? `<em class="sr-tag" title="${srcBuyBase(b).page ? '매입처 화면에 보이는 쿠폰·혜택가를 매입가에 반영했어요 (로그인·첫 구매·등급·카드 할인은 빼요)' : '매입처에 받을 수 있는 쿠폰이 있어요'}">${srcBuyBase(b).page ? '쿠폰 반영' : '쿠폰 받기'}</em> ` : ''}${C.list && C.buy != null && C.list > C.buy ? `<s>${W(C.list)}</s>` : ''}</span></td>`);
    if (!split) c.push(`<td><b>${N(C.n30All)}${plus}</b><span class="sr-s">${basis}</span></td>`);
    if (!split) c.push(`<td class="${lowSz.length ? 'sr-warn' : ''}"><b>${stockTxt}</b>${lowSz.length ? `<span class="sr-s sr-warn sr-ell">${lowSz.map(s => `${E(s.size)} ${s.stock}개`).join(' · ')}</span>` : ''}</td>`);
    c.push(`<td data-srtip="rec:${id}"><b>${N(C.recN30)}</b><span class="sr-s">${recSub}</span></td>`);
    c.push(`<td data-srtip="trend:${id}"><span class="${C.trend === '판매 증가' ? 'sr-ok' : C.trend === '판매 감소' ? 'sr-warn' : 'sr-mid'}">${C.trend}</span>${chp ? `<span class="sr-s${ch < 0 ? ' sr-warn' : ''}">가격 ${PCT(ch)}</span>` : ''}</td>`);
    c.push(`<td data-srtip="qty:${id}"><b>${N(C.qty)}개</b><span class="sr-s">사이즈 ${C.rec.length}개</span></td>`);
    const avgV = `<b class="sr-u ${C.avg > 0 ? 'sr-ok' : C.avg != null ? 'sr-neg' : ''}" data-srtip="avg:${id}">${C.avg != null ? SG(C.avg) : '–'}</b>`, bdg = `${sellers[0] ? `<span class="sr-bdg ${sellers[0]}">${SELL[sellers[0]]}</span>` : ''}${sellers.length > 1 ? `<span class="sr-s2">외 ${sellers.length - 1}</span>` : ''}`;
    // 상세 패널이 열려 표가 좁으면 판매처 배지를 아랫줄로 내려요
    c.push(split ? `<td>${avgV}<span class="sr-avg">${bdg}</span></td>` : `<td><span class="sr-avg">${avgV}${bdg}</span>${sellers[0] === 'poizon' && C.cashAvg != null ? `<span class="sr-s">현금 ${SG(C.cashAvg)}</span>` : ''}</td>`);
    if (!split) c.push(`<td>${PC(C.rate)}</td>`);
    c.push(`<td><b class="${C.monthly > 0 ? 'sr-ok' : ''} sr-mo">${C.monthly ? SG(C.monthly) : '–'}</b></td>`);
    if (!split) c.push(`<td class="sr-end">${I.ro ? '' : `<button type="button" class="sr-ib" data-srq="${id}" title="다시 조회" aria-label="다시 조회">${IC.re}</button>`}<button type="button" class="sr-ib${fav ? ' on' : ''}" data-srfav="${id}" title="관심 상품" aria-label="관심 상품" aria-pressed="${fav}">${IC.fav}</button></td>`);
    return `<tr data-srid="${id}" class="${PANEL && PANEL.I === I && PANEL.id === r.id ? 'sr-on' : ''}">${c.join('')}</tr>`;
  }
  // 확인 필요 줄 (10번): 크림 사진 옆에 후보 사진 — 같은 상품·색을 누르면 그 판매처를 다시 조회해요
  function chkRow({ r }, I, split) {
    const cols = split ? 6 : 11;
    const cands = (r.cands || []).map((c, j) => `<span class="sr-cand">
      <button type="button" data-srpick="${j}" data-srid="${E(r.id)}" title="크림 상품과 같은 상품·색이면 눌러 주세요"${I.ro ? ' disabled' : ''}>
      ${c.img ? `<img class="sr-img" src="${E(c.img)}" alt="">` : '<span class="sr-img sr-noimg">사진 없음</span>'}
      <span><span class="sr-s">${E(c.label || c.site)} · ${E(String(c.name || '').slice(0, 36))}</span><b>${W(c.price)}</b></span></button>
      <span class="sr-s">${c.url ? `<a href="${E(c.url)}" target="_blank" rel="noopener">보기 ↗</a>` : ''}${I.ro ? '' : `${c.url ? ' · ' : ''}<button type="button" class="linkbtn sr-no" data-srno="${j}" data-srid="${E(r.id)}">다른 상품이에요</button>`}</span></span>`).join('');
    return `<tr data-srid="${E(r.id)}" class="sr-chk">
      <td class="l sr-prod sr-pchk"><div class="sr-pc">${r.img ? `<img class="sr-img" src="${E(r.img)}" alt="">` : '<span class="sr-img"></span>'}<div class="sr-pt"><b class="sr-nm">${E(r.name || r.code)}</b><span class="sr-s">${E([r.brand, r.code].filter(Boolean).join(' · '))}</span></div></div></td>
      <td class="l" colspan="${cols - 2}"><div class="sr-cands">${cands || (r.needWhy ? `<span class="sr-s">${E(r.needWhy)} · <a href="https://kream.co.kr/search?keyword=${encodeURIComponent(r.code || '')}" target="_blank" rel="noopener">KREAM 에서 찾아보기 ↗</a>${I.ro ? '' : ` · <button type="button" class="linkbtn" data-srq="${E(r.id)}">다시 조회</button>`}</span>` : '<span class="sr-s">후보가 없어요</span>')}</div></td>
      <td class="sr-end"><span class="sr-bdg warn">확인 필요</span></td></tr>`;
  }
  async function rowsClick(I, e) {
    const pk = e.target.closest('[data-srpick]'); if (pk) return I.ro ? null : pick(pk.dataset.srid, +pk.dataset.srpick);
    const no = e.target.closest('[data-srno]'); if (no) return I.ro ? null : reject(no.dataset.srid, +no.dataset.srno);
    const q = e.target.closest('[data-srq]'); if (q) { requote([q.dataset.srq]); q.classList.add('spin'); q.title = '다시 조회를 요청했어요'; return; }
    const f = e.target.closest('[data-srfav]'); if (f) return toggleFav(f.dataset.srfav);
    if (e.target.closest('a,button,input,select,label')) return;
    const tr = e.target.closest('tr[data-srid]'); if (tr && !tr.classList.contains('sr-chk')) openDet(I, tr.dataset.srid);
  }
  async function toggleFav(id) { FAV = FAV.includes(id) ? FAV.filter(x => x !== id) : [...FAV, id]; await store.set('srcFav', FAV); paintAll(); }
  async function pick(id, j) {
    const r = LROWS.find(x => x.id === id); if (!r || !r.cands || !r.cands[j]) return;
    const c = r.cands[j];
    r.buy = (r.buy || []).filter(b => b.site !== c.site).concat([{ site: c.site, label: c.label, url: c.url, list: c.list || c.price, price: c.price, stock: null, stockAt: null, on: true, picked: true }]);
    r.need = false; r.picked = { ...c, at: Date.now() }; r.cands = []; r.at = Date.now();
    await saveRows([id]); requote([id], c.site); paintAll();
  }
  async function reject(id, j) {
    const r = LROWS.find(x => x.id === id); if (!r || !r.cands) return;
    r.cands.splice(j, 1); if (!r.cands.length) r.need = false; r.at = Date.now();
    await saveRows([id]); paintAll();
  }

  // ---------- 툴팁 (13·16·29·30번) ----------
  const kv = (k, v, cls = '') => `<div class="sr-kv"><span>${k}</span><b class="${cls}">${v}</b></div>`;
  const HT = {
    plan: '<b class="sr-tt">구매 계획</b><p>권장 수량대로 사이즈별로 사서, 사이즈마다 수익이 가장 큰 판매처에 팔 때의 계획이에요.</p><p>개당 수익은 판매처 수수료 · 발송비 · 매입가를 뺀 값이에요. POIZON 은 부가세 환급(매입가 ÷ 11)을 더했어요.</p><p>회색 줄은 판매 예상(30 ÷ 사이즈 30일 판매) · 판매 입찰 · 값 여유(판매가를 얼마나 내려도 수익인지) · 이 사이즈를 파는 다른 매입처 수예요. 주의할 내용은 주황이에요.</p>',
    filt: '<b class="sr-tt">필터</b><p>숫자 조건은 비우면 안 걸러요. 권장 사이즈 = 권장 수량이 1개 이상인 사이즈예요.</p><p>신규 수익 상품 = 이번 실행에서 처음 수익 상품이 된 것 · 매입처 재고 많음 = 매입처 재고 100개 이상 · 기준 밖 수익 후보 = 남지만 30일 판매 · 최소 수익 기준에 못 미친 것이에요.</p>',
    pz_n30: '<b class="sr-tt">POIZON 30일 판매</b><p>POIZON 에서 최근 30일 동안 이 사이즈가 팔린 수예요. 0 이면 거래가 없어 판매가는 노출가만 보고 정했어요.</p>',
    pz_price: '<b class="sr-tt">POIZON 예상 판매가</b><p>POIZON 앱에 보이는 이 사이즈의 판매가(노출가)예요 — 지금 등록하면 이 값에 팔린다고 보고 계산해요.</p>',
    pz_profit: '<b class="sr-tt">POIZON 개당 수익</b><p>예상 판매가에서 POIZON 수수료 · 발송비 · 매입가를 빼고 부가세 환급(매입가 ÷ 11)을 더한 값이에요.</p><p>환급 전 금액은 표의 [개당 수익] 아래 [현금]으로 따로 보여 줘요.</p>',
    pz_basis: '<b class="sr-tt">기준</b><p>노출가 = POIZON 앱에 보이는 값으로 계산했어요. 거래 없음 = 최근 30일 거래가 없어 수익 상품에는 넣지 않았어요.</p>',
    kr_n30: '<b class="sr-tt">KREAM 30일 판매</b><p>최근 30일 KREAM 체결 수예요. 괄호는 그중 빠른 배송 체결 수예요.</p>',
    kr_asks: '<b class="sr-tt">KREAM 판매 입찰</b><p>지금 등록된 판매 입찰 건수예요. 아랫줄은 최저 판매가 +5% 안에 있는 건수 — 많을수록 내 입찰이 밀려 늦게 팔려요.</p><p>+5% 안 건수가 30일 판매보다 많으면 권장 수량을 절반으로 줄여요.</p>',
    kr_bid: '<b class="sr-tt">KREAM 즉시 판매가</b><p>지금 판매하면 받는 금액 — 해당 사이즈의 구매 입찰 최고가예요.</p><p>오른쪽 [즉시 수익]은 KREAM 수수료 · 매입가를 뺀 수익이에요. 이 상품이 최근 30일 KREAM 에서 기준(설정 › 수익 계산) 이상 판매됐을 때만 수익 상품에 반영해요(못 미치면 흐리게).</p>',
    kr_inst: '<b class="sr-tt">KREAM 즉시 수익</b><p>즉시 판매가로 지금 팔 때의 개당 수익이에요 — KREAM 수수료 · 발송비 · 매입가를 뺐어요.</p><p>필터 줄의 [즉시 판매]를 켜면 이 값으로 계산해요.</p>',
    kr_ask: '<b class="sr-tt">KREAM 최저 판매가</b><p>지금 등록된 가장 싼 판매 입찰이에요. 내가 입찰하면 이 값보다 비싸게 팔기 어려워 체결가 상한으로 봐요.</p>',
    kr_bidp: '<b class="sr-tt">KREAM 입찰 시 수익</b><p>최저 판매가로 판매 입찰해서 팔릴 때의 개당 수익이에요. 기본 계산은 이 값을 써요.</p>',
  };
  function tipRec(C, title) {
    const L = [`<b class="sr-tt">${title}</b>`,
      kv('최근 14일 · 30일 판매(권장 사이즈 합)', `${N(C.recN14)} · ${N(C.recN30)}`),
      kv(`마지막 판매 ${C.lastDays != null ? daysAgo(C.lastDays) : ''}`, C.lastDate || '기록 없음'),
      kv('최근 90일 판매(권장 사이즈 합)', `${N(C.recN90)}${C.recN90 ? ' 이상' : ''}`),
      kv('가격 — 최근 14일 평균 ÷ 그 전', C.change == null ? '–' : PCT(C.change)),
      kv('상품 전체(전 사이즈) 판매 추세', `${C.trend} · 14일 ${N(C.n14All)} · 30일 ${N(C.n30All)}`), '<hr>'];
    for (const s of C.rec.slice(0, 8)) L.push(kv(E(s.size), `14일 ${N(s.n14)} · 30일 ${N(s.n30)} · ${s.trend}`));
    if (C.rec.length > 8) L.push(`<div class="sr-s">외 ${C.rec.length - 8}개 사이즈</div>`);
    if (!C.rec.length) L.push('<div class="sr-s">권장 사이즈가 없어요</div>');
    L.push('<hr><p>권장 사이즈(권장 1개 이상)의 최근 30일 판매를 더한 수예요 — 아래 구매 계획의 [30일 판매]와 같은 값이에요. 옆 [상품 30일 판매]는 상품 전체(전 사이즈)의 수예요.</p>',
      '<p>아랫줄은 마지막 판매일과 최근 90일 판매 수(「18일 전 · 90일 5개」)예요 — 권장 사이즈에 판매 기록이 없으면 「최근 판매 없음」이에요. 판매 · 가격 추세는 오른쪽 [판매 추세] 열에 있어요.</p>');
    return L.join('');
  }
  function tipQty(C) {
    const c = { ...SRC_CALC_DEF.rec, ...((CALC && CALC.rec) || {}) };
    const L = [`<b class="sr-tt">권장 수량 ${N(C.qty)}개</b>`];
    for (const s of C.rec) L.push(kv(`${E(s.size)} · ${SELL[s.best.seller]} 30일 판매 ${N(s.n30)}개`, `${s.q}개`));
    if (!C.rec.length) L.push('<div class="sr-s">권장 수량이 있는 사이즈가 없어요</div>');
    L.push(`<hr><p>한 달 안에 판매할 수 있는 수량이에요 — 사이즈마다 수익이 가장 큰 판매처의 30일 판매를 ${c.div}로 나눈 수(최대 ${c.max}개)로 정하고, 매입처 재고까지로 제한했어요. 30일 판매를 모두 가져갈 수 있다고 보지 않아 나눠요.</p>`,
      `<p>${c.bidHalf ? 'KREAM 판매 입찰(최저 판매가 +5% 안)이 30일 판매보다 많은 사이즈는 절반으로 줄였어요. ' : ''}개당 수익이 0 이하이거나 최소 수익 · 최소 수익률(설정 › 수익 계산)에 못 미치면 0개예요.</p>`);
    return L.join('');
  }
  function tipBuy(r, C) {
    const s = C.rec[0] || C.sizes.find(z => z.disc), d = s && s.disc;
    if (!d) return '<b class="sr-tt">매입가</b><p>매입가를 찾은 매입처가 없어요.</p>';
    const L = [`<b class="sr-tt">매입가 ${W(d.final)}</b>`, kv(`${E((s.offer && (s.offer.label || s.offer.site)) || '')} 판매가`, W(d.tag))];
    for (const t of d.steps) if (t.amt) L.push(kv(E(t.label), `−${W(t.amt)}`));
    L.push(kv('할인 반영 매입가', W(d.final)));
    if (C.list && C.list > d.tag) L.push(kv('정가', `<s>${W(C.list)}</s>`));
    L.push('<hr><p>상품 쿠폰 → 장바구니 · 중복 쿠폰 → 등급 할인 → 적립금 선할인 → 결제 즉시할인 차례로 넣어요. 켜고 끄기는 설정 › 수익 계산, 매입처별 내 할인은 상세의 [매입가 › 내 할인]에서 바꿔요.</p>');
    return L.join('');
  }
  function tipAvg(C) {
    const L = ['<b class="sr-tt">개당 수익</b>'];
    for (const s of C.rec.slice(0, 8)) L.push(kv(`${E(s.size)} · ${SELL[s.best.seller]} ${W(s.best.price)}`, SG(s.best.profit), s.best.profit > 0 ? 'sr-ok' : 'sr-neg'));
    L.push(`<hr><p>권장 사이즈의 개당 수익을 권장 수량으로 평균했어요. 개당 수익 = 예상 판매가 − 판매처 수수료 − 발송비 − 매입가${CALC.vatRefund !== false ? ' · POIZON 은 부가세 환급(매입가 ÷ 11)을 더했어요' : ''}.</p>`);
    if (C.cashAvg != null && C.cashAvg !== C.avg) L.push(`<p>환급 전 현금 수익은 평균 ${SG(C.cashAvg)}이에요.</p>`);
    return L.join('');
  }
  function tipHtml(el) {
    if (el.dataset.srtipt != null) return E(el.dataset.srtipt).replace(/\n/g, '<br>');
    const [k, ...rest] = el.dataset.srtip.split(':'), id = rest.join(':');
    if (k === 'h') return HT[id] || '';
    const host = el.closest('[data-srinst]'), I = host ? INSTS[+host.dataset.srinst] : PANEL && PANEL.I;
    const r = I && rowsOf(I).find(x => x.id === id); if (!r) return '';
    const C = calcOf(r);
    return k === 'rec' ? tipRec(C, `권장 사이즈 판매 · ${N(C.recN30)}개`) : k === 'trend' ? tipRec(C, '판매 추세') : k === 'qty' ? tipQty(C) : k === 'buy' ? tipBuy(r, C) : k === 'avg' ? tipAvg(C) : '';
  }
  let tipEl = null, tipCur = null;
  function tipHide() { tipCur = null; if (tipEl) tipEl.hidden = true; }
  document.addEventListener('mouseover', e => {
    const t = e.target.closest && e.target.closest('[data-srtip],[data-srtipt]');
    if (t === tipCur) return;
    if (!t) return tipHide();
    const html = tipHtml(t); if (!html) return tipHide();
    if (!tipEl) { tipEl = document.createElement('div'); tipEl.className = 'sr-tip'; tipEl.setAttribute('role', 'tooltip'); document.body.appendChild(tipEl); }
    tipCur = t; tipEl.innerHTML = html; tipEl.hidden = false;
    const a = t.getBoundingClientRect(), w = tipEl.offsetWidth, h = tipEl.offsetHeight, vw = innerWidth, vh = innerHeight;
    let x = a.left, y = a.bottom + 6;
    if (x + w > vw - 8) x = Math.max(8, vw - w - 8);
    if (y + h > vh - 8) y = a.top - h - 6 < 8 ? Math.max(8, vh - h - 8) : a.top - h - 6;
    tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px';
  });
  window.addEventListener('scroll', tipHide, true);

  // ---------- 작은 팝업 (품목 · 판매처 · 필터) ----------
  let POP = null;   // { el, btn, I, kind }
  function popOpen(I, btn, kind, html) {
    popClose();
    const el = document.createElement('div'); el.className = `sr-pop sr-pop-${kind}`; el.innerHTML = html; document.body.appendChild(el);
    const a = btn.getBoundingClientRect();
    el.style.top = (a.bottom + 6) + 'px';
    el.style.left = Math.max(8, Math.min(innerWidth - el.offsetWidth - 8, kind === 'filt' ? a.right - el.offsetWidth : a.left)) + 'px';
    const mh = innerHeight - a.bottom - 16; if (el.offsetHeight > mh) el.style.maxHeight = Math.max(200, mh) + 'px';
    btn.setAttribute('aria-expanded', 'true');
    POP = { el, btn, I, kind };
    return el;
  }
  function popClose() { if (!POP) return; POP.btn.setAttribute('aria-expanded', 'false'); POP.el.remove(); POP = null; }
  document.addEventListener('mousedown', e => { if (POP && !POP.el.contains(e.target) && !POP.btn.contains(e.target)) popClose(); });
  document.addEventListener('keydown', e => { if (e.key !== 'Escape') return; if (POP) return popClose(); if (PANEL && !document.querySelector('dialog[open]')) closeDet(); });
  window.addEventListener('resize', () => { popClose(); tipHide(); });
  function menu(I, btn, kind, items, cur, on) {
    if (POP && POP.btn === btn) return popClose();
    const el = popOpen(I, btn, kind, `<div role="listbox">${items.map(([v, l, n]) => `<button type="button" role="option" data-srmv="${E(v)}" aria-selected="${v === cur}"><i>${v === cur ? '✓' : ''}</i><span>${E(l)}</span>${n != null ? `<em>${N(n)}</em>` : ''}</button>`).join('')}</div>`);
    el.addEventListener('click', e => { const b = e.target.closest('[data-srmv]'); if (!b) return; on(b.dataset.srmv); popClose(); });
  }
  function catMenu(I, btn) {
    const tabRows = rowsOf(I).filter(r => r && r.id).map(r => ({ r, C: calcOf(r) })).filter(x => inTab(x, I.tab));
    const cats = {}; for (const x of tabRows) { const c = x.r.cat || '기타'; cats[c] = (cats[c] || 0) + 1; }
    menu(I, btn, 'menu', [['', '전체', tabRows.length], ...Object.entries(cats).sort((a, b) => b[1] - a[1]).map(([c, n]) => [c, c, n])], FL.cur.cat || '', v => { FL.cur.cat = v; I.page = 0; saveFL(); paintAll(); });
  }
  function selMenu(I, btn) { menu(I, btn, 'menu', [['', '전체'], ['poizon', 'POIZON'], ['kream', 'KREAM']], FL.cur.seller || '', v => { FL.cur.seller = v; saveFL(); paintAll(); }); }

  // ---------- 필터 팝업 (05·06·07번) — 고치는 대로 바로 걸러요 ----------
  const keepCur = () => ({ q: FL.cur.q || '', cat: FL.cur.cat || '', seller: FL.cur.seller || '', instant: !!FL.cur.instant });
  const fOnly = f => { const o = {}; for (const k of FKEYS) if (f[k] != null && f[k] !== '' && f[k] !== false && !(k === 'sort' && f[k] === 'monthly')) o[k] = f[k]; return o; };
  const sameF = (a, b) => JSON.stringify(fOnly(a), FKEYS.slice().sort()) === JSON.stringify(fOnly(b), FKEYS.slice().sort());
  function filtHtml() {
    const c = FL.cur;
    return `<div class="sr-fsv"><span class="sr-fl">저장한 필터</span>${FL.saved.map((s, i) => `<span class="sr-fch${sameF(s.f, c) ? ' on' : ''}"><button type="button" data-srsl="${i}">${E(s.name)}</button><button type="button" class="sr-fx" data-srsx="${i}" aria-label="${E(s.name)} 지우기" title="지우기">×</button></span>`).join('')}
        <span class="sr-fch sr-fadd"><button type="button" data-srsadd title="지금 조건에 이름을 붙여 저장해요">+ 저장</button></span></div>
      <div class="sr-fnum">${NUMS.map(([k, l, u]) => `<label><span>${l}</span><input data-srfn="${k}" inputmode="decimal" value="${c[k] ?? ''}" placeholder="0" aria-label="${l} ${u}"><em>${u}</em></label>`).join('')}</div>
      <div class="sr-fchk">${CHKS.map(([k, l]) => `<label><input type="checkbox" data-srfc="${k}"${c[k] ? ' checked' : ''}><span>${l}</span></label>`).join('')}</div>
      <label class="sr-fsort"><span>정렬 기준</span><select data-srfs>${SORTS.map(([k, l]) => `<option value="${k}"${(c.sort || 'monthly') === k ? ' selected' : ''}>${l}</option>`).join('')}</select></label>
      <div class="sr-ffoot"><span class="sr-fhid"></span><span class="sr-sp"></span><i class="sr-qm" data-srtip="h:filt">?</i><button type="button" class="sr-sm" data-srfclr>지우기</button></div>`;
  }
  function filtSync() {
    if (!POP || POP.kind !== 'filt') return;
    const h = POP.el.querySelector('.sr-fhid'); if (h) h.textContent = `${N(POP.I.hid || 0)}개 숨김`;
    POP.el.querySelectorAll('[data-srsl]').forEach(b => b.parentElement.classList.toggle('on', sameF(FL.saved[+b.dataset.srsl].f, FL.cur)));
  }
  let fT = null;
  function filtPop(I, btn) {
    if (POP && POP.btn === btn) return popClose();
    const el = popOpen(I, btn, 'filt', filtHtml());
    const redraw = () => { el.innerHTML = filtHtml(); filtSync(); };
    const apply = () => { I.page = 0; clearTimeout(fT); fT = setTimeout(() => { saveFL(); paintAll(); }, 150); };
    filtSync();
    el.addEventListener('input', e => {
      const n = e.target.closest('[data-srfn]'); if (!n) return;
      const s = String(n.value || '').replace(/[^\d.-]/g, ''); if (s !== '' && !isNaN(+s)) FL.cur[n.dataset.srfn] = +s; else delete FL.cur[n.dataset.srfn];
      apply();
    });
    el.addEventListener('change', e => {
      const c = e.target.closest('[data-srfc]'); if (c) { if (c.checked) FL.cur[c.dataset.srfc] = true; else delete FL.cur[c.dataset.srfc]; return apply(); }
      const s = e.target.closest('[data-srfs]'); if (s) { if (s.value === 'monthly') delete FL.cur.sort; else FL.cur.sort = s.value; return apply(); }
    });
    el.addEventListener('click', e => {
      const sl = e.target.closest('[data-srsl]'); if (sl) { FL.cur = { ...keepCur(), ...FL.saved[+sl.dataset.srsl].f }; saveFL(); paintAll(); return redraw(); }
      const sx = e.target.closest('[data-srsx]'); if (sx) { FL.saved.splice(+sx.dataset.srsx, 1); saveFL(); return redraw(); }
      if (e.target.closest('[data-srfclr]')) { FL.cur = keepCur(); saveFL(); paintAll(); return redraw(); }
      const add = e.target.closest('[data-srsadd]');
      if (add) { add.parentElement.outerHTML = '<span class="sr-fch sr-fadd on"><input data-srsname maxlength="16" placeholder="이름" aria-label="저장할 필터 이름"><button type="button" data-srsok>저장</button></span>'; el.querySelector('[data-srsname]').focus(); return; }
      if (e.target.closest('[data-srsok]')) return saveNamed();
    });
    el.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.closest('[data-srsname]')) { e.preventDefault(); saveNamed(); } });
    function saveNamed() {
      const nm = String((el.querySelector('[data-srsname]') || {}).value || '').trim().slice(0, 16); if (!nm) return;
      const f = fOnly(FL.cur), i = FL.saved.findIndex(s => s.name === nm), s = { name: nm, f };
      if (i >= 0) FL.saved[i] = s; else FL.saved.push(s);
      saveFL(); redraw();
    }
  }

  // ---------- 상품 상세 패널 (12·14~19번) — 오른쪽에 열리고 표는 왼쪽으로 좁아져요 ----------
  function detEl() {
    let a = document.getElementById('srDet'); if (a) return a;
    a = document.createElement('aside'); a.id = 'srDet'; a.className = 'sr-det'; a.setAttribute('aria-label', '상품 상세'); a.setAttribute('aria-hidden', 'true');
    document.body.appendChild(a);
    a.addEventListener('click', drwClick); a.addEventListener('change', drwChange);
    document.addEventListener('click', e => { if (PANEL && e.target.closest('aside.side')) closeDet(); });   // 메뉴로 다른 화면에 가면 닫아요
    return a;
  }
  function openDet(I, id) {
    const keep = PANEL && PANEL.I === I ? PANEL : null;
    PANEL = { I, id, all: false, trn: { kream: 10, poizon: 10 }, ch: keep ? keep.ch : { kream: { per: 90, size: '' }, poizon: { per: 90, size: '' } }, fold: keep ? keep.fold : { buy: false, chart: true } };
    const d = detEl(); paintDet(); d.classList.add('on'); d.setAttribute('aria-hidden', 'false'); d.scrollTop = 0;
    const db = d.querySelector('.sr-db'); if (db) db.scrollTop = 0;
    document.body.classList.add('sr-split', 'drw-open');
    paint(I);
  }
  window.srCloseDet = () => { if (PANEL) closeDet(); };   // 화면을 바꾸면(route) 닫아요
  function closeDet() {
    const I = PANEL && PANEL.I; PANEL = null;
    const d = document.getElementById('srDet'); if (d) { d.classList.remove('on'); d.setAttribute('aria-hidden', 'true'); }
    document.body.classList.remove('sr-split'); if (!document.querySelector('.drw.on')) document.body.classList.remove('drw-open');
    if (I) paint(I);
  }
  const kUrl = r => r.pid ? `https://kream.co.kr/products/${encodeURIComponent(r.pid)}` : r.code ? `https://kream.co.kr/search?keyword=${encodeURIComponent(r.code)}` : '';
  const pUrl = r => (r.poizon && r.poizon.url) || '';
  const lnk = (u, v, cls = '') => u ? `<a class="sr-lk ${cls}" href="${E(u)}" target="_blank" rel="noopener">${v}</a>` : `<span class="${cls}">${v}</span>`;
  function sizeNote(r, s) {
    const P = [];
    if (s.n14 != null && (s.trend === '판매 증가' || s.trend === '판매 감소')) P.push(s.trend === '판매 감소' ? `<span class="sr-warn">14일 ${N(s.n14)}개 · 판매 감소</span>` : `14일 ${N(s.n14)}개 · 판매 증가`);
    if (s.period) P.push(`최저가로 등록하면 약 ${s.period >= 1 ? Math.round(s.period) : s.period}일에 1개 판매`);
    if (s.best && s.best.seller === 'kream' && s.asks != null) {
      if (!s.asks) P.push('판매 입찰 없음');
      else if (s.n30 > 0 && s.asks >= s.n30 * 2) P.push(`<span class="sr-warn">판매 입찰 ${N(s.asks)}건(한 달 판매의 ${Math.round(s.asks / s.n30)}배)</span>`);
      else P.push(`판매 입찰 ${N(s.asks)}건`);
      if (s.asks5) P.push(`등록 가격 +5% 안 ${N(s.asks5)}건`);
    }
    if (s.room != null) { const p = Math.round(s.room * 100); P.push(p < 5 ? `<span class="sr-warn">판매가 ${p}% 내려도 수익</span>` : `판매가 ${p}% 내려도 수익`); }
    const o = offersFor(r, s.size) - 1; if (o > 0) P.push(`외 ${o}`);
    return P.join(' · ');
  }
  function paintDet() {
    if (!PANEL) return;
    const { I } = PANEL, r = rowsOf(I).find(x => x.id === PANEL.id), D = detEl(); if (!r) return closeDet();
    const keepTop = (D.querySelector('.sr-db') || {}).scrollTop || 0;
    const C = calcOf(r), b = C.offer, main = C.sellers[0], ro = I.ro, fav = FAV.includes(r.id);
    const stk = s => s.stockKnown ? (s.stock >= 100 ? '100개+' : `${N(s.stock)}개`) : '있음';
    const eu = s => s.eu ? ` <small>(EU ${E(s.eu)})</small>` : '';
    // 1. 머리
    const headH = `<div class="sr-dh"><div class="sr-dht"><h2>${E(String(r.name || r.code || '').slice(0, 90))}</h2><button type="button" class="sr-x" data-srx aria-label="닫기" title="닫기 (Esc)">✕</button></div>
      <div class="sr-dhl">${r.brand ? `<span class="sr-s">${E(r.brand)} ·</span>` : ''}${r.code ? `<button type="button" class="sr-chip" data-srcopy="${E(r.code)}" title="품번 복사">${E(r.code)} ${IC.cp}</button>` : ''}
        ${pUrl(r) ? `<a class="sr-chip" href="${E(pUrl(r))}" target="_blank" rel="noopener"><i class="sr-dot poizon"></i>POIZON ↗</a>` : r.poizon ? '<span class="sr-chip off"><i class="sr-dot poizon"></i>POIZON</span>' : ''}
        ${kUrl(r) ? `<a class="sr-chip" href="${E(kUrl(r))}" target="_blank" rel="noopener"><i class="sr-dot kream"></i>KREAM ↗</a>` : ''}</div></div>`;
    // 2. 요약 카드
    const szs = C.rec.map(s => E(s.size)).join(' · ');
    const sum = `<div class="sr-sum">${r.img ? `<img class="sr-simg" src="${E(r.img)}" alt="">` : '<span class="sr-simg"></span>'}
      <div class="sr-sumc">${C.qty ? `<span class="sr-s">${szs} 사이즈 ${N(C.qty)}개를 사면</span>` : '<span class="sr-s">지금 기준으로는 권장 수량이 없어요</span>'}
        <div class="sr-big"><small>한 달</small> <b class="${C.monthly > 0 ? 'sr-ok' : ''}">${C.monthly ? SG(C.monthly) : '–'}</b></div>
        <span class="sr-s">개당 평균 ${SG(C.avg)} · 수익률 ${PC(C.rate)} · 매입액 ${W(C.buyAmt)}${main ? ` · 주로 ${SELL[main]}` : ''}</span></div>
      <div class="sr-sumr"><span class="sr-s">매입가</span><b>${W(C.buy)}</b><span>수익 한도 ${W(C.limit)}</span></div></div>`;
    // 3. 버튼 줄 6개
    const btns = `<div class="sr-btns">${b && b.url ? `<a class="primary" href="${E(b.url)}" target="_blank" rel="noopener">구매 ↗</a>` : '<button type="button" class="primary" disabled title="매입처 주소가 없어요">구매 ↗</button>'}
      <button type="button" class="ghost" data-srinv>매입 등록</button><button type="button" class="ghost${fav ? ' on' : ''}" data-srfav2 aria-pressed="${fav}">관심 상품</button>
      <button type="button" class="ghost" data-srreq${ro ? ' disabled title="지난 실행 결과는 다시 조회할 수 없어요 — 소싱 실행에서 조회해요"' : ''}>다시 조회</button>
      <button type="button" class="ghost" disabled title="준비 중이에요">대리 매입 요청 ›</button><button type="button" class="ghost" disabled title="준비 중이에요">공매도</button></div><p class="sr-msg" id="srDetMsg"></p>`;
    // 4. 구매 계획
    const rest = C.sizes.filter(s => !s.q), loss = rest.filter(s => s.best && s.best.profit <= 0).length, noT = rest.filter(s => !s.n30).length;
    const plan = `<section class="sr-sec"><div class="sr-sh"><b>구매 계획</b><i class="sr-qm" data-srtip="h:plan">?</i><span class="sr-s">수익 사이즈 ${C.rec.length}개</span></div>
      ${C.rec.length ? `<table class="sr-dt sr-plan"><thead><tr><th class="l">사이즈</th><th class="l">판매처</th><th>30일 판매</th><th>재고</th><th>권장</th><th>개당 수익<small>환급 포함</small></th><th>소계</th></tr></thead><tbody>
      ${C.rec.map(s => `<tr class="sr-p1"><td class="l"><b>${E(s.size)}</b>${eu(s)}</td><td class="l">${SELL[s.best.seller]}</td><td>${N(s.n30)}</td><td>${stk(s)}</td><td><b>${s.q}개</b></td><td class="sr-ok">${SG(s.best.profit)}</td><td class="sr-ok"><b>${SG(s.sub)}</b></td></tr>
        <tr class="sr-p2"><td class="l" colspan="7">${sizeNote(r, s)}</td></tr>`).join('')}
      <tr class="sr-ptot"><td class="l" colspan="4"><b>합계</b></td><td><b>${N(C.qty)}개</b></td><td><b>평균 ${SG(C.avg)}</b></td><td class="sr-ok"><b>${SG(C.monthly)}</b></td></tr></tbody></table>`
      : '<p class="sr-s">권장 수량이 있는 사이즈가 없어요 — 수익이 안 나거나 30일 판매가 적어요.</p>'}
      ${rest.length ? `<p class="sr-s">그 밖 사이즈 ${rest.length}개 — 손실 ${loss}${noT ? ` · 30일 거래 없음 ${noT}` : ''}</p>` : ''}
      <p class="sr-s">상품 전체(전 사이즈) 판매 추세 — ${C.trend} · 14일 ${N(C.n14All)} · 30일 ${N(C.n30All)}</p></section>`;
    // 5. 판매처 비교 (사이즈별 최대 수익 칸 테두리)
    const show = PANEL.all ? C.sizes : (C.rec.length ? C.rec : C.sizes.slice(0, 8));
    const bestCell = (s, seller, which) => s.best && s.best.seller === seller && (seller === 'poizon' || (FL.cur.instant ? which === 'inst' : which === 'bid'));
    const th = (t, k, cls = '') => `<th class="${cls}"><span class="sr-u" data-srtip="h:${k}">${t}</span></th>`;
    const pzRows = show.filter(s => s.per.poizon);
    const pz = pzRows.length ? `<div class="sr-sl"><i class="sr-dot poizon"></i><b>POIZON</b><span class="sr-s">${r.poizon && r.poizon.at ? mdhm(r.poizon.at) + ' 조회' : ''}</span></div>
      <table class="sr-dt sr-cmp"><thead><tr><th class="l">사이즈</th>${th('30일 판매', 'pz_n30')}${th('예상 판매가', 'pz_price')}${th('개당 수익', 'pz_profit')}${th('기준', 'pz_basis', 'l')}</tr></thead><tbody>
      ${pzRows.map(s => { const v = s.per.poizon, u = pUrl(r); return `<tr><td class="l"><b>${E(s.size)}</b></td><td>${lnk(u, N(v.n30), v.n30 ? '' : 'sr-warn')}</td><td>${lnk(u, W(v.price))}</td>
        <td class="${v.noTrade ? '' : v.profit > 0 ? 'sr-ok' : 'sr-neg'}${bestCell(s, 'poizon') && !v.noTrade ? ' sr-best' : ''}"><b>${v.noTrade ? '—' : SG(v.profit)}</b></td><td class="l ${v.noTrade ? 'sr-warn' : 'sr-s'}">${v.noTrade ? '거래 없음' : '노출가'}</td></tr>`; }).join('')}</tbody></table>` : '';
    const krRows = show.filter(s => s.per.kream), KS = (r.kream && r.kream.sizes) || {};
    const totAsks = Object.values(KS).reduce((t, k) => t + (+(k && k.asks) || 0), 0);
    const kr = krRows.length ? `<div class="sr-sl"><i class="sr-dot kream"></i><b>KREAM</b><span class="sr-s">판매 입찰 ${N(totAsks)}건</span><span class="sr-s">${r.kream && r.kream.at ? mdhm(r.kream.at) + ' 조회' : ''}</span></div>
      <table class="sr-dt sr-cmp"><thead><tr><th class="l">사이즈</th>${th('30일 판매', 'kr_n30')}${th('판매 입찰', 'kr_asks')}${th('즉시 판매가', 'kr_bid')}${th('즉시 수익', 'kr_inst')}${th('최저 판매가', 'kr_ask')}${th('입찰 시 수익', 'kr_bidp')}</tr></thead><tbody>
      ${krRows.map(s => { const v = s.per.kream, k = KS[s.size] || {}, u = kUrl(r);
        return `<tr><td class="l"><b>${E(s.size)}</b></td><td><b>${N(k.n30)}</b>${k.nFast30 != null ? `<small>(빠른 ${N(k.nFast30)})</small>` : ''}</td><td><span class="sr-2l">${N(k.asks)}건${k.asks5 != null ? `<small>+5% 안 ${N(k.asks5)}</small>` : ''}</span></td>
          <td>${k.bid ? lnk(u, W(k.bid)) : '—'}</td><td class="${v.inst ? (v.inst.profit > 0 ? 'sr-ok' : 'sr-neg') : ''}${bestCell(s, 'kream', 'inst') ? ' sr-best' : ''}"><b>${v.inst ? SG(v.inst.profit) : '—'}</b></td>
          <td>${k.ask ? `<span class="sr-2l">${lnk(u, W(k.ask))}<small>체결가 상한</small></span>` : '—'}</td><td class="${v.bidP ? (v.bidP.profit > 0 ? 'sr-ok' : 'sr-neg') : ''}${bestCell(s, 'kream', 'bid') ? ' sr-best' : ''}"><b>${v.bidP ? SG(v.bidP.profit) : '—'}</b></td></tr>`; }).join('')}</tbody></table>` : '';
    const cmp = `<section class="sr-sec"><div class="sr-sh"><b>판매처 비교</b><span class="sr-s">값을 누르면 해당 판매처 화면 · 초록 테두리는 사이즈별 수익이 가장 큰 판매처</span></div>
      ${pz + kr || '<p class="sr-s">판매처 시세가 아직 없어요</p>'}
      ${C.sizes.length > show.length || PANEL.all ? `<button type="button" class="sr-sm" data-srall>${PANEL.all ? '권장 사이즈만' : `모든 사이즈 ${C.sizes.length}개`}</button>` : ''}</section>`;
    // 6. 매입가 접기/펼치기 (18번)
    const vatOn = CALC.vatRefund !== false;
    const offs = (r.buy || []).map((o, i) => ({ o, i })).filter(x => x.o && x.o.price > 0).sort((x, y) => (x.o === b ? -1 : y.o === b ? 1 : 0));
    const offH = offs.map(({ o, i }) => {
      const d = sdBuy(disc(), o.site, o.price, o), mine = disc().sites[o.site], on = o.on !== false;
      return `<div class="sr-off">${offs.length > 1 ? `<div class="sr-offh"><b>${E(o.label || o.site)}</b> ${W(d.final)}${on ? '' : ' <span class="sr-s sr-neg">실행에서 뺌</span>'}</div>` : ''}
        <p>정가 ${(o.list || o.price) > d.final ? `<s>${W(o.list || o.price)}</s>` : W(o.list || o.price)}${(o.list || o.price) !== d.tag ? ` · 판매가 ${W(d.tag)}` : ''}</p>
        ${d.steps.filter(t => t.amt).map(t => `<p>${E(t.label)} −${W(t.amt)}</p>`).join('')}
        ${vatOn ? `<p>부가세 환급 ${W(srcVat(d.final))} — POIZON(해외)에 판매하면 환급받는 금액 · POIZON 수익에 더했어요</p>` : ''}
        <p>재고 확인 ${o.stockAt ? hm(o.stockAt) : '–'}</p>
        <div class="sr-offr"><span class="sr-s">이 매입처</span><button type="button" class="sr-sm${mine && mine.own ? ' on' : ''}" data-srmdlg="${E(o.site)}"${ro ? ' disabled' : ''} title="${mine && mine.own ? `내 등급 ${E(mine.gname || '')} · 할인 고치기` : '이 매입처 내 등급 · 할인 넣기'}">내 할인</button>
          <button type="button" class="sr-sm sr-tog${on ? ' on' : ''}" data-sron2="${i}" aria-pressed="${on}"${ro ? ' disabled' : ''}><i></i>실행에 포함</button>
          ${o.url ? `<a class="sr-s" href="${E(o.url)}" target="_blank" rel="noopener">상품 페이지 ↗</a>` : ''}</div></div>`;
    }).join('');
    const buyS = `<section class="sr-sec sr-fold${PANEL.fold.buy ? ' on' : ''}"><button type="button" class="sr-fh" data-srfold="buy" aria-expanded="${PANEL.fold.buy}"><i class="sr-chev"></i><b class="sr-acc">매입가 ${W(C.buy)}</b><span class="sr-s">할인 · 쿠폰 · 재고 확인 · 이 매입처</span></button>
      <div class="sr-fbd">${offH || '<p class="sr-s">매입처가 없어요</p>'}</div></section>`;
    // 7. 시세 차트 (17·19번)
    const chartS = `<section class="sr-sec sr-fold${PANEL.fold.chart ? ' on' : ''}"><button type="button" class="sr-fh" data-srfold="chart" aria-expanded="${PANEL.fold.chart}"><i class="sr-chev"></i><b>시세 차트</b><span class="sr-s">KREAM · POIZON — 오피스와 같은 차트</span></button>
      <div class="sr-fbd">${noneLines(r, C)}${chartBox(r, 'poizon')}${chartBox(r, 'kream')}${!r.poizon && !r.kream ? '<p class="sr-s">시세 기록이 없어요</p>' : ''}</div></section>`;
    D.innerHTML = headH + `<div class="sr-db">${sum}${btns}${plan}${cmp}${buyS}${chartS}</div>`;
    D.querySelector('.sr-db').scrollTop = keepTop;
  }
  // 거래 없는 사이즈 요약 줄 (17번 위)
  // 실행 중 빈 탭 안내 — 수익 상품은 KREAM · POIZON 시세를 조회한 뒤에 나와요
  function runWait(run, tab) {
    const c = (run && run.counts) || {}, n = v => (+v || 0).toLocaleString('ko-KR'), all = tab === 'all' ? '' : ` 수집한 상품 ${n(c.items)}개는 [전체] 탭에서 볼 수 있어요.`;
    return run && run.kind === 'collect' ? `매입처 상품을 수집하는 중이에요.${all}`
      : `${run && run.stage === 'quote' ? '시세 조회 중이에요' : '매입처 상품을 수집하면서 바로 시세를 조회하고 있어요'} (${n(c.quoted)} / ${n(c.quoteTotal || c.items)} 품번) — 수익 상품이 나오는 대로 여기에 바로 표시돼요.${all}`;
  }
  function noneLines(r, C) {
    const KS = (r.kream && r.kream.sizes) || {};
    const sk = r.kream && r.kream.skip ? `<p>${E(r.kream.skip)}</p>` : '';
    const L = C.sizes.filter(s => s.per.kream && !s.n30).slice(0, 3).map(s => {
      const k = KS[s.size] || {}, lt = (k.trades || []).slice().sort((a, b) => String(b.d).localeCompare(String(a.d)))[0];
      const ago = k.last ? Math.round((Date.now() - new Date(k.last).getTime()) / 864e5) : null;
      const pf = lt && s.buy != null ? srcSell('kream', lt.p, s.buy, env(), false) : null;
      return `${E(s.size)} 30일 거래 없음 · ${ago == null ? '판매 기록 없음' : ago > 30 ? `최근 판매 없음(마지막 ${ago}일 전)` : `마지막 판매 ${ago}일 전${k.n90 ? `(90일 ${N(k.n90)}개)` : ''}`}${lt ? ` · 지난 거래가 ${W(lt.p)} 기준 ${pf ? SG(pf.profit) : '(매입처 재고 없음)'}` : ''}`;
    });
    return L.length || sk ? `<div class="sr-none">${sk}${L.map(x => `<p>${x}</p>`).join('')}</div>` : '';
  }
  // ---- 시세 차트 ----
  const PERS = [[7, '1주'], [30, '1개월'], [90, '3개월'], [180, '6개월'], [365, '1년']];
  const perL = d => (PERS.find(p => p[0] === d) || [0, ''])[1];
  const tTime = d => { const t = new Date(String(d).length <= 10 ? d + 'T00:00:00' : d).getTime(); return isNaN(t) ? 0 : t; };
  const tLabel = d => { const s = String(d), m = s.match(/^\d{4}-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}))?/); if (!m) return E(s); const ms = Date.now() - tTime(d), h = Math.floor(ms / 36e5), dd = Math.floor(ms / 864e5);
    return `${m[1]}.${m[2]}${m[3] ? ` ${m[3]}:${m[4]}` : ''} · ${m[3] && h < 24 ? (h < 1 ? '방금' : `${h}시간 전`) : dd <= 0 ? '오늘' : `${dd}일 전`}`; };
  const agoTxt = t => { const ms = Date.now() - t, h = Math.floor(ms / 36e5); return h < 1 ? '방금' : h < 24 ? `${h}시간 전` : `${Math.floor(h / 24)}일 전`; };
  const man = v => { const x = v / 10000; return (x >= 10 ? Math.round(x) : Math.round(x * 10) / 10) + '만'; };
  // 점들을 부드러운 곡선으로 (Catmull-Rom → 베지어)
  function smooth(P) {
    if (P.length < 2) return P.length ? `M${P[0][0]},${P[0][1]}` : '';
    let d = `M${P[0][0].toFixed(1)},${P[0][1].toFixed(1)}`;
    for (let i = 0; i < P.length - 1; i++) {
      const p0 = P[i - 1] || P[i], p1 = P[i], p2 = P[i + 1], p3 = P[i + 2] || p2;
      d += ` C${(p1[0] + (p2[0] - p0[0]) / 6).toFixed(1)},${(p1[1] + (p2[1] - p0[1]) / 6).toFixed(1)} ${(p2[0] - (p3[0] - p1[0]) / 6).toFixed(1)},${(p2[1] - (p3[1] - p1[1]) / 6).toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
    }
    return d;
  }
  function chartBox(r, sl) {
    const src = r[sl]; if (!src) return '';
    const st = PANEL.ch[sl], sizes = Object.keys(src.sizes || {}).sort((a, b) => (parseFloat(a) - parseFloat(b)) || String(a).localeCompare(String(b)));
    const from = Date.now() - st.per * 864e5;
    const all = Object.entries(src.sizes || {}).flatMap(([s, v]) => ((v && v.trades) || []).map(t => ({ ...t, size: t.size || s })));
    const tr = all.filter(t => (!st.size || String(t.size) === st.size) && tTime(t.d) >= from).sort((a, b) => tTime(b.d) - tTime(a.d));
    const pl = perL(st.per);
    const headH = `<div class="sr-cct"><i class="sr-dot ${sl}"></i><b>${SELL[sl]} 시세 차트</b></div>
      <div class="sr-ccr"><span class="sr-s">조회 기간</span>${PERS.map(([d, l]) => `<button type="button" class="sr-pchip ${sl}" data-srper="${sl}:${d}" aria-pressed="${st.per === d}">${l}</button>`).join('')}</div>
      <div class="sr-ccr"><span class="sr-s">사이즈</span><select class="sr-ssel" data-srsz="${sl}" aria-label="${SELL[sl]} 차트 사이즈"><option value="">전체</option>${sizes.map(s => `<option value="${E(s)}"${st.size === s ? ' selected' : ''}>${E(s)}</option>`).join('')}</select>
        ${sl === 'kream' ? `<button type="button" class="sr-pchip${MYSZ && st.size === MYSZ ? ' on' : ''}" data-srmy="${sl}" title="${MYSZ ? `내 사이즈 ${E(MYSZ)}만 보기` : '사이즈를 고른 뒤 누르면 내 사이즈로 기억해요'}">내 사이즈${MYSZ ? ` ${E(MYSZ)}${srcEu(MYSZ) ? ` <small>(EU ${srcEu(MYSZ)})</small>` : ''}` : ''}</button>` : ''}</div>`;
    const foot = sl === 'poizon' ? `<p class="sr-s sr-cnote">POIZON 판매자 센터의 거래 추이(전 세계 평균 거래가)${src.at ? ` · ${agoTxt(src.at)} 갱신` : ''} — 판정에 쓰는 중국 노출가와 다른 값이에요</p>` : '';
    if (!tr.length) return `<div class="sr-cc">${headH}<p class="sr-s">이 기간에 거래 기록이 없어요</p>${foot}</div>`;
    const ps = tr.map(t => t.p), avg = ps.reduce((a, b) => a + b, 0) / ps.length;
    const card = (l, v, cls) => `<div class="sr-ck"><span>${l}</span><b class="${cls}">${v}</b></div>`;
    const lastD = String(tr[0].d).match(/^\d{4}-(\d{2})-(\d{2})/);
    const cards = `<div class="sr-cks">${card(`${pl} 평균`, W(avg), 'sr-ok')}${card(`${pl} 최저`, W(Math.min(...ps)), 'sr-blue')}${card(`${pl} 최고`, W(Math.max(...ps)), 'sr-neg')}${card(`마지막 거래${lastD ? ` ${+lastD[1]}/${+lastD[2]}` : ''}`, W(tr[0].p), '')}${card(`${pl} ${sl === 'kream' ? '거래' : '판매량'}`, `${N(tr.length)}건`, 'sr-warn')}</div>`;
    // 날짜별 평균가 · 건수
    const byD = new Map(); for (const t of tr) { const k = String(t.d).slice(0, 10), o = byD.get(k) || { n: 0, s: 0 }; o.n++; o.s += t.p; byD.set(k, o); }
    const days = [...byD.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([d, o]) => ({ d, n: o.n, p: o.s / o.n }));
    const Wd = 640, H = 210, L0 = 42, R0 = 26, T0 = 10, B0 = 24, iw = Wd - L0 - R0, ih = H - T0 - B0;
    let mx = Math.max(...days.map(x => x.p)), mn = Math.min(...days.map(x => x.p)); if (mx === mn) { mx *= 1.05; mn *= 0.95; }
    const padv = (mx - mn) * 0.08; mx += padv; mn = Math.max(0, mn - padv);
    const nx = Math.max(...days.map(x => x.n)), cmax = Math.max(4, Math.ceil(nx / 4) * 4);
    const t0 = from, t1 = Date.now(), X = d => L0 + (tTime(d) - t0) / (t1 - t0) * iw, Y = p => T0 + (1 - (p - mn) / (mx - mn)) * ih;
    const bw = Math.max(2, Math.min(14, iw / (st.per + 1) * 0.7));
    const P = days.map(x => [X(x.d), Y(x.p)]);
    const yT = [0, 1, 2, 3].map(i => mn + (mx - mn) * i / 3), cT = [0, 1, 2, 3, 4].map(i => cmax * i / 4);
    const xT = Array.from({ length: 7 }, (_, i) => t0 + (t1 - t0) * (i + 0.5) / 7);
    const col = sl === 'kream' ? 'var(--sr-kr)' : 'var(--sr-pz)';
    const svg = `<svg class="sr-chart" viewBox="0 0 ${Wd} ${H}" role="img" aria-label="${SELL[sl]} 시세 차트 — 가격선과 판매량 막대">
      <defs><linearGradient id="srg-${sl}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".28"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>
      ${yT.map(v => `<line x1="${L0}" x2="${Wd - R0}" y1="${Y(v)}" y2="${Y(v)}" class="sr-grid"/><text x="${L0 - 6}" y="${Y(v) + 4}" text-anchor="end" class="sr-ax">${man(v)}</text>`).join('')}
      ${cT.map(v => `<text x="${Wd - R0 + 6}" y="${T0 + ih - v / cmax * ih + 4}" class="sr-ax sr-axr">${Math.round(v)}</text>`).join('')}
      ${xT.map(t => { const d = new Date(t); return `<text x="${L0 + (t - t0) / (t1 - t0) * iw}" y="${H - 6}" text-anchor="middle" class="sr-ax">${d.getMonth() + 1}/${d.getDate()}</text>`; }).join('')}
      ${days.map(x => `<rect x="${(X(x.d) - bw / 2).toFixed(1)}" y="${(T0 + ih - x.n / cmax * ih).toFixed(1)}" width="${bw.toFixed(1)}" height="${(x.n / cmax * ih).toFixed(1)}" class="sr-vb"/>`).join('')}
      ${P.length > 1 ? `<path d="${smooth(P)} L${P[P.length - 1][0].toFixed(1)},${T0 + ih} L${P[0][0].toFixed(1)},${T0 + ih} Z" fill="url(#srg-${sl})"/>` : ''}
      <path d="${smooth(P)}" fill="none" stroke="${col}" stroke-width="2"/>${P.length === 1 ? `<circle cx="${P[0][0]}" cy="${P[0][1]}" r="3" fill="${col}"/>` : ''}
      ${days.map((x, i) => { const w = Math.max(6, iw / Math.max(days.length, 1)); return `<rect x="${(P[i][0] - w / 2).toFixed(1)}" y="${T0}" width="${w.toFixed(1)}" height="${ih}" fill="transparent" data-srtipt="${x.d.slice(5).replace('-', '/')} · 평균 ${W(x.p)} · ${sl === 'kream' ? '거래' : '판매량'} ${x.n}건"/>`; }).join('')}</svg>`;
    const n = PANEL.trn[sl], rest = tr.length - n;
    const list = tr.slice(0, n).map(t => `<div class="sr-trr"><span>${E(t.size)}${srcEu(t.size) ? ` <small>(EU ${srcEu(t.size)})</small>` : ''}</span><b>${W(t.p)}</b><span class="sr-s">${tLabel(t.d)}</span></div>`).join('');
    return `<div class="sr-cc">${headH}${cards}${svg}
      <div class="sr-trh"><b>최근 거래 · 팔린 값</b><span class="sr-s">${N(tr.length)}건</span><span class="sr-sp"></span>${rest > 0 ? `<button type="button" class="linkbtn sr-acc" data-srtrmore="${sl}">더 보기 (${N(Math.min(rest, 20))}건)</button>` : ''}</div>
      <div class="sr-trl">${list}</div>${foot}</div>`;
  }
  async function drwClick(e) {
    if (!PANEL) return;
    const r = rowsOf(PANEL.I).find(x => x.id === PANEL.id), ro = PANEL.I.ro;
    if (e.target.closest('[data-srx]')) return closeDet();
    const cp = e.target.closest('[data-srcopy]'); if (cp) { try { await navigator.clipboard.writeText(cp.dataset.srcopy); cp.classList.add('on'); cp.title = '복사했어요'; setTimeout(() => cp.classList.remove('on'), 1200); } catch (er) {} return; }
    if (e.target.closest('[data-srall]')) { PANEL.all = !PANEL.all; return paintDet(); }
    const fo = e.target.closest('[data-srfold]'); if (fo) { const k = fo.dataset.srfold; PANEL.fold[k] = !PANEL.fold[k]; return paintDet(); }
    const tm = e.target.closest('[data-srtrmore]'); if (tm) { PANEL.trn[tm.dataset.srtrmore] += 20; return paintDet(); }
    const pr = e.target.closest('[data-srper]'); if (pr) { const [sl, d] = pr.dataset.srper.split(':'); PANEL.ch[sl].per = +d; return paintDet(); }
    const my = e.target.closest('[data-srmy]'); if (my) { const sl = my.dataset.srmy; if (MYSZ && PANEL.ch[sl].size !== MYSZ) PANEL.ch[sl].size = MYSZ; else if (PANEL.ch[sl].size) { MYSZ = PANEL.ch[sl].size; await store.set('srcMySize', MYSZ); } else if (MYSZ) PANEL.ch[sl].size = ''; return paintDet(); }
    const md = e.target.closest('[data-srmdlg]'); if (md) return ro ? null : mineDlg(md.dataset.srmdlg);
    if (!r) return;
    const o2 = e.target.closest('[data-sron2]');
    if (o2) { if (ro || !PANEL.I.live) return; const bb = r.buy[+o2.dataset.sron2]; if (bb) { bb.on = bb.on === false; r.at = Date.now(); await saveRows([r.id]); paintAll(); } return; }
    if (e.target.closest('[data-srfav2]')) { await toggleFav(r.id); return; }
    if (e.target.closest('[data-srreq]')) { if (ro) return; requote([r.id]); document.getElementById('srDetMsg').textContent = '다시 조회를 요청했어요 — 끝나면 표가 바뀌어요'; return; }
    if (e.target.closest('[data-srinv]')) return toInv(r, calcOf(r));
  }
  function drwChange(e) {
    const sz = e.target.closest('[data-srsz]'); if (sz && PANEL) { PANEL.ch[sz.dataset.srsz].size = sz.value; paintDet(); }
  }
  // 매입 등록: 재고관리 입고 화면에 권장 사이즈·수량·할인 반영 매입가를 넣어 둬요 (완료는 사용자가 눌러요)
  async function toInv(r, C) {
    const msg = t => { const m = document.getElementById('srDetMsg'); if (m) m.textContent = t; };
    if (typeof INV === 'undefined' || typeof ioAddRow !== 'function') { msg('재고관리를 아직 못 불러왔어요. 잠시 뒤 다시 눌러 주세요.'); return; }
    const ck = codeKey(r.code);
    let item = (ck && INV.items.find(x => codeKey(x.code) === ck)) || INV.items.find(x => x.pid && r.pid && String(x.pid) === String(r.pid));
    if (!item) {
      const shoe = /신발|shoe/i.test(r.cat || ''), wear = /의류|아우터|상의|하의|wear/i.test(r.cat || '');
      const sizes = C.sizes.length ? C.sizes.map(s => s.size) : (shoe ? SIZE_PRESETS['공용 신발 220~300'] : wear ? SIZE_PRESETS['의류 XS~XXL'] : SIZE_PRESETS.FREE);
      const it = saveItemFrom({ code: r.code || String(r.pid || r.id), name: r.name || '', brand: r.brand || '', cat: shoe ? '신발' : wear ? '의류' : '', sub: '', sizes: sizes.join(', '), memo: '소싱에서 추가', pid: String(r.pid || '') }, null);
      if (typeof it === 'string') { msg(it); return; }
      item = it; await invSave();
    }
    IS.io.mode = 'in';
    const pk = C.rec.length ? C.rec : [{ size: '', q: 1, buy: C.buy, offer: C.offer }];
    for (const s of pk) {
      const size = s.size && (item.sizes || []).map(String).includes(String(s.size)) ? String(s.size) : '';
      ioAddRow(item, size);
      const row = IS.io.rows.filter(x => x.itemId === item.id).pop();
      if (row) { row.qty = s.q || 1; if (s.buy != null) row.price = String(s.buy); if (!row.memo) row.memo = `소싱 · ${(s.offer && (s.offer.label || s.offer.site)) || ''}`; }
    }
    if (C.offer) { const pt = ioPartners('in').find(p => String(p.name || '').replace(/\s/g, '') === String(C.offer.label || '').replace(/\s/g, '')); if (pt) IS.io.partnerId = pt.id; }
    IS.io.msg = `${itName(item)} — 사이즈·수량·거래처를 확인하고 '입고 등록 완료'를 눌러 주세요`;
    saveDraft(); closeDet(); route('inv:io');
  }

  // ---------- 내 할인 (상세 › 매입가 › 이 매입처 [내 할인]) — srcCalc.disc 구조 그대로 ----------
  function mineDlg(k) {
    let d = document.getElementById('srDlg'); if (!d) { d = document.createElement('dialog'); d.id = 'srDlg'; d.className = 'invdlg'; document.body.appendChild(d); }
    const D0 = disc();
    const keys = [...new Set([...LROWS.flatMap(r => (r.buy || []).map(b => b.site)), ...Object.keys(D0.sites)])].filter(Boolean);
    const label = s => { for (const r of LROWS) for (const b of (r.buy || [])) if (b.site === s && b.label) return b.label; return s; };
    const c = k ? (D0.sites[k] || {}) : D0.def, v = (s, f) => c[s] && c[s][f] ? c[s][f] : '';
    d.innerHTML = `<form method="dialog" class="dlg"><h3>내 할인</h3><div class="dlg-body dgrid">
      <label>매입처<select name="site"><option value="">모든 매입처 (기본)</option>${keys.map(x => `<option value="${E(x)}"${x === k ? ' selected' : ''}>${E(label(x))}${D0.sites[x] && D0.sites[x].own ? ' · 내 할인 있음' : ''}</option>`).join('')}</select></label>
      ${k ? `<label>내 등급<input name="gname" value="${E(c.gname || '')}" placeholder="예: 골드"></label>` : '<p class="dl-sub" style="margin:0">매입처별로 따로 넣지 않은 곳은 이 기본값을 써요</p>'}
      ${SD_STEPS.map(([s, l], i) => `<div class="wide" style="display:grid;grid-template-columns:150px repeat(4,minmax(0,1fr));gap:6px;align-items:center"><b class="small">${i + 1}. ${l}</b>
        <label class="dl-num"><input name="${s}.pct" inputmode="decimal" value="${v(s, 'pct')}" placeholder="0"><span>%</span></label>
        <label class="dl-num"><input name="${s}.won" inputmode="numeric" value="${v(s, 'won')}" placeholder="0"><span>원</span></label>
        <label class="dl-num"><input name="${s}.cap" inputmode="numeric" value="${v(s, 'cap')}" placeholder="최대"><span>원</span></label>
        <label class="dl-num"><input name="${s}.min" inputmode="numeric" value="${v(s, 'min')}" placeholder="최소 주문"><span>원</span></label></div>`).join('')}
      <p class="dl-sub wide" style="margin:0">위에서부터 차례로 빼요. %는 앞 단계까지 깎인 값에 매겨요 · 최대는 그 할인의 한도, 최소 주문은 이 금액보다 싸면 그 할인을 안 넣어요. 할인 종류 켜고 끄기는 설정 › 수익 계산에 있어요.</p></div>
      <div class="row-btns end">${k && D0.sites[k] ? '<button type="button" class="ghost" id="srMineDel">이 매입처 내 할인 지우기</button>' : ''}<button value="cancel" class="ghost" formnovalidate>닫기</button><button value="ok" class="primary">저장</button></div></form>`;
    const f = d.querySelector('form');
    f.querySelector('[name=site]').addEventListener('change', e => mineDlg(e.target.value));
    const del = f.querySelector('#srMineDel'); if (del) del.addEventListener('click', async () => { delete D0.sites[k]; await saveCalc(); d.close(); paintAll(); });
    f.addEventListener('submit', async e => {
      if (e.submitter && e.submitter.value === 'cancel') return;
      e.preventDefault();
      const fd = Object.fromEntries(new FormData(f)), o = {};
      for (const [s] of SD_STEPS) { const x = {}; for (const t of ['pct', 'won', 'cap', 'min']) { const n = +String(fd[`${s}.${t}`] || '').replace(/[^\d.]/g, ''); if (n > 0) x[t] = t === 'pct' ? Math.min(100, n) : Math.round(n); } if (Object.keys(x).length) o[s] = x; }
      if (k) D0.sites[k] = { ...o, own: true, gname: String(fd.gname || '').trim().slice(0, 20), off: !!(D0.sites[k] && D0.sites[k].off) }; else D0.def = o;
      await saveCalc(); d.close(); paintAll();
    });
    if (!d.open) d.showModal();
  }

  // ---------- 바깥에서 부르는 곳 ----------
  // renderSrcResult() · renderSrcResult(false: 다시 읽지 않고 그리기) · renderSrcResult({ mount, rows, run, readonly })
  window.renderSrcResult = async function (a) {
    if (a && typeof a === 'object') {
      const host = typeof a.mount === 'string' ? document.querySelector(a.mount) : a.mount || document.getElementById('srcResult');
      if (!host) return;
      const I = inst(host, a);
      if (I.live || a.reload !== false) { if (I.live) await load(); else { CALC = (await store.get('srcCalc', {})) || CALC; ver++; } }
      if (PANEL && PANEL.I === I && !rowsOf(I).some(r => r.id === PANEL.id)) closeDet();
      paint(I); if (PANEL && PANEL.I === I) paintDet();
      return;
    }
    if (a !== false) await load();
    const host = document.getElementById('srcResult'); if (host) inst(host, null);
    paintAll();
  };
  window.addEventListener('src:calc', async () => { CALC = (await store.get('srcCalc', {})) || {}; ver++; paintAll(); });   // 설정 › 수익 계산이 바뀌면
  let tmr = null;
  window.addEventListener('src:rows', e => { if (e.detail && e.detail.from === 'res') return; clearTimeout(tmr); tmr = setTimeout(() => renderSrcResult(), 300); });
  (async () => {
    try { const f = await store.get('srcFilt', null); if (f) FL = { cur: f.cur || {}, saved: f.saved || [], seeded: !!f.seeded || !!(f.saved && f.saved.length) }; } catch (e) {}
    if (!FL.seeded) { FL.saved = PRESETS.map(([name, f]) => ({ name, f })); FL.seeded = true; try { await saveFL(); } catch (e) {} }
    try { FAV = (await store.get('srcFav', [])) || []; MYSZ = (await store.get('srcMySize', '')) || ''; } catch (e) {}
    if (document.getElementById('srcResult')) renderSrcResult();
  })();
})();
