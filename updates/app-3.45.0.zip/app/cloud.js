/* 킥스캔 — PC ⇄ 서버 ⇄ 폰 동기화 (지시서 C-3 · docs/supabase/sync-setup.sql 의 ks_doc)
   - 재고를 저장하면(invSave) 바뀐 문서만 30초 안에 서버로 올려요: 상품 · 입고(남은 수량 포함) · 판매 · 거래처 · 결제수단(이름 · 카드사 · 끝 4자리만) · 지출 · 발송 · PC 신호
   - 30초마다 폰에서 온 것을 받아요: 폰 매입 등록(phone_buy → 입고로 넣고 done) · 바코드 연결 · 시세 조회 요청(job → 이 PC 가 KREAM 을 조회해서 결과)
   - 인터넷이 끊기면 그대로 로컬로 일하고, 다음 주기에 밀린 것을 올려요. 서버 표가 아직 없으면 '서버 준비 전'으로 두고 30분마다 다시 봐요.
   - [서버로 옮기기]: 로컬 백업을 남기고 전부 올린 뒤 종류별 건수를 비교해요.
   - ★ 판매처 · 쇼핑몰 아이디 · 비밀번호(acctData)는 절대 올리지 않아요 — INV 에 없어요.
   저장: 'cloudSt' = { on, hashes:{kind:id → hash}, pullAt(ISO), pushAt, pullOkAt, err, notReady, moved } */
const CLD = { busy: false, dirty: true, st: null, msg: '' };
const CL_KINDS_PULL = ['phone_buy', 'barcode', 'job', 'store_day'];
function clHash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return h.toString(36) + ':' + s.length; }
async function clSave() { try { const A = CLD.st.applied; if (A) { const k = Object.keys(A); if (k.length > 2000) for (const x of k.slice(0, k.length - 2000)) delete A[x]; } await store.set('cloudSt', CLD.st); } catch (e) {} }
const clOn = () => !!(window.kcApp && window.kcApp.lic && window.kcApp.lic.share) && !(CLD.st && CLD.st.on === false);
async function clRpc(fn, args) {
  const r = await window.kcApp.lic.share(fn, args || {});
  if (r && r.ok) return r.data;
  if (r && r.skip) throw Object.assign(new Error(r.skip === 'login' ? '킥스캔 계정에 로그인해 주세요' : '쓸 수 없는 서버 기능이에요'), { skip: r.skip });
  const t = (r && r.err) || '';
  if (r && (r.status === 404 || /PGRST202|PGRST205|42P01|42883|Could not find/.test(t))) throw Object.assign(new Error('서버 준비 전이에요 — 동기화 표(sync-setup.sql)를 먼저 만들어야 해요'), { notReady: true });
  throw new Error((r && r.err) || '서버에 연결하지 못했어요');
}
// 지금 PC 데이터 → 서버 문서 목록
function clDocs() {
  if (typeof INV === 'undefined') return [];
  const C = invCalc(), D = [];
  const put = (kind, id, data) => D.push({ kind, id: String(id), data });
  for (const it of INV.items) put('item', it.id, { code: it.code || '', name: it.name || '', brand: it.brand || '', cat: it.cat || '', sizes: it.sizes || [], barcodes: it.barcodes || {}, img: it.img || '' });
  for (const l of INV.lots) put('lot', l.id, { itemId: l.itemId, size: l.size, qty: l.qty, cost: l.cost, date: l.date, partnerId: l.partnerId || '', returnDue: l.returnDue || '', src: l.src || '', left: C.left.get(l.id) || 0, memo: String(l.memo || '').slice(0, 80) });
  for (const o of INV.outs) put('out', o.id, { itemId: o.itemId, size: o.size, qty: o.qty, price: o.price || 0, fee: o.fee ?? '', date: o.date, settleDate: o.settleDate || '', partnerId: o.partnerId || '', kind: o.kind || 'out', settled: !!o.settled, retQty: o.retQty || 0, costs: (o.costs || []).map(c => ({ lotId: c.lotId, qty: c.qty, cost: c.cost })) });
  for (const p of INV.partners) put('partner', p.id, { name: p.name, kind: p.kind, tax: p.tax || '', store: !!p.store, returnDays: p.returnDays ?? null, lastDisc: p.lastDisc ?? null });
  for (const p of INV.pays || []) put('pay', p.id, { type: p.type || '', name: p.name || '', issuer: p.issuer || '', last4: String(p.last4 || '').slice(-4) });
  for (const x of INV.expenses || []) put('expense', x.id, { date: x.date, cat: x.cat, amount: x.amount, memo: String(x.memo || '').slice(0, 80) });
  // 공매도 입찰(일반 판매 › 공매도): 폰 홈 '매입할 공매도 N개'
  try { const sold = new Set(Object.values((typeof kSales !== 'undefined' && kSales.unrec) || {}).map(u => codeKey(u.code) + '|' + String(u.size))); for (const a of (typeof abList !== 'undefined' ? abList : []).filter(x => x.short)) put('short', a.key, { code: a.code || '', name: a.name || '', size: a.size, price: +a.price || 0, from: a.short.from || '', cost: a.short.cost || 0, at: a.short.at || 0, status: !a.gone ? '입찰 중' : sold.has(codeKey(a.code) + '|' + String(a.size)) ? '매입 필요' : '내린 입찰' }); } catch (e) {}
  for (const s of INV.ships || []) put('ship', s.id, { date: s.date, courier: s.courier, no: s.no, cost: s.cost || 0, n: s.n || (s.ids || []).length, storage: !!s.storage });
  return D;
}
function clPcDoc() {
  const S0 = typeof S !== 'undefined' ? S : {};
  return { kind: 'pc', id: 'main', data: { at: Date.now(), ver: (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return ''; } })(), fee: { rate: +S0.rate || 6, base: +S0.base || 2500, max: +S0.max || 300000, ship: +S0.ship || 0 }, pz: typeof DO !== 'undefined' && DO.pz ? DO.pz : null } };
}
async function clPush(all) {
  const st = CLD.st, now = new Date().toISOString(), docs = clDocs(), cur = {};
  const out = [];
  for (const d of docs) { const k = d.kind + ':' + d.id, h = clHash(JSON.stringify(d.data)); cur[k] = h; if (all || st.hashes[k] !== h) out.push({ ...d, by: 'pc', at: now }); }
  for (const k of Object.keys(st.hashes)) if (!(k in cur)) { const [kind, ...r] = k.split(':'); out.push({ kind, id: r.join(':'), data: {}, deleted: true, by: 'pc', at: now }); }
  out.push({ ...clPcDoc(), by: 'pc', at: now });
  let n = 0;
  for (let i = 0; i < out.length; i += 200) { n += +(await clRpc('ks_doc_put', { p_docs: out.slice(i, i + 200) })) || 0; }
  st.hashes = cur; st.pushAt = Date.now(); CLD.dirty = false;
  return { sent: out.length, n };
}
// 폰에서 온 것 반영
async function clApply(rows) {
  let changed = false, buys = 0; const done = [];
  for (const r of rows) {
    if (r.deleted) continue;
    const d = r.data || {};
    if (r.kind === 'phone_buy' && !d.done && (CLD.st.applied || {})[r.id]) { done.push({ ...r, data: { ...d, done: true, lotId: CLD.st.applied[r.id] } }); continue; }
    if (r.kind === 'phone_buy' && !d.done) {
      const code = String(d.code || '').trim(); if (!code || !d.size || !(+d.cost > 0)) { done.push({ ...r, data: { ...d, done: true, why: '품번 · 사이즈 · 매입가가 비었어요' } }); continue; }
      let it = INV.items.find(x => String(x.code || '').split('/').some(c => codeKey(c) === codeKey(code)));
      if (!it) { it = { id: uid(), code: code.toUpperCase(), name: d.name || code, brand: d.brand || '', cat: '', sub: '', sizes: [], barcodes: {}, memo: '폰에서 추가', created: Date.now() }; INV.items.unshift(it); }
      else { if (!it.brand && d.brand) it.brand = d.brand; if ((!it.name || it.name === it.code) && d.name) it.name = d.name; }   // 폰이 아는 브랜드 · 상품명으로 채워요(반품 기한 브랜드 규칙)
      let p = d.storeId ? partnerOf(d.storeId) : null;
      if (!p && d.store) { p = INV.partners.find(x => x.name === d.store); if (!p) { p = { id: uid(), kind: 'buy', name: d.store, biz: '', tax: '과세', store: true, returnDays: null }; INV.partners.push(p); } }
      if (p && d.disc != null) p.lastDisc = +d.disc;
      const date = d.date || today(), pay = d.payId ? payOf(d.payId) : null;
      const l = { id: uid(), at: Date.now(), date, itemId: it.id, size: String(d.size), qty: Math.max(1, +d.qty || 1), cost: +d.cost, partnerId: p ? p.id : '', payId: pay ? pay.id : '', memo: `${d.via === 'receipt' ? '폰 영수증' : '폰 매입'}${d.tag ? ` · 태그가 ${won(d.tag)}` : ''}${d.disc ? ` · 할인 ${d.disc}%` : ''}`, src: 'phone', returnDue: d.wh ? '' : addDays(date, typeof retDaysOf === 'function' ? retDaysOf(p, it) : 14), retQty: 0, exQty: 0, events: [] };
      if (d.barcode) { it.barcodes = it.barcodes || {}; it.barcodes[String(d.size)] = String(d.barcode); }
      INV.lots.push(l); changed = true; buys += l.qty; (CLD.st.applied = CLD.st.applied || {})[r.id] = l.id;
      done.push({ ...r, data: { ...d, done: true, lotId: l.id, at: Date.now() } });
    } else if (r.kind === 'barcode' && d.code && d.size && d.barcode) {
      const it = INV.items.find(x => String(x.code || '').split('/').some(c => codeKey(c) === codeKey(d.code)));
      if (it && (it.barcodes || {})[d.size] !== d.barcode) { it.barcodes = it.barcodes || {}; it.barcodes[d.size] = String(d.barcode); changed = true; }
    } else if (r.kind === 'job' && d.type === 'quote' && d.status === 'wait' && d.code) {
      done.push(await clQuote(r));
    } else if (r.kind === 'job' && d.type === 'run' && d.status === 'wait') {
      // H11: 폰에서 [PC 에서 소싱 실행] — 지금 실행 중이 아니고 긴급 정지가 아니면 상품 소싱을 시작해요
      let why = '';
      if (typeof SE === 'undefined' || typeof seStart !== 'function') why = '이 PC 에서 소싱을 쓸 수 없어요';
      else if (SE.busy) why = '이미 소싱이 돌고 있어요';
      else if (typeof OPS !== 'undefined' && OPS.halt) why = 'PC 가 긴급 정지 중이에요';
      if (!why) { try { seStart({ kind: 'product' }); } catch (e) { why = String(e.message || e); } }
      done.push({ ...r, data: { ...d, status: why ? 'fail' : 'done', why, at: Date.now() } });
      try { if (!why) wkLog('소싱 실행 (폰에서 요청)', true, '시작'); } catch (e) {}
    } else if (r.kind === 'job' && d.type === 'short' && d.status === 'wait' && d.code && d.size && +d.price >= 1000) {
      // J9: 폰 공매도 — 자동 입찰 방식(알림만 / 확인 화면까지 / 끝까지 자동) 그대로
      done.push(await clShort(r));
    } else if (r.kind === 'job' && d.type === 'push') {
      // 11/25: 폰 앱 › 발매 탭 › [알림 켜기 · 끄기] — 폰 알림 보낼 곳 (push.js)
      if (typeof pushSubPut === 'function') { pushSubPut(r); pushSubsSave(); }
    } else if (r.kind === 'store_day' && d.storeId && d.disc != null) {
      const p = partnerOf(d.storeId); if (p && p.lastDisc !== +d.disc) { p.lastDisc = +d.disc; changed = true; }
    }
  }
  // 재고를 먼저 저장하고(반영한 번호도 기억해서 다시 받아도 두 번 넣지 않아요) 그다음 서버에 done 을 알려요
  if (changed) { await invSave(); await clSave(); }
  if (done.length) { const now = new Date().toISOString(); await clRpc('ks_doc_put', { p_docs: done.map(r => ({ kind: r.kind, id: r.id, data: r.data, by: 'pc', at: now })) }); }
  if (buys) { try { notiAdd1('폰 매입 등록', `폰에서 매입 ${buys}개가 들어왔어요 — 재고 현황에 넣었어요`); notiBadge(); } catch (e) {} }
  return { buys };
}
async function clShort(r) {
  const d = r.data || {}, res = { ...d, at: Date.now() };
  try {
    if (typeof opsBlock === 'function' && opsBlock('abid')) throw new Error(opsBlock('abid'));
    const price = Math.ceil(+d.price / 1000) * 1000, f = await kreamByCode(d.code);
    if (!f || !f.pid) throw new Error('KREAM 에서 이 품번을 못 찾았어요');
    const rec = { key: 'normal|short-' + Date.now(), askId: '', type: 'normal', pid: String(f.pid), name: f.name || d.name || d.code, code: d.code, size: String(d.size), price, status: '판매 입찰 중', on: false, floor: '', step: 1000, cost: +d.cost || '', short: { at: Date.now(), from: d.from || '', cost: +d.cost || 0 } };
    if (abOpt.mode === 'notify') { rec.status = '공매도(직접 걸어 주세요)'; rec.st = "자동 입찰 방식이 '알림만'이라 KREAM 에서 직접 걸어 주세요"; abList.push(rec); await abSave(); res.status = 'done'; res.why = 'PC 에 기록했어요 — 자동 입찰 방식이 알림만이라 KREAM 에서 직접 걸어 주세요'; return { ...r, data: res }; }
    const x = await abSellPage(String(f.pid), String(d.size), '', price, +d.days || 180, abOpt.mode === 'auto', { code: d.code, name: f.name || d.name });
    if (x && (x.ready || (x.submitted && x.done))) { rec.st = x.ready ? 'KREAM 확인 화면까지 — 마지막 버튼은 PC 에서 직접' : '폰에서 건 공매도 입찰'; abList.push(rec); await abSave(); res.status = 'done'; res.why = x.ready ? 'PC 에 KREAM 확인 화면을 열었어요 — 마지막 버튼은 PC 에서 눌러 주세요' : '공매도 입찰을 걸었어요'; }
    else throw new Error((x && (x.mismatch || x.error)) || '입찰을 못 걸었어요');
  } catch (e) { res.status = 'fail'; res.why = String(e.message || e).slice(0, 120); }
  return { ...r, data: res };
}
// 폰의 시세 조회 요청 → 이 PC 가 KREAM 을 조회해서 사이즈별 최저 판매가 · 즉시 판매가 · 30일 거래
async function clQuote(r) {
  const d = r.data || {}, res = { ...d, status: 'done', at: Date.now() };
  try {
    if (typeof opsBlock === 'function' && OPS.halt) throw new Error('PC 가 긴급 정지 중이에요');
    const f = await kreamByCode(d.code);
    if (!f || !f.pid) throw new Error('KREAM 에서 이 품번을 못 찾았어요');
    const p = { id: 'cq', pid: f.pid, raw: null };
    await collectOne(p, { days: 30, maxPages: 4 });
    const raw = p.raw || {}, sizes = {}, now = raw.ts || Date.now();
    const sz = new Set([...(raw.asks || []).map(a => a.o), ...(raw.sales || []).map(s => s.o)].filter(Boolean));
    for (const s of sz) {
      const m = typeof abMarket === 'function' ? abMarket(raw, s, false) : {};
      const n30 = (raw.sales || []).filter(x => x.o === s && x.t && now - x.t <= 30 * 864e5).length;
      const bids = (raw.bids || []).filter(b => b.o === s && b.p).map(b => b.p);
      sizes[s] = { ask: m.minAsk || null, bid: bids.length ? Math.max(...bids) : null, n30, d14: m.d14 ? m.d14.p : null };
    }
    Object.assign(res, { pid: f.pid, name: f.name || d.name || '', img: f.img || '', sizes });
  } catch (e) { res.status = 'fail'; res.why = String(e.message || e).slice(0, 120); }
  return { ...r, data: res };
}
async function clPull() {
  const st = CLD.st;
  const rows = (await clRpc('ks_doc_get', { p_since: st.pullAt || null, p_kinds: CL_KINDS_PULL, p_limit: 500 })) || [];
  if (rows.length) { const mine = rows.filter(r => r.by === 'phone'); if (mine.length) await clApply(mine); st.pullAt = rows[rows.length - 1].updated_at; }   // 반영이 끝난 뒤에 받은 시점을 넘겨요
  st.pullOkAt = Date.now();
  return rows.length;
}
async function clTick(force) {
  if (CLD.busy || !clOn() || typeof INV === 'undefined') return;
  const st = CLD.st; if (st.notReady && !force && Date.now() - (st.notReadyAt || 0) < 30 * 60e3) return;
  CLD.busy = true;
  try {
    if (CLD.dirty || force || Date.now() - (st.pushAt || 0) > 5 * 60e3) await clPush(false);
    await clPull();
    st.err = ''; st.notReady = false;
  } catch (e) {
    st.err = String(e.message || e).slice(0, 160); if (e.notReady) { st.notReady = true; st.notReadyAt = Date.now(); }
  } finally { CLD.busy = false; await clSave(); try { if (typeof curView !== 'undefined' && curView === 'link') lkPaint(); } catch (e) {} }
}
// [서버로 옮기기]: 로컬 백업 → 전부 올리기 → 건수 비교
async function clMove() {
  if (CLD.busy) return '지금 올리는 중이에요';
  CLD.busy = true; const st = CLD.st;
  try {
    const bk = 'cloudBackup_' + today(); await store.set(bk, JSON.parse(JSON.stringify(INV)));
    st.hashes = {}; const r = await clPush(true);
    const cnt = (await clRpc('ks_doc_count', {})) || [], M = {}; for (const x of cnt) M[x.kind] = +x.n;
    const L = { item: INV.items.length, lot: INV.lots.length, out: INV.outs.length, partner: INV.partners.length, pay: (INV.pays || []).length, expense: (INV.expenses || []).length, ship: (INV.ships || []).length };
    const NM = { item: '상품', lot: '입고', out: '판매 · 출고', partner: '거래처', pay: '결제수단', expense: '지출', ship: '발송' };
    st.moved = { at: Date.now(), rows: Object.keys(L).map(k => ({ k: NM[k], pc: L[k], sv: M[k] || 0 })) }; st.err = ''; st.notReady = false;
    const bad = st.moved.rows.filter(x => x.pc !== x.sv);
    return bad.length ? `올렸어요 — 건수가 다른 종류가 있어요: ${bad.map(x => `${x.k} PC ${x.pc} · 서버 ${x.sv}`).join(' / ')}` : `서버로 옮겼어요 — ${st.moved.rows.map(x => `${x.k} ${x.pc}`).join(' · ')} (로컬 백업 '${bk}')`;
  } catch (e) { st.err = String(e.message || e); if (e.notReady) { st.notReady = true; st.notReadyAt = Date.now(); } return st.err; }
  finally { CLD.busy = false; await clSave(); }
}
// 판매처 연동 화면에 '서버 동기화' 카드
function clCard() {
  const st = CLD.st || {}, ago = t => typeof lkAgo === 'function' && t ? lkAgo(t) : '–';
  const badge = !clOn() ? lkBadge('꺼짐', '') : st.notReady ? lkBadge('서버 준비 전', 'warn') : st.err ? lkBadge('오류', 'bad') : st.pullOkAt ? lkBadge('연결됨', 'ok') : lkBadge('확인 전', '');
  const mv = st.moved ? `<table class="lk-al"><thead><tr><th class="l">종류</th><th>PC</th><th>서버</th></tr></thead><tbody>${st.moved.rows.map(x => `<tr><td class="l">${esc(x.k)}</td><td>${x.pc}</td><td class="${x.pc !== x.sv ? 'neg' : ''}">${x.sv}</td></tr>`).join('')}</tbody></table>` : '';
  return `<section class="panel lk-card"><div class="lk-ch"><h3>서버 동기화 (PC ⇄ 폰)</h3>${badge}</div>
    <p class="lk-desc">재고 · 매입 · 판매 · 거래처를 킥스캔 계정 서버에 올려 폰 현장 앱과 1분 안에 맞춰요. 폰에서 등록한 매입은 이 PC 재고로 들어오고, 폰의 시세 조회 요청은 이 PC 가 KREAM 을 조회해서 돌려줘요. 판매처 아이디 · 비밀번호는 올리지 않아요.</p>
    ${st.err ? `<p class="lk-desc neg">${esc(st.err)}</p>` : ''}
    <div class="lk-meta"><div><small>마지막 올림</small><b>${ago(st.pushAt)}</b></div><div><small>마지막 받음</small><b>${ago(st.pullOkAt)}</b></div><div><small>주기</small><b>30초마다(바뀐 것만)</b></div></div>
    ${mv}
    <div class="row-btns"><button type="button" class="primary small" data-x="lkClMove">서버로 옮기기</button><button type="button" class="ghost small" data-x="lkClNow">지금 맞추기</button><button type="button" class="ghost small" data-x="lkClOff">${clOn() ? '동기화 끄기' : '동기화 켜기'}</button><span class="small">폰 현장 앱: chldydrnr2-eng.github.io/kream-scanner/m/</span></div></section>`;
}
(function clWire() {
  if (typeof invSave === 'function') { const f = invSave; invSave = async function () { const r = await f.apply(this, arguments); CLD.dirty = true; return r; }; }
  if (typeof vLink === 'function') { const v = vLink; vLink = function () { const h = v(); const i = h.lastIndexOf('<details class="panel lk-how">'); return i > 0 ? h.slice(0, i) + clCard() + h.slice(i) : h + clCard(); }; }
  if (typeof lkAct === 'function') {
    const a0 = lkAct;
    lkAct = async function (a, el) {
      if (a === 'lkClMove') { LK.msg = '서버로 옮기는 중이에요…'; lkPaint(); LK.msg = await clMove(); return lkPaint(); }
      if (a === 'lkClNow') { LK.msg = '서버와 맞추는 중이에요…'; lkPaint(); await clTick(true); LK.msg = CLD.st.err || '서버와 맞췄어요'; return lkPaint(); }
      if (a === 'lkClOff') { CLD.st.on = !clOn() ? true : false; await clSave(); LK.msg = CLD.st.on === false ? '서버 동기화를 껐어요' : '서버 동기화를 켰어요'; return lkPaint(); }
      return a0(a, el);
    };
  }
})();
(async function clBoot() {
  try { CLD.st = (await store.get('cloudSt', null)) || {}; } catch (e) { CLD.st = {}; }
  CLD.st.hashes = CLD.st.hashes || {};
  setTimeout(() => clTick().catch(() => {}), 45e3);
  setInterval(() => clTick().catch(() => {}), 30e3);
})();
