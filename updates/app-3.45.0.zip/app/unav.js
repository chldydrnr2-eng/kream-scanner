'use strict';
/* 3.42 메뉴 한 줄 (11/23 검수 1번 — 줍픽 오피스 14_홈_전체 메뉴 순서)
   '자동화 / 재고관리' 두 모드 토글 대신 한 줄 메뉴: 홈 · 재고 · 일반 판매 · 보관 판매 · 정산·부가세 · 분석 · 소싱 · 행사 · 판매처 연동
   옛 메뉴 기능은 하나도 빼지 않고 '더 많은 기능 ▾' 안에 그대로 있어요(같은 화면으로 가요).
   설정 store 'navUni' 가 false 면 예전 두 모드 메뉴로 보여요 (메뉴 맨 아래 '예전 메뉴로 보기'). 기존 디자인(.snav 버튼 · 그라데이션)은 그대로 써요. */
const UNAV_MAIN = [
  ['inv:home', '홈', 'home'], ['inv:stock', '재고', 'box'], ['inv:sell', '일반 판매', 'swap'], ['inv:storage', '보관 판매', 'archive'],
  ['inv:ledger', '정산 · 부가세', 'receipt'], ['inv:ana', '분석', 'chart'], ['find', '소싱', 'search'], ['inv:drops', '발매', 'spark'], ['inv:events', '행사', 'cal'], ['link', '판매처 연동', 'plug']
];
// 11/24: '소싱 · 시세'는 '더 많은 기능' 맨 아래에 숨어 있었어요 → 위 '소싱' 바로 아래 하위 메뉴로 합쳤어요 (사장님 지시)
const UNAV_SUB = {
  find: [['srchist', '소싱 이력', 'sheet'], ['perf', '성과', 'chart'], ['dual', '크림 / 포이즌 동시 분석', 'scale'], ['msstock', '상품 재고조회', 'box'], ['mstrack', '상품 가격 · 재입고 추적', 'trend']]
};
// 옛 메뉴 → '더 많은 기능' (어디로 옮겨 갈지 묶음 이름)
const UNAV_MORE = [
  ['재고 · 입고', [['inv:bc', '바코드 입고', 'sheet'], ['inv:excel', '엑셀 대량 입고', 'sheet'], ['inv:ms', '구매처 주문 입고', 'cart'], ['inv:plan', '입고예정 관리', 'cal'], ['inv:items', '상품 · 재고', 'tag'], ['inv:io', '입출고', 'swap']]],
  ['판매 · 정산', [['inv:pre', '우선출고 정산', 'zap'], ['inv:ret', '반품 · 교환', 'ret'], ['inv:vat', '부가세 예상', 'percent']]],
  ['도움말', [['guide', '사용 가이드', 'book']]]
];
// 11/23(02_설정화면_정리 · 덧붙임): 메뉴에서 뺀 옛 메뉴 — '크림 · 개인' · '크림 · 입점' 묶음(일반 판매 · 보관 판매의 계정 칩 [KREAM] [KREAM 입점]으로)
//   · '계정 연결 · 로그인'(판매처 연동 › 매입처 로그인) · '기본정보'(설정 › 매장 · 사업자) · '백업 · 초기화'(설정 › 내 계정 › 백업). 메뉴 찾기에서 옛 이름으로 찾으면 새 위치로 데려가요
const UNAV_GONE = [
  ['크림 · 개인', [['ksell', '일반판매 입찰 & 관리'], ['kauto', '자동 입찰'], ['kinv', '보관판매 관리'], ['kmacro', '보관판매 매크로'], ['kship', '발송관리'], ['khist', '판매 · 구매 내역'], ['kcancel', '취소 · 반송 관리']]],
  ['크림 · 입점', [['pbid', '일반판매 입찰 & 관리'], ['pinv', '보관판매 관리'], ['pmacro', '보관판매 매크로 (준비 중)'], ['pship', '발송관리'], ['psales', '판매내역']]],
  ['계정 · 기본', [['acct', '계정 연결 · 로그인'], ['inv:base', '기본정보'], ['inv:reset', '백업 · 초기화']]]
];
let UNAV = { on: true, more: false };
const unavKey = () => (typeof stShown === 'function' && stShown()) ? 'settings' : (typeof curMode !== 'undefined' && curMode === 'inv') ? 'inv:' + invView : (typeof curView !== 'undefined' ? curView : '');   // 11/23: 설정을 볼 때는 메뉴에 선택 표시 없이
// 메뉴에 실제로 있는 항목만 (AUTO_MENU · INV_MENU 에 없는 건 빼요 — 예: 취소·반송이 다른 이름이면)
function unavHas(k) {
  if (k.startsWith('inv:')) return typeof INV_MENU !== 'undefined' && INV_MENU.some(m => m[0] === k.slice(4));
  return typeof AUTO_MENU !== 'undefined' && AUTO_MENU.some(m => m[0] === k);
}
function unavLabel(k, t) { if (k.startsWith('inv:')) return t; const m = (typeof AUTO_MENU !== 'undefined' ? AUTO_MENU : []).find(x => x[0] === k); return m ? m[1] : t; }
function unavBtn([k, t, ic], cur) {
  const lock = typeof canUse === 'function' && !canUse(k) ? `<span class="slock">${ico('lock')}</span>` : '';
  const badge = !k.startsWith('inv:') && typeof sideBadge === 'function' && typeof canUse === 'function' && canUse(k) ? sideBadge(k) : '';
  return `<button type="button" data-uv="${esc(k)}" aria-current="${k === cur}">${ico(ic)}<span class="lbl">${esc(t)}</span>${badge}${lock}</button>`;
}
function unavPaint() {
  const nav = document.getElementById('uniNav'); if (!nav) return;
  if (!UNAV.on) { nav.hidden = true; return; }
  const cur = unavKey();
  // 지금 보는 화면이 '더 많은 기능' 안에 있으면 펼쳐 둬요
  const inMore = UNAV_MORE.some(([, L]) => L.some(x => x[0] === cur));
  const more = UNAV_MORE.map(([g, L]) => { const B = L.filter(x => unavHas(x[0])); return B.length ? `<div class="sgrp">${esc(g)}</div>${B.map(x => unavBtn(x, cur)).join('')}` : ''; }).join('');
  const sub = k => { const B = (UNAV_SUB[k] || []).filter(x => unavHas(x[0])); return B.length ? `<div class="unav-sub">${B.map(x => unavBtn(x, cur)).join('')}</div>` : ''; };
  nav.innerHTML = UNAV_MAIN.filter(x => unavHas(x[0])).map(x => unavBtn(x, cur) + sub(x[0])).join('')
    + `<details class="unav-more"${UNAV.more || inMore ? ' open' : ''}><summary class="sgrp">더 많은 기능</summary>${more}</details>`;
  nav.hidden = false;
}
// route 가 끝난 뒤: 두 모드 메뉴는 숨기고 한 줄 메뉴만 보여요
function unavApply() {
  const on = UNAV.on;
  document.body.classList.toggle('unav', on);
  const an = document.getElementById('autoNav'), iv = document.getElementById('invNav'), bx = document.getElementById('bizBox');
  if (on) { if (an) an.hidden = true; if (iv) iv.hidden = true; if (bx) bx.hidden = false; }
  unavPaint();
  if (on) { const vi = document.getElementById('viewIco'), a = document.querySelector('#uniNav [aria-current="true"] svg'); if (vi && a) vi.innerHTML = a.outerHTML; else if (vi && unavKey() === 'settings' && typeof ico === 'function') vi.innerHTML = ico('gear'); }
}
(function unavWire() {
  if (typeof document === 'undefined' || typeof route !== 'function') return;
  const side = document.querySelector('aside.side'), anchor = document.getElementById('autoNav');
  if (!side || !anchor || document.getElementById('uniNav')) return;
  const nav = document.createElement('nav'); nav.id = 'uniNav'; nav.className = 'snav'; nav.setAttribute('aria-label', '메뉴'); nav.hidden = true;
  anchor.parentNode.insertBefore(nav, anchor);
  const r0 = route; route = function (v) {
    // 11/23: 옛 '기본정보' · '백업 · 초기화' 화면은 설정으로 옮겼어요 (예전 메뉴 · 가이드 · 홈 링크로 와도 새 위치로)
    const mv = { 'inv:base': 'store', 'inv:reset': 'bak' }[String(v || '')];
    if (mv && typeof stOpen === 'function') return stOpen(mv);
    const r = r0.apply(this, arguments); try { unavApply(); } catch (e) {} return r;
  };
  if (typeof renderSide === 'function') { const s0 = renderSide; renderSide = function () { const r = s0.apply(this, arguments); try { unavPaint(); } catch (e) {} return r; }; }
  nav.addEventListener('click', async e => {
    const old = e.target.closest('[data-uv-old]');
    if (old) return unavSetOn(false);
    const b = e.target.closest('[data-uv]'); if (b) route(b.dataset.uv);
  });
  nav.addEventListener('toggle', e => { if (e.target.classList && e.target.classList.contains('unav-more')) UNAV.more = e.target.open; }, true);
  (async () => {
    try { const v = await store.get('navUni', true); UNAV.on = v !== false; } catch (e) {}
    if (UNAV.on) unavApply(); else unavOldLink();
    unavModeSw();
  })();
})();
// 11/24: 메뉴 모양 고르기 — 사이드 맨 위 [새 메뉴 | 예전 메뉴(자동화 · 재고관리)]. 새 메뉴가 기본, 고른 건 store 'navUni' 에 기억
function unavOldLink() { const b = document.getElementById('unavBack'); if (b) b.remove(); unavModeSw(); }
function unavModeSw() {
  let m = document.getElementById('unavMode');
  if (!m) {
    const nav = document.getElementById('uniNav'); if (!nav) return;
    m = document.createElement('div'); m.id = 'unavMode'; m.className = 'unav-mode'; m.setAttribute('role', 'group'); m.setAttribute('aria-label', '메뉴 모양');
    nav.parentNode.insertBefore(m, document.getElementById('unavFind') || nav);
    m.addEventListener('click', e => { const b = e.target.closest('[data-um]'); if (b) unavSetOn(b.dataset.um === 'new'); });
  }
  m.innerHTML = `<button type="button" data-um="new" aria-pressed="${UNAV.on}" title="한 줄 메뉴 (홈 · 재고 · 일반 판매 · … · 소싱)">새 메뉴</button><button type="button" data-um="old" aria-pressed="${!UNAV.on}" title="예전처럼 자동화 / 재고관리 두 모드로">예전 메뉴</button>`;
}
async function unavSetOn(on) {
  if (UNAV.on === on) return unavModeSw();
  UNAV.on = on; try { await store.set('navUni', on); } catch (e) {}
  const nav = document.getElementById('uniNav');
  if (on) unavApply(); else { document.body.classList.remove('unav'); if (nav) nav.hidden = true; route(unavKey()); }
  unavModeSw();
}

/* 3.42 메뉴 찾기 · 옛 메뉴 이사 안내 (11/23 검수 1번 나머지)
   - 메뉴 맨 위 '메뉴 찾기' 칸: 새 메뉴 · 옛 메뉴 · 설정 항목을 이름으로 찾아요. 옛 이름을 치면 새 위치로 데려가요(예전 화면도 그대로 열 수 있어요).
   - 한 달(처음 3.42 를 켠 날부터 30일) 동안은 '더 많은 기능'의 옛 메뉴를 누르면 아래에 "이제 여기서도 돼요" 안내가 떠요. store 'unavMoveSince' */
const UNAV_DAY = 864e5;
// 옛 메뉴 → [새 위치 글, 새 위치 여는 함수]
const unavSl = (tab, acct) => () => { route('inv:sell'); try { const S0 = slS(); S0.tab = tab; if (acct !== undefined) S0.acct = acct; renderInv(); } catch (e) {} };
const unavSto = () => () => route('inv:storage');
const unavStoA = acct => () => { route('inv:storage'); try { stoS().acct = acct; renderInv(); } catch (e) {} };
const unavStk = tab => () => { route('inv:stock'); try { stkS().tab = tab; renderInv(); } catch (e) {} };
const unavBr = (tab, sub) => () => { route('inv:stock'); try { if (sub) BR.sub = sub; brOpen(tab); } catch (e) {} };
const unavLg = tab => () => { route('inv:ledger'); try { IS.lg.tab = tab; renderInv(); } catch (e) {} };
const unavSet = (tab, box) => () => { if (typeof stOpen === 'function') stOpen(tab || 'sell'); else route('settings'); setTimeout(() => { try { const b = box && document.getElementById(box); if (b) { if (b.tagName === 'DETAILS') b.open = true; b.scrollIntoView({ block: 'start' }); } } catch (e) {} }, 300); };
const unavRules = unavSet('rule');
const unavLinkShop = () => { route('link'); setTimeout(() => { const b = document.getElementById('lkShops'); if (b) b.scrollIntoView({ block: 'start' }); }, 200); };
const UNAV_MOVE = {
  'inv:bc': ['재고 › 매입 등록 › 일괄 등록 · 바코드로 담기', unavBr('bulk', 'bc')],
  'inv:excel': ['재고 › 매입 등록 › 일괄 등록 · 엑셀 붙여넣기', unavBr('bulk', 'paste')],
  'inv:ms': ['재고 › 매입 등록 창 아래 [쇼핑몰 주문 불러오기]', unavBr('one')],
  'inv:plan': ['재고 › 매입 등록 창 아래 [입고예정]', unavBr('one')],
  'inv:items': ['재고 › 재고 현황', unavStk('now')],
  'inv:io': ['재고 › 재고 현황 · 매입 내역', unavStk('now')],
  'inv:ret': ['재고 › 반품·반출', unavStk('out')],
  'inv:vat': ['정산 · 부가세 › 부가세', unavLg('vat')],
  'ksell': ['일반 판매 › 판매 중 [KREAM]', unavSl('on', 'normal')],
  'pbid': ['일반 판매 › 판매 중 [KREAM 입점]', unavSl('on', 'partner')],
  'kinv': ['보관 판매 [KREAM]', unavStoA('kream')], 'pinv': ['보관 판매 [KREAM 입점]', unavStoA('partner')],
  'kauto': ['설정 › 판매 규칙 › 입찰가 자동 조정', unavRules], 'kmacro': ['보관 판매 › [보관판매 매크로]', unavStoA('kream')], 'pmacro': ['보관 판매 [KREAM 입점] › 입점 보관판매 매크로', unavStoA('partner')],
  'kship': ['일반 판매 › 발송 [KREAM]', unavSl('ship', 'normal')], 'pship': ['일반 판매 › 발송 [KREAM 입점]', unavSl('ship', 'partner')],
  'khist': ['일반 판매 › 판매 내역 [KREAM]', unavSl('hist', 'normal')], 'psales': ['일반 판매 › 판매 내역 [KREAM 입점]', unavSl('hist', 'partner')],
  'inv:base': ['설정 › 매장 · 사업자', unavSet('store')], 'inv:reset': ['설정 › 내 계정 › 백업', unavSet('bak')],
  'kcancel': ['일반 판매 › 검수 (불합격 · 반송)', unavSl('insp')],
  'acct': ['판매처 연동 › 매입처(쇼핑몰) 로그인', unavLinkShop],
  'mstrack': ['소싱 › 관심 상품', () => route('find')]
};
// 메뉴에 없는 찾기 낱말 (설정 안 항목 · 탭)
const UNAV_EXTRA = [
  ['설정', '왼쪽 아래 설정', unavSet('sell')], ['판매 규칙', '설정 › 판매 규칙', unavRules], ['자동 판매 등록', '설정 › 판매 규칙', unavRules], ['입찰가 자동 조정', '설정 › 판매 규칙', unavRules],
  ['수수료 할인', '설정 › 판매처 › 수수료 자동 확인', unavSet('sell', 'fdCard')], ['수수료', '설정 › 판매처', unavSet('sell')], ['판매처 설정', '설정 › 판매처', unavSet('sell')], ['POIZON 오픈 API', '설정 › 판매처 › POIZON', unavSet('sell')],
  ['매장', '설정 › 매장', unavSet('store')], ['할인율', '설정 › 매장', unavSet('store')], ['내 스캔 보태기', '설정 › 매장', unavSet('store')], ['거래처', '설정 › 매장(매입처) · 판매처(장부 매출처)', unavSet('store')], ['반품 기한', '설정 › 매장 › 기본값', unavSet('store')],
  ['사업자', '설정 › 사업자', unavSet('biz')], ['관리 시작일', '설정 › 사업자', unavSet('biz')], ['결제 카드', '설정 › 사업자 › 결제 카드', unavSet('biz')], ['결제수단', '설정 › 사업자 › 결제 카드', unavSet('biz')], ['배송사', '설정 › 사업자 › 장부 목록', unavSet('biz')], ['택배사', '설정 › 사업자 › 장부 목록', unavSet('biz')], ['분류 · 브랜드', '설정 › 사업자 › 장부 목록', unavSet('biz')],
  ['상품 소싱 설정', '설정 › 상품 소싱', unavSet('src')], ['수익 계산', '설정 › 상품 소싱', unavSet('src')], ['수집 범위', '설정 › 상품 소싱 · 이 PC 설정 › 일반', unavSet('src')], ['최소 수익', '설정 › 상품 소싱', unavSet('src')],
  ['매입처 묶음', '이 PC 설정 › 일반 › 수집할 매입처', unavSet('gen')], ['일반 설정', '이 PC 설정 › 일반', unavSet('gen')], ['작업용 크롬', '이 PC 설정 › 일반 › 고급', unavSet('gen', 'stAdv')], ['크림 작업 방식', '이 PC 설정 › 일반 › 고급', unavSet('gen', 'stAdv')],
  ['계정', '설정 › 내 계정 › 계정', unavSet('acct')], ['로그아웃', '설정 › 내 계정 › 계정', unavSet('acct')], ['휴대폰 연결', '설정 › 내 계정 › 휴대폰 연결', unavSet('phone')], ['알림', '설정 › 내 계정 › 알림', unavSet('noti')], ['백업', '설정 › 내 계정 › 백업', unavSet('bak')], ['초기화', '설정 › 내 계정 › 백업', unavSet('bak')],
  ['휴가 모드', '왼쪽 아래 휴가 모드', () => { const v = document.getElementById('wkVac'); if (v) v.focus(); }], ['긴급 정지', '판매처 연동 › 이 PC', () => route('link')], ['업데이트', '왼쪽 아래 프로그램 업데이트', () => { const p = document.getElementById('updPop'); if (p) p.hidden = false; }], ['오류 보고서', '위쪽 [가이드] › 오류 보고서 저장', () => setTimeout(() => { const g = document.getElementById('tGuide'); if (g) g.click(); }, 0)],
  ['매입 등록', '재고 › [매입 등록]', unavBr('one')], ['영수증', '재고 › 매입 등록 › 영수증 사진', unavBr('one')], ['매입 내역', '재고 › 매입 내역', unavStk('buy')],
  ['정산', '정산 · 부가세 › 정산', unavLg('settle')], ['지출', '정산 · 부가세 › 지출', unavLg('exp')], ['장부 내역', '정산 · 부가세 › 장부 내역', unavLg('list')],
  ['대시보드', '분석', () => route('inv:ana')], ['자산현황', '분석', () => route('inv:ana')], ['상품별 마진', '분석', () => route('inv:ana')], ['거래처별', '분석', () => route('inv:ana')],
  ['공매도', '일반 판매 › 공매도', unavSl('short')], ['확인 필요', '일반 판매 › 확인 필요', unavSl('check')], ['재고 연동', '일반 판매 › 재고 연동', unavSl('cross')],
  ['관심 상품', '소싱 › 관심 상품', () => route('find')]
];
const unavNorm = s => String(s || '').toLowerCase().replace(/[\s·&/()\-_.›]+/g, '');
let unavSince = 0;
const unavMoving = () => !!unavSince && Date.now() - unavSince < 30 * UNAV_DAY;
function unavAll() {
  const R = [];
  UNAV_MAIN.filter(x => unavHas(x[0])).forEach(([k, t]) => { R.push({ t, path: t, go: () => route(k) }); (UNAV_SUB[k] || []).filter(x => unavHas(x[0])).forEach(([k2, t2]) => { const n2 = unavLabel(k2, t2); R.push({ t: n2, path: `${t} › ${n2}`, go: () => route(k2) }); }); });
  UNAV_MORE.forEach(([g, L]) => L.filter(x => unavHas(x[0])).forEach(([k, t]) => {
    const name = unavLabel(k, t), mv = UNAV_MOVE[k];
    R.push(mv ? { t: name, path: mv[0], go: mv[1], old: () => route(k), moved: true, from: g + ' ' + name } : { t: name, path: `더 많은 기능 › ${g} › ${name}`, go: () => route(k) });
  }));
  UNAV_GONE.forEach(([g, L]) => L.forEach(([k, t]) => { const mv = UNAV_MOVE[k]; if (mv) R.push({ t: unavLabel(k, t), path: mv[0], go: mv[1], old: k.startsWith('inv:') ? null : () => route(k), moved: true, from: g + ' ' + t }); }));
  UNAV_EXTRA.forEach(([t, path, go]) => R.push({ t, path, go }));
  return R;
}
function unavFind(q) {
  const n = unavNorm(q); if (!n) return [];
  const R = unavAll().map(r => { const a = unavNorm(r.t); const s = a === n ? 0 : a.startsWith(n) ? 1 : a.includes(n) ? 2 : unavNorm(r.from).includes(n) || unavNorm(r.path).includes(n) ? 3 : 9; return { ...r, s }; }).filter(r => r.s < 9);
  R.sort((a, b) => a.s - b.s); const seen = new Set();
  return R.filter(r => { const k = r.t + '|' + r.path; if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 8);
}
let UNAV_HITS = [];
function unavHitsPaint(q) {
  const box = document.getElementById('unavHits'); if (!box) return;
  UNAV_HITS = unavFind(q);
  if (!String(q || '').trim()) { box.hidden = true; box.innerHTML = ''; return; }
  box.innerHTML = UNAV_HITS.length ? UNAV_HITS.map((r, i) => `<div class="unav-hit"><button type="button" data-uh="${i}"><b>${esc(r.t)}</b><small>${r.moved && unavMoving() ? '옮겼어요 → ' : ''}${esc(r.path)}</small></button>${r.old ? `<button type="button" class="unav-hold" data-uh-old="${i}" title="예전 화면 그대로 열기">예전 화면</button>` : ''}</div>`).join('')
    : `<p class="unav-none">'${esc(q)}' 메뉴가 없어요 — 오른쪽 위 [가이드]에서 찾아보세요.</p>`;
  box.hidden = false;
}
function unavSearchClear() { const i = document.getElementById('unavQ'); if (i) i.value = ''; unavHitsPaint(''); }
// 한 달 동안: 옛 메뉴를 누르면 아래에 새 위치 안내
function unavTip(k) {
  const mv = UNAV_MOVE[k]; if (!mv || !unavMoving()) return;
  let t = document.getElementById('unavTip');
  if (!t) { t = document.createElement('div'); t.id = 'unavTip'; t.className = 'unav-tip'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
  const name = unavLabel(k, (UNAV_MORE.flatMap(x => x[1]).find(x => x[0] === k) || [])[1] || '');
  t.innerHTML = `<span><b>${esc(name)}</b> — 이제 <b>${esc(mv[0])}</b>에서도 할 수 있어요.</span><button type="button" class="primary small" data-ut="go">거기로 가기</button><button type="button" class="sr-x" data-ut="x" aria-label="닫기">✕</button>`;
  t.hidden = false; t.onclick = e => { const b = e.target.closest('[data-ut]'); if (!b) return; t.hidden = true; if (b.dataset.ut === 'go') mv[1](); };
  clearTimeout(unavTip.tm); unavTip.tm = setTimeout(() => { t.hidden = true; }, 12000);
}
(function unavSearchWire() {
  if (typeof document === 'undefined') return;
  const nav = document.getElementById('uniNav'); if (!nav || document.getElementById('unavFind')) return;
  const w = document.createElement('div'); w.id = 'unavFind'; w.className = 'unav-find'; w.hidden = true;
  w.innerHTML = `<input id="unavQ" type="search" placeholder="메뉴 찾기 (예전 이름도 돼요)" autocomplete="off" aria-label="메뉴 찾기"><div id="unavHits" class="unav-hits" hidden></div>`;
  nav.parentNode.insertBefore(w, nav);
  const q = w.querySelector('#unavQ');
  q.addEventListener('input', () => unavHitsPaint(q.value));
  q.addEventListener('keydown', e => {
    if (e.key === 'Escape') { unavSearchClear(); q.blur(); }
    if (e.key === 'Enter' && UNAV_HITS[0]) { e.preventDefault(); const r = UNAV_HITS[0]; unavSearchClear(); r.go(); }
  });
  w.addEventListener('click', e => {
    const o = e.target.closest('[data-uh-old]'); if (o) { const r = UNAV_HITS[+o.dataset.uhOld]; unavSearchClear(); if (r && r.old) r.old(); return; }
    const b = e.target.closest('[data-uh]'); if (b) { const r = UNAV_HITS[+b.dataset.uh]; unavSearchClear(); if (r) r.go(); }
  });
  // 옛 메뉴 클릭 → 안내 (기존 클릭 처리 뒤에)
  nav.addEventListener('click', e => { const b = e.target.closest('[data-uv]'); if (b && UNAV_MOVE[b.dataset.uv]) setTimeout(() => unavTip(b.dataset.uv), 60); });
  // 찾기 칸은 한 줄 메뉴일 때만
  const p0 = unavPaint; unavPaint = function () { const r = p0.apply(this, arguments); w.hidden = !UNAV.on; return r; };
  w.hidden = !UNAV.on;
  (async () => { try { let s = +(await store.get('unavMoveSince', 0)) || 0; if (!s) { s = Date.now(); await store.set('unavMoveSince', s); } unavSince = s; } catch (e) { unavSince = Date.now(); } })();
})();
