/* 킥스캔 — 발매 (11/25 사장님: 줍픽처럼 발매 탭 + 새 발매는 앱(폰)으로도 알림)
   슈프라이즈 공개 목록을 본체(main-core API.drop)가 30분마다 받아요: 진행 중 응모 · 선착순(상품별로 묶음) + 발매 예정 상품
   - 새 응모 · 새 발매 예정이 올라오면 알림 종 + 윈도우 알림 + 폰 알림(push.js — 폰 앱 발매 탭에서 [알림 켜기] 한 폰)
   - 알림 설정: 켜기 · 국내 응모만 · 발매 예정도 알리기 (알림 종류 '발매' 끄기 · 밤 10시~아침 8시 조용히는 설정 › 알림 규칙 그대로)
   - 첫 번째 받기는 알림 없이 기억만 해요(처음부터 수십 개가 한꺼번에 울리지 않게) */
const RL_TTL = 30 * 60e3;
let RLD = { at: 0, rel: [], up: [], first: {}, err: '' };
let RLC = { on: true, krOnly: false, up: true };
const rlS = () => IS.rl || (IS.rl = { tab: 'rel', q: '', kr: false });
const rlKST = t => { const d = new Date(t); return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const rlPrice = x => !x.price ? '' : /KRW/i.test(x.cur) || x.sym === '₩' || x.sym === '￦' ? won(x.price) : `${x.sym || ''}${(+x.price).toLocaleString('en-US')}${x.sym ? '' : ' ' + x.cur}`;
// NEW: 처음 받은 뒤(base)에 새로 생긴 것 중 하루 안 된 것만 — 처음 받은 목록은 NEW 를 안 붙여요
const rlNew = id => { const t = (RLD.first || {})[id]; return t && RLD.base && t > RLD.base + 60e3 && Date.now() - t < 24 * 3600e3; };
const rlKream = code => code ? `https://kream.co.kr/search?keyword=${encodeURIComponent(String(code).split('/')[0])}` : '';
// 진행 중 응모 · 선착순: 상품별로 묶고, 가장 먼저 끝나는 순서
function rlGroups() {
  const S0 = rlS(), q = S0.q.trim().toLowerCase(), now = Date.now(), G = {};
  for (const x of RLD.rel || []) {
    if (S0.kr && !x.kr) continue;
    if (x.end && !x.noEnd && x.end < now) continue;
    if (q && ![x.brand, x.name, x.en, x.code, x.market].join(' ').toLowerCase().includes(q)) continue;
    (G[x.pid || x.id] = G[x.pid || x.id] || []).push(x);
  }
  const key = L => Math.min(...L.map(x => (x.start > now ? x.start : x.end) || 9e15));
  return Object.values(G).map(L => L.sort((a, b) => ((a.start > now ? a.start : a.end) || 9e15) - ((b.start > now ? b.start : b.end) || 9e15))).sort((a, b) => key(a) - key(b));
}
function rlUps() {
  const S0 = rlS(), q = S0.q.trim().toLowerCase();
  return (RLD.up || []).filter(p => !q || [p.brand, p.name, p.en, p.code].join(' ').toLowerCase().includes(q)).sort((a, b) => String(a.date).localeCompare(String(b.date)));
}
function rlWhen(x) {
  const now = Date.now();
  if (x.start && x.start > now) return `<span class="rl-when">${rlKST(x.start)} 시작</span>`;
  if (x.end && !x.noEnd) { const left = x.end - now; return `<span class="rl-when${left < 24 * 3600e3 ? ' due' : ''}">${left < 24 * 3600e3 ? '오늘 ' : ''}${rlKST(x.end)} 마감</span>`; }
  return `<span class="rl-when">${esc(x.when || '진행 중')}</span>`;
}
function rlCard(L) {
  const p = L[0], nw = L.some(x => rlNew('r' + x.id));
  const sites = L.slice(0, 6).map(x => `<div class="rl-site"><span class="rl-m" title="${esc(x.market)}">${esc(x.market || '응모처')}</span><span class="rl-tag${x.draw ? ' draw' : ''}">${x.draw ? '추첨' : '선착순'}</span><span class="rl-tag${x.kr ? ' kr' : ''}">${esc(x.kr ? '국내' : (x.region || '해외'))}</span>${rlWhen(x)}${x.url ? `<a href="${esc(x.url)}" target="_blank" rel="noopener">${x.draw ? '응모' : '구매'} ↗</a>` : ''}</div>`).join('');
  return `<div class="rl-card"><div class="rl-top">${p.img ? `<img class="rl-img" src="${esc(p.img)}" alt="" loading="lazy">` : '<span class="rl-img"></span>'}<div class="rl-h"><span class="rl-brand">${esc(p.brand)}${nw ? ' <em class="ev-new">NEW</em>' : ''}</span><b>${esc(p.name || p.en)}</b>${p.code ? `<span class="rl-code">${esc(p.code)}</span>` : ''}</div></div>
    <div class="rl-sites">${sites}${L.length > 6 ? `<p class="small">외 ${L.length - 6}곳 — 슈프라이즈에서 보기</p>` : ''}</div>
    <div class="rl-foot"><span class="rl-pr">${esc(rlPrice(p))}</span><span class="topsp"></span>${p.code ? `<a href="${esc(rlKream(p.code))}" target="_blank" rel="noopener">크림 시세 ↗</a>` : ''}${p.link ? `<a href="${esc(p.link)}" target="_blank" rel="noopener">슈프라이즈 ↗</a>` : ''}</div></div>`;
}
function rlUpCard(p) {
  const d = p.date ? dday(p.date) : null, nw = rlNew('u' + p.pid);
  return `<div class="rl-card"><div class="rl-top">${p.img ? `<img class="rl-img" src="${esc(p.img)}" alt="" loading="lazy">` : '<span class="rl-img"></span>'}<div class="rl-h"><span class="rl-brand">${esc(p.brand)}${nw ? ' <em class="ev-new">NEW</em>' : ''}</span><b>${esc(p.name || p.en)}</b>${p.code ? `<span class="rl-code">${esc(p.code)}</span>` : ''}</div></div>
    <dl class="rl-dl"><dt>발매일</dt><dd>${p.date ? `${esc(p.date.slice(5).replace('-', '/'))} <span class="rl-when${d != null && d <= 1 ? ' due' : ''}">${d === 0 ? '오늘' : d === 1 ? '내일' : d > 0 ? 'D-' + d : ''}</span>` : '미정'}</dd><dt>발매가</dt><dd>${p.price ? (/KRW/i.test(p.cur) ? won(p.price) : esc(p.priceTxt || String(p.price))) : esc(p.priceTxt || '–')}</dd><dt>응모처</dt><dd>${p.sites ? p.sites + '곳' : '아직 없음'}</dd></dl>
    <div class="rl-foot"><span class="topsp"></span>${p.code ? `<a href="${esc(rlKream(p.code))}" target="_blank" rel="noopener">크림 시세 ↗</a>` : ''}${p.link ? `<a href="${esc(p.link)}" target="_blank" rel="noopener">슈프라이즈 ↗</a>` : ''}</div></div>`;
}
function vRel() {
  const S0 = rlS(), G = rlGroups(), U = rlUps(), now = Date.now();
  const relN = new Set((RLD.rel || []).filter(x => (!S0.kr || x.kr) && !(x.end && !x.noEnd && x.end < now)).map(x => x.pid || x.id)).size;
  const todayN = G.filter(L => L.some(x => x.end && !x.noEnd && x.end - now < 24 * 3600e3 && !(x.start > now))).length;
  const ago = RLD.at ? (typeof lkAgo === 'function' ? lkAgo(RLD.at) : '') + ' 업데이트' : '아직 안 받아왔어요';
  const nPh = typeof pushCount === 'function' ? pushCount() : 0;
  const cards = S0.tab === 'up' ? U.map(rlUpCard).join('') : G.map(rlCard).join('');
  return `${head('발매', '한정판 응모 · 선착순과 발매 예정 상품을 모아 봐요. 새로 올라오면 알림 종 · 윈도우 알림 · 폰 알림으로 알려요.', `<span class="small">${ago}</span><button type="button" class="ghost" data-a="rlLoad"${IS.rlBusy ? ' disabled' : ''}>${IS.rlBusy ? '받는 중…' : '↻ 새로 받기'}</button><button type="button" class="primary" data-a="rlCfg">알림 설정${RLC.on ? '' : ' (꺼짐)'}</button>`)}${typeof flash === 'function' ? flash() : ''}
  ${RLD.err ? `<div class="ev-note"><span>슈프라이즈 목록을 못 받았어요 — ${esc(RLD.err)}</span></div>` : ''}
  <div class="stk-bar"><span class="ev-seg"><button type="button" class="chip${S0.tab !== 'up' ? ' on' : ''}" data-a="rlTab" data-v="rel">진행 중 응모 ${relN}</button><button type="button" class="chip${S0.tab === 'up' ? ' on' : ''}" data-a="rlTab" data-v="up">발매 예정 ${(RLD.up || []).length}</button></span>${S0.tab !== 'up' ? `<button type="button" class="chip${S0.kr ? ' on' : ''}" data-a="rlKr">국내만</button>${todayN ? `<span class="pill warn">오늘 마감 ${todayN}</span>` : ''}` : ''}<input data-k="rlQ" value="${esc(S0.q)}" placeholder="브랜드 · 상품명 · 품번 · 응모처" class="stk-q"><span class="topsp"></span><span class="small">${RLC.on ? `알림 켜짐 · 폰 ${nPh}대` : '알림 꺼짐'}</span></div>
  <div class="ev-grid rl-grid">${cards || `<div class="panel dl-empty"><span>${RLD.at ? (S0.tab === 'up' ? '발매 예정 상품이 없어요' : '지금 진행 중인 응모가 없어요') : '[↻ 새로 받기]를 누르면 발매 정보를 받아와요'}</span></div>`}</div>
  <p class="hint">출처: 슈프라이즈 공개 발매 정보 · 30분마다 새로 받아요 · 알림은 PC 킥스캔이 켜져 있을 때 보내요(폰 알림은 폰 앱 › 발매 탭에서 [알림 켜기])</p>`;
}
// 받아오기 + 새로 올라온 것 알림
async function rlLoad(quiet) {
  if (IS.rlBusy || !(window.kcApp && window.kcApp.drop)) return;
  IS.rlBusy = true; if (!quiet) { try { renderInv(); } catch (e) {} }
  let r = null;
  try { r = await window.kcApp.drop.list(); } catch (e) { RLD.err = String(e.message || e).slice(0, 120); }
  IS.rlBusy = false;
  if (r) {
    const F = RLD.first || {}, had = !!RLD.firstDone, now = Date.now(), fresh = [], freshUp = [];
    for (const x of r.rel) if (!F['r' + x.id]) { F['r' + x.id] = now; if (had) fresh.push(x); }
    for (const p of r.up) if (!F['u' + p.pid]) { F['u' + p.pid] = now; if (had) freshUp.push(p); }
    // 기억은 2주까지만
    for (const k of Object.keys(F)) if (now - F[k] > 14 * 864e5) delete F[k];
    RLD = { at: r.at || now, rel: r.rel, up: r.up, first: F, firstDone: true, base: RLD.base || now, err: '' };
    try { await store.set('rlData', RLD); } catch (e) {}
    try { await rlNotify(fresh, freshUp); } catch (e) {}
    if (!quiet) IS.msg = `발매 정보를 받았어요 — 진행 중 응모 ${new Set(r.rel.map(x => x.pid)).size}개 · 발매 예정 ${r.up.length}개${fresh.length || freshUp.length ? ` · 새로 올라온 것 ${fresh.length + freshUp.length}개` : ''}`;
  } else if (!quiet) IS.msg = '발매 정보를 못 받았어요 — ' + RLD.err;
  if (!quiet || (typeof curMode !== 'undefined' && curMode === 'inv' && typeof invView !== 'undefined' && invView === 'drops')) { try { renderInv(); } catch (e) {} }
}
async function rlNotify(fresh, freshUp) {
  if (!RLC.on) return;
  const F = (fresh || []).filter(x => !RLC.krOnly || x.kr), U = RLC.up ? (freshUp || []) : [];
  if (!F.length && !U.length) return;
  const G = {}; for (const x of F) (G[x.pid || x.id] = G[x.pid || x.id] || []).push(x);
  const groups = Object.values(G);
  const lines = groups.slice(0, 3).map(L => `${L[0].name || L[0].en}${L[0].code ? ` (${L[0].code})` : ''} — ${L[0].market}${L.length > 1 ? ` 외 ${L.length - 1}곳` : ''} · ${L[0].draw ? '추첨' : '선착순'}`);
  const ulines = U.slice(0, 3).map(p => `${p.name || p.en} · ${p.date ? p.date.slice(5).replace('-', '/') : '미정'} 발매`);
  const title = F.length ? `새 발매 응모 ${groups.length}개 상품${U.length ? ` · 발매 예정 ${U.length}개` : ''}` : `발매 예정 추가 ${U.length}개`;
  const body = [...lines, ...ulines].join('\n') + (groups.length + U.length > lines.length + ulines.length ? `\n외 ${groups.length + U.length - lines.length - ulines.length}개 — 발매 탭에서 보기` : '');
  if (typeof notiAdd1 === 'function') { await notiAdd1(title, body.replace(/\n/g, ' · ')); try { notiBadge(); } catch (e) {} }
  try { chrome.notifications.create('rl-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title, message: body.slice(0, 220), priority: 1 }); } catch (e) {}
  if (typeof pushSend === 'function') await pushSend('drop', title, body, './?t=drop', 'drop-' + Date.now());
}
async function rlAct(a, el) {
  const S0 = rlS(), v = el.dataset.v;
  switch (a) {
    case 'rlLoad': return rlLoad(false);
    case 'rlTab': S0.tab = v; break;
    case 'rlKr': S0.kr = !S0.kr; break;
    case 'rlCfg': {
      const nPh = typeof pushCount === 'function' ? pushCount() : 0, last = typeof PSH !== 'undefined' && PSH.last ? PSH.last : null;
      return invDialog('발매 알림 설정', `<p class="hint">새 응모 · 선착순 · 발매 예정이 올라오면 알림 종 · 윈도우 알림 · 폰 알림으로 알려요. 밤 10시~아침 8시에는 윈도우 · 폰 알림을 쉬어요(설정 › 알림 규칙).</p>
        <div class="ev-favs"><label class="chip${RLC.on ? ' on' : ''}"><input type="checkbox" name="on"${RLC.on ? ' checked' : ''}> 발매 알림 켜기</label><label class="chip${RLC.krOnly ? ' on' : ''}"><input type="checkbox" name="kr"${RLC.krOnly ? ' checked' : ''}> 국내 응모만 알리기</label><label class="chip${RLC.up ? ' on' : ''}"><input type="checkbox" name="up"${RLC.up ? ' checked' : ''}> 발매 예정 추가도 알리기</label></div>
        <p class="small">폰 알림: ${nPh ? `켠 폰 ${nPh}대` : '아직 켠 폰이 없어요 — 폰 앱(킥스캔 계정으로 로그인) › 발매 탭 › [알림 켜기]'}${last ? ` · 마지막 보냄 ${lkAgo(last.at)} (${last.status === 201 || last.status === 200 ? '성공' : esc(String(last.status || last.err || ''))})` : ''}</p>
        ${nPh ? '<button type="button" class="ghost small" data-rltest="1">폰으로 시험 알림 보내기</button> <span class="small" data-rltmsg></span>' : ''}`, async fd => {
        RLC = { on: fd.on === 'on', krOnly: fd.kr === 'on', up: fd.up === 'on' };
        await store.set('rlCfg', RLC); IS.msg = RLC.on ? '발매 알림을 켰어요' : '발매 알림을 껐어요'; renderInv();
      });
      const tb = document.querySelector('#invDlg [data-rltest]');
      if (tb) tb.addEventListener('click', async () => {
        const m = document.querySelector('#invDlg [data-rltmsg]'); tb.disabled = true; if (m) m.textContent = '보내는 중…';
        const r = typeof pushSend === 'function' ? await pushSend('drop', '킥스캔 시험 알림', '폰 알림이 잘 와요 — 새 발매가 올라오면 이렇게 알려 드려요', './?t=drop', 'test-' + Date.now(), true) : null;
        if (m) m.textContent = r && r.ok ? `폰 ${r.ok}대에 보냈어요` : `못 보냈어요${r && r.why ? ' — ' + r.why : ''}`; tb.disabled = false;
      });
      return;
    }
  }
  renderInv();
}
function rlInput(el, ev) {
  const S0 = rlS(), k = el.dataset.k;
  if (k === 'rlQ') { S0.q = el.value; clearTimeout(rlInput.t); rlInput.t = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=rlQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, ev.type === 'input' ? 300 : 0); }
}
(async function rlBoot() {
  try { RLD = (await store.get('rlData', null)) || RLD; RLC = { ...RLC, ...((await store.get('rlCfg', null)) || {}) }; } catch (e) {}
  setTimeout(() => { if (Date.now() - (RLD.at || 0) > RL_TTL - 60e3) rlLoad(true).catch(() => {}); }, 45e3);
  setInterval(() => { if (Date.now() - (RLD.at || 0) > RL_TTL - 60e3) rlLoad(true).catch(() => {}); }, 5 * 60e3);
})();
