'use strict';
/* 개선판 1-11 · 1-12: 실행 편의(설정 › 일반) · 휴가 모드 · 긴급 정지 · 시작 가이드
   - 'ops'     = { vac: 휴가 모드, halt: 긴급 정지, haltAt } — 프로그램에서는 본체(main-core)가 적고, 킥스캔 확장에서는 이 화면이 적어요
   - 'opsPref' = { idleDefer: PC 사용 중이면 예약 미루기(기본 켬), feeOk: 시작 가이드 '수수료 확인' }
   프로그램 전용 기능(자동 실행 · 트레이 · 절전 · 화면 크기 · 브라우저 창)은 window.kcApp.ops 가 있을 때만 보여요. */
const OPS_APP = !!(window.__KC_APP && window.kcApp && window.kcApp.ops);
let OPS = { vac: false, halt: false, haltAt: 0 };
let OPP = { idleDefer: true, catchUp: true, feeOk: false };

// 자동 작업이 지금 돌아도 되는지 — 막히면 이유(문구), 아니면 ''
// kind: sched(소싱 예약) · abid(자동 입찰) · sq(보관 자동 신청) · orders(주문 자동 동기화) · track(가격 추적) · keep(로그인 유지) · sales(판매 내역 갱신)
function opsBlock(kind) {
  if (OPS.halt) return '긴급 정지 중이라 멈춰 있어요';
  if (OPS.vac && kind !== 'keep' && kind !== 'sales') return '휴가 모드라 쉬고 있어요';
  return '';
}

// ---------- PC 사용 중이면 예약 미루기 (10분 안에 입력이 있으면 30분 뒤로, 최대 4번) ----------
let opsDef = { due: 0, until: 0, n: 0 };
async function opsDefer(due) {
  if (opsDef.due !== due) opsDef = { due, until: 0, n: 0 };
  if (Date.now() < opsDef.until) return true;
  if (!OPS_APP || OPP.idleDefer === false || opsDef.n >= 4) return false;
  let idle = -1; try { idle = await window.kcApp.ops.idle(); } catch (e) {}
  if (idle >= 0 && idle < 600) { opsDef.n++; opsDef.until = Date.now() + 30 * 60e3; try { schedPaint(); } catch (e) {} return true; }
  return false;
}
function opsDeferTxt() {
  if (!(opsDef.until > Date.now())) return '';
  return ` · PC 사용 중이라 ${new Date(opsDef.until).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}로 미뤘어요`;
}

// ---------- 긴급 정지 ----------
// 이 화면 안에서 도는 것부터 바로 멈춰요 (자동 입찰 끄기 · 보관 자동 신청 · 찾기 · 줄 선 작업 · 작업 창)
async function opsHaltLocal() {
  OPS.halt = true;
  try { if (typeof AB !== 'undefined') { AB.run = false; AB.next = 0; abOpt.run = false; if (typeof abSave === 'function') abSave().catch(() => {}); if (typeof abSet === 'function') abSet('긴급 정지로 자동 입찰을 껐어요'); } } catch (e) {}
  try { if (typeof SQ !== 'undefined') SQ.run = false; } catch (e) {}
  try { stopFlag = true; } catch (e) {}
  try { const b = $('#btnFindStop'); if (b && !b.hidden) b.click(); } catch (e) {}
  try { await jobStopAll(); } catch (e) {}
  opsBusySync(true); opsPaint();
  try { if (typeof renderX === 'function' && curMode !== 'inv') renderX(); } catch (e) {}
}
async function opsHalt() {
  const t0 = Date.now();
  OPS = { ...OPS, halt: true, haltAt: t0 };
  const local = opsHaltLocal();
  let r = null;
  if (OPS_APP) { try { r = await window.kcApp.ops.halt(); } catch (e) {} }
  else await store.set('ops', OPS);
  await local;
  const ms = Date.now() - t0;
  opsSay(`모든 자동 작업을 멈췄어요 (${(ms / 1000).toFixed(1)}초)${r && r.closed ? ` · 작업 창 ${r.closed}개 닫음` : ''}`);
  return { ms, closed: r ? r.closed : 0 };
}
async function opsResume() {
  if (OPS_APP) { try { OPS = { ...OPS, ...(await window.kcApp.ops.resume()) }; } catch (e) {} }
  else { OPS = { ...OPS, halt: false, haltAt: 0 }; await store.set('ops', OPS); }
  OPS.halt = false; opsPaint();
  opsSay('다시 시작했어요. 자동 입찰은 자동 입찰 화면에서 다시 켜 주세요');
}
async function opsSetVac(on) {
  if (OPS_APP) { try { OPS = { ...OPS, ...(await window.kcApp.ops.vac(!!on)) }; } catch (e) {} }
  else { OPS = { ...OPS, vac: !!on }; await store.set('ops', OPS); }
  OPS.vac = !!on; opsPaint();
  opsSay(on ? '휴가 모드를 켰어요. 판매 내역 갱신만 돌아요' : '휴가 모드를 껐어요');
}
// 다른 창(트레이 · 다른 킥스캔 창)에서 바뀐 것 받기
function opsApply(st) {
  if (!st) return;
  const was = OPS.halt; OPS = { ...OPS, ...st };
  if (OPS.halt && !was) opsHaltLocal();
  opsPaint();
}

// ---------- 작업 중 절전 막기: 자동 작업이 도는 동안만 본체에 알려요 ----------
let opsBusyNow = null;
function opsBusySync(force) {
  if (!OPS_APP) return;
  let b = false;
  try { b = (typeof jobBusy !== 'undefined' && jobBusy > 0) || (typeof AB !== 'undefined' && AB.run) || (typeof SQ !== 'undefined' && SQ.run) || (typeof fdSchedBusy !== 'undefined' && fdSchedBusy); } catch (e) {}
  if (OPS.halt) b = false;
  if (b === opsBusyNow && !force) return;
  opsBusyNow = b; try { window.kcApp.ops.busy(b); } catch (e) {}
}

// ---------- 화면: 위쪽 표시줄 · 설정 › 일반 ----------
function opsSay(t) { const m = $('#opsMsg'); if (m) m.textContent = t; }
function opsPaint() {
  const bar = $('#opsBar');
  if (bar) {
    if (OPS.halt) { bar.hidden = false; bar.innerHTML = `<b>긴급 정지 중이에요</b><span class="small">자동 입찰 · 예약 · 자동 동기화가 모두 멈춰 있어요.</span><button type="button" class="ghost small" data-ops="resume">다시 시작</button>`; }
    else if (OPS.vac) { bar.hidden = false; bar.innerHTML = `<b>휴가 모드예요</b><span class="small">자동 입찰 · 자동 등록 · 예약은 쉬고, 판매 내역 갱신만 돌아요.</span><button type="button" class="ghost small" data-ops="vacOff">휴가 모드 끄기</button>`; }
    else { bar.hidden = true; bar.innerHTML = ''; }
  }
  const h = $('#btnHalt'), r = $('#btnHaltResume'), v = $('#o_vac');
  if (h) h.hidden = !!OPS.halt; if (r) r.hidden = !OPS.halt; if (v) v.value = OPS.vac ? '1' : '0';
  try { schedPaint(); } catch (e) {}
}
async function opsFill() {
  const box = $('#opsGen'); if (!box) return;
  box.querySelectorAll('[data-app]').forEach(el => { el.hidden = !OPS_APP; });
  $('#o_idleDefer').value = OPP.idleDefer === false ? '0' : '1';
  if ($('#o_catchUp')) $('#o_catchUp').value = OPP.catchUp === false ? '0' : '1';
  if (OPS_APP) {
    try {
      const g = await window.kcApp.ops.get();
      $('#o_autoStart').value = g.autoStart ? '1' : '0'; $('#o_trayKeep').value = g.trayKeep ? '1' : '0'; $('#o_noSleep').value = g.noSleep ? '1' : '0';
      $('#o_zoom').value = String(g.zoom); $('#o_cdpShow').value = g.cdpShow ? '1' : '0';
      if (g.ops) OPS = { ...OPS, ...g.ops };
    } catch (e) {}
  }
  opsPaint();
}
function opsBind() {
  const box = $('#opsGen');
  if (box) box.addEventListener('change', async e => {
    const el = e.target; if (!el || !el.id || !el.id.startsWith('o_')) return;
    const k = el.id.slice(2), v = el.value;
    if (k === 'vac') return opsSetVac(v === '1');
    if (k === 'catchUp') { OPP.catchUp = v === '1'; await store.set('opsPref', OPP); return opsSay(v === '1' ? '놓친 예약은 다음에 켤 때 바로 한 번 실행해요' : '놓친 예약은 건너뛰어요'); }
    if (k === 'idleDefer') { OPP.idleDefer = v === '1'; await store.set('opsPref', OPP); return opsSay(v === '1' ? 'PC를 쓰고 있으면 예약을 30분씩 미뤄요' : '예약은 정한 시각에 바로 돌아요'); }
    if (!OPS_APP) return;
    const o = { [k]: k === 'zoom' ? +v : v === '1' };
    try { await window.kcApp.ops.set(o); opsSay('바꿨어요'); } catch (er) { opsSay('바꾸지 못했어요 — ' + er.message); }
    opsFill();
  });
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-ops]'); if (b) { const a = b.dataset.ops; if (a === 'resume') opsResume(); if (a === 'vacOff') opsSetVac(false); return; }
    const g = e.target.closest('[data-sg]'); if (g) sgAct(g.dataset.sg, g);
  });
  if ($('#btnHalt')) $('#btnHalt').addEventListener('click', () => opsHalt());
  if ($('#btnHaltResume')) $('#btnHaltResume').addEventListener('click', () => opsResume());
  if ($('#btnStartGuide')) $('#btnStartGuide').addEventListener('click', () => sgOpen());
  if ($('#btnSettings')) $('#btnSettings').addEventListener('click', () => { if (!$('#settings').hidden) opsFill(); });
}

// ---------- 1-12 시작 가이드: 단계 완료는 실제 데이터로 판단해요 ----------
const SG_STEPS = [
  { k: 'acct', t: '계정 연결', d: '쇼핑몰 · 크림 계정을 저장하고 로그인해요. 하나라도 ONLINE이면 끝이에요.', go: 'acct',
    ok: () => typeof ACCTS !== 'undefined' && ACCTS.some(A => (acctState[A.k] || {}).st === 'on') },
  { k: 'shop', t: '구매처 고르기', d: '주문을 불러올 구매처(무신사 · 지그재그 등)를 골라요.', go: 'inv:ms',
    ok: () => typeof INV !== 'undefined' && Array.isArray(INV.opt.ordSites) && INV.opt.ordSites.length > 0 },
  { k: 'buy', t: '첫 매입 등록', d: '산 상품을 입고로 넣어요. 구매처 주문 불러오기로도 돼요.', go: 'inv:io',
    ok: () => typeof INV !== 'undefined' && INV.lots.length > 0 },
  { k: 'sell', t: '판매처 연결', d: '크림에 로그인해 두면 시세 · 입찰 · 판매 내역을 읽어요.', go: 'acct',
    ok: () => typeof acctState !== 'undefined' && (acctState.kream || {}).st === 'on' },
  { k: 'fee', t: '수수료 확인', d: '설정에서 수수료율 · 발송비가 내 크림 등급과 맞는지 보고 [확인했어요]를 눌러요.', go: 'settings',
    ok: () => !!OPP.feeOk },
  { k: 'sale', t: '첫 판매 기록', d: '팔린 상품을 출고로 넣거나 크림 판매 내역을 불러와요.', go: 'inv:io',
    ok: () => typeof INV !== 'undefined' && INV.outs.length > 0 }
];
function sgState() { const L = SG_STEPS.map(s => { let ok = false; try { ok = !!s.ok(); } catch (e) {} return { ...s, done: ok }; }); return { L, n: L.filter(s => s.done).length }; }
// 홈 · 가이드 위에 붙이는 한 줄 (다 끝났으면 안 보여요)
function sgLine() {
  const { L, n } = sgState(); if (n >= L.length) return '';
  const nx = L.find(s => !s.done);
  return `<div class="row-btns sg-line"><span class="hint">시작 가이드 ${n}/${L.length} — 다음: ${esc(nx.t)}</span><button type="button" class="ghost small" data-sg="open">이어서 하기</button></div>`;
}
function sgPaint() {
  const w = $('#sgWiz'); if (!w || w.hidden) return;
  const { L, n } = sgState();
  $('#sgBar').style.width = Math.round(n / L.length * 100) + '%';
  $('#sgSub').textContent = n >= L.length ? '다 끝났어요. 이제 킥스캔이 알아서 정리해요.' : `${L.length}단계 중 ${n}단계 끝났어요. 실제 데이터로 확인해요.`;
  $('#sgSteps').innerHTML = L.map((s, i) => `<li class="${s.done ? 'done' : ''}"><span class="wn">${i + 1}</span><div class="wb"><b>${esc(s.t)}</b><p class="hint">${esc(s.d)}</p>
    <div class="row-btns">${s.done ? '<span class="hint">끝났어요</span>' : `<button type="button" class="${L.findIndex(x => !x.done) === i ? 'primary' : 'ghost'} small" data-sg="go" data-v="${s.go}">바로 가기</button>${s.k === 'fee' ? '<button type="button" class="ghost small" data-sg="feeOk">확인했어요</button>' : ''}`}</div></div></li>`).join('');
}
function sgOpen() {
  let w = $('#sgWiz');
  if (!w) {
    w = document.createElement('div'); w.id = 'sgWiz'; w.className = 'wiz'; w.setAttribute('role', 'dialog'); w.setAttribute('aria-modal', 'true'); w.setAttribute('aria-labelledby', 'sgTitle'); w.hidden = true;
    w.innerHTML = `<div class="wizbox"><div class="wizhead"><div><h2 id="sgTitle">시작 가이드</h2><p class="hint" id="sgSub"></p></div><button type="button" class="ghost tiny" data-sg="close">닫기</button></div>
      <div class="bar"><span id="sgBar"></span></div><ol class="wzsteps" id="sgSteps"></ol></div>`;
    document.body.appendChild(w);
    w.addEventListener('click', e => { if (e.target === w) sgClose(); });
  }
  w.hidden = false; sgPaint();
}
function sgClose() { const w = $('#sgWiz'); if (w) w.hidden = true; }
async function sgAct(a, el) {
  if (a === 'open') return sgOpen();
  if (a === 'close') return sgClose();
  if (a === 'feeOk') { OPP.feeOk = true; await store.set('opsPref', OPP); return sgPaint(); }
  if (a === 'go') {
    sgClose(); const v = el.dataset.v;
    if (v === 'settings') { const p = $('#settings'); p.hidden = false; $('#btnSettings').setAttribute('aria-expanded', 'true'); opsFill(); p.scrollIntoView({ block: 'start' }); return; }
    route(v);
  }
}

async function opsInit() {
  OPS = { ...OPS, ...(await store.get('ops', {})) };
  OPP = { ...OPP, ...(await store.get('opsPref', {})) };
  opsBind();
  if (OPS_APP) { try { window.kcApp.ops.onChange(opsApply); } catch (e) {} }
  else { try { if (window.chrome && chrome.storage && chrome.storage.onChanged && chrome.storage.onChanged.addListener) chrome.storage.onChanged.addListener(ch => { if (ch && ch.ops) opsApply(ch.ops.newValue || {}); }); } catch (e) {} }
  if (OPS.halt) opsHaltLocal(); else opsPaint();
  setInterval(() => opsBusySync(false), 5000);
  setInterval(sgPaint, 3000);
}
