'use strict';
/* 킥스캔 — 재고관리 · 분석 (개선판 1-8)
   추이 · 이렇게 해 보세요 · 상품별 · 매장(매입처)별 · 사이즈별 · 판매처(매출처)별 · 반품률 + 월 결산 보고서
   계산은 inv.js 의 outNums · monthFigures · lgFigures 와 같은 기준이에요 (판매는 정산일, 매입은 입고일). */

const ANA_TABS = [['trend', '추이'], ['tip', '이렇게 해 보세요'], ['item', '상품별'], ['buy', '매장별'], ['size', '사이즈별'], ['sell', '판매처별'], ['ret', '반품률'], ['report', '월 결산 보고서']];
const ANA_PER = [['m0', '이번 달'], ['m1', '지난달'], ['m3', '3개월'], ['y', '올해'], ['all', '전체']];
const anaSt = () => IS.ana || (IS.ana = { tab: 'trend', per: 'm0', mon: '' });
const anaSg = n => (n > 0 ? '+' : '') + wonS(n);
const anaPct = (a, b) => b ? Math.round(a / b * 1000) / 10 + '%' : '–';
const anaQ = n => Number.isInteger(n) ? String(n) : (Math.round(n * 10) / 10).toString();

function anaRange(p) {
  const t = today();
  if (p === 'm1') { const s = monthStart(addDays(monthStart(t), -1)); return [s, monthEnd(s)]; }
  if (p === 'm3') { const d = new Date(monthStart(t) + 'T00:00:00'); d.setMonth(d.getMonth() - 2); return [fmtD(d), monthEnd(t)]; }
  if (p === 'y') return [t.slice(0, 4) + '-01-01', t.slice(0, 4) + '-12-31'];
  if (p === 'all') { const ds = [...INV.lots.map(l => l.date), ...INV.outs.map(o => o.settleDate || o.date)].filter(Boolean).sort(); return [ds[0] && ds[0] < t ? ds[0] : monthStart(t), ds.length && ds[ds.length - 1] > t ? ds[ds.length - 1] : t]; }
  return [monthStart(t), monthEnd(t)];
}

// 묶음 계산 — kind: item(상품) · size(사이즈) · buy(매입처) · sell(판매처)
function anaGroups(a, b, kind, C) {
  C = C || invCalc();
  const lotById = new Map(INV.lots.map(l => [l.id, l])), G = new Map();
  const key = {
    item: (o, l) => (o || l).itemId,
    size: (o, l) => String((o || l).size),
    buy: (o, l) => l ? (l.partnerId || '-') : '-',
    sell: (o, l) => o ? (o.partnerId || '-') : null
  }[kind];
  const name = k => kind === 'item' ? itName(itemOf(k)) : kind === 'size' ? k : (partnerOf(k)?.name || (kind === 'buy' ? '매입처 없음' : '판매처 없음'));
  const grp = k => { let g = G.get(k); if (!g) G.set(k, g = { k, name: name(k), code: kind === 'item' ? (itemOf(k)?.code || '') : '', buyQ: 0, buy: 0, buyRet: 0, lotSold: 0, sold: 0, outQ: 0, retQ: 0, rev: 0, fees: 0, cogs: 0, ship: 0, margin: 0, dSum: 0, dN: 0, saleN: 0, lossN: 0, stockQ: 0, stockV: 0 }); return g; };
  for (const o of INV.outs) {
    if (!o.settled || !inRange(o.settleDate, a, b)) continue;
    const n = outNums(o), cs = (o.costs || []).filter(c => c.qty > 0), cq = cs.reduce((s, c) => s + c.qty, 0);
    const parts = cq ? cs.map(c => [lotById.get(c.lotId), c.qty / cq]) : [[null, 1]];
    for (const [l, f] of parts) {
      const k = key(o, l); if (k == null) continue;
      const g = grp(k);
      g.sold += n.net * f; g.outQ += o.qty * f; g.retQ += (o.retQty || 0) * f; g.rev += n.rev * f; g.fees += n.fees * f; g.cogs += n.cogs * f; g.ship += n.ship * f; g.margin += n.margin * f;
      if (l && l.date) { const d = Math.max(0, Math.round((new Date((o.date || o.settleDate) + 'T00:00:00') - new Date(l.date + 'T00:00:00')) / 864e5)); g.dSum += d * n.net * f; g.dN += n.net * f; }
    }
    if (n.net > 0) { const k = key(o, cq ? lotById.get(cs[0].lotId) : null); if (k != null) { const g = grp(k); g.saleN++; if (n.margin < 0) g.lossN++; } }
  }
  // 판매율: 팔렸다가 판매 반품된 수량은 빼요 (반품 수량을 그 판매가 쓴 입고에 나눠서)
  const retByLot = new Map();
  for (const o of INV.outs) { const rq = +o.retQty || 0, cs = o.costs || [], tq = cs.reduce((x, c) => x + (+c.qty || 0), 0); if (rq && tq) for (const c of cs) if (c.lotId) retByLot.set(c.lotId, (retByLot.get(c.lotId) || 0) + rq * c.qty / tq); }
  if (kind !== 'sell') for (const l of INV.lots) {
    if (!lotIsBuy(l) || !inRange(l.date, a, b)) continue;
    const g = grp(key(null, l));
    g.buyQ += l.qty; g.buy += l.qty * l.cost; g.buyRet += l.retQty || 0; g.lotSold += Math.max(0, (C.used.get(l.id) || 0) - (retByLot.get(l.id) || 0));
  }
  if (kind !== 'sell') for (const l of INV.lots) { const left = C.left.get(l.id) || 0; if (left <= 0) continue; const g = G.get(key(null, l)); if (g) { g.stockQ += left; g.stockV += left * l.cost; } }
  for (const g of G.values()) { g.unit = g.sold ? g.margin / g.sold : null; g.rate = (g.buyQ - g.buyRet) > 0 ? g.lotSold / (g.buyQ - g.buyRet) : null; g.days = g.dN ? g.dSum / g.dN : null; }
  return [...G.values()];
}

function anaTbl(cols, rows, empty) {
  if (!rows.length) return `<div class="panel dl-empty">${ico('chart')}<span>${empty || '이 기간에 판매 · 매입 기록이 없어요.'}</span></div>`;
  return `<div class="tbl kh-tbl"><table><thead><tr>${cols.map(([t, , l]) => `<th${l ? ' class="l"' : ''}>${t}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${cols.map(([, f, l]) => `<td${l ? ' class="l"' : ''}>${f(r)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
const anaM = v => v == null ? '–' : `<b class="${v > 0 ? 'pos' : v < 0 ? 'neg' : ''}">${anaSg(v)}</b>`;
const anaNm = g => `<b>${esc(g.name)}</b>${g.code ? ` <span class="code">${esc(g.code)}</span>` : ''}`;

// ---------- 이렇게 해 보세요 (규칙 기반 제안 — 모든 줄에 근거 숫자) ----------
function anaTips(a, b, C) {
  const T = [], items = anaGroups(a, b, 'item', C), sells = anaGroups(a, b, 'sell', C), buys = anaGroups(a, b, 'buy', C), sizes = anaGroups(a, b, 'size', C);
  for (const g of items) if (g.rate != null && g.rate >= 0.8 && g.sold > 0 && g.unit > 0)
    T.push(['기회', `${g.name} — 다음 매입 때 더 사도 돼요`, `산 ${anaQ(g.buyQ - g.buyRet)}개 중 ${anaQ(g.lotSold)}개 팔림 (${anaPct(g.lotSold, g.buyQ - g.buyRet)}) · 개당 ${anaSg(g.unit)}`]);
  for (const g of items) if (g.days != null && g.days <= 7 && g.sold >= 2 && g.unit > 0)
    T.push(['기회', `${g.name} — 빨리 팔려요. 재고를 끊기지 않게 챙겨 보세요`, `평균 ${Math.round(g.days)}일 만에 팔림 · ${anaQ(g.sold)}개 · 개당 ${anaSg(g.unit)}`]);
  const SZ = sizes.filter(g => g.rate != null && g.buyQ >= 2).sort((x, y) => y.rate - x.rate);
  if (SZ.length >= 2 && SZ[0].rate >= 0.8) T.push(['기회', `${SZ[0].name} 사이즈가 잘 팔려요`, `산 ${anaQ(SZ[0].buyQ - SZ[0].buyRet)}개 중 ${anaQ(SZ[0].lotSold)}개 팔림 (${anaPct(SZ[0].lotSold, SZ[0].buyQ - SZ[0].buyRet)})`]);
  const S = sells.filter(g => g.sold >= 1 && g.unit != null).sort((x, y) => y.unit - x.unit);
  if (S.length >= 2 && S[0].unit - S[S.length - 1].unit >= 5000) { const hi = S[0], lo = S[S.length - 1]; T.push(['참고', `${hi.name}에 팔 때 개당 ${won(hi.unit - lo.unit)} 더 남았어요`, `${hi.name} 개당 ${anaSg(hi.unit)} (${anaQ(hi.sold)}개) · ${lo.name} 개당 ${anaSg(lo.unit)} (${anaQ(lo.sold)}개)`]); }
  const BU = buys.filter(g => g.sold >= 1 && g.unit != null && g.k !== '-').sort((x, y) => y.unit - x.unit);
  if (BU.length >= 2 && BU[0].unit - BU[BU.length - 1].unit >= 5000) { const hi = BU[0], lo = BU[BU.length - 1]; T.push(['참고', `${hi.name}에서 산 물건이 개당 ${won(hi.unit - lo.unit)} 더 남았어요`, `${hi.name} 개당 ${anaSg(hi.unit)} (${anaQ(hi.sold)}개) · ${lo.name} 개당 ${anaSg(lo.unit)} (${anaQ(lo.sold)}개)`]); }
  const lowSz = sizes.filter(g => g.rate != null && g.buyQ >= 3 && g.rate <= 0.3);
  for (const g of lowSz) T.push(['참고', `${g.name} 사이즈는 덜 팔려요. 매입을 줄여 보세요`, `산 ${anaQ(g.buyQ - g.buyRet)}개 중 ${anaQ(g.lotSold)}개 팔림 (${anaPct(g.lotSold, g.buyQ - g.buyRet)}) · 남은 ${g.stockQ}개`]);
  const old = INV.lots.filter(l => (C.left.get(l.id) || 0) > 0 && dday(addDays(l.date, 60)) < 0);
  if (old.length) { const q = old.reduce((s, l) => s + C.left.get(l.id), 0), v = old.reduce((s, l) => s + C.left.get(l.id) * l.cost, 0); T.push(['주의', '60일이 넘은 재고가 있어요. 값을 낮춰서라도 정리해 보세요', `${q}개 · 원가 ${won(v)} (지금 기준)`]); }
  const due = INV.lots.filter(l => typeof retOpen === 'function' && retOpen(l, C) && dday(l.returnDue) >= 0 && dday(l.returnDue) <= 3);
  if (due.length) { const q = due.reduce((s, l) => s + C.left.get(l.id), 0), v = due.reduce((s, l) => s + C.left.get(l.id) * l.cost, 0); T.push(['주의', '반품 기한이 3일 안에 끝나는 재고가 있어요. 팔지 반품할지 정해 주세요', `${q}개 · 원가 ${won(v)} (지금 기준)`]); }
  for (const g of items) if (g.saleN >= 1 && g.lossN === g.saleN && g.margin < 0)
    T.push(['주의', `${g.name} — 팔 때마다 손해예요. 매입가나 판매가를 다시 봐 주세요`, `${anaQ(g.sold)}개 판매 · 개당 ${anaSg(g.unit)} · 합계 ${wonS(g.margin)}`]);
  for (const g of buys) if (g.k !== '-' && g.buyQ >= 3 && g.buyRet / g.buyQ >= 0.2)
    T.push(['주의', `${g.name} 매입 반품이 잦아요`, `${g.buyQ}개 중 ${g.buyRet}개 반품 (${anaPct(g.buyRet, g.buyQ)})`]);
  for (const g of sells) if (g.outQ >= 3 && g.retQ / g.outQ >= 0.1)
    T.push(['주의', `${g.name} 판매 반품이 잦아요`, `${anaQ(g.outQ)}개 중 ${anaQ(g.retQ)}개 반품 (${anaPct(g.retQ, g.outQ)})`]);
  return T;
}

// ---------- 월 결산 ----------
function anaMonth(mon) {
  const a = mon + '-01', b = monthEnd(a), f = lgFigures(a, b), C = invCalc();
  let buyN = 0, buyQ = 0, buyGross = 0, bRetQ = 0, bRetV = 0, outQ = 0, sRetQ = 0, sRetV = 0, lotQ = 0, lotRet = 0;
  for (const l of INV.lots) {
    if (lotIsBuy(l) && inRange(l.date, a, b)) { buyN++; buyQ += l.qty; buyGross += l.qty * l.cost; lotQ += l.qty; lotRet += l.retQty || 0; }
    for (const e of l.events || []) if (e.t === '반품' && inRange(e.d, a, b)) { bRetQ += +e.q || 0; bRetV += (+e.q || 0) * l.cost; }
  }
  for (const o of INV.outs) {
    if (o.settled && inRange(o.settleDate, a, b)) { outQ += o.qty; }
    for (const e of o.events || []) if (e.t === '반품' && inRange(e.d, a, b)) { sRetQ += +e.q || 0; sRetV += (+e.q || 0) * (o.price - (o.disc || 0)); }
  }
  let exp = f.exp;   // 장부 합계(lgFigures)에 수기 지출 + 지출 탭(INV.expenses)이 이미 들어 있어요
  const profit = f.margin + f.inc - exp;
  const items = anaGroups(a, b, 'item', C).filter(g => g.sold > 0).sort((x, y) => y.margin - x.margin);
  return { a, b, f, buyN, buyQ, buyGross, bRetQ, bRetV, outQ, sRetQ, sRetV, exp, profit, sRate: anaPct(sRetQ, outQ), bRate: anaPct(lotRet, lotQ), items };
}
function anaReportHtml(R, mon) {
  const f = R.f, row = (k, v, s = '') => `<tr><td class="l">${k}</td><td>${v}</td><td class="l small">${s}</td></tr>`;
  const sec = (t, rows) => `<h3>${t}</h3><div class="tbl"><table><tbody>${rows}</tbody></table></div>`;
  const y = mon.slice(0, 4), m = +mon.slice(5, 7);
  return `<h2>${y}년 ${m}월 결산</h2><p class="hint">${R.a} ~ ${R.b} · ${esc((bizCur() || {}).name || '')} · 만든 날 ${today()}</p>
  <div class="kgrid">${card('매입', won(f.buy), 'warn', `${R.buyQ}개 · 반품 뺀 금액`)}${card('매출', won(f.rev), 'acc', `${f.sold}개 판매`)}${card('지출', won(R.exp), R.exp ? 'neg' : '', '택배비 · 유류비 등 + 수기 지출')}${card('손익', wonS(R.profit), R.profit >= 0 ? 'pos' : 'neg', `마진율 ${f.rate.toFixed(1)}%`)}</div>
  <div class="igrid2"><div>${sec('매입', row('입고', `${R.buyN}건 · ${R.buyQ}개`) + row('매입 금액', won(R.buyGross)) + row('매입 반품', `${R.bRetQ}개 · ${won(R.bRetV)}`, '반품일 기준') + row('순매입', won(f.buy)))}
  ${sec('판매', row('판매 (반품 뺌)', `${f.sold}개`) + row('매출', won(f.rev)) + row('수수료', won(f.fees)) + row('정산액', won(f.settle)) + row('택배비', won(f.ship)) + row('상품 마진', wonS(f.margin)))}</div>
  <div>${sec('손익', row('상품 마진', wonS(f.margin)) + row('수기 수입', won(f.inc)) + row('지출', R.exp ? '−' + won(R.exp) : '0원') + row('<b>손익</b>', `<b>${wonS(R.profit)}</b>`, '마진 + 수입 − 지출'))}
  ${sec('반품률', row('판매 반품률', R.sRate, `이 달 판매 ${R.outQ}개 중 반품 ${R.sRetQ}개 · ${won(R.sRetV)}`) + row('매입 반품률', R.bRate, '이 달 입고분 기준'))}</div></div>
  <h3>많이 남긴 상품</h3>${R.items.length ? `<div class="tbl"><table><thead><tr><th class="l">상품</th><th>판매</th><th>매출</th><th>마진</th><th>개당</th></tr></thead><tbody>${R.items.slice(0, 8).map(g => `<tr><td class="l">${esc(g.name)}</td><td>${anaQ(g.sold)}개</td><td>${won(g.rev)}</td><td>${wonS(g.margin)}</td><td>${anaSg(g.unit)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="hint">이 달 판매가 없어요.</p>'}`;
}
const ANA_PRINT_CSS = `@page{size:A4;margin:14mm}body{font-family:'Pretendard','Malgun Gothic',sans-serif;color:#111;font-size:11.5px;margin:0}h2{font-size:20px;margin:0 0 2px}h3{font-size:13px;margin:12px 0 4px}.hint,.small{color:#666;font-size:10.5px}
.kgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:10px 0}.kcard{border:1px solid #ccc;border-radius:6px;padding:6px 8px}.kc-top{font-size:10.5px;color:#555}.kcard b{display:block;font-size:15px}.kcard small{color:#777;font-size:10px}.kc-ic,.kc-line{display:none}
.igrid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #e3e3e3;padding:3px 5px;text-align:right}.l{text-align:left}th{background:#f3f3f3}.neg{color:#c00}.pos{color:#080}`;
function anaPrint(html, title) {
  const fr = document.createElement('iframe'); fr.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0'; document.body.appendChild(fr);
  const d = fr.contentDocument; d.open(); d.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>${ANA_PRINT_CSS}</style></head><body>${html}</body></html>`); d.close();
  setTimeout(() => { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (e) { IS.msg = '인쇄 창을 못 열었어요: ' + e.message; renderInv(); } setTimeout(() => fr.remove(), 60000); }, 300);
}
function anaXlSheets(R, mon) {
  const f = R.f;
  return [
    { name: '월 결산', rows: [['항목', '값', '비고'], ['기간', `${R.a} ~ ${R.b}`, ''], ['입고 건수', R.buyN, ''], ['입고 수량', R.buyQ, ''], ['매입 금액', Math.round(R.buyGross), ''], ['매입 반품 수량', R.bRetQ, '반품일 기준'], ['매입 반품 금액', Math.round(R.bRetV), ''], ['순매입', Math.round(f.buy), ''],
      ['판매 수량', f.sold, '반품 뺌'], ['매출', Math.round(f.rev), ''], ['수수료', Math.round(f.fees), ''], ['정산액', Math.round(f.settle), ''], ['택배비', Math.round(f.ship), ''], ['상품 마진', Math.round(f.margin), ''], ['수기 수입', Math.round(f.inc), ''], ['지출', Math.round(R.exp), ''], ['손익', Math.round(R.profit), '마진 + 수입 − 지출'],
      ['판매 반품률', R.sRate, `판매 ${R.outQ}개 중 ${R.sRetQ}개`], ['매입 반품률', R.bRate, '이 달 입고분 기준']], widths: [18, 18, 30] },
    { name: '상품별', rows: [['상품', '품번', '판매', '매출', '수수료', '매입원가', '마진', '개당 수익'], ...R.items.map(g => [g.name, g.code, Math.round(g.sold * 10) / 10, Math.round(g.rev), Math.round(g.fees), Math.round(g.cogs), Math.round(g.margin), Math.round(g.unit || 0)])], widths: [30, 16, 8, 12, 12, 12, 12, 12] }
  ];
}

// ---------- 화면 ----------
function vAna(C) {
  const A = anaSt(), tab = A.tab;
  const H = head('분석', '판매 · 매입 기록으로 무엇이 잘 남는지 보여 드려요. 판매는 정산일, 매입은 입고일 기준이에요.') + flash()
    + `<div class="subtabs">${ANA_TABS.map(([k, t]) => `<button type="button" data-a="anaTab" data-v="${k}" aria-selected="${tab === k}">${t}</button>`).join('')}</div>`;
  if (tab === 'report') return H + vAnaReport();
  const [a, b] = anaRange(A.per);
  const bar = `<div class="panel kh-bar"><div class="kh-row"><span class="kh-lab">${ico('cal')}기간</span><div class="dl-seg">${ANA_PER.map(([k, t]) => `<button type="button" data-a="anaPer" data-v="${k}" aria-pressed="${A.per === k}">${t}</button>`).join('')}</div><span class="sub">${a} ~ ${b}</span></div></div>`;
  let body = '';
  if (tab === 'trend') {
    const f = lgFigures(a, b), pts = lgSeries(a, b);
    body = `<div class="kgrid">${card('매출', won(f.rev), 'acc', f.sold + '개 판매')}${card('매입', won(f.buy), 'warn')}${card('마진', wonS(f.margin), f.margin >= 0 ? 'pos' : 'neg', `마진율 ${f.rate.toFixed(1)}%`)}${card('개당 마진', f.sold ? anaSg(f.margin / f.sold) : '–', '', '판매 1개당')}</div>
    <div class="box lg-cbox"><div class="lg-ch"><h3>매출 / 매입 / 마진 추이</h3><div class="lg-leg"><span><i class="r"></i>매출</span><span><i class="b"></i>매입</span><span><i class="m"></i>마진</span></div></div>${pts.length ? lgChart(pts) : '<p class="hint">기록이 없어요</p>'}</div>
    ${anaTbl([['기간', p => esc(p.l), 1], ['판매', p => p.sold + '개'], ['매출', p => won(p.rev)], ['매입', p => won(p.buy)], ['마진', p => anaM(p.margin)]], pts.filter(p => p.sold || p.buy || p.rev).reverse())}`;
  } else if (tab === 'tip') {
    const T = anaTips(a, b, C), pc = { 기회: 'ok', 참고: 'mute', 주의: 'warn' };
    body = T.length ? `<div class="tbl kh-tbl"><table><thead><tr><th class="l">구분</th><th class="l">제안</th><th class="l">근거 숫자</th></tr></thead><tbody>${T.map(([k, s, n]) => `<tr><td class="l"><span class="pill ${pc[k]}">${k}</span></td><td class="l">${esc(s)}</td><td class="l small">${esc(n)}</td></tr>`).join('')}</tbody></table></div>`
      : `<div class="panel dl-empty">${ico('chart')}<span>아직 드릴 제안이 없어요. 판매 · 매입 기록이 쌓이면 보여 드려요.</span></div>`;
  } else if (tab === 'item') {
    const L = anaGroups(a, b, 'item', C).sort((x, y) => (y.margin - x.margin) || (y.buy - x.buy));
    body = anaTbl([['상품', anaNm, 1], ['매입', g => g.buyQ + '개'], ['판매', g => anaQ(g.sold) + '개'], ['판매율', g => g.rate == null ? '–' : anaPct(g.lotSold, g.buyQ - g.buyRet)], ['매출', g => won(g.rev)], ['마진', g => anaM(g.sold ? g.margin : null)], ['개당 수익', g => anaM(g.unit)], ['평균 판매일', g => g.days == null ? '–' : Math.round(g.days) + '일'], ['지금 재고', g => g.stockQ + '개']], L);
  } else if (tab === 'buy') {
    const L = anaGroups(a, b, 'buy', C).sort((x, y) => (y.buy - x.buy) || (y.margin - x.margin));
    body = anaTbl([['매장 (매입처)', anaNm, 1], ['매입', g => g.buyQ + '개'], ['매입 금액', g => won(g.buy)], ['매입 반품', g => g.buyRet ? `${g.buyRet}개 (${anaPct(g.buyRet, g.buyQ)})` : '–'], ['판매율', g => g.rate == null ? '–' : anaPct(g.lotSold, g.buyQ - g.buyRet)], ['판매', g => anaQ(g.sold) + '개'], ['마진', g => anaM(g.sold ? g.margin : null)], ['개당 수익', g => anaM(g.unit)], ['지금 재고', g => g.stockQ + '개']], L);
  } else if (tab === 'size') {
    const L = anaGroups(a, b, 'size', C).sort((x, y) => (parseFloat(x.name) || 0) - (parseFloat(y.name) || 0) || x.name.localeCompare(y.name));
    body = anaTbl([['사이즈', g => `<b>${esc(g.name)}</b>`, 1], ['매입', g => g.buyQ + '개'], ['판매', g => anaQ(g.sold) + '개'], ['판매율', g => g.rate == null ? '–' : anaPct(g.lotSold, g.buyQ - g.buyRet)], ['매출', g => won(g.rev)], ['마진', g => anaM(g.sold ? g.margin : null)], ['개당 수익', g => anaM(g.unit)], ['평균 판매일', g => g.days == null ? '–' : Math.round(g.days) + '일'], ['지금 재고', g => g.stockQ + '개']], L);
  } else if (tab === 'sell') {
    const L = anaGroups(a, b, 'sell', C).sort((x, y) => y.margin - x.margin);
    body = anaTbl([['판매처 (매출처)', anaNm, 1], ['판매', g => anaQ(g.sold) + '개'], ['매출', g => won(g.rev)], ['수수료', g => won(g.fees)], ['매입원가', g => won(g.cogs)], ['마진', g => anaM(g.margin)], ['마진율', g => g.rev ? (g.margin / g.rev * 100).toFixed(1) + '%' : '–'], ['개당 수익', g => anaM(g.unit)], ['반품', g => g.retQ ? `${anaQ(g.retQ)}개 (${anaPct(g.retQ, g.outQ)})` : '–']], L, '이 기간에 정산된 판매가 없어요.');
  } else if (tab === 'ret') {
    const S = anaGroups(a, b, 'sell', C), B = anaGroups(a, b, 'buy', C), I = anaGroups(a, b, 'item', C);
    const so = S.reduce((s, g) => s + g.outQ, 0), sr = S.reduce((s, g) => s + g.retQ, 0), bq = B.reduce((s, g) => s + g.buyQ, 0), br = B.reduce((s, g) => s + g.buyRet, 0);
    body = `<div class="kgrid">${card('판매 반품률', anaPct(sr, so), sr ? 'warn' : '', `판매 ${anaQ(so)}개 중 ${anaQ(sr)}개`)}${card('매입 반품률', anaPct(br, bq), br ? 'warn' : '', `입고 ${bq}개 중 ${br}개`)}</div>
    <div class="igrid2"><div class="box"><h3>판매처별 판매 반품</h3>${anaTbl([['판매처', anaNm, 1], ['판매', g => anaQ(g.outQ) + '개'], ['반품', g => anaQ(g.retQ) + '개'], ['반품률', g => anaPct(g.retQ, g.outQ)]], S.filter(g => g.outQ).sort((x, y) => y.retQ / y.outQ - x.retQ / x.outQ), '판매가 없어요.')}</div>
    <div class="box"><h3>매장별 매입 반품</h3>${anaTbl([['매장', anaNm, 1], ['입고', g => g.buyQ + '개'], ['반품', g => g.buyRet + '개'], ['반품률', g => anaPct(g.buyRet, g.buyQ)]], B.filter(g => g.buyQ).sort((x, y) => y.buyRet / y.buyQ - x.buyRet / x.buyQ), '입고가 없어요.')}</div></div>
    <div class="box"><h3>상품별 반품</h3>${anaTbl([['상품', anaNm, 1], ['판매', g => anaQ(g.outQ) + '개'], ['판매 반품', g => anaQ(g.retQ) + '개'], ['판매 반품률', g => anaPct(g.retQ, g.outQ)], ['입고', g => g.buyQ + '개'], ['매입 반품', g => g.buyRet + '개'], ['매입 반품률', g => anaPct(g.buyRet, g.buyQ)]], I.filter(g => g.retQ || g.buyRet).sort((x, y) => (y.retQ + y.buyRet) - (x.retQ + x.buyRet)), '이 기간에 반품이 없어요.')}</div>`;
  }
  return H + bar + body;
}
function anaDefMon() { const t = today(); return +t.slice(8, 10) <= 5 ? addDays(monthStart(t), -1).slice(0, 7) : t.slice(0, 7); }
function vAnaReport() {
  const A = anaSt(); if (!A.mon) A.mon = anaDefMon();
  const R = anaMonth(A.mon);
  return `<div class="panel kh-bar"><div class="kh-row"><span class="kh-lab">${ico('cal')}결산 달</span><input type="month" data-k="anaMon" value="${A.mon}"><span class="topsp"></span><button type="button" class="primary" data-a="anaPdf">PDF 저장</button><button type="button" class="ghost" data-a="anaXl">엑셀 내려받기</button></div><p class="hint">PDF 저장을 누르면 인쇄 창이 떠요. 프린터에서 'PDF로 저장'(또는 Microsoft Print to PDF)을 골라 주세요.</p></div>
  <div class="box" style="max-width:860px">${anaReportHtml(R, A.mon)}</div>`;
}
async function anaAct(a, el) {
  const A = anaSt();
  if (a === 'anaTab') { A.tab = el.dataset.v; return renderInv(); }
  if (a === 'anaPer') { A.per = el.dataset.v; return renderInv(); }
  if (a === 'anaPdf' || a === 'anaXl') {
    if (!A.mon) A.mon = anaDefMon();
    const R = anaMonth(A.mon), nm = `킥스캔_월결산_${A.mon}`;
    if (a === 'anaPdf') return anaPrint(anaReportHtml(R, A.mon), nm);
    return xlDownload(anaXlSheets(R, A.mon), nm + '.xlsx');
  }
}
function anaInput(el) {
  if (el.dataset.k === 'anaMon' && /^\d{4}-\d{2}$/.test(el.value)) { anaSt().mon = el.value; renderInv(); }
}
