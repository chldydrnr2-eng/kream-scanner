// 소싱 개선 (설계서 1-3-1 · 1-6) — 할인 반영 매입가 · 결과 탭(수익 상품 / 확인 필요 / 전체) · 상세 패널 · 필터·저장 필터
// app.js 의 judgeItem · renderFinder 를 감싸서 붙여요 (app.js 는 finderRow 매입가 칸·줄 pid 만 연결).

// ---------- 순수 계산 (node 로 시험해요) ----------
// 할인 순서: 상품 쿠폰 → 장바구니·중복 쿠폰 → 등급 할인 → 적립금 선할인 → 결제 즉시할인
// 단계마다 '지금까지 깎인 값'에 %를 매기고(원 미만 버림) 정액(원)을 더해요. 최대(cap)가 있으면 그 이상은 안 깎고,
// 최소 주문 금액(min)보다 싸면 그 단계는 건너뛰어요. 깎는 값은 남은 값보다 클 수 없어요.
const SD_STEPS = [['coupon', '상품 쿠폰'], ['cart', '장바구니·중복 쿠폰'], ['grade', '등급 할인'], ['point', '적립금 선할인'], ['pay', '결제 즉시할인']];
function sdCalc(tag, cfg, on) {
  const t = Math.max(0, Math.round(+tag || 0));
  let p = t; const steps = [];
  for (const [k, label] of SD_STEPS) {
    const c = (cfg && cfg[k]) || {};
    if (on && on[k] === false) { steps.push({ k, label, amt: 0, off: true }); continue; }
    let a = Math.floor(p * (+c.pct || 0) / 100) + Math.round(+c.won || 0);
    if (+c.cap > 0) a = Math.min(a, Math.round(+c.cap));
    if (+c.min > 0 && p < +c.min) a = 0;
    a = Math.max(0, Math.min(a, p));
    p -= a; steps.push({ k, label, amt: a });
  }
  return { tag: t, steps, disc: t - p, final: p };
}
// 개당 수익 = 예상 판매가 − 판매처 수수료 − 발송비 − 할인 반영 매입가
function sdProfit(sell, fee, ship, buy) { return Math.round((+sell || 0) - (+fee || 0) - (+ship || 0) - (+buy || 0)); }
// 수익률(매입가 대비 %) · 수익 한도(개당 수익이 0 이 되는 매입가)
function sdRate(profit, buy) { return buy > 0 ? Math.round(profit / buy * 1000) / 10 : null; }
function sdLimit(sell, fee, ship) { return Math.round((+sell || 0) - (+fee || 0) - (+ship || 0)); }
if (typeof module !== 'undefined' && module.exports) module.exports = { sdCalc, sdProfit, sdRate, sdLimit, SD_STEPS };

// ---------- 화면 ----------
if (typeof document !== 'undefined' && typeof judgeItem === 'function') (() => {
  const W = n => (n == null || isNaN(n)) ? '–' : Math.round(n).toLocaleString('ko-KR') + '원';
  // 설정: on = 항목 켜기/끄기, def = 모든 구매처 기본, sites[k] = 구매처별 내 등급·내 할인 (있으면 기본 대신), sites[k].off = 이 구매처는 할인 안 넣기
  let SD = { on: { coupon: true, cart: true, grade: true, point: true, pay: true }, def: {}, sites: {} };
  let FL = { cur: {}, saved: [] };   // 필터: cur = 지금 조건, saved = [{name, f}]
  let TAB = 'profit', SEL = null;   // 결과 탭, 상세 패널 상품
  const saveSD = () => store.set('srcDisc', SD), saveFL = () => store.set('fdFilt', FL);
  const cfgFor = k => { const s = SD.sites[k]; if (s && s.off) return null; return s && s.own ? s : SD.def; };
  const buyOf = s => sdCalc(s.min, cfgFor(s.k), SD.on);
  window.sdBuyOf = buyOf;
  const anyDisc = () => SD_STEPS.some(([k]) => SD.on[k] !== false && [SD.def, ...Object.values(SD.sites).filter(s => s.own && !s.off)].some(c => c && c[k] && (+c[k].pct || +c[k].won)));
  const siteLabel = k => { const s = (typeof SRC_SITES !== 'undefined' ? SRC_SITES : []).find(x => x.k === k); return s ? s.label : k; };

  // 판정 감싸기: 할인 반영 매입가로 최저 매입처·순마진·판정을 다시 내고, 이름만 맞은 매입처 중 남을 수 있는 건 '확인 필요'로
  const judge0 = judgeItem;
  judgeItem = function (it, opts) {
    judge0(it, opts);
    const tiers = opts.market ? ['trust', 'market'] : ['trust'];
    const all = (it.src && it.src.sites || []).filter(s => s.level && s.min && !s.no && tiers.includes(srcTier(s)));
    for (const s of all) s.buy = buyOf(s).final;
    const sure = all.filter(s => s.level === 'strong' || s.userOk).sort((a, b) => a.buy - b.buy);
    const best = sure[0] || null, bestT = sure.find(s => srcTier(s) === 'trust') || null;
    const buy = best ? best.buy : null;
    const margin = best && it.be != null ? it.be - buy : null;
    let grade = 'none';
    const mw = +opts.minWon || 0, mp = +opts.minPct || 0;
    if (best && it.sell) {
      if (margin > 0) grade = margin >= mw && (!mp || margin / buy * 100 >= mp) ? 'go' : 'low';
      else if (it.be != null && buy <= it.be * (1 + (opts.tol || 5) / 100)) grade = 'near';
      else grade = 'pricey';
    }
    const chk = it.be != null ? all.filter(s => s.level === 'weak' && !s.userOk && s.buy < it.be && (!best || s.buy < best.buy)) : [];
    return Object.assign(it, { best, bestT, margin, grade, buy, tag: best ? best.min : null, chk: chk.length ? chk.map(s => s.k) : null });
  };
  // 매입가 칸: 할인 반영가 + 정가 취소선
  window.sdBuyCell = it => {
    const b = it.best; if (!b) return '';
    const d = b.buy != null && b.buy < b.min;
    return `<div class="n">${W(d ? b.buy : b.min)}</div>${d ? `<div class="small"><s>${W(b.min)}</s> 할인 ${W(b.min - b.buy)}</div>` : ''}`;
  };

  // ---- 필터 ----
  const owned = () => { try { return new Set((INV.items || []).map(x => String(x.code || '').replace(/[^A-Z0-9]/gi, '').toUpperCase()).filter(Boolean)); } catch (e) { return new Set(); } };
  const rateOf = it => it.margin != null && it.buy > 0 ? it.margin / it.buy * 100 : null;
  function pass(it, f, own) {
    f = f || FL.cur;
    if (f.cat && it.cat !== f.cat) return false;
    const q = String(f.q || '').trim().toLowerCase();
    if (q && !(String(it.name || '') + ' ' + String(it.code || '')).toLowerCase().includes(q)) return false;
    if (+f.est7 && (it.est7 || 0) < +f.est7) return false;
    if (f.won !== undefined && f.won !== '' && (it.margin == null || it.margin < +f.won)) return false;
    if (+f.pct && !(rateOf(it) >= +f.pct)) return false;
    if (+f.maxBuy && !(it.buy != null && it.buy <= +f.maxBuy)) return false;
    if (f.trust && it.best && srcTier(it.best) !== 'trust') return false;
    if (f.own && own && own.has(String(it.code || '').replace(/[^A-Z0-9]/gi, '').toUpperCase())) return false;
    return true;
  }
  const fCount = f => ['est7', 'won', 'pct', 'maxBuy'].filter(k => f[k] !== undefined && f[k] !== '' && f[k] !== null).length + (f.trust ? 1 : 0) + (f.own ? 1 : 0);
  const SORTS = { def: '기본 (추천 순)', margin: '개당 수익', rate: '수익률', est7: '최근 7일 거래', buy: '매입가 낮은 순' };
  const sorter = k => k === 'margin' ? (a, b) => (b.margin ?? -9e9) - (a.margin ?? -9e9) : k === 'rate' ? (a, b) => (rateOf(b) ?? -9e9) - (rateOf(a) ?? -9e9)
    : k === 'est7' ? (a, b) => (b.est7 || 0) - (a.est7 || 0) : k === 'buy' ? (a, b) => (a.buy ?? 9e9) - (b.buy ?? 9e9)
    : (a, b) => (FD_ORDER[a.grade] - FD_ORDER[b.grade]) || ((b.margin ?? -9e9) - (a.margin ?? -9e9)) || ((b.est7 || 0) - (a.est7 || 0));

  // ---- 화면 뼈대 (기존 클래스만 써요) ----
  function ui() {
    if ($('#sdBox')) return;
    const tbl = document.querySelector('#tab-find .fd-tbl'); if (!tbl) return;
    const box = document.createElement('div'); box.id = 'sdBox';
    box.innerHTML = `<div class="subtabs" id="sdTabs" role="tablist"></div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:10px 0 4px">
        <select id="sdCat" aria-label="품목" style="width:auto;min-width:150px;flex:0 0 auto"></select>
        <label class="dl-search" data-ico="search" style="flex:1 1 240px;min-width:180px"><input id="sdQ" type="search" placeholder="상품명 · 품번 검색" autocomplete="off"></label>
        <button type="button" class="ghost" id="sdFiltBtn">필터</button>
        <button type="button" class="ghost" id="sdMine">내 매입가 맞추기</button>
      </div>
      <div class="dl-row" id="sdSaved" style="flex-wrap:wrap;gap:6px"></div>
      <div class="fd-basis" id="sdDisc" style="display:block;margin:6px 0 8px">
        <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center"><b class="small">할인 반영 매입가</b>${SD_STEPS.map(([k, l], i) => `<label class="fd-tg"><input type="checkbox" data-sdon="${k}"><span>${i + 1}. ${l}</span></label>`).join('')}</div>
        <p class="dl-sub" id="sdWhy" style="margin:6px 0 0"></p>
      </div>
      <p class="dl-sub" id="sdHide" hidden></p>`;
    tbl.parentNode.insertBefore(box, tbl);
    const dlg = document.createElement('dialog'); dlg.id = 'sdDlg'; dlg.className = 'invdlg'; document.body.appendChild(dlg);
    const dim = document.createElement('div'); dim.className = 'drw-dim'; dim.id = 'sdDim'; dim.hidden = true; document.body.appendChild(dim);
    const drw = document.createElement('aside'); drw.className = 'drw'; drw.id = 'sdDrw'; drw.setAttribute('aria-hidden', 'true'); drw.setAttribute('aria-label', '상품 상세'); drw.style.width = 'min(560px,100vw)';
    document.body.appendChild(drw);
    $('#sdTabs').addEventListener('click', e => { const b = e.target.closest('[data-sdtab]'); if (b) { TAB = b.dataset.sdtab; renderFinder(); } });
    $('#sdCat').addEventListener('change', e => { FL.cur.cat = e.target.value; saveFL(); renderFinder(); });
    $('#sdQ').addEventListener('input', e => { FL.cur.q = e.target.value; renderFinder(); });
    $('#sdFiltBtn').addEventListener('click', filtDlg);
    $('#sdMine').addEventListener('click', () => mineDlg());
    $('#sdSaved').addEventListener('click', e => {
      const x = e.target.closest('[data-sdsx]'); if (x) { FL.saved.splice(+x.dataset.sdsx, 1); saveFL(); renderFinder(); return; }
      const b = e.target.closest('[data-sds]'); if (b) { const s = FL.saved[+b.dataset.sds]; FL.cur = { ...s.f, q: FL.cur.q || '' }; saveFL(); renderFinder(); }
      if (e.target.closest('#sdClr')) { FL.cur = {}; $('#sdQ').value = ''; saveFL(); renderFinder(); }
    });
    box.addEventListener('change', e => { const c = e.target.closest('[data-sdon]'); if (c) { SD.on[c.dataset.sdon] = c.checked; saveSD(); renderFinder(); } });
    // 줄 누르면 오른쪽 상세 (버튼·링크는 그대로)
    $('#fRows').addEventListener('click', e => {
      const pk = e.target.closest('[data-sdpick]'); if (pk) return pick(pk.dataset.sdpid, pk.dataset.sdpick, +pk.dataset.sdi);
      const no = e.target.closest('[data-sdno]'); if (no) return reject(no.dataset.sdpid, no.dataset.sdno);
      if (e.target.closest('a,button,input,select,label')) return;
      const tr = e.target.closest('tr[data-fpid]'); if (tr) openDet(tr.dataset.fpid);
    });
    dim.addEventListener('click', closeDet);
    drw.addEventListener('click', drwClick);
    drw.addEventListener('change', e => { const t = e.target.closest('[data-sdoff]'); if (t) { const k = t.dataset.sdoff; SD.sites[k] = { ...(SD.sites[k] || {}), off: !t.checked }; saveSD(); renderFinder(); } });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && drw.classList.contains('on')) closeDet(); });
  }

  // ---- 결과 그리기 ----
  const render0 = renderFinder;
  renderFinder = function () {
    ui();
    const F0 = finder, box = $('#sdBox');
    if (!F0 || !F0.at || !Array.isArray(F0.items)) { render0(); if (box) box.hidden = true; closeDet(); return; }
    if (box) box.hidden = false;
    const o = { tol: 5, ...(F0.opts || {}), market: FO.market, minWon: FO.minWon, minPct: FO.minPct };
    for (const it of F0.items) if (!it.err) judgeItem(it, o);
    const base = F0.items.filter(it => !it.err && (F0.mode || !F0.opts || ((it.est7 || 0) >= F0.opts.min7 && it.src)));
    const own = FL.cur.own ? owned() : null, ok = it => pass(it, FL.cur, own);
    const shown = base.filter(ok), chk = shown.filter(it => it.chk), prof = shown.filter(it => it.grade === 'go');
    const srt = FL.cur.sort || 'def';
    if (TAB === 'profit' && srt === 'def') {
      finder = { ...F0, items: F0.items.filter(it => it.err || ok(it)) };
      try { render0(); } finally { finder = F0; }
    } else {
      render0();   // 기준 줄·요약 카드·메타는 원래대로
      $('#fEmpty').hidden = true;
      const list = (TAB === 'check' ? chk : TAB === 'profit' ? shown.filter(it => it.grade === 'go' || it.grade === 'low') : shown).slice().sort(sorter(srt));
      $('#fRows').innerHTML = list.length ? list.map((it, i) => TAB === 'check' ? chkRow(it, i) : finderRow(it, i, F0)).join('')
        : `<tr><td colspan="8" class="empty">${TAB === 'check' ? '확인할 상품이 없어요 — 모델번호로 같은 상품을 다 찾았어요' : '조건에 맞는 상품이 없어요'}</td></tr>`;
    }
    // 탭 · 품목 · 저장 필터 · 숨김 · 계산 근거
    $('#sdTabs').innerHTML = [['profit', '수익 상품', prof.length], ['check', '확인 필요', chk.length], ['all', '전체', shown.length]]
      .map(([k, t, n]) => `<button type="button" data-sdtab="${k}" aria-selected="${TAB === k}">${t}${k === 'check' && n ? ' <span class="neg">●</span>' : ''} <span class="small">${n}개</span></button>`).join('');
    const cats = {}; for (const it of base) cats[it.cat || '기타'] = (cats[it.cat || '기타'] || 0) + 1;
    $('#sdCat').innerHTML = `<option value="">품목 전체 ${base.length}</option>` + Object.entries(cats).map(([c, n]) => `<option value="${esc(c)}"${FL.cur.cat === c ? ' selected' : ''}>${esc(c)} ${n}</option>`).join('');
    if ($('#sdQ').value !== (FL.cur.q || '') && document.activeElement !== $('#sdQ')) $('#sdQ').value = FL.cur.q || '';
    const fc = fCount(FL.cur);
    $('#sdFiltBtn').textContent = fc ? `필터 ${fc} ▾` : '필터 ▾';
    $('#sdSaved').innerHTML = FL.saved.map((s, i) => `<span class="fd-chip" style="display:inline-flex;gap:4px;align-items:center"><button type="button" class="linkbtn" data-sds="${i}">${esc(s.name)}</button><button type="button" class="linkbtn" data-sdsx="${i}" aria-label="지우기">×</button></span>`).join('')
      + (fc || FL.cur.cat || FL.cur.q ? '<button type="button" class="linkbtn" id="sdClr">조건 지우기</button>' : '');
    const hid = base.length - shown.length;
    $('#sdHide').hidden = !hid; $('#sdHide').textContent = hid ? `필터로 ${hid}개 숨겼어요` : '';
    document.querySelectorAll('#sdBox [data-sdon]').forEach(c => { c.checked = SD.on[c.dataset.sdon] !== false; });
    why(F0);
    if (SEL) { if (F0.items.some(x => String(x.pid) === String(SEL))) paintDet(); else closeDet(); }
  };
  // 계산 근거: 상세에서 고른 상품, 없으면 첫 수익 상품
  function why(F0) {
    const el = $('#sdWhy'); if (!el) return;
    const it = (SEL && F0.items.find(x => String(x.pid) === String(SEL) && x.best)) || F0.items.filter(x => x.grade === 'go' && x.best).sort((a, b) => b.margin - a.margin)[0] || F0.items.find(x => x.best);
    if (!it) { el.textContent = '매입처를 찾은 상품이 없어요'; return; }
    const d = buyOf(it.best);
    const parts = d.steps.filter(s => s.amt || s.off).map(s => s.off ? `${s.label} 끔` : `${s.label} −${W(s.amt)}`);
    el.innerHTML = `계산 근거 · <b>${esc(String(it.name || '').slice(0, 26))}</b> ${esc(it.best.label)} : 태그가 ${W(d.tag)}${parts.length ? ' → ' + esc(parts.join(' → ')) : ' (넣은 할인 없음)'} → <b>최종 매입가 ${W(d.final)}</b>`
      + (it.margin != null ? ` · 개당 수익 <b class="${it.margin > 0 ? 'pos' : 'neg'}">${sign(it.margin)}</b>` : '') + (anyDisc() ? '' : ' · <span class="small">할인은 \'내 매입가 맞추기\'에서 넣어요</span>');
  }
  // 확인 필요 줄: 크림 사진 옆에 이름만 맞은 매입처 상품을 보여 주고, 같은 상품을 누르면 다시 조회해 반영
  function chkRow(it, i) {
    const sites = (it.src.sites || []).filter(s => (it.chk || []).includes(s.k));
    const cand = sites.map(s => `<div style="display:flex;flex-wrap:wrap;gap:6px;align-items:stretch;margin:2px 0"><span class="small" style="min-width:70px"><b>${esc(s.label)}</b><br>${srcTier(s) === 'trust' ? '정품 유통' : '오픈마켓'}</span>`
      + (s.items || []).filter(x => x.price).slice(0, 3).map((x, j) => `<button type="button" class="ghost" data-sdpid="${esc(it.pid)}" data-sdpick="${esc(s.k)}" data-sdi="${j}" title="이 상품이 크림 상품과 같으면 눌러 주세요" style="display:flex;gap:8px;align-items:center;text-align:left;max-width:260px;height:auto;padding:6px 8px">`
        + (x.img ? `<img class="thumb" src="${esc(x.img)}" alt="">` : '<span class="thumb" style="display:grid;place-items:center;font-size:11px">사진 없음</span>')
        + `<span><span class="small">${esc(String(x.name || '').slice(0, 40))}</span><br><b>${W(sdCalc(x.price, cfgFor(s.k), SD.on).final)}</b>${x.soldOut ? ' <span class="small neg">품절</span>' : ''}</span></button>`
        + (x.url ? `<a class="small" href="${esc(x.url)}" target="_blank" rel="noopener" style="align-self:center">보기 ↗</a>` : '')).join('')
      + `<button type="button" class="linkbtn" data-sdpid="${esc(it.pid)}" data-sdno="${esc(s.k)}">다른 상품이에요</button></div>`).join('');
    return `<tr data-fpid="${esc(it.pid)}"><td class="small">${i + 1}</td>
      <td class="l name">${it.img ? `<img class="thumb" src="${esc(it.img)}" alt="">` : ''}<b>${esc(it.name)}</b><span class="code">${esc(it.code)} · 크림 ${W(it.sell)}</span></td>
      <td class="l" colspan="5"><div class="small" style="margin-bottom:4px">모델번호가 안 보여 같은 상품·색인지 자동으로 못 정했어요. 크림 사진과 같은 상품을 눌러 주세요.</div>${cand}</td>
      <td><span class="pill warn">확인 필요</span></td></tr>`;
  }
  async function pick(pid, k, j) {
    const it = finder.items.find(x => String(x.pid) === String(pid)); if (!it) return;
    const s = (it.src.sites || []).find(x => x.k === k); if (!s) return;
    const x = (s.items || [])[j]; if (!x) return;
    s.items = [x]; s.min = x.price; s.n = 1; s.userOk = true; s.pickAt = Date.now();
    await store.set('finder', finder); renderFinder();
    // 그 판매처를 다시 조회해 지금 가격·품절을 반영 (킥스캔 안에서만)
    if (window.SD_NO_NET || typeof HAS_CHROME === 'undefined' || !HAS_CHROME || !chrome.scripting || !x.url) return;
    $('#fProgress').hidden = false; $('#fText').textContent = `${s.label} 다시 조회하는 중…`;
    queueJob(async () => {
      try {
        const res = await srcRead(await srcNav(x.url));
        const info = { name: it.name, code: it.code, en: it.en };
        const site = SRC_SITES.find(z => z.k === k) || { k, label: s.label, tier: s.tier };
        const got = matchSrc(res, srcCtx(info.name, info.code, info.en), site);
        const g = got.find(z => z.url === x.url) || got[0];
        const price = g ? g.price : (res.page && res.page.price);
        if (price) { x.price = price; s.min = price; }
        if (g) x.soldOut = g.soldOut;
        s.at = Date.now();
        $('#fText').textContent = `${s.label} 다시 조회했어요 — ${W(s.min)}${x.soldOut ? ' (품절)' : ''}`;
      } catch (e) { $('#fText').textContent = `${s.label} 다시 조회하지 못했어요 — 찾을 때 가격으로 넣었어요`; }
      if (typeof work !== 'undefined' && work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
      await store.set('finder', finder); renderFinder();
    });
  }
  async function reject(pid, k) {
    const it = finder.items.find(x => String(x.pid) === String(pid)); if (!it) return;
    const s = (it.src.sites || []).find(x => x.k === k); if (s) s.no = true;
    await store.set('finder', finder); renderFinder();
  }

  // ---- 상세 패널 ----
  function openDet(pid) { SEL = pid; paintDet(); document.body.classList.add('drw-open'); $('#sdDrw').classList.add('on'); $('#sdDrw').setAttribute('aria-hidden', 'false'); $('#sdDim').hidden = false; why(finder); }
  function closeDet() { SEL = null; const d = $('#sdDrw'); if (!d) return; d.classList.remove('on'); d.setAttribute('aria-hidden', 'true'); $('#sdDim').hidden = true; if (!document.querySelector('.drw.on')) document.body.classList.remove('drw-open'); }
  function paintDet() {
    const it = finder.items.find(x => String(x.pid) === String(SEL)); const D = $('#sdDrw'); if (!it || !D) return;
    const b = it.best, ship = it.sell != null && it.fee != null && it.be != null ? it.sell - it.fee - it.be : 0;
    const lim = it.be, rate = rateOf(it);
    const sites = (it.src && it.src.sites || []).filter(s => s.level && s.min && !s.no).map(s => ({ s, d: buyOf(s) })).sort((a, b2) => a.d.final - b2.d.final);
    const dk = (l, v, cls = '') => `<div class="dk"><span>${l}</span><b class="${cls}">${v}</b></div>`;
    const d0 = b ? buyOf(b) : null, mine = b ? SD.sites[b.k] : null;
    const buyUrl = b ? ((b.items && b.items[0] && b.items[0].url) || b.searchUrl) : '';
    D.innerHTML = `<div class="drw-head"><div><small>${esc(it.cat || '소싱')} · 상품 상세</small><h2>${esc(String(it.name || '').slice(0, 60))}</h2></div><button type="button" class="drw-x" data-sdx aria-label="닫기">×</button></div>
      <div class="drw-kpi">${dk('개당 수익', it.margin != null ? sign(it.margin) : '–')}${dk('수익률', rate != null ? rate.toFixed(1) + '%' : '–')}${dk('매입가', b ? W(it.buy) : '–')}${dk('수익 한도', lim != null ? W(lim) : '–')}</div>
      <div class="drw-list" style="gap:12px">
        <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center">${it.img ? `<img class="thumb" src="${esc(it.img)}" alt="">` : ''}<span class="code">${esc(it.code || '품번 없음')}</span>${it.code ? `<button type="button" class="linkbtn" data-sdcopy="${esc(it.code)}">복사</button>` : ''}
          <span class="topsp"></span>${it.pid ? `<a class="ghost" href="https://kream.co.kr/products/${esc(it.pid)}" target="_blank" rel="noopener">KREAM ↗</a>` : ''}${buyUrl ? `<a class="ghost" href="${esc(buyUrl)}" target="_blank" rel="noopener">구매 ↗</a>` : ''}${it.grade === 'go' && it.pid ? `<button type="button" class="primary" data-sdinv="${esc(it.pid)}">재고에 입고</button>` : ''}</div>
        ${b && it.margin != null ? `<p class="dl-sub" style="margin:0">${esc(b.label)}에서 ${W(it.buy)}에 사서 크림에 팔면 개당 <b class="${it.margin > 0 ? 'pos' : 'neg'}">${sign(it.margin)}</b> 남아요. 매입가 ${W(lim)}까지는 손해가 없어요${it.sell && it.margin > 0 ? ` · 판매가가 ${Math.round(it.margin / it.sell * 100)}% 내려도 수익` : ''}.</p>` : '<p class="dl-sub" style="margin:0">아직 같은 상품을 파는 매입처를 확정하지 못했어요.</p>'}
        <div><b class="small">판매처 · KREAM</b>
          <div class="tbl"><table class="main"><thead><tr><th>예상 판매가<small>최근 체결 평균</small></th><th>수수료</th><th>발송비</th><th>정산액</th><th>최근 7일 거래</th></tr></thead>
          <tbody><tr><td>${W(it.sell)}</td><td>${W(it.fee)}</td><td>${W(ship)}</td><td>${W(it.settle)}</td><td>${(it.est7 || 0).toLocaleString('ko-KR')}건${it.trades ? `<div class="small">누적 ${it.trades.toLocaleString('ko-KR')}</div>` : ''}</td></tr></tbody></table></div></div>
        <div><b class="small">매입처 비교</b> <span class="small">${it.src && it.src.at ? new Date(it.src.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' 조회' : ''}</span>
          <div class="tbl"><table class="main"><thead><tr><th class="l">구매처</th><th>정가</th><th>할인 반영가</th><th>개당 수익</th><th>같은 상품</th><th></th></tr></thead><tbody>
          ${sites.length ? sites.map(({ s, d }) => { const m = it.be != null ? it.be - d.final : null, u = (s.items && s.items[0] && s.items[0].url) || s.searchUrl;
            return `<tr${s === b ? ' style="outline:2px solid var(--pos,#16a34a);outline-offset:-2px"' : ''}><td class="l"><b>${esc(s.label)}</b> <span class="pill ${srcTier(s) === 'trust' ? 'ok' : 'warn'}">${srcTier(s) === 'trust' ? '정품 유통' : '오픈마켓'}</span></td><td style="white-space:nowrap">${W(d.tag)}</td><td style="white-space:nowrap"><b>${W(d.final)}</b></td>
              <td class="${m > 0 ? 'pos' : m != null ? 'neg' : ''}">${m != null ? sign(m) : '–'}</td><td class="small">${s.level === 'strong' ? '모델번호 확인' : s.userOk ? '내가 고름' : '<span class="neg">확인 필요</span>'}</td><td>${u ? `<a class="ghost" href="${esc(u)}" target="_blank" rel="noopener">↗</a>` : ''}</td></tr>`; }).join('') : '<tr><td colspan="6" class="empty">매입처를 못 찾았어요</td></tr>'}
          </tbody></table></div></div>
        ${b ? `<details open><summary><b class="small">매입가 펼치기 · ${esc(b.label)}</b></summary>
          <div class="tbl"><table class="main"><tbody><tr><td class="l">정가 (태그가)</td><td>${W(d0.tag)}</td></tr>
          ${d0.steps.map((s, i) => `<tr><td class="l">${i + 1}. ${esc(s.label)}</td><td>${s.off ? '<span class="small">끔</span>' : s.amt ? `−${W(s.amt)}` : '<span class="small">없음</span>'}</td></tr>`).join('')}
          <tr><td class="l"><b>최종 매입가</b></td><td><b>${W(d0.final)}</b></td></tr></tbody></table></div>
          <div style="display:flex;gap:10px;align-items:center;margin-top:6px"><label class="dl-sw fd-sw"><input type="checkbox" data-sdoff="${esc(b.k)}"${mine && mine.off ? '' : ' checked'}><i></i><span class="fd-swl">이 구매처에 내 할인 넣기</span></label>
          <button type="button" class="linkbtn" data-sdmine="${esc(b.k)}">${mine && mine.own ? `내 등급 ${esc(mine.gname || '')} 고치기` : '이 구매처 내 등급·할인 넣기'}</button></div></details>` : ''}
      </div>
      <div class="drw-foot"><button type="button" class="ghost" data-sdx>닫기</button>${it.grade === 'go' && it.pid ? `<button type="button" class="primary" data-sdinv="${esc(it.pid)}">재고에 입고</button>` : ''}</div>`;
  }
  function drwClick(e) {
    if (e.target.closest('[data-sdx]')) return closeDet();
    const c = e.target.closest('[data-sdcopy]'); if (c) { try { navigator.clipboard.writeText(c.dataset.sdcopy); c.textContent = '복사했어요'; } catch (er) {} return; }
    const v = e.target.closest('[data-sdinv]'); if (v) { closeDet(); return finderToInv(v.dataset.sdinv); }
    const m = e.target.closest('[data-sdmine]'); if (m) return mineDlg(m.dataset.sdmine);
  }

  // ---- 내 매입가 맞추기 (구매처별 내 등급·내 할인) ----
  function mineDlg(k0) {
    const d = $('#sdDlg');
    const seen = new Set(); for (const it of (finder.items || [])) for (const s of (it.src && it.src.sites || [])) if (s.level) seen.add(s.k);
    const keys = [...new Set([...seen, ...Object.keys(SD.sites)])];
    let k = k0 || '';
    const body = () => {
      const c = k ? (SD.sites[k] || {}) : SD.def;
      const v = (s, f) => c[s] && c[s][f] ? c[s][f] : '';
      return `<label>구매처<select name="site"><option value="">모든 구매처 (기본)</option>${keys.map(x => `<option value="${esc(x)}"${x === k ? ' selected' : ''}>${esc(siteLabel(x))}${SD.sites[x] && SD.sites[x].own ? ' · 내 할인 있음' : ''}</option>`).join('')}</select></label>
        ${k ? `<label>내 등급<input name="gname" value="${esc(c.gname || '')}" placeholder="예: 골드"></label>` : '<p class="dl-sub" style="margin:0">구매처별로 따로 넣지 않은 곳은 이 기본값을 써요</p>'}
        ${SD_STEPS.map(([s, l], i) => `<div class="wide" style="display:grid;grid-template-columns:150px repeat(3,minmax(0,1fr));gap:6px;align-items:center"><b class="small">${i + 1}. ${l}</b>
          <label class="dl-num"><input name="${s}.pct" inputmode="decimal" value="${v(s, 'pct')}" placeholder="0"><span>%</span></label>
          <label class="dl-num"><input name="${s}.won" inputmode="numeric" value="${v(s, 'won')}" placeholder="0"><span>원</span></label>
          <label class="dl-num"><input name="${s}.cap" inputmode="numeric" value="${v(s, 'cap')}" placeholder="최대"><span>원</span></label></div>`).join('')}
        <p class="dl-sub wide" style="margin:0">위에서부터 차례로 빼요. %는 앞 단계까지 깎인 값에 매겨요 · 세 번째 칸은 그 할인의 최대 금액이에요.</p>`;
    };
    d.innerHTML = `<form method="dialog" class="dlg"><h3>내 매입가 맞추기</h3><div class="dlg-body dgrid" id="sdMineBody">${body()}</div><p class="hint neg dlg-msg"></p>
      <div class="row-btns end">${k ? '<button type="button" class="ghost" id="sdMineDel">이 구매처 내 할인 지우기</button>' : ''}<button value="cancel" class="ghost" formnovalidate>닫기</button><button value="ok" class="primary">저장</button></div></form>`;
    const f = d.querySelector('form');
    f.querySelector('[name=site]').addEventListener('change', e => { mineDlg(e.target.value); });
    const del = f.querySelector('#sdMineDel'); if (del) del.addEventListener('click', async () => { delete SD.sites[k]; await saveSD(); d.close(); renderFinder(); });
    f.addEventListener('submit', async e => {
      if (e.submitter && e.submitter.value === 'cancel') return;
      e.preventDefault();
      const fd = Object.fromEntries(new FormData(f)), c = {};
      for (const [s] of SD_STEPS) { const o = {}; for (const x of ['pct', 'won', 'cap']) { const n = +String(fd[`${s}.${x}`] || '').replace(/[^\d.]/g, ''); if (n > 0) o[x] = x === 'pct' ? Math.min(100, n) : Math.round(n); } if (Object.keys(o).length) c[s] = o; }
      if (k) SD.sites[k] = { ...c, own: true, gname: String(fd.gname || '').trim().slice(0, 20), off: !!(SD.sites[k] && SD.sites[k].off) };
      else SD.def = c;
      await saveSD(); d.close(); renderFinder();
    });
    if (!d.open) d.showModal();
  }

  // ---- 필터 팝업 · 저장 필터 ----
  function filtDlg() {
    const d = $('#sdDlg'), c = FL.cur;
    const num = (n, l, u, ph = '') => `<label class="dl-num wide"><em>${l}</em><input name="${n}" inputmode="decimal" value="${c[n] ?? ''}" placeholder="${ph}"><span>${u}</span></label>`;
    d.innerHTML = `<form method="dialog" class="dlg"><h3>필터</h3><div class="dlg-body dgrid">
      ${FL.saved.length ? `<div class="wide" style="display:flex;flex-wrap:wrap;gap:6px"><span class="small">저장한 필터</span>${FL.saved.map((s, i) => `<button type="button" class="fd-chip" data-sdl="${i}">${esc(s.name)}</button>`).join('')}</div>` : ''}
      ${num('est7', '최근 7일 거래 ≥', '건')}${num('won', '개당 수익 ≥', '원')}${num('pct', '수익률 ≥', '%')}${num('maxBuy', '매입가 ≤', '원')}
      <label class="fd-tg"><input type="checkbox" name="own"${c.own ? ' checked' : ''}><span>보유 상품 제외</span></label>
      <label class="fd-tg"><input type="checkbox" name="trust"${c.trust ? ' checked' : ''}><span>정품 유통 매입처만</span></label>
      <label class="wide">정렬<select name="sort">${Object.entries(SORTS).map(([k, l]) => `<option value="${k}"${(c.sort || 'def') === k ? ' selected' : ''}>${l}</option>`).join('')}</select></label>
      <label class="wide">이 조건 저장 (이름)<input name="name" placeholder="예: 빠른 회전 · 틈새 · 입찰 대기"></label>
      </div><p class="hint neg dlg-msg"></p>
      <div class="row-btns end"><button type="button" class="ghost" id="sdFClr">지우기</button><button value="cancel" class="ghost" formnovalidate>닫기</button><button value="ok" class="primary">적용</button></div></form>`;
    const f = d.querySelector('form');
    f.querySelectorAll('[data-sdl]').forEach(b => b.addEventListener('click', () => { FL.cur = { ...FL.saved[+b.dataset.sdl].f, q: FL.cur.q || '', cat: FL.cur.cat || '' }; saveFL(); d.close(); renderFinder(); }));
    f.querySelector('#sdFClr').addEventListener('click', () => { FL.cur = { q: FL.cur.q || '', cat: FL.cur.cat || '' }; saveFL(); d.close(); renderFinder(); });
    f.addEventListener('submit', async e => {
      if (e.submitter && e.submitter.value === 'cancel') return;
      e.preventDefault();
      const fd = Object.fromEntries(new FormData(f)), n = {};
      for (const x of ['est7', 'won', 'pct', 'maxBuy']) { const s = String(fd[x] || '').replace(/[^\d.-]/g, ''); if (s !== '' && !isNaN(+s)) n[x] = +s; }
      if (fd.own) n.own = true; if (fd.trust) n.trust = true; if (fd.sort && fd.sort !== 'def') n.sort = fd.sort;
      FL.cur = { ...n, q: FL.cur.q || '', cat: FL.cur.cat || '' };
      const nm = String(fd.name || '').trim().slice(0, 16);
      if (nm) { const i = FL.saved.findIndex(s => s.name === nm); const s = { name: nm, f: n }; if (i >= 0) FL.saved[i] = s; else FL.saved.push(s); }
      await saveFL(); d.close(); renderFinder();
    });
    d.showModal();
  }

  // 시작: 저장된 할인·필터 불러오기
  (async () => {
    try { const s = await store.get('srcDisc', null); if (s) SD = { ...SD, ...s, on: { ...SD.on, ...(s.on || {}) }, sites: s.sites || {}, def: s.def || {} }; } catch (e) {}
    try { const f = await store.get('fdFilt', null); if (f) FL = { cur: f.cur || {}, saved: f.saved || [] }; } catch (e) {}
    ui();
    if (finder && finder.at) renderFinder();
  })();
})();
