/* 킥스캔 — 홈 보강 (줍픽 PC 홈 · 오피스 홈)
   - 맨 위 경고 띠: KREAM 로그인이 풀려 판매 내역을 못 불러오면 [로그인 창 열기]
   - 카드 '판매처 연동'(켜져 있음 배지): KREAM 상태 · POIZON · 자동 작업 · 판매 확인 주기 [판매처 연동 ›]
   - 카드 '상품 소싱': 다음 예약 · 최근 실행(수익 상품 N개) · 켠 매입처 N곳 · [소싱 실행 ›]
   - 오늘 할 일 '처음 시작하기 — 재고 가져오기'(재고 가져오기에 줄이 있을 때)
   inv.js vHome 위에 덧붙여요. */
function hmCards() {
  const ks = (typeof acctState !== 'undefined' && acctState.kream) || {}, K = (typeof LKS !== 'undefined' && LKS.kream) || {}, P = typeof LKP !== 'undefined' ? LKP : {};
  const pz = typeof LK !== 'undefined' && LK.pz;
  const off = ks.st === 'off', fail = (K.fails || 0) >= 3;
  const ago = t => typeof lkAgo === 'function' ? lkAgo(t) : '';
  const every = typeof lkEveryTxt === 'function' ? lkEveryTxt(+P.every || 5) : '5분마다';
  const auto = typeof lkAutoTxt === 'function' ? lkAutoTxt() : [];
  const link = `<div class="hm-card"><div class="hm-ch"><b>판매처 연동</b>${P.off ? '<span class="pill bad">꺼져 있음</span>' : OPS && OPS.halt ? '<span class="pill bad">긴급 정지 중</span>' : '<span class="pill ok">켜져 있음</span>'}</div>
    <dl><dt>KREAM</dt><dd>${off ? '<span class="neg">로그인이 풀려 판매 내역을 못 불러와요</span>' : K.okAt ? `${ago(K.okAt)} 갱신 · 진행 중 ${K.pend || 0}건` : ks.st === 'on' ? '로그인됨 · 아직 갱신 전' : '로그인 전'}</dd>
    <dt>POIZON</dt><dd>${!pz || !pz.set ? '연결 대기 — 오픈 API 심사 중' : pz.status === 'err' ? '<span class="neg">오류</span>' : '오픈 API 연결됨'}</dd>
    <dt>자동 작업</dt><dd>${auto.length ? '실행 중 — ' + esc(auto.join(' · ')) : '켜 둔 자동 작업 없음'}</dd>
    <dt>판매 확인</dt><dd>${P.off ? '꺼짐' : every}${fail ? ' · 잇따라 실패해 지금은 한 시간마다' : ''}</dd></dl>
    <div class="row-btns end"><button type="button" class="ghost small" data-a="hmGo" data-v="link">판매처 연동 ›</button></div></div>`;
  let src = '';
  try {
    const R = typeof SE !== 'undefined' ? SE.run : null, scheds = typeof SE !== 'undefined' ? (SE.scheds || []).filter(s => s.on) : [];
    const nx = scheds.map(s => { try { return seSchedNext(s, Date.now()); } catch (e) { return 0; } }).filter(x => x > 0).sort((a, b) => a - b)[0];
    const mods = typeof seMods === 'function' ? seMods() : [], offS = new Set((SE.scope && SE.scope.off) || []), on = mods.filter(m => !offS.has(m.k)).length;
    const prof = R && R.counts ? R.counts.profit || 0 : 0;
    src = `<div class="hm-card"><div class="hm-ch"><b>상품 소싱</b></div>
    <dl><dt>다음 예약</dt><dd>${nx ? new Date(nx).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '없음'}</dd>
    <dt>최근 실행</dt><dd>${R && R.startedAt ? `${new Date(R.startedAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })} · ${R.kind === 'kmap' || R.kind === 'collect' ? `${R.kind === 'kmap' ? '품번 짝 모으기' : '매입처만 수집'} · 시세 조회 안 함` : `수익 상품 ${prof}개`}` : '아직 없음'}</dd>
    <dt>켠 매입처</dt><dd>${on}곳${mods.length ? ` / ${mods.length}곳` : ''}</dd></dl>
    <div class="row-btns end"><button type="button" class="ghost small" data-a="hmGo" data-v="settings">수집 범위</button><button type="button" class="primary small" data-a="hmGo" data-v="find">소싱 실행 ›</button></div></div>`;
  } catch (e) {}
  const warn = off ? `<div class="hm-warn"><span>KREAM 로그인이 풀려 판매 내역을 못 불러오고 있어요. 네이버 · Apple 로 로그인한 계정은 자동 로그인이 안 돼요.</span><button type="button" class="primary small" data-a="hmLogin">로그인 창 열기</button></div>` : '';
  let ev = '';
  try { if (typeof evItems === 'function') { const E = evItems(), wk = E.filter(e => e.left != null && e.left <= 7).length, nw = E.filter(e => e.isNew).length, fav = typeof EVF !== 'undefined' ? E.filter(e => EVF.includes(e.brand)).length : 0;
    ev = `<div class="hm-card"><div class="hm-ch"><b>아울렛 행사</b><span class="pill mute">${E.length}개</span></div><dl><dt>새로 올라옴</dt><dd>${nw}개</dd><dt>이번 주 마감</dt><dd>${wk}개</dd><dt>관심 브랜드</dt><dd>${fav}개</dd></dl><div class="row-btns end"><button type="button" class="ghost small" data-a="hmGo2" data-v="events">행사 ›</button></div></div>`; } } catch (e) {}
  return { warn, cards: `<div class="hm-cards">${link}${src}${ev}</div>` };
}
function hmTodo() {
  try { const n = typeof stkImpRows === 'function' ? stkImpRows().length : 0; return n ? `<div class="hm-todo"><b>처음 시작하기 — 재고 가져오기</b><span class="small">판매처 재고 · 쓰던 시트를 매입가만 입력해 재고로 등록 — 매입 기록이 없는 재고 ${n}건</span><button type="button" class="ghost small" data-a="hmImp">재고 가져오기 ›</button></div>` : ''; } catch (e) { return ''; }
}
async function hmAct(a, el) {
  if (a === 'hmGo') return route(el.dataset.v);
  if (a === 'hmLogin') { if (typeof acctOpenWin === 'function') acctOpenWin('kream'); return; }
  if (a === 'hmGo2') return go(el.dataset.v);
  if (a === 'hmImp') { IS.stk = { ...(typeof stkS === 'function' ? stkS() : {}), tab: 'imp' }; return go('stock'); }
}
(function hmWire() {
  if (typeof vHome !== 'function') return;
  const v = vHome;
  vHome = function (C) {
    const h = v(C);
    try {
      const X = hmCards(), i = h.indexOf('<div class="kgrid">');
      const add = X.warn + X.cards + hmTodo();
      return i > 0 ? h.slice(0, i) + add + h.slice(i) : add + h;
    } catch (e) { return h; }
  };
})();
