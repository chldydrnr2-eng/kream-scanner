/* 킥스캔 — 왼쪽 아래 고정 칸 (줍픽 PC 왼쪽 아래 · 오피스 왼쪽 아래)
   작업 현황(진행 중 N · 최근 처리 내역 · [작업 내역 전체 보기]) · 휴가 모드 · 판매처 연동(KREAM · POIZON 'N분 전' + ↻)
   · 작업용 크롬(창 숨김) · 프로그램 업데이트(버전 · [확인])
   작업 기록은 'workLog' 에 남겨요: 위쪽 줄 선 작업(queueJob) · KREAM 판매 내역 갱신 · 자동 판매 등록 */
let WK = { log: [], open: false, all: false };
async function wkLog(name, auto, result) {
  WK.log.unshift({ t: Date.now(), name: String(name || '작업').slice(0, 40), auto: !!auto, result: String(result || '완료').slice(0, 160) });
  WK.log = WK.log.slice(0, 200); try { await store.set('workLog', WK.log); } catch (e) {}
  wkPaint();
}
function wkRunning() {
  const L = [];
  try { if (typeof jobNow !== 'undefined' && jobNow) L.push(jobNow + (jobDetail ? ' — ' + jobDetail : '')); } catch (e) {}
  try { for (const w of (typeof jobWait !== 'undefined' ? jobWait : [])) L.push(w.label + ' (대기)'); } catch (e) {}
  try { if (typeof SE !== 'undefined' && SE.busy) L.push('소싱 실행'); } catch (e) {}
  try { if (typeof LK !== 'undefined' && LK.busy) L.push('KREAM 판매 내역 갱신'); } catch (e) {}
  try { if (typeof AL !== 'undefined' && AL.busy) L.push('자동 판매 등록'); } catch (e) {}
  try { if (typeof AB !== 'undefined' && AB.busy) L.push('입찰가 자동 조정'); } catch (e) {}
  return L;
}
function wkFootHTML() {
  return `<div class="wk-foot" id="wkFoot">
    <button type="button" class="wk-row" data-wk="open"><span class="wk-t">작업 현황</span><small id="wkSub"></small></button>
    <label class="wk-row"><span class="wk-t">휴가 모드</span><input type="checkbox" class="sw" id="wkVac" aria-label="휴가 모드"></label>
    <div class="wk-row wk-link"><button type="button" class="wk-t wk-lt" data-wk="link">판매처 연동</button><span class="wk-ls"><span id="wkK"></span><button type="button" class="wk-re" data-wk="sync" title="KREAM 판매 내역 지금 갱신" aria-label="KREAM 갱신">↻</button></span><small class="wk-note" id="wkKNote" data-wk="link"></small><span class="wk-ls" id="wkP"></span></div>
    <label class="wk-row" data-app><span class="wk-t">작업용 크롬<small id="wkCdpT"></small></span><input type="checkbox" class="sw" id="wkCdp" aria-label="작업용 크롬 창 보이기"></label>
    <button type="button" class="wk-row" data-wk="upd"><span class="wk-t">프로그램 업데이트<small id="wkVer"></small></span><span>›</span></button>
    <button type="button" class="wk-row" data-wk="prof"><span class="wk-t" id="wkProf">프로필</span><span>▾</span></button>
  </div>`;
}
function wkPaint() {
  const sub = $('#wkSub'); if (!sub) return;
  { const pf = $('#wkProf'), L = typeof LICST !== 'undefined' && LICST ? LICST : null; if (pf) pf.innerHTML = L && L.email ? `${esc(String(L.email).split('@')[0])}<small>${esc(typeof planLabel === 'function' ? planLabel(L.plan) : (L.plan || ''))}${L.expires ? ' · ' + esc(String(L.expires).slice(0, 10)) + '까지' : ''}</small>` : '프로필<small>로그인 전</small>'; }
  const R = wkRunning(); sub.textContent = R.length ? `진행 중 ${R.length}` : '진행 중인 작업 없음';
  const v = $('#wkVac'); if (v && typeof OPS !== 'undefined') v.checked = !!OPS.vac;
  const K = (typeof LKS !== 'undefined' && LKS.kream) || {}, ks = (typeof acctState !== 'undefined' && acctState.kream) || {};
  const ago = t => typeof lkAgo === 'function' ? lkAgo(t) : '';
  // 11/25: 갱신 중이면 '갱신 중 1:23' + 도는 ↻ · 단계는 아래 한 줄 · 마지막이 실패면 '로그인 필요' / '실패'(전엔 마지막 성공 'n시간 전'만 빨갛게 보여 눌러도 반응이 없는 것 같았어요)
  const k = $('#wkK'); if (k) {
    const run = typeof LK !== 'undefined' && LK.busy && K.running, loginBad = ks.st === 'off' || /로그인/.test(K.err || ''), bad = !run && (loginBad || !!K.err || (K.fails || 0) >= 3);
    const txt = run ? `갱신 중 ${typeof lkRunTxt === 'function' ? lkRunTxt() : ''}` : loginBad ? '로그인 필요' : K.err ? '실패' : K.okAt ? ago(K.okAt) : '–';
    const tip = run ? `KREAM 판매 내역 갱신 중 — ${LK.phase || '시작'}` : K.err ? `마지막 갱신 실패 (${ago(K.at)}): ${K.err}${K.okAt ? ` · 마지막 성공 ${ago(K.okAt)}` : ''}` : K.okAt ? `마지막 갱신 ${ago(K.okAt)} · 새로 반영 ${K.n || 0}건 · 진행 중 ${K.pend || 0}건` : '';
    k.innerHTML = `<i class="wk-dot ${bad ? 'bad' : K.okAt && !run ? 'ok' : ''}"></i>KREAM <b class="${bad ? 'neg' : ''}">${esc(txt)}</b>`; k.title = tip;
    const re = document.querySelector('#wkFoot .wk-re'); if (re) { re.classList.toggle('spin', !!run); re.title = run ? '갱신 중이에요 — 누르면 진행 상황을 알려 줘요' : 'KREAM 판매 내역 지금 갱신'; }
    const nt = $('#wkKNote'); if (nt) { const showMsg = typeof LK !== 'undefined' && LK.msg && LK.msgAt && Date.now() - LK.msgAt < 60e3; const t = run ? (LK.phase || '시작') + (LK.msgAt && Date.now() - LK.msgAt < 8e3 && /이미|멈추고/.test(LK.msg) ? ' · ' + LK.msg : '') : showMsg ? LK.msg : (loginBad ? '크림 로그인이 풀렸어요 — 눌러서 다시 로그인' : ''); nt.textContent = t; nt.classList.toggle('neg', !run && (bad || /못|실패|풀려/.test(t))); nt.title = t; }
  }
  const p = $('#wkP'); if (p) { const pz = typeof LK !== 'undefined' && LK.pz; p.innerHTML = `<i class="wk-dot ${pz && pz.set && pz.status === 'on' ? 'ok' : ''}"></i>POIZON <b>${!pz || !pz.set ? '대기' : pz.status === 'err' ? '오류' : '연결됨'}</b>`; }
  const pop = $('#wkPop');
  if (pop && WK.open) {
    const L = WK.all ? WK.log : WK.log.slice(0, 8);
    pop.hidden = false;
    pop.innerHTML = `<div class="wk-ph"><b>작업 현황</b><button type="button" class="sr-x" data-wk="close" aria-label="닫기">✕</button></div>
      <p class="small"><b>진행 중 ${R.length}</b>${R.length ? ' — ' + esc(R.join(' · ')) : ' — 진행 중인 작업이 없어요'}</p>
      <p class="small wk-sh">최근 처리 내역</p>
      <table class="wk-t2"><tbody>${L.map(x => `<tr><td>${new Date(x.t).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td><td>${esc(x.name)}</td><td>${x.auto ? '자동' : '직접'}</td><td class="${/실패|멈춤|풀려/.test(x.result) ? 'neg' : ''}">${esc(x.result)}</td></tr>`).join('') || '<tr><td colspan="4" class="small">아직 기록이 없어요</td></tr>'}</tbody></table>
      ${!WK.all && WK.log.length > 8 ? '<button type="button" class="ghost small" data-wk="all">작업 내역 전체 보기 ›</button>' : ''}`;
  } else if (pop) pop.hidden = true;
}
async function wkAct(a) {
  if (a === 'open') { WK.open = !WK.open; WK.all = false; return wkPaint(); }
  if (a === 'close') { WK.open = false; return wkPaint(); }
  if (a === 'all') { WK.all = true; return wkPaint(); }
  if (a === 'link') return route('link');
  if (a === 'prof') { const pop = $('#wkPop'); WK.open = false; const L = typeof LICST !== 'undefined' && LICST ? LICST : {};
    pop.hidden = false; pop.innerHTML = `<div class="wk-ph"><b>${esc(L.email || '로그인 안 됨')}</b><button type="button" class="sr-x" data-wk="close" aria-label="닫기">✕</button></div>
      <p class="small">킥스캔 계정(이메일) 로그인 · 이용권 <b>${esc(typeof planLabel === 'function' ? planLabel(L.plan) : (L.plan || '–'))}</b>${L.expires ? ` · ${esc(String(L.expires).slice(0, 10))}까지` : ''}${L.state === 'grace' ? ' · 유예 중' : ''}</p>
      <div class="wk-dev" id="wkDev"><p class="small">로그인된 기기 불러오는 중…</p></div><div class="wk-pm"><button type="button" class="ghost small" data-wk="p:acct">계정</button><button type="button" class="ghost small" data-wk="p:phone">휴대폰 연결</button><button type="button" class="ghost small" data-wk="p:noti">알림</button><button type="button" class="ghost small" data-wk="p:bak">백업</button><button type="button" class="ghost small" data-wk="pBuy">이용권 · 결제</button><button type="button" class="ghost small" data-wk="pSet">설정</button><button type="button" class="ghost small" data-wk="pGuide">사용 가이드</button><button type="button" class="ghost small" data-wk="pOut">로그아웃</button></div>`; wkDevPaint(); return; }
  if (a === 'pOthers') { const b = document.querySelector('[data-wk=pOthers]'); if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = '한 번 더 누르면 다른 PC 를 모두 연결 끊어요'; return; } const r = await window.kcApp.lic.releaseOthers().catch(e => ({ message: e.message })); b.textContent = r && r.ok ? '다른 PC 를 연결 끊었어요' : (r && r.message) || '못 끊었어요'; return wkDevPaint(); }
  if (a === 'pBuy') { WK.open = false; wkPaint(); return typeof buyOpen === 'function' ? buyOpen() : null; }
  if (a === 'pSet') { WK.open = false; wkPaint(); return typeof stOpen === 'function' ? stOpen('sell') : route('settings'); }
  // 11/23 프로필 메뉴: 계정 · 휴대폰 연결 · 알림 · 백업 → 설정의 '내 계정' 탭
  if (a.startsWith('p:')) { WK.open = false; wkPaint(); return typeof stOpen === 'function' ? stOpen(a.slice(2)) : route('settings'); }
  if (a === 'pGuide') { WK.open = false; wkPaint(); return route('guide'); }
  if (a === 'pOut') { const b = document.getElementById('btnLicOut'); WK.open = false; wkPaint(); if (b) b.click(); return; }
  if (a === 'sync') {
    if (typeof lkSync !== 'function') return;
    // 도는 동안 1초마다 '갱신 중 m:ss'를 고쳐 그려요
    clearInterval(wkAct.tk); wkAct.tk = setInterval(() => { wkPaint(); if (!(typeof LK !== 'undefined' && LK.busy)) clearInterval(wkAct.tk); }, 1000);
    const p = lkSync(true); if (typeof LK !== 'undefined') { LK.msgAt = Date.now(); } wkPaint(); await p; wkPaint(); return;
  }
  // 11/23: '프로그램 업데이트' 칸 → 작은 창(업데이트 확인 · 파일로 직접 넣기 · 처음 버전으로 되돌리기)
  if (a === 'upd') { const P = $('#updPop'); if (!P) return; WK.open = false; wkPaint(); P.hidden = !P.hidden; const u = $('#appUpd'), n = $('#updPopNone'); if (n) n.hidden = !!u && !u.hidden; return; }
  if (a === 'updX') { const P = $('#updPop'); if (P) P.hidden = true; return; }
}
async function wkVer() {
  const el = $('#wkVer'); if (!el) return;
  let v = ''; try { v = chrome.runtime.getManifest().version; } catch (e) {}
  let s = null; try { s = window.kcApp && window.kcApp.updateState ? await window.kcApp.updateState() : null; } catch (e) {}
  el.textContent = ` v${v}${s ? s.state === 'latest' ? ' · 최신' : s.state === 'ready' || s.state === 'downloaded' ? ' · 새 버전 받음' : s.state === 'checking' ? ' · 확인 중' : '' : ''}`;
  const c = $('#wkCdp'), ct = $('#wkCdpT');
  try { if (window.kcApp && window.kcApp.ops) { const g = await window.kcApp.ops.get(); if (c) c.checked = !!g.cdpShow; if (ct) ct.textContent = g.cdpShow ? ' 켜짐 · 창 보임' : ' 켜짐 · 창 숨김'; } } catch (e) {}
}
function wkInit() {
  const foot = document.querySelector('.side-foot'); if (!foot || $('#wkFoot')) return;
  foot.insertAdjacentHTML('afterbegin', wkFootHTML());
  if (!$('#wkPop')) document.body.insertAdjacentHTML('beforeend', '<div class="wk-pop" id="wkPop" hidden></div>');
  if (!(window.kcApp && window.kcApp.ops)) foot.querySelectorAll('[data-app]').forEach(x => { x.hidden = true; });
  foot.addEventListener('click', e => { const b = e.target.closest('[data-wk]'); if (b) { e.preventDefault(); wkAct(b.dataset.wk); } });
  document.addEventListener('click', e => { const b = e.target.closest('#wkPop [data-wk]'); if (b) wkAct(b.dataset.wk); });
  foot.addEventListener('change', async e => {
    if (e.target.id === 'wkVac' && typeof opsSetVac === 'function') { await opsSetVac(e.target.checked); wkLog(e.target.checked ? '휴가 모드 켬' : '휴가 모드 끔', false, '완료'); }
    if (e.target.id === 'wkCdp') { try { await window.kcApp.ops.set({ cdpShow: e.target.checked }); } catch (x) {} wkVer(); }
  });
  wkPaint(); wkVer();
  setInterval(wkPaint, 5000); setInterval(wkVer, 10 * 60e3);
  // 트레이 작은 창 상태: 확인할 항목(오늘 할 일 급함·확인 + 로그인 풀림) · 마지막 갱신 · 진행 중 작업
  const tray = () => { try { if (!(window.kcApp && window.kcApp.ops && window.kcApp.ops.tray)) return; const A = typeof wktUnread === 'function' ? wktUnread() : 0, ks = (typeof acctState !== 'undefined' && acctState.kream) || {}; window.kcApp.ops.tray({ warn: A + (ks.st === 'off' ? 1 : 0), last: (typeof LKS !== 'undefined' && LKS.kream && LKS.kream.okAt) || 0, run: wkRunning() }); } catch (e) {} };
  setTimeout(tray, 3000); setInterval(tray, 30000);
}
(function wkWire() {
  // 위쪽 줄 선 작업은 끝날 때 기록해요
  if (typeof queueJob === 'function') {
    const q0 = queueJob;
    queueJob = function (fn, o) {
      const label = (o && o.label) || '작업';
      return q0(async () => { try { const r = await fn(); wkLog(label, !!(o && o.auto), (typeof stopFlag !== 'undefined' && stopFlag) ? '멈춤' : '완료'); return r; } catch (e) { wkLog(label, !!(o && o.auto), '실패 — ' + (e.message || e)); throw e; } }, o);
    };
  }
  // 11/25: 이미 돌고 있어 그냥 끝난 누름('busy')은 기록하지 않아요 — 전엔 지난 실패를 또 적어서 '로그인이 풀려 멈춤'이 줄줄이 남았어요
  if (typeof lkSync === 'function') { const s0 = lkSync; lkSync = async function (manual) { const r = await s0(manual); if (r !== 'ok' && r !== 'fail') return r; try { const K = LKS.kream || {}, tm = Object.entries(K.tm || {}).filter(([k, v]) => k && v >= 5).map(([k, v]) => `${k} ${v}초`).join(' · '); wkLog('KREAM 판매 내역 갱신', !manual, (K.err ? (/로그인/.test(K.err) ? '로그인이 풀려 멈춤' : '실패 — ' + K.err) : `완료 · 진행 중 ${K.pend || 0}건`) + (tm ? ` (${tm})` : '')); } catch (e) {} return r; }; }
  if (typeof alRun === 'function') { const r0 = alRun; alRun = async function (q) { await r0(q); try { wkLog('자동 판매 등록', !q.manual, `${q.name || q.code} ${q.size} — ${q.why || q.st}`); } catch (e) {} }; }
})();
(async function wkBoot() {
  try { WK.log = (await store.get('workLog', [])) || []; } catch (e) {}
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(wkInit, 600)); else setTimeout(wkInit, 600);
})();

// ---------- 알림 종: 오늘 할 일과 같은 목록 (줍픽 오피스 알림 종) ----------
// 11/25 사장님 «종 표시 오늘 할 일이 지울 수 없어서 계속 알림이 안 없어짐»: 전엔 오늘 할 일(급함 · 확인) 개수를 종 숫자에 늘 더해서
//   [모두 읽음] · [지우기]를 눌러도 숫자가 안 빠졌어요. 이제 종을 열어 본 줄은 읽음 · [지우기]나 ✕는 숨김 — 그 줄의 건수가 늘어날 때만 다시 세요.
//   저장 'todoSeen' = { read: {줄 열쇠: 건수}, hide: {줄 열쇠: 건수} } · 홈 '오늘 할 일' 칸은 그대로 다 보여요
function wkTodo() { try { return typeof invAlerts === 'function' && typeof INV !== 'undefined' ? invAlerts(invCalc()) : []; } catch (e) { return []; } }
const WKT = { read: {}, hide: {}, ok: false };
const wktKey = a => (a.go || '') + '|' + String(a.t || '').split(' — ')[0].replace(/\d[\d,.]*/g, '#');
const wktN = a => { const h = String(a.t || '').split(' — ')[0], m = h.match(/(\d[\d,]*)\s*(건|개)/) || h.match(/(\d[\d,]*)/); return m ? +m[1].replace(/,/g, '') || 1 : 1; };
async function wktLoad() { if (WKT.ok) return; try { const s = (await store.get('todoSeen', null)) || {}; WKT.read = s.read || {}; WKT.hide = s.hide || {}; } catch (e) {} WKT.ok = true; }
async function wktSave() { try { await store.set('todoSeen', { read: WKT.read, hide: WKT.hide }); } catch (e) {} }
const wktImp = a => a.lv === 'bad' || a.lv === 'warn';
const wktHidden = a => (WKT.hide[wktKey(a)] || 0) >= wktN(a);
// 종 숫자에 더할 것: 숨기지 않았고, 아직 안 읽었거나 읽은 뒤 건수가 늘어난 급함 · 확인 줄
function wktUnread(A) { return (A || wkTodo()).filter(a => wktImp(a) && !wktHidden(a) && (WKT.read[wktKey(a)] || 0) < wktN(a)).length; }
// kind: 'read' = 지금 있는 줄 읽음 · 'hide' = 모두 숨김 · 'show' = 숨긴 것 다시 보기 · 줄 열쇠 = 그 줄만 숨김
async function notiTodoMark(kind) {
  await wktLoad();
  const A = wkTodo(), live = new Set(A.map(wktKey));
  if (kind === 'show') WKT.hide = {};
  else for (const a of A) { const k = wktKey(a), n = wktN(a); if (kind === 'read' || kind === 'hide' || kind === k) WKT.read[k] = Math.max(WKT.read[k] || 0, n); if (kind === 'hide' || kind === k) WKT.hide[k] = n; }
  // 이제 없는 줄은 기록에서 빼요(다음에 다시 생기면 새로 알려요)
  for (const o of [WKT.read, WKT.hide]) for (const k of Object.keys(o)) if (!live.has(k)) delete o[k];
  await wktSave(); if (typeof notiBadge === 'function') notiBadge();
}
(function wkBell() {
  if (typeof notiShow === 'function') {
    const n0 = notiShow;
    notiShow = async function (open) {
      await n0(open); await wktLoad();
      const P = $('#notiPanel'); if (!open || !P) return;
      const all = wkTodo(), A = all.filter(a => !wktHidden(a)), hidN = all.length - A.length;
      if (!A.length && !hidN) return;
      const isNew = a => wktImp(a) && (WKT.read[wktKey(a)] || 0) < wktN(a);
      P.insertAdjacentHTML('afterbegin', `<div class="wk-todo"><b>오늘 할 일 ${A.length}개</b>${A.slice(0, 8).map(a => `<div class="wk-todo-r${isNew(a) ? ' new' : ''}"><span class="pill ${a.lv}">${a.lv === 'bad' ? '급함' : a.lv === 'warn' ? '확인' : '참고'}</span><span>${esc(a.t)}</span>${a.go ? `<button type="button" class="linkbtn" data-wkgo="${esc(a.go)}">보기 ›</button>` : ''}<button type="button" class="wk-todo-x" data-wkhide="${esc(wktKey(a))}" title="이 알림 숨기기 — 건수가 늘어나면 다시 알려요" aria-label="숨기기">✕</button></div>`).join('')}${hidN ? `<button type="button" class="linkbtn wk-todo-show" data-wkshow="1">숨긴 할 일 ${hidN}개 다시 보기</button>` : ''}</div>`);
      P.querySelectorAll('[data-wkgo]').forEach(b => b.addEventListener('click', async e => { e.stopPropagation(); await notiTodoMark('read'); notiShow(false); route(b.dataset.wkgo); }));
      P.querySelectorAll('[data-wkhide]').forEach(b => b.addEventListener('click', async e => { e.stopPropagation(); await notiTodoMark(b.dataset.wkhide); notiShow(true); }));
      P.querySelectorAll('[data-wkshow]').forEach(b => b.addEventListener('click', async e => { e.stopPropagation(); await notiTodoMark('show'); notiShow(true); }));
    };
  }
  if (typeof notiBadge === 'function') {
    const b0 = notiBadge;
    notiBadge = async function () { await b0(); try { await wktLoad(); const n = wktUnread(), b = $('#tBellN'); if (b && n) { const cur = b.hidden ? 0 : +String(b.textContent).replace('+', '') || 0; b.hidden = false; b.textContent = cur + n > 9 ? '9+' : String(cur + n); const bell = $('#tBell'); if (bell) bell.classList.add('has'); } } catch (e) {} };
  }
})();

// ---------- 업데이트 띠: "업데이트가 됐어요 … [업데이트 소식] ✕" (줍픽 오피스 위 띠) ----------
async function wkUpdBand() {
  let v = ''; try { v = chrome.runtime.getManifest().version; } catch (e) { return; }
  // 받은 업데이트의 바뀐 점을 미리 적어 둬요(다시 켜지면 띠에 보여요)
  try { const s = window.kcApp && window.kcApp.updateState ? await window.kcApp.updateState() : null; if (s && (s.notes || s.msg) && s.version) await store.set('updNotes', { v: s.version, notes: s.notes || [], msg: s.msg || '' }); } catch (e) {}
  const seen = await store.get('seenVer', ''); if (!seen) { await store.set('seenVer', v); return; }
  if (seen === v || $('#wkUpd')) return;
  const N = await store.get('updNotes', null), notes = N && N.v === v ? [...(N.notes || []), N.msg].filter(Boolean) : [];
  const top = document.querySelector('.topbar'); if (!top) return;
  top.insertAdjacentHTML('beforebegin', `<div class="wk-upd" id="wkUpd"><span>업데이트가 됐어요 (${esc(v)}). 무엇이 달라졌는지는 업데이트 소식에서 볼 수 있어요.</span><button type="button" class="linkbtn" data-wku="news">업데이트 소식</button><button type="button" class="wk-x" data-wku="x" aria-label="닫기">✕</button><div class="wk-news" hidden>${notes.length ? `<ul>${notes.map(t => `<li>${esc(String(t))}</li>`).join('')}</ul>` : '<p>이번 업데이트 소식은 사용 가이드 › 업데이트 소식에 정리돼요.</p>'}</div></div>`);
  const el = $('#wkUpd');
  el.addEventListener('click', async e => { const a = e.target.closest('[data-wku]'); if (!a) return; if (a.dataset.wku === 'news') { const n = el.querySelector('.wk-news'); n.hidden = !n.hidden; } else { await store.set('seenVer', v); el.remove(); } });
}
setTimeout(() => { wkUpdBand().catch(() => {}); }, 2500);
setInterval(() => { (async () => { try { const s = window.kcApp && window.kcApp.updateState ? await window.kcApp.updateState() : null; if (s && s.version && (s.notes || s.msg)) await store.set('updNotes', { v: s.version, notes: s.notes || [], msg: s.msg || '' }); } catch (e) {} })(); }, 30 * 60e3);

// ---------- 도움말 메뉴(A6) · 메뉴 안내 투어(A15) ----------
// 위쪽 [가이드]를 누르면: 시작 가이드 · 메뉴 안내 투어 · 사용 가이드 · 업데이트 소식
const TOUR = [
  ['inv:home', '홈', '오늘 할 일 · 판매처 연동 · 상품 소싱 · 아울렛 행사 · 최근 30일 숫자를 한눈에 봐요.'],
  ['inv:stock', '재고', '재고 현황 · 매입 내역 · 반품·반출. [매입 등록]으로 바코드 · 엑셀 붙여넣기로 한꺼번에 넣고, [재고 가져오기]로 판매처에만 있던 재고를 채워요.'],
  ['inv:sell', '일반 판매', 'KREAM 판매 입찰 · 공매도 · 발송 · 검수 · 판매 내역 · 확인 필요를 한 곳에서 봐요.'],
  ['inv:storage', '보관 판매', 'KREAM 보관 판매 재고의 입고 검수 · 보관 중 · 판매 · 발송을 봐요.'],
  ['inv:ledger', '장부 · 정산', '판매처별 정산 금액 · 수수료 · 지출을 정리해요. 안 맞는 거래는 경고로 알려요.'],
  ['inv:vat', '부가세', '신고 기간별 신고서 항목 · 카드별 · 신고 준비 체크리스트 · 계산 근거를 봐요.'],
  ['inv:ana', '분석', '추이 · 상품별 · 매장별 · 사이즈별 · 판매처별 · 반품률 · 월 결산 보고서.'],
  ['inv:tbuy', '오늘 살 것', '소싱 결과에서 지금 살 만한 수익 상품만 모아요. 결제만 하면 돼요 — 새 상품은 PC · 폰으로 알려요.'],
  ['inv:drops', '발매', '한정판 응모 · 선착순 · 발매 예정. 새로 올라오면 PC · 폰으로 알려요.'],
  ['inv:events', '행사', '신세계 · 롯데 · 현대 아울렛 지점별 브랜드 할인 행사. 관심 브랜드를 고르면 새 행사를 알려요.'],
  ['link', '판매처 연동', 'KREAM · POIZON 연결 상태, 새 판매 확인 주기, 긴급 정지. 자동 판매 등록 기록도 여기 있어요.'],
  ['find', '소싱 실행', '매입처에서 상품을 모아 KREAM · POIZON 시세와 비교해 수익 상품을 찾아요. 새 실행은 지난 수익 상품부터 다시 확인해요.']
];
let TOURi = -1;
function tourShow(i) {
  TOURi = i; let el = document.getElementById('tourBox');
  if (i < 0 || i >= TOUR.length) { if (el) el.remove(); store.set('tourSeen', true).catch(() => {}); return; }
  const [v, t, d] = TOUR[i]; route(v);
  if (!el) { document.body.insertAdjacentHTML('beforeend', '<div id="tourBox" class="tour"></div>'); el = document.getElementById('tourBox'); el.addEventListener('click', e => { const b = e.target.closest('[data-tour]'); if (!b) return; const a = b.dataset.tour; tourShow(a === 'next' ? TOURi + 1 : a === 'prev' ? TOURi - 1 : -1); }); }
  el.innerHTML = `<div class="tour-b"><small>메뉴 안내 ${i + 1} / ${TOUR.length}</small><b>${esc(t)}</b><p>${esc(d)}</p><div class="row-btns"><button type="button" class="ghost small" data-tour="end">그만 보기</button><span class="topsp"></span>${i ? '<button type="button" class="ghost small" data-tour="prev">이전</button>' : ''}<button type="button" class="primary small" data-tour="next">${i === TOUR.length - 1 ? '끝' : '다음'}</button></div></div>`;
  setTimeout(() => { const nav = document.querySelector(`[aria-current="true"]`); document.querySelectorAll('.tour-hl').forEach(x => x.classList.remove('tour-hl')); if (nav) { nav.classList.add('tour-hl'); nav.scrollIntoView({ block: 'nearest' }); } }, 120);
}
(function helpMenu() {
  const go = () => {
    const g = document.getElementById('tGuide'); if (!g || g.__help) return; g.__help = 1;
    const g2 = g.cloneNode(true); g.replaceWith(g2); g2.__help = 1;   // 예전 '가이드 바로 열기' 대신 도움말 메뉴
    g2.insertAdjacentHTML('afterend', `<div class="help-m" id="helpM" hidden><button type="button" data-help="start">시작 가이드</button><button type="button" data-help="tour">메뉴 안내 투어 다시 보기</button><button type="button" data-help="guide">사용 가이드</button><button type="button" data-help="news">업데이트 소식</button><button type="button" data-help="err">오류 보고서 저장</button><button type="button" data-help="kakao" id="helpKakao">카카오톡 상담</button></div>`);
    const M = document.getElementById('helpM');
    g2.addEventListener('click', e => { e.stopPropagation(); M.hidden = !M.hidden; const k = document.getElementById('tKakao'), hk = document.getElementById('helpKakao'); if (hk) hk.hidden = !k || k.hidden; });
    document.addEventListener('click', () => { M.hidden = true; });
    M.addEventListener('click', async e => {
      const a = (e.target.closest('[data-help]') || {}).dataset; if (!a) return; M.hidden = true;
      if (a.help === 'start' && typeof sgOpen === 'function') return sgOpen();
      if (a.help === 'tour') return tourShow(0);
      // 11/23: 오류 보고서 저장 (예전 설정 › 일반)
      if (a.help === 'err') { try { await kcErrReport(); if (typeof stSaved === 'function') stSaved(null, '오류 보고서를 저장했어요 — 이 파일을 보내 주시면 원인을 찾아볼게요. 아이디 · 비밀번호 · 주문 내용은 들어가지 않아요', 6000); } catch (x) { if (typeof stSaved === 'function') stSaved(null, '오류 보고서를 못 저장했어요 — ' + (x.message || x), 6000); } return; }
      if (a.help === 'guide') return route('guide');
      if (a.help === 'kakao') { const k = document.getElementById('tKakao'); if (k) k.click(); return; }
      if (a.help === 'news') { const N = await store.get('updNotes', null); return invDialog('업데이트 소식', N && ((N.notes || []).length || N.msg) ? `<p><b>${esc(N.v || '')}</b></p><ul>${[...(N.notes || []), N.msg].filter(Boolean).map(t => `<li>${esc(String(t))}</li>`).join('')}</ul>` : '<p>받은 업데이트 소식이 아직 없어요. 새 버전을 받으면 여기에 바뀐 점이 보여요.</p>', async () => {}, '닫기'); }
    });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(go, 800)); else setTimeout(go, 800);
})();

// ---------- 처음 연결: 영업비밀 안내 [확인했어요] (계정마다 한 번 · 줍픽 PC 처음 연결) ----------
async function wkTradeNotice() {
  const st = typeof LICST !== 'undefined' ? LICST : null;
  if (!st || !['ok', 'grace'].includes(st.state)) return;
  const key = 'tradeOk_' + String(st.email || 'local').toLowerCase().replace(/[^a-z0-9@._-]/g, '');
  if (await store.get(key, false)) return;
  if (document.getElementById('tradeDlg')) return;
  document.body.insertAdjacentHTML('beforeend', `<div class="br-ov" id="tradeDlg"><div class="br-box" role="dialog" aria-modal="true" aria-label="처음 연결 안내" style="width:min(560px,100%)"><h3 style="margin:0">이 PC 를 킥스캔에 연결했어요</h3>
    <p class="lk-desc">킥스캔은 이 PC 에서 KREAM · POIZON · 매입처 화면을 대신 열어 시세 · 판매 내역 · 재고를 읽고, 정해 둔 자동 작업(입찰가 조정 · 판매 등록 · 보관 신청)을 해요.</p>
    <ul class="lk-desc" style="margin:0;padding-left:18px;line-height:1.8"><li>판매처 · 매입처 아이디 · 비밀번호는 <b>이 PC 에만</b> 암호화해서 둬요 — 서버로 보내지 않아요.</li><li>소싱 방법 · 수익 계산 · 판매 규칙 같은 킥스캔 화면과 동작은 영업비밀이에요 — 화면을 그대로 옮기거나 다른 사람과 계정을 나눠 쓰지 말아 주세요.</li><li>자동 작업은 [긴급 정지]로 언제든 멈출 수 있어요.</li></ul>
    <div class="row-btns end"><button type="button" class="primary" id="tradeOk">확인했어요</button></div></div></div>`);
  document.getElementById('tradeOk').addEventListener('click', async () => { await store.set(key, Date.now()); document.getElementById('tradeDlg').remove(); });
}
setTimeout(() => wkTradeNotice().catch(() => {}), 4000);

// 로그인된 기기 (A8) — PC 는 이용권 PC 수에 들어가고, 폰 현장 앱은 들어가지 않아요
async function wkDevPaint() {
  const el = document.getElementById('wkDev'); if (!el) return;
  if (!(window.kcApp && window.kcApp.lic && window.kcApp.lic.devices)) { el.innerHTML = ''; return; }
  const r = await window.kcApp.lic.devices().catch(() => null);
  if (!r || !r.ok) { el.innerHTML = `<p class="small">${esc((r && r.message) || '기기 목록을 못 불러왔어요')}</p>`; return; }
  const ago = t => t && typeof lkAgo === 'function' ? lkAgo(Date.parse(t)) : '–';
  el.innerHTML = `<p class="small wk-sh">로그인된 기기 · PC ${r.list.length}대 (폰 현장 앱은 세지 않아요)</p><table class="wk-t2"><tbody>${r.list.map(d => `<tr><td>${esc(d.name)}${d.me ? ' <b>(이 PC)</b>' : ''}</td><td>마지막 사용 ${ago(d.last)}</td></tr>`).join('')}</tbody></table>${r.list.length > 1 ? '<button type="button" class="ghost small" data-wk="pOthers">다른 PC 모두 연결 끊기</button>' : ''}`;
}

// ---------- 알림 종류 · 밤 규칙 (A9 · 줍픽 프로필 설정 › 알림) ----------
// 종류별로 켜고 끄고, 밤 10시~아침 8시에는 윈도우 알림을 띄우지 않아요(알림 종에는 남아요) — 두 번 팔릴 위험(재고보다 많이 팔림)만 바로 알려요.
const NT_KINDS = [['order', '주문 · 판매', '새 판매 · 발송 기한 · 검수 · 폰 매입'], ['ret', '반품 · 회수 기한', '아울렛 반품 · 불합격품 회수'], ['link', '판매처 연동', '로그인 풀림 · 연동 멈춤'], ['profit', '수익 알림', '정해 둔 수익 · 가격에 닿았을 때'], ['event', '행사', '관심 브랜드 새 행사'], ['drop', '발매', '새 응모 · 선착순 · 발매 예정'], ['buy', '살 것', '오늘 살 것 — 새 수익 상품'], ['ship', '보낼 것', '매일 아침 — 크림으로 보낼 것'], ['short', '공매도', '팔린 공매도 · 매입할 것'], ['auto', '자동 작업', '입찰가 자동 조정 · 자동 판매 등록 · 보관 신청']];
let NTP = { on: { order: 1, ret: 1, link: 1, profit: 1, event: 1, drop: 1, buy: 1, ship: 1, short: 1, auto: 1 }, quiet: true };
function ntKind(t) {
  t = String(t || '');
  if (/두 번 팔|재고보다 많|모자라/.test(t)) return 'urgent';
  if (/수익 알림/.test(t)) return 'profit'; if (/보낼 것/.test(t)) return 'ship'; if (/살 것/.test(t)) return 'buy'; if (/발매|응모|선착순/.test(t)) return 'drop'; if (/행사/.test(t)) return 'event'; if (/공매도/.test(t)) return 'short';
  if (/반품|회수|기한/.test(t)) return 'ret'; if (/로그인|연동|연결/.test(t)) return 'link';
  if (/자동 입찰|입찰가|하한가|자동 판매|보관|매크로/.test(t)) return 'auto';
  return 'order';
}
const ntQuiet = () => { const h = new Date().getHours(); return NTP.quiet && (h >= 22 || h < 8); };
(function ntWire() {
  try {
    if (typeof chrome !== 'undefined' && chrome.notifications && chrome.notifications.create) {
      const c0 = chrome.notifications.create.bind(chrome.notifications);
      chrome.notifications.create = function (id, o, cb) {
        const opt = typeof id === 'object' ? id : o, k = ntKind((opt && opt.title || '') + ' ' + (opt && opt.message || ''));
        if (k !== 'urgent' && (NTP.on[k] === 0 || ntQuiet())) { if (typeof cb === 'function') cb(''); return; }
        return c0(id, o, cb);
      };
    }
  } catch (e) {}
  if (typeof notiAdd1 === 'function') { const n0 = notiAdd1; notiAdd1 = async function (title, msg) { const k = ntKind(title + ' ' + msg); if (k !== 'urgent' && NTP.on[k] === 0) return; return n0(title, msg); }; }
})();
async function ntSave() { try { await store.set('ntPref', NTP); } catch (e) {} }
function ntCard() {
  const col = document.getElementById('ntBox') || document.querySelector('#opsGen'); if (!col || document.getElementById('ntCard')) return;   // 11/23: 설정 › 내 계정 › 알림
  const sw = (id, t, sm, on) => `<div class="st-row"><div class="st-l"><b>${t}</b><small>${sm}</small></div><select id="${id}" class="st-hsel" tabindex="-1" aria-hidden="true"><option value="1"${on ? ' selected' : ''}>켬</option><option value="0"${on ? '' : ' selected'}>끔</option></select><button type="button" class="dl-sw st-sw" data-sw="${id}" role="switch" aria-label="${t}"><i></i></button></div>`;
  col.insertAdjacentHTML(col.id === 'ntBox' ? 'afterbegin' : 'beforeend', `<div id="ntCard" class="st-col"><h3 class="st-h">알림 <i class="se-q" title="윈도우 알림과 알림 종에 받을 종류예요">?</i></h3><div class="st-card">${NT_KINDS.map(([k, t, sm]) => sw('nt_' + k, t, sm, NTP.on[k] !== 0)).join('')}${sw('nt_quiet', '밤 10시~아침 8시 조용히', '윈도우 알림을 띄우지 않고 알림 종에만 남겨요 — 두 번 팔릴 위험만 바로 알려요', NTP.quiet !== false)}</div></div>`);
  col.addEventListener('change', async e => {
    const id = e.target.id || ''; if (!/^nt_/.test(id)) return;
    if (id === 'nt_quiet') NTP.quiet = e.target.value === '1'; else NTP.on[id.slice(3)] = e.target.value === '1' ? 1 : 0;
    await ntSave();
  });
  try { stSwSync(); } catch (e) {}
}
(async function ntBoot() {
  try { const p = await store.get('ntPref', null); if (p) NTP = { ...NTP, ...p, on: { ...NTP.on, ...(p.on || {}) } }; } catch (e) {}
  const go = () => setTimeout(ntCard, 1500);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
})();
