/* 킥스캔 — 행사 (줍픽 오피스 행사 /outlet-sales · C-2)
   신세계사이먼 프리미엄 아울렛 지점별 브랜드 할인(공개 sales-list)을 6시간마다 받아와요 — 본체(main-core API.ev)가 대신 불러요.
   11/25: 롯데아울렛 17곳(롯데쇼핑 지점별 쇼핑뉴스 — 패션 · 잡화 · 스포츠 · 아동) · 현대아울렛 8곳(지점별 이번 주 쇼핑뉴스)도 받아요.
   지점 번호: 신세계 '01' 꼴 · 롯데 'L0339' 꼴 · 현대 'B00172000' 꼴
   - 위 줄: [아울렛 전체 ▾] · 검색(브랜드 · 지점 · 문구) · [지점별 | 브랜드별] · 'N시간 전 업데이트' · [관심 브랜드]
   - 브랜드 칩(전체 N · 브랜드 N … +N개 더) · 새로 올라옴 N · 이번 주 마감 N
   - 지점 카드: 지점 이름 · 새 N · N건 / 줄마다 브랜드 · NEW · 최대 N% · 남은 기간 · ↗ / 행사 내용 / ‹ 1/N ›
   - 관심 브랜드 새 행사는 알림 종에 남겨요(K2) */
const EV_STORES = [['01', '신세계사이먼 프리미엄 아울렛 여주'], ['02', '신세계사이먼 프리미엄 아울렛 파주'], ['03', '신세계사이먼 프리미엄 아울렛 부산'], ['05', '신세계사이먼 프리미엄 아울렛 시흥'], ['06', '신세계사이먼 프리미엄 아울렛 제주'],
  ['L0339', '롯데프리미엄아울렛 파주점'], ['L0346', '롯데프리미엄아울렛 이천점'], ['L0331', '롯데프리미엄아울렛 김해점'], ['L0352', '롯데프리미엄아울렛 동부산점'], ['L0362', '롯데프리미엄아울렛 기흥점'], ['L0406', '롯데프리미엄아울렛 타임빌라스(의왕)'],
  ['L0360', '롯데아울렛 고양점'], ['L0347', '롯데아울렛 고양터미널점'], ['L0343', '롯데아울렛 서울역점'], ['L0351', '롯데아울렛 구리점'], ['L0342', '롯데아울렛 청주점'], ['L0345', '롯데아울렛 부여점'], ['L0021', '롯데아울렛 광주월드컵점'], ['L0332', '롯데아울렛 광주수완점'], ['L0359', '롯데아울렛 남악점'], ['L0337', '롯데아울렛 대구율하점'], ['L0338', '롯데아울렛 이시아폴리스점'],
  ['B00172000', '현대프리미엄아울렛 김포점'], ['B00174000', '현대프리미엄아울렛 송도점'], ['B00177000', '현대프리미엄아울렛 대전점'], ['B00178000', '현대프리미엄아울렛 스페이스원'],
  ['B00173000', '현대아울렛 동대문점'], ['B00171000', '현대아울렛 가산점'], ['B00175000', '현대아울렛 가든파이브점'], ['B00176000', '현대아울렛 대구점']];
const EV_MALLS = [['ss', '신세계'], ['lt', '롯데'], ['hd', '현대']];
const evMall = c => /^L/.test(c) ? 'lt' : /^B/.test(c) ? 'hd' : 'ss';
const evShort = n => String(n || '').replace('신세계사이먼 프리미엄 아울렛 ', '신세계 ').replace(/^롯데(프리미엄)?아울렛 /, '롯데 ').replace(/^현대(프리미엄)?아울렛 /, '현대 ');
// 원문 링크 (지점 · 행사 번호로)
function evLink(e) {
  const m = evMall(e.code);
  if (m === 'lt') return `https://www.lotteshopping.com/shpgnews/shpgnewsDetail?shpgNewsNo=${encodeURIComponent(e.id)}`;
  if (m === 'hd') return `https://www.ehyundai.com/newPortal/SN/SN_0201000.do?evntCrdCd=${encodeURIComponent(e.id)}&category=event&branchCd=${e.code}`;
  return `https://www.premiumoutlets.co.kr/rpage/shopping-info/news/${e.code}`;
}
const EV_TTL = 6 * 3600e3;
let EVD = { at: 0, stores: {} }, EVF = [];
const evS = () => IS.ev || (IS.ev = { mall: '', q: '', by: 'store', brand: '', chip: '', page: {}, pg: 1, more: false });
const evTxt = h => String(h || '').replace(/<br\s*\/?>/gi, ' · ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
const evDay = s => { const m = String(s || '').match(/(\d{4})[.-](\d{1,2})[.-](\d{1,2})/); return m ? `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}` : ''; };
function evItems() {
  const out = [];
  for (const [code, name] of EV_STORES) for (const x of ((EVD.stores[code] || {}).items || [])) {
    const to = evDay(x.to), from = evDay(x.from), created = evDay(x.created);
    if (to && to < today()) continue;
    const rate = (String(x.title || '').match(/(?:최대|최고)?\s*(\d{2})\s*(?:~|-)\s*(\d{2})\s*%/) || String(x.title || '').match(/(?:최대|최고)\s*(\d{2})\s*%/));
    out.push({ ...x, code, store: name, to, from, isNew: created && dday(created) >= -7, left: to ? dday(to) : null, rateTxt: rate ? (rate[2] ? `최대 ${rate[2] > rate[1] ? rate[2] : rate[1]}%` : `최대 ${rate[1]}%`) : '' });
  }
  return out;
}
function evFiltered() {
  const S0 = evS(), q = S0.q.trim().toLowerCase();
  return evItems().filter(e => (!S0.mall || e.code === S0.mall || S0.mall === 'g:' + evMall(e.code)) && (!S0.brand || e.brand === S0.brand) && (!q || [e.brand, e.en, e.store, e.title].join(' ').toLowerCase().includes(q))
    && (S0.chip !== 'new' || e.isNew) && (S0.chip !== 'week' || (e.left != null && e.left <= 7)));
}
function evRow(e) {
  const left = e.left == null ? '' : e.left <= 1 ? `<span class="ev-due bad">${e.left === 0 ? '오늘까지' : '내일까지'}</span>` : e.left <= 7 ? `<span class="ev-due">${e.left}일 남음</span>` : `<span class="ev-due mute">~${e.to.slice(5).replace('-', '/')}</span>`;
  const fav = EVF.includes(e.brand);
  return `<div class="ev-row"><div class="ev-r1"><b>${fav ? '★ ' : ''}${esc(e.brand)}</b>${e.isNew ? '<span class="ev-new">NEW</span>' : ''}${e.rateTxt ? `<span class="ev-rate">${esc(e.rateTxt)}</span>` : ''}<span class="topsp"></span>${left}<a class="ev-go" href="${esc(evLink(e))}" target="_blank" rel="noopener" title="원문">↗</a></div>
    <div class="ev-r2">${esc(evTxt(e.title).slice(0, 80) || '할인 행사')}</div><div class="ev-r3">${esc(e.place || '본 매장 · 조건은 원문에서')}</div></div>`;
}
function evCard(title, L, key) {
  const S0 = evS(), per = 3, pages = Math.max(1, Math.ceil(L.length / per)), p = Math.min(S0.page[key] || 1, pages);
  const nNew = L.filter(e => e.isNew).length;
  return `<div class="ev-card"><div class="ev-ch"><b>${esc(title)}</b><span>${nNew ? `<em class="ev-n">새 ${nNew}</em>` : ''}${L.length}건</span></div>
    <div class="ev-rows">${L.slice((p - 1) * per, p * per).map(evRow).join('')}</div>
    ${pages > 1 ? `<div class="ev-pg"><button type="button" class="ghost tiny" data-a="evPg" data-k="${esc(key)}" data-v="${p - 1}"${p <= 1 ? ' disabled' : ''}>‹</button><span>${p} / ${pages}</span><button type="button" class="ghost tiny" data-a="evPg" data-k="${esc(key)}" data-v="${p + 1}"${p >= pages ? ' disabled' : ''}>›</button></div>` : ''}</div>`;
}
function vEvents() {
  const S0 = evS(), all = evItems(), L = evFiltered();
  const byBrand = {}; for (const e of all) byBrand[e.brand] = (byBrand[e.brand] || 0) + 1;
  const brands = Object.entries(byBrand).sort((a, b) => (EVF.includes(b[0]) - EVF.includes(a[0])) || b[1] - a[1]);
  const showB = S0.more ? brands : brands.slice(0, 12);
  const sortFav = arr => arr.sort((a, b) => (EVF.includes(b.brand) - EVF.includes(a.brand)) || (a.left ?? 999) - (b.left ?? 999));
  let cards = '';
  if (S0.by === 'brand') {
    const G = {}; for (const e of L) (G[e.brand] = G[e.brand] || []).push(e);
    cards = Object.entries(G).sort((a, b) => (EVF.includes(b[0]) - EVF.includes(a[0])) || b[1].length - a[1].length).map(([b, X]) => evCard(b, X.map(e => ({ ...e, brand: evShort(e.store) + ' · ' + e.brand })), 'b:' + b)).join('');
  } else cards = EV_STORES.filter(([c]) => !S0.mall || c === S0.mall || S0.mall === 'g:' + evMall(c)).map(([c, n]) => { const X = sortFav(L.filter(e => e.code === c)); return X.length ? evCard(n, X, 's:' + c) : ''; }).join('');
  const ago = EVD.at ? (typeof lkAgo === 'function' ? lkAgo(EVD.at) : '') + ' 업데이트' : '아직 안 받아왔어요';
  return `${head('행사', '신세계 · 롯데 · 현대 아울렛 지점별 브랜드 할인 행사를 모아 봐요.', `<span class="small">${ago}</span><button type="button" class="ghost" data-a="evLoad"${IS.evBusy ? ' disabled' : ''}>${IS.evBusy ? '받는 중…' : '↻ 새로 받기'}</button><button type="button" class="primary" data-a="evFav">관심 브랜드${EVF.length ? ` ${EVF.length}` : ''}</button>`)}${typeof flash === 'function' ? flash() : ''}
  <div class="stk-bar"><select data-k="evMall"><option value="">아울렛 전체</option>${EV_MALLS.map(([g, gn]) => `<optgroup label="${gn}"><option value="g:${g}"${S0.mall === 'g:' + g ? ' selected' : ''}>${gn} 전체</option>${EV_STORES.filter(([c]) => evMall(c) === g).map(([c, n]) => `<option value="${c}"${S0.mall === c ? ' selected' : ''}>${esc(evShort(n))}</option>`).join('')}</optgroup>`).join('')}</select><input data-k="evQ" value="${esc(S0.q)}" placeholder="브랜드 · 지점 · 문구 검색" class="stk-q"><span class="ev-seg"><button type="button" class="chip${S0.by === 'store' ? ' on' : ''}" data-a="evBy" data-v="store">지점별</button><button type="button" class="chip${S0.by === 'brand' ? ' on' : ''}" data-a="evBy" data-v="brand">브랜드별</button></span></div>
  ${EVD.fails && EVD.fails.length ? `<div class="ev-note"><span>이번에 못 받은 지점: ${esc(EVD.fails.map(c => evShort((EV_STORES.find(x => x[0] === c) || [c, c])[1])).join(', '))} — 다음 받기 때 다시 받아요</span></div>` : ''}
  <div class="stk-bar ev-chips"><button type="button" class="chip${!S0.brand ? ' on' : ''}" data-a="evBrand" data-v="">전체 ${all.length}</button>${showB.map(([b, n]) => `<button type="button" class="chip${S0.brand === b ? ' on' : ''}" data-a="evBrand" data-v="${esc(b)}">${EVF.includes(b) ? '★ ' : ''}${esc(b)} ${n}</button>`).join('')}${brands.length > 12 ? `<button type="button" class="chip" data-a="evMore">${S0.more ? '접기' : `+${brands.length - 12}개 더`}</button>` : ''}<span class="topsp"></span>
    <button type="button" class="chip${S0.chip === 'new' ? ' on' : ''}" data-a="evChip" data-v="new">새로 올라옴 ${all.filter(e => e.isNew).length}</button><button type="button" class="chip${S0.chip === 'week' ? ' on' : ''}" data-a="evChip" data-v="week">이번 주 마감 ${all.filter(e => e.left != null && e.left <= 7).length}</button></div>
  <div class="ev-grid">${cards || `<div class="panel dl-empty"><span>${EVD.at ? '조건에 맞는 행사가 없어요' : '[↻ 새로 받기]를 누르면 아울렛 행사를 받아와요'}</span></div>`}</div>
  <p class="hint">${S0.by === 'store' ? `지점 ${EV_STORES.filter(([c]) => (EVD.stores[c] || {}).items).length}곳` : `브랜드 ${new Set(L.map(e => e.brand)).size}개`} · 신세계 · 롯데 · 현대 아울렛 공개 행사(쇼핑뉴스) 기준 · 6시간마다 새로 받아요</p>`;
}
async function evLoad(quiet) {
  if (IS.evBusy || !(window.kcApp && window.kcApp.ev)) return;
  IS.evBusy = true; if (!quiet) { try { renderInv(); } catch (e) {} }
  const before = new Set(evItems().map(e => e.code + ':' + e.id)); let fails = 0;
  const hadStore = new Set(Object.keys(EVD.stores).filter(c => (EVD.stores[c] || {}).items));   // 처음 받는 지점(11/25 롯데 · 현대)은 '새 행사' 알림에서 빼요 — 한꺼번에 울리지 않게
  const E = window.kcApp.ev, failed = [];
  for (const [c] of EV_STORES) {
    const m = evMall(c), fn = m === 'lt' ? E.lotte : m === 'hd' ? E.hd : E.ss;
    if (typeof fn !== 'function') continue;   // 본체가 옛 판이면 신세계만
    try { const items = await fn(m === 'lt' ? c.slice(1) : c); EVD.stores[c] = { at: Date.now(), items }; } catch (e) { fails++; failed.push(c); }
    if (m !== 'ss') await new Promise(r => setTimeout(r, 300));   // 롯데 · 현대 사이트는 천천히
  }
  EVD.at = Date.now(); EVD.fails = failed; IS.evBusy = false;
  try { await store.set('evData', EVD); } catch (e) {}
  // K2: 관심 브랜드에 새 행사가 올라오면 알림 종에
  if (before.size && EVF.length && typeof notiAdd1 === 'function') { const nw = evItems().filter(e => EVF.includes(e.brand) && hadStore.has(e.code) && !before.has(e.code + ':' + e.id)); for (const e of nw.slice(0, 5)) await notiAdd1(`관심 브랜드 새 행사 — ${e.brand}`, `${e.store} · ${evTxt(e.title).slice(0, 80)}`); try { notiBadge(); } catch (x) {}
    // 11/25: 폰 알림도 (한 번에 묶어서)
    if (nw.length && typeof pushSend === 'function') pushSend('event', `관심 브랜드 새 행사 ${nw.length}건`, nw.slice(0, 3).map(e => `${e.brand} — ${evShort(e.store)} · ${evTxt(e.title).slice(0, 40)}`).join('\n'), './', 'event-' + Date.now()).catch(() => {}); }
  if (!quiet) { IS.msg = fails ? `행사를 받았어요 (못 받은 지점 ${fails}곳)` : '아울렛 행사를 새로 받았어요'; try { renderInv(); } catch (e) {} }
}
async function evAct(a, el) {
  const S0 = evS(), v = el.dataset.v;
  switch (a) {
    case 'evLoad': return evLoad(false);
    case 'evBy': S0.by = v; S0.page = {}; break;
    case 'evBrand': S0.brand = v; S0.page = {}; break;
    case 'evChip': S0.chip = S0.chip === v ? '' : v; S0.page = {}; break;
    case 'evMore': S0.more = !S0.more; break;
    case 'evPg': S0.page[el.dataset.k] = Math.max(1, +v || 1); break;
    case 'evFav': {
      const all = evItems(), cnt = {}; for (const e of all) cnt[e.brand] = (cnt[e.brand] || 0) + 1;
      const B = Object.entries(cnt).sort((a, b) => b[1] - a[1]);
      return invDialog('관심 브랜드', `<p class="hint">고른 브랜드의 행사를 먼저 보여 드려요. 하나도 안 고르면 전부 보입니다. 고른 브랜드에 새 행사가 올라오면 알림 종으로 알려요.</p><div class="ev-favs">${B.map(([b, n]) => `<label class="chip${EVF.includes(b) ? ' on' : ''}"><input type="checkbox" name="fav" value="${esc(b)}"${EVF.includes(b) ? ' checked' : ''}> ${esc(b)} ${n}</label>`).join('') || '<p class="small">먼저 [↻ 새로 받기]로 행사를 받아 주세요</p>'}</div>`, async (fd, form) => {
        EVF = [...form.querySelectorAll('input[name=fav]:checked')].map(x => x.value); await store.set('evFav', EVF); IS.msg = `관심 브랜드 ${EVF.length}개를 저장했어요`; renderInv();
      });
    }
  }
  renderInv();
}
function evInput(el, ev) {
  const S0 = evS(), k = el.dataset.k;
  if (k === 'evMall') { S0.mall = el.value; S0.page = {}; renderInv(); }
  if (k === 'evQ') { S0.q = el.value; clearTimeout(evInput.t); evInput.t = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=evQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, ev.type === 'input' ? 300 : 0); }
}
(async function evBoot() {
  try { EVD = (await store.get('evData', null)) || EVD; EVF = (await store.get('evFav', [])) || []; } catch (e) {}
  setTimeout(() => { if (Date.now() - (EVD.at || 0) > EV_TTL) evLoad(true).catch(() => {}); }, 90e3);
  setInterval(() => { if (Date.now() - (EVD.at || 0) > EV_TTL) evLoad(true).catch(() => {}); }, 30 * 60e3);
})();
