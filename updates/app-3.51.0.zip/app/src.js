// 소싱 계산 (설계서 1-3-1 계산 규칙 · 1-6) — 순수 함수만 둬요. 화면은 srcres.js, 수집은 srceng.js.
// node 로 시험해요: require('./src.js')

// ---------- 할인 반영 매입가 (1-6) ----------
// 순서: 상품 쿠폰 → 장바구니·중복 쿠폰 → 등급 할인 → 적립금 선할인 → 결제 즉시할인
// 단계마다 '지금까지 깎인 값'에 %를 매기고(원 미만 버림) 정액(원)을 더해요. 최대(cap)가 있으면 그 이상은 안 깎고,
// 최소 주문 금액(min)보다 싸면 그 단계는 건너뛰어요. 깎는 값은 남은 값보다 클 수 없어요.
const SD_STEPS = [['coupon', '상품 쿠폰'], ['cart', '장바구니·중복 쿠폰'], ['grade', '등급 할인'], ['point', '적립금 선할인'], ['pay', '결제 즉시할인']];
function sdCalc(tag, cfg, on) {
  const t = Math.max(0, Math.round(+tag || 0));
  let p = t; const steps = [];
  for (const [k, label] of SD_STEPS) {
    const c = (cfg && cfg[k]) || {};
    if (on && on[k] === false) { steps.push({ k, label, amt: 0, off: true }); continue; }
    let a = Math.floor(p * (+c.pct || 0) / 100) + Math.round(+c.won || 0);
    if (+c.cap > 0) a = Math.min(a, Math.round(+c.cap));
    if (+c.min > 0 && p < +c.min) a = 0;
    a = Math.max(0, Math.min(a, p));
    p -= a; steps.push({ k, label, amt: a });
  }
  return { tag: t, steps, disc: t - p, final: p };
}
// disc = { on:{coupon:true,…}, def:{…모든 구매처}, sites:{ [k]: { own:true, gname, off, coupon:{pct,won,cap,min}, … } } }
function sdCfgFor(disc, k) { const s = disc && disc.sites && disc.sites[k]; if (s && s.off) return null; return s && s.own ? s : (disc && disc.def) || {}; }
// 3.36.8: 매입처 상품 화면에서 읽은 '로그인 없이 보이는 쿠폰·혜택가'(b.benefit) — 목록 가격이 읽을 때와 같을 때만 써요
function srcBuyBase(b) { const z = b && b.benefit; return z && z.price > 0 && z.base === b.price && z.price < b.price ? { price: z.price, page: true, all: !!z.all, pay: +z.pay || 0 } : { price: b && b.price, page: false }; }
// b(매입처 항목)를 주면 화면 쿠폰·혜택가를 먼저 빼고, 그 쿠폰과 겹치는 설정(상품 쿠폰·장바구니 쿠폰)은 건너뛰어요
function sdBuy(disc, k, price, b) {
  const base = b ? srcBuyBase(b) : { page: false };
  if (!base.page) return sdCalc(price, sdCfgFor(disc, k), disc && disc.on);
  // 화면 값에 이미 들어간 할인은 설정에서 또 빼지 않아요 — 쿠폰은 늘, 결제혜택을 계산했으면 결제 즉시할인도, 무신사 최대혜택가(로그인)면 전부
  const skip = base.all ? ['coupon', 'cart', 'grade', 'point', 'pay'] : base.pay ? ['coupon', 'cart', 'pay'] : ['coupon', 'cart'];
  const on = { ...((disc && disc.on) || {}) }; for (const x of skip) on[x] = false;
  const r = sdCalc(base.price, sdCfgFor(disc, k), on);
  const pg = Math.max(0, Math.round(+price - base.price));
  const [l1, l2] = String(b.benefit.label || '혜택가').split(' − ');
  const pre = base.pay ? [{ k: 'page', label: '화면 쿠폰 · ' + l1, amt: Math.max(0, pg - base.pay) }, { k: 'pagepay', label: '화면 ' + (l2 || '결제혜택'), amt: Math.min(pg, base.pay) }]
    : [{ k: 'page', label: (base.all ? '' : '화면 쿠폰 · ') + l1, amt: pg }];
  r.steps = [...pre, ...r.steps.filter(s => !skip.includes(s.k))];
  r.tag = Math.round(+price); r.disc += pg; r.page = true;
  return r;
}
function sdProfit(sell, fee, ship, buy) { return Math.round((+sell || 0) - (+fee || 0) - (+ship || 0) - (+buy || 0)); }
function sdRate(profit, buy) { return buy > 0 ? Math.round(profit / buy * 1000) / 10 : null; }
function sdLimit(sell, fee, ship) { return Math.round((+sell || 0) - (+fee || 0) - (+ship || 0)); }

// ---------- 소싱 행 계산 (1-3-1) ----------
const SRC_CALC_DEF = { sellers: ['kream'], minWon: 0, minRate: 0, min30: 5, unknownStock: false, vatRefund: true, rec: { div: 3, max: 5, bidHalf: true }, disc: null };
// 3.39: POIZON 은 로그인 없이 30일 판매가 안 보여요 — 누적 거래가 이 수 이상인 상품은 팔리는 상품으로 보고 사이즈마다 1개만 권장해요
const SRC_PZ_SOLD = 1000;
const srcDay = s => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) / 864e5 : null; };
// 부가세 환급 = 매입가 ÷ 11 (반올림) — POIZON(해외) 판매만
const srcVat = buy => Math.round((+buy || 0) / 11);
// 권장 수량(초안): floor(30일 판매 ÷ div) 최대 max · KREAM 판매 입찰(+5% 안)이 30일 판매보다 많으면 절반
// · 개당 수익 < 최소 수익(또는 0 이하)·수익률 미달이면 0 · 매입처 재고를 알면 재고까지
function srcRec(n30, asks5, profit, rate, stock, c) {
  c = c || {};
  const r = { ...SRC_CALC_DEF.rec, ...(c.rec || {}) };
  if (profit == null || profit <= 0 || profit < (+c.minWon || 0)) return 0;
  if (+c.minRate && !(rate >= +c.minRate)) return 0;
  let q = Math.min(+r.max || 0, Math.floor((+n30 || 0) / (+r.div || 3)));
  if (r.bidHalf && asks5 != null && n30 != null && asks5 > n30) q = Math.floor(q / 2);
  if (stock != null && stock >= 0) q = Math.min(q, stock);
  return Math.max(0, q);
}
// 판매처 하나·사이즈 하나의 개당 수익 (POIZON 은 부가세 환급을 더하고, 환급 전은 cash)
function srcSell(seller, price, buy, env, vatOn) {
  if (price == null || !(price > 0) || buy == null) return null;
  const fee = seller === 'poizon' ? env.pFee(price) : env.kFee(price), ship = seller === 'poizon' ? (env.pShip || 0) : (env.ship || 0);
  const cash = sdProfit(price, fee, ship, buy), vat = seller === 'poizon' && vatOn ? srcVat(buy) : 0;
  return { price, fee, ship, cash, vat, profit: cash + vat };
}
// 수익 한도 = 개당 수익이 0 이 되는 매입가 (POIZON 환급 포함이면 (판매가−수수료−발송비) × 11/10)
function srcLimit(seller, price, env, vatOn) {
  if (!(price > 0)) return null;
  const net = seller === 'poizon' ? price - env.pFee(price) - (env.pShip || 0) : price - env.kFee(price) - (env.ship || 0);
  return seller === 'poizon' && vatOn ? Math.floor(net * 11 / 10) : Math.round(net);
}
// 값 여유 = 개당 수익이 0 이 될 때까지 판매가를 내릴 수 있는 비율 (0~1, 수수료가 계단이라 나눠서 찾아요)
function srcRoom(seller, price, buy, env, vatOn) {
  const s0 = srcSell(seller, price, buy, env, vatOn); if (!s0 || s0.profit <= 0) return 0;
  let lo = 0, hi = price;
  for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2, s = srcSell(seller, m, buy, env, vatOn); if (s && s.profit > 0) hi = m; else lo = m; }
  return Math.floor((1 - hi / price) * 1000) / 1000;
}
// 가격 변화 = 최근 14일 평균 거래가 ÷ 그 전 기간(15~90일) 평균 − 1
function srcPriceChange(trades, today) {
  const t0 = srcDay(today); if (t0 == null || !Array.isArray(trades)) return null;
  const a = [], b = [];
  for (const x of trades) { const d = srcDay(x.d); if (d == null || !(x.p > 0)) continue; const age = t0 - d; if (age < 0) continue; if (age < 14) a.push(x.p); else if (age < 90) b.push(x.p); }
  if (!a.length || !b.length) return null;
  const av = v => v.reduce((s, x) => s + x, 0) / v.length;
  return Math.round((av(a) / av(b) - 1) * 1000) / 1000;
}
// 판매 추세: 30일 3개 미만 → 거래 부족 · 최근 14일이 그 전 16일(14일 기준으로 맞춤)보다 25% 넘게 많으면 증가, 적으면 감소
// 11/26 사장님 «소싱 제품이 1개만»: 14일은 KREAM 숫자뿐인데 30일은 POIZON 숫자(수천 개)와 비교해 수익 상품 19개 중 18개가 '판매 감소'로
//   잡혀 '판매 감소 제외' 필터에 숨었어요 — 추세는 KREAM 14일 · KREAM 30일끼리만 재고, KREAM 거래가 모자라면 '추세 모름'(POIZON 은 14일 숫자가 없어요)
function srcTrendK(n14, kn30, n30) { return n14 != null && kn30 != null && kn30 >= 3 ? srcTrend(n14, kn30) : (n30 || 0) >= 3 ? '추세 모름' : '거래 부족'; }
function srcTrend(n14, n30) {
  if (n30 == null || n30 < 3) return '거래 부족';
  const prior = Math.max(0, n30 - (n14 || 0)) * 14 / 16;
  if ((n14 || 0) > prior * 1.25) return '판매 증가';
  if ((n14 || 0) < prior * 0.75) return '판매 감소';
  return '변동 없음';
}
const srcSizeSort = (a, b) => { const na = parseFloat(a), nb = parseFloat(b); if (!isNaN(na) && !isNaN(nb)) return na - nb; const O = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', '2XL', '3XL']; return (O.indexOf(String(a).toUpperCase()) - O.indexOf(String(b).toUpperCase())) || String(a).localeCompare(String(b)); };
// 신발 mm → EU (대략, 나이키 공용표)
const SRC_EU = { 220: '35.5', 225: '36', 230: '36.5', 235: '37.5', 240: '38', 245: '38.5', 250: '39', 255: '40', 260: '40.5', 265: '41', 270: '42', 275: '42.5', 280: '43', 285: '44', 290: '44.5', 295: '45', 300: '45.5', 305: '46', 310: '47' };
const srcEu = s => SRC_EU[String(s)] || '';

// row(srcRows 한 항목) → 사이즈별 계산과 상품 요약
// calc = store 'srcCalc' · opt = { seller:'kream'|'poizon'|'' (판매처 필터), instant:bool (KREAM 즉시 판매가 기준) }
// env = { kFee(price), pFee(price), ship, pShip, today:'YYYY-MM-DD' }
function srcCalcRow(row, calc, env, opt) {
  const c = { ...SRC_CALC_DEF, ...(calc || {}), rec: { ...SRC_CALC_DEF.rec, ...((calc && calc.rec) || {}) } };
  opt = opt || {};
  env = { kFee: () => 0, pFee: () => 0, ship: 0, pShip: 0, ...(env || {}) };
  { const kF = env.kFee, pF = env.pFee; env.kFee = p => kF(p, row); env.pFee = p => pF(p, row); }   // 3.42: 수수료 할인 규칙이 품번을 보게 줄을 넘겨요
  let sellers = (c.sellers && c.sellers.length ? c.sellers : ['kream']).filter(s => !opt.seller || s === opt.seller);
  if (opt.seller && !sellers.length) sellers = [opt.seller];
  const K = (row.kream && row.kream.sizes) || {}, P = (row.poizon && row.poizon.sizes) || {};
  const offers = (row.buy || []).filter(b => b && b.on !== false && b.price > 0).map(b => ({ b, d: sdBuy(c.disc, b.site, b.price, b) }));
  const names = new Set([...Object.keys(K), ...Object.keys(P)]);
  for (const o of offers) if (o.b.stock && o.b.stock.by) Object.keys(o.b.stock.by).forEach(s => names.add(s));
  const sizes = [];
  for (const s of [...names].sort(srcSizeSort)) {
    // 이 사이즈를 살 수 있는 가장 싼 매입처 (사이즈 재고를 모르면 '재고 미확인 사이즈 포함' 설정에 따라)
    let off = null, stock = null, known = false;
    for (const o of offers) {
      const st = o.b.stock, by = st && st.by && Object.keys(st.by).length ? st.by : null;
      let n = null, ok;
      if (by) { n = +by[s] || 0; ok = n > 0; } else if (st && st.total != null) ok = st.total > 0; else ok = !!c.unknownStock;
      if (!ok) continue;
      if (!off || o.d.final < off.d.final) { off = o; stock = n; known = !!by; }
    }
    const k = K[s] || null, p = P[s] || null;
    const buy = off ? off.d.final : null;
    const kPrice = k ? (opt.instant ? k.bid : (k.ask ?? k.bid)) : null;
    const per = {};
    if (sellers.includes('kream') && k) per.kream = Object.assign({ price: kPrice, profit: null }, srcSell('kream', kPrice, buy, env, false) || {}, {
      inst: srcSell('kream', k.bid, buy, env, false), bidP: srcSell('kream', k.ask, buy, env, false), n30: k.n30 ?? null });
    const pzSold = row.poizon && row.poizon.sold != null ? +row.poizon.sold : null, pzEst = !!p && p.n30 == null && pzSold != null && pzSold >= SRC_PZ_SOLD;
    if (sellers.includes('poizon') && p) per.poizon = Object.assign({ price: p.price, profit: null }, srcSell('poizon', p.price, buy, env, c.vatRefund) || {}, { n30: p.n30 ?? null, sold: pzSold, est: pzEst, noTrade: !(p.trades && p.trades.length) && !p.n30 && !pzEst });
    let best = null;
    for (const [sl, v] of Object.entries(per)) if (v.profit != null && (!best || v.profit > best.profit)) best = { seller: sl, ...v };
    const n30 = best ? (best.n30 ?? null) : (k ? k.n30 ?? null : p ? p.n30 ?? null : null);
    const rate = best && buy ? sdRate(best.profit, buy) : null;
    const est = !!(best && best.seller === 'poizon' && best.est);
    const q = best ? (est ? Math.min(1, srcRec(+c.rec.div || 3, null, best.profit, rate, known ? stock : null, c)) : srcRec(n30, best.seller === 'kream' && k ? k.asks5 : null, best.profit, rate, known ? stock : null, c)) : 0;
    sizes.push({
      size: s, eu: srcEu(s), offer: off ? off.b : null, disc: off ? off.d : null, buy, tag: off ? off.b.price : null, list: off ? (off.b.list || off.b.price) : null, stock, stockKnown: known,
      per, best, n30, est, n14: k ? k.n14 ?? null : null, kn30: k ? k.n30 ?? null : null, n90: k ? k.n90 ?? null : null, nFast30: k ? k.nFast30 ?? null : null, last: k ? k.last || null : null,
      asks: k ? k.asks ?? null : null, asks5: k ? k.asks5 ?? null : null, rate, q, sub: best ? q * best.profit : 0,
      limit: best ? srcLimit(best.seller, best.price, env, best.seller === 'poizon' && c.vatRefund) : null,
      room: best && buy != null ? srcRoom(best.seller, best.price, buy, env, best.seller === 'poizon' && c.vatRefund) : null,
      period: n30 > 0 ? Math.round(30 / n30 * 10) / 10 : null, trend: srcTrendK(k ? k.n14 ?? null : null, k ? k.n30 ?? null : null, n30) });
  }
  const rec = sizes.filter(x => x.q > 0), sum = (a, f) => a.reduce((t, x) => t + (+f(x) || 0), 0);
  const qty = sum(rec, x => x.q), monthly = sum(rec, x => x.sub), buyAmt = sum(rec, x => x.q * x.buy), cashSum = sum(rec, x => x.q * x.best.cash);
  const n30All = sum(sizes, x => x.n30), n14All = sum(sizes, x => x.n14);
  const kz = sizes.filter(x => x.n14 != null && x.kn30 != null), n14K = kz.length ? sum(kz, x => x.n14) : null, n30K = kz.length ? sum(kz, x => x.kn30) : null;
  const t0 = srcDay(env.today);
  const lastD = rec.map(x => srcDay(x.last)).filter(d => d != null);
  const allTrades = Object.values(K).flatMap(x => x.trades || []);
  const bySeller = {}; for (const x of rec) bySeller[x.best.seller] = (bySeller[x.best.seller] || 0) + x.sub;
  const prof = sizes.filter(x => x.best && x.best.profit > 0);
  const buys = offers.map(o => o.d.final), minBuy = buys.length ? Math.min(...buys) : null, minOff = offers.find(o => o.d.final === minBuy) || null;
  // 11/22 줍픽 수익 상품 기준: POIZON 30일 판매(min30) · KREAM 30일 체결(kmin30, 없으면 min30)을 판매처마다 따로
  const sellersC = c.sellers || ['kream'], kmin = c.kmin30 != null && c.kmin30 !== '' ? +c.kmin30 : +c.min30 || 0;
  const sumK = sum(sizes, x => x.per && x.per.kream ? x.per.kream.n30 : 0), sumP = sum(sizes, x => x.per && x.per.poizon ? x.per.poizon.n30 : 0);
  const ok30 = (sellersC.includes('kream') && sumK >= kmin) || (sellersC.includes('poizon') && sumP >= (+c.min30 || 0)) || (!sellersC.includes('kream') && !sellersC.includes('poizon') && n30All >= (+c.min30 || 0)) || rec.some(x => x.est);
  return {
    sizes, rec, qty, monthly, buyAmt,
    avg: qty ? Math.round(monthly / qty) : (prof.length ? Math.max(...prof.map(x => x.best.profit)) : null),
    cashAvg: qty ? Math.round(cashSum / qty) : null, rate: buyAmt ? Math.round(monthly / buyAmt * 1000) / 10 : null,
    n30All, n14All, n14K, n30K, recN30: sum(rec, x => x.n30), recN14: sum(rec, x => x.n14), recN90: sum(rec, x => x.n90),
    lastDays: lastD.length && t0 != null ? t0 - Math.max(...lastD) : null, lastDate: lastD.length ? new Date(Math.max(...lastD) * 864e5).toISOString().slice(0, 10) : null,
    change: srcPriceChange(allTrades, env.today), trend: srcTrendK(n14K, n30K, n30All), sellers: Object.entries(bySeller).sort((a, b) => b[1] - a[1]).map(x => x[0]),
    buy: minBuy, list: minOff ? (minOff.b.list || minOff.b.price) : null, offer: minOff ? minOff.b : null,
    room: rec.length ? Math.min(...rec.map(x => x.room ?? 1)) : null, limit: rec.length ? Math.min(...rec.map(x => x.limit)) : null,
    profitable: qty > 0 && ok30, outside: !(qty > 0 && ok30) && prof.length > 0, ok30,
    stockTotal: offers.some(o => o.b.stock) ? offers.reduce((t, o) => t + (o.b.stock && o.b.stock.total != null ? +o.b.stock.total : o.b.stock && o.b.stock.by ? Object.values(o.b.stock.by).reduce((a, n) => a + (+n || 0), 0) : 0), 0) : null,
    noBid: rec.length > 0 && rec.every(x => !x.asks),
  };
}
if (typeof module !== 'undefined' && module.exports) module.exports = { sdCalc, sdCfgFor, sdBuy, srcBuyBase, sdProfit, sdRate, sdLimit, srcVat, srcRec, srcSell, srcLimit, srcRoom, srcPriceChange, srcTrend, srcCalcRow, srcEu, SD_STEPS, SRC_CALC_DEF };
