'use strict';
/* 킥스캔 — 보낼 것 (11/25 자동화 3번: 결제 · 포장 발송만 사장님)
   크림으로 보내야 하는 것을 모아 홈 '오늘 할 일'에 한 줄로 · 매일 아침(기본 9시) 한 번 알림 종 · 윈도우 · 폰 알림
   - 일반 판매: 체결돼서 발송해야 하는 것(auto.js kSales.pending — 새 판매 확인 주기마다 갱신)
   - 보관 판매: 보관 신청했는데 아직 크림 창고로 안 보낸 것(크림 보관판매 내역 kInv · 그 뒤에 매크로로 신청 완료한 것 stockLog)
   상태 글은 크림 화면 글 기준이라 '발송 대기 · 입고 대기 · 신청 완료'처럼 보내기 전 상태만 세요(검수 · 배송 중 · 보관 중은 빼요)
   저장: 'sbState' { day(알린 날) } */
const SB_SEND = /발송\s*대기|발송\s*요청|입고\s*대기|입고\s*요청|신청\s*완료|체결|발송\s*필요/;
const SB_NOT = /검수|배송\s*중|입고\s*중|입고\s*완료|보관\s*중|정산|취소|반송|회수|완료됨|판매\s*완료/;
let SBS = { day: '' };
const sbDay = (t = Date.now()) => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const sbToSend = s => { s = String(s || ''); return SB_SEND.test(s) && !SB_NOT.test(s); };

function sbList() {
  const sell = (typeof kSales !== 'undefined' && kSales && Array.isArray(kSales.pending) ? kSales.pending : []).filter(p => sbToSend(p.status));
  let keep = [], invAt = 0;
  try { if (typeof kInv !== 'undefined' && kInv && Array.isArray(kInv.items)) { invAt = kInv.at || 0; keep = kInv.items.filter(i => sbToSend(i.statusName || i.status)); } } catch (e) {}
  // 크림 보관 내역을 읽은 뒤에 매크로로 신청 완료한 것(다음에 내역을 읽으면 위 keep 으로 들어와요)
  const after = typeof stockLog !== 'undefined' && Array.isArray(stockLog) ? stockLog.filter(x => x.result === '신청 완료' && x.t > invAt && Date.now() - x.t < 14 * 864e5) : [];
  const afterN = after.reduce((t, x) => t + (+x.qty || 1), 0);
  const due = sell.map(p => typeof kDday === 'function' && p.exp ? kDday(p.exp) : null).filter(d => d != null);
  return { sell, keep, after, n: sell.length + keep.length + afterN, keepN: keep.length + afterN, soon: due.length ? Math.min(...due) : null, invAt };
}
function sbText(L) {
  const parts = [];
  if (L.sell.length) parts.push(`일반 판매 발송 ${L.sell.length}건${L.soon != null && L.soon <= 1 ? ` (기한 ${L.soon <= 0 ? '오늘' : '내일'})` : ''}`);
  if (L.keepN) parts.push(`보관 판매 입고 ${L.keepN}개`);
  return parts.join(' · ');
}

// 홈 '오늘 할 일'에 한 줄
(function sbWire() {
  if (typeof invAlerts !== 'function') return;
  const f = invAlerts;
  invAlerts = function (C) {
    const A = f.apply(this, arguments);
    try {
      const L = sbList();
      if (L.n) A.push({ lv: L.soon != null && L.soon <= 1 ? 'bad' : 'warn', t: `크림으로 보낼 것 ${L.n}개 — ${sbText(L)} · 모아서 한 상자로 보내면 돼요`, go: L.sell.length ? 'inv:sell' : 'inv:storage' });
    } catch (e) {}
    return A;
  };
})();

// 매일 아침 한 번 알림 (기본 9시 · 설정 › 알림 규칙의 '보낼 것'으로 끄기)
async function sbTick(force) {
  try {
    const now = new Date(), d = sbDay();
    if (!force && (SBS.day === d || now.getHours() < 9)) return null;
    const L = sbList();
    SBS.day = d; await store.set('sbState', SBS);
    if (!L.n) return L;
    const title = `오늘 크림으로 보낼 것 ${L.n}개`;
    const body = `${sbText(L)}\n모아서 한 상자로 보내고, 송장은 크림 발송관리에 넣어 주세요`;
    const cr = window.chrome && chrome.notifications && chrome.notifications.create;
    if (cr) { try { chrome.notifications.create('sb-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title, message: body, priority: 1 }); } catch (e) {} }
    if (!(cr && cr.__ks) && typeof notiAdd1 === 'function') { await notiAdd1(title, body.replace(/\n/g, ' · ')); try { notiBadge(); } catch (e) {} }
    if (typeof pushSend === 'function') { try { await pushSend('ship', title, body, './', 'ship-' + d); } catch (e) {} }
    return L;
  } catch (e) { console.warn('shipbox', e); return null; }
}
(async function sbBoot() {
  try { SBS = { ...SBS, ...((await store.get('sbState', null)) || {}) }; } catch (e) {}
  setTimeout(() => sbTick().catch(() => {}), 90e3);
  setInterval(() => sbTick().catch(() => {}), 10 * 60e3);
})();
