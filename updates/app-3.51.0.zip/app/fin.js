'use strict';
/* 킥스캔 — 개선판 1-9 · 1-10: 정산 · 지출 · 부가세 신고 자료 · 엑셀 붙여넣기 입고
   inv.js 의 데이터(INV) · 계산(invCalc · outNums · ledgerRows) · 화면 조각(card · head)을 그대로 써요.
   지출은 INV.expenses 에 저장해요 — 백업 · 초기화에 같이 들어가요. */

const EXP_CATS = ['택배비', '유류비', '주차비', '포장재', '기타'];
const FIN = { exp: { m: '', mode: 'cal' }, paste: '' };   // 화면마다 잠깐 들고 있는 상태
const finYm = (d, add = 0) => { const x = new Date(d.slice(0, 7) + '-01T00:00:00'); x.setMonth(x.getMonth() + add); return fmtD(x).slice(0, 7); };
const finPct = (a, b) => b ? `${a >= b ? '+' : '−'}${Math.abs(Math.round((a - b) / b * 1000) / 10)}%` : (a ? '새로 생김' : '–');

// ---------- 지출 → 장부 줄 (ledgerRows 가 불러요) ----------
function finLedgerRows() {
  return (INV.expenses || []).map(x => ({ date: x.date, kind: '지출', desc: x.cat + (x.memo ? ' · ' + x.memo : ''), partner: x.where || '', partnerId: '', pay: payOf(x.payId)?.name || '', payId: x.payId || '', amount: -(+x.amount || 0), memo: '', expId: x.id, cat: x.cat, vatIn: x.vat ? +x.amount || 0 : 0 }));
}
const finExpSum = (a, b, cat) => (INV.expenses || []).reduce((s, x) => s + (inRange(x.date, a, b) && (!cat || x.cat === cat) ? +x.amount || 0 : 0), 0);

// ---------- 지출 화면 (장부 · 정산 › 지출) ----------
function finExpView() {
  const F = FIN.exp; if (!F.m) F.m = today().slice(0, 7);
  const a = F.m + '-01', b = monthEnd(a), pa = finYm(a, -1) + '-01', pb = monthEnd(pa);
  const L = (INV.expenses || []).filter(x => inRange(x.date, a, b)).sort((x, y) => x.date.localeCompare(y.date) || (x.at || 0) - (y.at || 0));
  const tot = finExpSum(a, b), prev = finExpSum(pa, pb), diff = tot - prev;
  const byCat = EXP_CATS.map(c => ({ c, v: finExpSum(a, b, c), p: finExpSum(pa, pb, c) })), cmx = Math.max(1, ...byCat.map(x => x.v));
  const top = byCat.slice().sort((x, y) => y.v - x.v)[0];
  const [yy, mm] = F.m.split('-').map(Number);
  const bar = `<div class="panel kh-bar"><div class="kh-row"><span class="kh-lab">${ico('cal')}${yy}년 ${mm}월</span><button type="button" class="kq" data-a="expMon" data-v="-1">이전 달</button><button type="button" class="kq" data-a="expMon" data-v="0">이번 달</button><button type="button" class="kq" data-a="expMon" data-v="1">다음 달</button><span class="topsp"></span><button type="button" class="kq${F.mode === 'cal' ? ' on' : ''}" data-a="expMode" data-v="cal">달력</button><button type="button" class="kq${F.mode === 'list' ? ' on' : ''}" data-a="expMode" data-v="list">목록</button><button type="button" class="primary" data-a="expAdd" data-v="">지출 추가</button><button type="button" class="ghost" data-a="expXl">엑셀 내려받기</button></div></div>`;
  const cards = `<div class="kgrid">${card('이번 달 지출', won(tot), tot ? 'neg' : '', L.length + '건')}${card('지난달 대비', (diff > 0 ? '+' : '') + wonS(diff), diff > 0 ? 'neg' : diff < 0 ? 'pos' : '', `지난달 ${won(prev)} · ${finPct(tot, prev)}`)}${card('가장 많이 쓴 항목', top && top.v ? top.c : '–', 'acc', top && top.v ? won(top.v) : '')}${card('하루 평균', won(Math.round(tot / Math.max(1, F.m === today().slice(0, 7) ? +today().slice(8, 10) : +b.slice(8, 10)))), '')}</div>`;
  const cats = `<div class="box"><h3>항목별 (지난달 대비)</h3><div class="lg-bars">${byCat.map(x => `<div class="lg-bar"><span>${x.c}</span><i><b style="width:${x.v ? Math.max(2, Math.round(x.v / cmx * 100)) : 0}%"></b></i><em>${won(x.v)} · <span class="${x.v > x.p ? 'neg' : x.v < x.p ? 'pos' : 'sub'}">${x.v === x.p ? '같음' : (x.v > x.p ? '+' : '−') + won(Math.abs(x.v - x.p))}</span></em></div>`).join('')}</div><p class="hint">택배비는 매입가에 섞지 말고 발송할 때마다(회차별로) 넣어요. 판매 출고에 적은 택배비는 장부에 따로 잡혀요.</p></div>`;
  let body;
  if (F.mode === 'list') {
    body = L.length ? `<div class="tbl"><table><thead><tr><th class="l">날짜</th><th class="l">항목</th><th>금액</th><th class="l">결제수단</th><th class="l">부가세 증빙</th><th class="l">메모</th><th></th></tr></thead><tbody>${L.map(x => `<tr><td class="l">${x.date}</td><td class="l"><span class="pill mute">${esc(x.cat)}</span></td><td class="neg"><b>${won(+x.amount)}</b></td><td class="l">${esc(payOf(x.payId)?.name || '–')}</td><td class="l">${x.vat ? '<span class="pill ok">있음</span>' : '<span class="sub">없음</span>'}</td><td class="l small">${esc(x.memo || '')}</td><td><button type="button" class="ghost tiny" data-a="expEdit" data-id="${x.id}">고치기</button> <button type="button" class="ghost tiny" data-a="expDel" data-id="${x.id}">삭제</button></td></tr>`).join('')}</tbody></table></div>`
      : `<div class="panel dl-empty">${ico('truck')}<span>이 달에 넣은 지출이 없어요.</span><button type="button" class="primary" data-a="expAdd" data-v="">지출 추가</button></div>`;
  } else {
    const first = new Date(a + 'T00:00:00').getDay(), days = +b.slice(8, 10), cells = [];
    for (let i = 0; i < first; i++) cells.push('<div></div>');
    for (let d = 1; d <= days; d++) {
      const ds = F.m + '-' + String(d).padStart(2, '0'), xs = L.filter(x => x.date === ds), s = xs.reduce((t, x) => t + (+x.amount || 0), 0);
      cells.push(`<div class="box" data-a="expAdd" data-v="${ds}" title="${ds} 지출 추가" style="min-height:66px;padding:6px 8px;cursor:pointer;display:grid;align-content:start;gap:2px${ds === today() ? ';outline:2px solid var(--acc)' : ''}"><span class="small sub">${d}</span>${s ? `<b class="neg small" style="white-space:nowrap">${won(s)}</b><span class="small sub">${xs.length > 1 ? xs.length + '건' : esc(xs[0].cat)}</span>` : ''}</div>`);
    }
    body = `<div class="box"><div style="display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:6px">${['일', '월', '화', '수', '목', '금', '토'].map(w => `<div class="small sub" style="text-align:center">${w}</div>`).join('')}${cells.join('')}</div><p class="hint">날짜를 누르면 그날 지출을 넣어요. 고치거나 지우려면 [목록]으로 봐요.</p></div>`;
  }
  return bar + cards + `<div class="igrid2">${cats}<div>${body}</div></div>`;
}
function finExpDialog(x, date) {
  const e = x || { date: date || today(), cat: '택배비', amount: '', payId: '', vat: false, memo: '' };
  return invDialog(x ? '지출 고치기' : '지출 추가', `<div class="dgrid"><label>날짜<input type="date" name="date" value="${esc(e.date)}"></label><label>항목<select name="cat">${EXP_CATS.map(c => opt(c, c, c === e.cat)).join('')}</select></label><label>금액 (원) *<input type="number" name="amount" min="1" required value="${esc(e.amount)}"></label><label>결제수단<select name="payId"><option value="">–</option>${INV.pays.map(p => opt(p.id, p.name, p.id === e.payId)).join('')}</select></label><label>부가세 증빙<select name="vat">${opt('0', '없음', !e.vat)}${opt('1', '있음 (카드 · 세금계산서, 부가세 포함 금액)', !!e.vat)}</select></label><label class="wide">메모<input name="memo" value="${esc(e.memo || '')}" placeholder="택배비는 발송 회차 · 송장 수 (예: 11/20 2차 발송 5박스)"></label></div>`, async fd => {
    const amount = Math.round(num(fd.amount)); if (!(amount > 0)) return '금액을 넣어 주세요';
    const v = { date: fd.date || today(), cat: EXP_CATS.includes(fd.cat) ? fd.cat : '기타', amount, payId: fd.payId || '', vat: fd.vat === '1', memo: String(fd.memo || '').trim() };
    INV.expenses = INV.expenses || [];
    if (x) Object.assign(x, v); else INV.expenses.push({ id: uid(), at: Date.now(), ...v });
    FIN.exp.m = v.date.slice(0, 7);
    await invSave(); IS.msg = x ? '지출을 고쳤어요' : `${v.cat} ${won(amount)} 넣었어요`; renderInv();
  });
}

// ---------- 정산 화면 (장부 · 정산 › 정산) — 판매처별 ----------
function finSettleView(a, b) {
  const sells = INV.partners.filter(p => p.kind === 'sell'), G = {};
  const g0 = id => G[id] = G[id] || { rev: 0, fees: 0, sold: 0, n: 0, pendQ: 0, pendV: 0, zero: 0, noCost: 0 };
  for (const o of INV.outs) {
    const g = g0(o.partnerId || '-');
    if (o.settled) {
      if (!inRange(o.settleDate, a, b)) continue;
      const n = outNums(o); g.rev += n.rev; g.fees += n.fees; g.sold += n.net; g.n++;
      if (!o.price && n.net > 0) g.zero++;
      if (!(o.costs || []).length && n.net > 0) g.noCost++;
    } else { const n = outNums(o); g.pendQ += n.net; g.pendV += n.net * n.unitCost; }
  }
  // 크림에서 팔렸는데 재고관리에 못 넣은 판매 (상품 미등록 등)
  const have = new Set(INV.outs.map(o => String(o.kreamSaleId || '')));
  const U = typeof kSales !== 'undefined' && kSales && kSales.unrec ? Object.entries(kSales.unrec).filter(([id, u]) => !have.has(id) && (!u.date || inRange(u.date, a, b))).map(([, u]) => u) : [];
  const T = Object.values(G).reduce((t, g) => ({ rev: t.rev + g.rev, fees: t.fees + g.fees, pendQ: t.pendQ + g.pendQ, pendV: t.pendV + g.pendV, zero: t.zero + g.zero, noCost: t.noCost + g.noCost }), { rev: 0, fees: 0, pendQ: 0, pendV: 0, zero: 0, noCost: 0 });
  const warn = [];
  if (U.length) warn.push(`크림에서 팔린 ${U.length}건(정산 ${won(U.reduce((s, u) => s + (+u.payout || 0), 0))})이 장부에 없어요 — 판매 내역과 정산이 안 맞아요. 상품을 등록하고 크림 판매를 다시 불러와요.`);
  if (T.zero) warn.push(`판매가 0원으로 정산된 출고가 ${T.zero}건 있어요. 판매가를 넣어 주세요.`);
  if (T.noCost) warn.push(`매입원가가 안 잡힌 판매가 ${T.noCost}건 있어요 — 마진이 실제보다 크게 보여요.`);
  const W = warn.map(t => `<div class="kw-warn">${ico('scale')}<span>${esc(t)}</span></div>`).join('');
  const rows = sells.map(p => ({ p, g: G[p.id] })).filter(x => x.g && (x.g.n || x.g.pendQ));
  if (G['-'] && (G['-'].n || G['-'].pendQ)) rows.push({ p: { name: '판매처 없음', tax: '' }, g: G['-'] });
  const blocks = rows.map(({ p, g }) => `<p class="lg-sec">${esc(p.name)}${p.tax ? ` <span class="pill ${p.tax === '영세' ? 'warn' : 'mute'}">${p.tax === '영세' ? '영세율' : p.tax}</span>` : ''}</p><div class="kgrid">${card('정산 금액', won(g.rev - g.fees), 'acc', `판매 ${g.sold}개 · 매출 − 수수료`)}${card('매출액', won(g.rev), '', '판매가 합계 (할인 · 반품 뺀 금액)')}${card('수수료', won(g.fees), g.fees ? 'warn' : '', g.rev ? `매출의 ${(g.fees / g.rev * 100).toFixed(1)}%` : '')}${card('정산 예정', g.pendQ + '개', g.pendQ ? 'warn' : '', g.pendQ ? `아직 안 팔림 · 매입가 ${won(Math.round(g.pendV))}` : '')}</div>`).join('');
  return `<div class="kgrid">${card('정산 금액 (전체)', won(T.rev - T.fees), 'acc', '기간 안에 정산된 판매')}${card('매출액', won(T.rev), '')}${card('수수료', won(T.fees), '')}${card('정산 예정', T.pendQ + '개', T.pendQ ? 'warn' : '', '크림 보관 등 아직 안 팔린 것')}</div>
  ${W}
  ${blocks || `<div class="panel dl-empty">${ico('receipt')}<span>이 기간에 정산된 판매가 없어요.</span></div>`}
  <div class="row-btns end"><button type="button" class="ghost" data-a="settleXl">엑셀 내려받기</button></div>
  <p class="hint">판매처마다 계정 하나로 봐요. 판매처 과세 구분(과세 · 영세)은 기본정보 › 거래처에서 바꿔요.</p>`;
}

// ---------- 부가세 (일반과세자) — 신고 기간 · 신고서 항목별 공급가액 · 세액 ----------
const VAT_PER = { h1: ['1기 확정 (1~6월)', [1, 2, 3, 4, 5, 6], '07-25', 0], q1: ['1기 예정 (1~3월)', [1, 2, 3], '04-25', 0], q2: ['1기 확정 (4~6월, 예정 신고한 경우)', [4, 5, 6], '07-25', 0], h2: ['2기 확정 (7~12월)', [7, 8, 9, 10, 11, 12], '01-25', 1], q3: ['2기 예정 (7~9월)', [7, 8, 9], '10-25', 0], q4: ['2기 확정 (10~12월, 예정 신고한 경우)', [10, 11, 12], '01-25', 1] };
function finVatPeriod(V) {
  if (!VAT_PER[V.per]) V.per = V.half === 2 ? 'h2' : 'h1';
  const [label, ms, due, ny] = VAT_PER[V.per], y = V.year, mm = m => String(m).padStart(2, '0');
  V.half = ms[0] <= 6 ? 1 : 2;
  return { label, ms, from: `${y}-${mm(ms[0])}-01`, to: monthEnd(`${y}-${mm(ms[ms.length - 1])}-01`), due: `${y + ny}-${due}` };
}
// 장부 줄 하나를 신고서 항목으로: side out(매출) · in(매입), deduct(세액 계산 대상), zero(영세율)
function finVatLine(r) {
  const p = r.partnerId ? partnerOf(r.partnerId) : null;
  if (['매출', '매출반품', '할인'].includes(r.kind)) {
    const g = r.gross != null ? r.gross : r.amount;
    // 3.42(11/23 검수): 국내 매출(과세) · 해외 매출(영세율, POIZON)을 나눠 보여요. 판매처의 과세 구분이 비어 있어도 POIZON 은 영세율, KREAM 은 과세로 봐요
    const tax = p && p.tax ? p.tax : p && typeof isPoizon === 'function' && isPoizon(p) ? '영세' : p && (p.id === 'p-kream' || /크림|KREAM/i.test(p.name || '')) ? '과세' : '';
    if (tax === '과세') return { side: 'out', cat: '국내 매출 · 과세 (KREAM 등)', g, tx: true };
    if (tax === '영세') return { side: 'out', cat: '해외 매출 · 영세율 (POIZON)', g, zero: true };
    if (tax === '면세') return { side: 'out', cat: '면세 매출', g };
    return { side: 'out', cat: '기타 매출 (과세 구분 없음)', g };
  }
  if (r.kind === '수기 수입') return r.vatOut ? { side: 'out', cat: '과세 매출 (수기)', g: r.amount, tx: true } : { side: 'out', cat: '수기 수입 (증빙 없음)', g: r.amount };
  const g = -r.amount, ok = !!r.vatIn;
  if (r.kind === '매입' || r.kind === '매입반품') return { side: 'in', cat: ok ? '상품 매입 (공제)' : '상품 매입 (공제 안 됨)', g, tx: ok };
  if (r.kind === '수수료') return { side: 'in', cat: ok ? '판매 수수료 (공제)' : '판매 수수료 (영세 판매처 · 공제 안 됨)', g, tx: ok };
  if (r.kind === '지출') return { side: 'in', cat: ok ? `지출 · ${r.cat || '기타'} (공제)` : `지출 · ${r.cat || '기타'} (증빙 없음)`, g, tx: ok };
  if (r.kind === '택배비') return { side: 'in', cat: '판매 출고 택배비 (증빙 확인 필요)', g };
  if (r.kind === '수기 지출') return { side: 'in', cat: ok ? '수기 지출 (공제)' : '수기 지출 (증빙 없음)', g, tx: ok };
  return { side: 'in', cat: r.kind, g };
}
function finVatCalc(R, P) {
  const L = [];
  for (const r of R) {
    if (!inRange(r.date, P.from, P.to)) continue;
    const v = finVatLine(r); if (!v.g) continue;
    const tax = v.tx ? Math.round(v.g / 11) : 0;
    L.push({ r, ...v, tax, sup: v.g - tax });
  }
  L.sort((x, y) => x.r.date.localeCompare(y.r.date));
  const C = {};
  for (const x of L) { const k = x.side + '|' + x.cat, c = C[k] = C[k] || { side: x.side, cat: x.cat, n: 0, g: 0, sup: 0, tax: 0, tx: x.tx, zero: x.zero }; c.n++; c.g += x.g; c.sup += x.sup; c.tax += x.tax; }
  // 국내 · 해외 매출 줄은 0원이어도 늘 보여요 (POIZON 매출이 생기면 어디로 가는지 알 수 있게)
  for (const [cat, f] of [['국내 매출 · 과세 (KREAM 등)', { tx: true }], ['해외 매출 · 영세율 (POIZON)', { zero: true }]]) { const k = 'out|' + cat; if (!C[k]) C[k] = { side: 'out', cat, n: 0, g: 0, sup: 0, tax: 0, ...f }; }
  const cats = Object.values(C).sort((a, b) => (a.side === b.side ? 0 : a.side === 'out' ? -1 : 1) || b.g - a.g);
  const sum = (side, f) => L.filter(x => x.side === side).reduce((s, x) => s + x[f], 0);
  return { L, cats, outT: sum('out', 'tax'), inT: sum('in', 'tax'), outG: sum('out', 'g'), inG: sum('in', 'g'), outS: sum('out', 'sup'), inS: sum('in', 'sup') };
}
function finVatGeneral(V, R, yearSel, bars) {
  const P = finVatPeriod(V), D = finVatCalc(R, P), diff = D.outT - D.inT, dd = dday(P.due);
  const catSum = side => D.cats.filter(c => c.side === side).reduce((s, c) => s + c.g, 0);
  const ok = catSum('out') === D.outG && catSum('in') === D.inG;   // 항목별 합계 = 원장 합계
  const tr = c => `<tr><td class="l">${c.side === 'out' ? '매출' : '매입'}</td><td class="l">${esc(c.cat)}${c.zero ? ' <span class="pill warn">영세율</span>' : ''}</td><td>${c.n}건</td><td>${wonS(c.g)}</td><td>${wonS(c.sup)}</td><td>${c.tx ? wonS(c.tax) : '<span class="sub">–</span>'}</td></tr>`;
  const sub = (t, g, s, x) => `<tr><td class="l" colspan="3"><b>${t}</b></td><td><b>${wonS(g)}</b></td><td><b>${wonS(s)}</b></td><td><b>${wonS(x)}</b></td></tr>`;
  return `${head('부가세 예상 (일반과세자)', '신고 기간을 고르면 매입 · 판매 · 지출을 신고서 항목별 공급가액 · 세액으로 나눠요.', `<button type="button" class="primary" data-a="vatXl">세무사용 엑셀 내려받기</button>`)}${flash()}
  <div class="filters">${yearSel}<select data-k="vatPer">${Object.entries(VAT_PER).map(([k, x]) => opt(k, x[0], V.per === k)).join('')}</select></div>
  <div class="kw-warn soft">${ico('gavel')}<span><b>신고를 대신하지 않고, 판단은 세무사가 합니다.</b> 여기 숫자는 장부로 낸 참고 자료예요.</span></div>
  <div class="kgrid">${card('신고 기한', dd >= 0 ? `D-${dd}` : `${-dd}일 지남`, dd < 0 ? 'neg' : dd <= 14 ? 'warn' : 'acc', `${P.due} (주말 · 공휴일이면 다음 평일)`)}${card('매출세액', won(D.outT), '', `과세 매출 공급가액 ${won(D.cats.filter(c => c.side === 'out' && c.tx).reduce((s, c) => s + c.sup, 0))}`)}${card('매입세액 (공제)', won(D.inT), '', '상품 매입 + 수수료 + 증빙 있는 지출 (반품 뺌)')}${card(diff >= 0 ? '납부 예상' : '환급 예상', won(Math.abs(diff)), diff >= 0 ? 'neg' : 'pos', P.label)}</div>
  <div class="tbl"><table><thead><tr><th class="l">구분</th><th class="l">신고서 항목</th><th>건수</th><th>합계금액</th><th>공급가액</th><th>세액</th></tr></thead><tbody>
    ${D.cats.filter(c => c.side === 'out').map(tr).join('')}${sub('매출 합계', D.outG, D.outS, D.outT)}
    ${D.cats.filter(c => c.side === 'in').map(tr).join('')}${sub('매입 합계', D.inG, D.inS, D.inT)}
    ${D.L.length ? '' : '<tr><td colspan="6" class="empty">이 기간에 기록이 없어요</td></tr>'}</tbody></table></div>
  <p class="hint">${ok ? '검산: 항목별 합계가 매출 · 매입 원장 합계와 같아요.' : '<span class="neg">검산: 항목별 합계와 원장 합계가 달라요 — 문의해 주세요.</span>'} 매출 원장 ${wonS(D.outG)} · 매입 원장 ${wonS(D.inG)} (엑셀의 원장 시트와 같아요)</p>
  ${bars}
  <p class="hint">구매처에 반품한 매입은 반품한 날 빼요. '영세'로 둔 판매처(포이즌 등 수출)는 세액이 0원이에요. 결제수단을 '부가세 증빙 없음'으로 둔 매입과 증빙 없는 지출은 공제에서 빠져요. 세금계산서 · 카드 구분은 세무사와 확인하세요.</p>`;
}
function finVatXl() {
  const V = IS.vat, P = finVatPeriod(V), D = finVatCalc(ledgerRows(), P);
  const led = side => { const xs = D.L.filter(x => x.side === side), n = xs.length + 1; return [['날짜', '구분', '신고서 항목', '내용', '거래처', '결제수단', '합계금액', '공급가액', '세액'], ...xs.map(x => [x.r.date, x.r.kind, x.cat, x.r.desc, x.r.partner, x.r.pay, x.g, x.sup, x.tax]), ['합계', '', '', '', '', '', { f: `SUM(G2:G${n})` }, { f: `SUM(H2:H${n})` }, { f: `SUM(I2:I${n})` }]]; };
  const S = [['구분', '신고서 항목', '건수', '합계금액', '공급가액', '세액', '원장 합계 (검산)']];
  const add = side => { const nm = side === 'out' ? '매출 원장' : '매입 원장', i0 = S.length + 1; for (const c of D.cats.filter(c => c.side === side)) S.push([side === 'out' ? '매출' : '매입', c.cat, c.n, c.g, c.sup, c.tax, { f: `SUMIF('${nm}'!C:C,B${S.length + 1},'${nm}'!G:G)` }]); const i1 = S.length, tot = `'${nm}'!G${D.L.filter(x => x.side === side).length + 2}`; S.push(i1 < i0 ? [side === 'out' ? '매출 합계' : '매입 합계', '', 0, 0, 0, 0, { f: tot }] : [side === 'out' ? '매출 합계' : '매입 합계', '', { f: `SUM(C${i0}:C${i1})` }, { f: `SUM(D${i0}:D${i1})` }, { f: `SUM(E${i0}:E${i1})` }, { f: `SUM(F${i0}:F${i1})` }, { f: tot }]); };
  add('out'); add('in');
  S.push([], ['납부(−면 환급) 예상', '', '', '', '', D.outT - D.inT], [], ['신고 기간', P.label + ` ${P.from} ~ ${P.to}`], ['신고 기한', P.due + ' (주말 · 공휴일이면 다음 평일)'], ['사업자', (bizCur() || {}).name || ''], ['안내', '킥스캔 장부로 낸 참고 자료예요. 신고를 대신하지 않고, 판단은 세무사가 합니다.']);
  xlDownload([{ name: '요약', rows: S, widths: [16, 34, 8, 14, 14, 12, 16] }, { name: '매출 원장', rows: led('out'), widths: [12, 10, 26, 40, 14, 14, 14, 14, 12] }, { name: '매입 원장', rows: led('in'), widths: [12, 10, 30, 40, 14, 14, 14, 14, 12] }], `킥스캔_부가세_${V.year}_${P.label.split(' ')[0]}${P.label.split(' ')[1]}_${P.from.slice(5, 7)}-${P.to.slice(5, 7)}월.xlsx`);
}

// ---------- 엑셀 붙여넣기 입고 (엑셀 대량 입고 화면 안) ----------
function finPasteBox() {
  return `<div class="panel"><h2>붙여넣어 입고</h2><p class="hint">엑셀에서 <b>품번 · 사이즈 · 수량 · 매입가</b> 순서로 칸을 복사해 아래에 붙여넣어요. 첫 줄이 제목(품번 · 사이즈 …)이면 칸 이름으로 맞춰요.</p>
  <textarea data-k="xlPaste" rows="5" placeholder="DD1391-100&#9;270&#9;1&#9;129000&#10;MR530KA&#9;260&#9;2&#9;82000">${esc(FIN.paste)}</textarea>
  <div class="row-btns"><span class="topsp"></span><button type="button" class="ghost" data-a="xlPasteClear">지우기</button><button type="button" class="primary" data-a="xlPasteGo">미리보기</button></div></div>`;
}
function finPasteParse(text) {
  const lines = String(text || '').replace(/\r/g, '').split('\n').filter(l => l.trim());
  if (!lines.length) throw new Error('붙여넣은 내용이 없어요');
  const split = l => l.includes('\t') ? l.split('\t') : l.includes(',') && !/\d,\d{3}/.test(l) ? l.split(',') : l.trim().split(/\s{2,}|\s+/);
  const rows = lines.map(l => split(l).map(v => v.trim()));
  const hasHead = rows[0].some(v => XL_COLS.code.test(v)) && rows[0].some(v => XL_COLS.size.test(v));
  return hasHead ? rows : [['품번', '사이즈', '수량', '매입가'], ...rows];
}

// ---------- 정산 엑셀 ----------
function finSettleXl() {
  const F = IS.lg, R = [['판매처', '과세 구분', '정산일', '상품', '사이즈', '수량', '매출액', '수수료', '정산 금액']];
  for (const o of INV.outs) { if (!o.settled || !inRange(o.settleDate, F.from, F.to)) continue; const n = outNums(o), p = partnerOf(o.partnerId); R.push([p?.name || '', p?.tax || '', o.settleDate, itName(itemOf(o.itemId)), o.size, n.net, n.rev, n.fees, n.rev - n.fees]); }
  R.sort((a, b) => a === R[0] ? -1 : b === R[0] ? 1 : String(a[0]).localeCompare(String(b[0])) || String(a[2]).localeCompare(String(b[2])));
  const n = R.length; R.push(['합계', '', '', '', '', { f: `SUM(F2:F${n})` }, { f: `SUM(G2:G${n})` }, { f: `SUM(H2:H${n})` }, { f: `SUM(I2:I${n})` }]);
  const sells = {}; for (const r of R.slice(1, -1)) { const s = sells[r[0]] = sells[r[0]] || [r[0], r[1], 0, 0, 0, 0]; s[2] += r[5]; s[3] += r[6]; s[4] += r[7]; s[5] += r[8]; }
  const S = [['판매처', '과세 구분', '수량', '매출액', '수수료', '정산 금액'], ...Object.values(sells)]; const m = S.length;
  S.push(['합계', '', { f: `SUM(C2:C${m})` }, { f: `SUM(D2:D${m})` }, { f: `SUM(E2:E${m})` }, { f: `SUM(F2:F${m})` }]);
  xlDownload([{ name: '판매처별', rows: S, widths: [14, 10, 8, 14, 12, 14] }, { name: '정산 내역', rows: R, widths: [12, 10, 12, 36, 8, 6, 14, 12, 14] }], `킥스캔_정산_${F.from}_${F.to}.xlsx`);
}
function finExpXl() {
  const F = FIN.exp, a = F.m + '-01', b = monthEnd(a), L = (INV.expenses || []).filter(x => inRange(x.date, a, b)).sort((x, y) => x.date.localeCompare(y.date));
  const R = [['날짜', '항목', '금액', '결제수단', '부가세 증빙', '메모'], ...L.map(x => [x.date, x.cat, +x.amount, payOf(x.payId)?.name || '', x.vat ? '있음' : '없음', x.memo || ''])]; const n = R.length;
  R.push(['합계', '', { f: `SUM(C2:C${n})` }]);
  const pa = finYm(a, -1) + '-01', pb = monthEnd(pa), C = [['항목', '이번 달', '지난달', '증감'], ...EXP_CATS.map((c, i) => [c, finExpSum(a, b, c), finExpSum(pa, pb, c), { f: `B${i + 2}-C${i + 2}` }])];
  C.push(['합계', { f: `SUM(B2:B${EXP_CATS.length + 1})` }, { f: `SUM(C2:C${EXP_CATS.length + 1})` }, { f: `B${EXP_CATS.length + 2}-C${EXP_CATS.length + 2}` }]);
  xlDownload([{ name: '지출 목록', rows: R, widths: [12, 10, 12, 14, 10, 36] }, { name: '항목별', rows: C, widths: [12, 14, 14, 14] }], `킥스캔_지출_${F.m}.xlsx`);
}

// ---------- 버튼 · 입력 (inv.js 의 invAct · invInput 이 모르는 것만 여기로 와요) ----------
async function finAct(a, el) {
  const id = el.dataset.id, v = el.dataset.v;
  switch (a) {
    case 'expAdd': return finExpDialog(null, v || '');
    case 'expEdit': { const x = (INV.expenses || []).find(e => e.id === id); return x ? finExpDialog(x) : undefined; }
    case 'expDel': { const x = (INV.expenses || []).find(e => e.id === id); if (!x) return; return invDialog('지출 지우기', `<p>${esc(x.date)} ${esc(x.cat)} ${won(+x.amount)}을 지울까요?</p>`, async () => { INV.expenses = INV.expenses.filter(e => e.id !== id); await invSave(); IS.msg = '지웠어요'; renderInv(); }, '지우기'); }
    case 'expMon': FIN.exp.m = +v ? finYm((FIN.exp.m || today().slice(0, 7)) + '-01', +v) : today().slice(0, 7); return renderInv();
    case 'expMode': FIN.exp.mode = v; return renderInv();
    case 'expXl': return finExpXl();
    case 'settleXl': return finSettleXl();
    case 'vatXl': return finVatXl();
    case 'xlPasteClear': FIN.paste = ''; IS.xl = null; return renderInv();
    case 'xlPasteGo': {
      const ta = document.querySelector('[data-k=xlPaste]'); if (ta) FIN.paste = ta.value;
      try { xlBuild(finPasteParse(FIN.paste), '붙여넣은 내용', true); } catch (e) { IS.xl = { file: '붙여넣은 내용', rows: [], msg: e.message }; }
      const X = IS.xl, bad = X ? X.rows.filter(r => r.err).length : 0;
      if (X && X.rows.length) IS.msg = `${X.rows.length}줄을 읽었어요${bad ? ` — 오류 ${bad}줄은 빨간 글씨를 보고 고쳐요` : ''}. 매입처를 고르고 [입고 저장]을 눌러요.`;
      return renderInv();
    }
  }
}
async function finInput(el, k, v, live) {
  switch (k) {
    case 'xlPaste': FIN.paste = v; return false;
    case 'vatPer': IS.vat.per = v; return true;
  }
  return false;
}
