'use strict';
/* 킥스캔 — 설정 화면 정리 (11/23 사용자 "설정창이 너무 복잡해서 머리가 아프다" · 다음작업_1123b 02_설정화면_정리)
   - 왼쪽 세로 탭마다 지금 값 한 줄 요약(stSumPaint)
   - 매장 · 사업자 · 판매처 아래 장부 매출처 · 백업 칸 채우기 — 예전 재고관리 '기본정보' · '백업 · 초기화'의 같은 단추(data-a · data-k)를 그대로 써요(invAct · invInput)
   - 판매 규칙 › 입찰가 자동 조정(예전 자동화 '자동 입찰' 위쪽 칸) · 계정 · 휴대폰 칸 안내
   - 바꾸면 바로 저장: 저장되면 아래에 2초 "저장됐어요 · [되돌리기]"(stSaved). 음수 · 빈칸은 저장하지 않고 칸 아래 빨간 한 줄(stErr)
   - stOpen(탭): 다른 화면(프로필 메뉴 · 메뉴 찾기 · 옛 메뉴)에서 설정의 그 탭으로
   srceng.js 의 stPaint 가 탭을 바꾸거나 다시 그릴 때 stExtPaint(탭)을 불러요. */
const STX = { undoing: false, lastInput: 0, gx: {}, tm: 0 };
function stOpen(tab) {
  route('settings');
  (async () => {
    try { if (typeof stDraftReset === 'function') await stDraftReset(); } catch (e) {}
    try { await stTab(tab || (typeof ST !== 'undefined' ? ST.tab : 'sell')); stSwSync(); setTimeout(stSwSync, 500); } catch (e) {}
    try { if (typeof phoneRowPaint === 'function') phoneRowPaint(); } catch (e) {}
  })();
}

// ---------- 저장 안내 "저장됐어요 · [되돌리기]" (아래 가운데, 2초 · 마우스를 올리면 기다려요) ----------
function stSaved(undo, msg, ms) {
  let t = document.getElementById('stToast');
  if (!t) {
    t = document.createElement('div'); t.id = 'stToast'; t.className = 'unav-tip'; t.setAttribute('role', 'status'); t.hidden = true; document.body.appendChild(t);
    t.addEventListener('mouseenter', () => clearTimeout(stSaved.tm));
    t.addEventListener('mouseleave', () => { clearTimeout(stSaved.tm); stSaved.tm = setTimeout(() => { t.hidden = true; }, 1200); });
  }
  t.innerHTML = `<span>${esc(msg || '저장됐어요')}</span>${undo ? '<button type="button" class="ghost small" data-stu="1">되돌리기</button>' : ''}`;
  t.onclick = async e => {
    if (!undo || !e.target.closest('[data-stu]')) return;
    t.hidden = true; STX.undoing = true;
    try { await undo(); } catch (x) { console.warn(x); }
    setTimeout(() => { STX.undoing = false; }, 250);
    stSaved(null, '되돌렸어요');
  };
  t.hidden = false;
  clearTimeout(stSaved.tm); stSaved.tm = setTimeout(() => { t.hidden = true; }, ms || 2000);
}
// 칸 아래 빨간 한 줄
function stErrBox(t) { const row = t.closest('.st-row'); if (row) return { ref: row, mode: 'after' }; const td = t.closest('td'); if (td) return { ref: td, mode: 'in' }; return { ref: t.closest('label') || t, mode: 'after' }; }
function stErr(t, msg) {
  const { ref, mode } = stErrBox(t);
  let p = mode === 'in' ? ref.querySelector('.st-err') : ref.nextElementSibling;
  if (!(p && p.classList.contains('st-err'))) { p = document.createElement('p'); p.className = 'st-err se-bad'; p.setAttribute('role', 'alert'); if (mode === 'in') ref.appendChild(p); else ref.after(p); }
  p.textContent = msg; t.setAttribute('aria-invalid', 'true');
}
function stErrClear(t) {
  const { ref, mode } = stErrBox(t), p = mode === 'in' ? ref.querySelector('.st-err') : ref.nextElementSibling;
  if (p && p.classList.contains('st-err')) p.remove();
  t.removeAttribute('aria-invalid');
}
const stIsNum = t => t.tagName === 'INPUT' && (t.type === 'number' || t.inputMode === 'numeric' || t.inputMode === 'decimal');
const stIsField = t => !!t && /^(INPUT|SELECT|TEXTAREA)$/.test(t.tagName);

// ---------- 탭 요약 한 줄 ----------
function stSumTxt(k) {
  try {
    if (k === 'sell') { const s = (typeof SE !== 'undefined' && SE.calc && SE.calc.sellers) || []; const L = []; if (s.includes('poizon')) L.push('POIZON'); if (s.includes('kream')) { L.push('KREAM'); if (typeof LKP === 'undefined' || LKP.kPartner !== false) L.push('KREAM 입점'); } return L.join(' · ') || '판매처를 골라 주세요'; }
    if (k === 'store') { const n = typeof INV !== 'undefined' ? INV.partners.filter(p => p.kind === 'buy').length : 0; const off = typeof BCS !== 'undefined' && BCS.st && BCS.st.off; return `${n}곳 · 내 스캔 보태기 ${off ? '끔' : '켬'}`; }
    if (k === 'rule') return `자동 판매 등록 ${typeof ALO !== 'undefined' && ALO.on ? '켜짐' : '꺼짐'} · 자동 입찰 ${typeof AB !== 'undefined' && AB.run ? '켜짐' : '꺼짐'}`;
    if (k === 'biz') { const B = typeof bizCur === 'function' ? bizCur() : null; const T = { '일반': '과세사업자', '간이': '간이과세자', '면세': '면세사업자' }; return `${B ? T[B.type || '일반'] || B.type : '사업자'} · 카드 ${typeof INV !== 'undefined' ? INV.pays.length : 0}장`; }
    if (k === 'src') { const c = (typeof SE !== 'undefined' && SE.calc) || {}, s = c.sellers || []; return `최소 수익 ${won(+c.minWon || 0)} · ${s.includes('poizon') ? `POIZON 30일 ${+c.min30 || 0}개` : `KREAM 30일 ${+(c.kmin30 ?? c.min30) || 0}건`} 이상`; }
    if (k === 'gen') { const g = (typeof SE !== 'undefined' && SE.scope && SE.scope.groups) || {}; const n = Object.values(g).filter(Boolean).length, m = ((typeof SE !== 'undefined' && SE.scope && SE.scope.mine) || []).length; return `매입처 묶음 ${n}개${m ? ` · 내 매입처 ${m}곳` : ''}`; }
    if (k === 'acct') { const L = typeof LICST !== 'undefined' && LICST; return L && L.email ? `${String(L.email).split('@')[0]} · ${typeof planLabel === 'function' ? planLabel(L.plan) : (L.plan || '')}` : '로그인 전'; }
    if (k === 'phone') { const r = document.getElementById('phoneRow'); return r && !r.hidden ? '현장 앱 QR · 올리기' : '로그인하면 써요'; }
    if (k === 'noti') { if (typeof NTP === 'undefined' || typeof NT_KINDS === 'undefined') return ''; const n = NT_KINDS.filter(([x]) => NTP.on[x] !== 0).length; return `${n}/${NT_KINDS.length}개 켬${NTP.quiet !== false ? ' · 밤 조용히' : ''}`; }
    if (k === 'bak') return '전체 백업 · 초기화';
  } catch (e) {}
  return '';
}
function stSumPaint() { document.querySelectorAll('#settings [data-sts]').forEach(el => { el.textContent = stSumTxt(el.dataset.sts); }); }

// ---------- ① 매장 ----------
function stStoreHTML() {
  if (typeof INV === 'undefined' || !INV.partners) return '<p class="hint">재고 자료를 불러오는 중이에요…</p>';
  const P = INV.partners.filter(p => p.kind === 'buy'), L = [...P.filter(p => p.store), ...P.filter(p => !p.store)];
  const bs = (typeof BCS !== 'undefined' && BCS.st) || {};
  const row = p => `<tr><td class="l"><b>${esc(p.name)}</b>${p.biz ? `<div class="small">${esc(p.biz)}</div>` : ''}</td><td class="l">${p.store ? '오프라인 매장' : '온라인 · 기타'}</td><td class="l">${p.store ? '브랜드별 13~15일' : (p.returnDays ?? INV.opt.returnDays) + '일'}</td>
    <td><label class="st-num"><input type="number" min="0" max="100" step="1" data-stdc="${esc(p.id)}" value="${p.lastDisc != null && p.lastDisc !== '' ? +p.lastDisc : ''}" placeholder="–" data-stempty aria-label="${esc(p.name)} 할인율"><span>%</span></label></td>
    <td><div class="act"><button type="button" class="ghost small" data-a="partnerEdit" data-id="${esc(p.id)}">수정</button><button type="button" class="ghost small" data-a="partnerDel" data-id="${esc(p.id)}">삭제</button></div></td></tr>`;
  const num = (o, t, sm, min) => `<div class="st-row"><div class="st-l"><b>${t}</b><small>${sm}</small></div><label class="st-num"><input type="number" min="${min}" data-k="opt" data-o="${o}" value="${INV.opt[o]}"><span>일</span></label></div>`;
  return `${typeof flash === 'function' ? flash() : ''}<div class="st-col">
    <div class="st-hrow"><h3 class="st-h">매장 · 매입처 ${stQ('사 오는 곳이에요. 휴대폰 현장 앱에서 매장과 할인율을 고르면 마지막 할인율이 여기 들어와요. 오프라인 매장(매장 사전에서 고른 곳)은 브랜드별 반품 기한을 써요')}</h3><span class="topsp"></span><button type="button" class="ghost small" data-a="partnerEdit" data-id="">매장 추가</button><button type="button" class="ghost small" data-a="stkStoreDict">매장 사전에서 고르기</button></div>
    <div class="st-card">${L.length ? `<div class="tbl st-tbl"><table><thead><tr><th class="l">매장</th><th class="l">종류</th><th class="l">반품 기한</th><th>마지막 할인율</th><th></th></tr></thead><tbody>${L.map(row).join('')}</tbody></table></div>`
      : '<div class="st-row"><div class="st-l"><b>아직 매장이 없어요</b><small>휴대폰 현장 앱에서 매장을 고르거나 위 [매장 추가]로 넣어요</small></div></div>'}</div>
    <div class="st-cols"><div class="st-col">
      <h3 class="st-h">기본값 ${stQ('매입처마다 반품 기한을 따로 정하면 그 값이 먼저 쓰여요')}</h3><div class="st-card">
        ${num('returnDays', '기본 반품 기한', '입고일부터', 0)}${num('soon', '반품 기한 임박 알림', '남은 일수', 0)}${num('staleDays', '장기 재고 기준', '입고 후', 1)}
      </div>
    </div><div class="st-col">
      <h3 class="st-h">내 스캔 보태기 ${stQ('재고 · 폰 스캔에 있는 바코드를 공유 바코드 표에 올려요. 다른 킥스캔 사용자 폰도 처음 찍는 바코드를 바로 찾아요. 매장 · 날짜 말고 다른 내용은 올리지 않아요')}</h3><div class="st-card">
        <div class="st-row"><div class="st-l"><b>공유 바코드에 올리기</b><small>${esc(typeof bcsLine === 'function' && bcsLine() ? bcsLine().replace(/^공유 바코드 — /, '') : '로그인하면 올려요')}</small></div><button type="button" class="dl-sw st-sw2${bs.off ? '' : ' on'}" data-stbcs="1" role="switch" aria-checked="${!bs.off}" aria-label="내 스캔 보태기"><i></i></button></div>
      </div>
    </div></div>
  </div>`;
}
// ---------- ① 판매처 아래: 장부 매출처 (예전 '기본정보' 거래처의 매출처) ----------
function stSellPartHTML() {
  if (typeof INV === 'undefined' || !INV.partners) return '';
  const L = INV.partners.filter(p => p.kind === 'sell'), pz = L.find(p => isPoizon(p));
  return `<h3 class="st-h">장부 매출처 ${stQ('출고 · 정산할 때 이 수수료가 자동으로 빠지고, 그때 값으로 저장돼요(나중에 바꿔도 지난 판매는 그대로예요)')}</h3>
  <div class="st-card">${L.map(p => `<div class="st-row"><div class="st-l"><b>${esc(p.name)}</b><small>${esc(feeText(p))}</small></div><button type="button" class="ghost small" data-a="partnerEdit" data-id="${esc(p.id)}">수정</button></div>`).join('')}
    <div class="st-row"><div class="st-l"><small>다른 판매처(국내 · 기타)에 팔면 매출처를 넣어요</small></div><button type="button" class="ghost small" data-a="partnerEdit" data-id="">매출처 추가</button></div></div>
  ${typeof poizonNoFee === 'function' && poizonNoFee() && pz ? `<p class="st-chk warn">포이즌 수수료가 0% + 0원이라 포이즌 마진이 크게 나와요 — 포이즌 줄의 [수정]에서 넣어 주세요</p>` : ''}`;
}
// ---------- ① 사업자 ----------
function stBizHTML() {
  if (typeof bizCur !== 'function' || typeof INV === 'undefined') return '<p class="hint">재고 자료를 불러오는 중이에요…</p>';
  const B = bizCur(), o = (v, t) => `<option value="${v}"${(B.type || '일반') === v ? ' selected' : ''}>${t}</option>`;
  return `${typeof flash === 'function' ? flash() : ''}<div class="st-col"><div class="st-cols"><div class="st-col">
    <div class="st-hrow"><h3 class="st-h">사업자 정보</h3><span class="topsp"></span>${BIZ.list.length > 1 ? `<small class="st-sm">사업자 ${BIZ.list.length}곳 · 왼쪽 메뉴 사업자에서 바꿔요</small>` : ''}</div>
    <div class="st-card">
      <div class="st-row"><div class="st-l"><b>${esc(B.name)}</b><small>${B.no ? '사업자등록번호 끝 ' + esc(B.no) : '사업자등록번호 끝 5자리는 넣지 않았어요'}</small></div><div class="st-btns"><button type="button" class="ghost small" data-stbiz="edit">이름 · 번호 바꾸기</button><button type="button" class="ghost small" data-stbiz="add">+ 사업자 추가</button></div></div>
      <div class="st-row"><div class="st-l"><b>부가세 과세 유형 ${stQ('부가세 화면에만 써요. 간이과세자 · 비사업자면 바꿔 주세요')}</b><small>부가세 화면에만 써요</small></div><select id="stBizType">${o('일반', '일반과세자')}${o('간이', '간이과세자')}${o('면세', '면세사업자')}</select></div>
      <div class="st-row"><div class="st-l"><b>관리 시작일 ${stQ('이 날짜 전의 구매처 주문은 저절로 입고하지 않아요. 비우면 날짜를 따지지 않아요')}</b><small>그 전 주문은 저절로 입고하지 않아요</small></div><input type="date" id="stBizStart" value="${esc(B.start || '')}"></div>
    </div>
  </div><div class="st-col">
    <h3 class="st-h">결제 카드 ${stQ('카드에 이름을 붙이면 매입 등록 · 반품 창에 이 이름으로 보여요. 카드 · 계좌 번호는 넣지 말고 끝 4자리만')}</h3><div class="st-card st-misc">${vBaseBody('pays')}</div>
  </div></div>
  <details class="st-adv" data-stgx2="bizMore"${STX.gx.bizMore ? ' open' : ''}><summary>장부 목록 <small>배송사 · 분류 · 브랜드</small></summary><div class="st-card st-misc">${vBaseBody('couriers')}</div><div class="st-card st-misc" style="margin-top:8px">${vBaseBody('cats')}</div></details>
  </div>`;
}
// ---------- ③ 백업 (재고관리 백업 · 초기화) ----------
function stBakHTML() {
  if (typeof INV === 'undefined' || typeof BIZ === 'undefined') return '';
  const multi = BIZ.list.length > 1, rs = IS.rs || 'all';
  return `${typeof flash === 'function' ? flash() : ''}<h3 class="st-h">재고관리 백업 ${stQ("상품 · 재고 · 입출고 · 장부 · 기본정보를 파일 하나로 받아요. 다른 PC 에서 '백업 불러오기'로 그대로 옮길 수 있어요")}</h3>
  <div class="st-card"><div class="st-row"><div class="st-l"><b>재고관리만</b><small>${multi ? `사업자 ${BIZ.list.length}곳 모두` : '상품 · 재고 · 장부 · 기본정보'}</small></div><div class="st-btns"><button type="button" class="ghost small" data-a="backup">백업 파일 받기</button><label class="ghost small filebtn">백업 불러오기<input type="file" accept=".json" data-k="restore" hidden></label></div></div></div>
  <details class="st-adv" data-stgx2="rs"${STX.gx.rs ? ' open' : ''}><summary>초기화 <small>되돌릴 수 없어요${multi ? ` · 지금 사업자(${esc(bizCur().name)})만 지워요` : ''}</small></summary><div class="st-card st-misc">
    <label class="chk"><input type="radio" name="rs" value="all" data-k="rsKind"${rs === 'all' ? ' checked' : ''}> 상품 + 재고 전체 삭제 <span class="small">(기본정보는 남아요)</span></label>
    <label class="chk"><input type="radio" name="rs" value="stock" data-k="rsKind"${rs === 'stock' ? ' checked' : ''}> 재고만 삭제 <span class="small">(상품은 남기고 입출고 · 장부 기록 삭제 — 새 시즌 시작할 때)</span></label>
    <label class="chk"><input type="radio" name="rs" value="base" data-k="rsKind"${rs === 'base' ? ' checked' : ''}> 기본정보만 처음 상태로</label>
    <label class="chk"><input type="checkbox" data-k="rsBk"${IS.rsBk !== false ? ' checked' : ''}> 지우기 전에 지금 데이터를 백업 파일로 받기</label>
    <label>확인 문구 입력 — <b>${{ all: '전체삭제', stock: '재고삭제', base: '삭제' }[rs]}</b> <input data-k="rsText" autocomplete="off" value="${esc(IS.rsText || '')}"></label>
    <div class="row-btns"><button type="button" class="primary danger" data-a="resetRun">삭제 실행</button></div>
  </div></details>`;
}
// ---------- ① 판매 규칙 › 입찰가 자동 조정 (예전 자동 입찰 화면 위쪽 칸) ----------
function stAbPaint() {
  const s = document.getElementById('stAutoBid'); if (s && typeof AB !== 'undefined') s.textContent = AB.run ? (AB.busy ? '확인 중' : '켜짐') : '꺼짐';
  const b = document.getElementById('stAbOpt'); if (!b || typeof abOpt === 'undefined') return;
  if (b.contains(document.activeElement)) return;
  const sig = JSON.stringify([abOpt.gap, abOpt.mode, abOpt.cap]); if (b.dataset.sig === sig && b.firstChild) return; b.dataset.sig = sig;
  const o = (v, t, cur) => `<option value="${v}"${String(cur) === String(v) ? ' selected' : ''}>${t}</option>`;
  b.innerHTML = `<div class="st-row"><div class="st-l"><b>확인 간격 ${stQ('크림은 매크로를 허용하지 않아서 너무 자주 확인하면 계정이 제한될 수 있어요')}</b><small>10분마다를 추천해요</small></div><select id="sab_gap">${[5, 10, 15, 30, 60].map(v => o(v, v + '분마다' + (v === 10 ? ' (추천)' : ''), +abOpt.gap)).join('')}</select></div>
    <div class="st-row"><div class="st-l"><b>가격 바꾸는 방식 ${stQ("처음에는 '확인 화면까지'로 한 번 돌려 보세요. 크림 창에 새 가격이 들어간 확인 화면을 띄우고 멈춰요. 잘 되면 '끝까지 자동'으로 바꿔요")}</b><small>처음에는 확인 화면까지로</small></div><select id="sab_mode">${Object.entries(typeof AB_MODE !== 'undefined' ? AB_MODE : {}).map(([k, t]) => o(k, t, abOpt.mode)).join('')}</select></div>
    <div class="st-row"><div class="st-l"><b>하루 최대 변경</b><small>넘으면 그날은 더 바꾸지 않아요</small></div><select id="sab_cap">${[50, 100, 200, 500].map(v => o(v, v + '번', +abOpt.cap)).join('')}</select></div>`;
}

// ---------- 탭 그리기 (srceng.js stPaint → stExtPaint) ----------
function stExtPaint(tab) {
  stSumPaint();
  const put = (id, f) => { const el = document.getElementById(id); if (!el) return; if (el.contains(document.activeElement) && /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName) && !/^(checkbox|radio|file)$/.test(document.activeElement.type)) return; el.innerHTML = f(); };
  if (tab === 'store') put('stStore', stStoreHTML);
  if (tab === 'biz') put('stBiz', stBizHTML);
  if (tab === 'sell') put('stSellPart', stSellPartHTML);
  if (tab === 'bak') put('stBak', stBakHTML);
  if (tab === 'rule') { stAbPaint(); try { if (typeof alSetPaint === 'function' && !document.getElementById('alSetBox').contains(document.activeElement)) alSetPaint(); } catch (e) {} }
  if (tab === 'acct') { const r = document.getElementById('licRow'), n = document.getElementById('stLicNone'); if (n) n.hidden = !!r && !r.hidden; }
  if (tab === 'phone') { const r = document.getElementById('phoneRow'), n = document.getElementById('stPhoneNone'); if (n) n.hidden = !!r && !r.hidden; }
  if (tab === 'noti' && !document.getElementById('ntCard') && typeof ntCard === 'function') { try { ntCard(); } catch (e) {} }
  if (tab === 'gen' || tab === 'noti') { try { stSwSync(); } catch (e) {} }
}
// 재고 화면이 다시 그려지면(대화창에서 저장 등) 지금 보는 설정 탭도 다시 그려요 — 칸에 글을 치는 중이면 기다려요
function stInvSoon() {
  clearTimeout(STX.tm);
  STX.tm = setTimeout(() => {
    const p = document.getElementById('settings'); if (!p || p.hidden || typeof ST === 'undefined') return;
    if (Date.now() - STX.lastInput < 600) return stInvSoon();
    if (['store', 'biz', 'sell', 'bak'].includes(ST.tab)) stExtPaint(ST.tab); else stSumPaint();
  }, 60);
}

(function stWire() {
  if (typeof document === 'undefined') return;
  const set = document.getElementById('settings'); if (!set || set.dataset.stx) return; set.dataset.stx = '1';
  if (typeof renderInv === 'function') { const r0 = renderInv; renderInv = function () { const r = r0.apply(this, arguments); try { stInvSoon(); } catch (e) {} return r; }; }

  // 1) 바꾸기 전 값 기억 (되돌리기용)
  set.addEventListener('focusin', e => { const t = e.target; if (stIsField(t) && t.type !== 'file') t.dataset.stPrev = t.type === 'checkbox' ? (t.checked ? '1' : '0') : t.value; }, true);
  // 2) 음수 · 빈칸 막기 + 저장 안내 (각 모듈이 저장하기 전에 — 잡는 단계)
  set.addEventListener('change', e => {
    const t = e.target; if (!stIsField(t) || t.type === 'file' || t.hasAttribute('data-st-nosave')) return;
    if (stIsNum(t)) {
      const raw = String(t.value).trim(), n = +raw.replace(/,/g, '');
      const why = raw === '' ? (t.hasAttribute('data-stempty') ? '' : '빈칸은 저장하지 않아요 — 숫자를 넣어 주세요') : !isFinite(n) ? '숫자만 넣어 주세요' : n < 0 ? '0보다 작은 값은 저장하지 않아요' : '';
      if (why) { e.stopImmediatePropagation(); stErr(t, why); return; }
      stErrClear(t);
    }
    if (t.closest('[data-stown]')) return;   // srceng.js · 아래 3)이 각자 안내해요
    const id = t.id, now = t.type === 'checkbox' ? (t.checked ? '1' : '0') : t.value;
    const prev = t.type === 'checkbox' ? (t.checked ? '0' : '1') : t.type === 'radio' ? null : t.dataset.stPrev;
    t.dataset.stPrev = now; delete t.dataset.stNo;
    setTimeout(() => {
      if (t.dataset.stNo) { delete t.dataset.stNo; return; }
      if (STX.undoing) return;
      const undo = prev == null || prev === now ? null : () => {
        const el = (id && document.getElementById(id)) || t; if (!el.isConnected) return;
        if (el.type === 'checkbox') el.checked = prev === '1'; else el.value = prev;
        el.dataset.stPrev = prev; el.dispatchEvent(new Event('change', { bubbles: true }));
        try { stSwSync(); setTimeout(stSwSync, 500); } catch (x) {}
      };
      stSaved(undo); stSumPaint();
    }, 90);
  }, true);
  // Enter = 칸 벗어나기(저장)
  set.addEventListener('keydown', e => { const t = e.target; if (e.key === 'Enter' && stIsField(t) && t.tagName === 'INPUT' && (stIsNum(t) || t.type === 'date')) { e.preventDefault(); t.blur(); } }, true);

  // 3) 매장 · 사업자 · 백업 · 장부 매출처 칸 (data-stown) — 재고관리와 같은 단추
  set.addEventListener('click', async e => {
    const tg = e.target.closest('[data-stown] [data-a]');
    if (tg && set.contains(tg) && !(tg.tagName === 'INPUT')) {
      try { await invAct(tg.dataset.a, tg); } catch (err) { IS.msg = '오류: ' + err.message; }
      return stInvSoon();
    }
    const bz = e.target.closest('[data-stbiz]');
    if (bz) { const B = bizCur(); return bizDialog(bz.dataset.stbiz === 'edit' ? B : null); }
    const bc = e.target.closest('[data-stbcs]');
    if (bc && typeof bcsLoad === 'function') {
      const S0 = await bcsLoad(), was = !!S0.off;
      const put = async v => { S0.off = v; await bcsSave(); stExtPaint('store'); };
      await put(!was); return stSaved(() => put(was));
    }
    const go = e.target.closest('[data-stgo]');
    if (go) {
      const v = go.dataset.stgo;
      if (v === 'buy') return typeof buyOpen === 'function' ? buyOpen() : null;
      if (v === 'cross' || v === 'short') { route('inv:sell'); try { const S0 = slS(); S0.tab = v; S0.sub = v === 'short' ? '입찰 중' : 'wait'; renderInv(); } catch (x) {} return; }
    }
    if (e.target.closest('#stAutoBidGo')) return;   // srceng.js 가 자동 입찰 표로 보내요
  });
  set.addEventListener('toggle', e => { const d = e.target; if (d && d.dataset && d.dataset.stgx2) STX.gx[d.dataset.stgx2] = d.open; }, true);
  set.addEventListener('input', e => {
    const el = e.target.closest('[data-stown] [data-k]'); if (!el) return; STX.lastInput = Date.now();
    if (el.type !== 'checkbox' && el.type !== 'radio' && el.tagName !== 'SELECT' && el.type !== 'file') invInput(el, e);
  });
  set.addEventListener('keydown', e => { const el = e.target.closest('[data-stown] [data-k]'); if (el) invKey(el, e); });
  set.addEventListener('change', async e => {
    const t = e.target;
    // 재고관리 칸 (기본값 · 초기화 · 결제 카드 · 분류 …)
    const el = t.closest('[data-stown] [data-k]');
    if (el) {
      const k = el.dataset.k, o = el.dataset.o, prev = k === 'opt' ? INV.opt[o] : null;
      await invInput(el, e);
      if (k === 'opt' && prev != null && INV.opt[o] !== prev) stSaved(async () => { INV.opt[o] = prev; await invSave(); stExtPaint(ST.tab); });
      return stInvSoon();
    }
    // 매장 마지막 할인율 (비우면 지워요)
    if (t.dataset.stdc) {
      const p = typeof partnerOf === 'function' ? partnerOf(t.dataset.stdc) : null; if (!p) return;
      const was = p.lastDisc, v = String(t.value).trim();
      const put = async x => { if (x == null || x === '') delete p.lastDisc; else p.lastDisc = Math.min(100, +x); await invSave(); stExtPaint('store'); };
      await put(v); return stSaved(() => put(was));
    }
    // 사업자 과세 유형 · 관리 시작일
    if (t.id === 'stBizType' || t.id === 'stBizStart') {
      const B = bizCur(), k = t.id === 'stBizType' ? 'type' : 'start', was = B[k] || '';
      const v = k === 'start' ? (/^\d{4}-\d{2}-\d{2}$/.test(t.value) ? t.value : '') : t.value;
      const put = async x => { B[k] = x; await store.set('biz', BIZ); try { renderBiz(); } catch (er) {} stExtPaint('biz'); };
      await put(v); return stSaved(() => put(was));
    }
    // 입찰가 자동 조정 (예전 자동 입찰 화면 위쪽 칸과 같은 값)
    if (/^sab_(gap|mode|cap)$/.test(t.id) && typeof abOpt !== 'undefined') {
      const v = t.value;
      if (t.id === 'sab_mode' && v === 'auto' && abOpt.mode !== 'auto' && !(AB.modeAsk && Date.now() - AB.modeAsk < 120000)) {
        AB.modeAsk = Date.now(); t.value = abOpt.mode; t.dataset.stPrev = abOpt.mode; t.dataset.stNo = '1';
        return stErr(t, "'끝까지 자동'은 확인 화면의 가격 · 사이즈가 맞으면 마지막 버튼까지 킥스캔이 눌러요 — 맞으면 2분 안에 한 번 더 골라 주세요");
      }
      stErrClear(t);
      if (t.id === 'sab_mode') AB.modeAsk = 0;
      if (t.id === 'sab_gap') abOpt.gap = +v; else if (t.id === 'sab_mode') abOpt.mode = v; else abOpt.cap = +v;
      await abSave(); return;
    }
  });
  // 프로그램 업데이트 작은 창 닫기
  document.addEventListener('click', e => { if (e.target.closest('#updPopX')) { const p = document.getElementById('updPop'); if (p) p.hidden = true; } });
  // 휴대폰 · 계정 칸은 설정을 열 때 · 상태가 바뀔 때 안내 줄을 맞춰요
  setInterval(() => { const p = document.getElementById('settings'); if (p && !p.hidden && typeof ST !== 'undefined') { stSumPaint(); if (ST.tab === 'acct' || ST.tab === 'phone') stExtPaint(ST.tab); if (ST.tab === 'rule') stAbPaint(); } }, 3000);
  // srceng.js stBind 가 먼저 그린 탭을 한 번 더 채워요(이 파일이 늦게 읽혀서)
  setTimeout(() => { try { if (typeof ST !== 'undefined') stExtPaint(ST.tab); } catch (e) {} }, 1200);
})();
