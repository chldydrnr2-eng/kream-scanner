'use strict';
// 3.42: 수수료 자동 확인 — 줍픽처럼 손으로 넣지 않고 크림이 실제로 매긴 수수료를 읽어서 계산에 써요
//  1) 판매자 등급 요율: 크림 계정의 /api/users/me/seller-grades/ 를 6시간에 한 번 읽어 설정 수수료율(S.rate)을 맞춰요
//  2) 상품별 할인: 크림이 정산한 판매 · 진행 중 판매 · 보관판매 · 판매 입찰의 실제 수수료(판매가 − 정산금)를
//     계산식 수수료와 비교해서, 그 품번만 눈에 띄게 적으면 '할인 중'으로 기억해요
//     - 내 계정의 평소 비율(중앙값)과 비교해요 → 등급 요율이 설정과 달라도 모든 상품이 할인으로 잡히지 않아요
//     - 마지막으로 본 날부터 14일이 지나거나, 그 품번에서 평소 수수료가 다시 보이면 저절로 풀려요
// feeOf(price, prod, item) · pzFee(price, cat, item) · partnerFee(p, price, it) 가 fdFind 로 할인을 찾아요
const FD = { map: null, at: 0, grade: null, med: null, n: 0, q: [] };
const FD_KEEP = 14, FD_WIN = 30, FD_CUT = 0.85, FD_GRADE_EVERY = 6 * 36e5;
const fdCk = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
const fdDay = t => { const d = t ? new Date(t) : new Date(); if (isNaN(d)) return ''; return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const fdTime = v => { if (!v) return 0; if (typeof v === 'number') return v; const s = String(v); const t = new Date(s.length <= 10 ? s + 'T12:00:00' : s).getTime(); return isNaN(t) ? 0 : t; };
// 할인 없는 크림 계산식 수수료 (설정 요율 기준)
const fdBaseK = p => Math.floor(Math.min((p * (+S.rate || 0) / 100 + (+S.base || 0)) * 1.1, +S.max || Infinity) / 10) * 10;

// ---------- 실제 수수료 모으기 ----------
// 크림 응답 아무거나 → price_breakdown 이 있는 거래 { code, name, price, fee, t, src }
function fdWalk(data, t0, src, out) {
  const seen = new Set();
  const go = (o, d) => {
    if (!o || typeof o !== 'object' || d > 8 || seen.has(o)) return; seen.add(o);
    if (Array.isArray(o)) { for (const x of o) go(x, d + 1); return; }
    const pb = o.price_breakdown;
    if (pb && typeof pb === 'object') {
      const rel = (o.product && o.product.release) || o.release || {}, price = +pb.price || +o.price || 0, pay = +pb.total_payout || +o.total_payout || 0;
      const fee = o.total_fee != null ? +o.total_fee : pb.total_fee != null ? +pb.total_fee : pay > 0 ? price - pay : null;
      if (rel.style_code && price > 0 && fee != null && fee >= 0) out.push({ code: rel.style_code, name: rel.translated_name || rel.name || '', price, fee, t: fdTime(o.date_paid || o.date_updated || o.date_created) || t0, src });
    }
    for (const k in o) if (o[k] && typeof o[k] === 'object') go(o[k], d + 1);
  };
  go(data, 0); return out;
}
function fdCollect() {
  const L = [];
  const add = (code, name, price, pay, t, src) => { price = +price || 0; pay = +pay || 0; if (code && code !== '-' && price > 0 && pay > 0 && pay <= price) L.push({ code, name: name || '', price, fee: price - pay, t: fdTime(t), src }); };
  try { // 재고관리에 들어간 크림 판매 정산(자동) — fee = 판매가 − 정산금 으로 적혀 있어요
    if (typeof INV !== 'undefined' && INV.outs) for (const o of INV.outs) if (o.kreamSaleId && o.fee !== '' && o.fee != null && +o.price > 0) { const it = itemOf(o.itemId); if (it) L.push({ code: it.code, name: it.name || '', price: +o.price, fee: +o.fee, t: fdTime(o.settleDate || o.date), src: '판매 정산' }); }
  } catch (e) {}
  try { if (typeof kSales !== 'undefined' && kSales) { for (const r of kSales.pending || []) add(r.code, r.name, r.price, r.payout, r.date || kSales.pendingAt, '진행 중 판매'); for (const u of Object.values(kSales.unrec || {})) add(u.code, u.name, u.price, u.payout, u.date, '판매 정산'); } } catch (e) {}
  try { if (typeof kInv !== 'undefined' && kInv && kInv.items) for (const i of kInv.items) if (/^(sold|payout_completed)$/.test(i.status) || /판매\s*완료|정산/.test(i.statusName || '')) add(i.code, i.name, i.price, i.payout, i.date || kInv.at, '보관판매'); } catch (e) {}
  for (const x of FD.q || []) L.push(x);   // 입찰 직전 크림 확인 화면의 견적
  try { if (typeof XS !== 'undefined' && XS.km) for (const [key, pg] of Object.entries(XS.km)) if (!/buy/i.test(key)) for (const c of (pg && pg.cap) || []) fdWalk(c.data, pg.at || 0, /inventory/.test(c.url) ? '보관판매' : '판매 입찰', L); } catch (e) {}
  return L;
}
// 품번마다 가장 최근 거래로 할인 여부를 정해요
function fdBuild() {
  const now = Date.now(), L = fdCollect().filter(x => x.t && now - x.t <= FD_WIN * 864e5).map(x => { const b = fdBaseK(x.price); return { ...x, base: b, r: b > 0 ? x.fee / b : 1 }; });
  const rs = L.map(x => x.r).sort((a, b) => a - b);
  const med = rs.length >= 5 ? rs[Math.floor(rs.length / 2)] : 1;   // 거래가 적으면 계산식 그대로를 기준으로
  const by = new Map();
  for (const x of L) { const k = fdCk(String(x.code).split('/')[0]); if (!k) continue; const p = by.get(k); if (!p || x.t > p.t) by.set(k, x); }
  const map = new Map();
  for (const [k, x] of by) {
    const rel = med > 0 ? x.r / med : x.r;
    if (rel >= FD_CUT || now - x.t > FD_KEEP * 864e5) continue;
    const pct = x.fee === 0 ? 100 : Math.max(1, Math.min(100, Math.round((1 - rel) * 100)));
    map.set(k, { kind: 'pct', pct, seller: 'kream', code: x.code, name: x.name, seen: fdDay(x.t), to: fdDay(x.t + FD_KEEP * 864e5), src: x.src, price: x.price, fee: x.fee, base: Math.round(x.base * med) });
  }
  FD.map = map; FD.at = now; FD.med = med; FD.n = L.length;
  return map;
}
function fdFind(seller, x) {
  if (seller !== 'kream' || !x) return null;
  if (!FD.map || Date.now() - FD.at > 60000) { try { fdBuild(); } catch (e) { FD.map = new Map(); FD.at = Date.now(); } }
  if (!FD.map.size) return null;
  const i = (x.raw && x.raw.info) || x.it || x, code = typeof x === 'string' ? x : i.code || x.code || '';
  for (const c of String(code || '').split('/')) { const d = FD.map.get(fdCk(c)); if (d) return d; }
  return null;
}
const fdText = r => !r ? '' : (+r.pct >= 100 ? '수수료 무료' : `수수료 ${+r.pct}% 할인`) + (r.to ? ` · ~${r.to.slice(5).replace('-', '/')}` : '');
function fdTag(seller, x) { const r = fdFind(seller, x); return r ? `<span class="pill ok fd-pill" title="${esc(`크림이 실제로 매긴 수수료로 확인했어요 — ${r.seen} ${r.src} · ${won(r.price)}에 수수료 ${won(r.fee)} (평소 ${won(r.base)})`)}">${esc(fdText(r))}</span>` : ''; }
// 판매 · 보관 · 입찰 내역을 새로 읽었을 때 바로 다시 계산해요
function fdRebuild() { FD.map = null; try { fdPaint(); } catch (e) {} }

// ---------- 판매자 등급 요율 ----------
function fdGradeParse(j) {
  let hit = null;
  const go = (o, d) => { if (hit || !o || typeof o !== 'object' || d > 5) return; if (Array.isArray(o)) { o.forEach(x => go(x, d + 1)); return; } if ('fee_rate' in o) { hit = o; return; } for (const k in o) go(o[k], d + 1); };
  go(j, 0); if (!hit) return null;
  const v = hit.fee_rate, r = typeof v === 'number' ? v : Number(String(v || '').replace(/%/g, '').trim());
  if (!Number.isFinite(r) || r <= 0 || r > 30) return null;
  return { tier: typeof hit.tier === 'string' ? hit.tier.slice(0, 20) : (typeof hit.grade === 'string' ? hit.grade.slice(0, 20) : ''), rate: Math.round(r * 1000) / 1000, at: Date.now() };
}
// 크림 창(tabId)이 열려 있을 때 불러요 — 6시간에 한 번만
async function fdGradeTry(tabId, force) {
  if (!tabId || typeof execT !== 'function') return null;
  if (!force && FD.grade && FD.grade.tried && Date.now() - FD.grade.tried < FD_GRADE_EVERY) return null;
  FD.grade = { ...(FD.grade || {}), tried: Date.now() };
  let res = null; try { const [x] = await execT({ target: { tabId }, func: kcKreamGrade, world: 'MAIN' }, 30000); res = x && x.result; } catch (e) {}
  const g = res && res.ok ? fdGradeParse(res.data) : null;
  if (!g) { await store.set('kreamGrade', FD.grade).catch(() => {}); return null; }
  FD.grade = { ...g, tried: Date.now(), prev: S.rate };
  if (+S.rate !== g.rate) { S.rate = g.rate; await store.set('settings', S); const e = document.getElementById('s_rate'); if (e && document.activeElement !== e) e.value = g.rate; FD.map = null; try { if (typeof renderMine === 'function') renderMine(); } catch (er) {} }
  await store.set('kreamGrade', FD.grade).catch(() => {});
  try { if (typeof lkSellPaint === 'function') lkSellPaint(); } catch (er) {}
  return g;
}

// ---------- 입찰 직전 견적 ----------
// 입찰을 걸거나 바꿀 때 크림 확인 화면(마지막 버튼 전)의 수수료 견적을 받아 적어요 → 아직 안 팔린 상품의 할인도 미리 잡혀요
async function fdQuoteAdd(item, price, q) {
  price = +price || 0; if (!q || !price) return null;
  const fee = q.fee != null ? +q.fee : +q.payout > 0 ? price - +q.payout : null;
  const i = item && ((item.raw && item.raw.info) || item.it || item), code = String((i && i.code) || (item && item.code) || '').split('/')[0].trim();
  if (!code || code === '-' || fee == null || !(fee >= 0) || fee > price) return null;
  const now = Date.now(), k = fdCk(code);
  FD.q = (FD.q || []).filter(x => now - x.t <= FD_WIN * 864e5 && !(fdCk(x.code) === k && now - x.t < 60000));
  const x = { code, name: (i && i.name) || (item && item.name) || '', price, fee, t: now, src: '입찰 견적' };
  FD.q.push(x); FD.q = FD.q.slice(-300); FD.map = null;
  try { await store.set('fdQuotes', FD.q); } catch (e) {}
  try { fdPaint(); } catch (e) {}
  return x;
}
// 크림 견적 수수료가 이만큼 넘으면 마지막 버튼을 누르지 않고 멈춰요 (킥스캔 계산 + 1,000원 또는 10% 여유)
function fdFeeCap(price, item) { const f = feeOf(+price, null, item); return f + Math.max(1000, Math.round(f * 0.1)); }
// 확인 화면 결과에 견적이 있으면 받아 적고, 멈춘 이유를 사람 말로
function fdQuoteSay(r) { const q = r && r.quote; return q && q.fee != null ? `크림 견적 수수료 ${won(q.fee)}` : ''; }

// ---------- 설정 › 판매 설정 › 수수료 자동 확인 (보기만) ----------
function fdPaint() {
  const box = document.getElementById('fdCard'); if (!box) return;
  const g = FD.grade && FD.grade.rate ? FD.grade : null;
  if (!FD.map || Date.now() - FD.at > 60000) { try { fdBuild(); } catch (e) {} }
  const L = [...(FD.map || new Map()).values()].sort((a, b) => b.seen.localeCompare(a.seen));
  box.innerHTML = `<div class="sl-h"><b>수수료 자동 확인</b><span class="small">크림이 실제로 매긴 수수료를 읽어서 계산에 써요 — 넣을 건 없어요</span></div>
    <div class="st-row"><div class="st-l"><b>판매자 등급</b><small>크림 계정에서 6시간마다 읽어 위 수수료율에 넣어요</small></div><span class="st-val">${g ? `${esc(g.tier || '등급')} · ${g.rate}% + VAT = ${Math.round(g.rate * 11) / 10}% · ${esc(fdDay(g.at).slice(5).replace('-', '/'))} 확인` : '아직 못 읽었어요 — 크림 판매 · 보관 내역을 불러오면 같이 읽어요'}</span></div>
    <div class="st-row"><div class="st-l"><b>할인 중인 상품</b><small>최근 ${FD_WIN}일 판매 · 진행 중 판매 · 보관판매 · 판매 입찰 · 입찰 견적 ${FD.n}건의 실제 수수료로 찾아요 · 마지막으로 본 뒤 ${FD_KEEP}일이 지나면 풀려요</small></div><span class="st-val">${L.length ? L.length + '개' : '없어요'}</span></div>
    ${L.length ? `<div class="tbl fd-tbl"><table class="main"><thead><tr><th class="l">상품</th><th class="l">품번</th><th class="l">할인</th><th>실제 수수료</th><th>평소 수수료</th><th class="l">확인</th></tr></thead><tbody>${L.map(r => `<tr><td class="l">${esc(String(r.name || '').slice(0, 40))}</td><td class="l mono">${esc(r.code)}</td><td class="l"><span class="pill ok">${esc(fdText(r))}</span></td><td>${won(r.fee)}<div class="small">${won(r.price)} 판매</div></td><td>${won(r.base)}</td><td class="l">${esc(r.seen.slice(5).replace('-', '/'))} · ${esc(r.src)}</td></tr>`).join('')}</tbody></table></div>` : ''}`;
}
(function fdWire() {
  if (typeof document === 'undefined') return;
  if (typeof lkSellPaint === 'function') { const f = lkSellPaint; lkSellPaint = function () { const r = f.apply(this, arguments); try { fdPaint(); } catch (e) {} return r; }; }
  (async () => { try { FD.grade = await store.get('kreamGrade', null); FD.q = (await store.get('fdQuotes', [])) || []; } catch (e) {} setTimeout(() => { FD.map = null; try { fdPaint(); if (typeof renderMine === 'function') renderMine(); } catch (e) {} }, 3000); })();
})();
