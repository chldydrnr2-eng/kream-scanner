/* 킥스캔 — 폰 알림(웹 푸시) 보내기 (11/25 · 줍픽 J10 폰 푸시의 첫 단계: 발매 · 관심 브랜드 행사)
   - 폰 앱(kream-scanner/m) › 발매 탭 › [알림 켜기] → 폰이 구독 정보를 서버 문서(ks_doc kind 'job', type 'push')로 올려요
   - PC 는 그 구독으로 본체(main-core API.push)가 직접 보내요 — 서버 함수 · 서버 열쇠 설정이 필요 없어요
   - 보내는 열쇠(VAPID)는 처음 한 번 만들어 서버 문서 job/pushkey 로 올려요(폰이 공개 키를 읽고, 같은 계정의 다른 PC 도 같은 열쇠를 써요)
   - 알림 종류 끄기 · 밤 10시~아침 8시 조용히(설정 › 알림 규칙)를 따라요. 하루 40번까지 */
const PSH = { subs: {}, ready: false, last: null, day: { d: '', n: 0 }, syncAt: 0 };
const pushCount = () => Object.keys(PSH.subs).length;
function pushSubPut(r) {
  const d = (r && r.data) || {};
  if (!r || d.type !== 'push') return;
  if (r.deleted || d.on === false || !d.sub || !d.sub.endpoint) delete PSH.subs[r.id];
  else PSH.subs[r.id] = { sub: { endpoint: d.sub.endpoint, keys: d.sub.keys || {} }, ua: String(d.ua || '').slice(0, 80), at: d.at || Date.now(), kinds: d.kinds || null };
}
const pushSubsSave = () => store.set('pushSubs', PSH.subs).catch(() => {});
// 서버의 job 문서에서 열쇠 · 폰 구독을 맞춰요 (켤 때 · 6시간마다 · 키가 안 맞을 때)
async function pushSync() {
  if (!(window.kcApp && window.kcApp.push) || typeof clRpc !== 'function' || (typeof clOn === 'function' && !clOn())) return false;
  const rows = (await clRpc('ks_doc_get', { p_since: null, p_kinds: ['job'], p_limit: 2000 })) || [];
  const kd = rows.find(r => r.id === 'pushkey' && !r.deleted && r.data && r.data.jwk && r.data.jwk.d);
  if (kd) await window.kcApp.push.use(kd.data.jwk);
  else {
    const jwk = await window.kcApp.push.jwk(), pub = await window.kcApp.push.pub();
    await clRpc('ks_doc_put', { p_docs: [{ kind: 'job', id: 'pushkey', data: { type: 'pushkey', pub, jwk, status: 'done', at: Date.now() }, by: 'pc', at: new Date().toISOString() }] });
  }
  const seen = {}; for (const r of rows) if (r.data && r.data.type === 'push') { seen[r.id] = 1; pushSubPut(r); }
  for (const id of Object.keys(PSH.subs)) if (!seen[id]) delete PSH.subs[id];
  PSH.ready = true; PSH.syncAt = Date.now(); await pushSubsSave();
  return true;
}
// kind: 알림 종류(drop · event …) · force: 시험 보내기(밤 · 끄기 · 하루 한도 무시) → { ok: 보낸 폰 수, why }
async function pushSend(kind, title, body, url, tag, force) {
  try {
    if (!(window.kcApp && window.kcApp.push)) return { ok: 0, why: '이 PC 킥스캔이 폰 알림을 못 보내요' };
    if (!PSH.ready || Date.now() - PSH.syncAt > 6 * 3600e3) { try { await pushSync(); } catch (e) { if (!pushCount()) return { ok: 0, why: String(e.message || e) }; } }
    if (!force && typeof NTP !== 'undefined' && (NTP.on[kind] === 0 || (typeof ntQuiet === 'function' && ntQuiet()))) return { ok: 0, why: '알림을 쉬는 시간이에요' };
    const L = Object.entries(PSH.subs).filter(([, s]) => !s.kinds || s.kinds[kind] !== 0).map(([id, s]) => ({ id, sub: s.sub }));
    if (!L.length) return { ok: 0, why: '알림을 켠 폰이 없어요' };
    const d = today(); if (PSH.day.d !== d) PSH.day = { d, n: 0 };
    if (!force && PSH.day.n >= 40) return { ok: 0, why: '오늘 폰 알림 40번을 다 썼어요' };
    PSH.day.n++;
    const res = (await window.kcApp.push.send(L, { title, body, url: url || './', tag: tag || kind })) || [];
    let ok = 0, gone = false, bad = false;
    for (const x of res) {
      if (x.status >= 200 && x.status < 300) ok++;
      else if (x.status === 404 || x.status === 410) { delete PSH.subs[x.id]; gone = true; }   // 그 폰이 알림을 끄거나 앱을 지웠어요
      else if (x.status === 401 || x.status === 403) bad = true;                              // 열쇠가 안 맞아요 → 다음에 다시 맞춰요
    }
    PSH.last = { at: Date.now(), status: res[0] && (res[0].status || 0), err: res[0] && res[0].err, ok, n: res.length };
    if (gone) await pushSubsSave();
    if (bad) PSH.ready = false;
    return { ok, why: ok ? '' : (res[0] && (res[0].err || '응답 ' + res[0].status)) || '' };
  } catch (e) { return { ok: 0, why: String(e.message || e) }; }
}
(async function pushBoot() {
  try { PSH.subs = (await store.get('pushSubs', {})) || {}; } catch (e) {}
  // 로그인 · 동기화가 준비될 시간을 두고 한 번 맞춰요
  setTimeout(() => { pushSync().catch(() => {}); }, 70e3);
  setInterval(() => { if (Date.now() - PSH.syncAt > 6 * 3600e3) pushSync().catch(() => {}); }, 30 * 60e3);
})();
