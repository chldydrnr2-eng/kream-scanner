'use strict';
/* 킥스캔 — 재고관리 (입고·출고·우선출고·반품·장부·부가세)
   데이터는 이 PC 확장 프로그램 저장소(inv)에만 있어요. 백업은 '데이터 초기화' 화면에서 받아요. */

const INV_DEF = () => ({
  v: 1,
  partners: [
    { id: 'p-kream', kind: 'sell', name: '크림', biz: '크림 주식회사', tax: '과세', feeMode: 'kream', feeRate: 6, feeFix: 2500, vat: '포함' },
    { id: 'p-poizon', kind: 'sell', name: '포이즌', biz: '', tax: '영세', feeMode: 'custom', feeRate: 0, feeFix: 0, vat: '포함' },
    { id: 'p-ms', kind: 'buy', name: '무신사', biz: '주식회사 무신사', tax: '과세', returnDays: 7 },
    { id: 'p-nike', kind: 'buy', name: '나이키 공식몰', biz: '나이키코리아', tax: '과세', returnDays: 30 }
  ],
  pays: [],
  couriers: [{ id: 'c-cj', name: 'CJ대한통운', box: { 극소: '', 소: '', 중: '', 대: '', 특대: '' } }],
  cats: { 신발: ['스니커즈', '러닝화', '부츠', '샌들·슬리퍼'], 의류: ['아우터', '상의', '하의'], 잡화: ['가방', '모자', '기타'] },
  brands: ['나이키', '조던', '뉴발란스', '아디다스', '아식스', '노스페이스'],
  items: [], lots: [], outs: [], ledger: [], expenses: [], poizonMap: {}, plans: [],
  opt: { returnDays: 7, staleDays: 30, soon: 3, autoIn: true, autoHours: 0, ordSites: null, ordDays: 30, optV: 2 }
});
let INV = INV_DEF();
let invView = 'home';
const IS = {   // 화면마다 잠깐 들고 있는 상태
  io: { mode: 'in', date: '', partnerId: '', payId: '', rows: [], bc: false, multi: true, q: '', msg: '' },
  items: { q: '', brand: '', cat: '', only: false, open: '' },
  base: 'grid', ret: 'buy', xl: null, ms: { sel: new Set(), msg: '' }, pre: { sel: new Set(), price: {}, kream: null, poizon: null, msg: '' },
  lg: { from: '', to: '', kind: '', partner: '', pay: '', size: 50, page: 0 }, vat: { year: 0, half: 0 }, msg: ''
};

// ---------- 공통 ----------
const fmtD = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const addDays = (s, n) => { if (n === null) return '';   // 11/22 C14: 반품 불가(개인 거래) — 반품 기한 없음
  const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + n); return fmtD(d); };
const dday = s => Math.round((new Date(s + 'T00:00:00') - new Date(today() + 'T00:00:00')) / 864e5);
const num = v => { const n = +String(v ?? '').replace(/[^\d.-]/g, ''); return isFinite(n) ? n : 0; };
const opt = (v, label, sel) => `<option value="${esc(v)}"${sel ? ' selected' : ''}>${esc(label)}</option>`;
const itemOf = id => INV.items.find(x => x.id === id);
const partnerOf = id => INV.partners.find(x => x.id === id);
const payOf = id => INV.pays.find(x => x.id === id);
const itName = it => it ? `${it.brand ? it.brand + ' ' : ''}${it.name || it.code}` : '(지운 상품)';
const codeKey = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
const wonS = n => (n < 0 ? '−' : '') + won(Math.abs(n));
const monthStart = (d = today()) => d.slice(0, 7) + '-01';
const monthEnd = (d = today()) => { const x = new Date(d.slice(0, 7) + '-01T00:00:00'); x.setMonth(x.getMonth() + 1); x.setDate(0); return fmtD(x); };
const inRange = (d, a, b) => !!d && (!a || d >= a) && (!b || d <= b);
// 3.25: 사업자 여러 개 — 기본 사업자는 예전 그대로 'inv', 추가한 사업자는 'inv@아이디'에 따로 저장해요
let BIZ = { list: [{ id: 'main', name: '기본 사업자', type: '일반' }], cur: 'main' };
const invStoreKey = () => BIZ.cur === 'main' ? 'inv' : 'inv@' + BIZ.cur;
const bizCur = () => BIZ.list.find(b => b.id === BIZ.cur) || BIZ.list[0];
async function invSave() { freezeFees(); await store.set(invStoreKey(), INV); try { if (DRW.open) drwPaint(); } catch (e) {} }
// 3.42: it(품목)을 주면 크림 · 포이즌 수수료 할인 규칙(feedisc.js)을 반영해요
function partnerFee(p, price, it) {
  if (!price || !p) return 0;
  if (p.feeMode === 'kream') return feeOf(price, null, it);
  if (p.feeMode === 'none') return 0;
  const d = it && isPoizon(p) && typeof fdFind === 'function' ? fdFind('poizon', it) : null;
  let f = price * (d && d.kind === 'rate' ? +d.rate || 0 : +p.feeRate || 0) / 100 + (+p.feeFix || 0);
  if (p.vat === '별도') f *= 1.1;
  if (d && d.kind === 'pct') f *= 1 - Math.min(100, Math.max(0, +d.pct || 0)) / 100;
  return Math.floor(f / 10) * 10;
}
// 상용화 점검: 출고 수수료(개당)는 정산할 때 값으로 저장해요 — 나중에 설정·거래처 수수료를 바꿔도 지난 판매의 마진·장부·부가세는 그대로예요
const outFee = o => o.fee !== '' && o.fee != null ? +o.fee : partnerFee(partnerOf(o.partnerId), o.price, itemOf(o.itemId));
function freezeFees() { let n = 0; for (const o of INV.outs || []) if (o.settled && (o.fee === '' || o.fee == null)) { o.fee = partnerFee(partnerOf(o.partnerId), o.price, itemOf(o.itemId)); n++; } return n; }
const isPoizon = p => !!p && p.kind === 'sell' && (p.id === 'p-poizon' || p.name === '포이즌');
const poizonNoFee = () => INV.partners.some(p => isPoizon(p) && p.feeMode !== 'none' && p.feeMode !== 'kream' && !(+p.feeRate) && !(+p.feeFix));
const feeText = p => p.kind !== 'sell' ? '–' : p.feeMode === 'kream' ? `크림 계산식 (설정: ${S.rate}% + ${won(S.base)}, VAT 별도)` : p.feeMode === 'none' ? '수수료 없음' : `${+p.feeRate || 0}% + ${won(+p.feeFix || 0)} · VAT ${p.vat || '포함'}`;

// 재고 계산: 입고 묶음(lot)마다 남은 개수 = 입고 − 반품 − 교환 − 출고에 쓰인 개수 (출고는 먼저 들어온 것부터 꺼내요)
function invCalc() {
  const used = new Map();
  for (const o of INV.outs) for (const c of o.costs || []) used.set(c.lotId, (used.get(c.lotId) || 0) + c.qty);
  const left = new Map(), stock = new Map();
  for (const l of INV.lots) {
    const n = l.qty - (l.retQty || 0) - (l.exQty || 0) - (l.adjQty || 0) - (l.outQty || 0) - (used.get(l.id) || 0);   // outQty: 11/22 폐기 · 기타 반출 (stock.js)   // adjQty: 3.7.5 재고 수량 직접 수정(줄임)
    left.set(l.id, n);
    if (n > 0) { const k = l.itemId + '|' + l.size; const s = stock.get(k) || { qty: 0, value: 0 }; s.qty += n; s.value += n * l.cost; stock.set(k, s); }
  }
  return { used, left, stock };
}
function itemStock(it, C) {
  let qty = 0, value = 0; const by = {};
  for (const [k, s] of C.stock) { const [id, size] = k.split('|'); if (id === it.id) { qty += s.qty; value += s.value; by[size] = s; } }
  return { qty, value, by };
}
function allocate(itemId, size, qty, C) {
  const lots = INV.lots.filter(l => l.itemId === itemId && l.size === size && C.left.get(l.id) > 0).sort((a, b) => a.date.localeCompare(b.date) || a.at - b.at);
  const costs = []; let need = qty;
  for (const l of lots) { if (!need) break; const take = Math.min(need, C.left.get(l.id)); costs.push({ lotId: l.id, qty: take, cost: l.cost }); C.left.set(l.id, C.left.get(l.id) - take); need -= take; }
  return need ? null : costs;
}
// 상용화 점검: 출고에 잡힌 입고(costs)에서 뒤쪽 n개를 떼어 둘로 나눠요 (묶음출고 1원 맞추기용)
function splitCosts(costs, n) {
  const head = (costs || []).map(c => ({ ...c })), tail = [];
  for (let i = head.length - 1; i >= 0 && n > 0; i--) { const t = Math.min(n, head[i].qty); tail.unshift({ ...head[i], qty: t }); head[i].qty -= t; n -= t; }
  return [head.filter(c => c.qty > 0), tail];
}
// 매입가 칸이 비었는지 (0은 무상이라 비어 있지 않아요)
const priceBlank = v => String(v ?? '').replace(/[^\d.-]/g, '') === '';
function outNums(o) {
  const net = o.qty - (o.retQty || 0);
  const cq = (o.costs || []).reduce((s, c) => s + c.qty, 0);
  const unitCost = cq ? (o.costs.reduce((s, c) => s + c.qty * c.cost, 0) / cq) : 0;
  if (!o.settled) return { net, unitCost, price: 0, fee: 0, rev: 0, fees: 0, cogs: unitCost * net, ship: +o.ship || 0, margin: null };
  const fee = outFee(o);
  const price = o.price - (o.disc || 0);
  // 상용화 점검: 반품할 때 환급 못 받은 수수료(feeLost)도 비용이에요. feeLost 가 없는 옛 반품 기록은 예전처럼 셉니다
  const lost = (o.events || []).reduce((s, e) => s + (e.t === '반품' ? +e.feeLost || 0 : 0), 0);
  const rev = price * net, fees = fee * net + lost, cogs = unitCost * net, ship = +o.ship || 0;
  return { net, unitCost, price, fee, rev, fees, cogs, ship, margin: rev - fees - cogs - ship };
}
function beep(ok) {
  try { const a = new (window.AudioContext || window.webkitAudioContext)(); const o = a.createOscillator(), g = a.createGain(); o.frequency.value = ok ? 1320 : 220; g.gain.value = 0.08; o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + (ok ? 0.08 : 0.25)); setTimeout(() => a.close(), 400); } catch (e) {}
}
function xlDownload(sheets, name) {
  const blob = XL.write(sheets);
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
// 사이즈 표기 바꾸기 (신발 mm만 — 나이키 남성 기준이라 브랜드마다 조금 다를 수 있어요)
const szLabel = (s, m) => { if (!m) return s; const x = US_M[String(s).trim()]; return x ? (m === 'us' ? 'US ' + x[0] : 'EU ' + x[1]) : s; };
// 나이키 남성 기준 (브랜드마다 조금씩 달라요)
const US_M = { 220: ['4', '36'], 225: ['4.5', '36.5'], 230: ['5', '37.5'], 235: ['5.5', '38'], 240: ['6', '38.5'], 245: ['6.5', '39'], 250: ['7', '40'], 255: ['7.5', '40.5'], 260: ['8', '41'], 265: ['8.5', '42'], 270: ['9', '42.5'], 275: ['9.5', '43'], 280: ['10', '44'], 285: ['10.5', '44.5'], 290: ['11', '45'], 295: ['11.5', '45.5'], 300: ['12', '46'], 305: ['12.5', '47'], 310: ['13', '47.5'] };
const SIZE_PRESETS = { '남성 신발 250~300': [250, 255, 260, 265, 270, 275, 280, 285, 290, 295, 300], '여성 신발 220~260': [220, 225, 230, 235, 240, 245, 250, 255, 260], '공용 신발 220~300': [220, 225, 230, 235, 240, 245, 250, 255, 260, 265, 270, 275, 280, 285, 290, 295, 300], '의류 XS~XXL': ['XS', 'S', 'M', 'L', 'XL', 'XXL'], '의류 90~110': [90, 95, 100, 105, 110], 'FREE': ['FREE'] };

// ---------- 화면 틀 ----------
const INV_MENU = [
  ['home', '홈'], ['stock', '재고'], ['sell', '일반 판매'], ['storage', '보관 판매'], ['tbuy', '오늘 살 것'], ['drops', '발매'], ['events', '행사'], ['base', '기본정보'], ['items', '상품 · 재고'], ['io', '입출고'], ['bc', '바코드 입고'], ['plan', '입고예정 관리'], ['excel', '엑셀 대량 입고'], ['ms', '구매처 주문 입고'],
  ['pre', '우선출고 정산'], ['ret', '반품 · 교환'], ['ledger', '정산 · 부가세'], ['vat', '부가세 예상'], ['ana', '분석'], ['reset', '백업 · 초기화']
];
function renderInv() {
  const nav = $('#invNav'); if (!nav) return;
  renderBiz();
  const C = invCalc();
  const preN = INV.outs.filter(o => o.kind === 'pre' && !o.settled).length;
  const soonN = INV.lots.filter(l => !l.confirmed && C.left.get(l.id) > 0 && l.returnDue && dday(l.returnDue) >= 0 && dday(l.returnDue) <= INV.opt.soon).length;   // 상용화 점검: 홈 카드처럼 기한 지난 건 빼요
  const tt = $('#viewTitle'); if (tt && typeof curMode !== 'undefined' && curMode === 'inv') tt.textContent = ($('#viewGroup') ? '' : '재고관리 · ') + ((INV_MENU.find(m => m[0] === invView) || [])[1] || '');
  const IIC = { stock: 'box', sell: 'swap', storage: 'archive', tbuy: 'cart', drops: 'spark', events: 'cal', home: 'home', base: 'info', items: 'tag', io: 'swap', bc: 'sheet', plan: 'cal', excel: 'sheet', ms: 'cart', pre: 'zap', ret: 'ret', ledger: 'book', vat: 'percent', ana: 'chart', reset: 'shield' };
  nav.innerHTML = INV_MENU.map(([k, t]) => `<button type="button" data-v="${k}" aria-current="${k === invView}">${typeof ico === 'function' ? ico(IIC[k]) : ''}<span class="lbl">${t}</span>${k === 'pre' && preN ? ` <span class="cnt">${preN}</span>` : ''}${k === 'ret' && soonN ? ` <span class="cnt warn">${soonN}</span>` : ''}${k === 'ms' && +INV.opt.autoHours > 0 ? '<span class="sbadge on">자동</span>' : ''}${typeof canUse === 'function' && !canUse('inv:' + k) ? `<span class="slock">${ico('lock')}</span>` : ''}</button>`).join('');
  if (renderInv.last !== invView) { if (['io', 'bc'].includes(renderInv.last)) IS.io.msg = ''; renderInv.last = invView; }   // 상용화 점검: 입출고를 떠나면 지난 안내를 지워요
  const V = { stock: typeof vStock === 'function' ? vStock : vHome, sell: typeof vSell === 'function' ? vSell : vHome, storage: typeof vStorage === 'function' ? vStorage : vHome, tbuy: typeof vTbuy === 'function' ? vTbuy : vHome, drops: typeof vRel === 'function' ? vRel : vHome, events: typeof vEvents === 'function' ? vEvents : vHome, home: vHome, base: vBase, items: vItems, io: vIO, bc: vIO, plan: vPlan, excel: vExcel, ms: vMs, pre: vPre, ret: vRet, ledger: vLedger, vat: vVat, ana: typeof vAna === 'function' ? vAna : vHome, reset: vReset }[invView] || vHome;
  $('#invMain').innerHTML = V(C);
  if (invView === 'io') { const q = $('#ioQ'); if (q && IS.io.bc) q.focus(); }
}
function go(v) { if (typeof route === 'function') return route('inv:' + v); invView = v; IS.msg = ''; renderInv(); window.scrollTo(0, 0); }
// 3.19: 숫자 카드 — 색 그라데이션 아이콘 + 아래 빛나는 선
const KC_IC = [[/대기|임박|처리할|기한/, 'cal'], [/입고|주문 상품/, 'down'], [/출고|발송/, 'truck'], [/반품|취소/, 'undo'], [/중복|바코드/, 'sheet'], [/자산|금액|가|세액|마진|현금|원가|매출|매입/, 'receipt'], [/재고|수량/, 'cube'], [/상품|종/, 'tag'], [/상태|자동/, 'zap'], [/계정/, 'key'], [/건|내역|줄/, 'book']];
const card = (label, val, cls = '', sub = '') => {
  const ic = (KC_IC.find(([re]) => re.test(label)) || [0, 'chart'])[1];
  const tone = { pos: 'green', acc: 'blue', warn: 'orange', neg: 'red' }[cls] || 'violet';
  return `<div class="kcard kc-${tone}"><div class="kc-top"><span>${label}</span>${typeof ico === 'function' ? `<i class="kc-ic">${ico(ic)}</i>` : ''}</div><b class="${cls}">${val}</b>${sub ? `<small>${sub}</small>` : ''}<em class="kc-line" aria-hidden="true"></em></div>`;
};
const head = (t, d, right = '') => `<div class="ihead"><div><h2>${t}</h2>${d ? `<p class="hint">${d}</p>` : ''}</div><div class="row-btns">${right}</div></div>`;
const flash = () => IS.msg ? `<p class="iflash">${esc(IS.msg)}</p>` : '';

// ---------- 홈 ----------
function monthFigures(a, b) {
  let sold = 0, rev = 0, fees = 0, margin = 0, buy = 0;
  for (const o of INV.outs) if (o.settled && inRange(o.settleDate, a, b)) { const n = outNums(o); sold += n.net; rev += n.rev; fees += n.fees; margin += n.margin; }
  // 상용화 점검: 장부와 같은 기준 — 원래 입고분은 입고일에 +, 매입 반품은 (교환으로 받은 것까지) 반품일에 −
  for (const l of INV.lots) {
    if (lotIsBuy(l) && inRange(l.date, a, b)) buy += l.cost * l.qty;
    for (const e of l.events || []) if (e.t === '반품' && inRange(e.d, a, b)) buy -= l.cost * (+e.q || 0);
  }
  let exp = 0; for (const x of INV.expenses || []) if (inRange(x.date, a, b)) exp += +x.amount || 0;   // 개선판 1-9: 지출(택배비·유류비 등)
  return { sold, rev, fees, margin, buy, exp };
}
// 매입으로 세는 입고 (교환·판매 반품·재고 조정으로 생긴 입고는 새로 산 게 아니라서 빼요)
const lotIsBuy = l => !['exchange', 'return', 'adjust'].includes(l.src);
// 개선판 1-4: 홈 '오늘 할 일' — 재고관리 밖(크림 판매 · 자동 입찰 · 계정 연결 · 소싱 예약)도 모아요. 누르면 그 화면 · 필터로 가요
const retOpen = (l, C) => !l.confirmed && C.left.get(l.id) > 0 && l.src !== 'return' && !!l.returnDue;
function invAlerts(C) {
  const A = [], nm = l => `${itName(itemOf(l.itemId))} ${l.size}`;
  const few = (L, f = nm) => L.slice(0, 2).map(f).join(', ') + (L.length > 2 ? ` 외 ${L.length - 2}건` : '');
  const R = INV.lots.filter(l => retOpen(l, C)).map(l => [l, dday(l.returnDue)]);
  const r01 = R.filter(([, d]) => d >= 0 && d <= 1).map(([l]) => l), rSoon = R.filter(([, d]) => d >= 2 && d <= INV.opt.soon).map(([l]) => l), rPast = R.filter(([, d]) => d < 0).map(([l]) => l);
  if (r01.length) A.push({ lv: 'bad', t: `오늘·내일 반품 마감 ${r01.length}건 — ${few(r01)}`, go: 'inv:ret', f: 'd1' });
  if (rSoon.length) A.push({ lv: 'warn', t: `반품 마감 D-${INV.opt.soon} 이내 ${rSoon.length}건 — ${few(rSoon)}`, go: 'inv:ret', f: 'alert' });
  if (typeof kSales !== 'undefined' && kSales && kSales.unrec) {
    const have = new Set(INV.outs.map(o => String(o.kreamSaleId || '')));
    const U = Object.entries(kSales.unrec).filter(([id]) => !have.has(id)).map(([, u]) => u);
    if (U.length) A.push({ lv: 'warn', t: `재고와 연결 못 한 크림 판매 ${U.length}건 — ${few(U, u => `${u.name} ${u.size}`)}`, go: 'khist', f: 'sell' });
  }
  try { if (typeof KM !== 'undefined' && XS.km && XS.km[KM.kship.page]) { const S = kRows(XS.km[KM.kship.page].cap).filter(r => /발송|입고 대기|체결/.test(String(r.status || '')) && kDday(r.exp) != null && kDday(r.exp) <= 0); if (S.length) A.push({ lv: 'bad', t: `발송 기한이 오늘이거나 지난 크림 판매 ${S.length}건 — ${few(S, r => `${r.name || r.code || ''} ${r.size || ''}`)}`, go: 'kship' }); } } catch (e) {}
  try { if (typeof kAlignRows === 'function' && typeof kInv !== 'undefined' && kInv) { const B = kAlignRows().filter(r => r.diff !== 0 && !kAlignHide.includes(r.key)); if (B.length) A.push({ lv: 'warn', t: `크림 보관 판매 수량과 재고가 다른 상품 ${B.length}건`, go: 'kinv' }); } } catch (e) {}
  if (typeof mktHits === 'function') { const H = mktHits(C); if (H.length) A.push({ lv: 'warn', t: `수익 알림 ${H.length}건 — ${few(H, h => `${itName(h.it)} ${h.size} 개당 ${wonS(h.unit)} (${MKT_LABEL[h.where]})`)}`, go: 'inv:items', f: 'in' }); }
  const pre = INV.outs.filter(o => o.kind === 'pre' && !o.settled);
  if (pre.length) A.push({ lv: 'warn', t: `우선출고 ${pre.length}건이 정산 대기 중이에요`, go: 'inv:pre' });
  if (typeof abList !== 'undefined') {
    const L = abList.filter(it => !it.on && !it.gone), floor = L.filter(it => /^하한가 도달/.test(it.st || '')), stop = L.filter(it => /^멈춤|3번 실패/.test(it.st || ''));
    const an = it => `${String(it.name || '').slice(0, 24)} ${it.size || ''}`;
    if (floor.length) A.push({ lv: 'warn', t: `하한가에 닿아 멈춘 자동 입찰 ${floor.length}건 — ${few(floor, an)}`, go: 'kauto' });
    if (stop.length) A.push({ lv: 'bad', t: `실패·확인 불일치로 멈춘 자동 입찰 ${stop.length}건 — ${few(stop, an)}`, go: 'kauto' });
  }
  if (typeof acctState !== 'undefined') {
    const off = Object.entries(acctState).filter(([, x]) => x && x.st === 'off').map(([k]) => (typeof acctOf === 'function' && acctOf(k) || {}).label || k);
    if (off.length) A.push({ lv: 'bad', t: `로그인이 풀린 계정 ${off.length}개 — ${off.slice(0, 3).join(', ')}${off.length > 3 ? ' 외' : ''}`, go: 'acct' });
  }
  if (typeof FS !== 'undefined' && FS && FS.lastFail && Date.now() - FS.lastFail.at < 3 * 864e5) A.push({ lv: 'warn', t: `소싱 예약이 제대로 안 끝났어요 (${new Date(FS.lastFail.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}) — ${FS.lastFail.why}`, go: 'find' });
  if (rPast.length) A.push({ lv: 'mute', t: `반품 기한 지난 매입 ${rPast.length}건 — 안 돌려보낼 거면 [보유]로 정리해요`, go: 'inv:ret', f: 'past' });
  const stale = INV.lots.filter(l => C.left.get(l.id) > 0 && dday(l.date) <= -INV.opt.staleDays);
  if (stale.length) A.push({ lv: 'mute', t: `${INV.opt.staleDays}일 넘게 안 팔린 재고 ${stale.reduce((s, l) => s + C.left.get(l.id), 0)}개`, go: 'inv:items', f: 'in' });
  return A;
}
function vHome(C) {
  const t = today();
  const inToday = INV.lots.filter(l => l.date === t && !['exchange', 'return', 'adjust'].includes(l.src)).reduce((s, l) => s + l.qty, 0);
  const outToday = INV.outs.filter(o => o.date === t).reduce((s, o) => s + o.qty, 0);
  const pre = INV.outs.filter(o => o.kind === 'pre' && !o.settled);
  let skus = new Set(), qty = 0, value = 0;
  for (const [k, s] of C.stock) { skus.add(k.split('|')[0]); qty += s.qty; value += s.value; }
  const M = monthFigures(monthStart(), monthEnd());
  const A = invAlerts(C);
  // 최근 6개월 마진 막대
  const months = []; const d0 = new Date(t.slice(0, 7) + '-01T00:00:00');
  for (let i = 5; i >= 0; i--) { const d = new Date(d0); d.setMonth(d.getMonth() - i); const s = fmtD(d); months.push({ m: s.slice(0, 7), ...monthFigures(monthStart(s), monthEnd(s)) }); }
  const mx = Math.max(1, ...months.map(m => Math.abs(m.margin)));
  const neg = months.some(m => m.margin < 0), base = neg ? 100 : 130, hmax = neg ? 62 : 96;
  const bars = months.map((m, i) => { const h = Math.round(Math.abs(m.margin) / mx * hmax); const x = 28 + i * 68; return `<rect x="${x}" y="${m.margin >= 0 ? base - h : base}" width="34" height="${Math.max(h, 1)}" rx="3" class="${m.margin >= 0 ? 'b-pos' : 'b-neg'}"><title>${m.m} 마진 ${wonS(m.margin)} · 판매 ${m.sold}개</title></rect><text x="${x + 17}" y="${m.margin >= 0 ? base - h - 6 : base + h + 14}" text-anchor="middle" class="b-val">${m.margin ? (Math.abs(m.margin) >= 10000 ? (m.margin < 0 ? '−' : '') + (Math.abs(m.margin) < 100000 ? Math.round(Math.abs(m.margin) / 1000) / 10 : Math.round(Math.abs(m.margin) / 10000)) + '만' : wonS(m.margin)) : ''}</text><text x="${x + 17}" y="${neg ? 186 : 152}" text-anchor="middle" class="b-lab">${+m.m.slice(5)}월</text>`; }).join('');
  return `${head('홈', '오늘 할 일, 오늘 입출고, 최근 30일 숫자, 재고를 한눈에 봐요.', `<button type="button" class="primary" data-a="quick" data-v="in">입고 등록</button><button type="button" class="ghost" data-a="quick" data-v="out">출고 등록</button><button type="button" class="ghost" data-a="quick" data-v="pre">우선출고</button><button type="button" class="ghost" data-a="nav" data-v="items">상품 관리</button><button type="button" class="ghost" data-a="nav" data-v="ledger">장부</button><button type="button" class="ghost" data-a="sendMobile">휴대폰으로 보내기</button>`)}
  ${flash()}${typeof sgLine === 'function' ? sgLine() : ''}
  ${!INV.items.length && !INV.lots.length ? `<div class="panel inv-start"><h2>처음 시작하기</h2><p class="hint">세 단계만 하면 재고 · 장부 · 마진이 저절로 정리돼요.</p><ol class="inv-steps">
    <li><b>① 거래처 · 결제수단 확인</b><span class="sub">사 오는 곳(매입처)과 파는 곳(매출처) 수수료, 쓰는 카드를 확인해요.${poizonNoFee() ? ' 포이즌 수수료도 넣어 주세요.' : ''}</span><button type="button" class="ghost" data-a="nav" data-v="base">기본정보 열기</button></li>
    <li><b>② 상품 넣기</b><span class="sub">상품을 직접 추가하거나, 무신사 · 지그재그 같은 구매처 주문을 불러와 바로 입고해요.</span><span class="row-btns"><button type="button" class="ghost" data-a="itemEdit" data-id="">상품 추가</button><button type="button" class="ghost" data-a="nav" data-v="ms">구매처 주문 불러오기</button></span></li>
    <li><b>③ 출고 · 정산</b><span class="sub">팔면 출고로, 판매가가 나중에 정해지면 우선출고로 넣고 정산해요.</span><span class="row-btns"><button type="button" class="ghost" data-a="quick" data-v="out">출고 등록</button><button type="button" class="ghost" data-a="nav" data-v="pre">우선출고 정산</button></span></li></ol></div>` : ''}
  <div class="kgrid">${card('오늘 입고', inToday + '개', 'pos')}${card('오늘 출고', outToday + '개', 'acc')}${card('우선출고 정산 대기', pre.length + '건', pre.length ? 'warn' : '')}${(() => { const D = INV.lots.filter(l => retOpen(l, C)).map(l => dday(l.returnDue)).filter(d => d >= 0 && d <= INV.opt.soon); return card('반품 기한 임박', D.length + '건', D.some(d => d <= 1) ? 'neg' : D.length ? 'warn' : ''); })()}</div>
  <div class="igrid2">
    <div class="box todo"><h3>오늘 할 일</h3>${A.length ? `<ul class="alerts">${A.slice(0, 14).map(a => `<li><span class="pill ${a.lv}">${a.lv === 'bad' ? '급함' : a.lv === 'warn' ? '확인' : '참고'}</span> <button type="button" class="linkbtn" data-a="todo" data-v="${a.go}" data-f="${a.f || ''}">${esc(a.t)}</button></li>`).join('')}</ul>` : '<p class="hint">오늘 처리할 일이 없어요.</p>'}</div>
    <div class="box"><h3>최근 30일</h3>${(() => { const a = addDays(t, -29), F = monthFigures(a, t); let cogs = 0; for (const o of INV.outs) if (o.settled && inRange(o.settleDate, a, t)) cogs += outNums(o).cogs; const net = F.rev - F.fees, roi = cogs ? Math.round(F.margin / cogs * 1000) / 10 : null, cash = net - F.buy - F.exp;
      return `<div class="kgrid k2">${card('매입', won(F.buy), '', '반품 뺀 금액')}${card('판매 실수령', won(net), 'acc', `판매 ${F.sold}개 · 수수료 뺀 금액`)}${card('원가 수익률', roi == null ? '–' : roi + '%', roi > 0 ? 'pos' : roi < 0 ? 'neg' : '', `마진 ${wonS(F.margin)} ÷ 판매 원가`)}${card('현금흐름', wonS(cash), cash >= 0 ? 'pos' : 'neg', F.exp ? `판매 실수령 − 매입 − 지출 ${won(F.exp)}` : '판매 실수령 − 매입')}</div>`; })()}
      <h3 class="h3sub">${+t.slice(5, 7)}월 실적</h3><dl class="kv"><dt>판매</dt><dd>${M.sold}개 · ${won(M.rev)}</dd><dt>매입</dt><dd>${won(M.buy)}</dd><dt>수수료</dt><dd>${won(M.fees)}</dd><dt>판매 마진 (판매 − 수수료 − 매입원가 − 택배비)</dt><dd><b class="${M.margin >= 0 ? 'pos' : 'neg'}">${wonS(M.margin)}</b></dd><dt>지출 (택배비 · 유류비 · 주차비 · 포장재 · 기타)</dt><dd>${won(M.exp)}</dd><dt>지출 뺀 순이익</dt><dd><b class="${M.margin - M.exp >= 0 ? 'pos' : 'neg'}">${wonS(M.margin - M.exp)}</b></dd></dl></div>
  </div>
  <div class="igrid2">
    <div class="box"><h3>재고 현황</h3><dl class="kv"><dt>재고 있는 상품</dt><dd>${skus.size}종</dd><dt>전체 재고</dt><dd>${qty}개</dd><dt>재고 자산 (매입가 기준)</dt><dd><b>${won(value)}</b></dd></dl>${(() => { const by = new Map(); for (const [k, st] of C.stock) { const id = k.split('|')[0]; const x = by.get(id) || { qty: 0, value: 0 }; x.qty += st.qty; x.value += st.value; by.set(id, x); } const top = [...by.entries()].filter(([, x]) => x.value > 0).sort((a, b) => b[1].value - a[1].value).slice(0, 3); return top.length ? `<h4 class="sub" style="margin:12px 0 6px">재고 자산 상위 ${top.length}</h4><ol class="top3">${top.map(([id, x], i) => `<li><span class="pill ${i ? 'mute' : 'acc'}">${i + 1}위</span> <b>${esc(itName(itemOf(id)))}</b> <span class="sub">${x.qty}개 · ${won(x.value)}</span></li>`).join('')}</ol>` : ''; })()}</div>
    <div class="box"><h3>최근 6개월 판매 마진</h3><svg viewBox="0 0 440 ${neg ? 196 : 162}" class="ichart" role="img" aria-label="최근 6개월 판매 마진"><defs><linearGradient id="gPos" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6ee7b7"/><stop offset="1" stop-color="#10b981"/></linearGradient><linearGradient id="gNeg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f43f5e"/><stop offset="1" stop-color="#fb7185"/></linearGradient></defs><line x1="10" x2="430" y1="${base}" y2="${base}" class="b-axis"/>${bars}</svg></div>
  </div>`;
}

// ---------- 기본정보 ----------
// 11/23: 기본정보 칸 내용은 설정 › 매장 · 판매처 · 사업자에서도 그대로 써요(stset.js)
function vBaseBody(K) { let body = '';
  if (K === 'partners') {
    const row = p => `<tr><td class="l"><b>${esc(p.name)}</b><div class="small">${esc(p.biz || '')}</div></td><td class="l">${p.kind === 'buy' ? '매입처' : '매출처'}</td><td class="l">${esc(p.tax)}</td><td class="l">${esc(feeText(p))}</td><td>${p.kind === 'buy' && p.store ? '<span class="small">브랜드별 13~15일</span>' : p.kind === 'buy' ? (p.returnDays ?? INV.opt.returnDays) + '일' : '–'}</td><td><div class="act"><button type="button" class="ghost" data-a="partnerEdit" data-id="${p.id}">수정</button><button type="button" class="ghost" data-a="partnerDel" data-id="${p.id}">삭제</button></div></td></tr>`;
    const pz = INV.partners.find(p => isPoizon(p));
    body = `<div class="row-btns"><button type="button" class="primary" data-a="partnerEdit" data-id="">거래처 추가</button><button type="button" class="ghost" data-a="stkStoreDict">매장 사전에서 고르기</button><span class="hint">매입처 = 사 오는 곳, 매출처 = 파는 곳. 매출처 수수료는 출고·정산할 때 자동으로 빠지고, 그때 값으로 저장돼요(나중에 바꿔도 지난 판매는 그대로예요).</span></div>
    ${poizonNoFee() && pz ? `<p class="iflash neg">포이즌 수수료를 넣어 주세요 — 지금 0% + 0원이라 포이즌 판매 마진이 실제보다 크게 나와요. <button type="button" class="linkbtn" data-a="partnerEdit" data-id="${pz.id}">포이즌 수수료 넣기</button></p>` : ''}
    <div class="tbl"><table><thead><tr><th class="l">거래처명 · 상호</th><th class="l">구분</th><th class="l">과세</th><th class="l">수수료</th><th>반품 기한</th><th></th></tr></thead><tbody>${INV.partners.map(row).join('')}</tbody></table></div>`;
  } else if (K === 'cats') {
    body = `<div class="igrid2"><div class="box"><h3>분류 (대분류 → 소분류)</h3>${Object.entries(INV.cats).map(([c, subs]) => `<div class="catrow"><b>${esc(c)}</b> <button type="button" class="x" data-a="catDel" data-c="${esc(c)}" aria-label="${esc(c)} 삭제">×</button><div class="chips">${subs.map(s => `<span class="chip">${esc(s)}<button type="button" class="x" data-a="subDel" data-c="${esc(c)}" data-s="${esc(s)}" aria-label="${esc(s)} 삭제">×</button></span>`).join('')}<input class="mini tagin" data-k="subAdd" data-c="${esc(c)}" placeholder="소분류 추가 후 Enter"></div></div>`).join('')}
      <input class="mini tagin" data-k="catAdd" placeholder="대분류 추가 후 Enter"></div>
      <div class="box"><h3>브랜드</h3><div class="chips">${INV.brands.map(b => `<span class="chip">${esc(b)}<button type="button" class="x" data-a="brandDel" data-s="${esc(b)}" aria-label="${esc(b)} 삭제">×</button></span>`).join('')}</div><input class="mini tagin" data-k="brandAdd" placeholder="브랜드 추가 후 Enter"></div></div>`;
  } else if (K === 'pays') {
    body = `<div class="row-btns"><button type="button" class="primary" data-a="payEdit" data-id="">결제수단 추가</button><span class="hint">카드·계좌 번호는 넣지 마세요. 이름과 끝 4자리면 충분해요.</span></div>
    <div class="tbl"><table><thead><tr><th class="l">종류</th><th class="l">이름</th><th class="l">끝 4자리</th><th class="l">부가세 증빙</th><th></th></tr></thead><tbody>${INV.pays.map(p => `<tr><td class="l">${esc(p.type)}</td><td class="l"><b>${esc(p.name)}</b>${p.issuer ? `<div class="small">${esc(p.issuer)}카드</div>` : ''}</td><td class="l">${esc(p.last4 || '')}</td><td class="l">${p.proof === false ? '없음' : '있음'}</td><td><div class="act"><button type="button" class="ghost" data-a="payEdit" data-id="${p.id}">수정</button><button type="button" class="ghost" data-a="payDel" data-id="${p.id}">삭제</button></div></td></tr>`).join('') || '<tr><td colspan="5" class="empty">아직 없어요</td></tr>'}</tbody></table></div>`;
  } else if (K === 'couriers') {
    const B = ['극소', '소', '중', '대', '특대'];
    body = `<div class="row-btns"><button type="button" class="primary" data-a="courierEdit" data-id="">택배사 추가</button><span class="hint">박스 크기별 비용을 넣어 두면 출고할 때 골라서 넣을 수 있어요.</span></div>
    <div class="tbl"><table><thead><tr><th class="l">택배사</th>${B.map(b => `<th>${b}</th>`).join('')}<th></th></tr></thead><tbody>${INV.couriers.map(c => `<tr><td class="l"><b>${esc(c.name)}</b></td>${B.map(b => `<td>${c.box[b] ? won(+c.box[b]) : '–'}</td>`).join('')}<td><div class="act"><button type="button" class="ghost" data-a="courierEdit" data-id="${c.id}">수정</button><button type="button" class="ghost" data-a="courierDel" data-id="${c.id}">삭제</button></div></td></tr>`).join('')}</tbody></table></div>`;
  } else {
    body = `<div class="box"><div class="grid-set">
      <label>기본 반품 기한 (입고일부터, 일)<input type="number" min="0" data-k="opt" data-o="returnDays" value="${INV.opt.returnDays}"></label>
      <label>반품 기한 임박 알림 (남은 일수)<input type="number" min="0" data-k="opt" data-o="soon" value="${INV.opt.soon}"></label>
      <label>장기 재고 기준 (입고 후, 일)<input type="number" min="1" data-k="opt" data-o="staleDays" value="${INV.opt.staleDays}"></label></div>
      <p class="hint">매입처마다 반품 기한을 따로 정하면 그 값이 먼저 쓰여요. 크림 수수료 계산식은 위쪽 '설정'의 수수료율·기본료를 같이 써요.</p></div>`;
  }
  return body;
}
function vBase() {
  const tabs = [['partners', '거래처'], ['cats', '분류 · 브랜드'], ['pays', '결제수단'], ['couriers', '택배사'], ['opt', '기본값']];
  const bodyOf = vBaseBody;
  if ((IS.base || 'grid') === 'grid') {
    const panel = (k, t, ic, n, cls) => `<div class="box bs-p ${cls}"><div class="bs-h"><i>${ico(ic)}</i><b>${t}</b><span class="sub">${n}</span></div>${bodyOf(k)}</div>`;
    const buyN = INV.partners.filter(p => p.kind === 'buy').length, sellN = INV.partners.length - buyN;
    return `${head('기본정보 관리', '거래처 · 결제수단 · 분류 · 배송사를 한 화면에서 관리해요. 등록해 두면 입출고와 장부에서 골라 써요.')}${flash()}
    <div class="bs-grid">${panel('partners', '거래처', 'cart', `매입 ${buyN} · 매출 ${sellN}`, 'c1')}${panel('pays', '결제수단', 'receipt', `${INV.pays.length}개`, 'c2')}${panel('cats', '분류 · 브랜드', 'tag', `대분류 ${Object.keys(INV.cats).length} · 브랜드 ${INV.brands.length}`, 'c3')}${panel('couriers', '배송사', 'truck', `${INV.couriers.length}곳`, 'c4')}</div>
    <div class="box bs-p c5"><div class="bs-h"><i>${ico('gear')}</i><b>기본값</b><span class="sub">반품 기한 · 알림 · 장기 재고 기준</span></div>${bodyOf('opt')}</div>`;
  }
  const body = bodyOf(IS.base);
  return `${head('기본정보', '거래처·분류·결제수단·택배사를 등록해 두면 입출고와 장부에서 골라 써요.')}${flash()}
  <div class="subtabs">${tabs.map(([k, t]) => `<button type="button" data-a="baseTab" data-v="${k}" aria-selected="${IS.base === k}">${t}</button>`).join('')}</div>${body}`;
}

// ---------- 상품 · 재고 ----------
// 개선판 1-5: 상품에서 가장 가까운 반품 기한 (보유 · 기한 없음 · 다 나간 입고는 빼요). 지난 것만 있으면 -1, 없으면 null
function itemRetDue(it, C) { let m = null, past = false; for (const l of INV.lots) if (l.itemId === it.id && retOpen(l, C)) { const d = dday(l.returnDue); if (d < 0) past = true; else if (m == null || d < m) m = d; } return m != null ? m : past ? -1 : null; }
function itemsFiltered(C) {
  const F = IS.items, q = F.q.trim().toLowerCase();
  return INV.items.filter(it => {
    if (F.brand && it.brand !== F.brand) return false;
    if (F.cat && it.cat !== F.cat) return false;
    if (q && !(`${it.code} ${it.name} ${it.brand} ${Object.values(it.barcodes || {}).join(' ')}`.toLowerCase().includes(q))) return false;
    if ((F.only || F.tab === 'in') && !itemStock(it, C).qty) return false;
    if (F.tab === 'out' && itemStock(it, C).qty) return false;
    if (F.tab === 'due') { const d = itemRetDue(it, C); if (d == null || d < 0 || d > 7) return false; }
    return true;
  });
}
function vItems(C) {
  const F = IS.items, list = itemsFiltered(C);
  const bcAll = {}; for (const it of INV.items) for (const v of Object.values(it.barcodes || {})) if (v) bcAll[v] = (bcAll[v] || 0) + 1;
  let tq = 0, tv = 0, mq = 0, mn = 0, mp = 0;
  const rows = list.map(it => {
    const st = itemStock(it, C); tq += st.qty; tv += st.value;
    const MK = mktItem(it, C); mq += MK.qty; mn += MK.net; mp += MK.profit;   // 개선판 1-5: 시세 (mkt.js)
    const sizes = (it.sizes || []).map(s => { const n = st.by[s] ? st.by[s].qty : 0; return `<span class="sz-chip${n ? ' on' : ''}" title="${esc(s)}">${esc(szLabel(s, F.sz))}${n ? ` <b>${n}</b>` : ''}</span>`; }).join('');
    const open = F.open === it.id;
    const rd = itemRetDue(it, C), rdp = rd == null || rd > 7 ? '' : ` <span class="pill ${rd < 0 ? 'mute' : rd <= 2 ? 'bad' : 'warn'}" title="가장 가까운 반품 기한 (보유 표시한 건 빼요)">${rd < 0 ? '반품 기한 지남' : rd === 0 ? '오늘 반품 마감' : '반품 D-' + rd}</span>`;
    return `<tr class="item" data-a="itemOpen" data-id="${it.id}"><td class="l name"><b>${esc(itName(it))}</b><span class="code">${esc(it.code)}</span>${rdp}</td><td class="l cat">${esc([it.cat, it.sub].filter(Boolean).join(' · '))}</td><td class="l"><div class="sz-wrap">${sizes || '<span class="small">사이즈 없음</span>'}</div></td><td><b class="n">${st.qty}</b></td><td>${st.qty ? won(st.value / st.qty) : '–'}</td><td>${won(st.value)}</td><td>${MK.qty ? won(MK.net) : '<span class="small">–</span>'}</td><td class="${MK.profit > 0 ? 'pos' : MK.profit < 0 ? 'neg' : ''}">${MK.qty ? `${wonS(Math.round(MK.profit))}<div><span class="pill ${MK.best === 'poizon' ? 'acc' : 'ok'}">${MKT_LABEL[MK.best]}</span>${MK.qty < st.qty ? ` <span class="small">${MK.qty}/${st.qty}개</span>` : ''}</div>` : '–'}</td>
      <td><div class="act"><button type="button" class="ghost" data-a="itemIn" data-id="${it.id}">입고</button><button type="button" class="ghost" data-a="itemOut" data-id="${it.id}">출고</button><button type="button" class="ghost" data-a="itemEdit" data-id="${it.id}">수정</button><button type="button" class="ghost" data-a="itemDel" data-id="${it.id}">삭제</button></div></td></tr>
      ${open ? `<tr class="detail"><td colspan="9">${itemDetail(it, C, bcAll)}</td></tr>` : ''}`;
  }).join('');
  return `${head('상품 · 재고', '상품을 누르면 사이즈별 재고·바코드·입출고 이력이 보여요.', `<button type="button" class="primary" data-a="ordQuick">구매처 주문 불러와서 자동 입고</button><button type="button" class="ghost" data-a="itemEdit" data-id="">상품 추가</button><button type="button" class="ghost" data-a="sizeSortAll">사이즈 전체 정렬</button><button type="button" class="ghost" data-a="itemsXl">엑셀 다운로드</button><button type="button" class="ghost" data-a="mktAll" title="재고 있는 품번의 크림 · 포이즌 시세를 가져와요 (12시간 안에 본 품번은 건너뛰어요)">${IS.mkt ? `시세 갱신 멈추기 (${IS.mkt.i}/${IS.mkt.n})` : '시세 갱신'}</button>`)}
  ${flash()}
  <div class="filters"><input type="search" data-k="itemsQ" value="${esc(F.q)}" placeholder="품번 · 상품명 · 바코드 검색">
    <select data-k="itemsBrand"><option value="">브랜드 전체</option>${[...new Set(INV.items.map(i => i.brand).filter(Boolean))].sort().map(b => opt(b, b, F.brand === b)).join('')}</select>
    <select data-k="itemsCat"><option value="">분류 전체</option>${Object.keys(INV.cats).map(c => opt(c, c, F.cat === c)).join('')}</select>
</div>
  <div class="kh-row it-tools"><div class="kh-tabs2">${[['all', '전체'], ['in', '재고 있음'], ['out', '품절'], ['due', `반품 임박 ${INV.items.filter(it => { const d = itemRetDue(it, C); return d != null && d >= 0 && d <= 7; }).length}`]].map(([k, t]) => `<button type="button" class="${(F.tab || (F.only ? 'in' : 'all')) === k ? 'on' : ''}" data-a="itemsTab" data-v="${k}">${t}</button>`).join('')}</div>
    <button type="button" class="kq" data-a="itemsFold">${ico('down')}전부 접기</button><button type="button" class="kq" data-a="sizeSortAll">사이즈 정렬</button>
    <span class="topsp"></span><span class="sub">사이즈 표기</span><div class="dl-seg it-sz">${[['', 'KR'], ['eu', 'EU'], ['us', 'US']].map(([k, t]) => `<button type="button" data-a="itemsSz" data-v="${k}" aria-pressed="${(F.sz || '') === k}">${t}</button>`).join('')}</div></div>
  <div class="kgrid">${card('재고', tq + '개', '', list.length + '종')}${card('매입 원가', won(tv), '', '재고 자산')}${card('예상 실수령', mq ? won(mn) : '–', 'acc', mq ? `시세 있는 ${mq}개 기준` : '시세 갱신을 눌러 주세요')}${card('예상 손익', mq ? wonS(Math.round(mp)) : '–', mp > 0 ? 'pos' : mp < 0 ? 'neg' : '', mq ? '실수령 − 매입 원가' : '')}</div>${Object.values(bcAll).some(n => n > 1) ? `<p class="iflash neg">중복 바코드 ${Object.values(bcAll).filter(n => n > 1).length}개 — 상품을 열어 바코드를 확인해 주세요</p>` : ''}
  <div class="tbl"><table class="main"><thead><tr><th class="l">상품</th><th class="l cat">분류</th><th class="l">사이즈별 재고</th><th>재고</th><th>평균 매입가</th><th>재고 금액</th><th title="시세 있는 사이즈만 · 더 남는 판매처 기준">예상 실수령</th><th>예상 손익 · 추천</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="9" class="empty">상품이 없어요. 위의 <b>구매처 주문 불러와서 자동 입고</b>를 누르면 무신사·지그재그·ABC마트 등에서 산 상품이 재고로 들어와요.<br><span class="small">어느 구매처를 볼지·자동 동기화 간격은 <button type="button" class="linkbtn" data-a="nav" data-v="ms"><b>구매처 주문 입고</b></button> 메뉴에서 정해요. 직접 넣으려면 <b>상품 추가</b>나 <b>엑셀 대량 입고</b>.</span></td></tr>`}</tbody></table></div>`;
}
// 3.7.5: 재고 수량 직접 수정 — 늘리면 '재고 조정' 입고(평균 매입가), 줄이면 최근 입고분부터 조정 수량으로 빼요 (장부·매입 합계에는 안 잡힘)
async function stockSet(itemId, size, want) {
  want = Math.max(0, Math.floor(+want || 0));
  const C = invCalc(); const cur = (C.stock.get(itemId + '|' + size) || { qty: 0, value: 0 });
  const diff = want - cur.qty; if (!diff) return 0;
  if (diff > 0) {
    const mine = INV.lots.filter(l => l.itemId === itemId && l.src !== 'adjust').sort((a, b) => b.date.localeCompare(a.date));
    const lastLot = mine.find(l => l.size === size) || mine[0];   // 그 사이즈 입고가 없으면 같은 상품 최근 매입가
    const cost = cur.qty ? Math.round(cur.value / cur.qty) : lastLot ? lastLot.cost : 0;
    INV.lots.push({ id: uid(), at: Date.now(), date: today(), itemId, size, qty: diff, cost, partnerId: '', src: 'adjust', confirmed: true, retQty: 0, exQty: 0, events: [], memo: '재고 수량 직접 수정' });
  } else {
    let need = -diff;
    const lots = INV.lots.filter(l => l.itemId === itemId && l.size === size && C.left.get(l.id) > 0).sort((a, b) => b.date.localeCompare(a.date) || b.at - a.at);
    for (const l of lots) { if (!need) break; const take = Math.min(need, C.left.get(l.id)); l.adjQty = (l.adjQty || 0) + take; need -= take; }
  }
  await invSave(); return diff;
}
// 3.7.8/3.7.9: 입고 삭제 — 출고에 쓰였으면 그 출고도 같이 지워요(확인 창에 보여줘요).
//        구매처 주문에서 들어온 입고면 그 주문을 기억해서 다음 동기화 때 다시 안 들어와요.
function lotDelete(id, C, say) {
  const l = INV.lots.find(x => x.id === id); if (!l) return renderInv();
  const used = C.used.get(id) || 0;
  // 3.7.9: 출고에 쓰였어도 지울 수 있어요 — 그 출고도 같이 지워요
  const usedOuts = used > 0 ? INV.outs.filter(o => (o.costs || []).some(c => c.lotId === id)) : [];
  const fromOrder = l.srcKey ? '<p class="small">구매처 주문에서 자동으로 들어온 입고예요. 지우면 다음 동기화 때 다시 들어오지 않아요. 다시 넣으려면 입출고 메뉴에서 직접 입고하면 돼요.</p>' : '';
  const outNote = usedOuts.length ? `<p><b>이 입고를 쓴 출고 ${usedOuts.length}건(${usedOuts.reduce((s2, o) => s2 + o.qty, 0)}개)도 같이 지워져요</b> — ${usedOuts.slice(0, 3).map(o => `${esc(o.date)} ${esc(partnerOf(o.partnerId)?.name || (o.kind === 'pre' ? '보관 신청' : '출고'))}`).join(', ')}${usedOuts.length > 3 ? ' 외' : ''}. 매출 장부에서도 빠져요.</p>` : '';
  return invDialog('입고 삭제', `<p>${esc(itName(itemOf(l.itemId)))} ${esc(l.size)} ×${l.qty} (${esc(l.date)}, ${won(l.cost)}) 입고를 지울까요? 재고에서 빠지고 매입 장부에서도 빠져요.</p>${outNote}${fromOrder}`, async () => {
    if (usedOuts.length) { const del = new Set(usedOuts); INV.outs = INV.outs.filter(o => !del.has(o)); }
    INV.lots = INV.lots.filter(x => x !== l);
    if (l.srcKey) { INV.skipKeys = [...new Set([...(INV.skipKeys || []), l.srcKey])].slice(-5000); }
    await invSave(); IS.msg = '입고를 지웠어요'; renderInv();
  }, '삭제');
}
function itemDetail(it, C, bcAll) {
  const st = itemStock(it, C);
  const shoes = (it.sizes || []).some(s => US_M[s]);
  const sz = (it.sizes || []).map(s => { const x = st.by[s]; const b = (it.barcodes || {})[s] || ''; return `<tr><td class="l"><b>${esc(s)}</b></td>${shoes ? `<td class="l small">${US_M[s] ? `US ${US_M[s][0]} · EU ${US_M[s][1]}` : ''}</td>` : ''}<td><input type="number" class="mini" style="width:64px" min="0" step="1" data-k="stockSet" data-id="${it.id}" data-s="${esc(s)}" value="${x ? x.qty : 0}" title="재고 수량을 직접 고쳐요"></td><td>${x ? won(x.value / x.qty) : '–'}</td><td class="l"><input class="mini bc${b && bcAll[b] > 1 ? ' dup' : ''}" data-k="bc" data-id="${it.id}" data-s="${esc(s)}" value="${esc(b)}" placeholder="바코드"></td></tr>`; }).join('');
  const lots = INV.lots.filter(l => l.itemId === it.id).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
  const outs = INV.outs.filter(o => o.itemId === it.id).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
  return `<div class="det"><div class="det-top">
    <div class="box"><h3>사이즈별 재고 · 바코드</h3><table class="srct"><thead><tr><th class="l">사이즈</th>${shoes ? '<th class="l">변환 (나이키 남성 기준)</th>' : ''}<th>재고</th><th>평균 매입가</th><th class="l">바코드</th></tr></thead><tbody>${sz}</tbody></table><p class="hint">재고 숫자를 고치면 바로 반영돼요 (늘리면 '재고 조정' 입고, 줄이면 가장 최근 입고분에서 빼요 — 매입·매출 장부에는 안 잡혀요). 바코드를 넣으면 입출고에서 스캐너로 바로 찾아요. 빨간 칸은 다른 상품과 겹치는 바코드예요.</p></div>
    <div class="box"><h3>정보</h3><dl class="kv"><dt>품번</dt><dd>${esc(it.code)}</dd><dt>분류</dt><dd>${esc([it.cat, it.sub].filter(Boolean).join(' · ') || '–')}</dd><dt>크림 상품번호</dt><dd>${it.pid ? `<a href="https://kream.co.kr/products/${esc(it.pid)}" target="_blank" rel="noopener">${esc(it.pid)}</a>` : '–'}</dd><dt>메모</dt><dd>${esc(it.memo || '–')}</dd></dl></div></div>
    ${mktBox(it, C)}
    <div class="igrid2"><div class="box"><h3>입고 이력</h3>${(() => { const A = acctSizeLines(INV.lots.filter(l => l.itemId === it.id && lotAcct(l)).map(l => ({ site: String(l.srcKey).split('|')[0], size: l.size, qty: (l.qty || 0) - (l.retQty || 0) }))); return A.length ? `<div class="small" style="margin:0 0 8px"><b>아이디별</b> ${A.map(a => `${esc(a.label)}: ${esc(a.sizes)} (${a.total}개)`).join(' / ')}</div>` : ''; })()}<table class="srct"><thead><tr><th class="l">입고일</th><th class="l">사이즈</th><th>수량</th><th>남음</th><th>매입가</th><th class="l">매입처</th><th></th></tr></thead><tbody>${lots.map(l => `<tr><td class="l">${l.date}</td><td class="l">${esc(l.size)}</td><td>${l.qty}${l.retQty ? ` <span class="small">(반품 ${l.retQty})</span>` : ''}${l.exQty ? ` <span class="small">(교환 ${l.exQty})</span>` : ''}${l.adjQty ? ` <span class="small">(조정 −${l.adjQty})</span>` : ''}</td><td>${Math.max(0, C.left.get(l.id))}</td><td>${won(l.cost)}</td><td class="l">${esc(lotAcct(l) || partnerOf(l.partnerId)?.name || (l.src === 'return' ? '판매 반품' : l.src === 'adjust' ? '재고 조정' : ''))}</td><td><button type="button" class="ghost tiny" data-a="lotDel" data-id="${l.id}"${(C.used.get(l.id) || 0) > 0 ? ' title="출고에 쓰인 입고예요"' : ''}>삭제</button></td></tr>`).join('') || '<tr><td colspan="7" class="small">없음</td></tr>'}</tbody></table></div>
    <div class="box"><h3>출고 이력</h3><table class="srct"><thead><tr><th class="l">출고일</th><th class="l">사이즈</th><th>수량</th><th>판매가</th><th>마진</th><th class="l">매출처</th></tr></thead><tbody>${outs.map(o => { const n = outNums(o); return `<tr><td class="l">${o.date}</td><td class="l">${esc(o.size)}</td><td>${o.qty}${o.retQty ? ` <span class="small">(반품 ${o.retQty})</span>` : ''}</td><td>${o.settled ? won(o.price) : '<span class="pill warn">정산 전</span>'}</td><td class="${n.margin > 0 ? 'pos' : n.margin < 0 ? 'neg' : ''}">${n.margin == null ? '–' : wonS(n.margin)}</td><td class="l">${esc(partnerOf(o.partnerId)?.name || '')}</td></tr>`; }).join('') || '<tr><td colspan="6" class="small">없음</td></tr>'}</tbody></table></div></div></div>`;
}
function itemForm(it) {
  it = it || { code: '', name: '', brand: '', cat: '', sub: '', sizes: [], memo: '', pid: '' };
  const cats = Object.keys(INV.cats);
  return `<div class="dgrid"><label>품번 (모델번호) *<input name="code" required value="${esc(it.code)}" placeholder="예: DD1391-100"${it.id && (INV.lots.some(l => l.itemId === it.id) || INV.outs.some(o => o.itemId === it.id)) ? ' readonly title="입출고 기록이 있어서 품번은 못 바꿔요"' : ''}></label>
    <label>상품명<input name="name" value="${esc(it.name)}" placeholder="예: 덩크 로우 블랙 화이트"></label>
    <label>브랜드<input name="brand" list="invBrands" value="${esc(it.brand)}"></label>
    <label>크림 상품번호<input name="pid" value="${esc(it.pid || '')}" placeholder="kream.co.kr/products/ 뒤 숫자"></label>
    <label>대분류<select name="cat"><option value="">선택 안 함</option>${cats.map(c => opt(c, c, it.cat === c)).join('')}</select></label>
    <label>소분류<select name="sub"><option value="">선택 안 함</option>${cats.flatMap(c => INV.cats[c].map(s => `<option value="${esc(s)}" data-c="${esc(c)}"${it.sub === s ? ' selected' : ''}>${esc(c)} · ${esc(s)}</option>`)).join('')}</select></label>
    <label class="wide">사이즈 (쉼표로 구분, 최소 1개) *<input name="sizes" required value="${esc((it.sizes || []).join(', '))}" placeholder="예: 250, 255, 260 또는 S, M, L"></label>
    <div class="wide row-btns">${Object.keys(SIZE_PRESETS).map(k => `<button type="button" class="ghost tiny" data-preset="${esc(k)}">${esc(k)}</button>`).join('')}</div>
    <label class="wide">메모<input name="memo" value="${esc(it.memo || '')}"></label></div>
    <datalist id="invBrands">${INV.brands.map(b => `<option value="${esc(b)}">`).join('')}</datalist>
    <div class="row-btns"><button type="button" class="ghost tiny" data-kfill>크림에서 상품명 찾기</button><span class="hint" data-kmsg>품번을 넣고 누르면 크림 검색 결과에서 이름·상품번호를 채워요.</span></div>`;
}
function parseSizes(s) { return [...new Set(String(s || '').split(/[,，/\s]+/).map(x => x.trim()).filter(Boolean))]; }
function saveItemFrom(fd, old) {
  const code = String(fd.code || '').trim(); if (!code) return '품번을 넣어 주세요';
  const sizes = parseSizes(fd.sizes); if (!sizes.length) return '사이즈를 1개 이상 넣어 주세요';
  const dup = INV.items.find(x => codeKey(x.code) === codeKey(code) && (!old || x.id !== old.id));
  if (dup) return `같은 품번이 이미 있어요: ${itName(dup)}`;
  if (old) {
    const usedSizes = new Set([...INV.lots.filter(l => l.itemId === old.id).map(l => l.size), ...INV.outs.filter(o => o.itemId === old.id).map(o => o.size)]);
    for (const s of usedSizes) if (!sizes.includes(s)) sizes.push(s);
  }
  const brand = String(fd.brand || '').trim();
  if (brand && !INV.brands.includes(brand)) INV.brands.push(brand);
  const it = old || { id: uid(), barcodes: {}, created: Date.now() };
  Object.assign(it, { code, name: String(fd.name || '').trim(), brand, cat: fd.cat || '', sub: fd.sub || '', sizes, memo: fd.memo || '', pid: String(fd.pid || '').replace(/\D/g, '') });
  if (!old) INV.items.unshift(it);
  return it;
}
function openItemDialog(it, after) {
  invDialog(it ? '상품 수정' : '상품 추가', itemForm(it), async fd => {
    const r = saveItemFrom(fd, it); if (typeof r === 'string') return r;
    await invSave(); IS.msg = `${itName(r)} 저장했어요`; if (after) after(r); renderInv();
  });
  const dlg = $('#invDlg');
  dlg.querySelectorAll('[data-preset]').forEach(b => b.addEventListener('click', () => { dlg.querySelector('[name=sizes]').value = SIZE_PRESETS[b.dataset.preset].join(', '); }));
  const sub = dlg.querySelector('[name=sub]'), cat = dlg.querySelector('[name=cat]');
  sub.addEventListener('change', () => { const o = sub.selectedOptions[0]; if (o && o.dataset.c) cat.value = o.dataset.c; });
  dlg.querySelector('[data-kfill]').addEventListener('click', async () => {
    const code = dlg.querySelector('[name=code]').value.trim(), m = dlg.querySelector('[data-kmsg]');
    if (!code) { m.textContent = '품번부터 넣어 주세요'; return; }
    const local = products.find(p => p.raw && p.raw.info && codeKey(p.raw.info.code).includes(codeKey(code)));
    if (local) { const i = local.raw.info; dlg.querySelector('[name=name]').value = i.name || ''; dlg.querySelector('[name=pid]').value = local.pid; if (i.brand) dlg.querySelector('[name=brand]').value = i.brand; m.textContent = '내 상품에 있는 크림 정보로 채웠어요'; return; }
    if (!HAS_CHROME || !chrome.scripting) { m.textContent = '킥스캔 안에서만 돼요'; return; }
    m.textContent = '크림 검색 중… (작은 창이 열렸다 닫혀요)';
    try {
      const tabId = await srcNav(`https://kream.co.kr/search?keyword=${encodeURIComponent(code)}`);
      await sleep(1500);
      const [r] = await execT({ target: { tabId }, func: kcList, args: [3] });
      const k = ((r && r.result) || [])[0];
      if (!k) m.textContent = '크림에서 못 찾았어요. 직접 넣어 주세요.';
      else { dlg.querySelector('[name=name]').value = k.name || ''; dlg.querySelector('[name=pid]').value = k.pid || ''; if (k.brand) dlg.querySelector('[name=brand]').value = k.brand; m.textContent = `크림 검색 첫 결과로 채웠어요: ${k.name} — 품번이 맞는지 한 번 보세요`; }
    } catch (e) { m.textContent = '검색 실패: ' + e.message; }
    if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  });
}

// ---------- 입출고 ----------
function ioPartners(mode) { return INV.partners.filter(p => p.kind === (mode === 'in' ? 'buy' : 'sell')); }
function ioDefaults() {
  const io = IS.io; if (!io.date) io.date = today();
  const ps = ioPartners(io.mode); if (!ps.some(p => p.id === io.partnerId)) io.partnerId = ps[0] ? ps[0].id : '';
}
function ioSearch(q) {
  q = q.trim().toLowerCase(); if (!q) return [];
  const k = codeKey(q);
  return INV.items.filter(it => codeKey(it.code).includes(k) && k.length >= 2 || `${it.name} ${it.brand}`.toLowerCase().includes(q) || Object.values(it.barcodes || {}).includes(q)).slice(0, 8);
}
function findBarcode(code) { try { IS.io.lastBc = String(code).slice(0, 40); } catch (e) {} for (const it of INV.items) for (const [s, b] of Object.entries(it.barcodes || {})) if (b && b === code) return { it, size: s }; return null; }
function ioAddRow(it, size) {
  const io = IS.io;
  const same = io.rows.find(r => r.itemId === it.id && r.size === size && size);
  if (same && io.multi) { same.qty = (+same.qty || 0) + 1; }
  else {
    const lastCost = INV.lots.filter(l => l.itemId === it.id).sort((a, b) => b.at - a.at)[0];
    io.rows.push({ key: uid(), itemId: it.id, size: size || '', qty: 1, price: io.mode === 'in' && lastCost ? lastCost.cost : '', ship: '', memo: '' });
  }
  saveDraft();
}
function saveDraft() { store.set('invDraft', { mode: IS.io.mode, date: IS.io.date, partnerId: IS.io.partnerId, payId: IS.io.payId, rows: IS.io.rows }); }
function vIO(C) {
  ioDefaults();
  const io = IS.io, M = io.mode;
  const title = { in: '입고', out: '출고', pre: '우선출고', bundle: '묶음출고' }[M];
  const NP = M === 'pre' || M === 'bundle';
  const sug = ioSearch(io.q);
  const boxes = INV.couriers.flatMap(c => Object.entries(c.box).filter(([, v]) => +v).map(([b, v]) => ({ label: `${c.name} ${b}`, v: +v })));
  let total = 0;
  const rows = io.rows.map((r, i) => {
    const it = itemOf(r.itemId); if (!it) return '';
    const have = (C.stock.get(it.id + '|' + r.size) || { qty: 0 }).qty;
    const q = +r.qty || 0; total += (NP ? 0 : num(r.price) * q);
    const short = M !== 'in' && r.size && have < q;
    return `<tr><td>${i + 1}</td><td class="l name"><b>${esc(itName(it))}</b><span class="code">${esc(it.code)}</span></td>
      <td><select data-k="ioRow" data-f="size" data-i="${r.key}"><option value="">사이즈</option>${(it.sizes || []).map(s => opt(s, s + (M !== 'in' ? ` (재고 ${(C.stock.get(it.id + '|' + s) || { qty: 0 }).qty})` : ''), r.size === s)).join('')}</select>${M === 'in' && r.size && have > 0 ? `<div class="small warn-t">이미 ${have}개 보유 중</div>` : ''}</td>
      <td><input type="number" min="1" class="cost-in" data-k="ioRow" data-f="qty" data-i="${r.key}" value="${esc(r.qty)}">${short ? `<div class="small neg">재고 ${have}개</div>` : ''}</td>
      ${NP ? '' : `<td><input inputmode="numeric" class="cost-in" data-k="ioRow" data-f="price" data-i="${r.key}" value="${esc(r.price)}" placeholder="${M === 'in' ? '매입가' : '판매가'}">${M === 'out' && num(r.price) ? `<div class="small">수수료 ${won(partnerFee(partnerOf(io.partnerId), num(r.price)))}</div>` : ''}</td>`}
      ${M === 'in' || M === 'bundle' ? '' : `<td><input inputmode="numeric" class="cost-in" list="invBoxes" data-k="ioRow" data-f="ship" data-i="${r.key}" value="${esc(r.ship)}" placeholder="택배비"></td>`}
      <td><input class="mini" data-k="ioRow" data-f="memo" data-i="${r.key}" value="${esc(r.memo)}" placeholder="메모"></td>
      <td><button type="button" class="x" data-a="ioDel" data-i="${r.key}" aria-label="줄 삭제">×</button></td></tr>`;
  }).join('');
  // 최근 이력
  const a = IS.lg.from || monthStart(), b = IS.lg.to || monthEnd();
  const hist = [
    ...INV.lots.filter(l => inRange(l.date, addDays(today(), -30), '9999') && !['exchange', 'return', 'adjust'].includes(l.src)).map(l => ({ d: l.date, at: l.at, t: '입고', it: itemOf(l.itemId), size: l.size, qty: l.qty, price: l.cost, p: partnerOf(l.partnerId), id: l.id, k: 'lot' })),
    ...INV.outs.filter(o => inRange(o.date, addDays(today(), -30), '9999')).map(o => ({ d: o.date, at: o.at, t: o.kind === 'pre' ? (o.settled ? '우선출고 · 정산됨' : '우선출고') : '출고', it: itemOf(o.itemId), size: o.size, qty: o.qty, price: o.settled ? o.price : null, p: partnerOf(o.partnerId), id: o.id, k: 'out' }))
  ].sort((x, y) => y.d.localeCompare(x.d) || y.at - x.at).slice(0, 60);
  void a; void b;
  const BCP = invView === 'bc';
  if (BCP) { io.mode = 'in'; io.bc = true; }
  return `${BCP ? head('바코드 입고', '바코드를 찍으면 상품이 자동으로 줄에 들어가요. 처음 보는 바코드는 상품에 연결해 두면 다음부터 바로 잡혀요.') + `<div class="bc-hero"><i>${ico('sheet')}</i><div><b>바코드 스캔 중</b><span>${esc(io.lastBc ? '마지막 스캔: ' + io.lastBc : '아래 칸에 커서를 두고 스캐너로 찍으세요 · Esc로 끄기')}</span></div><span class="bc-pulse"></span></div>` : head('입출고', '입고·출고·우선출고(판매가 나중에 정해지는 출고)를 한 화면에서 등록해요. 적던 내용은 다른 메뉴에 갔다 와도 남아요.')}
  ${flash()}
  ${BCP ? '' : `<div class="subtabs">${[['in', '입고'], ['out', '출고'], ['pre', '우선출고'], ['bundle', '묶음출고']].map(([k, t]) => `<button type="button" data-a="ioMode" data-v="${k}" aria-selected="${M === k}">${t}</button>`).join('')}</div>`}
  <div class="panel">
    <div class="grid-set"><label>거래일<input type="date" data-k="io" data-f="date" value="${esc(io.date)}"></label>
      <label>${M === 'in' ? '매입처' : '매출처'}<select data-k="io" data-f="partnerId">${ioPartners(M).map(p => opt(p.id, p.name, p.id === io.partnerId)).join('')}</select></label>
      ${M === 'in' ? `<label>결제수단<select data-k="io" data-f="payId"><option value="">선택 안 함</option>${INV.pays.map(p => opt(p.id, `${p.type} · ${p.name}${p.issuer ? ' (' + p.issuer + ')' : ''}${p.last4 ? ' ' + p.last4 : ''}`, p.id === io.payId)).join('')}</select></label>` : `<div class="hint" style="align-self:end">${M === 'pre' ? '판매가 없이 먼저 내보내요. 나중에 <b>우선출고 정산</b>에서 판매가를 넣어요.' : '판매가를 넣으면 매출처 수수료가 자동으로 빠져요.'}</div>`}</div>
    <div class="ioq"><input id="ioQ" data-k="ioQ" value="${esc(io.q)}" placeholder="${io.bc ? '바코드를 스캔하세요 (끝내려면 Esc)' : '품번 · 상품명 · 바코드로 상품 찾기 (Enter = 첫 번째 결과)'}" autocomplete="off"${io.bc ? ' class="bcmode"' : ''}>
      <button type="button" class="${io.bc ? 'primary' : 'ghost'}" data-a="ioBc">바코드 ${io.bc ? '켜짐' : '꺼짐'}</button>
      <button type="button" class="ghost" data-a="ioMulti" title="복수: 같은 상품을 다시 찍으면 수량 +1 / 단건: 매번 새 줄">${io.multi ? '복수 등록' : '단건 등록'}</button>
      <button type="button" class="ghost" data-a="itemEdit" data-id="" data-then="io">새 상품</button></div>
    ${sug.length && !io.bc ? `<div class="sug">${sug.map(it => `<button type="button" data-a="ioPick" data-id="${it.id}"><b>${esc(it.code)}</b> ${esc(itName(it))}</button>`).join('')}</div>` : ''}
    ${io.msg ? `<p class="hint ${/못|없|부족|주세요|작아서/.test(io.msg) ? 'neg' : 'pos'}">${esc(io.msg)}</p>` : ''}
    <div class="tbl"><table><thead><tr><th>#</th><th class="l">상품</th><th>사이즈</th><th>수량</th>${NP ? '' : `<th>${M === 'in' ? '매입가 (개당)' : '판매가 (개당)'}</th>`}${M === 'in' || M === 'bundle' ? '' : '<th>택배비 (합계)</th>'}<th class="l">메모</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="8" class="empty">위에서 상품을 찾아 넣으세요.</td></tr>`}</tbody></table></div>
    ${M === 'bundle' ? `<div class="io-bundle"><b>${ico('cube')}묶음 금액</b><label>총 판매금액<input inputmode="numeric" data-k="io" data-f="bPrice" value="${esc(io.bPrice || '')}" placeholder="예: 450000"></label><label>총 택배비<input inputmode="numeric" data-k="io" data-f="bShip" value="${esc(io.bShip || '')}" placeholder="예: 4000"></label><span class="hint">여러 상품을 한 번에 팔았을 때 써요. 총 금액을 각 상품의 매입가 비율로 나눠서 출고해요.</span></div>` : ''}
    ${M === 'in' && io.rows.length ? `<div class="io-bulk"><span class="sub">매입가 일괄 적용</span><input inputmode="numeric" class="cost-in" data-k="io" data-f="bulkPrice" value="${esc(io.bulkPrice || '')}" placeholder="매입가"><button type="button" class="kq" data-a="ioBulkPrice" data-v="all">전체</button><button type="button" class="kq" data-a="ioBulkPrice" data-v="empty">빈 칸만</button></div>` : ''}
    <datalist id="invBoxes">${boxes.map(x => `<option value="${x.v}">${esc(x.label)}</option>`).join('')}</datalist>
    <div class="toolbar"><span class="hint" id="ioSum">${io.rows.length}줄 · ${io.rows.reduce((s, r) => s + (+r.qty || 0), 0)}개${NP ? '' : ` · 합계 ${won(total)}`}</span><div class="row-btns"><button type="button" class="ghost" data-a="ioClear">비우기</button>${M === 'in' ? `<input class="mini io-plan" data-k="io" data-f="planName" value="${esc(io.planName || '')}" placeholder="입고예정명 (예: 11월 무신사 세일)"><input class="mini io-plan" data-k="io" data-f="orderNo" value="${esc(io.orderNo || '')}" placeholder="주문번호 (선택)"><button type="button" class="ghost io-planbtn" data-a="ioPlanSave">${ico('cal')}입고예정으로 저장</button>` : ''}<button type="button" class="primary" data-a="ioSave">${title} 등록 완료</button></div></div>
  </div>
  <div class="panel"><h2>최근 30일 입출고</h2>
    <div class="tbl"><table><thead><tr><th class="l">날짜</th><th class="l">구분</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>단가</th><th class="l">거래처</th><th></th></tr></thead><tbody>${hist.map(h => `<tr><td class="l">${h.d}</td><td class="l"><span class="pill ${h.t === '입고' ? 'ok' : h.t === '우선출고' ? 'warn' : 'mute'}">${h.t}</span></td><td class="l">${esc(itName(h.it))}</td><td class="l">${esc(h.size)}</td><td>${h.qty}</td><td>${h.price == null ? '–' : won(h.price)}</td><td class="l">${esc(h.p?.name || '')}</td><td><button type="button" class="ghost tiny" data-a="histDel" data-k="${h.k}" data-id="${h.id}">삭제</button></td></tr>`).join('') || '<tr><td colspan="8" class="empty">최근 30일 기록이 없어요</td></tr>'}</tbody></table></div></div>`;
}
async function ioSave() {
  const io = IS.io, M = io.mode;
  const rows = io.rows.filter(r => itemOf(r.itemId));
  if (!rows.length) { io.msg = '등록할 줄이 없어요'; return renderInv(); }
  for (const [i, r] of rows.entries()) {
    if (!r.size) { io.msg = `${i + 1}번 줄 사이즈를 골라 주세요`; return renderInv(); }
    if (!(+r.qty >= 1)) { io.msg = `${i + 1}번 줄 수량을 넣어 주세요`; return renderInv(); }
    if (M === 'out' && !num(r.price)) { io.msg = `${i + 1}번 줄 판매가가 없어요. 판매가를 모르면 '우선출고'로 등록하세요`; return renderInv(); }
    if (M === 'in' && priceBlank(r.price)) { io.msg = `${i + 1}번 줄 매입가를 넣어 주세요 (무상이면 0)`; return renderInv(); }
  }
  if (!io.partnerId) { io.msg = '거래처를 골라 주세요 (기본정보에서 추가)'; return renderInv(); }
  const p = partnerOf(io.partnerId);
  if (M === 'bundle') {
    const tot = num(io.bPrice), ship = num(io.bShip); if (!tot) { io.msg = '묶음 총 판매금액을 넣어 주세요'; return renderInv(); }
    const C = invCalc(), made = [];
    for (const [i, r] of rows.entries()) { const costs = allocate(r.itemId, r.size, +r.qty, C); if (!costs) { const have = (invCalc().stock.get(r.itemId + '|' + r.size) || { qty: 0 }).qty; io.msg = `${i + 1}번 줄 재고 부족 — ${itName(itemOf(r.itemId))} ${r.size} 재고 ${have}개`; return renderInv(); } made.push({ r, costs, cost: costs.reduce((a, c) => a + c.qty * c.cost, 0) }); }
    const byCost = made.reduce((a, m) => a + m.cost, 0) > 0, base = byCost ? made.reduce((a, m) => a + m.cost, 0) : made.reduce((a, m) => a + +m.r.qty, 0);
    // 상용화 점검: 1원 오차 없애기 — 다른 줄은 개수로 나눠 떨어지게 나누고, 남는 금액은 1개짜리 줄(없으면 마지막 줄)이 받아요.
    //        그 줄도 개수로 안 나눠 떨어지면 1원 비싼 개수만큼 출고를 둘로 나눠서 합계가 총 판매금액과 딱 맞게 해요
    const absorb = (() => { const k = made.map(m => +m.r.qty === 1).lastIndexOf(true); return k >= 0 ? k : made.length - 1; })();
    const shares = made.map((m, i) => { const q = +m.r.qty, w = (byCost ? m.cost : q) / base; return i === absorb ? null : { p: Math.round(tot * w / q) * q, s: Math.round(ship * w) }; });
    shares[absorb] = { p: tot - shares.reduce((a, x) => a + (x ? x.p : 0), 0), s: ship - shares.reduce((a, x) => a + (x ? x.s : 0), 0) };
    if (shares.some(x => x.p < 0 || x.s < 0)) { io.msg = '묶음 총 판매금액이 너무 작아서 나눌 수 없어요'; return renderInv(); }
    const bid = uid(), memo0 = `묶음출고 (${made.length}줄 · 총 ${won(tot)})`; let at = Date.now();
    made.forEach((m, i) => {
      const q = +m.r.qty, { p: share, s: sh } = shares[i], unit = Math.floor(share / q), extra = share - unit * q;   // extra 개는 unit+1 원
      const parts = extra ? [[q - extra, unit, m.costs.slice(0)], [extra, unit + 1, null]] : [[q, unit, m.costs]];
      if (extra) { const [head, tail] = splitCosts(m.costs, extra); parts[0][2] = head; parts[1][2] = tail; }
      parts.forEach(([pq, pu, pc], j) => INV.outs.push({ id: uid(), at: at++, date: io.date, itemId: m.r.itemId, size: m.r.size, qty: pq, price: pu, partnerId: io.partnerId, kind: 'out', settled: true, settleDate: io.date, ship: j ? 0 : sh, fee: partnerFee(p, pu, itemOf(m.r.itemId)), costs: pc, retQty: 0, disc: 0, events: [], confirmed: false, bundleId: bid, memo: memo0 + (m.r.memo ? ' · ' + m.r.memo : '') }));
    });
    const n = rows.reduce((a, r) => a + +r.qty, 0);
    io.rows = []; io.q = ''; io.bPrice = ''; io.bShip = ''; io.msg = `묶음출고 ${rows.length}줄 · ${n}개 (총 ${won(tot)}) 등록했어요`;
    await invSave(); saveDraft(); return renderInv();
  }
  if (M === 'in') {
    for (const r of rows) {
      const it = itemOf(r.itemId); if (!it.sizes.includes(r.size)) it.sizes.push(r.size);
      INV.lots.push({ id: uid(), at: Date.now(), date: io.date, itemId: r.itemId, size: r.size, qty: +r.qty, cost: num(r.price), partnerId: io.partnerId, payId: io.payId, memo: r.memo, src: 'manual', returnDue: addDays(io.date, typeof retDaysOf === 'function' ? retDaysOf(p, itemOf(r.itemId)) : (p.returnDays ?? INV.opt.returnDays)), confirmed: false, retQty: 0, exQty: 0, events: [] });
      if (r.bi && typeof biAttachId === 'function') biAttachId(INV.lots[INV.lots.length - 1], r.bi, false);   // 11/22 E: 소싱 [매입 등록]으로 넣은 줄
    }
  } else {
    const C = invCalc(); const made = [];
    for (const [i, r] of rows.entries()) {
      const costs = allocate(r.itemId, r.size, +r.qty, C);
      if (!costs) { const have = (invCalc().stock.get(r.itemId + '|' + r.size) || { qty: 0 }).qty; io.msg = `${i + 1}번 줄 재고 부족 — ${itName(itemOf(r.itemId))} ${r.size} 재고 ${have}개 (같은 상품 여러 줄이면 합계로 봐요)`; return renderInv(); }
      made.push({ id: uid(), at: Date.now() + i, date: io.date, itemId: r.itemId, size: r.size, qty: +r.qty, price: M === 'out' ? num(r.price) : 0, partnerId: io.partnerId, kind: M, settled: M === 'out', settleDate: M === 'out' ? io.date : '', ship: num(r.ship), fee: M === 'out' ? partnerFee(p, num(r.price)) : '', costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: r.memo });
    }
    INV.outs.push(...made);
  }
  const n = rows.reduce((s, r) => s + +r.qty, 0);
  io.rows = []; io.q = ''; io.msg = `${{ in: '입고', out: '출고', pre: '우선출고' }[M]} ${rows.length}줄 · ${n}개 등록했어요`;
  if (typeof BI !== 'undefined' && BI.dirty) await biSave();
  await invSave(); saveDraft(); renderInv();
}


// ---------- 3.23: 입고예정 관리 — 온라인 주문을 먼저 저장해 두고, 도착한 만큼만 확정 입고 ----------
const planQty = P => P.lines.reduce((a, l) => a + (+l.qty || 0), 0), planGot = P => P.lines.reduce((a, l) => a + (+l.got || 0), 0);
const PLAN_ST = { wait: ['입고예정', 'warn'], partial: ['부분입고', 'acc'], done: ['입고완료', 'ok'], cancel: ['취소', 'mute'] };
async function ioPlanSave() {
  const io = IS.io; const rows = io.rows.filter(r => itemOf(r.itemId));
  if (!rows.length) { io.msg = '입고예정에 넣을 줄이 없어요'; return renderInv(); }
  for (const [i, r] of rows.entries()) { if (!r.size) { io.msg = `${i + 1}번 줄 사이즈를 골라 주세요`; return renderInv(); } if (!(+r.qty >= 1)) { io.msg = `${i + 1}번 줄 수량을 넣어 주세요`; return renderInv(); } if (priceBlank(r.price)) { io.msg = `${i + 1}번 줄 매입가를 넣어 주세요 (무상이면 0)`; return renderInv(); } }
  if (!io.partnerId) { io.msg = '매입처(주문처)를 골라 주세요'; return renderInv(); }
  const name = String(io.planName || '').trim() || `${partnerOf(io.partnerId)?.name || ''} ${io.date} 주문`;
  (INV.plans = INV.plans || []).unshift({ id: uid(), at: Date.now(), date: io.date, name, partnerId: io.partnerId, payId: io.payId, orderNo: String(io.orderNo || '').trim(), status: 'wait', lines: rows.map(r => ({ key: uid(), itemId: r.itemId, size: r.size, qty: +r.qty, got: 0, cost: num(r.price), memo: r.memo || '' })) });
  const n = rows.reduce((s, r) => s + +r.qty, 0);
  io.rows = []; io.q = ''; io.planName = ''; io.orderNo = ''; io.msg = `입고예정 '${name}' ${rows.length}줄 · ${n}개를 저장했어요 — 도착하면 입고예정 관리에서 확정하세요`;
  await invSave(); saveDraft(); renderInv();
}
async function planConfirm(id, all) {
  const P = (INV.plans || []).find(x => x.id === id); if (!P) return;
  const date = (IS.plan && IS.plan.date) || today(), p = partnerOf(P.partnerId); let n = 0;
  for (const l of P.lines) {
    const left = (+l.qty || 0) - (+l.got || 0); if (left <= 0) continue;
    const take = all ? left : Math.max(0, Math.min(left, Math.floor(num(((IS.plan || {}).got || {})[l.key] ?? left))));
    if (!take) continue;
    const it = itemOf(l.itemId); if (!it) continue; if (!it.sizes.includes(l.size)) it.sizes.push(l.size);
    INV.lots.push({ id: uid(), at: Date.now(), date, itemId: l.itemId, size: l.size, qty: take, cost: +l.cost || 0, partnerId: P.partnerId, payId: P.payId || '', memo: `입고예정 '${P.name}'${P.orderNo ? ' · 주문 ' + P.orderNo : ''}${l.memo ? ' · ' + l.memo : ''}`, src: 'plan', planId: P.id, returnDue: addDays(date, typeof retDaysOf === 'function' ? retDaysOf(p, itemOf(l.itemId)) : ((p && p.returnDays) ?? INV.opt.returnDays)), confirmed: false, retQty: 0, exQty: 0, events: [] });
    l.got = (+l.got || 0) + take; n += take;
  }
  if (!n) { IS.msg = '이번에 입고할 수량이 없어요'; return renderInv(); }
  P.status = planGot(P) >= planQty(P) ? 'done' : 'partial';
  if (IS.plan) IS.plan.got = {};
  IS.msg = `'${P.name}' ${n}개를 입고했어요${P.status === 'partial' ? ` — 아직 ${planQty(P) - planGot(P)}개가 안 왔어요` : ' — 입고완료'}`;
  await invSave(); renderInv();
}
function vPlan() {
  const F = IS.plan = IS.plan || { st: 'open', partner: '', q: '', open: '', got: {}, date: '' };
  const L = INV.plans || [];
  const q = F.q.trim().toLowerCase();
  const hit = P => !q || `${P.name} ${P.orderNo} ${partnerOf(P.partnerId)?.name || ''} ${P.lines.map(l => { const it = itemOf(l.itemId); return it ? it.code + ' ' + itName(it) : ''; }).join(' ')}`.toLowerCase().includes(q);
  const rows = L.filter(P => (F.st === 'all' || (F.st === 'open' ? ['wait', 'partial'].includes(P.status) : P.status === F.st)) && (!F.partner || P.partnerId === F.partner) && hit(P));
  const open = L.filter(P => ['wait', 'partial'].includes(P.status));
  const waitQ = open.reduce((a, P) => a + planQty(P) - planGot(P), 0), waitV = open.reduce((a, P) => a + P.lines.reduce((b, l) => b + ((+l.qty || 0) - (+l.got || 0)) * (+l.cost || 0), 0), 0);
  const buys = INV.partners.filter(p => p.kind === 'buy');
  const detail = P => `<tr class="pl-det"><td colspan="9"><div class="pl-box"><div class="tbl"><table><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th>예정</th><th>입고됨</th><th>이번에 입고</th><th>매입가</th><th class="l">메모</th></tr></thead><tbody>${P.lines.map(l => { const it = itemOf(l.itemId), left = (+l.qty || 0) - (+l.got || 0); return `<tr><td class="l name"><b>${esc(itName(it))}</b><span class="code">${esc(it ? it.code : '')}</span></td><td class="l">${esc(l.size)}</td><td>${l.qty}</td><td>${l.got || 0}</td><td>${left > 0 && ['wait', 'partial'].includes(P.status) ? `<input type="number" min="0" max="${left}" class="cost-in" data-k="planGot" data-i="${l.key}" value="${esc((F.got || {})[l.key] ?? left)}">` : '<span class="sub">–</span>'}</td><td>${won(+l.cost)}</td><td class="l small">${esc(l.memo)}</td></tr>`; }).join('')}</tbody></table></div>
    ${['wait', 'partial'].includes(P.status) ? `<div class="row-btns"><label class="small">입고일 <input type="date" data-k="planDate" value="${esc(F.date || today())}"></label><span class="topsp"></span><button type="button" class="ghost" data-a="planCancel" data-id="${P.id}">예정 취소</button><button type="button" class="ghost" data-a="planConfirm" data-id="${P.id}">도착한 수량만 입고</button><button type="button" class="primary" data-a="planAll" data-id="${P.id}">전부 도착 · 입고</button></div>` : `<div class="row-btns"><span class="topsp"></span><button type="button" class="ghost" data-a="planDel" data-id="${P.id}">기록 지우기</button></div>`}</div></td></tr>`;
  const tr = P => { const st = PLAN_ST[P.status] || PLAN_ST.wait, it0 = itemOf((P.lines[0] || {}).itemId); return `<tr class="pl-row" data-a="planOpen" data-id="${P.id}"><td class="l"><b>${esc(P.name)}</b><small class="sub"> ${esc(P.date)}</small></td><td class="l">${esc(partnerOf(P.partnerId)?.name || '–')}</td><td class="l"><span class="pill ${st[1]}">${st[0]}</span></td><td class="l small">${esc(P.orderNo || '–')}</td><td class="l">${esc(itName(it0))}${P.lines.length > 1 ? ` <span class="sub">외 ${P.lines.length - 1}줄</span>` : ''}</td><td>${planQty(P)}</td><td><b>${planGot(P)}</b></td><td><div class="pl-bar"><i style="width:${Math.round(planGot(P) / Math.max(1, planQty(P)) * 100)}%"></i></div></td><td><span class="pl-chev">${F.open === P.id ? '▴' : '▾'}</span></td></tr>${F.open === P.id ? detail(P) : ''}`; };
  return `${head('입고예정 관리', '온라인으로 산 주문을 실제로 받기 전에 저장해 두고, 도착한 상품만 확정 입고해요. 입고예정은 <b>입출고 → 입고</b>에서 상품을 넣고 \'입고예정으로 저장\'을 눌러 만들어요.', `<button type="button" class="primary" data-a="nav" data-v="io">입고예정 만들기</button>`)}
  ${flash()}
  <div class="kgrid">${card('진행 중 예정', open.length + '건', 'acc')}${card('아직 안 온 수량', waitQ + '개', waitQ ? 'warn' : '')}${card('안 온 매입 금액', won(waitV))}${card('입고완료', L.filter(P => P.status === 'done').length + '건', 'pos')}</div>
  <div class="panel kh-bar"><div class="kh-row"><select data-k="planSt">${[['open', '입고예정 + 부분입고'], ['all', '전체'], ['done', '입고완료'], ['cancel', '취소']].map(([v, t]) => opt(v, t, F.st === v)).join('')}</select><select data-k="planPartner"><option value="">전체 주문처</option>${buys.map(p => opt(p.id, p.name, F.partner === p.id)).join('')}</select><label class="dl-search kh-q" style="flex:1;min-width:220px">${ico('search')}<input data-k="planQ" value="${esc(F.q)}" placeholder="입고예정명 · 주문번호 · 상품 · 브랜드 검색" autocomplete="off"></label></div></div>
  ${rows.length ? `<div class="tbl kh-tbl pl-tbl"><table><thead><tr><th class="l">입고예정명</th><th class="l">주문처</th><th class="l">상태</th><th class="l">주문번호</th><th class="l">상품</th><th>예정수량</th><th>확정수량</th><th>진행</th><th></th></tr></thead><tbody>${rows.map(tr).join('')}</tbody></table></div>` : `<div class="panel dl-empty">${ico('cal')}<span>${L.length ? '조건에 맞는 입고예정이 없어요.' : '진행 중인 입고예정이 없어요. 입출고 → 입고에서 상품을 넣고 \'입고예정으로 저장\'을 누르세요.'}</span></div>`}`;
}
// ---------- 엑셀 대량 입고 ----------
const XL_COLS = { code: /품번|모델\s*번호|모델명?코드|스타일\s*코드|style|sku|article|货号/i, name: /상품\s*명|^상품$|제품\s*명|name/i, size: /사이즈|옵션|size|尺码/i, qty: /수량|qty|개수/i, cost: /매입\s*가|단가|매입\s*금액|구매\s*가|가격|cost|price/i, date: /거래\s*일|매입\s*일|구매\s*일|주문\s*일|날짜|date/i, brand: /브랜드|brand/i, memo: /메모|비고|memo/i };
function xlTemplate() {
  xlDownload([
    { name: '입고양식', rows: [['품번', '상품명', '사이즈', '수량', '매입가', '거래일', '브랜드', '메모'], ['DD1391-100', '덩크 로우 블랙 화이트', '270', 1, 129000, today(), '나이키', ''], ['MR530KA', '530 스틸 그레이', '260', 2, 82000, today(), '뉴발란스', '쿠폰 적용']], widths: [16, 30, 8, 6, 10, 12, 12, 20] },
    { name: '작성 가이드', rows: [['항목', '설명'], ['품번 (필수)', '모델번호. 같은 품번은 같은 상품으로 묶여요.'], ['상품명', '처음 등록되는 상품일 때 필요해요. 이미 있는 품번이면 비워도 돼요.'], ['사이즈 (필수)', '250, 270, M, XL 처럼'], ['수량 (필수)', '숫자'], ['매입가', '개당 금액. 비우면 미리보기에서 넣을 수 있어요.'], ['거래일', '2026-11-11 형식. 비우면 오늘'], ['매입처·결제수단', '엑셀에 쓰지 않아요. 올린 뒤 미리보기 화면에서 골라요.'], ['파일 형식', '.xlsx 또는 .csv (옛날 .xls 는 안 돼요)']], widths: [18, 70] }
  ], '킥스캔_입고양식.xlsx');
}
async function xlLoad(file) {
  try { xlBuild(await XL.readFile(file), file.name); } catch (e) { IS.xl = { file: file.name, rows: [], msg: e.message }; }
  renderInv();
}
// 개선판 1-10: 파일 · 붙여넣기 둘 다 여기서 미리보기 줄을 만들어요 (loose: 붙여넣기 — 새 품번은 품번을 이름으로)
function xlBuild(rows, fname, loose) {
  {
    let hi = rows.findIndex(r => r.some(v => XL_COLS.code.test(String(v))) && r.some(v => XL_COLS.size.test(String(v))));
    if (hi < 0) throw new Error('첫 줄에서 "품번"과 "사이즈" 칸을 못 찾았어요. 양식 다운로드로 받은 파일 형식에 맞춰 주세요.');
    const H = rows[hi].map(v => String(v).trim()); const col = {};
    for (const [k, re] of Object.entries(XL_COLS)) col[k] = H.findIndex((h, i) => re.test(h) && !Object.values(col).includes(i));
    const buy = INV.partners.find(p => p.kind === 'buy');
    const out = [];
    for (const r of rows.slice(hi + 1)) {
      const g = k => col[k] >= 0 ? r[col[k]] : '';
      const code = String(g('code') || '').trim(); if (!code) continue;
      const it = INV.items.find(x => codeKey(x.code) === codeKey(code));
      const row = { k: uid(), sel: true, code, name: String(g('name') || '').trim(), brand: String(g('brand') || '').trim(), size: String(g('size') ?? '').trim(), qty: Math.round(num(g('qty'))) || 1, cost: priceBlank(g('cost')) ? '' : num(g('cost')), date: XL.dateOf(g('date')) || today(), memo: String(g('memo') || ''), partnerId: buy ? buy.id : '', payId: '', isNew: !it };
      if (loose && !it && !row.name) row.name = code;
      const rq = String(g('qty') ?? '').replace(/[\s,개]/g, ''), rc = String(g('cost') ?? '').trim();
      if (!row.size) row.err = '사이즈 없음'; else if (!it && !row.name) row.err = '새 상품인데 상품명 없음';
      else if (rq && !/^\d+(\.0+)?$/.test(rq)) row.err = '수량이 숫자가 아니에요'; else if (rq && +rq <= 0) row.err = '수량이 0이에요'; else if (rc && priceBlank(rc)) row.err = '매입가가 숫자가 아니에요'; else if (row.cost !== '' && row.cost < 0) row.err = '매입가가 0보다 작아요';
      out.push(row);
    }
    if (!out.length) throw new Error('읽을 줄이 없어요');
    IS.xl = { file: fname, rows: out, msg: '' };
  }
}
function vExcel(C) {
  const X = IS.xl; C = C || invCalc();
  const buys = INV.partners.filter(p => p.kind === 'buy');
  const rows = X && X.rows.length ? X.rows.map(r => `<tr class="${r.err ? 'err' : r.cost === '' ? 'warn' : ''}"><td><input type="checkbox" data-k="xlRow" data-f="sel" data-i="${r.k}"${r.sel && !r.err ? ' checked' : ''}${r.err ? ' disabled' : ''}></td><td class="l"><b>${esc(r.code)}</b>${r.isNew ? ' <span class="pill warn">새 상품</span>' : ''}<div class="small">${esc(r.brand ? r.brand + ' ' : '')}${esc(r.name)}</div>${r.err ? `<div class="small neg">${esc(r.err)}</div>` : ''}</td><td class="l">${esc(r.size)}${(() => { const it = INV.items.find(x => codeKey(x.code) === codeKey(r.code)), have = it ? (C.stock.get(it.id + '|' + r.size) || { qty: 0 }).qty : 0; return have > 0 ? `<div class="small warn-t">이미 ${have}개 보유 중</div>` : ''; })()}</td><td>${r.qty}</td>
    <td><input inputmode="numeric" class="cost-in" data-k="xlRow" data-f="cost" data-i="${r.k}" value="${r.cost === '' ? '' : r.cost}" placeholder="매입가"></td><td><input type="date" data-k="xlRow" data-f="date" data-i="${r.k}" value="${esc(r.date)}"></td>
    <td><select data-k="xlRow" data-f="partnerId" data-i="${r.k}">${buys.map(p => opt(p.id, p.name, p.id === r.partnerId)).join('')}</select></td>
    <td><select data-k="xlRow" data-f="payId" data-i="${r.k}"><option value="">–</option>${INV.pays.map(p => opt(p.id, p.name, p.id === r.payId)).join('')}</select></td></tr>`).join('') : '';
  const selN = X ? X.rows.filter(r => r.sel && !r.err).length : 0, noCost = X ? X.rows.filter(r => r.sel && !r.err && r.cost === '').length : 0;
  return `${head('엑셀 대량 입고', '엑셀(.xlsx)이나 CSV로 여러 상품을 한 번에 입고해요. 매입처·결제수단은 올린 뒤 여기서 골라요.', `<button type="button" class="ghost" data-a="xlTpl">양식 다운로드</button>`)}
  ${flash()}
  ${typeof finPasteBox === 'function' ? finPasteBox() : ''}
  <label class="drop" data-drop><input type="file" accept=".xlsx,.xlsm,.csv" data-k="xlFile" hidden><b>파일을 끌어다 놓거나 눌러서 고르세요</b><span class="hint">.xlsx · .xlsm · .csv (옛날 .xls 는 엑셀에서 .xlsx 로 다시 저장)</span>${X ? `<span class="small">${esc(X.file)}</span>` : ''}</label>
  ${X && X.msg ? `<p class="iflash neg">${esc(X.msg)}</p>` : ''}
  ${X && X.rows.length ? `<div class="panel"><div class="toolbar"><div class="row-btns"><span class="hint">선택한 줄에 일괄 적용:</span>
      <select data-k="xlBulk" data-f="partnerId"><option value="">매입처</option>${buys.map(p => opt(p.id, p.name)).join('')}</select>
      <select data-k="xlBulk" data-f="payId"><option value="">결제수단</option>${INV.pays.map(p => opt(p.id, p.name)).join('')}</select>
      <input type="date" data-k="xlBulk" data-f="date" title="거래일"></div>
      <div class="row-btns"><button type="button" class="ghost" data-a="xlAll">전체 선택/해제</button><button type="button" class="primary" data-a="xlSave"${selN ? '' : ' disabled'}>선택 ${selN}줄 입고 저장</button></div></div>
    ${noCost ? `<p class="hint neg">매입가가 빈 줄이 ${noCost}개 있어요(노란 줄). 매입가를 넣어 주세요 — 무상으로 받은 거면 0을 넣어요.</p>` : ''}
    <div class="tbl"><table><thead><tr><th></th><th class="l">품번 · 상품</th><th class="l">사이즈</th><th>수량</th><th>매입가 (개당 실결제)</th><th>거래일</th><th>매입처</th><th>결제수단</th></tr></thead><tbody>${rows}</tbody></table></div></div>` : ''}`;
}
async function xlSave() {
  const X = IS.xl; if (!X) return;
  const sel = X.rows.filter(r => r.sel && !r.err); let newItems = 0, n = 0;
  const miss = sel.find(r => r.cost === '' || r.cost == null);
  if (miss) { IS.msg = `${X.rows.indexOf(miss) + 1}번 줄 매입가를 넣어 주세요 (무상이면 0)`; return renderInv(); }
  for (const r of sel) {
    let it = INV.items.find(x => codeKey(x.code) === codeKey(r.code));
    if (!it) { it = { id: uid(), code: r.code, name: r.name, brand: r.brand, cat: '', sub: '', sizes: [], barcodes: {}, memo: '', created: Date.now(), auto: 'order' }; INV.items.unshift(it); newItems++; if (r.brand && !INV.brands.includes(r.brand)) INV.brands.push(r.brand); }
    if (!it.sizes.includes(r.size)) it.sizes.push(r.size);
    const p = partnerOf(r.partnerId);
    INV.lots.push({ id: uid(), at: Date.now() + n, date: r.date, itemId: it.id, size: r.size, qty: r.qty, cost: r.cost, partnerId: r.partnerId, payId: r.payId, memo: r.memo, src: 'excel', returnDue: addDays(r.date, typeof retDaysOf === 'function' ? retDaysOf(p, it) : (p && p.returnDays != null ? p.returnDays : INV.opt.returnDays)), confirmed: false, retQty: 0, exQty: 0, events: [] });
    n += r.qty;
  }
  X.rows = X.rows.filter(r => !(r.sel && !r.err));
  IS.msg = `${sel.length}줄 · ${n}개 입고했어요${newItems ? ` (새 상품 ${newItems}종 등록)` : ''}`;
  await invSave(); renderInv();
}

// ---------- 구매처 주문 입고 (무신사 + 다른 쇼핑몰) ----------
// 주문 내역 화면 주소 (2026-11-11 로그인한 화면에서 확인). 무신사는 전용 읽기, 나머지는 공통 읽기(kcOrders)를 써요.
const ORDER_SITES = [
  { k: 'musinsa', label: '무신사', partner: '무신사', ok: '확인' },
  { k: 'zigzag', label: '지그재그', url: 'https://zigzag.kr/checkout/orders', ok: '확인' },
  { k: 'gmarket', label: 'G마켓', url: 'https://my.gmarket.co.kr/ko/pc/list/all', ok: '확인' },
  { k: '11st', label: '11번가', url: 'https://buy.11st.co.kr/my11st/order/OrderList.tmall', ok: '빈 화면 확인' },
  { k: 'ssg', label: 'SSG · 신세계', partner: 'SSG', url: 'https://pay.ssg.com/myssg/orderInfo.ssg?viewType=Ssg', ok: '빈 화면 확인' },
  { k: 'lotte', label: '롯데ON', url: 'https://www.lotteon.com/p/order/mylotte/orderDeliveryList', ok: '빈 화면 확인' },
  { k: '29cm', label: '29CM', url: 'https://www.29cm.co.kr/order/my-order/list', ok: '빈 화면 확인' },
  { k: 'wconcept', label: 'W컨셉', url: 'https://www.wconcept.co.kr/MyPage/MyOrderList', ok: '빈 화면 확인' },
  { k: 'rexmonde', label: '렉스몬드', url: 'https://www.rexmonde.com/mypage/order_list', ok: '빈 화면 확인' },
  { k: 'nike', label: '나이키', partner: '나이키 공식몰', url: 'https://www.nike.com/kr/orders', ok: '화면만 확인' },
  { k: 'ssf', label: 'SSF샵', url: 'https://www.ssfshop.com/secured/mypage/myPage', ok: '로그인 안 됨' },
  { k: 'abc', label: 'ABC마트 · 그랜드스테이지', partner: 'ABC마트', url: 'https://abcmart.a-rt.com/mypage/claim/claim-order-main', detail: id => `https://abcmart.a-rt.com/product/new?prdtNo=${id}`, ok: '확인' },
  // 3.8.1: 4910 웹 주문내역 (로그인 안 돼 있으면 홈으로 넘어가요 → 로그인 필요로 봐요)
  { k: '4910', label: '4910', url: 'https://4910.kr/order', mustPath: '/order', ok: '처음 주문 읽기 확인 중' }
];
const ORD_SKIP = /취소|반품|환불|교환완료/;
// 3.0.1: 처음엔 실제 주문으로 확인한 곳만 켜 둬요(나머지는 체크하면 같이 봐요). 안 쓰는 곳까지 돌면 동기화가 오래 걸려요.
const ORD_DEFAULT = ['musinsa', 'zigzag', 'gmarket', 'abc'];   // 3.3: 쿠팡은 뺐어요
// 설치 프로그램에서는 쿠팡이 접속 자체를 막아요(Access Denied) — 쿠팡 주문은 킥스캔 확장이나 직접 입력으로
let ordCache = {};   // { site: { at, rows, msg } }
// 3.10.24: 옵션이 아예 없는 가방·모자 같은 상품(예: G마켓 아디다스 미니 백팩)은 사이즈를 'ONE SIZE'로 봐요 (크림도 ONE SIZE). 신발·옷은 그대로(직접 확인).
const ONE_SIZE_RE = /(백팩|가방|토트|숄더|크로스\s*백|힙색|슬링|파우치|지갑|모자|볼캡|캡\b|비니|버킷|머플러|목도리|스카프|벨트|키링|양말|\bbag\b|backpack|tote|cap\b|beanie|wallet)/i;
const ordSize = (opt, name, code) => {
  if (!String(opt || '').trim() && ONE_SIZE_RE.test(String(name || ''))) return 'ONE SIZE';
  let o = String(opt || '').replace(/\s*\d{1,3}\s*개\s*$/, '').replace(/\(\s*[+-]?[\d,]+\s*원\s*\)/g, '').trim();
  if (code && codeKey(o).startsWith(codeKey(code))) o = o.slice(o.toUpperCase().indexOf(String(code).slice(-3).toUpperCase()) + 3).trim();
  const seg = o.split('/').map(x => x.trim()).filter(Boolean).pop() || '';
  const m = seg.match(/\b(\d{3}(?:\.\d)?|[2-4]?X{0,3}[SML]|XS|XXL|FREE|F)\b(\(\d{2,3}\))?/i) || String(name || '').match(/\b(2[2-9]\d|3[0-2]\d)\b/);
  return m ? m[0].toUpperCase() : seg.slice(0, 12);
};
const ordCode = name => {
  const t = String(name || '').toUpperCase();
  const paren = (t.match(/\(([A-Z0-9][A-Z0-9-]{4,})\)/) || [])[1];
  if (paren && /\d/.test(paren) && /[A-Z]/.test(paren)) return paren;
  const ms = typeof msCode === 'function' ? msCode(name) : '';
  if (ms) return ms;
  const c = (t.match(/[A-Z0-9][A-Z0-9-]{4,}/g) || []).filter(x => /\d/.test(x) && /[A-Z]/.test(x) && !/^\d+[A-Z]{1,2}$/.test(x));
  return c.find(x => x.includes('-')) || c[0] || '';
};
function ordRows() {
  const out = [];
  for (const r of records.filter(r => r.musinsaId || /^ms-/.test(r.id))) {
    const status = String(r.memo || '').replace(/^무신사 주문 \S+ · /, '');
    out.push({ site: r.msAcct || 'musinsa', img: r.img || '', key: r.id, date: r.buyDate || '', name: r.name || '', opt: r.size || '', size: String(r.size || '').split('/').pop().trim(), qty: +r.qty || 1, unit: +r.cost || 0, listUnit: r.listCost != null ? +r.listCost : +r.cost || 0, paidOk: !!r.paidOk, needPaid: false, status, orderNo: (String(r.memo || '').match(/주문 (\S+)/) || [])[1] || '', code: r.code || msCode(r.name) || '', fallback: 'MS-' + (r.musinsaId || r.id.split('-')[1]) });
  }
  for (const S of ORDER_SITES) {
    const C = ordCache[S.k]; if (!C) continue;
    const seen = {};
    for (const r of C.rows) {
      const base = [S.k, r.orderNo || r.date, r.name, r.opt, r.price].join('|'); seen[base] = (seen[base] || 0) + 1;
      const code = r.code || ordCode(r.name);
      const q = Math.max(1, r.qty || 1), listUnit = r.price ? Math.round(r.price / q) : 0;
      // 3.10.7: 주문번호 — 목록에 없으면 주문상세에서 읽은 번호, 그것도 없으면 주문상세 주소(주문마다 하나)를 주문 구분용으로 써요
      const pcx = (ordCache.paid || {})[r.detail] || {};
      const ordId = r.orderNo || pcx.orderNo || (r.detail ? 'D:' + String(r.detail).replace(/^https?:\/\/[^/]+/, '').split('#')[0] : '');
      out.push({ ordId, img: r.img || '', site: S.k, key: base + '|' + seen[base], date: r.date, name: r.name, opt: r.opt, size: ordSize(r.opt, r.name, code), qty: r.qty || 1, unit: r.paid ? Math.round(r.paid / q) : listUnit, listUnit, paidOk: !!r.paid, needPaid: !!r.detail && !r.paid, status: r.status, orderNo: r.orderNo, code, fallback: (S.k + '-' + (r.orderNo || r.date.replace(/-/g, ''))).toUpperCase() });
    }
  }
  const done = new Set(INV.lots.map(l => l.srcKey).filter(Boolean));
  const skip = new Set(INV.skipKeys || []);   // 3.7.8: 입고를 지운 주문은 다시 안 들여와요
  const ck = new Set(ordCache.cancelKeys || []);
  out.forEach(x => { x.done = done.has(x.key) || skip.has(x.key); x.deleted = skip.has(x.key); x.cancel = ORD_SKIP.test(x.status) || ck.has(x.key); });
  ordDedupe(out);
  return out;
}
// 3.10.7: 같은 주문이 재고에 두 번 들어오지 않게 막아요 (보관 신청은 재고 수만큼만 하니까 재고가 틀리면 안 돼요)
//  ① 주문번호가 같은 주문이 다른 아이디 칸(예: 지그재그 #2와 #5)에 둘 다 보이면 = 같은 아이디로 두 칸에 로그인한 것 → 한 칸 것만 써요
//  ② 주문 목록의 가격·상품명 표시가 바뀌어 주문 키가 달라져도, (구매처·주문번호·사이즈)로 이미 입고된 수량만큼은 '이미 입고됨'으로 봐요
const ordBase = k => String(k).split('~')[0];
const ordSz = s => String(s || '').trim().toUpperCase().replace(/\s+/g, '');
let ordDupWarn = [];
function ordDedupe(out) {
  ordDupWarn = [];
  const idOf = x => { const o = x.ordId || x.orderNo; return o ? [ordBase(x.site), String(o).trim(), ordSz(x.size)].join('|') : ''; };
  // ① 다른 아이디 칸의 같은 주문
  const owner = new Map();
  for (const x of out) { const id = idOf(x); if (!id) continue; if (!owner.has(id)) owner.set(id, x.site); }
  for (const x of out) {
    const id = idOf(x); if (!id) continue; const o = owner.get(id);
    if (o !== x.site) { if (!x.done) { x.done = true; x.dup = true; } const w = `${siteLabel(o)} · ${siteLabel(x.site)}${x.orderNo ? ` (주문 ${x.orderNo})` : ''}`; if (!ordDupWarn.includes(w)) ordDupWarn.push(w); }
  }
  // ② 이미 입고된 수량 (예전 키로 들어간 입고도 포함)
  const imported = new Map();
  for (const l of INV.lots) {
    if (!l.srcKey || !(l.src === 'order' || l.src === 'musinsa')) continue;
    const no = l.ordId || l.ordNo || (String(l.memo || '').match(/주문 (\S+)/) || [])[1]; if (!no) continue;
    const site = l.src === 'musinsa' ? 'musinsa' : ordBase(String(l.srcKey).split('|')[0]);
    const id = [site, no, ordSz(l.size)].join('|'); imported.set(id, (imported.get(id) || 0) + (+l.qty || 0));
  }
  const doneQty = new Map();
  for (const x of out) { const id = idOf(x); if (!id || !x.done || x.dup || x.deleted) continue; doneQty.set(id, (doneQty.get(id) || 0) + (+x.qty || 1)); }
  const extra = new Map([...imported].map(([id, q]) => [id, q - (doneQty.get(id) || 0)]));
  for (const x of out) {
    const id = idOf(x); if (!id || x.done || x.cancel) continue;
    const e = extra.get(id) || 0; const q = +x.qty || 1;
    if (e >= q) { x.done = true; x.dup = true; extra.set(id, e - q); }
  }
}
// 3.10.15: 어느 아이디 칸에서 들어온 입고인지 (구매처 주문으로 들어온 것만)
const lotAcct = l => l && l.src === 'order' && l.srcKey ? siteLabel(String(l.srcKey).split('|')[0]) : '';
const szSort = (a, b) => { const x = parseFloat(a), y = parseFloat(b); return isFinite(x) && isFinite(y) ? x - y : String(a).localeCompare(String(b)); };
// [{site, size, qty}] → '240×2 · 245×1' 를 아이디별로 묶어요
function acctSizeLines(list) {
  const by = new Map();
  for (const r of list) { const k = r.site; if (!by.has(k)) by.set(k, new Map()); const m = by.get(k); m.set(r.size, (m.get(r.size) || 0) + (+r.qty || 0)); }
  const order = ORDER_SITES.map(S => S.k);
  return [...by].sort((a, b) => order.indexOf(a[0]) - order.indexOf(b[0])).map(([k, m]) => ({ label: siteLabel(k), total: [...m.values()].reduce((s, q) => s + q, 0), sizes: [...m].sort((a, b) => szSort(a[0], b[0])).map(([sz, q]) => `${sz}×${q}`).join(' · ') }));
}
function siteLabel(k) { const S = ORDER_SITES.find(s => s.k === k); if (S) return S.label; const [b, n] = String(k).split('~'); const B = ORDER_SITES.find(s => s.k === b); return B && n ? B.label + ' #' + n : k; }   // 11/23: musinsa~2 → 무신사 #2
function sitePartner(k) {
  const S = ORDER_SITES.find(s => s.k === k) || { label: k };
  const name = S.partner || S.label;
  let p = INV.partners.find(x => x.kind === 'buy' && (x.name === name || x.name === S.label));
  if (!p) { p = { id: 'p-' + k, kind: 'buy', name, biz: '', tax: '과세', returnDays: INV.opt.returnDays }; INV.partners.push(p); }
  return p;
}
// 3.38: 구매처 · 계정마다 진행 (불러오는 중 / 완료 N건 / 실패(이유)) — 지난 동기화 결과도 남겨 둬요
function ordProgPanel() {
  const M = IS.ms, tm = (ordCache.timing || [])[0];
  const P = M.prog || (tm ? Object.fromEntries(Object.entries(tm.sites).map(([k, v]) => [k, { ...v, t: v }])) : null); if (!P) return '';
  const sec = ms => ms ? (ms / 1000).toFixed(ms < 10000 ? 1 : 0) + '초' : '';
  const it = (k, p) => {
    const st = p.st === 'wait' ? '대기' : p.st === 'run' ? (p.why || '불러오는 중…') : p.st === 'ok' ? `완료 ${p.n}건${p.newN ? ` · 새 주문 ${p.newN}건` : ''}` : `실패(${p.why || '이유 모름'})`;
    const tip = p.t ? `로그인 확인 ${sec(p.t.login) || '0초'} · 주문 목록 ${sec(p.t.list) || '0초'} · 주문 상세 ${sec(p.t.detail) || '0초'}${p.opened ? `(${p.opened}건 열람)` : ''} · 입고 저장 ${sec(p.t.save) || '0초'}${p.until || p.newOnly ? ' · 새 주문만 읽음' : ' · 기간 전체 읽음'}` : '';
    const btn = p.st === 'fail' && !M.running ? (/로그인/.test(p.why || '') ? ` <button type="button" class="ghost small" data-a="msLogin" data-v="${esc(k)}">로그인</button>` : ` <button type="button" class="ghost small" data-a="msRetry" data-v="${esc(k)}">다시 시도</button>`) : '';
    return `<span class="chip${p.st === 'fail' ? ' neg' : ''}" title="${esc(tip)}"><b>${esc(siteLabel(k))}</b> ${esc(st)}${p.ms ? ` · ${sec(p.ms)}` : ''}${btn}</span>`;
  };
  return `<div class="panel"><h2>${M.running ? '불러오는 중' : '지난 동기화'}${!M.running && tm ? ` <small class="hint">${esc(new Date(tm.at).toLocaleString('ko-KR'))} · 전체 ${sec(tm.total)}</small>` : ''}</h2><div class="chips">${Object.entries(P).map(([k, p]) => it(k, p)).join('')}</div><p class="hint">구매처 · 계정 칸에 마우스를 올리면 단계별 걸린 시간이 보여요.</p></div>`;
}
function vMs() {
  const M = IS.ms; M.sites = M.sites || new Set((INV.opt.ordSites || ORD_DEFAULT).filter(k => ORDER_SITES.some(S => S.k === k))); M.edit = M.edit || {};
  const all = ordRows();
  const view = all.filter(x => !x.done && (M.showCancel || !x.cancel) && (!M.site || x.site === M.site));
  const siteChips = ORDER_SITES.map(S => { const C = S.k === 'musinsa' ? null : ordCache[S.k]; const n = all.filter(x => x.site === S.k && !x.done && !x.cancel).length; return `<label class="chk chip"><input type="checkbox" data-k="ordSite" data-i="${S.k}"${M.sites.has(S.k) ? ' checked' : ''}> ${esc(S.label)}${n ? ` <b>${n}</b>` : ''}${C && C.msg ? ` <span class="small neg">${esc(C.msg)}</span>` : ''}${C && /로그인/.test(C.msg || '') ? ` <button type="button" class="linkbtn small" data-a="goAcct">로그인하기 ↗</button>` : ''}</label>`; }).join('');
  const val = (x, f) => (M.edit[x.key] || {})[f] ?? x[f];
  return `${head('구매처 주문 입고', '무신사·지그재그·G마켓·11번가·SSG·롯데ON·29CM·W컨셉·렉스몬드·나이키·SSF·ABC마트(그랜드스테이지 포함) 주문 내역을 불러와서 골라 입고해요. 이미 입고한 주문은 빠져요.')}${flash()}
  <div class="panel"><div class="chips">${siteChips}</div>
    <div class="row-btns"><select data-k="msDays">${[[30, '최근 1개월'], [90, '최근 3개월'], [180, '최근 6개월']].map(([v, t]) => opt(v, t, (M.days || 90) === v)).join('')}</select><button type="button" class="primary" data-a="msSync">고른 곳 주문 동기화</button><span class="hint">${M.running ? '' : ordMissHtml()}${esc((M.running || !(M.miss || []).length ? M.msg : String(M.msg || '').replace(/^\S+ \S+ \d+\S+ · /, '')) || '각 사이트에 킥스캔 안에서 로그인돼 있어야(계정 연결 메뉴) 해요. 사이트마다 작은 창이 차례로 열렸다 닫혀요.')}</span></div>
    <p class="hint">사이트마다 화면이 달라서 상품명·옵션·가격을 화면 글자에서 읽어요. 매입가는 주문마다 <b>주문상세</b>를 열어 쿠폰·할인·적립금·카드 즉시할인까지 빠진 <b>실제 결제금액</b>으로 넣어요(한 주문에 상품이 여러 개면 목록 가격 비율로 나눠요). 처음 동기화는 주문 수만큼 시간이 더 걸리고, 한 번 읽은 주문은 기억해요.</p></div>
  ${ordProgPanel()}
  ${ordSumPanel()}
  <div class="panel"><h2>자동 입고</h2>
    <div class="row-btns"><label class="chk"><input type="checkbox" data-k="autoIn"${INV.opt.autoIn ? ' checked' : ''}> 동기화하면 바로 재고에 넣기</label>
      <label>자동 동기화<select data-k="autoHours">${[[0, '끔 (버튼 누를 때만)'], [1, '1시간마다'], [3, '3시간마다'], [6, '6시간마다'], [12, '12시간마다'], [24, '하루에 한 번']].map(([v, t]) => opt(v, t, +INV.opt.autoHours === v)).join('')}</select></label>
      ${INV.opt.lastOrdSync ? `<span class="hint">마지막 동기화 ${new Date(INV.opt.lastOrdSync).toLocaleString('ko-KR')}</span>` : ''}</div>
    <p class="hint">자동으로 넣는 건 <b>품번·사이즈·매입가를 다 읽은 주문</b>만이에요(생활용품처럼 사이즈가 없는 주문은 아래 표에 '확인 필요'로 남아요). 입고한 주문이 나중에 구매처에서 취소·반품되면, 아직 출고 안 한 수량은 재고에서 자동으로 빠져요(장부에 매입반품으로 기록). 자동 동기화는 위에서 체크한 구매처만, 최근 1개월 주문을 봐요. PC와 킥스캔이 켜져 있어야 돌아가요(창을 닫아도 작업 표시줄 트레이에서 계속 돌아요).</p></div>
  <div class="panel"><div class="toolbar"><div class="row-btns"><label>구매처<select data-k="ms" data-f="site"><option value="">전체</option>${ORDER_SITES.map(S => opt(S.k, S.label, M.site === S.k)).join('')}</select></label>
     <label>결제수단<select data-k="ms" data-f="payId"><option value="">선택 안 함</option>${INV.pays.map(p => opt(p.id, p.name, p.id === M.payId)).join('')}</select></label>
     <label>분류 일괄<select data-k="ms" data-f="cat"><option value="">선택 안 함</option>${Object.entries(INV.cats).flatMap(([c, ss]) => [opt(c + '|', c, M.cat === c + '|'), ...ss.map(s => opt(c + '|' + s, `${c} · ${s}`, M.cat === c + '|' + s))]).join('')}</select></label>
     <label class="chk"><input type="checkbox" data-k="ordCancel"${M.showCancel ? ' checked' : ''}> 취소·반품도 보기</label></div>
     <div class="row-btns"><button type="button" class="ghost" data-a="msAll">전체 선택/해제</button><button type="button" class="primary" data-a="msSave">선택 ${view.filter(x => M.sel.has(x.key)).length}건 입고 등록</button></div></div>
   ${view.length ? `<div class="tbl"><table><thead><tr><th></th><th class="l">구매처</th><th class="l">주문일</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th>수량</th><th>매입가 (개당 실결제)</th><th class="l">상태</th></tr></thead><tbody>${view.map(x => `<tr class="${x.cancel ? 'err' : ''}"><td><input type="checkbox" data-k="msSel" data-i="${esc(x.key)}"${M.sel.has(x.key) ? ' checked' : ''}${x.cancel ? ' disabled' : ''}></td><td class="l"><span class="pill mute">${esc(siteLabel(x.site))}</span></td><td class="l">${esc(x.date)}</td><td class="l name"><b>${esc(x.name)}</b><span class="small">${esc(x.opt)}</span></td>
     <td class="l"><input class="mini" data-k="ordEdit" data-f="code" data-i="${esc(x.key)}" value="${esc(val(x, 'code'))}" placeholder="${esc(x.fallback)}"></td><td class="l"><input class="mini" style="width:80px" data-k="ordEdit" data-f="size" data-i="${esc(x.key)}" value="${esc(val(x, 'size'))}"></td><td>${x.qty}</td>
     <td><input class="cost-in" inputmode="numeric" data-k="ordEdit" data-f="unit" data-i="${esc(x.key)}" value="${esc(val(x, 'unit') || '')}">${x.paidOk && x.listUnit && x.listUnit !== x.unit ? `<span class="small" title="주문 목록에 보이던 가격">목록 <s>${won(x.listUnit)}</s></span>` : x.paidOk ? '<span class="small">결제금액 확인</span>' : x.needPaid ? '<span class="small neg">결제금액 확인 전</span>' : ''}</td><td class="l small">${esc(x.status)}</td></tr>`).join('')}</tbody></table></div>
   <p class="hint">품번 칸이 비면 임시코드(구매처-주문번호)로 들어가요. 나중에 상품 · 재고에서 고칠 수 있어요. 매입처는 구매처 이름으로 자동으로 잡혀요(없으면 기본정보에 새로 만들어요).</p>`
   : `<p class="empty">${all.length ? '입고할 주문이 없어요 (모두 입고했거나 취소·반품이에요).' : '아직 불러온 주문이 없어요. 위에서 구매처를 고르고 <b>주문 동기화</b>를 누르세요.'}</p>`}</div>
  ${ordDupWarn.length ? `<div class="panel"><p class="iflash neg"><b>같은 주문이 두 아이디 칸에 같이 보여요</b> — 두 칸에 같은 아이디로 로그인했을 수 있어요. 재고에는 한 번만 넣었어요: ${esc(ordDupWarn.slice(0, 6).join(' / '))}${ordDupWarn.length > 6 ? ` 외 ${ordDupWarn.length - 6}건` : ''}. 계정 연결에서 각 칸의 아이디를 확인해 주세요.</p></div>` : ''}
  <div class="panel"><h2>구매처별 마지막 동기화</h2><p class="hint">${ORDER_SITES.map(S => { const c = S.k === 'musinsa' ? null : ordCache[S.k]; const n = S.k === 'musinsa' ? all.filter(x => x.site === 'musinsa').length : 0; return `${esc(S.label)}: ${c && c.at ? `${esc(new Date(c.at).toLocaleString('ko-KR'))} · ${(c.rows || []).length}건` : n ? `${n}건` : '아직 안 불러왔어요'}`; }).join(' / ')}</p>
    <p class="hint">에이블리는 웹에 주문 화면이 없어서(앱 전용), 페이코는 결제 내역만 있어서 연결하지 않았어요.</p></div>`;
}
function ordSumPanel() {
  const L = INV.opt.lastOrdSum; if (!L || !L.items) return '';
  const blocks = Object.entries(L.items).map(([id, list]) => {
    const it = itemOf(id); const tot = list.reduce((s, r) => s + (+r.qty || 0), 0);
    const rows = acctSizeLines(list).map(a => `<tr><td class="l"><span class="pill mute">${esc(a.label)}</span></td><td class="l">${esc(a.sizes)}</td><td><b>${a.total}</b></td></tr>`).join('');
    return `<div class="box"><h3>${esc(it ? itName(it) : '상품')} <span class="small">${esc(it ? it.code : '')} · 합계 ${tot}개</span></h3><table class="srct"><thead><tr><th class="l">아이디</th><th class="l">사이즈 × 수량</th><th>개수</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }).join('');
  const all = Object.values(L.items).flat().reduce((s, r) => s + (+r.qty || 0), 0);
  return `<div class="panel"><h2>마지막 입고 — 아이디별 사이즈·수량</h2><p class="hint">${new Date(L.at).toLocaleString('ko-KR')} ${L.auto ? '자동 입고' : '입고 등록'} · 전체 ${all}개. 아이디 칸마다 몇 사이즈를 몇 개 불러왔는지예요.</p><div class="igrid2">${blocks}</div></div>`;
}
// 자동 입고 기준: 품번과 사이즈를 읽었고 매입가가 있는 주문만 (생활용품처럼 사이즈가 없는 주문은 '확인 필요'로 남겨요)
const SIZE_OK = /^(\d{2,3}(\.5)?|[2-4]?X{0,3}[SML](\(\d{2,3}\))?|XS|XXL|XXXL|FREE|F|ONE ?SIZE|OS)$/i;
// 관리 시작일(설정 › 사업자, 줍픽 같은 이름) — 그 전 주문은 저절로 입고하지 않아요
const bizStart = () => { try { const c = bizCur(); return (c && c.start) || ''; } catch (e) { return ''; } };
const bizBefore = x => { const st = bizStart(), d = String((x && x.date) || '').replace(/[./]/g, '-').slice(0, 10); return !!(st && /^\d{4}-\d{2}-\d{2}$/.test(d) && d < st); };
const autoOk = x => !!(SIZE_OK.test(String(x.size).trim()) && x.unit > 0 && !x.needPaid && !bizBefore(x));   // 2.6.3: 품번을 못 읽어도 사이즈·실결제금액이 있으면 임시코드로 넣어요(나중에 고칠 수 있어요)   // 2.6.1: 주문상세 결제금액을 못 읽은 건 자동으로 안 넣어요
async function importRows(L, o) {
  o = o || {}; const M = IS.ms;
  if (typeof biLoad === 'function') await biLoad();   // 11/22 E: 소싱 [구매] 기록과 잇기
  const [cat, sub] = (o.cat || '|').split('|'); let n = 0, newItems = 0; const sum = {};
  for (const x of L) {
    const E = (M.edit || {})[x.key] || {};
    const code = String(E.code ?? x.code).trim() || x.fallback;
    let it = INV.items.find(i => codeKey(i.code) === codeKey(code));
    if (!it) { const nm = String(x.name || '').replace(/^\[[^\]]+\]\s*/, ''); const br = (String(x.name).match(/^\[([^\]]+)\]/) || [])[1] || nm.split(' ')[0]; it = { id: uid(), code, name: nm.replace(br, '').trim().replace(/\s*\/\s*[A-Z0-9-]+.*$/i, '').slice(0, 80), brand: br, cat: cat || '', sub: sub || '', sizes: [], barcodes: {}, memo: '', created: Date.now(), auto: 'order' }; INV.items.unshift(it); newItems++; if (br && !INV.brands.includes(br) && br.length < 20) INV.brands.push(br); }
    else if (cat && !it.cat) { it.cat = cat; it.sub = sub; }
    if (x.img && /^https?:/i.test(x.img) && it.imgSrc !== 'order') { it.img = x.img; it.imgSrc = 'order'; }   // 3.38: 구매처 주문의 상품 사진
    const size = String(E.size ?? x.size).trim() || 'FREE'; if (!it.sizes.includes(size)) it.sizes.push(size);
    const p = sitePartner(x.site);
    const date = x.date || today();
    // 11/22 C15: 손으로 먼저 넣은 같은 매입이 있으면 새로 입고하지 않고 결제액만 주문 기준으로 고쳐요
    const mm = typeof biMergeManual === 'function' ? biMergeManual(it, size, x, p, date, num(E.unit ?? x.unit)) : null;
    if (mm) { if (typeof biOnOrderLot === 'function' && !mm.bi) biOnOrderLot(mm, it, x.site, date); n++; (sum[it.id] = sum[it.id] || []).push({ site: x.site, size, qty: +x.qty || 1 }); continue; }
    INV.lots.push({ id: uid(), at: Date.now() + n, date, itemId: it.id, size, qty: +x.qty || 1, cost: num(E.unit ?? x.unit), partnerId: p.id, payId: o.payId || '', memo: `${siteLabel(x.site)} 주문${x.orderNo ? ' ' + x.orderNo : ''}${x.status ? ' · ' + x.status : ''}${o.auto ? ' · 자동 입고' : ''}`, ordNo: x.orderNo || '', ordId: x.ordId || x.orderNo || '', src: x.site === 'musinsa' ? 'musinsa' : 'order', srcKey: x.key, returnDue: addDays(date, typeof retDaysOf === 'function' ? retDaysOf(p, it) : (p.returnDays != null ? p.returnDays : INV.opt.returnDays)), confirmed: false, retQty: 0, exQty: 0, events: [] });
    if (typeof biOnOrderLot === 'function') biOnOrderLot(INV.lots[INV.lots.length - 1], it, x.site, date);
    n++;
    (sum[it.id] = sum[it.id] || []).push({ site: x.site, size, qty: +x.qty || 1 });
  }
  if (typeof BI !== 'undefined' && BI.dirty) await biSave();
  if (n) INV.opt.lastOrdSum = { at: Date.now(), auto: !!o.auto, items: sum };
  await invSave();
  return { n, newItems };
}
// 입고한 뒤에 구매처에서 취소·반품된 주문은 재고에서 빼요(아직 출고 안 한 수량만)
function syncCancels() {
  const C = invCalc(); let n = 0, removed = 0;
  const cancelled = new Set([...ordRows().filter(x => x.cancel).map(x => x.key), ...(ordCache.cancelKeys || [])]);
  const drop = new Set();
  for (const l of INV.lots) {
    if (!l.srcKey || !cancelled.has(l.srcKey)) continue;
    const left = C.left.get(l.id) || 0, autoRet = (l.events || []).filter(e => e.auto === 'cancel').reduce((s, e) => s + (+e.q || 0), 0);
    const other = (l.events || []).some(e => e.auto !== 'cancel') || (l.exQty || 0) > 0 || (C.used.get(l.id) || 0) > 0;
    // 2.6.2: 아무것도 안 나간 취소 주문은 입고 자체를 지워요(재고·장부에서 완전히 빠짐)
    if (!other && left + autoRet === l.qty) { drop.add(l.id); removed += l.qty - autoRet; continue; }
    if (autoRet || !(left > 0)) continue;
    l.retQty = (l.retQty || 0) + left; (l.events = l.events || []).push({ t: '반품', d: today(), q: left, auto: 'cancel' }); n += left;
  }
  if (drop.size) {
    const gone = INV.lots.filter(l => drop.has(l.id));
    INV.lots = INV.lots.filter(l => !drop.has(l.id));
    // 그 주문 때문에 새로 만들어진 상품(다른 입고·출고가 없는 것)도 같이 지워요
    for (const l of gone) {
      const it = INV.items.find(i => i.id === l.itemId); if (!it) continue;
      if (INV.lots.some(x => x.itemId === it.id) || INV.outs.some(o => o.itemId === it.id)) continue;
      if (it.auto === 'order' || (!it.memo && Math.abs((it.created || 0) - (l.at || 0)) < 60000)) INV.items = INV.items.filter(i => i !== it);
    }
  }
  return n + removed;
}
// 2.6.1: 주문상세 화면을 열어 실제 결제금액을 읽고, 같은 주문(같은 상세 주소)의 상품들에 목록 가격 비율로 나눠요.
// 읽은 결과는 ordCache.paid[주소]에 기억(못 읽은 건 하루 뒤 다시). 한 번 동기화에 새로 여는 주문은 최대 40건.
const PAID_MAX = 40;
function paidSplit(g, P) {
  if (!P || !(P.paid > 0)) return false;
  const sum = g.reduce((s, x) => s + (+x.price || 0), 0); if (!sum) return false;
  const ratio = P.paid / sum;
  if (ratio < 0.15 || ratio > 1.6) { g.forEach(x => { x.paid = 0; x.paidWarn = `상세 ${P.paid}원 ↔ 목록 합계 ${sum}원이 너무 달라요`; }); return false; }
  let left = P.paid;
  g.forEach((x, i) => { const v = i === g.length - 1 ? left : Math.round((+x.price || 0) * ratio); x.paid = v; left -= v; x.paidFrom = P.label || ''; x.points = P.points || 0; });
  return true;
}
async function readPaid(url, slot) {
  const pc = (ordCache.paid = ordCache.paid || {});
  const c = pc[url];
  if (c && (c.paid > 0 || Date.now() - c.at < 864e5)) return c;
  const t2 = await srcNav(url, slot);
  const [r] = await execT({ target: { tabId: t2 }, func: kcOrderPaid }, 40000);
  const v = r && r.result;
  pc[url] = v && v.paid > 0 ? { paid: v.paid, goods: v.goods, points: v.points || 0, label: v.label, orderNo: v.orderNo || '', at: Date.now() } : { paid: 0, at: Date.now(), login: !!(v && v.loginNeeded) };
  return pc[url];
}
async function ordPaid(S, rows, M, po) {
  po = po || {};
  const groups = {}; rows.forEach(x => { if (x.detail) (groups[x.detail] = groups[x.detail] || []).push(x); });
  const pc = (ordCache.paid = ordCache.paid || {});
  let opened = 0, left = 0, i = 0; const urls = Object.keys(groups);
  for (const u of urls) {
    i++;
    const g = groups[u];
    if (g.every(x => ORD_SKIP.test(x.status))) continue;
    // 3.38: 이미 입고한 주문 · 목록에 결제금액이 보이는 주문 · 이번에 새로 읽는 날짜보다 오래된 주문은 주문상세를 안 열어요
    if (g.every(x => x.listPaid)) { g.forEach(x => { x.paid = +x.price || 0; x.paidFrom = '주문 목록 결제금액'; }); continue; }
    if ((po.done && g.every(x => po.done.has(ordRowBase(S.k, x)))) || (po.until && g.every(x => x.date && x.date < po.until))) { if (pc[u] && pc[u].paid > 0) paidSplit(g, pc[u]); continue; }   // 읽어 둔 결제금액만 다시 붙여요
    const cached = pc[u] && (pc[u].paid > 0 || Date.now() - pc[u].at < 864e5);
    if (!cached && opened >= PAID_MAX) { left++; continue; }
    if (!cached) { opened++; if (M) { M.msg = `${S.label} 주문상세에서 결제금액 읽는 중… (${i}/${urls.length})`; if (typeof jobSay === 'function') jobSay(M.msg); } }
    try { paidSplit(g, await readPaid(u, po.slot)); } catch (e) {}
  }
  return { opened, left };
}
// 3.10.14: 예전에 수량을 1개로 잘못 읽어 들어간 입고(지그재그 '(34,000원)2개')를 주문 수량에 맞춰 고쳐요.
// 낸 돈(매입가 × 수량 합계)은 그대로 두고 개당 매입가만 나눠요. 한 번 고친 입고는 다시 안 건드려요.
function ordFixQty() {
  const by = new Map(ordRows().map(x => [x.key, x])); let n = 0;
  for (const l of INV.lots) {
    if (!l.srcKey || l.src !== 'order' || l.qtyFixed) continue;
    const x = by.get(l.srcKey); if (!x || x.cancel) continue;
    const q = +x.qty || 1, old = +l.qty || 1; if (!(q > old)) continue;
    const tot = num(l.cost) * old;
    l.qty = q; l.cost = x.paidOk && x.unit > 0 ? x.unit : Math.round(tot / q); l.qtyFixed = true;
    l.memo = String(l.memo || '') + ` · 수량 ${old}→${q}개로 고침`; n += q - old;
  }
  return n;
}
// 이미 입고한 주문인데 매입가가 목록 가격 그대로면(직접 고치지 않았으면) 실결제금액으로 바꿔요
function ordFixLots() {
  const by = new Map(ordRows().filter(x => x.paidOk).map(x => [x.key, x])); let n = 0;
  for (const l of INV.lots) {
    if (!l.srcKey || !(l.src === 'order' || l.src === 'musinsa')) continue;
    const x = by.get(l.srcKey); if (!x || !x.unit || l.cost === x.unit || l.paidFixed) continue;
    if (x.listUnit && Math.round(l.cost) !== Math.round(x.listUnit)) continue;   // 직접 고친 매입가는 그대로
    l.listCost = l.cost; l.cost = x.unit; l.paidFixed = true; l.memo = String(l.memo || '') + ' · 실결제금액 반영'; n++;
  }
  return n;
}
// 3.38: 주문 불러오기 빠르게
//  · 새 주문만: 구매처 · 계정마다 마지막으로 불러온 때(INV.opt.ordLast)를 기억해서 그 3일 전까지만 읽어요. 그보다 오래된 건 저장해 둔 목록 그대로.
//    (취소 · 반품 상태를 놓치지 않게 7일에 한 번은 고른 기간 전체를 읽어요 · 기간을 바꾸면 그 기간 전체)
//  · 동시에: 무신사는 한 줄, 나머지는 창 3개로 같이 (같은 구매처는 2개까지)
//  · 가볍게: 이미 입고한 주문 · 목록에 결제금액이 있는 주문 · 오래된 주문은 주문상세를 안 열어요
//  · 진행: 구매처 · 계정마다 불러오는 중 / 완료 N건 / 실패(이유) · 끝난 곳부터 바로 자동 입고
//  · 시간: 단계별(로그인 확인 · 주문 목록 · 주문 상세 · 입고 저장) 걸린 시간을 ordCache.timing 에 남겨요
const ORD_FULL_EVERY = 7 * 864e5, ORD_BACK = 3 * 864e5, ORD_LANES = 4, ORD_PER_BASE = 3;
const ordLock = () => { let p = Promise.resolve(); return fn => { const r = p.then(fn, fn); p = r.catch(() => {}); return r; }; };
const ordDay = t => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const ordRowBase = (k, r) => [k, r.orderNo || r.date, r.name, r.opt, r.price].join('|');
function ordDoneBases() {
  const s = new Set();
  for (const l of INV.lots) if (l.srcKey) s.add(String(l.srcKey).replace(/\|\d+$/, ''));
  for (const k of INV.skipKeys || []) s.add(String(k).replace(/\|\d+$/, ''));
  return s;
}
let ordPaintT = 0;
function ordPaintSoon(o) { if (o.quiet || ordPaintT) return; ordPaintT = setTimeout(() => { ordPaintT = 0; if (invView === 'ms' && typeof curMode !== 'undefined' && curMode === 'inv') renderInv(); }, 350); }
// 11/23: 동기화 실패 이유를 한국어로 · 한 번 더 해 볼 만한 오류인지
const ORD_TRANSIENT = /reply was never sent|message port closed|Receiving end does not exist|Target closed|No tab with id|No window with id|context invalidated|Frame .*(removed|detached)|timed? ?out|ERR_|net::|Failed to fetch|Cannot access/i;
function ordWhyKo(m) {
  m = String(m || '').replace(/^\S+:\s*(?=Error invoking)/, '').replace(/^Error invoking remote method '[^']*':\s*/, '').replace(/^Error:\s*/, '').trim();
  if (/reply was never sent|message port closed|Receiving end does not exist|Target closed|No tab with id|No window with id|context invalidated|Frame .*(removed|detached)/i.test(m)) return '작업 창이 중간에 닫히거나 새로 고쳐져서 응답을 못 받았어요';
  if (/timed? ?out/i.test(m)) return '사이트가 너무 늦게 열려서 기다리다 멈췄어요';
  if (/ERR_|net::|Failed to fetch/i.test(m)) return '인터넷 연결이나 사이트 접속이 잠깐 끊겼어요';
  if (/Cannot access/i.test(m)) return '사이트 화면을 읽을 수 없었어요(다른 주소로 넘어감)';
  return /[가-힣]/.test(m) ? m.replace(/^[^:]{0,8}:\s*/, '').slice(0, 60) : (m ? '알 수 없는 오류 (' + m.slice(0, 40) + ')' : '이유 모름');
}
// 11/23: 동기화가 끝났을 때 빠진 구매처 (로그인 필요 · 못 읽음 · 실패) — 결과 줄 맨 앞에 빨갛게
function ordMissHtml() {
  const L = IS.ms.miss || []; if (!L.length) return '';
  return `<b class="neg ord-miss">⚠ 로그인 필요 · 못 읽음으로 빠진 구매처 ${L.length}곳: ${esc(L.map(x => `${x.label}(${x.why})`).join(', '))}</b> · `;
}
async function ordSync(o) {
  o = o || {};
  const M = IS.ms; M.sites = M.sites || new Set((INV.opt.ordSites || ORD_DEFAULT).filter(k => ORDER_SITES.some(S => S.k === k)));
  const sites = o.only ? ORDER_SITES.filter(S => o.only.includes(S.k)) : ORDER_SITES.filter(S => M.sites.has(S.k)), days = M.days || (o.quiet ? INV.opt.ordDays || 30 : 90);
  const from = addDays(today(), -days), T0 = Date.now();
  const last = (INV.opt.ordLast = INV.opt.ordLast || {}), full = (INV.opt.ordFull = INV.opt.ordFull || {});
  const forceFull = !!(o.full || M.full); M.full = false;
  // 고른 기간 안에서 이번에 읽을 날짜(until): 처음 · 7일 지남 · 기간 바꿈이면 기간 전체
  const untilOf = k => (forceFull || !last[k] || !full[k] || T0 - full[k] > ORD_FULL_EVERY) ? '' : (d => d > from ? d : '')(ordDay(last[k] - ORD_BACK));
  M.prog = o.only && M.prog ? M.prog : {}; M.miss = []; for (const S of sites) M.prog[S.k] = { st: 'wait', n: 0, newN: 0, why: '', ms: 0, until: untilOf(S.k), t: { login: 0, list: 0, detail: 0, save: 0 } };
  M.running = true; M.msg = '로그인 상태 확인 중…'; if (typeof jobSay === 'function') jobSay(M.msg); ordPaintSoon(o);
  const say = t => { M.msg = t; if (typeof jobSay === 'function') jobSay(t); ordPaintSoon(o); };
  // ① 로그인 확인 — 여러 곳을 동시에 (풀린 곳은 저장한 계정으로 다시 로그인)
  const tL = Date.now();
  if (typeof acctFast === 'function' && acctFast() && typeof acctCheck === 'function') {
    const ks = sites.map(S => S.k).filter(k => acctOf(k) && acctOf(k).check);
    const st = await Promise.all(ks.map(k => { const t = Date.now(); return acctCheck(k).catch(() => null).finally(() => { if (M.prog[k]) M.prog[k].t.login += Date.now() - t; }); }));
    for (let i = 0; i < ks.length; i++) {
      if (!(st[i] && st[i].needLogin)) continue;
      let ok = false;
      if (acctCanAuto(ks[i])) { const t = Date.now(); say(`${acctOf(ks[i]).label} 로그인이 풀려서 다시 로그인하는 중…`); try { ok = !!(await acctEnsure(ks[i], true)); } catch (e) {} M.prog[ks[i]].t.login += Date.now() - t; }
      if (!ok) M.prog[ks[i]].noLogin = true;   // 3.38: 로그인이 풀렸고 다시 로그인도 못 하면 주문 화면을 열지 않고 '로그인 필요'로 넘어가요
    }
  }
  const loginMs = Date.now() - tL;
  // ② 구매처 · 계정마다 읽기
  const doneB = ordDoneBases(), importQ = ordLock(), auto = { n: 0, newItems: 0, sum: {} };
  const autoIn = async S => {   // 끝난 곳부터 바로 입고 (입고는 한 번에 하나씩)
    if (!(INV.opt.autoIn || o.auto)) return;
    await importQ(async () => {
      const ok = ordRows().filter(x => x.site === S.k && !x.done && !x.cancel && autoOk(x)); if (!ok.length) return;
      const r = await importRows(ok, { payId: M.payId, cat: M.cat, auto: true }); auto.n += r.n; auto.newItems += r.newItems;
      const ls = INV.opt.lastOrdSum; if (ls && ls.items) for (const [id, a] of Object.entries(ls.items)) (auto.sum[id] = auto.sum[id] || []).push(...a);
    });
  };
  const runSite = async (S, slot, again) => {
    const P = M.prog[S.k], t0 = Date.now(), lap = (k, t) => { P.t[k] += Date.now() - t; };
    P.st = 'run'; ordPaintSoon(o);
    slot.want = S.part || '';
    if (P.noLogin) { P.st = 'fail'; P.why = '로그인 필요'; ordCache[S.k] = { ...(ordCache[S.k] || { rows: [] }), at: Date.now(), msg: '로그인 필요' }; P.ms = Date.now() - t0; ordPaintSoon(o); return; }
    try {
      const readSite = async () => {
        const t = Date.now();
        let tabId = await srcNav(S.url, slot);
        try {
          if (S.mustPath) { const tb = await chrome.tabs.get(tabId).catch(() => null); try { if (tb && !new URL(tb.url).pathname.startsWith(S.mustPath)) return { rows: [], loginNeeded: true }; } catch (e) {} }
          // 2.6.1: '주문상세' 주소를 먼저 표시해 둬요 (지그재그처럼 누르면 새 창이 뜨는 곳은 새 창을 막고 주소만 받아요)
          try { const [tg] = await execT({ target: { tabId }, func: kcTagDetails, args: [S.dtpl || '', 4], world: 'MAIN' }, 30000); if (tg && tg.result && tg.result.moved) tabId = await srcNav(S.url, slot); } catch (e) {}
          let r = null; try { [r] = await execT({ target: { tabId }, func: kcOrders, args: [{ scroll: P.until ? 3 : 6, until: P.until }] }, 60000); } catch (e) { r = { err: e }; }
          const out = r && r.result;
          // 11/23: 29CM 처럼 늦게 로그인 화면(다른 주소)으로 넘어가면 결과가 없거나 비어요 → 탭 주소로 로그인 화면인지 봐요
          if (!out || !(out.rows || []).length) { const tb = await chrome.tabs.get(tabId).catch(() => null); if (tb && /\/\/(auth|accounts?|login|nid|member)\.|\/login|signin|\/auth\//i.test(tb.url || '')) return { rows: [], loginNeeded: true }; }
          if (r && r.err) throw r.err;
          return out;
        } finally { lap('list', t); }
      };
      let res = await readSite();
      if (res && res.loginNeeded && !(res.rows || []).length && typeof acctEnsure === 'function' && acctCanAuto(S.k)) {
        const t = Date.now(); P.why = '로그인 다시 하는 중'; ordPaintSoon(o);
        const ok = await acctEnsure(S.k, true).catch(() => false); lap('login', t); P.why = '';
        if (ok) res = await readSite();
      }
      if (res && typeof acctSetState === 'function') await acctSetState(S.k, res.loginNeeded && !(res.rows || []).length ? 'off' : 'on');
      if (!res) throw new Error('못 읽었어요');
      const fresh = (res.rows || []).filter(x => !x.date || x.date >= from);
      const td = Date.now();
      // 주문 목록에 품번이 없는 곳(ABC마트 등)은 상품 화면을 열어 스타일코드를 읽어요 (한 번 읽은 건 기억 · 이미 입고한 주문은 안 열어요)
      if (S.detail) {
        const map = (ordCache.codes = ordCache.codes || {});
        for (const x of fresh.filter(x => !ordCode(x.name) && !doneB.has(ordRowBase(S.k, x))).slice(0, 15)) {
          const id = (String(x.url).match(/goProductDetail\('(\d+)'/) || String(x.url).match(/prdtNo=(\d+)/) || [])[1]; if (!id) continue;
          if (!map[S.k + id]) { try { const t2 = await srcNav(S.detail(id), slot); const [c] = await execT({ target: { tabId: t2 }, func: kcArtCode }, 30000); map[S.k + id] = (c && c.result && c.result.code) || '-'; } catch (e) {} }
          if (map[S.k + id] && map[S.k + id] !== '-') x.code = map[S.k + id];
        }
      }
      const pd = await ordPaid(S, fresh, M, { slot, done: doneB, until: P.until });
      lap('detail', td);
      const ts = Date.now();
      // 새 주문만 읽었을 때: 저장해 둔 목록 중 이번 화면에 없던 주문만 이어 붙여요 (같은 주문은 하나씩 맞대어 빼요 — 두 번 입고되지 않게)
      const fc = {}; fresh.forEach(x => { const b = ordRowBase(S.k, x); fc[b] = (fc[b] || 0) + 1; });
      const oc = {}; const old = P.until ? ((ordCache[S.k] || {}).rows || []).filter(x => { if (x.date && x.date < from) return false; const b = ordRowBase(S.k, x); oc[b] = (oc[b] || 0) + 1; return oc[b] > (fc[b] || 0); }) : [];
      const rows = fresh.concat(old);
      const login = res.loginNeeded && !fresh.length;
      ordCache[S.k] = { at: Date.now(), rows, msg: login ? '로그인 필요' : res.empty ? '' : !rows.length ? '못 읽음' : pd.left ? `결제금액 ${pd.left}건 남음(다음 동기화 때 이어서)` : '' };
      await store.set('ordCache', ordCache);
      lap('save', ts);
      if (!login) { last[S.k] = Date.now(); if (!P.until) full[S.k] = Date.now(); }
      P.n = rows.length; P.newN = fresh.filter(x => !doneB.has(ordRowBase(S.k, x)) && !ORD_SKIP.test(x.status || '')).length; P.opened = pd.opened;
      const unread = !login && !res.empty && !rows.length;   // 11/23: 주문을 하나도 못 읽었으면 '완료 0건'이 아니라 '못 읽음'
      P.st = login || unread ? 'fail' : 'ok'; P.why = login ? '로그인 필요' : unread ? '못 읽음' : '';
      const ta = Date.now(); await autoIn(S); lap('save', ta);
    } catch (e) {
      ordCache[S.k] = { at: Date.now(), rows: (ordCache[S.k] || {}).rows || [], msg: '실패: ' + e.message };
      try { await store.set('ordCache', ordCache); } catch (e2) {}
      if (!again && ORD_TRANSIENT.test(String(e && e.message || e))) { P.why = '한 번 더 시도하는 중'; ordPaintSoon(o); await sleep(1500); return runSite(S, slot, true); }   // 11/23: 일시 오류면 한 번 더
      P.st = 'fail'; P.why = ordWhyKo(e && e.message || e);
    }
    P.ms = Date.now() - t0; ordPaintSoon(o);
  };
  const runMs = async S => {   // 무신사: 계정마다 차례로 (작업 창 하나)
    const P = M.prog[S.k], t0 = Date.now(); P.st = 'run'; ordPaintSoon(o);
    if (P.noLogin) { P.st = 'fail'; P.why = '로그인 필요'; P.ms = 0; ordPaintSoon(o); return; }
    try {
      navPart = S.part || '';
      const msDays = P.until ? Math.max(7, Math.ceil((Date.now() - new Date(P.until).getTime()) / 864e5) + 1) : days;
      await importMusinsaOrders(msDays, S.k, { T: P.t, newOnly: !!P.until });
      { const m1 = typeof lastMsMsg !== 'undefined' ? lastMsMsg : ''; if (/^\S+:\s/.test(m1) && !/로그인/.test(m1)) { P.why = '한 번 더 시도하는 중'; ordPaintSoon(o); if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; } await sleep(1500); navPart = S.part || ''; await importMusinsaOrders(msDays, S.k, { T: P.t, newOnly: !!P.until }); } }   // 11/23
      if (/로그인/.test((typeof lastMsMsg !== 'undefined' ? lastMsMsg : '')) && typeof acctEnsure === 'function' && acctCanAuto(S.k)) {
        const t = Date.now(); P.why = '로그인 다시 하는 중'; ordPaintSoon(o);
        const ok = await acctEnsure(S.k, true).catch(() => false); P.t.login += Date.now() - t; P.why = '';
        if (ok) { navPart = S.part || ''; await importMusinsaOrders(msDays, S.k, { T: P.t, newOnly: !!P.until }); }
      }
      const m = typeof lastMsMsg !== 'undefined' ? lastMsMsg : '', bad = /로그인|멈췄어요/.test(m);
      if (typeof acctSetState === 'function') await acctSetState(S.k, /로그인/.test(m) ? 'off' : 'on');
      if (!bad) { last[S.k] = Date.now(); if (!P.until) full[S.k] = Date.now(); }
      P.n = +((m.match(/주문 (\d+)건/) || [])[1] || 0); P.newN = +((m.match(/새로 (\d+)개/) || [])[1] || 0);
      P.st = bad ? 'fail' : 'ok'; P.why = bad ? (/로그인/.test(m) ? '로그인 필요' : ordWhyKo(m)) : '';
      const ta = Date.now(); await autoIn(S); P.t.save += Date.now() - ta;
    } catch (e) { P.st = 'fail'; P.why = ordWhyKo(e && e.message || e); }
    finally { navPart = ''; }
    P.ms = Date.now() - t0; ordPaintSoon(o);
  };
  const msSites = sites.filter(S => ordBase(S.k) === 'musinsa'), pool = sites.filter(S => ordBase(S.k) !== 'musinsa');
  const slots = [], cnt = {};
  const lane = async w => {
    const slot = slots[w] = { winId: null, tabId: null, part: '', want: '' };
    for (;;) {
      const i = pool.findIndex(S => (cnt[ordBase(S.k)] || 0) < ORD_PER_BASE);
      if (i < 0) { if (!pool.length) return; await sleep(200); continue; }
      const S = pool.splice(i, 1)[0], b = ordBase(S.k); cnt[b] = (cnt[b] || 0) + 1;
      say(`주문 읽는 중… ${sites.filter(x => M.prog[x.k].st === 'run').map(x => x.label).join(' · ')}`);
      try { await runSite(S, slot); } finally { cnt[b]--; }
    }
  };
  try {
    await Promise.all([(async () => { for (const S of msSites) await runMs(S); })(), ...Array.from({ length: Math.min(ORD_LANES, pool.length) }, (_, w) => lane(w))]);
  } finally {
    navPart = '';
    for (const W of slots) if (W && W.winId) { try { await chrome.windows.remove(W.winId); } catch (e) {} }
    if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  }
  // ③ 마무리: 수량 · 입고 고치기 · 취소 반영 · 남은 자동 입고
  const tF = Date.now();
  const qfix = ordFixQty();
  const fixed = ordFixLots();
  const back = syncCancels();
  let rows = ordRows().filter(x => !x.done && !x.cancel);
  if (INV.opt.autoIn || o.auto) { const ok = rows.filter(autoOk); if (ok.length) { const r = await importRows(ok, { payId: M.payId, cat: M.cat, auto: true }); auto.n += r.n; auto.newItems += r.newItems; const ls = INV.opt.lastOrdSum; if (ls && ls.items) for (const [id, a] of Object.entries(ls.items)) (auto.sum[id] = auto.sum[id] || []).push(...a); } rows = ordRows().filter(x => !x.done && !x.cancel); }
  if (auto.n) INV.opt.lastOrdSum = { at: Date.now(), auto: true, items: auto.sum };
  rows.forEach(x => M.sel.add(x.key));
  const lost = typeof acctState !== 'undefined' ? sites.filter(S => acctState[S.k] && acctState[S.k].st === 'off').map(S => S.label) : [];
  const total = Date.now() - T0;
  // 걸린 시간 기록 (최근 20번)
  const tm = { at: T0, total, login: loginMs, finish: Date.now() - tF, sites: Object.fromEntries(sites.map(S => { const P = M.prog[S.k]; return [S.k, { st: P.st, ms: P.ms, newOnly: !!P.until, n: P.n, newN: P.newN, opened: P.opened || 0, ...P.t, why: P.why }]; })) };
  ordCache.timing = [tm, ...(ordCache.timing || [])].slice(0, 20); await store.set('ordCache', ordCache);
  M.running = false;
  // 11/23: 빠진 곳 (실패 · 로그인 풀림) — 결과 줄 맨 앞 빨간 글씨
  M.miss = sites.filter(S => M.prog[S.k].st === 'fail' || lost.includes(S.label)).map(S => ({ k: S.k, label: S.label, why: M.prog[S.k].st === 'fail' ? (M.prog[S.k].why || '실패') : '로그인 필요' }));
  M.msg = `${M.miss.length ? `빠진 구매처 ${M.miss.length}곳 · ` : ''}${lost.length && !M.miss.length ? `⚠ 로그인 필요: ${lost.join(', ')} (계정 연결에서 '직접 로그인' 한 번 해 주세요) · ` : ''}동기화 끝(${Math.round(total / 1000)}초) — ${auto.n ? `자동 입고 ${auto.n}건${auto.newItems ? `(새 상품 ${auto.newItems}종)` : ''}` : '새로 입고한 주문 없음'}${back ? ` · 취소·반품 ${back}개를 재고에서 뺐어요` : ''}${qfix ? ` · 수량 ${qfix}건 고침` : ''}${rows.length ? ` · 확인할 주문 ${rows.length}건` : ''}`;
  INV.opt.lastOrdSync = Date.now(); await invSave();
  if (auto.newItems && typeof invImgFill === 'function') setTimeout(() => invImgFill(), 500);
  if (!o.quiet) renderInv();
  return { auto: auto.n, back, left: rows.length, ms: total };
}
async function msSave() {
  const M = IS.ms, L = ordRows().filter(x => !x.done && !x.cancel && M.sel.has(x.key));
  if (!L.length) { IS.msg = '입고할 주문을 골라 주세요'; return renderInv(); }
  const noCost = L.find(x => { const e = (M.edit || {})[x.key] || {}; return e.unit != null ? priceBlank(e.unit) : !(x.unit > 0); });   // 상용화 점검: 매입가를 못 읽은 주문은 조용히 0원으로 넣지 않아요
  if (noCost) { IS.msg = `${noCost.name.slice(0, 30)} ${noCost.size} — 매입가를 넣어 주세요 (무상이면 0)`; return renderInv(); }
  const r = await importRows(L, { payId: M.payId, cat: M.cat });
  M.sel.clear(); IS.msg = `주문 ${r.n}건 입고했어요${r.newItems ? ` (새 상품 ${r.newItems}종)` : ''}`;
  renderInv();
}
async function setOrderAlarm() {
  if (!HAS_CHROME || !chrome.alarms) return;
  await chrome.alarms.clear('ks-orders');
  if (+INV.opt.autoHours > 0) chrome.alarms.create('ks-orders', { periodInMinutes: +INV.opt.autoHours * 60, delayInMinutes: +INV.opt.autoHours * 60 });
}

// ---------- 우선출고 정산 ----------
function vPre() {
  const P = IS.pre;
  const list = INV.outs.filter(o => o.kind === 'pre' && !o.settled).sort((a, b) => a.date.localeCompare(b.date));
  const doneAll = INV.outs.filter(o => o.kind === 'pre' && o.settled).sort((a, b) => String(b.settleDate || '').localeCompare(String(a.settleDate || '')));
  const PT = P.tab || 'open', PQ = String(P.q || '').toLowerCase();
  const pqHit = o => { if (!PQ) return true; const it = itemOf(o.itemId) || {}; return [itName(it), it.code, it.brand, o.size, o.memo, o.track, partnerOf(o.partnerId)?.name].some(x => String(x || '').toLowerCase().includes(PQ)); };
  const q = list.reduce((s, o) => s + o.qty, 0), cost = list.reduce((s, o) => s + outNums(o).cogs, 0);
  const old30 = list.filter(o => -dday(o.date) > 30), m0 = monthStart(), doneM = INV.outs.filter(o => o.kind === 'pre' && o.settled && (o.settleDate || '') >= m0);
  const matchTbl = (M, kind) => M && M.rows.length ? `<div class="tbl"><table><thead><tr><th class="l">${kind} 줄</th><th class="l">품번</th><th class="l">사이즈</th><th>판매가</th><th class="l">맞춘 우선출고</th></tr></thead><tbody>${M.rows.map((r, i) => `<tr><td class="l small">${i + 1}</td><td class="l">${esc(r.code)}</td><td class="l">${esc(r.size)}</td><td>${won(r.price)}</td><td class="l">${r.outId ? `<span class="pill ok">맞춤</span> ${esc(itName(itemOf(INV.outs.find(o => o.id === r.outId)?.itemId)))} · ${esc(INV.outs.find(o => o.id === r.outId)?.date || '')}` : `<span class="pill bad">못 찾음</span>${kind === '포이즌' ? ` <select data-k="pzLink" data-c="${esc(r.code)}"><option value="">상품 연결 (다음부터 자동)</option>${INV.items.map(it => opt(it.id, `${it.code} ${itName(it)}`)).join('')}</select>` : ''}`}</td></tr>`).join('')}</tbody></table></div><div class="row-btns"><button type="button" class="primary" data-a="${kind === '크림' ? 'kreamApply' : 'pzApply'}"${M.rows.some(r => r.outId) ? '' : ' disabled'}>맞춘 ${M.rows.filter(r => r.outId).length}건 정산 완료</button></div>` : '';
  return `${head('우선출고 정산', '먼저 내보내고 판매가가 나중에 정해진 출고를 정산해요. 판매가를 넣으면 수수료·마진이 계산돼요.')}${flash()}
  <div class="kgrid">${card('정산 대기', list.length + '건', list.length ? 'warn' : '', q + '개')}${card('매입 원가 합계', won(cost), 'acc', list.length ? `가장 오래된 출고 ${Math.max(0, -dday(list[0].date))}일 전` : '대기 없음')}${card('30일 넘은 대기', old30.length + '건', old30.length ? 'neg' : '', old30.length ? '크림 · 포이즌 정산 내역을 확인해 보세요' : '오래 묵은 건 없음')}${card('이번 달 정산 완료', doneM.length + '건', 'pos', '마진 ' + wonS(doneM.reduce((a, o) => a + outNums(o).margin, 0)))}</div>
  <div class="panel kh-bar ret-bar"><div class="kh-row"><input data-k="preQ" value="${esc(P.q || '')}" placeholder="상품명 · 품번 · 브랜드 · 사이즈 · 메모 검색"></div></div>
  <div class="subtabs">${[['open', '미정산', list.length], ['done', '정산완료', doneAll.length], ['all', '전체', list.length + doneAll.length]].map(([k, t, n]) => `<button type="button" data-a="preTab" data-v="${k}" aria-selected="${PT === k}">${t} <span class="small">${n}</span></button>`).join('')}</div>
  ${PT !== 'open' ? `<div class="panel"><h2>정산 완료</h2><div class="tbl"><table><thead><tr><th class="l">정산일</th><th class="l">출고일</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>판매가</th><th>마진</th><th class="l">매출처</th></tr></thead><tbody>${doneAll.filter(pqHit).slice(0, 300).map(o => { const n = outNums(o); return `<tr><td class="l">${esc(o.settleDate || '')}</td><td class="l">${esc(o.date)}</td><td class="l name"><b>${esc(itName(itemOf(o.itemId)))}</b><span class="code">${esc(itemOf(o.itemId)?.code || '')}</span></td><td class="l">${esc(o.size)}</td><td>${n.net}</td><td>${won(o.price)}</td><td class="${n.margin >= 0 ? 'pos' : 'neg'}">${wonS(n.margin)}</td><td class="l">${esc(partnerOf(o.partnerId)?.name || '')}</td></tr>`; }).join('') || '<tr><td colspan="8" class="empty">정산 완료된 우선출고가 없어요</td></tr>'}</tbody></table></div></div>` : ''}
  ${PT === 'done' ? '' : `<div class="panel"><div class="toolbar"><h2>정산 대기 목록</h2><div class="row-btns"><input type="date" data-k="preDate" value="${esc(P.date || today())}" title="정산일"><button type="button" class="primary" data-a="preSettle">선택 ${[...P.sel].filter(id => list.some(o => o.id === id)).length}건 정산</button></div></div>
    <div class="tbl"><table><thead><tr><th><input type="checkbox" data-k="preAll" aria-label="전체 선택"></th><th class="l">출고일</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>매입 원가 (개당)</th><th class="l">매출처</th><th>판매가 (개당)</th><th>예상 마진</th><th></th></tr></thead><tbody>${list.filter(pqHit).map(o => { const n = outNums(o); const pr = num(P.price[o.id]); const fee = partnerFee(partnerOf(o.partnerId), pr); const mg = pr ? (pr - fee) * o.qty - n.cogs - n.ship : null; return `<tr><td><input type="checkbox" data-k="preSel" data-i="${o.id}"${P.sel.has(o.id) ? ' checked' : ''}></td><td class="l">${o.date}${dday(o.date) <= -14 ? ' <span class="pill warn">2주+</span>' : ''}</td><td class="l name"><b>${esc(itName(itemOf(o.itemId)))}</b><span class="code">${esc(itemOf(o.itemId)?.code || '')}</span></td><td class="l">${esc(o.size)}</td><td>${o.qty}</td><td>${won(n.unitCost)}</td><td class="l">${esc(partnerOf(o.partnerId)?.name || '')}</td><td><input inputmode="numeric" class="cost-in" data-k="prePrice" data-i="${o.id}" value="${esc(P.price[o.id] || '')}"></td><td data-mg="${o.id}" class="${mg > 0 ? 'pos' : mg < 0 ? 'neg' : ''}">${mg == null ? '–' : wonS(mg)}</td><td><button type="button" class="ghost tiny" data-a="preOne" data-id="${o.id}">정산</button></td></tr>`; }).join('') || '<tr><td colspan="10" class="empty">정산 대기 중인 우선출고가 없어요</td></tr>'}</tbody></table></div></div>`}
  <div class="igrid2"><div class="panel"><h2>크림 대량 정산</h2><p class="hint">크림 판매내역을 엑셀에서 복사해 붙여넣거나 한 줄에 하나씩 <b>품번 사이즈 판매가</b>로 적어요. 품번·사이즈가 같은 우선출고 중 오래된 것부터 맞춰요.</p>
      <textarea data-k="kreamText" rows="5" placeholder="DD1391-100  270  139000&#10;MR530KA	260	99,000">${esc(P.kreamText || '')}</textarea><div class="row-btns"><button type="button" class="ghost" data-a="kreamMatch">맞춰 보기</button></div>${matchTbl(P.kream, '크림')}</div>
    <div class="panel"><h2>포이즌 정산</h2><p class="hint">포이즌 판매자센터에서 받은 엑셀을 올려요. 품번이 다르게 적힌 상품은 한 번 연결해 두면 다음부터 자동으로 맞춰요.</p>${poizonNoFee() ? `<p class="hint neg">포이즌 수수료를 넣어 주세요 — 지금 0% + 0원이라 정산하면 수수료 없이 저장돼요. <button type="button" class="linkbtn" data-a="partnerEdit" data-id="${esc((INV.partners.find(isPoizon) || {}).id || '')}">포이즌 수수료 넣기</button></p>` : ''}
      <label class="drop small-drop"><input type="file" accept=".xlsx,.xlsm,.csv" data-k="pzFile" hidden><b>포이즌 엑셀 올리기</b>${P.pzFile ? `<span class="small">${esc(P.pzFile)}</span>` : ''}</label>${P.pzMsg ? `<p class="hint neg">${esc(P.pzMsg)}</p>` : ''}${matchTbl(P.poizon, '포이즌')}</div></div>`;
}
function parseSaleLines(text) {
  const out = [];
  for (const line of String(text || '').split(/\n/)) {
    const t = line.trim(); if (!t) continue;
    const parts = t.split(/\t|\s{2,}|,(?=\s)|\s+/).map(s => s.trim()).filter(Boolean);
    const nums = parts.map(s => num(s)).filter((n, i) => /^[\d,]+원?$/.test(parts[i]) && n >= 1000);
    const price = nums.length ? nums[nums.length - 1] : 0;
    const code = parts.find(s => /[A-Za-z]/.test(s) && /\d/.test(s) && s.length >= 4) || '';
    const size = parts.find(s => s !== code && !(/^[\d,]+원?$/.test(s) && num(s) >= 1000) && /^(\d{2,3}(\.5)?|[XSML]{1,4}|XXL|FREE|\d?XL)$/i.test(s)) || '';
    if (code && price) out.push({ code, size, price });
  }
  return out;
}
function matchPre(rows, prefer) {
  const used = new Set();
  for (const r of rows) {
    const itemIds = new Set(INV.items.filter(it => codeKey(it.code) === codeKey(r.code)).map(it => it.id));
    if (r.itemId) itemIds.add(r.itemId);
    const cand = INV.outs.filter(o => o.kind === 'pre' && !o.settled && !used.has(o.id) && itemIds.has(o.itemId) && (!r.size || String(o.size).toUpperCase() === String(r.size).toUpperCase()))
      .sort((a, b) => ((partnerOf(b.partnerId)?.name === prefer) - (partnerOf(a.partnerId)?.name === prefer)) || a.date.localeCompare(b.date));
    r.outId = cand[0] ? cand[0].id : '';
    if (r.outId) used.add(r.outId);
  }
  return rows;
}
async function settleOuts(pairs, date) {
  let n = 0;
  for (const [id, price] of pairs) { const o = INV.outs.find(x => x.id === id); if (!o || o.settled || !price) continue; o.price = price; o.settled = true; o.settleDate = date || today(); o.fee = partnerFee(partnerOf(o.partnerId), price); n++; }
  await invSave(); return n;
}
async function pzLoad(file) {
  const P = IS.pre; P.pzFile = file.name; P.pzMsg = '';
  try {
    const rows = await XL.readFile(file);
    const hi = rows.findIndex(r => r.some(v => /货号|품번|article|style|모델|sku/i.test(String(v))) && r.some(v => /尺码|사이즈|size|규격/i.test(String(v))));
    if (hi < 0) throw new Error('품번·사이즈 칸을 못 찾았어요');
    const H = rows[hi].map(v => String(v));
    const ci = re => H.findIndex(h => re.test(h));
    const cCode = ci(/货号|품번|article|style|모델|sku/i), cSize = ci(/尺码|사이즈|size|규격/i), cPrice = ci(/정산|결제|실수령|settle|结算|금액|price|가격/i);
    const out = [];
    for (const r of rows.slice(hi + 1)) {
      const raw = String(r[cCode] || '').trim(); if (!raw) continue;
      const mapped = INV.poizonMap[codeKey(raw)];
      out.push({ code: raw, size: String(r[cSize] ?? '').replace(/\s*(KR|EU|US|mm)$/i, '').trim(), price: num(r[cPrice]), itemId: mapped || '' });
    }
    P.poizon = { rows: matchPre(out.filter(r => r.price), '포이즌') };
    if (!P.poizon.rows.length) P.pzMsg = '금액이 있는 줄이 없어요';
  } catch (e) { P.pzMsg = e.message; P.poizon = null; }
  renderInv();
}

// ---------- 반품 · 교환 ----------
// 3.29: 반품 · 교환 — 숫자 카드, 검색 · 거래처 · 기한 필터, 처리 내역 탭
function vRet(C) {
  const T = IS.ret, F = IS.rf = IS.rf || { q: '', partner: '', due: '' };
  const qm = id => !F.q || itName(itemOf(id)).toLowerCase().includes(F.q.toLowerCase()) || String((itemOf(id) || {}).code || '').toLowerCase().includes(F.q.toLowerCase());
  const pm = pid => !F.partner || pid === F.partner;
  const bm = id => !F.brand || (itemOf(id) || {}).brand === F.brand, paym = x => !F.pay || x === F.pay;
  const buyAll = INV.lots.filter(l => !l.confirmed && C.left.get(l.id) > 0 && !['return'].includes(l.src));
  const kept = INV.lots.filter(l => l.confirmed && C.left.get(l.id) > 0 && lotIsBuy(l));   // 개선판 1-5: [보유] 표시한 매입 (되돌릴 수 있게)
  const sellAll = INV.outs.filter(o => o.settled && !o.confirmed && o.qty - (o.retQty || 0) > 0);
  const dd = l => l.returnDue ? dday(l.returnDue) : null;
  const soon = buyAll.filter(l => { const d = dd(l); return d != null && d >= 0 && d <= 2; }), past = buyAll.filter(l => { const d = dd(l); return d != null && d < 0; });
  const buyV = buyAll.reduce((a, l) => a + l.cost * C.left.get(l.id), 0), sellV = sellAll.reduce((a, o) => a + (o.price - (o.disc || 0)) * (o.qty - (o.retQty || 0)), 0);   // 상용화 점검: 할인 뺀 금액
  // 처리 내역 (매입 반품 · 교환 · 판매 반품 · 할인)
  const hist = [];
  for (const l of INV.lots) for (const e of l.events || []) if (['반품', '교환'].includes(e.t)) hist.push({ d: e.d, side: '매입', t: e.t, id: l.itemId, size: l.size, q: e.q, amt: e.t === '반품' ? l.cost * e.q : 0, to: e.to || '', pid: l.partnerId, auto: e.auto });
  for (const o of INV.outs) for (const e of o.events || []) if (['반품', '할인'].includes(e.t)) hist.push({ d: e.d, side: '판매', t: e.t, id: o.itemId, size: o.size, q: e.q, amt: -(e.total || 0), pid: o.partnerId, memo: e.memo || '' });
  hist.sort((x, y) => String(y.d).localeCompare(String(x.d)));
  const m0 = monthStart();
  const monthN = hist.filter(h => h.d >= m0).length;
  const partners = INV.partners.filter(p => T === 'buy' ? p.kind === 'buy' : T === 'sell' ? p.kind !== 'buy' : true);
  const bar = `<div class="panel kh-bar ret-bar"><div class="kh-row"><input data-k="retQ" value="${esc(F.q)}" placeholder="상품명 · 품번 검색"><select data-k="retPartner"><option value="">전체 거래처</option>${partners.map(p => opt(p.id, p.name, F.partner === p.id)).join('')}</select>${(() => { const B = [...new Set(INV.items.map(it => it.brand).filter(Boolean))].sort(); return B.length ? `<select data-k="retBrand"><option value="">전체 브랜드</option>${B.map(b => opt(b, b, F.brand === b)).join('')}</select>` : ''; })()}${T === 'buy' && INV.pays.length ? `<select data-k="retPay"><option value="">전체 결제수단</option>${INV.pays.map(p => opt(p.id, p.name, F.pay === p.id)).join('')}</select>` : ''}${F.q || F.partner || F.due || F.brand || F.pay ? '<button type="button" class="ghost tiny" data-a="retReset">초기화</button>' : ''}${T === 'buy' ? `<select data-k="retDue">${[['', '전체 기한'], ['d1', '오늘·내일'], ['soon', 'D-2 이내'], ['alert', `알림 기준 (D-${INV.opt.soon} 이내)`], ['week', 'D-7 이내'], ['past', '기한 지남'], ['none', '기한 없음'], ['kept', '보유 표시한 것']].map(([v, t]) => opt(v, t, F.due === v)).join('')}</select>` : ''}</div></div>`;
  let body = '';
  if (T === 'buy') {
    const L = (F.due === 'kept' ? kept : buyAll).filter(l => qm(l.itemId) && pm(l.partnerId) && bm(l.itemId) && paym(l.payId) && (() => { const d = dd(l); return !F.due || F.due === 'kept' || (F.due === 'd1' ? d != null && d >= 0 && d <= 1 : F.due === 'soon' ? d != null && d >= 0 && d <= 2 : F.due === 'alert' ? d != null && d >= 0 && d <= INV.opt.soon : F.due === 'week' ? d != null && d >= 0 && d <= 7 : F.due === 'past' ? d != null && d < 0 : d == null); })()).sort((a, b) => (a.returnDue || '9').localeCompare(b.returnDue || '9'));
    body = `<div class="toolbar"><p class="hint">${F.due === 'kept' ? '반품하지 않기로 [보유] 표시한 매입이에요. [보유 풀기]를 누르면 다시 반품 기한 알림에 들어가요.' : '매입한 상품을 반품하거나 사이즈를 교환해요. 반품하지 않을 물건은 [보유]를 누르면 목록과 반품 알림에서 빠져요. 기한을 누르면 이 매입만 기한을 고칠 수 있어요.'}</p>${F.due === 'kept' ? '' : '<button type="button" class="ghost" data-a="retConfirmSoon">마감 임박(D-2 이내·지남) 일괄 보유</button>'}</div>
    <div class="tbl"><table><thead><tr><th class="l">반품 기한</th><th class="l">입고일</th><th class="l">상품</th><th class="l">사이즈</th><th>남은 수량</th><th>매입가</th><th class="l">매입처</th><th></th></tr></thead><tbody>${L.map(l => { const d = dd(l); const cls = d == null ? 'mute' : d < 0 ? 'mute' : d <= 2 ? 'bad' : d <= 5 ? 'warn' : 'ok'; return `<tr><td class="l"><button type="button" class="linkbtn" data-a="lotDue" data-id="${l.id}" title="이 매입의 반품 기한 고치기"><span class="pill ${cls}">${d == null ? '없음' : d < 0 ? '지남' : d === 0 ? '오늘' : 'D-' + d}</span> <span class="small">${esc(l.returnDue || '기한 넣기')}</span></button></td><td class="l">${l.date}</td><td class="l name"><b>${esc(itName(itemOf(l.itemId)))}</b>${l.exQty ? ` <span class="small">(교환 ${l.exQty})</span>` : ''}${l.retQty ? ` <span class="small">(반품 ${l.retQty})</span>` : ''}</td><td class="l">${esc(l.size)}</td><td>${C.left.get(l.id)}</td><td>${won(l.cost)}</td><td class="l">${esc(partnerOf(l.partnerId)?.name || '')}</td><td><div class="act"><button type="button" class="ghost" data-a="lotRet" data-id="${l.id}">반품</button><button type="button" class="ghost" data-a="lotEx" data-id="${l.id}">교환</button>${l.confirmed ? `<button type="button" class="ghost" data-a="lotKeepOff" data-id="${l.id}">보유 풀기</button>` : `<button type="button" class="ghost" data-a="lotOk" data-id="${l.id}" title="반품하지 않을 물건으로 표시 — 반품 알림에서 빠져요">보유</button>`}</div></td></tr>`; }).join('') || `<tr><td colspan="8" class="empty">${F.due === 'kept' ? '보유 표시한 매입이 없어요' : buyAll.length ? '조건에 맞는 매입이 없어요' : '반품·교환할 매입이 없어요'}</td></tr>`}</tbody></table></div>`;
  } else if (T === 'sell') {
    const L = sellAll.filter(o => qm(o.itemId) && pm(o.partnerId) && bm(o.itemId)).sort((a, b) => b.settleDate.localeCompare(a.settleDate));
    body = `<p class="hint">판매한 상품이 반품되면 재고로 돌아와요. 판매 후 가격을 깎아 준 경우 '할인'으로 넣어요. 판매확정하면 목록에서 빠져요.</p>
    <div class="tbl"><table><thead><tr><th class="l">정산일</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>판매가</th><th>마진</th><th class="l">매출처</th><th></th></tr></thead><tbody>${L.map(o => { const n = outNums(o); return `<tr><td class="l">${o.settleDate}</td><td class="l name"><b>${esc(itName(itemOf(o.itemId)))}</b></td><td class="l">${esc(o.size)}</td><td>${n.net}${o.retQty ? ` <span class="small">(반품 ${o.retQty})</span>` : ''}</td><td>${won(o.price)}${o.disc ? `<div class="small">할인 −${won(o.disc)}</div>` : ''}</td><td class="${n.margin >= 0 ? 'pos' : 'neg'}">${wonS(n.margin)}</td><td class="l">${esc(partnerOf(o.partnerId)?.name || '')}</td><td><div class="act"><button type="button" class="ghost" data-a="outRet" data-id="${o.id}">반품</button><button type="button" class="ghost" data-a="outDisc" data-id="${o.id}">할인</button><button type="button" class="ghost" data-a="outOk" data-id="${o.id}">확정</button></div></td></tr>`; }).join('') || `<tr><td colspan="8" class="empty">${sellAll.length ? '조건에 맞는 판매가 없어요' : '판매 반품·할인 처리할 건이 없어요'}</td></tr>`}</tbody></table></div>`;
  } else {
    const L = hist.filter(h => qm(h.id) && pm(h.pid) && bm(h.id));
    const pillT = { 반품: 'bad', 교환: 'warn', 할인: 'acc' };
    body = `<p class="hint">지금까지 처리한 반품 · 교환 · 할인 기록이에요. 금액은 장부에 들어간 값이에요 (매입 반품은 돌려받는 돈, 판매 반품 · 할인은 줄어든 매출).</p>
    <div class="tbl"><table><thead><tr><th class="l">처리일</th><th class="l">구분</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>금액</th><th class="l">거래처</th><th class="l">메모</th></tr></thead><tbody>${L.slice(0, 300).map(h => `<tr><td class="l">${esc(h.d || '')}</td><td class="l"><span class="pill ${pillT[h.t] || 'mute'}">${h.side} ${h.t}</span></td><td class="l name"><b>${esc(itName(itemOf(h.id)))}</b></td><td class="l">${esc(h.size)}${h.to ? ` → ${esc(h.to)}` : ''}</td><td>${h.q}</td><td class="${h.amt > 0 ? 'pos' : h.amt < 0 ? 'neg' : ''}">${h.amt ? wonS(h.amt) : '–'}</td><td class="l">${esc(partnerOf(h.pid)?.name || '')}</td><td class="l small">${h.auto === 'cancel' ? '입고 취소로 자동 반품' : esc(h.memo || '')}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">아직 처리한 기록이 없어요</td></tr>'}</tbody></table></div>${L.length > 300 ? `<p class="hint">최근 300건만 보여요 (전체 ${L.length}건) — 장부 · 정산에서 기간으로 볼 수 있어요.</p>` : ''}`;
  }
  return `${head('반품 · 교환', `반품 기한이 가까우면 색이 바뀌어요: 빨강 2일 이하 · 주황 5일 이하 · 초록 6일 이상`)}${flash()}
  <div class="kgrid">${card('반품 가능한 매입', buyAll.length + '건', 'acc', won(buyV))}${card('반품 기한 임박 (D-2)', soon.length + '건', soon.length ? 'neg' : '', past.length ? `기한 지남 ${past.length}건` : '기한 지난 건 없음')}${card('판매확정 대기', sellAll.length + '건', 'warn', won(sellV))}${card('이번 달 처리', monthN + '건', 'pos', '반품 · 교환 · 할인')}</div>
  <div class="subtabs"><button type="button" data-a="retTab" data-v="buy" aria-selected="${T === 'buy'}">매입 반품 · 교환 <span class="small">${buyAll.length}</span></button><button type="button" data-a="retTab" data-v="sell" aria-selected="${T === 'sell'}">판매 반품 · 할인 <span class="small">${sellAll.length}</span></button><button type="button" data-a="retTab" data-v="hist" aria-selected="${T === 'hist'}">처리 내역 <span class="small">${hist.length}</span></button></div>${bar}${body}`;
}

// ---------- 장부 · 정산 ----------
function ledgerRows() {
  const R = [];
  const nm = (id, sz, q) => `${itName(itemOf(id))} ${sz} ×${q}`;
  for (const l of INV.lots) {
    // 상용화 점검: 매입 줄은 원래 입고에서만, 매입반품 줄은 모든 입고(교환으로 받은 것 포함)에서 내요
    const p = partnerOf(l.partnerId), pay = payOf(l.payId);
    if (lotIsBuy(l)) R.push({ date: l.date, kind: '매입', desc: nm(l.itemId, l.size, l.qty), partner: p?.name || '', partnerId: l.partnerId, pay: pay?.name || '', payId: l.payId || '', amount: -l.cost * l.qty, memo: l.memo || '', vatIn: p && p.tax === '과세' && !(pay && pay.proof === false) ? l.cost * l.qty : 0 });
    for (const e of l.events || []) if (e.t === '반품') R.push({ date: e.d, kind: '매입반품', desc: nm(l.itemId, l.size, e.q), partner: p?.name || '', partnerId: l.partnerId, pay: pay?.name || '', payId: l.payId || '', amount: l.cost * e.q, memo: '', vatIn: p && p.tax === '과세' && !(pay && pay.proof === false) ? -l.cost * e.q : 0 });
  }
  for (const o of INV.outs) {
    if (!o.settled) continue;
    const p = partnerOf(o.partnerId), fee = outFee(o), feeTax = !!(p && p.tax === '과세');   // 상용화 점검: 수수료 매입세액은 과세 거래처만 (영세 포이즌은 0)
    const base = { partner: p?.name || '', partnerId: o.partnerId, pay: '', payId: '', memo: o.memo || '' };
    R.push({ ...base, date: o.settleDate, kind: '매출', desc: nm(o.itemId, o.size, o.qty), amount: o.price * o.qty, gross: o.price * o.qty, vatOut: p && p.tax === '과세' ? o.price * o.qty : 0 });
    if (fee) R.push({ ...base, date: o.settleDate, kind: '수수료', desc: nm(o.itemId, o.size, o.qty), amount: -fee * o.qty, vatIn: feeTax ? fee * o.qty : 0 });
    if (+o.ship) R.push({ ...base, date: o.settleDate || o.date, kind: '택배비', desc: nm(o.itemId, o.size, o.qty), amount: -o.ship });
    for (const e of o.events || []) {
      if (e.t === '반품') { R.push({ ...base, date: e.d, kind: '매출반품', desc: nm(o.itemId, o.size, e.q), amount: -e.total, gross: -(e.gross != null ? e.gross : e.total), vatOut: p && p.tax === '과세' ? -e.gross : 0 }); if (e.feeBack) R.push({ ...base, date: e.d, kind: '수수료', desc: '반품 수수료 환급', amount: e.feeBack, vatIn: feeTax ? -e.feeBack : 0 }); }
      if (e.t === '할인') R.push({ ...base, date: e.d, kind: '할인', desc: nm(o.itemId, o.size, e.q), amount: -e.total, gross: -e.total, vatOut: p && p.tax === '과세' ? -e.total : 0, memo: e.memo || '' });
    }
  }
  for (const m of INV.ledger) R.push({ date: m.date, kind: m.io === 'in' ? '수기 수입' : '수기 지출', desc: m.desc, partner: m.partner || '', partnerId: '', pay: payOf(m.payId)?.name || '', payId: m.payId || '', amount: m.io === 'in' ? +m.amount : -m.amount, memo: m.memo || '', id: m.id, vatIn: m.io === 'out' && m.vat ? +m.amount : 0, vatOut: m.io === 'in' && m.vat ? +m.amount : 0 });
  if (typeof finLedgerRows === 'function') R.push(...finLedgerRows());   // 개선판 1-9: 지출 (fin.js)
  return R.sort((a, b) => b.date.localeCompare(a.date));
}
function vLedgerList() {
  const F = IS.lg; if (!F.from) { F.from = monthStart(); F.to = monthEnd(); }
  const all = ledgerRows().filter(r => inRange(r.date, F.from, F.to));
  const rows = all.filter(r => (!F.kind || r.kind.startsWith(F.kind)) && (!F.partner || r.partner === F.partner) && (!F.pay || r.payId === F.pay));
  let margin = 0;
  for (const o of INV.outs) if (o.settled && inRange(o.settleDate, F.from, F.to)) margin += outNums(o).margin;
  const cash = all.filter(r => !r.kind.startsWith('수기') && r.kind !== '택배비' && r.kind !== '지출').reduce((s, r) => s + r.amount, 0);
  const extra = all.filter(r => r.kind.startsWith('수기') || r.kind === '택배비' || r.kind === '지출').reduce((s, r) => s + r.amount, 0);
  const pages = Math.max(1, Math.ceil(rows.length / F.size)); if (F.page >= pages) F.page = pages - 1;
  const view = rows.slice(F.page * F.size, F.page * F.size + F.size);
  const y = +today().slice(0, 4);
  const kinds = ['매출', '매입', '수수료', '택배비', '지출', '매출반품', '매입반품', '할인', '수기'];
  return `
  <div class="filters"><select data-k="lgQuick"><option value="">기간 빠른 선택</option>${[0, 1, 2].map(i => { const d = new Date(today().slice(0, 7) + '-01T00:00:00'); d.setMonth(d.getMonth() - i); const s = fmtD(d); return opt('m' + s, `${s.slice(0, 4)}년 ${+s.slice(5, 7)}월`); }).join('')}${[y, y - 1].map(v => opt('y' + v, `${v}년 전체`)).join('')}</select>
    <input type="date" data-k="lg" data-f="from" value="${F.from}"><span class="hint">~</span><input type="date" data-k="lg" data-f="to" value="${F.to}">
    <select data-k="lg" data-f="kind"><option value="">구분 전체</option>${kinds.map(k => opt(k, k, F.kind === k)).join('')}</select>
    <select data-k="lg" data-f="partner"><option value="">거래처 전체</option>${[...new Set(all.map(r => r.partner).filter(Boolean))].map(p => opt(p, p, F.partner === p)).join('')}</select>
    <select data-k="lg" data-f="pay"><option value="">결제수단 전체</option>${INV.pays.map(p => opt(p.id, p.name, F.pay === p.id)).join('')}</select></div>
  <div class="kgrid k3">${card('판매 마진', wonS(margin), margin >= 0 ? 'pos' : 'neg', '판매 − 수수료 − 매입원가 − 택배비 (정산일 기준)')}${card('현금 흐름', wonS(cash), cash >= 0 ? 'pos' : 'neg', '실제 정산 받은 돈 − 실제 매입한 돈 (반품 포함)')}${card('부대비용', wonS(extra), extra >= 0 ? 'pos' : 'neg', '수기 수입·지출 + 택배비 + 지출')}</div>
  <div class="tbl"><table><thead><tr><th class="l">날짜</th><th class="l">구분</th><th class="l">내용</th><th class="l">거래처</th><th class="l">결제수단</th><th>금액</th><th class="l">메모</th><th></th></tr></thead><tbody>${view.map(r => `<tr><td class="l">${r.date}</td><td class="l"><span class="pill ${r.amount >= 0 ? 'ok' : 'mute'}">${r.kind}</span></td><td class="l">${esc(r.desc)}</td><td class="l">${esc(r.partner)}</td><td class="l">${esc(r.pay)}</td><td class="${r.amount >= 0 ? 'pos' : 'neg'}"><b>${r.amount >= 0 ? '+' : ''}${wonS(r.amount)}</b></td><td class="l small">${esc(r.memo)}</td><td>${r.id ? `<button type="button" class="ghost tiny" data-a="manualDel" data-id="${r.id}">삭제</button>` : r.expId ? `<button type="button" class="ghost tiny" data-a="expDel" data-id="${r.expId}">삭제</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">이 기간에 기록이 없어요</td></tr>'}</tbody></table></div>
  <div class="toolbar"><span class="hint">${rows.length}건 · 합계 ${wonS(rows.reduce((s, r) => s + r.amount, 0))}</span><div class="row-btns"><select data-k="lgSize">${[10, 50, 100].map(n => opt(n, n + '개씩', F.size === n)).join('')}</select><button type="button" class="ghost" data-a="lgPage" data-v="-1"${F.page ? '' : ' disabled'}>이전</button><span class="hint">${F.page + 1} / ${pages}</span><button type="button" class="ghost" data-a="lgPage" data-v="1"${F.page + 1 < pages ? '' : ' disabled'}>다음</button></div></div>`;
}


// ---------- 3.24: 장부 · 정산 — 대시보드 · 자산현황 · 상품별 · 거래처별 · 장부 내역 ----------
const LG_TABS = [['dash', '대시보드', 'chart'], ['asset', '자산현황', 'cube'], ['item', '상품별 분석', 'tag'], ['partner', '거래처별 분석', 'user'], ['settle', '정산', 'receipt'], ['exp', '지출', 'truck'], ['list', '장부 내역', 'book'], ['vat', '부가세', 'percent']];
function lgFigures(a, b) {
  const M = monthFigures(a, b); let ship = 0, cash = 0, inc = 0, exp = 0;
  for (const o of INV.outs) if (o.settled && inRange(o.settleDate, a, b)) ship += outNums(o).ship;
  for (const r of ledgerRows()) { if (!inRange(r.date, a, b)) continue; if (r.kind.startsWith('수기') || r.kind === '지출') { if (r.amount >= 0) inc += r.amount; else exp -= r.amount; } else if (r.kind !== '택배비') cash += r.amount; }
  return { ...M, ship, cash, inc, exp, rate: M.rev ? M.margin / M.rev * 100 : 0, settle: M.rev - M.fees };
}
function lgSeries(a, b) {
  const days = Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 864e5) + 1, byMonth = days > 62, pts = [];
  if (byMonth) { let d = new Date(a.slice(0, 7) + '-01T00:00:00'); const end = b.slice(0, 7); while (fmtD(d).slice(0, 7) <= end && pts.length < 36) { const s0 = fmtD(d); const f = monthFigures(monthStart(s0) < a ? a : monthStart(s0), monthEnd(s0) > b ? b : monthEnd(s0)); pts.push({ l: +s0.slice(5, 7) + '월', ...f }); d.setMonth(d.getMonth() + 1); } }
  else for (let i = 0; i < days; i++) { const s0 = addDays(a, i); const f = monthFigures(s0, s0); pts.push({ l: s0.slice(5).replace('-', '/'), ...f }); }
  return pts;
}
function lgChart(pts) {
  const W = 760, H = 220, P = 34, n = Math.max(1, pts.length), mx = Math.max(1, ...pts.flatMap(p => [p.rev, p.buy, Math.abs(p.margin)])), mn = Math.min(0, ...pts.map(p => p.margin));
  const y = v => P / 2 + (H - P) * (1 - (v - mn) / (mx - mn || 1)), x = i => P + (W - P * 1.4) * (n === 1 ? 0.5 : i / (n - 1));
  const line = (k, c) => `<path d="${pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p[k]).toFixed(1)}`).join('')}" fill="none" stroke="url(#${c})" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round" class="lg-line"/>`;
  const area = `<path d="M${x(0)},${y(0)}${pts.map((p, i) => `L${x(i).toFixed(1)},${y(p.rev).toFixed(1)}`).join('')}L${x(n - 1)},${y(0)}Z" fill="url(#lgA)" opacity=".5"/>`;
  const step = Math.ceil(n / 12), fmt = v => Math.abs(v) >= 1e4 ? Math.round(v / 1e4).toLocaleString('ko-KR') + '만' : Math.round(v).toLocaleString('ko-KR');
  const grid = [0, .25, .5, .75, 1].map(t => { const v = mn + (mx - mn) * t; return `<line x1="${P}" x2="${W - P * .4}" y1="${y(v)}" y2="${y(v)}" class="lg-grid"/><text x="${P - 6}" y="${y(v) + 3}" text-anchor="end" class="lg-tx">${fmt(v)}</text>`; }).join('');
  return `<svg viewBox="0 0 ${W} ${H + 18}" class="lg-chart" role="img" aria-label="매출 · 매입 · 마진 추이"><defs><linearGradient id="lgR" x1="0" x2="1"><stop offset="0" stop-color="#6b8cff"/><stop offset="1" stop-color="#7a5cff"/></linearGradient><linearGradient id="lgB" x1="0" x2="1"><stop offset="0" stop-color="#fda4af"/><stop offset="1" stop-color="#e11d48"/></linearGradient><linearGradient id="lgM" x1="0" x2="1"><stop offset="0" stop-color="#5eead4"/><stop offset="1" stop-color="#10b981"/></linearGradient><linearGradient id="lgA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6b8cff" stop-opacity=".35"/><stop offset="1" stop-color="#6b8cff" stop-opacity="0"/></linearGradient></defs>${grid}${area}${line('rev', 'lgR')}${line('buy', 'lgB')}${line('margin', 'lgM')}${pts.map((p, i) => i % step ? '' : `<text x="${x(i)}" y="${H + 12}" text-anchor="middle" class="lg-tx">${esc(p.l)}</text>`).join('')}${pts.map((p, i) => `<circle cx="${x(i)}" cy="${y(p.margin)}" r="3" class="lg-dot"><title>${esc(p.l)} · 매출 ${won(p.rev)} · 매입 ${won(p.buy)} · 마진 ${wonS(p.margin)}</title></circle>`).join('')}</svg>`;
}
function lgPeriodBar(F) {
  const y = +today().slice(0, 4), m = +today().slice(5, 7);
  return `<div class="panel kh-bar"><div class="kh-row"><span class="kh-lab">${ico('cal')}조회 기간</span><select data-k="lgYear">${[y, y - 1, y - 2].map(v => opt(v, v + '년', +F.from.slice(0, 4) === v)).join('')}</select><select data-k="lgMonth"><option value="">1년 전체</option>${Array.from({ length: 12 }, (_, i) => opt(i + 1, (i + 1) + '월', F.from.slice(5, 10) === String(i + 1).padStart(2, '0') + '-01' && F.to === monthEnd(F.from))).join('')}</select><input type="date" data-k="lg" data-f="from" value="${F.from}"><span class="sub">~</span><input type="date" data-k="lg" data-f="to" value="${F.to}"><button type="button" class="kq" data-a="lgQuickB" data-v="m0">이번 달</button><button type="button" class="kq" data-a="lgQuickB" data-v="m1">지난 달</button><button type="button" class="kq" data-a="lgQuickB" data-v="y0">올해</button></div></div>`;
}
// 3.42(11/23 검수 2번): 정산 · 부가세 한 메뉴 — 탭은 정산 · 지출 · 부가세 · 장부 내역. 대시보드 · 자산현황 · 상품별 · 거래처별은 분석 메뉴 탭으로 옮겼어요(vLedger(true) 로 그려요)
const LG_MAIN = ['settle', 'exp', 'vat', 'list'];
// 다른 화면의 머리(제목 줄)를 떼고 오른쪽 버튼만 남겨요 — 부가세 예상을 정산 · 부가세 탭 안에 그릴 때
const lgNoHead = h => String(h || '').replace(/<div class="ihead"><div><h2>[\s\S]*?<\/div><div class="row-btns">([\s\S]*?)<\/div><\/div>/, (m, b) => b ? `<div class="row-btns end lg-acts">${b}</div>` : '');
function vLedger(noHead) {
  noHead = noHead === true;   // 화면 그리기(V[invView](C))는 계산 결과를 넘겨요 — true 일 때만 머리 없이
  const F = IS.lg; if (!F.from) { F.from = monthStart(); F.to = monthEnd(); }
  let tab = F.tab || 'settle';
  if (!noHead && !LG_MAIN.includes(tab)) tab = 'settle';
  const tabs = `<div class="kh-tabs lg-tabs">${LG_MAIN.map(k => LG_TABS.find(x => x[0] === k)).filter(Boolean).map(([k, t, ic]) => `<button type="button" class="${tab === k ? 'on' : ''}" data-a="lgTab" data-v="${k}">${typeof ico === 'function' ? ico(ic) : ''}${t}</button>`).join('')}</div>`;
  const H = noHead ? '' : head('정산 · 부가세', '판매처별 정산 · 지출 · 부가세 신고 자료를 한 곳에서 봐요. 기간별 현황은 분석 메뉴에 있어요.', `<button type="button" class="primary" data-a="manual">수기 입력</button><button type="button" class="ghost" data-a="ledgerXl">엑셀 다운로드</button>`) + flash() + tabs;
  if (tab === 'list') return H + vLedgerList();
  if (tab === 'exp' && typeof finExpView === 'function') return H + finExpView();
  if (tab === 'settle' && typeof finSettleView === 'function') return H + lgPeriodBar(F) + finSettleView(F.from, F.to);
  if (tab === 'vat' && typeof vVat === 'function') return H + lgNoHead(vVat());
  if (tab === 'vat') return H + `<div class="panel dl-empty">${ico('percent')}<span>부가세 예상은 따로 계산해요 (반기별 매출세액 · 매입세액 · 납부 예상)</span><button type="button" class="primary" data-a="nav" data-v="vat">부가세 예상 열기</button></div>`;
  const C = invCalc();
  if (tab === 'asset') {
    let qty = 0, val = 0; const byBrand = {};
    for (const it of INV.items) { const st = itemStock(it, C); if (!st.qty) continue; qty += st.qty; val += st.value; const b = it.brand || '브랜드 없음'; byBrand[b] = byBrand[b] || { q: 0, v: 0 }; byBrand[b].q += st.qty; byBrand[b].v += st.value; }
    let keepQ = 0, keepV = 0; for (const o of INV.outs) if (o.kind === 'pre' && !o.settled) { const n = outNums(o); keepQ += n.net; keepV += n.net * n.unitCost; }
    let planQ = 0, planV = 0; for (const P of INV.plans || []) if (['wait', 'partial'].includes(P.status)) for (const l of P.lines) { const left = (+l.qty || 0) - (+l.got || 0); planQ += left; planV += left * (+l.cost || 0); }
    const total = val + keepV + planV, B = Object.entries(byBrand).sort((a, b) => b[1].v - a[1].v), bmx = Math.max(1, ...B.map(x => x[1].v));
    const old = INV.lots.filter(l => C.left.get(l.id) > 0 && dday(addDays(l.date, INV.opt.staleDays)) < 0);
    return H + `<div class="kgrid">${card('총 자산 (매입가)', won(total), 'acc', '창고 + 크림 보관 + 아직 안 온 입고예정')}${card('창고 재고', won(val), 'pos', qty + '개')}${card('크림 보관 · 우선출고', won(keepV), 'warn', keepQ + '개 · 아직 안 팔림')}${card('입고예정 (미도착)', won(planV), '', planQ + '개')}</div>
    <div class="igrid2"><div class="box"><h3>브랜드별 재고 자산</h3>${B.length ? `<div class="lg-bars">${B.slice(0, 12).map(([b, x]) => `<div class="lg-bar"><span>${esc(b)}</span><i><b style="width:${Math.max(2, Math.round(x.v / bmx * 100))}%"></b></i><em>${won(x.v)} · ${x.q}개</em></div>`).join('')}</div>` : '<p class="hint">창고 재고가 없어요.</p>'}</div>
    <div class="box"><h3>오래된 재고 (입고 후 ${INV.opt.staleDays}일 넘음)</h3>${old.length ? `<div class="tbl"><table><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th>남은 수</th><th>매입가</th><th class="l">입고일</th></tr></thead><tbody>${old.sort((a, b) => a.date.localeCompare(b.date)).slice(0, 15).map(l => `<tr><td class="l">${esc(itName(itemOf(l.itemId)))}</td><td class="l">${esc(l.size)}</td><td>${C.left.get(l.id)}</td><td>${won(l.cost)}</td><td class="l small">${l.date}</td></tr>`).join('')}</tbody></table></div>` : '<p class="hint">오래된 재고가 없어요.</p>'}</div></div>`;
  }
  const a = F.from, b = F.to;
  if (tab === 'item' || tab === 'partner') {
    const G = {};
    for (const o of INV.outs) { if (!o.settled || !inRange(o.settleDate, a, b)) continue; const n = outNums(o), it = itemOf(o.itemId), k = tab === 'item' ? o.itemId : (o.partnerId || '-'); const g = G[k] = G[k] || { name: tab === 'item' ? itName(it) : (partnerOf(o.partnerId)?.name || '거래처 없음'), code: it ? it.code : '', kind: '매출처', sold: 0, rev: 0, fees: 0, cogs: 0, margin: 0, buyQ: 0, buy: 0 }; g.sold += n.net; g.rev += n.rev; g.fees += n.fees; g.cogs += n.cogs; g.margin += n.margin; }
    // 상용화 점검: 장부와 같은 기준 — 원래 입고는 입고일에 +, 매입 반품은 (교환으로 받은 것까지) 반품일에 −
    for (const l of INV.lots) {
      const qIn = lotIsBuy(l) && inRange(l.date, a, b) ? l.qty : 0, qRet = (l.events || []).reduce((s, e) => s + (e.t === '반품' && inRange(e.d, a, b) ? +e.q || 0 : 0), 0);
      if (!qIn && !qRet) continue;
      const it = itemOf(l.itemId), k = tab === 'item' ? l.itemId : (l.partnerId || '-'); const g = G[k] = G[k] || { name: tab === 'item' ? itName(it) : (partnerOf(l.partnerId)?.name || '거래처 없음'), code: it ? it.code : '', kind: '매입처', sold: 0, rev: 0, fees: 0, cogs: 0, margin: 0, buyQ: 0, buy: 0 }; g.buyQ += qIn - qRet; g.buy += (qIn - qRet) * l.cost;
    }
    const L = Object.values(G).sort((x, y) => (y.margin - x.margin) || (y.buy - x.buy));
    const best = L.filter(g => g.sold).sort((x, y) => y.margin - x.margin)[0], worst = L.filter(g => g.sold).sort((x, y) => x.margin - y.margin)[0];
    return H + lgPeriodBar(F) + `<div class="kgrid">${card(tab === 'item' ? '판매한 상품' : '거래처', L.filter(g => g.sold || g.buyQ).length + (tab === 'item' ? '종' : '곳'), 'acc')}${card('가장 많이 남긴 곳', best ? wonS(best.margin) : '–', 'pos', best ? best.name : '')}${card('가장 적게 남긴 곳', worst ? wonS(worst.margin) : '–', worst && worst.margin < 0 ? 'neg' : '', worst ? worst.name : '')}${card('총 마진', wonS(L.reduce((s, g) => s + g.margin, 0)), 'pos')}</div>
    ${L.length ? `<div class="tbl kh-tbl"><table><thead><tr><th class="l">${tab === 'item' ? '상품' : '거래처'}</th><th>판매</th><th>매출</th><th>수수료</th><th>매입원가</th><th>마진</th><th>마진율</th><th>매입 수량</th><th>매입 금액</th></tr></thead><tbody>${L.map(g => `<tr><td class="l name"><b>${esc(g.name)}</b>${tab === 'item' ? `<span class="code">${esc(g.code)}</span>` : ''}</td><td>${g.sold}개</td><td>${won(g.rev)}</td><td class="sub">${won(g.fees)}</td><td>${won(g.cogs)}</td><td class="${g.margin > 0 ? 'pos' : g.margin < 0 ? 'neg' : ''}"><b>${g.sold ? wonS(g.margin) : '–'}</b></td><td>${g.rev ? (g.margin / g.rev * 100).toFixed(1) + '%' : '–'}</td><td>${g.buyQ}개</td><td>${won(g.buy)}</td></tr>`).join('')}</tbody></table></div>` : `<div class="panel dl-empty">${ico('chart')}<span>이 기간에 판매 · 매입 기록이 없어요.</span></div>`}`;
  }
  // 대시보드
  const f = lgFigures(a, b), pts = lgSeries(a, b);
  return H + lgPeriodBar(F) + `<p class="lg-sec">상품 마진</p><div class="kgrid">${card('매출', won(f.rev), 'acc', f.sold + '개 판매')}${card('수수료', won(f.fees), 'violet')}${card('매입', won(f.buy), 'warn')}${card('마진 / 마진율', wonS(f.margin), f.margin >= 0 ? 'pos' : 'neg', `마진율 ${f.rate.toFixed(1)}% · 택배비 ${won(f.ship)} 포함`)}</div>
  <p class="lg-sec">현금 흐름 · 부가 비용</p><div class="kgrid lg-k5">${card('정산액', won(f.settle), 'acc')}${card('매입액', won(f.buy), 'warn')}${card('순현금', wonS(f.cash), f.cash >= 0 ? 'pos' : 'neg')}${card('수기 수입', won(f.inc), 'pos')}${card('지출 · 수기 지출', won(f.exp), f.exp ? 'neg' : '')}</div>
  <div class="box lg-cbox"><div class="lg-ch"><h3>매출 / 매입 / 마진 추이</h3><div class="lg-leg"><span><i class="r"></i>매출</span><span><i class="b"></i>매입</span><span><i class="m"></i>마진</span></div></div>${pts.length ? lgChart(pts) : '<p class="hint">기간을 골라 주세요</p>'}</div>`;
}
// ---------- 부가세 예상 ----------
function vVat() {
  const V = IS.vat; const t = today(), type = (bizCur() || {}).type || '일반';
  if (!V.year) { V.year = +t.slice(0, 4); V.half = +t.slice(5, 7) <= 6 ? 1 : 2; }
  const R = ledgerRows();
  const yearSel = `<select data-k="vatYear">${[+t.slice(0, 4), +t.slice(0, 4) - 1, +t.slice(0, 4) - 2].map(y => opt(y, y + '년', V.year === y)).join('')}</select>`;
  const salesOf = rs => rs.filter(r => ['매출', '매출반품', '할인'].includes(r.kind)).reduce((s, r) => s + r.amount, 0);
  // 상용화 점검: 면세사업자 — 부가세 신고 대상이 아니에요
  if (type === '면세') {
    const yr = R.filter(r => r.date.startsWith(V.year + '-'));
    return `${head('부가세 예상 (면세사업자)', '면세사업자는 부가세를 신고 · 납부하지 않아요.')}${flash()}
    <div class="filters">${yearSel}</div>
    <div class="panel dl-empty">${ico('percent')}<span><b>부가세 신고 대상이 아니에요.</b> 대신 다음 해 2월 10일까지 한 해 수입금액을 <b>사업장현황신고</b>로 알려요.</span></div>
    <div class="kgrid k3">${card(V.year + '년 매출 (반품 · 할인 뺀 금액)', won(salesOf(yr)), 'acc', '사업장현황신고 수입금액 참고')}</div>
    <p class="hint">사업자 유형은 왼쪽 위 사업자 이름 옆 톱니에서 바꿔요. 여기 금액은 참고용이라 실제 신고는 세무사와 확인하세요.</p>`;
  }
  const ganyi = type === '간이';
  const ms = ganyi ? [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] : typeof finVatPeriod === 'function' ? finVatPeriod(V).ms : V.half === 1 ? [1, 2, 3, 4, 5, 6] : [7, 8, 9, 10, 11, 12];
  const months = ms.map(m => {
    const k = `${V.year}-${String(m).padStart(2, '0')}`, rs = R.filter(r => r.date.startsWith(k));
    const outG = rs.reduce((s, r) => s + (r.vatOut || 0), 0), inG = rs.reduce((s, r) => s + (r.vatIn || 0), 0);
    // 일반: 부가세 포함 금액 ÷ 11 · 간이: 과세 매출(공급대가) × 소매 부가가치율 15% × 10% − 증빙 있는 매입(공급대가) × 0.5%
    return { m, outG, inG, sales: salesOf(rs), outT: Math.round(ganyi ? outG * 0.015 : outG / 11), inT: Math.round(ganyi ? inG * 0.005 : inG / 11) };
  });
  const so = months.reduce((s, x) => s + x.outT, 0), si = months.reduce((s, x) => s + x.inT, 0), mx = Math.max(1, ...months.flatMap(x => [x.outT, x.inT]));
  const bars = `<div class="mgrid">${months.map(x => `<div class="box"><h3>${x.m}월</h3><div class="vbar"><span style="width:${x.outT / mx * 100}%" class="vo"></span></div><div class="small">${ganyi ? '매출 기준 세액' : '매출세액'} ${won(x.outT)}</div><div class="vbar"><span style="width:${x.inT / mx * 100}%" class="vi"></span></div><div class="small">${ganyi ? '매입 공제' : '매입세액'} ${won(x.inT)}</div>${x.outT || x.inT ? `<b class="${x.outT - x.inT > 0 ? 'neg' : 'pos'}">${x.outT - x.inT > 0 ? '납부' : ganyi ? '공제' : '환급'} ${won(Math.abs(x.outT - x.inT))}</b>` : '<b class="small">기록 없음</b>'}</div>`).join('')}</div>`;
  if (ganyi) {
    const outGs = months.reduce((s, x) => s + x.outG, 0), salesY = months.reduce((s, x) => s + x.sales, 0), pay = Math.max(0, so - si), free = salesY < 48000000;
    return `${head('부가세 예상 (간이과세자)', '간이과세자는 1년(1~12월)에 한 번, 다음 해 1월에 신고해요. 매출에 업종 부가가치율(소매 15%)과 10%를 곱하고, 증빙 있는 매입의 0.5%를 빼서 계산해요.')}${flash()}
    <div class="filters">${yearSel}</div>
    <div class="kgrid">${card('과세 매출 (공급대가)', won(outGs), '', '과세 매출처 판매금액 (부가세 포함)')}${card('매출 기준 세액', won(so), '', '과세 매출 × 15% × 10%')}${card('매입 공제', won(si), '', '과세 매입처 매입 + 수수료 + 증빙 있는 수기 지출 × 0.5%')}${card(free ? '납부 면제 예상' : '납부 예상', won(free ? 0 : pay), free ? 'pos' : pay ? 'neg' : 'pos', free ? `한 해 매출 ${won(salesY)} — 4,800만 원 미만이에요` : so < si ? '공제가 더 커도 간이과세자는 환급이 없어요' : '매출 기준 세액 − 매입 공제')}</div>
    <p class="hint">${free ? '<b>한 해 공급대가(부가세 포함 매출) 합계가 4,800만 원 미만이면 납부 의무가 면제돼요.</b> 신고는 해야 해요. ' : `한 해 매출 ${won(salesY)} — 4,800만 원 미만이면 납부가 면제돼요. `}7월에 직전 세액의 절반이 예정 고지될 수 있어요.</p>
    ${bars}
    <p class="hint">결제수단을 '부가세 증빙 없음'으로 둔 매입은 공제에서 빠져요. 여기 금액은 참고용 추정치라 실제 신고는 세무사와 확인하세요.</p>`;
  }
  if (typeof finVatGeneral === 'function') return finVatGeneral(V, R, yearSel, bars);   // 개선판 1-9: 신고 기간 · 항목별 공급가액/세액 · D-day · 엑셀 (fin.js)
  const diff = so - si;
  return `${head('부가세 예상 (일반과세자)', '반기마다 매출세액(판매할 때 받은 부가세)과 매입세액(사거나 수수료 낼 때 낸 부가세)을 비교해요.')}${flash()}
  <div class="filters">${yearSel}<select data-k="vatHalf">${opt(1, '상반기 (1~6월)', V.half === 1)}${opt(2, '하반기 (7~12월)', V.half === 2)}</select></div>
  <div class="kgrid k3">${card('매출세액', won(so), '', '과세 매출처 판매금액 ÷ 11')}${card('매입세액', won(si), '', '과세 매입처 매입 + 과세 매출처 수수료 + 증빙 있는 수기 지출 ÷ 11')}${card(diff >= 0 ? '납부 예상' : '환급 예상', won(Math.abs(diff)), diff >= 0 ? 'neg' : 'pos', diff >= 0 ? '매출세액이 더 많아요' : '매입세액이 더 많아서 돌려받아요')}</div>
  ${bars}
  <p class="hint">포이즌처럼 '영세'로 둔 매출처(수출)는 매출세액이 0원이라 매입세액만큼 환급에 유리해요(영세 매출처 수수료는 매입세액에 안 넣어요). 결제수단을 '부가세 증빙 없음'으로 둔 매입은 매입세액에서 빠져요. 여기 금액은 참고용 추정치라 실제 신고는 세무사와 확인하세요.</p>`;
}

// ---------- 백업 · 초기화 ----------
function vReset() {
  return `${head('백업 · 초기화', '재고관리 데이터는 이 PC 킥스캔에만 저장돼요. 정기적으로 백업 파일을 받아 두세요.')}${flash()}
  <div class="igrid2"><div class="panel"><h2>백업</h2><p class="hint">상품·재고·입출고·장부·기본정보 전부를 파일 하나로 받아요${BIZ.list.length > 1 ? ` (사업자 ${BIZ.list.length}곳 모두)` : ''}. 다른 PC에서 '백업 불러오기'로 그대로 옮길 수 있어요.</p>
      <div class="row-btns"><button type="button" class="primary" data-a="backup">백업 파일 받기</button><label class="ghost filebtn">백업 불러오기<input type="file" accept=".json" data-k="restore" hidden></label></div></div>
    <div class="panel"><h2>데이터 초기화</h2><p class="hint neg">되돌릴 수 없어요.${BIZ.list.length > 1 ? ` 지금 사업자(${esc(bizCur().name)})만 지워요.` : ''}</p>
      <label class="chk"><input type="radio" name="rs" value="all" data-k="rsKind"${IS.rs === 'all' ? ' checked' : ''}> 상품 + 재고 전체 삭제 <span class="small">(기본정보는 남아요)</span></label>
      <label class="chk"><input type="radio" name="rs" value="stock" data-k="rsKind"${IS.rs === 'stock' ? ' checked' : ''}> 재고만 삭제 <span class="small">(상품은 남기고 입출고·장부 기록 삭제 — 새 시즌 시작할 때)</span></label>
      <label class="chk"><input type="radio" name="rs" value="base" data-k="rsKind"${IS.rs === 'base' ? ' checked' : ''}> 기본정보만 처음 상태로</label>
      <label class="chk"><input type="checkbox" data-k="rsBk"${IS.rsBk !== false ? ' checked' : ''}> 지우기 전에 지금 데이터를 백업 파일로 받기</label>
      <label>확인 문구 입력 — <b>${{ all: '전체삭제', stock: '재고삭제', base: '삭제' }[IS.rs || 'all']}</b><input data-k="rsText" autocomplete="off"></label>
      <div class="row-btns"><button type="button" class="primary danger" data-a="resetRun">삭제 실행</button></div></div></div>`;
}

// ---------- 대화창 ----------
function invDialog(title, bodyHTML, onOk, okLabel = '저장') {
  const d = $('#invDlg');
  d.innerHTML = `<form method="dialog" class="dlg"><h3>${esc(title)}</h3><div class="dlg-body">${bodyHTML}</div><p class="hint neg dlg-msg"></p><div class="row-btns end"><button value="cancel" class="ghost" formnovalidate>취소</button><button value="ok" class="primary">${esc(okLabel)}</button></div></form>`;
  const f = d.querySelector('form');
  f.addEventListener('submit', async e => {
    if (e.submitter && e.submitter.value === 'cancel') return;
    e.preventDefault();
    const err = await onOk(Object.fromEntries(new FormData(f)), f);
    if (err) { f.querySelector('.dlg-msg').textContent = err; return; }
    d.close();
  });
  d.showModal();
  const first = f.querySelector('input:not([readonly]),select'); if (first) first.focus();
}
function partnerDialog(p) {
  const P = p || { kind: 'buy', name: '', biz: '', tax: '과세', feeMode: 'custom', feeRate: 0, feeFix: 0, vat: '포함', returnDays: INV.opt.returnDays };
  invDialog(p ? '거래처 수정' : '거래처 추가', `<div class="dgrid">
    <label>구분${p ? ' (등록 후 못 바꿔요)' : ''}<select name="kind"${p ? ' disabled' : ''}>${opt('buy', '매입처 (사 오는 곳)', P.kind === 'buy')}${opt('sell', '매출처 (파는 곳)', P.kind === 'sell')}</select></label>
    <label>거래처명 *<input name="name" required value="${esc(P.name)}"></label>
    <label>상호 (사업자 이름)<input name="biz" value="${esc(P.biz || '')}"></label>
    <label>과세 구분<select name="tax">${['과세', '영세', '면세'].map(t => opt(t, t === '영세' ? '영세 (수출 · 포이즌 등)' : t, P.tax === t)).join('')}</select></label>
    <label data-buy>반품 기한 (입고일부터, 일)<input type="number" min="0" name="returnDays" value="${P.returnDays ?? INV.opt.returnDays}"></label>
    <label data-sell>수수료 방식<select name="feeMode">${opt('kream', '크림 (설정의 계산식)', P.feeMode === 'kream')}${opt('custom', '직접 입력', P.feeMode === 'custom')}${opt('none', '수수료 없음', P.feeMode === 'none')}</select></label>
    <label data-sell>수수료율 (%)<input type="number" step="0.1" min="0" name="feeRate" value="${P.feeRate ?? 0}"></label>
    <label data-sell>고정 수수료 (원)<input type="number" min="0" name="feeFix" value="${P.feeFix ?? 0}"></label>
    <label data-sell>VAT<select name="vat">${opt('포함', 'VAT 포함 (위 금액 그대로)', P.vat !== '별도')}${opt('별도', 'VAT 별도 (위 금액 + 10%)', P.vat === '별도')}</select></label></div>`, async fd => {
    const name = String(fd.name || '').trim(); if (!name) return '거래처명을 넣어 주세요';
    if (INV.partners.some(x => x.name === name && x !== p)) return '같은 이름의 거래처가 있어요';
    const kind = p ? p.kind : fd.kind;
    const o = p || { id: uid() };
    Object.assign(o, { kind, name, biz: fd.biz || '', tax: fd.tax || '과세' });
    if (kind === 'buy') o.returnDays = Math.max(0, Math.round(num(fd.returnDays)));
    else Object.assign(o, { feeMode: fd.feeMode, feeRate: num(fd.feeRate), feeFix: num(fd.feeFix), vat: fd.vat });
    if (!p) INV.partners.push(o);
    await invSave(); IS.msg = `${name} 저장했어요`; renderInv();
  });
  const dlg = $('#invDlg'), k = dlg.querySelector('[name=kind]');
  const sync = () => { const sell = (p ? p.kind : k.value) === 'sell'; dlg.querySelectorAll('[data-sell]').forEach(e => e.hidden = !sell); dlg.querySelectorAll('[data-buy]').forEach(e => e.hidden = sell); };
  k.addEventListener('change', sync); sync();
}

// ---------- 이벤트 ----------
async function invAct(a, el) {
  const id = el.dataset.id, C = invCalc();
  IS.msg = '';
  if (a.startsWith('ana') && typeof anaAct === 'function') return anaAct(a, el);   // 개선판 1-8: 분석 (ana.js)
  if (a.startsWith('stk') && typeof stkAct === 'function') return stkAct(a, el);
  if (a.startsWith('sl') && typeof slAct === 'function') return slAct(a, el);
  if (a.startsWith('sto') && typeof stoAct === 'function') return stoAct(a, el);
  if (a.startsWith('vp') && typeof vpAct === 'function') return vpAct(a, el);
  if (a.startsWith('hm') && typeof hmAct === 'function') return hmAct(a, el);   // 11/22: 홈 카드 (home.js)
  if (a.startsWith('tb') && typeof tbAct === 'function') return tbAct(a, el);   // 11/25: 오늘 살 것 (todaybuy.js)
  if (a.startsWith('rl') && typeof rlAct === 'function') return rlAct(a, el);   // 11/25: 발매 (drops.js)
  if (a.startsWith('ev') && typeof evAct === 'function') return evAct(a, el);   // 11/22: 행사 (events.js)   // 11/22: 부가세 하위 탭 (vatplus.js)   // 11/22: 보관 판매 (storage.js)   // 11/22: 일반 판매 (sell.js)   // 11/22: 재고 (stock.js · 줍픽 재고)
  switch (a) {
    case 'nav': return go(el.dataset.v);
    case 'ordQuick': {
      if (!HAS_CHROME || !chrome.scripting) { IS.msg = '킥스캔 안에서만 돼요'; return renderInv(); }
      IS.msg = '구매처 주문을 불러오는 중이에요… 사이트마다 작은 창이 열렸다 닫혀요. 끝나면 여기에 재고가 보여요.'; renderInv();
      return queueJob(async () => { const r = await ordSync({ auto: true, quiet: true }); IS.msg = IS.ms.msg || (r ? `자동 입고 ${r.auto}건` : ''); if (r && r.left) IS.msg += ` — 품번·사이즈를 못 읽은 ${r.left}건은 '구매처 주문 입고'에서 확인해 주세요`; renderInv(); }, { label: '구매처 주문 동기화' });
    }
    case 'sendMobile': { await sendToWeb(false); IS.msg = ($('#sendMsg') && $('#sendMsg').textContent) || ''; return renderInv(); }
    case 'quick': IS.io.mode = el.dataset.v; IS.io.msg = ''; return go('io');
    case 'baseTab': IS.base = el.dataset.v; return renderInv();
    case 'partnerEdit': return partnerDialog(partnerOf(id));
    case 'partnerDel': {
      const p = partnerOf(id);
      if (INV.lots.some(l => l.partnerId === id) || INV.outs.some(o => o.partnerId === id)) { IS.msg = `${p.name}은(는) 입출고 기록이 있어서 못 지워요`; return renderInv(); }
      return invDialog('거래처 삭제', `<p>${esc(p.name)}을(를) 지울까요?</p>`, async () => { INV.partners = INV.partners.filter(x => x !== p); await invSave(); renderInv(); }, '삭제');
    }
    case 'catDel': { const c = el.dataset.c; if (INV.items.some(i => i.cat === c)) { IS.msg = `'${c}' 분류를 쓰는 상품이 있어서 못 지워요`; return renderInv(); } delete INV.cats[c]; await invSave(); return renderInv(); }
    case 'subDel': { const c = el.dataset.c, s = el.dataset.s; INV.cats[c] = INV.cats[c].filter(x => x !== s); await invSave(); return renderInv(); }
    case 'brandDel': INV.brands = INV.brands.filter(x => x !== el.dataset.s); await invSave(); return renderInv();
    case 'payEdit': {
      const p = payOf(id) || { type: '카드', name: '', last4: '', proof: true };
      return invDialog(id ? '결제수단 수정' : '결제수단 추가', `<div class="dgrid"><label>종류<select name="type">${['카드', '계좌', '현금', '포인트·적립금'].map(t => opt(t, t, p.type === t)).join('')}</select></label><label>이름 *<input name="name" required value="${esc(p.name)}" placeholder="예: 현대카드, 신한 사업자통장"></label><label>카드사 (카드일 때)<select name="issuer">${['', '신한', '삼성', '현대', 'KB국민', '롯데', '하나', '우리', 'BC', 'NH농협', 'IBK기업', '기타'].map(t => opt(t, t || '선택 안 함', (p.issuer || '') === t)).join('')}</select></label><label>끝 4자리 (선택)<input name="last4" maxlength="4" inputmode="numeric" value="${esc(p.last4 || '')}"></label><label>부가세 증빙<select name="proof">${opt('1', '있음 (카드·현금영수증·세금계산서)', p.proof !== false)}${opt('0', '없음 (매입세액 공제 안 됨)', p.proof === false)}</select></label></div>`, async fd => {
        const name = String(fd.name || '').trim(); if (!name) return '이름을 넣어 주세요';
        const last4 = String(fd.last4 || '').replace(/\D/g, '').slice(-4);
        const o = payOf(id) || { id: uid() }; Object.assign(o, { type: fd.type, name, last4, issuer: fd.type === '카드' ? String(fd.issuer || '') : '', proof: fd.proof !== '0' });
        if (!payOf(id)) INV.pays.push(o); await invSave(); renderInv();
      });
    }
    case 'payDel': { if (INV.lots.some(l => l.payId === id) || INV.ledger.some(m => m.payId === id)) { IS.msg = '이 결제수단을 쓴 기록이 있어서 못 지워요'; return renderInv(); } INV.pays = INV.pays.filter(x => x.id !== id); await invSave(); return renderInv(); }
    case 'courierEdit': {
      const c = INV.couriers.find(x => x.id === id) || { name: '', box: { 극소: '', 소: '', 중: '', 대: '', 특대: '' } };
      return invDialog(id ? '택배사 수정' : '택배사 추가', `<div class="dgrid"><label class="wide">택배사명 *<input name="name" required value="${esc(c.name)}"></label>${Object.keys(c.box).map(b => `<label>${b} 박스 (원)<input type="number" min="0" name="b_${b}" value="${esc(c.box[b])}"></label>`).join('')}</div>`, async fd => {
        const name = String(fd.name || '').trim(); if (!name) return '택배사명을 넣어 주세요';
        const o = INV.couriers.find(x => x.id === id) || { id: uid(), box: {} };
        o.name = name; for (const b of ['극소', '소', '중', '대', '특대']) o.box[b] = fd['b_' + b] === '' ? '' : num(fd['b_' + b]);
        if (!INV.couriers.includes(o)) INV.couriers.push(o); await invSave(); renderInv();
      });
    }
    case 'courierDel': INV.couriers = INV.couriers.filter(x => x.id !== id); await invSave(); return renderInv();
    case 'itemOpen': IS.items.open = IS.items.open === id ? '' : id; return renderInv();
    case 'itemEdit': return openItemDialog(itemOf(id), el.dataset.then === 'io' ? it => { IS.io.q = ''; IS.io.msg = `${itName(it)} — 사이즈를 고르세요`; ioAddRow(it, ''); } : null);
    case 'itemDel': {
      const it = itemOf(id);
      // 3.7.9: 입출고 기록이 있어도 지울 수 있어요 — 이 상품의 입고·출고 기록도 같이 지워요 (잘못 들어온 주문 정리용)
      const L = INV.lots.filter(l => l.itemId === id), O = INV.outs.filter(o => o.itemId === id);
      const nIn = L.reduce((s2, l) => s2 + l.qty, 0), nOut = O.reduce((s2, o) => s2 + o.qty, 0), fromOrd = L.filter(l => l.srcKey).length;
      const body = L.length || O.length
        ? `<p><b>${esc(itName(it))}</b> (${esc(it.code)})을(를) 지울까요?</p><p>이 상품의 <b>입고 ${L.length}건(${nIn}개)</b>${O.length ? `과 <b>출고 ${O.length}건(${nOut}개)</b>` : ''}도 같이 지워져요. 재고·매입·매출 장부에서 모두 빠지고 되돌릴 수 없어요.</p>${fromOrd ? `<p class="small">구매처 주문에서 들어온 입고 ${fromOrd}건은 기억해 둬서 다음 자동입고 때 다시 안 들어와요.</p>` : ''}`
        : `<p>${esc(itName(it))} (${esc(it.code)})을(를) 지울까요?</p>`;
      return invDialog('상품 삭제', body, async () => {
        const keys = L.map(l => l.srcKey).filter(Boolean);
        if (keys.length) INV.skipKeys = [...new Set([...(INV.skipKeys || []), ...keys])].slice(-5000);
        INV.lots = INV.lots.filter(l => l.itemId !== id); INV.outs = INV.outs.filter(o => o.itemId !== id); INV.items = INV.items.filter(x => x !== it);
        if (IS.items.open === id) IS.items.open = '';
        await invSave(); IS.msg = `${itName(it)}을(를) 지웠어요${L.length || O.length ? ` (입고 ${L.length}건${O.length ? `, 출고 ${O.length}건` : ''} 포함)` : ''}`; renderInv();
      }, '삭제');
    }
    case 'itemIn': case 'itemOut': { const it = itemOf(id); IS.io.mode = a === 'itemIn' ? 'in' : 'out'; IS.io.msg = `${itName(it)} — 사이즈를 고르세요`; ioAddRow(it, ''); return go('io'); }
    case 'sizeSortAll': INV.items.forEach(it => it.sizes.sort(sizeSort)); await invSave(); IS.msg = `상품 ${INV.items.length}종의 사이즈를 정렬했어요`; return renderInv();
    case 'itemsXl': {
      const rows = [['품번', '상품명', '브랜드', '대분류', '소분류', '사이즈', '재고', '평균 매입가', '재고 금액', '바코드']];
      for (const it of itemsFiltered(C)) { const st = itemStock(it, C); for (const s of it.sizes) { const x = st.by[s]; rows.push([it.code, it.name, it.brand, it.cat, it.sub, s, x ? x.qty : 0, x ? Math.round(x.value / x.qty) : '', x ? Math.round(x.value) : 0, (it.barcodes || {})[s] || '']); } }
      return xlDownload([{ name: '재고', rows, widths: [16, 30, 12, 8, 10, 8, 6, 12, 12, 16] }], `킥스캔_재고_${today()}.xlsx`);
    }
    case 'ioMode': IS.io.mode = el.dataset.v; IS.io.msg = ''; IS.io.partnerId = ''; saveDraft(); return renderInv();
    case 'ioBc': IS.io.bc = !IS.io.bc; IS.io.q = ''; return renderInv();
    case 'ioMulti': IS.io.multi = !IS.io.multi; return renderInv();
    case 'ioPick': { const it = itemOf(id); IS.io.q = ''; IS.io.msg = ''; ioAddRow(it, it.sizes.length === 1 ? it.sizes[0] : ''); return renderInv(); }
    case 'ioDel': IS.io.rows = IS.io.rows.filter(r => r.key !== el.dataset.i); saveDraft(); return renderInv();
    case 'ioClear': IS.io.rows = []; IS.io.msg = ''; saveDraft(); return renderInv();
    case 'ioSave': return ioSave();
    case 'ioPlanSave': return ioPlanSave();
    case 'ioBulkPrice': { const v = num(IS.io.bulkPrice); if (!v) { IS.io.msg = '적용할 매입가를 넣어 주세요'; return renderInv(); } let n = 0; for (const r of IS.io.rows) if (el.dataset.v === 'all' || !num(r.price)) { r.price = String(v); n++; } IS.io.msg = `${n}줄에 매입가 ${won(v)}을 넣었어요`; saveDraft(); return renderInv(); }
    case 'itemsTab': IS.items.tab = el.dataset.v; IS.items.only = false; return renderInv();
    case 'itemsSz': IS.items.sz = el.dataset.v; return renderInv();
    case 'itemsFold': IS.items.open = ''; return renderInv();
    case 'lgTab': IS.lg.tab = el.dataset.v; return renderInv();
    case 'lgQuickB': { const v = el.dataset.v, F = IS.lg; if (v === 'm0') { F.from = monthStart(); F.to = monthEnd(); } else if (v === 'm1') { const d = new Date(today().slice(0, 7) + '-01T00:00:00'); d.setMonth(d.getMonth() - 1); F.from = monthStart(fmtD(d)); F.to = monthEnd(fmtD(d)); } else { F.from = today().slice(0, 4) + '-01-01'; F.to = today().slice(0, 4) + '-12-31'; } F.page = 0; return renderInv(); }
    case 'planOpen': { const F = IS.plan = IS.plan || { st: 'open', partner: '', q: '', open: '', got: {} }; F.open = F.open === id ? '' : id; F.got = {}; return renderInv(); }
    case 'planConfirm': return planConfirm(id, false);
    case 'planAll': return planConfirm(id, true);
    case 'planCancel': { const P = (INV.plans || []).find(x => x.id === id); if (P) { P.status = planGot(P) ? 'done' : 'cancel'; IS.msg = planGot(P) ? `'${P.name}' 남은 수량은 안 오는 걸로 하고 입고완료로 바꿨어요` : `'${P.name}' 입고예정을 취소했어요`; await invSave(); } return renderInv(); }
    case 'planDel': INV.plans = (INV.plans || []).filter(x => x.id !== id); await invSave(); return renderInv();
    case 'lotDel': return lotDelete(id, C, m => { IS.msg = m; });
    case 'histDel': {
      if (el.dataset.k === 'lot') {
        return lotDelete(id, C, m => { IS.io.msg = m; });
      }
      const o = INV.outs.find(x => x.id === id);
      if ((o.events || []).length) { IS.io.msg = '반품·할인 처리된 출고는 못 지워요'; return renderInv(); }
      return invDialog('출고 삭제', `<p>${esc(itName(itemOf(o.itemId)))} ${esc(o.size)} ×${o.qty} 출고를 지울까요? 재고로 돌아가요.</p>`, async () => { INV.outs = INV.outs.filter(x => x !== o); await invSave(); renderInv(); }, '삭제');
    }
    case 'xlTpl': return xlTemplate();
    case 'xlAll': { const X = IS.xl; const ok = X.rows.filter(r => !r.err); const all = ok.every(r => r.sel); ok.forEach(r => r.sel = !all); return renderInv(); }
    case 'xlSave': return xlSave();
    case 'goAcct': return route('acct');
    case 'msSync': { if (!HAS_CHROME || !chrome.scripting) { IS.msg = '킥스캔 안에서만 돼요'; return renderInv(); } IS.ms.days = +(document.querySelector('[data-k=msDays]') || {}).value || 90; return queueJob(() => ordSync(), { label: '구매처 주문 동기화' }); }
    case 'msRetry': { if (!HAS_CHROME || !chrome.scripting) return; const k = el.dataset.v; if (!ORDER_SITES.some(S => S.k === k)) return; return queueJob(() => ordSync({ only: [k] }), { label: `${siteLabel(k)} 주문 다시 읽기` }); }
    case 'msLogin': return route('acct');
    case 'msAll': { const M = IS.ms; const L = ordRows().filter(x => !x.done && !x.cancel && (!M.site || x.site === M.site)); const all = L.every(x => M.sel.has(x.key)); L.forEach(x => all ? M.sel.delete(x.key) : M.sel.add(x.key)); return renderInv(); }
    case 'msSave': return msSave();
    case 'preOne': case 'preSettle': {
      const P = IS.pre; const ids = a === 'preOne' ? [id] : [...P.sel];
      const pairs = ids.map(i => [i, num(P.price[i])]);
      const miss = pairs.filter(([, p]) => !p).length;
      if (!ids.length) { IS.msg = '정산할 줄을 골라 주세요'; return renderInv(); }
      if (miss) { IS.msg = `판매가가 비어 있는 줄이 ${miss}개 있어요`; return renderInv(); }
      const n = await settleOuts(pairs, P.date || today()); ids.forEach(i => { P.sel.delete(i); delete P.price[i]; });
      IS.msg = `${n}건 정산했어요. 장부에 매출·수수료로 들어갔어요.`; return renderInv();
    }
    case 'kreamMatch': { const P = IS.pre; const rows = parseSaleLines(P.kreamText); P.kream = { rows: matchPre(rows, '크림') }; if (!rows.length) IS.msg = '읽을 줄이 없어요. 한 줄에 품번 사이즈 판매가 순서로 적어 주세요'; return renderInv(); }
    case 'kreamApply': case 'pzApply': {
      const P = IS.pre, M = a === 'kreamApply' ? P.kream : P.poizon;
      const n = await settleOuts(M.rows.filter(r => r.outId).map(r => [r.outId, r.price]), P.date || today());
      M.rows = M.rows.filter(r => !r.outId); IS.msg = `${n}건 정산했어요${M.rows.length ? ` · 못 맞춘 ${M.rows.length}줄은 남겨 뒀어요` : ''}`;
      if (a === 'kreamApply' && !M.rows.length) P.kreamText = '';
      return renderInv();
    }
    case 'retTab': IS.ret = el.dataset.v; return renderInv();
    case 'retReset': IS.rf = { q: '', partner: '', due: '', brand: '', pay: '' }; return renderInv();
    case 'preTab': IS.pre.tab = el.dataset.v; return renderInv();
    case 'lotOk': { const l = INV.lots.find(x => x.id === id); l.confirmed = true; (l.events = l.events || []).push({ t: '확정', d: today() }); await invSave(); IS.msg = `${itName(itemOf(l.itemId))} ${l.size} — 보유로 표시했어요. 반품 알림에서 빠져요 (기한 필터 '보유 표시한 것'에서 되돌릴 수 있어요)`; return renderInv(); }
    case 'lotKeepOff': { const l = INV.lots.find(x => x.id === id); if (!l) return; l.confirmed = false; (l.events = l.events || []).push({ t: '보유 해제', d: today() }); await invSave(); IS.msg = `${itName(itemOf(l.itemId))} ${l.size} — 보유를 풀었어요. 다시 반품 기한 알림에 들어가요`; return renderInv(); }
    case 'lotDue': {
      const l = INV.lots.find(x => x.id === id); if (!l) return;
      return invDialog('반품 기한 고치기', `<p class="hint">${esc(itName(itemOf(l.itemId)))} ${esc(l.size)} · 입고일 ${l.date} · 매입처 ${esc(partnerOf(l.partnerId)?.name || '없음')}</p><div class="dgrid"><label>반품 기한<input type="date" name="d" value="${esc(l.returnDue || '')}"></label></div><p class="hint">비우면 '기한 없음'이 돼요. 이 매입 하나만 바뀌고 매입처 기본값은 그대로예요.</p>`, async fd => {
        l.returnDue = fd.d || ''; await invSave(); IS.msg = l.returnDue ? `반품 기한을 ${l.returnDue}(${dday(l.returnDue) < 0 ? '지남' : 'D-' + dday(l.returnDue)})로 고쳤어요` : '반품 기한을 없앴어요'; renderInv();
      }, '저장');
    }
    case 'mktAll': invMktRefresh(); return;
    case 'mktOne': invMktRefresh([id]); return;
    case 'todo': {   // 개선판 1-4: 오늘 할 일 → 그 화면 · 필터로
      const v = el.dataset.v || '', f = el.dataset.f || '';
      if (v === 'inv:ret') { IS.ret = 'buy'; IS.rf = { q: '', partner: '', due: f, brand: '', pay: '' }; }
      if (v === 'inv:items') { IS.items.tab = f || 'all'; IS.items.only = false; }
      if (v === 'khist' && typeof XS !== 'undefined') XS.histTab = f || 'sell';
      return v.startsWith('inv:') ? go(v.slice(4)) : typeof route === 'function' ? route(v) : null;
    }
    case 'retConfirmSoon': {
      const L = INV.lots.filter(l => !l.confirmed && C.left.get(l.id) > 0 && l.returnDue && dday(l.returnDue) <= 2);
      if (!L.length) { IS.msg = '마감 임박 건이 없어요'; return renderInv(); }
      return invDialog('일괄 보유', `<p>반품 마감이 2일 이내이거나 지난 매입 ${L.length}건을 보유(반품 안 함)로 표시할까요? 반품·교환 목록과 반품 알림에서 빠져요. 기한 필터 '보유 표시한 것'에서 되돌릴 수 있어요.</p>`, async () => { L.forEach(l => { l.confirmed = true; (l.events = l.events || []).push({ t: '확정', d: today() }); }); await invSave(); IS.msg = `${L.length}건 보유로 표시했어요`; renderInv(); }, '보유');
    }
    case 'lotRet': case 'lotEx': {
      const l = INV.lots.find(x => x.id === id), max = C.left.get(id), it = itemOf(l.itemId);
      return invDialog(a === 'lotRet' ? '매입 반품' : '매입 교환 (사이즈 바꾸기)', `<p class="hint">${esc(itName(it))} ${esc(l.size)} · 남은 ${max}개</p><div class="dgrid"><label>수량<input type="number" name="q" min="1" max="${max}" value="1" required></label><label>처리일<input type="date" name="d" value="${today()}"></label>${a === 'lotEx' ? `<label class="wide">바꿀 사이즈<input name="s" list="exSizes" required><datalist id="exSizes">${it.sizes.filter(s => s !== l.size).map(s => `<option value="${esc(s)}">`).join('')}</datalist></label>` : ''}</div>`, async fd => {
        const q = Math.round(num(fd.q)); if (!(q >= 1 && q <= max)) return `1~${max}개 사이로 넣어 주세요`;
        l.events = l.events || [];
        if (a === 'lotRet') { l.retQty = (l.retQty || 0) + q; l.events.push({ t: '반품', d: fd.d || today(), q }); IS.msg = `${q}개 반품 처리했어요. 장부에 매입반품(+${won(l.cost * q)})으로 들어갔어요.`; }
        else {
          const s = String(fd.s || '').trim(); if (!s || s === l.size) return '다른 사이즈를 넣어 주세요';
          if (!it.sizes.includes(s)) it.sizes.push(s);
          l.exQty = (l.exQty || 0) + q; l.events.push({ t: '교환', d: fd.d || today(), q, to: s });
          INV.lots.push({ ...l, id: uid(), at: Date.now(), size: s, qty: q, retQty: 0, exQty: 0, events: [], src: 'exchange', exFrom: l.id, memo: `${l.size} → ${s} 교환` });
          IS.msg = `${l.size} → ${s} ${q}개 교환했어요`;
        }
        await invSave(); renderInv();
      }, a === 'lotRet' ? '반품' : '교환');
    }
    case 'outOk': { const o = INV.outs.find(x => x.id === id); o.confirmed = true; (o.events = o.events || []).push({ t: '확정', d: today() }); await invSave(); IS.msg = '판매확정했어요'; return renderInv(); }
    case 'outRet': case 'outDisc': {
      const o = INV.outs.find(x => x.id === id), n = outNums(o);
      return invDialog(a === 'outRet' ? '판매 반품 (재고로 돌아와요)' : '판매 후 할인', `<p class="hint">${esc(itName(itemOf(o.itemId)))} ${esc(o.size)} · 판매 ${n.net}개 · ${won(o.price)}</p><div class="dgrid">${a === 'outRet' ? `<label>반품 수량<input type="number" name="q" min="1" max="${n.net}" value="1"></label><label>수수료 환급<select name="fb">${opt('1', '받음 (크림 취소 등)', true)}${opt('0', '못 받음')}</select></label>` : `<label>개당 할인 금액 (원)<input type="number" name="amt" min="1" required></label><label>메모<input name="memo"></label>`}<label>처리일<input type="date" name="d" value="${today()}"></label></div>`, async fd => {
        o.events = o.events || [];
        if (a === 'outRet') {
          const q = Math.round(num(fd.q)); if (!(q >= 1 && q <= n.net)) return `1~${n.net}개 사이로 넣어 주세요`;
          const price = o.price - (o.disc || 0);
          o.retQty = (o.retQty || 0) + q;
          o.events.push({ t: '반품', d: fd.d || today(), q, total: price * q, gross: price * q, feeBack: fd.fb === '1' ? n.fee * q : 0, feeLost: fd.fb === '1' ? 0 : n.fee * q });   // feeLost: 환급 못 받은 수수료 → 마진에서 빠져요
          INV.lots.push({ id: uid(), at: Date.now(), date: fd.d || today(), itemId: o.itemId, size: o.size, qty: q, cost: Math.round(n.unitCost), partnerId: '', payId: '', memo: '판매 반품으로 돌아온 재고', src: 'return', srcKey: o.id, returnDue: '', confirmed: true, retQty: 0, exQty: 0, events: [] });
          IS.msg = `${q}개 반품 — 재고로 돌아왔어요`;
        } else {
          const amt = Math.round(num(fd.amt)); if (!(amt > 0)) return '할인 금액을 넣어 주세요';
          o.disc = (o.disc || 0) + amt; o.events.push({ t: '할인', d: fd.d || today(), q: n.net, total: amt * n.net, memo: fd.memo || '' });
          IS.msg = `개당 ${won(amt)} 할인 반영했어요`;
        }
        await invSave(); renderInv();
      }, a === 'outRet' ? '반품' : '할인 반영');
    }
    case 'manual': return invDialog('수기 입력', `<div class="dgrid"><label>구분<select name="io">${opt('out', '지출')}${opt('in', '수입')}</select></label><label>날짜<input type="date" name="date" value="${today()}"></label><label class="wide">내용 *<input name="desc" required placeholder="예: 박스·테이프 구입, 포인트 적립"></label><label>금액 (원) *<input type="number" name="amount" min="1" required></label><label>거래처<input name="partner"></label><label>결제수단<select name="payId"><option value="">–</option>${INV.pays.map(p => opt(p.id, p.name)).join('')}</select></label><label>부가세 증빙<select name="vat">${opt('0', '없음')}${opt('1', '있음 (부가세 포함 금액)')}</select></label><label class="wide">메모<input name="memo"></label></div>`, async fd => {
      const amount = Math.round(num(fd.amount)); if (!String(fd.desc || '').trim() || !(amount > 0)) return '내용과 금액을 넣어 주세요';
      INV.ledger.push({ id: uid(), date: fd.date || today(), io: fd.io, desc: fd.desc.trim(), amount, partner: fd.partner || '', payId: fd.payId || '', vat: fd.vat === '1', memo: fd.memo || '' });
      await invSave(); IS.msg = '장부에 넣었어요'; renderInv();
    });
    case 'manualDel': INV.ledger = INV.ledger.filter(m => m.id !== id); await invSave(); return renderInv();
    case 'lgPage': IS.lg.page = Math.max(0, IS.lg.page + +el.dataset.v); return renderInv();
    case 'ledgerXl': {
      const F = IS.lg; const R = ledgerRows().filter(r => inRange(r.date, F.from, F.to) && (!F.kind || r.kind.startsWith(F.kind)) && (!F.partner || r.partner === F.partner) && (!F.pay || r.payId === F.pay));
      return xlDownload([{ name: '장부', rows: [['날짜', '구분', '내용', '거래처', '결제수단', '금액', '메모'], ...R.map(r => [r.date, r.kind, r.desc, r.partner, r.pay, r.amount, r.memo])], widths: [12, 10, 40, 14, 14, 12, 24] }], `킥스캔_장부_${F.from}_${F.to}.xlsx`);
    }
    case 'backup': return invBackupDownload('');
    case 'resetRun': {
      const kind = IS.rs || 'all', need = { all: '전체삭제', stock: '재고삭제', base: '삭제' }[kind];
      if ((IS.rsText || '').trim() !== need) { IS.msg = `확인 문구 '${need}'를 정확히 넣어 주세요`; return renderInv(); }
      const bk = IS.rsBk !== false; if (bk) await invBackupDownload('초기화전');   // 상용화 점검: 지우기 전에 자동 백업
      const D = INV_DEF();
      if (kind === 'all') Object.assign(INV, { items: [], lots: [], outs: [], ledger: [], expenses: [], poizonMap: {}, skipKeys: [], plans: [] });
      else if (kind === 'stock') Object.assign(INV, { lots: [], outs: [], ledger: [], expenses: [], skipKeys: [], plans: [] });
      else Object.assign(INV, { partners: D.partners.concat(INV.partners.filter(p => !D.partners.some(d => d.id === p.id) && (INV.lots.some(l => l.partnerId === p.id) || INV.outs.some(o => o.partnerId === p.id)))), pays: INV.pays.filter(p => INV.lots.some(l => l.payId === p.id)), couriers: D.couriers, cats: D.cats, brands: D.brands, opt: D.opt });
      IS.rsText = ''; await invSave(); IS.msg = (bk ? '지우기 전 데이터를 백업 파일로 받았어요. ' : '') + (kind === 'base' ? '기본정보를 처음 상태로 돌렸어요 (기록에 쓰인 거래처·결제수단은 남겨요)' : '삭제했어요');
      return renderInv();
    }
    default: if (typeof finAct === 'function') return finAct(a, el, C);   // 개선판 1-9·1-10 (fin.js)
  }
}
async function invInput(el, ev) {
  const k = el.dataset.k, v = el.type === 'checkbox' ? el.checked : el.value;
  const live = ev.type === 'input';
  if (k.startsWith('ana') && typeof anaInput === 'function') return anaInput(el, ev);
  if (k.startsWith('stk') && typeof stkInput === 'function') return stkInput(el, ev);
  if (k.startsWith('sl') && typeof slInput === 'function') return slInput(el, ev);
  if (k.startsWith('rl') && typeof rlInput === 'function') return rlInput(el, ev);
  if (k.startsWith('tb') && typeof tbInput === 'function') return tbInput(el, ev);   // 11/25: 오늘 살 것 필터
  if (k.startsWith('ev') && typeof evInput === 'function') return evInput(el, ev);
  switch (k) {
    case 'itemsQ': IS.items.q = v; if (live) { clearTimeout(invInput.t); invInput.t = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=itemsQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, 250); } return;
    case 'itemsBrand': IS.items.brand = v; break;
    case 'lgYear': { const F = IS.lg, m = F.from.slice(5, 7), whole = F.from.slice(5) === '01-01' && F.to.slice(5) === '12-31'; if (whole) { F.from = v + '-01-01'; F.to = v + '-12-31'; } else { F.from = monthStart(v + '-' + m + '-01'); F.to = monthEnd(F.from); } F.page = 0; break; }
    case 'lgMonth': { const F = IS.lg, y = F.from.slice(0, 4); if (!v) { F.from = y + '-01-01'; F.to = y + '-12-31'; } else { F.from = monthStart(y + '-' + String(v).padStart(2, '0') + '-01'); F.to = monthEnd(F.from); } F.page = 0; break; }
    case 'planGot': { const F = IS.plan = IS.plan || {}; (F.got = F.got || {})[el.dataset.i] = v; return; }
    case 'planDate': (IS.plan = IS.plan || {}).date = v; return;
    case 'planSt': IS.plan.st = v; break;
    case 'planPartner': IS.plan.partner = v; break;
    case 'preQ': IS.pre.q = v; if (live) { clearTimeout(invInput.pq2); invInput.pq2 = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=preQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, 250); } return;
    case 'retBrand': (IS.rf = IS.rf || {}).brand = v; break;
    case 'retPay': (IS.rf = IS.rf || {}).pay = v; break;
    case 'mktAlert': { const it = itemOf(el.dataset.id); if (it) it.alertWon = Math.max(0, Math.floor(+v || 0)); if (live) return; await invSave(); await invMktCheck(); break; }
    case 'retPartner': (IS.rf = IS.rf || {}).partner = v; break;
    case 'retDue': (IS.rf = IS.rf || {}).due = v; break;
    case 'retQ': (IS.rf = IS.rf || {}).q = v; if (live) { clearTimeout(invInput.rq); invInput.rq = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=retQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, 250); } return;
    case 'planQ': IS.plan.q = v; if (live) { clearTimeout(invInput.pq); invInput.pq = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=planQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, 250); } return;
    case 'itemsCat': IS.items.cat = v; break;
    case 'itemsOnly': IS.items.only = v; break;
    case 'stockSet': {
      if (live) return; const it = itemOf(el.dataset.id); const d = await stockSet(el.dataset.id, el.dataset.s, v);
      IS.msg = d ? `${itName(it)} ${el.dataset.s} 재고를 ${Math.max(0, Math.floor(+v || 0))}개로 고쳤어요 (${d > 0 ? '+' : ''}${d})` : ''; return renderInv();
    }
    case 'bc': {
      if (live) return; const it = itemOf(el.dataset.id); it.barcodes = it.barcodes || {}; it.barcodes[el.dataset.s] = v.trim(); await invSave();
      const cnt = {}; for (const x of INV.items) for (const b of Object.values(x.barcodes || {})) if (b) cnt[b] = (cnt[b] || 0) + 1;
      document.querySelectorAll('[data-k=bc]').forEach(e => e.classList.toggle('dup', !!e.value && cnt[e.value.trim()] > 1));
      return;
    }
    case 'opt': if (live) return; INV.opt[el.dataset.o] = Math.max(0, Math.round(num(v))); await invSave(); return;
    case 'io': IS.io[el.dataset.f] = v; saveDraft(); if (live) return; break;
    case 'ioRow': {
      const r = IS.io.rows.find(x => x.key === el.dataset.i); if (!r) return; r[el.dataset.f] = v; saveDraft();
      if (el.dataset.f === 'size' && !live) break;
      // 칸을 옮겨 다닐 때 화면을 다시 그리면 커서가 사라져서, 합계만 고쳐요
      const io = IS.io, sum = $('#ioSum'); if (sum) sum.textContent = `${io.rows.length}줄 · ${io.rows.reduce((t, x) => t + (+x.qty || 0), 0)}개${io.mode === 'pre' ? '' : ` · 합계 ${won(io.rows.reduce((t, x) => t + num(x.price) * (+x.qty || 0), 0))}`}`;
      return;
    }
    case 'ioQ': {
      IS.io.q = v; if (IS.io.bc || !live) return;
      clearTimeout(invInput.t); invInput.t = setTimeout(() => { renderInv(); const e = $('#ioQ'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, 200); return;
    }
    case 'xlRow': { const r = IS.xl.rows.find(x => x.k === el.dataset.i); r[el.dataset.f] = el.dataset.f === 'cost' ? (priceBlank(v) ? '' : num(v)) : v; if (el.dataset.f === 'cost') { const tr = el.closest('tr'); if (tr && !r.err) tr.classList.toggle('warn', r.cost === ''); } if (live || el.dataset.f !== 'sel') return; break; }
    case 'xlBulk': { if (live || !v) return; IS.xl.rows.filter(r => r.sel && !r.err).forEach(r => r[el.dataset.f] = v); break; }
    case 'xlFile': if (el.files[0]) return xlLoad(el.files[0]); return;
    case 'ms': IS.ms[el.dataset.f] = v; break;
    case 'msSel': { v ? IS.ms.sel.add(el.dataset.i) : IS.ms.sel.delete(el.dataset.i); const b = document.querySelector('[data-a=msSave]'); if (b) b.textContent = `선택 ${ordRows().filter(x => !x.done && !x.cancel && IS.ms.sel.has(x.key)).length}건 입고 등록`; return; }
    case 'ordSite': v ? IS.ms.sites.add(el.dataset.i) : IS.ms.sites.delete(el.dataset.i); INV.opt.ordSites = [...IS.ms.sites]; await invSave(); return;
    case 'autoIn': INV.opt.autoIn = v; await invSave(); IS.msg = v ? '이제 동기화하면 품번·사이즈·매입가를 읽은 주문은 바로 입고해요' : '자동 입고를 껐어요'; break;
    case 'autoHours': INV.opt.autoHours = +v; await invSave(); await setOrderAlarm(); IS.msg = +v ? `${+v}시간마다 구매처 주문을 확인해요${INV.opt.autoIn ? ' (자동 입고 켜짐)' : ' — 바로 재고에 넣으려면 \'동기화하면 바로 재고에 넣기\'도 켜 주세요'}` : '자동 동기화를 껐어요'; break;
    case 'ordCancel': IS.ms.showCancel = v; break;
    case 'ordEdit': { (IS.ms.edit[el.dataset.i] = IS.ms.edit[el.dataset.i] || {})[el.dataset.f] = v; return; }
    case 'msDays': IS.ms.days = +v; IS.ms.full = true; return;
    case 'preDate': IS.pre.date = v; return;
    case 'prePrice': {
      IS.pre.price[el.dataset.i] = v; if (live) return;
      if (num(v)) { IS.pre.sel.add(el.dataset.i); const c = document.querySelector(`[data-k=preSel][data-i="${el.dataset.i}"]`); if (c) c.checked = true; }
      const o = INV.outs.find(x => x.id === el.dataset.i), cell = document.querySelector(`[data-mg="${el.dataset.i}"]`);
      if (o && cell) { const n = outNums(o), pr = num(v), mg = pr ? (pr - partnerFee(partnerOf(o.partnerId), pr, itemOf(o.itemId))) * o.qty - n.cogs - n.ship : null; cell.textContent = mg == null ? '–' : wonS(mg); cell.className = mg > 0 ? 'pos' : mg < 0 ? 'neg' : ''; }
      const b = document.querySelector('[data-a=preSettle]'); if (b) b.textContent = `선택 ${IS.pre.sel.size}건 정산`;
      return;
    }
    case 'preSel': { v ? IS.pre.sel.add(el.dataset.i) : IS.pre.sel.delete(el.dataset.i); const b = document.querySelector('[data-a=preSettle]'); if (b) b.textContent = `선택 ${IS.pre.sel.size}건 정산`; return; }
    case 'preAll': INV.outs.filter(o => o.kind === 'pre' && !o.settled).forEach(o => v ? IS.pre.sel.add(o.id) : IS.pre.sel.delete(o.id)); break;
    case 'kreamText': IS.pre.kreamText = v; return;
    case 'pzFile': if (el.files[0]) return pzLoad(el.files[0]); return;
    case 'pzLink': { if (!v) return; INV.poizonMap[codeKey(el.dataset.c)] = v; await invSave(); const M = IS.pre.poizon; M.rows.forEach(r => { if (codeKey(r.code) === codeKey(el.dataset.c)) r.itemId = v; }); matchPre(M.rows.filter(r => !r.outId), '포이즌'); break; }
    case 'lg': IS.lg[el.dataset.f] = v; IS.lg.page = 0; if (live && el.type !== 'date') return; break;
    case 'lgQuick': { if (v[0] === 'm') { IS.lg.from = monthStart(v.slice(1)); IS.lg.to = monthEnd(v.slice(1)); } else if (v[0] === 'y') { IS.lg.from = v.slice(1) + '-01-01'; IS.lg.to = v.slice(1) + '-12-31'; } IS.lg.page = 0; break; }
    case 'lgSize': IS.lg.size = +v; IS.lg.page = 0; break;
    case 'vatYear': IS.vat.year = +v; break;
    case 'vatHalf': IS.vat.half = +v; break;
    case 'rsKind': IS.rs = v; break;
    case 'rsText': IS.rsText = v; return;
    case 'rsBk': IS.rsBk = !!v; return;
    case 'restore': {
      const f = el.files[0]; if (!f) return;
      try {
        const o = JSON.parse(await f.text());
        // 상용화 점검: 새 백업(v2)은 사업자 전부(biz + invs), 옛 백업은 사업자 하나(inv)예요 — 둘 다 불러와요
        const multi = !!(o && o.invs && o.biz && Array.isArray(o.biz.list) && o.biz.list.length && o.biz.list.every(b => b && b.id && (o.invs[b.id] == null || Array.isArray(o.invs[b.id].items))));
        if (!o || (!multi && !(o.inv && Array.isArray(o.inv.items)))) throw new Error('킥스캔 재고관리 백업 파일이 아니에요');
        const what = multi ? `사업자 ${o.biz.list.length}곳(${o.biz.list.map(b => b.name).join(', ')})의 데이터` : (BIZ.list.length > 1 ? `지금 사업자(${bizCur().name}) 데이터` : '지금 데이터');
        return invDialog('백업 불러오기', `<p>${esc(f.name)} (${esc(String(o.at || '').slice(0, 10))})으로 ${esc(what)}를 <b>모두 바꿀까요?</b> 지금 데이터는 사라져요.</p><label class="chk"><input type="checkbox" name="bk" value="1" checked> 지금 데이터를 먼저 백업 파일로 받기</label>`, async fd => {
          if (fd.bk) await invBackupDownload('불러오기전');
          if (multi) {
            for (const b of o.biz.list) { const d = o.invs[b.id]; await store.set(b.id === 'main' ? 'inv' : 'inv@' + b.id, d && Array.isArray(d.items) ? d : null); }
            BIZ = { list: o.biz.list.map(b => ({ ...b })), cur: o.biz.list.some(b => b.id === o.biz.cur) ? o.biz.cur : o.biz.list[0].id };
            await store.set('biz', BIZ); await invLoad();
          } else { INV = Object.assign(INV_DEF(), o.inv); INV.opt = Object.assign(INV_DEF().opt, INV.opt || {}); await invSave(); }
          Object.assign(IS.io, { rows: [], q: '', msg: '' }); IS.items.open = ''; IS.plan = null;
          IS.msg = `${fd.bk ? '지금 데이터를 백업 파일로 받아 두고 ' : ''}백업을 불러왔어요 — ${multi ? `사업자 ${BIZ.list.length}곳 · 지금 '${bizCur().name}' ` : ''}상품 ${INV.items.length}종`; renderInv();
        }, '바꾸기');
      } catch (e) { IS.msg = '불러오기 실패: ' + e.message; }
      break;
    }
    default: if (!(typeof finInput === 'function' && await finInput(el, k, v, live))) return;   // 개선판 1-9·1-10 (fin.js)
  }
  renderInv();
}
async function invKey(el, ev) {
  const k = el.dataset.k;
  if (ev.key !== 'Enter' && !(k === 'ioQ' && ev.key === 'Escape')) return;
  if (['catAdd', 'subAdd', 'brandAdd'].includes(k)) {
    ev.preventDefault(); const v = el.value.trim(); if (!v) return;
    if (k === 'catAdd') { if (!INV.cats[v]) INV.cats[v] = []; }
    else if (k === 'subAdd') { const c = el.dataset.c; if (!INV.cats[c].includes(v)) INV.cats[c].push(v); }
    else if (!INV.brands.includes(v)) INV.brands.push(v);
    await invSave(); renderInv();
    const again = document.querySelector(`[data-k="${k}"]${el.dataset.c ? `[data-c="${CSS.escape(el.dataset.c)}"]` : ''}`); if (again) again.focus();
    return;
  }
  if (k !== 'ioQ') return;
  ev.preventDefault();
  const io = IS.io;
  if (ev.key === 'Escape') { io.bc = false; io.q = ''; return renderInv(); }
  const q = el.value.trim(); if (!q) return;
  if (io.bc) {
    const hit = findBarcode(q);
    if (hit) { ioAddRow(hit.it, hit.size); io.msg = `✓ ${itName(hit.it)} ${hit.size}`; beep(true); }
    else { io.msg = `모르는 바코드 ${q} — 상품 · 재고에서 사이즈 칸에 바코드를 넣어 주세요`; beep(false); }
    io.q = ''; renderInv(); const e = $('#ioQ'); if (e) e.focus(); return;
  }
  const exact = INV.items.find(it => codeKey(it.code) === codeKey(q)) || (findBarcode(q) || {}).it;
  const it = exact || ioSearch(q)[0];
  if (!it) { io.msg = `'${q}' 상품이 없어요. 새 상품으로 등록하세요`; return renderInv(); }
  const bc = findBarcode(q);
  ioAddRow(it, bc ? bc.size : it.sizes.length === 1 ? it.sizes[0] : ''); io.q = ''; io.msg = ''; renderInv();
  const e = $('#ioQ'); if (e) e.focus();
}

// ---------- 3.38: 보유 재고 상품 사진 ----------
// 1순위 구매처 주문의 상품 사진 → 같은 품번의 크림 상품 사진 → 브랜드 로고 → (없으면) 글자.
// 찾은 주소는 상품(it.img · it.imgSrc)에 저장해서 다음부터는 다시 찾지 않아요. 로고 · 글자인 상품은 7일 뒤에 한 번 더 찾아봐요.
const INV_BRAND_DOM = { '나이키': 'nike.com', nike: 'nike.com', '아디다스': 'adidas.com', adidas: 'adidas.com', '뉴발란스': 'newbalance.com', 'new balance': 'newbalance.com', '아식스': 'asics.com', asics: 'asics.com',
  '푸마': 'puma.com', puma: 'puma.com', '컨버스': 'converse.com', converse: 'converse.com', '반스': 'vans.com', vans: 'vans.com', '팀버랜드': 'timberland.com', timberland: 'timberland.com', '살로몬': 'salomon.com', salomon: 'salomon.com',
  '호카': 'hoka.com', hoka: 'hoka.com', '온러닝': 'on.com', '노스페이스': 'thenorthface.com', 'the north face': 'thenorthface.com', '아크테릭스': 'arcteryx.com', 'arcteryx': 'arcteryx.com', '파타고니아': 'patagonia.com',
  '47브랜드': '47brand.com', '47brand': '47brand.com', 'mlb': 'mlb-korea.com', '엠엘비': 'mlb-korea.com', '마뗑킴': 'matinkim.com', 'matin kim': 'matinkim.com', 'ami': 'amiparis.com', '아미': 'amiparis.com', '무신사': 'musinsa.com', '무신사 스탠다드': 'musinsa.com',
  '스투시': 'stussy.com', stussy: 'stussy.com', '슈프림': 'supremenewyork.com', supreme: 'supremenewyork.com', '오니츠카타이거': 'onitsukatiger.com', '리복': 'reebok.com', reebok: 'reebok.com', '휠라': 'fila.co.kr', fila: 'fila.co.kr',
  '칼하트': 'carhartt-wip.com', '몽클레어': 'moncler.com', '스톤아일랜드': 'stoneisland.com', '메종키츠네': 'maisonkitsune.com', '디스이즈네버댓': 'thisisneverthat.com', '마르디메크르디': 'mardimercredi.com', '젠틀몬스터': 'gentlemonster.com',
  '언더아머': 'underarmour.com', '데상트': 'descente.co.kr', '르꼬끄': 'lecoqsportif.co.kr', '디스커버리': 'discovery-expedition.com', '코오롱스포츠': 'kolonsport.com', '토앤토': 'toentoe.com' };
function invBrandLogo(brand) {
  const b = String(brand || '').trim().toLowerCase(); if (!b) return '';
  const d = INV_BRAND_DOM[b] || INV_BRAND_DOM[b.replace(/\s+/g, '')]; if (!d) return '';
  return `https://t3.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://${d}&size=128`;
}
const invImgOk = u => /^https?:\/\//i.test(String(u || ''));
// 3.42(11/23 검수 3번): 목록 상품 칸 왼쪽 작은 사진 (누르면 크게 — data-zoom) — 재고 상품 사진(it.img)을 쓰고,
//   입찰 · 보관판매 줄은 품번 · KREAM 상품 번호로 재고 상품이나 관심 상품을 찾아 그 사진을 써요
function itPicSrc(x) {
  if (!x) return '';
  if (invImgOk(x.img) && x.imgSrc !== 'logo') return x.img;
  const pid = String(x.pid || x.kreamPid || ''), ks = String(x.code || '').split('/').map(c => codeKey(c)).filter(Boolean);
  const it = INV.items.find(i => (pid && String(i.kreamPid || '') === pid) || (ks.length && String(i.code || '').split('/').some(c => ks.includes(codeKey(c)))));
  if (it && invImgOk(it.img) && it.imgSrc !== 'logo') return it.img;
  try { const p = pid && (typeof products !== 'undefined' ? products : []).find(p => String(p.pid) === pid); const u = p && p.raw && p.raw.info && p.raw.info.img; if (invImgOk(u)) return u; } catch (e) {}
  return '';
}
function itPic(x, name) {
  const u = itPicSrc(x), ini = [...String((x && (x.brand || x.name)) || name || '?').trim()][0] || '?';
  return u ? `<img class="sr-img tbl-pic" src="${esc(u)}" alt="" loading="lazy" referrerpolicy="no-referrer" data-zoom="${esc(u)}">` : `<span class="tbl-pic tbl-ini" aria-hidden="true">${esc(ini)}</span>`;
}
// 크림 상품 화면의 대표 사진(og:image)을 숨긴 창에서 읽어요
async function invKreamImg(pid, W) {
  const url = `https://kream.co.kr/products/${encodeURIComponent(pid)}`;
  if (!W.winId) { const w = await chrome.windows.create(winOpts({ url, type: 'popup', width: 900, height: 800, focused: false, background: true })); W.winId = w.id; W.tabId = w.tabs[0].id; }
  else await chrome.tabs.update(W.tabId, { url });
  for (let i = 0; i < 20; i++) { await sleep(400); try { const t = await chrome.tabs.get(W.tabId); if (t.status === 'complete') break; } catch (e) {} }
  for (let i = 0; i < 4; i++) {   // 상품 하나에 최대 약 10초
    try { const [r] = await execT({ target: { tabId: W.tabId }, func: () => { const m = document.querySelector('meta[property="og:image"]'); return m && location.pathname.includes('/products/') ? m.content : ''; } }, 4000); if (r && r.result) return r.result; } catch (e) {}
    await sleep(500);
  }
  return '';
}
let invImgRun = null;
function invImgFill(force) { if (!invImgRun) invImgRun = invImgFill0(force).catch(e => { console.warn(e); return 0; }).finally(() => { invImgRun = null; }); return invImgRun; }
async function invImgFill0(force) {
  // 주문 사진이 있는 상품은 끝. 가벼운 확인(저장해 둔 주문 · 크림 사진)은 열 때마다, 크림 화면 열기 · 매입처 사진 · 로고는 처음과 7일마다
  const need = INV.items.filter(it => it.imgSrc !== 'order'); if (!need.length) return 0;
  const heavy = it => force || !it.imgTry || Date.now() - it.imgTry > 7 * 864e5;
  const real = it => it.imgSrc === 'order' || it.imgSrc === 'kream';
  let n = 0;
  const set = (it, u, src) => { if (!invImgOk(u)) return false; if (it.img !== u || it.imgSrc !== src) { it.img = u; it.imgSrc = src; n++; } return true; };
  // ① 구매처 주문 사진 (같은 품번)
  const byCode = new Map();
  try { for (const x of ordRows()) { if (!invImgOk(x.img)) continue; const k = codeKey(x.code || ordCode(x.name) || ''); if (k && !byCode.has(k)) byCode.set(k, x.img); } } catch (e) {}
  for (const it of need) { const u = byCode.get(codeKey(it.code)); if (u) set(it, u, 'order'); }
  // ② 크림 사진: 이미 가진 것(시세 추적 상품 · 품번 짝 기억) → 서버 품번 짝 → 크림 상품 화면(숨긴 창 · 처음과 7일마다)
  let left = need.filter(it => !real(it));
  if (left.length) {
    const kp = (await store.get('srcKPid', {})) || {};
    const pOf = new Map((typeof products !== 'undefined' && Array.isArray(products) ? products : []).map(p => [String(p.pid), p.raw && p.raw.info && p.raw.info.img]));
    for (const it of left) { const c = kp[codeKey(it.code)], u = (it.kreamPid && pOf.get(String(it.kreamPid))) || (c && c.card && c.card.img) || ''; if (u) set(it, u, 'kream'); }
    left = left.filter(it => !real(it) && heavy(it));
    if (left.length && typeof seShare === 'function') {
      const rows = await seShare('ks_kmap_get', { p_codes: [...new Set(left.map(it => codeKey(it.code)).filter(Boolean))].slice(0, 1000) });
      const m = new Map((rows || []).filter(x => x.kream_img).map(x => [x.code, x]));
      for (const it of left) { const x = m.get(codeKey(it.code)); if (x) { set(it, x.kream_img, 'kream'); if (!it.kreamPid && x.kream_pid) it.kreamPid = String(x.kream_pid); } }
      left = left.filter(it => !real(it));
    }
    const W = { winId: null, tabId: null }, end = Date.now() + 120000;   // 한 번에 최대 2분 (남은 건 다음에)
    try { for (const it of left.filter(it => it.kreamPid).slice(0, 40)) { if (Date.now() > end) break; const u = await invKreamImg(it.kreamPid, W).catch(() => ''); if (u) set(it, u, 'kream'); } }
    finally { if (W.winId) { try { await chrome.windows.remove(W.winId); } catch (e) {} } }
  }
  // ③ 매입처 상품 사진 (소싱에서 모은 같은 품번)
  left = need.filter(it => !real(it) && heavy(it));
  if (left.length) {
    const src = new Map(), add = r => { if (!r || !invImgOk(r.img)) return; for (const c of (r.codes || [r.code])) { const k = codeKey(c); if (k && !src.has(k)) src.set(k, r.img); } };
    try { ((await store.get('srcRows', [])) || []).forEach(add); } catch (e) {}
    try { for (const h of ((await store.get('srcHist', [])) || []).slice(0, 5)) ((await store.get('srcHistRows_' + h.id, [])) || []).forEach(add); } catch (e) {}
    for (const it of left) { const u = src.get(codeKey(it.code)); if (u) set(it, u, 'shop'); }
  }
  // ④ 브랜드 로고
  for (const it of need) { if (real(it) || it.imgSrc === 'shop' || !heavy(it)) continue; const u = invBrandLogo(it.brand); if (u) set(it, u, 'logo'); }
  need.filter(heavy).forEach(it => { it.imgTry = Date.now(); });
  if (n || need.some(heavy)) await invSave();
  if (n && DRW.open) drwPaint();
  return n;
}
// 로고가 너무 작게(32px 아래) 오면 흐릿해서 글자로 둬요
document.addEventListener('load', e => {
  const im = e.target; if (!im || im.tagName !== 'IMG' || !im.classList.contains('dav-logo') || im.naturalWidth >= 32) return;
  const sp = document.createElement('span'); sp.className = 'dav'; sp.textContent = im.dataset.ini || '?'; im.replaceWith(sp);
}, true);
// 사진이 안 열리면(주소가 바뀜 등) 그 자리를 글자로 바꿔요
document.addEventListener('error', e => {
  const im = e.target; if (!im || im.tagName !== 'IMG' || !im.classList.contains('dav-img')) return;
  const sp = document.createElement('span'); sp.className = 'dav'; sp.textContent = im.dataset.ini || '?'; im.replaceWith(sp);
}, true);
// ---------- 3.18: 오른쪽 보유 재고 서랍 (어느 화면에서든) ----------
const DRW = { open: false, q: '', brand: '', cat: '', tab: 'all' };
// 3.19.1: 보유 재고 = 창고 재고 + 크림 보관판매로 보낸 것(우선출고 · 아직 안 팔림). 품절 표시는 안 해요.
function drwRows() {
  const C = invCalc(), keep = new Map();
  for (const o of INV.outs) {
    if (o.kind !== 'pre' || o.settled) continue;
    const N = outNums(o); if (N.net <= 0) continue;
    const k = o.itemId + '|' + o.size, x = keep.get(k) || { qty: 0, value: 0 }; x.qty += N.net; x.value += N.net * N.unitCost; keep.set(k, x);
  }
  return INV.items.map(it => {
    const st = itemStock(it, C), by = {}; let kq = 0, kv = 0;
    const sizes = [...it.sizes]; for (const k of keep.keys()) { const [id, sz] = k.split('|'); if (id === it.id && !sizes.includes(sz)) sizes.push(sz); }
    for (const sz of sizes) { const h = st.by[sz] ? st.by[sz].qty : 0, kp = keep.get(it.id + '|' + sz), q = kp ? kp.qty : 0; if (kp) { kq += kp.qty; kv += kp.value; } if (h || q) by[sz] = { home: h, keep: q }; }
    return { it, sizes, by, home: st.qty, keep: kq, qty: st.qty + kq, value: st.value + kv };
  }).filter(r => r.qty > 0);
}
function drwPaint() {
  const rows = drwRows();
  const qty = rows.reduce((s, r) => s + r.qty, 0), value = rows.reduce((s, r) => s + r.value, 0), keepQ = rows.reduce((s, r) => s + r.keep, 0);
  const man = v => v >= 1e8 ? (Math.round(v / 1e7) / 10) + '억' : v >= 1e4 ? Math.round(v / 1e4).toLocaleString('ko-KR') + '만' : Math.round(v).toLocaleString('ko-KR');
  $('#drwKpi').innerHTML = [['상품', rows.length.toLocaleString('ko-KR'), '종', 'k1'], ['재고', qty.toLocaleString('ko-KR'), '개', 'k2', '창고 ' + (qty - keepQ) + '개 + 크림 보관 ' + keepQ + '개'], ['가치', man(value), '원', 'k3', won(value) + ' (매입가 기준 · 보관 포함)'], ['크림 보관', keepQ.toLocaleString('ko-KR'), '개', 'k4', '크림 보관판매로 보낸 것 중 아직 안 팔린 수량']]
    .map(([l, v, u, c, t]) => `<div class="dk ${c}"${t ? ` title="${esc(t)}"` : ''}><span>${l}</span><b>${v}<small>${u}</small></b></div>`).join('');
  const brands = [...new Set(rows.map(r => r.it.brand).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'ko'));
  const cats = [...new Set(rows.map(r => r.it.cat).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'ko'));
  if (DRW.brand && !brands.includes(DRW.brand)) DRW.brand = '';
  if (DRW.cat && !cats.includes(DRW.cat)) DRW.cat = '';
  if (!['all', 'home', 'keep'].includes(DRW.tab)) DRW.tab = 'all';
  $('#drwBrand').innerHTML = opt('', '브랜드 전체', !DRW.brand) + brands.map(b => opt(b, b, DRW.brand === b)).join('');
  $('#drwCat').innerHTML = opt('', '분류 전체', !DRW.cat) + cats.map(c => opt(c, c, DRW.cat === c)).join('');
  const q = DRW.q.trim().toLowerCase(), qk = codeKey(DRW.q);
  const base = rows.filter(r => (!DRW.brand || r.it.brand === DRW.brand) && (!DRW.cat || r.it.cat === DRW.cat) && (!q || `${r.it.name} ${r.it.brand} ${r.it.code}`.toLowerCase().includes(q) || (qk.length >= 2 && codeKey(r.it.code).includes(qk))));
  const cnt = { all: base.length, home: base.filter(r => r.home > 0).length, keep: base.filter(r => r.keep > 0).length };
  $('#drwTabs').innerHTML = [['all', '전체'], ['home', '창고'], ['keep', '크림 보관']].map(([k, t]) => `<button type="button" role="tab" data-dt="${k}" aria-selected="${DRW.tab === k}">${t}<span>${cnt[k]}</span></button>`).join('');
  const list = base.filter(r => DRW.tab === 'all' || (DRW.tab === 'home' ? r.home > 0 : r.keep > 0)).sort((a, b) => b.value - a.value || (b.it.created || 0) - (a.it.created || 0));
  const LIM = 300;
  $('#drwList').innerHTML = list.length ? list.slice(0, LIM).map(r => {
    const it = r.it, ini = [...(it.brand || it.name || '?').trim()][0] || '?';
    const sizes = r.sizes.filter(sz => r.by[sz]).map(sz => { const x = r.by[sz]; return `<span class="dsz${x.keep && !x.home ? ' kp' : ''}" title="${esc(sz)} · 창고 ${x.home}개${x.keep ? ' · 크림 보관 ' + x.keep + '개' : ''}">${esc(sz)}<b>${x.home + x.keep}</b>${x.keep ? `<em>보관 ${x.keep}</em>` : ''}</span>`; }).join('');
    return `<button type="button" class="dit" data-di="${esc(it.id)}">${invImgOk(it.img) ? `<img class="sr-img dav-img${it.imgSrc === 'logo' ? ' dav-logo' : ''}" src="${esc(it.img)}" alt="" loading="lazy" referrerpolicy="no-referrer" data-ini="${esc(ini)}"${it.imgSrc === 'logo' ? '' : ` data-zoom="${esc(it.img)}"`}>` : `<span class="dav">${esc(ini)}</span>`}<span class="dmid"><small>${esc(it.brand || '브랜드 없음')}${it.cat ? ' · ' + esc(it.cat) : ''}</small><b>${esc(it.name || it.code)}</b><code>${esc(it.code || '')}</code><span class="dszs">${sizes}</span></span><span class="dend"><b>${r.qty}개</b><small>${won(r.value)}</small>${r.keep ? `<span class="dkp">크림 보관 ${r.keep}</span>` : ''}</span></button>`;
  }).join('') + (list.length > LIM ? `<p class="hint drw-more">${LIM}개까지 보여줘요 — 검색으로 좁혀 보세요 (전체 ${list.length}개)</p>` : '')
    : `<div class="drw-empty"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/></svg><b>${rows.length ? '조건에 맞는 상품이 없어요' : '아직 보유 재고가 없어요'}</b><span>${rows.length ? '검색어나 필터를 바꿔 보세요' : '재고관리 → 입고 등록이나 주문내역 자동 입고로 채워져요'}</span></div>`;
}
function drwSet(open) {
  DRW.open = open; const d = $('#invDrawer'), h = $('#drwHandle'), dim = $('#drwDim');
  d.classList.toggle('on', open); d.setAttribute('aria-hidden', String(!open)); h.setAttribute('aria-expanded', String(open)); dim.hidden = !open;
  document.body.classList.toggle('drw-open', open);
  if (open) { drwPaint(); invImgFill(); if (typeof kcCount === 'function') kcCount($('#drwKpi'), true); setTimeout(() => { try { $('#drwQ').focus(); } catch (e) {} }, 60); }
}
function drwInit() {
  if (!$('#invDrawer') || drwInit.done) return; drwInit.done = true;
  $('#drwHandle').addEventListener('click', () => drwSet(!DRW.open));
  $('#drwClose').addEventListener('click', () => drwSet(false));
  $('#drwDim').addEventListener('click', () => drwSet(false));
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && DRW.open) drwSet(false); });
  $('#drwQ').addEventListener('input', e => { DRW.q = e.target.value; drwPaint(); });
  $('#drwBrand').addEventListener('change', e => { DRW.brand = e.target.value; drwPaint(); });
  $('#drwCat').addEventListener('change', e => { DRW.cat = e.target.value; drwPaint(); });
  $('#drwTabs').addEventListener('click', e => { const b = e.target.closest('[data-dt]'); if (b) { DRW.tab = b.dataset.dt; drwPaint(); } });
  $('#invDrawer').addEventListener('click', e => {
    const it = e.target.closest('[data-di]'), v = e.target.closest('[data-dv]');
    if (it) { IS.items.open = it.dataset.di; Object.assign(IS.items, { q: '', brand: '', cat: '', only: false }); drwSet(false); go('items'); setTimeout(() => { const r = document.querySelector(`[data-id="${CSS.escape(it.dataset.di)}"]`); if (r) r.scrollIntoView({ block: 'center' }); }, 120); }
    else if (v) { drwSet(false); if (v.dataset.dv === 'io') IS.io.mode = 'in'; go(v.dataset.dv); }
  });
}

async function invLoad() {
  const saved = await store.get(invStoreKey(), null);
  INV = Object.assign(INV_DEF(), saved || {});
  INV.opt = Object.assign(INV_DEF().opt, INV.opt || {});
  // 상용화 점검: 수수료를 저장하지 않았던 옛 정산 출고(fee '')에 지금 수수료를 한 번만 채워요 — 이후로는 설정을 바꿔도 안 변해요
  if (saved && freezeFees()) await store.set(invStoreKey(), INV);
}
// 상용화 점검: 백업은 사업자 전부를 파일 하나에 담아요 (inv 는 옛 버전이 읽을 수 있게 지금 사업자 것을 같이 넣어요)
async function invBackupText() {
  await invSave();
  const invs = {};
  for (const b of BIZ.list) invs[b.id] = b.id === BIZ.cur ? INV : await store.get(b.id === 'main' ? 'inv' : 'inv@' + b.id, null);
  return JSON.stringify({ app: '킥스캔-재고관리', v: 2, at: new Date().toISOString(), biz: { list: BIZ.list, cur: BIZ.cur }, invs, inv: INV });
}
async function invBackupDownload(tag) {
  const t = new Date(), hm = String(t.getHours()).padStart(2, '0') + String(t.getMinutes()).padStart(2, '0');
  download(await invBackupText(), `킥스캔_재고관리_백업_${today()}${tag ? `_${hm}_${tag}` : ''}.json`, 'application/json');
}
async function bizSwitch(id) {
  if (!BIZ.list.some(b => b.id === id) || id === BIZ.cur) return;
  await invSave(); BIZ.cur = id; await store.set('biz', BIZ); await invLoad();
  Object.assign(IS.io, { rows: [], q: '', msg: '' }); IS.items.open = ''; IS.plan = null; IS.msg = `'${bizCur().name}'(으)로 바꿨어요`;
  if (typeof DRW !== 'undefined' && DRW.open) drwPaint();
  renderInv();
}
function bizDialog(b) {
  const B = b || { name: '', type: '일반', no: '' };
  invDialog(b ? '사업자 수정' : '사업자 추가', `<div class="dgrid"><label>사업자 이름 *<input name="name" required value="${esc(B.name)}" placeholder="예: 윤아상회"></label><label>과세 유형<select name="type">${opt('일반', '일반과세자', B.type === '일반')}${opt('간이', '간이과세자', B.type === '간이')}${opt('면세', '면세사업자', B.type === '면세')}</select></label><label>사업자등록번호 끝 5자리 (선택)<input name="no" maxlength="5" value="${esc(B.no || '')}" placeholder="12345"></label><label>관리 시작일 (선택)<input type="date" name="start" value="${esc(B.start || '')}"></label></div><p class="hint">관리 시작일을 넣으면 그 날짜 전 주문은 주문 불러오기에서 저절로 입고하지 않아요(직접 골라 넣는 건 돼요). 비우면 날짜 제한 없이 불러와요.</p><p class="hint">사업자마다 상품 · 재고 · 입출고 · 장부가 따로 저장돼요. 기본정보(거래처 · 결제수단)도 사업자마다 따로예요.</p>`, async d => {
    const name = String(d.name || '').trim(); if (!name) return '이름을 넣어 주세요';
    const start = /^\d{4}-\d{2}-\d{2}$/.test(String(d.start || '')) ? d.start : '';
    if (b) Object.assign(b, { name, type: d.type, no: d.no, start }); else { const nb = { id: uid(), name, type: d.type, no: d.no, start }; BIZ.list.push(nb); await store.set('biz', BIZ); await bizSwitch(nb.id); return; }
    await store.set('biz', BIZ); renderInv();
  }, b ? '저장' : '추가하고 바꾸기');
}
function renderBiz() {
  const box = $('#bizBox'); if (!box) return;
  const c = bizCur();
  box.innerHTML = `<div class="sgrp">사업자</div>${BIZ.list.map(b => `<div class="biz-row${b.id === BIZ.cur ? ' on' : ''}"><button type="button" class="biz-b" data-biz="${esc(b.id)}">${typeof ico === 'function' ? ico('home') : ''}<span>${esc(b.name)}</span><em>${esc(b.type || '일반')}</em></button>${b.id === BIZ.cur ? `<button type="button" class="biz-g" data-bizedit="${esc(b.id)}" aria-label="사업자 수정">${typeof ico === 'function' ? ico('gear') : '⚙'}</button>` : ''}</div>`).join('')}<button type="button" class="biz-add" data-bizadd="1">+ 사업자 추가</button>`;
  void c;
}
async function invInit() {
  BIZ = Object.assign(BIZ, await store.get('biz', null) || {});
  if (!BIZ.list.some(b => b.id === BIZ.cur)) BIZ.cur = 'main';
  await invLoad();
  if (!(INV.opt.optV >= 2)) { INV.opt.autoIn = true; INV.opt.optV = 2; }   // 2.6: 자동 입고 기본으로 켬
  ordCache = await store.get('ordCache', {});
  drwInit();
  const d = await store.get('invDraft', null);
  if (d) Object.assign(IS.io, d);
  const main = $('#invMain');
  $('#invNav').addEventListener('click', e => { const b = e.target.closest('[data-v]'); if (b) go(b.dataset.v); });
  { const bx = $('#bizBox'); if (bx) bx.addEventListener('click', e => { const s1 = e.target.closest('[data-biz]'), ed = e.target.closest('[data-bizedit]'), ad = e.target.closest('[data-bizadd]'); if (ed) return typeof stOpen === 'function' ? stOpen('biz') : bizDialog(BIZ.list.find(b => b.id === ed.dataset.bizedit)); if (ad) return bizDialog(null); if (s1) { if (typeof curMode !== 'undefined' && curMode !== 'inv') route('inv:' + invView); bizSwitch(s1.dataset.biz); } }); }
  main.addEventListener('click', e => {
    const el = e.target.closest('[data-a]'); if (!el || !main.contains(el)) return;
    if (el.tagName === 'TR' && e.target.closest('button,input,select,a,label')) return;
    invAct(el.dataset.a, el).catch(err => { IS.msg = '오류: ' + err.message; renderInv(); });
  });
  main.addEventListener('input', e => { const el = e.target.closest('[data-k]'); if (el && (el.type !== 'checkbox' && el.type !== 'radio' && el.tagName !== 'SELECT' && el.type !== 'file')) invInput(el, e); });
  main.addEventListener('change', e => { const el = e.target.closest('[data-k]'); if (el) invInput(el, e); });
  main.addEventListener('keydown', e => { const el = e.target.closest('[data-k]'); if (el) invKey(el, e); });
  main.addEventListener('dragover', e => { const z = e.target.closest('[data-drop],.drop'); if (z) { e.preventDefault(); z.classList.add('over'); } });
  main.addEventListener('dragleave', e => { const z = e.target.closest('.drop'); if (z) z.classList.remove('over'); });
  main.addEventListener('drop', e => { const z = e.target.closest('.drop'); if (!z) return; e.preventDefault(); z.classList.remove('over'); const f = e.dataTransfer.files[0]; if (!f) return; if (z.querySelector('[data-k=pzFile]')) pzLoad(f); else xlLoad(f); });
}

// ---------- 휴대폰으로 보낼 재고 요약 (웹페이지 저장 공간 문서 하나에 들어가게 짧게) ----------
function invMobileSummary() {
  if (!INV.items.length && !INV.lots.length) return null;
  const C = invCalc(), t = today();
  const stock = INV.items.map(it => { const st = itemStock(it, C); const sz = {}; for (const s of it.sizes) if (st.by[s]) sz[s] = st.by[s].qty; return { c: it.code, n: itName(it), q: st.qty, v: Math.round(st.value), s: sz, o: it.sizes.filter(s => sz[s]) }; })
    .filter(x => x.q > 0).sort((a, b) => b.v - a.v).slice(0, 600);
  const pre = INV.outs.filter(o => o.kind === 'pre' && !o.settled).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 200)
    .map(o => ({ d: o.date, n: itName(itemOf(o.itemId)), c: itemOf(o.itemId)?.code || '', s: o.size, q: o.qty, p: partnerOf(o.partnerId)?.name || '', cost: Math.round(outNums(o).unitCost) }));
  const soon = INV.lots.filter(l => !l.confirmed && C.left.get(l.id) > 0 && l.returnDue && dday(l.returnDue) <= Math.max(INV.opt.soon, 7)).sort((a, b) => a.returnDue.localeCompare(b.returnDue)).slice(0, 200)
    .map(l => ({ due: l.returnDue, n: itName(itemOf(l.itemId)), s: l.size, q: C.left.get(l.id), p: partnerOf(l.partnerId)?.name || '', cost: l.cost }));
  const months = [];
  const d0 = new Date(t.slice(0, 7) + '-01T00:00:00');
  for (let i = 5; i >= 0; i--) { const d = new Date(d0); d.setMonth(d.getMonth() - i); const s = fmtD(d); const f = monthFigures(monthStart(s), monthEnd(s)); months.push({ m: s.slice(0, 7), sold: f.sold, rev: Math.round(f.rev), buy: Math.round(f.buy), fees: Math.round(f.fees), margin: Math.round(f.margin) }); }
  let qty = 0, value = 0; for (const s of C.stock.values()) { qty += s.qty; value += s.value; }
  return { at: Date.now(), skus: stock.length, qty, value: Math.round(value), months, stock, pre, soon, soonDays: INV.opt.soon };
}
