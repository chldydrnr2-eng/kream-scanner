'use strict';
/* 킥스캔 — 오늘 살 것 (11/25 사장님 «리셀에 시간을 엄청 쓰고 싶지 않아 — 자동화가 목표»)
   소싱 결과(srcRows) 중 지금 살 만한 수익 상품만 한 화면에 모아요 — 사장님은 결제만
   - 빼는 것: 재고가 남아 있는 품번 · [샀어요] 누른 것 · 쇼핑몰 주문과 이어진 구매 기록 · [안 살래요](7일) · 시세 확인이 오래된 것(기본 48시간)
   - 하루 예산(기본 100만 원 · 0 = 제한 없음) 안에서 예상 수익 큰 순 · 상품당 최대 수량(기본 2개, 수익 큰 사이즈부터) — 넘는 건 '예산 넘는 상품'
   - 새로 생기면 알림 종 · 윈도우 알림 · 폰 알림(push.js 종류 'buy') — 폰 앱 › 살 것 탭에서도 봐요(ks_doc job 'tbuy')
   - 폰에서 [샀어요] · [안 살래요] → ks_doc job 'tbact-…'(by phone) → cloud.js clApply → tbPhoneAct
   저장: 'tbCfg' { budget, per, maxAge, on } · 'tbState' { done: {ck: {at, day, cost, q, name}}, skip: {ck: 까지}, sent: {ck: at}, base, hash, syncAt } */

// 11/25 사장님 «오늘 살 것에도 필터가 있어야 — 설정창에 두면 찾기 힘들어»: 화면 위 필터 줄(tbFlt)에서 바로 바꿔요(알림·폰 살 것 탭도 같은 조건)
const TBC_DEF = { budget: 1000000, per: 2, maxAge: 48, on: true, minWon: 0, minRate: 0, min30: 0, sl: ['kream', 'poizon'], sort: 'profit' };
let TBC = { ...TBC_DEF };
let TBS = { done: {}, skip: {}, sent: {}, base: 0, hash: '', syncAt: 0 };
let TBL = null;            // 마지막 계산 { pick, over, spent, budget, at, srcAt }
const TBMAP = new Map();   // 카드 id → { r, C } ([구매 ↗] · [샀어요] 때 구매 기록에 써요)
const TB_SKIP = 7 * 864e5, TB_DONE = 14 * 864e5;
const tbCk = c => typeof codeKey === 'function' ? codeKey(c || '') : String(c || '').replace(/[^A-Z0-9]/gi, '').toUpperCase();
const tbDay = (t = Date.now()) => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const tbWon = n => n == null || isNaN(n) ? '–' : Math.round(n).toLocaleString('ko-KR') + '원';
const tbHere = () => typeof curMode !== 'undefined' && curMode === 'inv' && typeof invView !== 'undefined' && invView === 'tbuy';

// 재고가 남아 있는 품번
function tbOwn() {
  const out = new Set();
  try {
    if (typeof INV === 'undefined' || typeof invCalc !== 'function') return out;
    const C = invCalc(), byId = new Map(INV.items.map(i => [i.id, i]));
    for (const l of INV.lots) if ((C.left.get(l.id) || 0) > 0) { const it = byId.get(l.itemId); if (it) for (const c of String(it.code || '').split('/')) { const k = tbCk(c); if (k) out.add(k); } }
  } catch (e) {}
  return out;
}
// 산 것: [샀어요] · 쇼핑몰 주문과 이어진 구매 기록 · [매입 등록]으로 넣은 구매 기록 (14일 안)
function tbBought(ck) {
  const d = TBS.done[ck]; if (d && Date.now() - d.at < TB_DONE) return true;
  return typeof BI !== 'undefined' && (BI.L || []).some(i => i.ck === ck && (i.linkedQ > 0 || i.st === 'manual' || i.st === 'linked') && Date.now() - i.at < TB_DONE);
}
const tbOpened = ck => typeof BI !== 'undefined' && (BI.L || []).some(i => i.ck === ck && i.st === 'open' && Date.now() - i.at < 3 * 864e5);
const tbSpent = () => Object.values(TBS.done).filter(d => d.day === tbDay()).reduce((t, d) => t + (+d.cost || 0), 0);

async function tbList() {
  // 11/25 사장님 «소싱 수익 상품 19개인데 오늘 살 것엔 1개만»: 예산 넘는 상품이 접혀 있었어요 — 이제 다 펼쳐 보이고,
  //   소싱 수익 상품 수(total)와 빠진 까닭(ex: 보유 재고 · 산 것 · 안 살래요 · 시세 오래됨 · 살 사이즈 없음)도 같이 세요
  const out = { pick: [], over: [], spent: tbSpent(), budget: +TBC.budget || 0, at: Date.now(), srcAt: 0, total: 0, ex: { own: 0, bought: 0, skip: 0, old: 0, nosz: 0, flt: 0 } };
  if (typeof srcCalcRow !== 'function') return out;
  const rows = (await store.get('srcRows', [])) || [];
  const calc = typeof seCalcCfg === 'function' ? await seCalcCfg() : ((await store.get('srcCalc', {})) || {});
  const env = typeof seCalcEnv === 'function' ? seCalcEnv() : undefined;
  if (typeof biLoad === 'function') { try { await biLoad(); } catch (e) {} }
  const own = tbOwn(), now = Date.now(), maxAge = Math.max(1, +TBC.maxAge || 48) * 3600e3, per = Math.max(1, +TBC.per || 2), L = [], seen = new Set();
  const sl = Array.isArray(TBC.sl) && TBC.sl.length && !(TBC.sl.includes('kream') && TBC.sl.includes('poizon')) ? TBC.sl : null, minWon = +TBC.minWon || 0, minRate = +TBC.minRate || 0, min30 = +TBC.min30 || 0;
  // 필터: 고른 판매처 중 수익이 제일 큰 곳으로 다시 고르고, 개당 수익 · 수익률이 모자란 사이즈는 빼요
  const tbPickSz = x => {
    let b = x.best;
    if (sl && b && !sl.includes(b.seller)) { b = null; for (const [k, v] of Object.entries(x.per || {})) if (sl.includes(k) && v && v.profit != null && (!b || v.profit > b.profit)) b = { seller: k, ...v }; }
    if (!b || !(b.profit > 0) || b.profit < minWon) return null;
    if (minRate && !(x.buy > 0 && b.profit / x.buy * 100 >= minRate)) return null;
    return b;
  };
  TBMAP.clear();
  for (const r of Array.isArray(rows) ? rows : []) {
    if (!r || !r.code) continue;
    out.srcAt = Math.max(out.srcAt, r.at || 0);
    if (r.need || r.none || r.hide) continue;
    const ck = tbCk(r.code); if (!ck || seen.has(ck)) continue;
    let C; try { C = srcCalcRow(r, calc, env); } catch (e) { continue; }
    if (!C || !C.profitable) continue;
    seen.add(ck); out.total++;
    const why = now - (r.at || 0) > maxAge ? 'old' : own.has(ck) ? 'own' : tbBought(ck) ? 'bought' : (TBS.skip[ck] || 0) > now ? 'skip' : !C.rec.length ? 'nosz' : '';
    if (why) { out.ex[why]++; continue; }
    // 상품당 최대 수량만큼 — 개당 수익이 큰 사이즈부터
    const cand = min30 && (+C.n30All || 0) < min30 ? [] : C.rec.map(x => ({ x, b: tbPickSz(x) })).filter(o => o.b);
    if (!cand.length) { out.ex.flt++; continue; }
    let left = per; const sizes = [];
    for (const { x, b: bs } of cand.sort((a, b) => b.b.profit - a.b.profit)) {
      if (left <= 0) break; const q = Math.min(x.q, left); if (q <= 0) continue; left -= q;
      sizes.push({ size: String(x.size), q, buy: x.buy, profit: bs.profit, seller: bs.seller, url: (x.offer && x.offer.url) || '' });
    }
    if (!sizes.length) { out.ex.nosz++; continue; }
    const b = C.offer || (r.buy || [])[0] || {};
    const x = { id: r.id, ck, code: r.code, name: r.name || r.code, brand: r.brand || '', img: r.img || '', site: b.label || b.site || '', url: sizes[0].url || b.url || '', unit: C.buy, sizes,
      q: sizes.reduce((t, s) => t + s.q, 0), cost: sizes.reduce((t, s) => t + s.q * (+s.buy || 0), 0), profit: sizes.reduce((t, s) => t + s.q * (+s.profit || 0), 0),
      avg: C.avg, n30: C.n30All, seller: sl ? sizes[0].seller : (C.sellers || [])[0] || sizes[0].seller || '', at: r.at || 0, opened: tbOpened(ck) };
    if (sl) x.avg = Math.round(x.profit / x.q);
    TBMAP.set(r.id, { r, C }); L.push(x);
  }
  const rt = x => x.cost > 0 ? x.profit / x.cost : 0;
  const SORT = { rate: (a, b) => rt(b) - rt(a), n30: (a, b) => (b.n30 || 0) - (a.n30 || 0), cost: (a, b) => a.cost - b.cost };
  L.sort((a, b) => (SORT[TBC.sort] ? SORT[TBC.sort](a, b) : 0) || b.profit - a.profit || (b.avg || 0) - (a.avg || 0));
  let room = out.budget ? Math.max(0, out.budget - out.spent) : Infinity;
  for (const x of L) { if (x.cost <= room) { out.pick.push(x); room -= x.cost; } else out.over.push(x); }
  return out;
}

// ---------- 화면 ----------
function tbCard(x, over) {
  const sl = x.seller === 'poizon' ? 'POIZON' : x.seller === 'kream' ? 'KREAM' : '';
  const age = x.at ? (typeof lkAgo === 'function' ? lkAgo(x.at) : '') : '';
  const id = esc(x.id);
  return `<div class="rl-card tb-card${over ? ' over' : ''}"><div class="rl-top">${x.img ? `<img class="rl-img" src="${esc(x.img)}" alt="" loading="lazy">` : '<span class="rl-img"></span>'}<div class="rl-h"><span class="rl-brand">${esc(x.brand)}${x.opened ? ' <em class="tb-tag">구매 창 열었어요</em>' : ''}</span><b>${esc(x.name)}</b><span class="rl-code">${esc(x.code)}</span></div></div>
    <dl class="rl-dl"><dt>매입처</dt><dd>${esc(x.site || '–')} · ${tbWon(x.unit)}</dd><dt>살 사이즈</dt><dd>${x.sizes.map(s => `${esc(s.size)} ×${s.q}`).join(' · ')}</dd>
      <dt>매입 금액</dt><dd>${tbWon(x.cost)}</dd><dt>예상 수익</dt><dd class="tb-pf">${tbWon(x.profit)} <span class="small">개당 ${tbWon(x.avg)}${sl ? ' · ' + sl : ''}</span></dd><dt>30일 판매</dt><dd>${(+x.n30 || 0).toLocaleString('ko-KR')}개</dd></dl>
    <div class="rl-foot"><span class="small">${age ? `시세 ${esc(age)}` : ''}</span><span class="topsp"></span><button type="button" class="ghost small" data-a="tbSkip" data-v="${id}" title="7일 동안 안 보여요">안 살래요</button><button type="button" class="ghost small" data-a="tbDone" data-v="${id}">샀어요</button>${x.url ? `<a class="primary small tb-buy" href="${esc(x.url)}" target="_blank" rel="noopener" data-tbbuy="${id}">구매 ↗</a>` : ''}</div></div>`;
}
function vTbuy() {
  if (!IS.tbBusy && (!TBL || Date.now() - TBL.at > 60e3)) setTimeout(() => tbCheck('view').catch(() => {}), 0);
  const D = TBL || { pick: [], over: [], spent: tbSpent(), budget: +TBC.budget || 0 };
  const sc = D.pick.reduce((t, x) => t + x.cost, 0), sp = D.pick.reduce((t, x) => t + x.profit, 0);
  const today = Object.entries(TBS.done).filter(([, d]) => d.day === tbDay());
  const nPh = typeof pushCount === 'function' ? pushCount() : 0;
  const EXN = { own: '재고 있는 품번', bought: '산 것', skip: '안 살래요', old: `시세 ${+TBC.maxAge || 48}시간 넘음`, nosz: '살 사이즈 없음', flt: '필터에 안 맞음' }, ex = Object.entries(D.ex || {}).filter(([, n]) => n > 0);
  const sum = `<div class="tb-sum"><b>${D.pick.length}개</b><span>매입 ${tbWon(sc)}</span><span class="tb-pf">예상 수익 ${tbWon(sp)}</span><span class="small">${D.budget ? `하루 예산 ${tbWon(D.budget)} · 오늘 산 것 ${tbWon(D.spent)}` : '예산 제한 없음'} · 상품당 최대 ${+TBC.per || 2}개</span>
    ${D.total ? `<span class="tb-cnt">소싱 수익 상품 ${D.total}개 = 예산 안 ${D.pick.length}개${D.over.length ? ` + 예산 넘는 ${D.over.length}개(아래)` : ''}${ex.length ? ` + 뺀 것 ${ex.reduce((t, [, n]) => t + n, 0)}개(${ex.map(([k, n]) => `${EXN[k]} ${n}`).join(' · ')})` : ''}</span>` : ''}</div>`;
  const empty = `<div class="panel dl-empty"><span>${!TBL ? '계산하는 중이에요…' : D.over.length ? '오늘 예산 안에 드는 상품이 없어요 — 아래 예산 넘는 상품을 보거나 위 필터에서 예산을 늘려 주세요' : `지금 살 만한 수익 상품이 없어요${TBL.srcAt ? ` — 마지막 소싱 결과 ${esc(typeof lkAgo === 'function' ? lkAgo(TBL.srcAt) : '')}` : ''}. 소싱 예약을 켜 두면 새로 찾는 대로 여기에 채워지고 알려 드려요`}</span>${TBL && !D.over.length ? '<button type="button" class="ghost" data-a="tbFind">소싱으로 가기</button>' : ''}</div>`;
  return `${head('오늘 살 것', '소싱 결과에서 지금 살 만한 수익 상품만 모았어요. 결제만 하시면 돼요 — 산 건 [샀어요], 안 살 건 [안 살래요]. 쇼핑몰 주문이 들어오면 재고에 자동으로 이어져요.', `<button type="button" class="ghost" data-a="tbLoad"${IS.tbBusy ? ' disabled' : ''}>${IS.tbBusy ? '계산 중…' : '↻ 다시 계산'}</button><button type="button" class="ghost" data-a="tbCfg">알림 설정</button>`)}
  ${tbFlt()}
  ${sum}
  <div class="ev-grid rl-grid">${D.pick.length ? D.pick.map(x => tbCard(x)).join('') : empty}</div>
  ${D.over.length ? `<div class="tb-overh"><b>예산 넘는 상품 ${D.over.length}개</b><span class="small">오늘 예산 ${tbWon(D.budget)}을 넘어서 뒤로 뺐어요 — 사도 돼요 · 예산은 위 필터에서 바꿔요</span></div><div class="ev-grid rl-grid">${D.over.map(x => tbCard(x, true)).join('')}</div>` : ''}
  ${today.length ? `<details class="tb-more"><summary>오늘 산 것 ${today.length}개 · ${tbWon(D.spent)}</summary><div class="tb-done">${today.map(([ck, d]) => `<div><span>${esc(d.name || ck)}${d.q ? ` · ${d.q}개` : ''} · ${tbWon(d.cost)}${d.from === 'phone' ? ' · 폰' : ''}</span><button type="button" class="linkbtn" data-a="tbUndo" data-v="${esc(ck)}">되돌리기</button></div>`).join('')}</div></details>` : ''}
  <p class="hint">수익 상품 기준은 설정 › 상품 소싱 기준과 같고, 위 필터로 더 좁혀요(알림 · 폰 살 것 탭도 같은 조건) · 재고가 남은 품번 · 산 것 · [안 살래요](7일) · 시세가 ${+TBC.maxAge || 48}시간 넘은 것은 빼요 · 새 상품은 알림 종 · 윈도우 알림 · 폰 알림(${nPh ? `켠 폰 ${nPh}대` : '폰 앱 › 살 것 탭에서 [알림 켜기]'})으로 알려요</p>`;
}

// 필터 줄 — 바꾸면 바로 다시 계산하고 저장해요(다음에 열어도 그대로)
const tbMan = n => n >= 10000 ? (n / 10000).toLocaleString('ko-KR') + '만 원' : n >= 1000 ? (n / 1000) + '천 원' : n + '원';
function tbOpt(cur, list, fmt) {
  cur = +cur || 0; const L = list.includes(cur) ? list : [...list, cur].sort((a, b) => a - b);
  return L.map(v => `<option value="${v}"${v === cur ? ' selected' : ''}>${esc(fmt(v))}</option>`).join('');
}
function tbFlt() {
  const sl = Array.isArray(TBC.sl) && TBC.sl.length ? TBC.sl : TBC_DEF.sl;
  const diff = ['budget', 'per', 'maxAge', 'minWon', 'minRate', 'min30', 'sort'].some(k => String(TBC[k] ?? TBC_DEF[k]) !== String(TBC_DEF[k])) || sl.length !== TBC_DEF.sl.length;
  const sel = (k, label, html) => `<label>${label}<select data-k="${k}">${html}</select></label>`;
  const SO = [['profit', '예상 수익 큰 순'], ['rate', '수익률 높은 순'], ['n30', '많이 팔리는 순'], ['cost', '매입 금액 적은 순']];
  return `<div class="tb-flt">
    ${sel('tbSort', '정렬', SO.map(([v, t]) => `<option value="${v}"${(TBC.sort || 'profit') === v ? ' selected' : ''}>${t}</option>`).join(''))}
    ${sel('tbBudget', '하루 예산', tbOpt(TBC.budget, [0, 300000, 500000, 1000000, 2000000, 3000000, 5000000, 10000000], v => v ? tbMan(v) : '제한 없음'))}
    ${sel('tbPer', '상품당', tbOpt(TBC.per || 2, [1, 2, 3, 4, 5, 10], v => `최대 ${v}개`))}
    ${sel('tbMinWon', '개당 수익', tbOpt(TBC.minWon, [0, 5000, 10000, 20000, 30000, 50000], v => v ? tbMan(v) + ' 이상' : '상관없음'))}
    ${sel('tbMinRate', '수익률', tbOpt(TBC.minRate, [0, 5, 10, 15, 20, 30], v => v ? v + '% 이상' : '상관없음'))}
    ${sel('tbMin30', '30일 판매', tbOpt(TBC.min30, [0, 10, 20, 30, 50, 100], v => v ? v + '개 이상' : '상관없음'))}
    ${sel('tbMaxAge', '시세', tbOpt(TBC.maxAge || 48, [24, 48, 72, 168], v => v % 24 ? v + '시간 안' : (v / 24) + '일 안'))}
    <span class="tb-sl">판매처 ${[['kream', 'KREAM'], ['poizon', 'POIZON']].map(([v, t]) => `<label class="chip${sl.includes(v) ? ' on' : ''}"><input type="checkbox" data-k="tbSl" value="${v}"${sl.includes(v) ? ' checked' : ''}>${t}</label>`).join('')}</span>
    ${diff ? '<button type="button" class="linkbtn" data-a="tbReset">처음 값으로</button>' : ''}
  </div>`;
}
async function tbInput(el, ev) {
  if (ev.type !== 'change') return;
  const k = el.dataset.k, v = el.value;
  if (k === 'tbSl') {
    const s = new Set(Array.isArray(TBC.sl) && TBC.sl.length ? TBC.sl : TBC_DEF.sl);
    if (el.checked) s.add(v); else s.delete(v);
    if (!s.size) { el.checked = true; IS.msg = '판매처는 하나 이상 골라 주세요'; if (typeof renderInv === 'function') renderInv(); return; }
    TBC.sl = ['kream', 'poizon'].filter(x => s.has(x));
  } else {
    const f = { tbSort: 'sort', tbBudget: 'budget', tbPer: 'per', tbMinWon: 'minWon', tbMinRate: 'minRate', tbMin30: 'min30', tbMaxAge: 'maxAge' }[k]; if (!f) return;
    TBC[f] = f === 'sort' ? v : Math.max(0, Math.round(+v || 0));
    if (f === 'per' || f === 'maxAge') TBC[f] = TBC[f] || TBC_DEF[f];
  }
  await store.set('tbCfg', TBC);
  if (typeof renderInv === 'function') renderInv();   // 고른 값이 바로 보이게 — 숫자는 다시 계산한 뒤 바뀌어요
  return tbCheck('cfg');
}

async function tbAct(a, el) {
  const v = el.dataset.v;
  switch (a) {
    case 'tbLoad': return tbCheck('view');
    case 'tbFind': return route('find');
    case 'tbDone': case 'tbSkip': {
      const x = TBL && [...TBL.pick, ...TBL.over].find(y => y.id === v); if (!x) return;
      if (a === 'tbDone') {
        TBS.done[x.ck] = { at: Date.now(), day: tbDay(), cost: x.cost, q: x.q, name: String(x.name).slice(0, 60) };
        const m = TBMAP.get(x.id); if (m && typeof biRecord === 'function') { try { await biRecord(m.r, m.C, null, 'buy'); } catch (e) {} }   // 쇼핑몰 주문이 들어오면 이 기록과 이어져요
        IS.msg = `샀어요로 옮겼어요 — ${x.name}`;
      } else { TBS.skip[x.ck] = Date.now() + TB_SKIP; IS.msg = `7일 동안 안 보여요 — ${x.name}`; }
      await store.set('tbState', TBS); return tbCheck('act');
    }
    case 'tbReset': TBC = { ...TBC_DEF, on: TBC.on }; await store.set('tbCfg', TBC); IS.msg = '필터를 처음 값으로 돌렸어요'; return tbCheck('cfg');
    case 'tbUndo': delete TBS.done[v]; await store.set('tbState', TBS); return tbCheck('act');
    case 'tbCfg': {
      const nPh = typeof pushCount === 'function' ? pushCount() : 0;
      invDialog('오늘 살 것 설정', `<p class="hint">소싱 결과의 수익 상품 중 이 조건으로 '오늘 살 것'을 골라요. 새 상품이 생기면 알림 종 · 윈도우 알림 · 폰 알림으로 알려요(밤 10시~아침 8시는 윈도우 · 폰 알림을 쉬어요).</p>
        <div class="dgrid"><label>하루 예산(원 · 0 = 제한 없음)<input name="budget" type="number" min="0" step="10000" value="${+TBC.budget || 0}"></label>
        <label>상품당 최대 수량<input name="per" type="number" min="1" max="20" value="${+TBC.per || 2}"></label>
        <label>시세가 이 시간보다 오래되면 빼기(시간)<input name="maxAge" type="number" min="1" max="336" value="${+TBC.maxAge || 48}"></label></div>
        <div class="ev-favs"><label class="chip${TBC.on ? ' on' : ''}"><input type="checkbox" name="on"${TBC.on ? ' checked' : ''}> 새 상품 알림 켜기</label></div>
        <p class="small">폰 알림: ${nPh ? `켠 폰 ${nPh}대` : '아직 켠 폰이 없어요 — 폰 앱(킥스캔 계정으로 로그인) › 살 것 탭 › [알림 켜기]'}</p>
        ${nPh ? '<button type="button" class="ghost small" data-tbtest="1">폰으로 시험 알림 보내기</button> <span class="small" data-tbtmsg></span>' : ''}`, async fd => {
        const budget = Math.max(0, Math.round(+fd.budget || 0)), per = Math.round(+fd.per || 0), maxAge = Math.round(+fd.maxAge || 0);
        if (per < 1 || per > 20) return '상품당 최대 수량은 1~20개로 넣어 주세요';
        if (maxAge < 1 || maxAge > 336) return '시간은 1~336 사이로 넣어 주세요';
        TBC = { ...TBC, budget, per, maxAge, on: fd.on === 'on' }; await store.set('tbCfg', TBC);
        IS.msg = '오늘 살 것 설정을 바꿨어요'; tbCheck('cfg');
      });
      const tb = document.querySelector('#invDlg [data-tbtest]');
      if (tb) tb.addEventListener('click', async () => {
        const m = document.querySelector('#invDlg [data-tbtmsg]'); tb.disabled = true; if (m) m.textContent = '보내는 중…';
        const r = typeof pushSend === 'function' ? await pushSend('buy', '킥스캔 시험 알림 — 오늘 살 것', '새 수익 상품이 생기면 이렇게 알려 드려요. 누르면 살 것 탭이 열려요', './?t=buy', 'test-' + Date.now(), true) : null;
        if (m) m.textContent = r && r.ok ? `폰 ${r.ok}대에 보냈어요` : `못 보냈어요${r && r.why ? ' — ' + r.why : ''}`; tb.disabled = false;
      });
      return;
    }
  }
}
// [구매 ↗] → 구매 기록(쇼핑몰 주문 자동 연결 · 3일 뒤 '구매하셨나요?')
document.addEventListener('click', e => {
  const a = e.target.closest && e.target.closest('[data-tbbuy]'); if (!a || typeof biRecord !== 'function') return;
  const m = TBMAP.get(a.dataset.tbbuy); if (m) biRecord(m.r, m.C, null, 'buy').catch(() => {});
}, true);

// ---------- 다시 계산 · 새 상품 알림 · 폰에 올리기 ----------
function tbToast(title, body) {
  const cr = window.chrome && chrome.notifications && chrome.notifications.create;
  if (cr) { try { chrome.notifications.create('tb-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title, message: body.slice(0, 220), priority: 1 }); } catch (e) {} }
  // 위쪽 종(app.js topExtras)이 윈도우 알림을 감싸 이미 종에 넣어요 — 못 감쌌을 때만 직접
  if (!(cr && cr.__ks) && typeof notiAdd1 === 'function') notiAdd1(title, body.replace(/\n/g, ' · ')).then(() => { try { notiBadge(); } catch (e) {} });
}
async function tbNotify(fresh) {
  const title = `오늘 살 것 새 상품 ${fresh.length}개`;
  const body = fresh.slice(0, 3).map(x => `${x.name} — ${x.sizes.map(s => s.size).join('·')} · 예상 수익 ${tbWon(x.profit)}`).join('\n') + (fresh.length > 3 ? `\n외 ${fresh.length - 3}개 — 오늘 살 것에서 보기` : '');
  tbToast(title, body);
  if (typeof pushSend === 'function') { try { await pushSend('buy', title, body, './?t=buy', 'buy-' + Date.now()); } catch (e) {} }
}
async function tbPhoneSync() {
  if (!TBL || typeof clRpc !== 'function' || (typeof clOn === 'function' && !clOn())) return;
  const over = new Set(TBL.over.map(x => x.id));
  const items = [...TBL.pick, ...TBL.over].slice(0, 40).map(x => ({ id: x.id, ck: x.ck, code: x.code, name: String(x.name).slice(0, 80), brand: x.brand, img: x.img, site: x.site, url: x.url, unit: x.unit,
    sizes: x.sizes.map(s => ({ size: s.size, q: s.q, url: s.url && s.url !== x.url ? s.url : '' })), q: x.q, cost: x.cost, profit: x.profit, avg: x.avg, n30: x.n30, seller: x.seller, at: x.at, over: over.has(x.id) ? 1 : 0 }));
  const data = { type: 'tbuy', items, budget: TBL.budget, spent: TBL.spent, per: +TBC.per || 2, srcAt: TBL.srcAt, status: 'done' };
  const s = JSON.stringify(data), h = typeof clHash === 'function' ? clHash(s) : String(s.length);
  if (h === TBS.hash && Date.now() - (TBS.syncAt || 0) < 6 * 3600e3) return;
  await clRpc('ks_doc_put', { p_docs: [{ kind: 'job', id: 'tbuy', data: { ...data, at: Date.now() }, by: 'pc', at: new Date().toISOString() }] });
  TBS.hash = h; TBS.syncAt = Date.now(); await store.set('tbState', TBS);
}
async function tbCheck(why) {
  if (IS.tbBusy) { if (why === 'cfg') tbCheck.again = true; return; } IS.tbBusy = true;
  try {
    TBL = await tbList();
    const now = Date.now();
    for (const k of Object.keys(TBS.sent)) if (now - TBS.sent[k] > 3 * 864e5) delete TBS.sent[k];
    for (const k of Object.keys(TBS.skip)) if (TBS.skip[k] < now) delete TBS.skip[k];
    for (const k of Object.keys(TBS.done)) if (now - TBS.done[k].at > TB_DONE) delete TBS.done[k];
    const fresh = TBL.pick.filter(x => !TBS.sent[x.ck]);
    for (const x of fresh) TBS.sent[x.ck] = now;
    // 처음 한 번은 지금 있는 것만 기억해요(업데이트 직후 한꺼번에 울리지 않게)
    if (!TBS.base) TBS.base = now; else if (fresh.length && TBC.on) await tbNotify(fresh);
    await store.set('tbState', TBS);
    try { await tbPhoneSync(); } catch (e) {}
  } catch (e) { console.warn('todaybuy', e); }
  finally { IS.tbBusy = false; }
  if (tbHere() || why === 'view' || why === 'act' || why === 'cfg') { try { if (tbHere()) renderInv(); } catch (e) {} }
  if (tbCheck.again) { tbCheck.again = false; return tbCheck('cfg'); }   // 계산 도중 필터를 바꿨으면 한 번 더
}
// 폰 앱 › 살 것 탭 [샀어요] · [안 살래요] (cloud.js clApply 가 불러요)
async function tbPhoneAct(d) {
  const ck = tbCk(d.ck || d.code); if (!ck) return;
  if (d.act === 'done') {
    const x = TBL && [...TBL.pick, ...TBL.over].find(y => y.ck === ck);
    TBS.done[ck] = { at: Date.now(), day: tbDay(), cost: x ? x.cost : (+d.cost || 0), q: x ? x.q : (+d.q || 0), name: String((x && x.name) || d.name || ck).slice(0, 60), from: 'phone' };
    const m = x && TBMAP.get(x.id); if (m && typeof biRecord === 'function') { try { await biRecord(m.r, m.C, null, 'buy'); } catch (e) {} }
  } else if (d.act === 'skip') TBS.skip[ck] = Date.now() + TB_SKIP;
  else if (d.act === 'undo') delete TBS.done[ck];
  await store.set('tbState', TBS);
  tbCheck('phone').catch(() => {});
}

(async function tbBoot() {
  try { TBC = { ...TBC_DEF, ...((await store.get('tbCfg', null)) || {}) }; TBS = { ...TBS, ...((await store.get('tbState', null)) || {}) }; } catch (e) {}
  setTimeout(() => tbCheck('boot').catch(() => {}), 50e3);
  setInterval(() => tbCheck('tick').catch(() => {}), 30 * 60e3);
  // 소싱이 도는 동안 결과가 바뀌면 5분에 한 번 다시 계산 — 새 수익 상품을 실행이 끝나기 전에도 알려요
  window.addEventListener('src:rows', () => { if (tbBoot.t) return; tbBoot.t = setTimeout(() => { tbBoot.t = null; tbCheck('rows').catch(() => {}); }, 5 * 60e3); });
})();
