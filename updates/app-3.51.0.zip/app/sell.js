/* 킥스캔 — 일반 판매 (줍픽 오피스 일반 판매: 판매 중 · 공매도 · 발송 · 검수 · 판매 내역 · 확인 필요 · 재고 연동)
   KREAM 입찰(abid.js abList) · 진행 중 판매(auto.js kSales.pending) · 못 넣은 판매(kSales.unrec) · 재고관리 판매(INV.outs)를 한 곳에서 봐요.
   POIZON 판매 등록 · 주문은 오픈 API 승인 뒤(단계 3)에 같은 표에 들어와요. */
const SL_TABS = [['on', '판매 중'], ['short', '공매도'], ['ship', '발송'], ['insp', '검수'], ['hist', '판매 내역'], ['check', '확인 필요'], ['cross', '재고 연동']];
const slS = () => IS.sl || (IS.sl = { tab: 'on', acct: '', q: '', per: 'm3', res: 'all', sub: 'all', sel: {}, msg: '' });
const slPend = () => (typeof kSales !== 'undefined' && kSales.pending) || [];
// 품번 · 사이즈 → 재고(남은 수량 · 평균 매입가)
function slStock() {
  const C = invCalc(), M = new Map();
  for (const l of INV.lots) {
    const left = C.left.get(l.id) || 0; if (left <= 0) continue;
    const it = itemOf(l.itemId); if (!it) continue;
    for (const c of String(it.code || '').split('/')) { const k = codeKey(c) + '|' + ckey(l.size); const s = M.get(k) || { qty: 0, cost: 0 }; s.qty += left; s.cost += left * (+l.cost || 0); M.set(k, s); }
  }
  return M;
}
const slKey = (code, size) => codeKey(code) + '|' + ckey(size);
const slFee = (p, a) => typeof feeOf === 'function' ? feeOf(p, null, a) : Math.floor(p * 0.066);
const slAgo = t => { if (!t) return ''; const m = Math.floor((Date.now() - t) / 60e3); return m < 1 ? '방금' : m < 60 ? `${m}분 전` : m < 1440 ? `${Math.floor(m / 60)}시간 전` : `${Math.floor(m / 1440)}일 전`; };
function slBids() {
  const S0 = slS(), q = S0.q.trim().toLowerCase();
  return (typeof abList !== 'undefined' ? abList : []).filter(a => !a.gone && (!S0.acct || (S0.acct === 'fast' ? a.type === 'fast' : a.type !== 'fast')))
    .filter(a => !q || [a.name, a.code, a.size].join(' ').toLowerCase().includes(q));
}

// ---------- 판매 중 ----------
function slOn() {
  const S0 = slS(), st = slStock(), B = slBids().filter(a => !a.short);
  const G = new Map(); for (const a of B) { const k = slKey(a.code, a.size) + '|' + a.price + '|' + (a.type || ''); const g = G.get(k) || { a, n: 0, keys: [] }; g.n++; g.keys.push(a.key); G.set(k, g); }
  const need = new Map(); for (const a of slBids().filter(x => !x.short)) { const k = slKey(a.code, a.size); need.set(k, (need.get(k) || 0) + 1); }
  let cost = 0, sell = 0, prof = 0, noRec = 0, recN = 0;
  const rows = [...G.values()].map(g => {
    const a = g.a, k = slKey(a.code, a.size), s = st.get(k), unit = s && s.qty ? s.cost / s.qty : null, short = Math.max(0, (need.get(k) || 0) - (s ? s.qty : 0));
    const net = (+a.price || 0) - slFee(+a.price || 0, a) - (+((typeof S !== 'undefined' && S.ship) || 0));
    if (unit != null) { cost += unit * g.n; sell += net * g.n; prof += (net - unit) * g.n; recN += g.n; } else noRec += g.n;
    const m = a.mk || {}, comp = m.minAsk == null ? '<span class="small">–</span>' : m.minAsk >= +a.price ? '<span class="pill ok">최저가</span>' : `<span class="pill warn">최저 ${won(m.minAsk)}</span>`;
    return `<tr><td><input type="checkbox" data-a="slSel" data-v="${esc(g.keys.join(','))}"${g.keys.every(x => S0.sel[x]) ? ' checked' : ''}></td><td class="l">${itPic(a)}${esc(String(a.name || a.code).slice(0, 38))}</td><td class="l mono">${esc(a.code || '')}</td><td class="l">${esc(a.size)}</td><td class="l">${a.type === 'fast' ? 'KREAM 보관' : 'KREAM'}</td><td>${g.n}</td>
      <td class="l">${s ? `${s.qty}개` : '<span class="small">매입 기록 없음</span>'}${short ? ` <span class="pill bad">${short}개 모자람</span>` : ''}</td><td>${unit != null ? won(unit) : '–'}</td><td><b>${won(a.price)}</b></td><td>${comp}</td>
      <td class="${unit != null && net - unit < 0 ? 'neg' : 'pos'}">${unit != null ? wonS(Math.round((net - unit) * g.n)) : '–'}</td><td class="l"><span class="pill mute">판매 중</span></td>
      <td><a class="ghost tiny" href="https://kream.co.kr/sell/${esc(a.pid)}?size=${encodeURIComponent(a.size)}${a.askId ? '&ask=' + esc(a.askId) : ''}" target="_blank" rel="noopener">수정 ↗</a><a class="ghost tiny" href="https://kream.co.kr/my/selling" target="_blank" rel="noopener" title="KREAM 판매 입찰 화면에서 [입찰 지우기]로 내려요">내리기 ↗</a></td></tr>`;
  }).join('');
  const selN = Object.values(S0.sel).filter(Boolean).length;
  const loaded = typeof XS !== 'undefined' && XS.km && XS.km.selling && XS.km.selling.at;
  return `<div class="kgrid stk-cards">${card('매입 원가', won(cost), '', `KREAM ${recN}개${noRec ? ` · 매입 기록 없는 ${noRec}개 제외` : ''}`)}${card('예상 판매가', won(sell), 'acc', '지금 판매가에 다 팔리면 받는 정산 금액(수수료 뺀 값)')}${card('= 예상 손익', wonS(Math.round(prof)), prof >= 0 ? 'pos' : 'neg', '예상 판매가 − 매입 원가')}</div>
  <div class="stk-bar"><b>판매 물품</b> <span class="small">${G.size}건 · ${B.length}개${loaded ? ` · KREAM ${slAgo(loaded)} 불러옴` : ''}</span><input data-k="slQ" value="${esc(S0.q)}" placeholder="상품명 · 품번 · 사이즈" class="stk-q"><span class="topsp"></span><span class="small">${selN}개 선택</span><button type="button" class="ghost small" data-a="slMarkShort"${selN ? '' : ' disabled'}>공매도로 표시</button><button type="button" class="ghost small" data-a="slSelX"${selN ? '' : ' disabled'}>선택 해제</button></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th></th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">판매처</th><th>등록 수량</th><th class="l">재고</th><th>매입가</th><th>판매가</th><th>가격 경쟁</th><th>예상 손익</th><th class="l">상태</th><th></th></tr></thead>
  <tbody>${rows || '<tr><td colspan="13" class="empty">판매 중인 입찰이 없어요 — 위 [↻ KREAM 입찰 불러오기]를 누르거나, 재고 현황에서 [KREAM 에 올리기]로 올려요</td></tr>'}</tbody></table></div>
  <p class="hint">같은 사이즈 입찰이 재고보다 많으면 몇 개 모자란지 빨갛게 보여요. 공매도로 표시한 입찰은 여기와 '확인 필요 · 재고보다 많음'에 나오지 않아요.</p>`;
}

// ---------- 공매도 ----------
function slShort() {
  const S0 = slS(), all = (typeof abList !== 'undefined' ? abList : []).filter(a => a.short);
  const sold = new Set(Object.values((typeof kSales !== 'undefined' && kSales.unrec) || {}).map(u => slKey(u.code, u.size)));
  const stOf = a => !a.gone ? '입찰 중' : sold.has(slKey(a.code, a.size)) ? '매입 필요' : '내린 입찰';
  const cnt = t => all.filter(a => stOf(a) === t).length;
  const L = S0.sub === 'all' ? all : all.filter(a => stOf(a) === S0.sub);
  const chip = (v, t) => `<button type="button" class="chip${S0.sub === v ? ' on' : ''}" data-a="slSub" data-v="${v}">${t}</button>`;
  return `<div class="stk-bar">${chip('입찰 중', `입찰 중 ${cnt('입찰 중')}`)}${chip('매입 필요', `매입 필요 ${cnt('매입 필요')}`)}${chip('내린 입찰', `내린 입찰 ${cnt('내린 입찰')}`)}${chip('all', `기록 ${all.length}`)}<span class="topsp"></span><button type="button" class="primary small" data-a="slShortAdd">공매도 추가</button></div>
  <p class="hint">공매도 — 매입 전에 등록한 입찰이에요 · 입찰 중 공매도 수량 ${cnt('입찰 중')}개 · 보유 재고와 비교하지 않아요. 팔리면 '매입 필요'로 옮겨요 — 매입처에서 사서 [매입 등록]해 주세요.</p>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">표시한 날</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">매입처</th><th>KREAM 공매도 수량</th><th>판매가</th><th>매입 예정가</th><th>예상 손익</th><th class="l">상태</th><th></th></tr></thead><tbody>
  ${L.map(a => { const sh = a.short || {}, net = (+a.price || 0) - slFee(+a.price || 0, a); const st = stOf(a); return `<tr><td class="l">${esc(sh.at ? new Date(sh.at).toLocaleDateString('ko-KR') : '')}</td><td class="l">${itPic(a)}${esc(String(a.name || '').slice(0, 36))}</td><td class="l mono">${esc(a.code || '')}</td><td class="l">${esc(a.size)}</td><td class="l">${esc(sh.from || '–')}</td><td>1</td><td>${won(a.price)}</td><td>${sh.cost ? won(sh.cost) : '–'}</td><td class="${sh.cost && net - sh.cost < 0 ? 'neg' : 'pos'}">${sh.cost ? wonS(net - sh.cost) : '–'}</td><td class="l"><span class="pill ${st === '매입 필요' ? 'bad' : st === '입찰 중' ? 'ok' : 'mute'}">${st}</span></td><td><button type="button" class="ghost tiny" data-a="slShortOff" data-v="${esc(a.key)}">표시 풀기</button></td></tr>`; }).join('') || '<tr><td colspan="11" class="empty">[공매도 추가]에서 품번으로 새로 등록하거나, 판매 중 목록에서 매입 전에 건 입찰을 [공매도로 표시]하면 여기 모여요. 소싱 결과의 상세 창 [공매도]로도 등록해요.</td></tr>'}
  </tbody></table></div>`;
}

// ---------- 발송 · 검수 (KREAM 진행 중 판매) ----------
function slShip() {
  const S0 = slS(), P = slPend();
  const ships = INV.ships || [];
  const wait = P.filter(p => /발송|요청|대기/.test(p.status || '') && !/완료|검수|입고/.test(p.status || '') && !ships.some(s => (s.ids || []).includes(p.id)));
  const sub = S0.sub === 'done' ? 'done' : 'wait';
  const rowsW = wait.map(p => { const d = p.date ? Math.max(0, Math.floor((Date.now() - new Date(String(p.date).slice(0, 10) + 'T00:00:00')) / 864e5)) : null; return `<tr><td><input type="checkbox" data-a="slSel" data-v="${esc(p.id)}"${S0.sel[p.id] ? ' checked' : ''}></td><td class="l">${esc(String(p.date || '').slice(0, 10))}</td><td class="l">${itPic(p)}${esc(String(p.name || '').slice(0, 36))}</td><td class="l mono">${esc(p.code || '')}</td><td class="l">${esc(p.size || '')}</td><td class="l">KREAM</td><td class="l small">${esc(p.status || '')}</td><td>${d != null ? `<span class="${d >= 2 ? 'neg' : ''}">${d}일</span>` : '–'}</td><td>1</td><td>${won(p.price)}</td></tr>`; }).join('');
  const rowsD = ships.slice().reverse().map(s => `<tr><td class="l">${esc(s.date)}</td><td class="l">${esc(s.courier || '')}</td><td class="l mono">${esc(s.no || '')}</td><td>${(s.ids || []).length || s.n || 0}개</td><td>${s.cost ? won(s.cost) : '–'}</td><td class="l small">${esc(s.memo || '')}</td></tr>`).join('');
  const selN = wait.filter(p => S0.sel[p.id]).length;
  return `<div class="stk-bar"><button type="button" class="chip${sub === 'wait' ? ' on' : ''}" data-a="slSub" data-v="wait">보낼 주문 ${wait.length}</button><button type="button" class="chip${sub === 'done' ? ' on' : ''}" data-a="slSub" data-v="done">발송 내역 ${ships.length}</button><span class="topsp"></span>${sub === 'wait' ? `<span class="small">${selN}건 선택</span><button type="button" class="primary small" data-a="slShipReg"${selN ? '' : ' disabled'}>발송 등록</button>` : ''}<button type="button" class="ghost small" data-a="slShipXls">송장 양식 내려받기</button><label class="ghost small filebtn">엑셀(CSV)로 송장 넣기<input type="file" accept=".csv,text/csv" data-k="slShipFile" hidden></label><button type="button" class="ghost small" data-a="go" data-v="kship">KREAM 발송관리 ›</button></div>
  ${sub === 'wait' ? `<div class="tbl"><table class="main stk-t"><thead><tr><th></th><th class="l">주문일</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">판매처</th><th class="l">단계</th><th>기다린 날</th><th>수량</th><th>판매가</th></tr></thead><tbody>${rowsW || '<tr><td colspan="10" class="empty">보낼 주문이 없어요. 판매처를 연결하면 새 주문이 여기에 자동 등록돼요 — 판매처 연동의 새 판매 확인 주기마다 갱신해요.</td></tr>'}</tbody></table></div>`
    : `<div class="tbl"><table class="main"><thead><tr><th class="l">보낸 날</th><th class="l">택배사</th><th class="l">운송장</th><th>포함 수량</th><th>택배비</th><th class="l">메모</th></tr></thead><tbody>${rowsD || '<tr><td colspan="6" class="empty">발송 기록이 없어요</td></tr>'}</tbody></table></div>`}
  <p class="hint">발송 기한은 KREAM 발송관리 화면 기준이에요. 송장 입력 · 발송 처리는 KREAM 에서 하고, 여기에는 택배비(지출로 자동 등록)와 운송장을 남겨요.</p>`;
}
function slInsp() {
  const S0 = slS(), P = slPend(), bad = P.filter(p => /불합격|반송|보류/.test(p.status || '')), ing = P.filter(p => /검수|입고/.test(p.status || '') && !/불합격|반송|보류/.test(p.status || ''));
  const L = S0.sub === 'bad' ? bad : ing;
  return `<div class="stk-bar"><button type="button" class="chip${S0.sub !== 'bad' ? ' on' : ''}" data-a="slSub" data-v="ing">검수 중 ${ing.length}</button><button type="button" class="chip${S0.sub === 'bad' ? ' on' : ''}" data-a="slSub" data-v="bad">불합격 ${bad.length}</button></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">판매일</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">구분</th><th class="l">계정</th><th>판매가</th><th class="l">검수 결과</th></tr></thead><tbody>
  ${L.map(p => `<tr><td class="l">${esc(String(p.date || '').slice(0, 10))}</td><td class="l">${itPic(p)}${esc(String(p.name || '').slice(0, 36))}</td><td class="l mono">${esc(p.code || '')}</td><td class="l">${esc(p.size || '')}</td><td class="l">일반 판매</td><td class="l">KREAM</td><td>${won(p.price)}</td><td class="l"><span class="pill ${/불합격|반송|보류/.test(p.status || '') ? 'bad' : 'warn'}">${esc(p.status || '')}</span></td></tr>`).join('') || `<tr><td colspan="8" class="empty">${S0.sub === 'bad' ? '불합격된 판매가 없어요' : 'KREAM 에 보낸 뒤 검수 중인 판매가 여기 보여요'}</td></tr>`}
  </tbody></table></div><p class="hint">KREAM 진행 중 판매(판매처 연동 › 새 판매 확인 ${typeof LKS !== 'undefined' && LKS.kream && LKS.kream.okAt ? slAgo(LKS.kream.okAt) : '전'}) 기준이에요. 검수가 끝나 정산되면 판매 내역으로 옮겨져요.</p>`;
}

// ---------- 판매 내역 ----------
function slHist() {
  const S0 = slS(), since = typeof stkSince === 'function' ? stkSince(S0.per) : '', q = S0.q.trim().toLowerCase();
  let L = INV.outs.filter(o => o.kind !== 'pre' && (o.settled || o.settleDate) && (!since || (o.settleDate || o.date || '') >= since));
  if (q) L = L.filter(o => { const it = itemOf(o.itemId); return [it ? itName(it) : '', it && it.code, o.size].join(' ').toLowerCase().includes(q); });
  const fail = o => (o.retQty || 0) >= o.qty;
  const LR = S0.res === 'ok' ? L.filter(o => !fail(o)) : S0.res === 'fail' ? L.filter(fail) : L;
  let rev = 0, cogs = 0, fees = 0, adj = 0, n = 0;
  for (const o of L) { const x = outNums(o); rev += x.rev; cogs += x.cogs; fees += x.fees; adj += x.ship || 0; n += x.net; }
  const prof = rev - cogs - fees - adj, rate = rev ? Math.round(prof / rev * 1000) / 10 : null;
  const pz = p => { const P = partnerOf(p); return P ? P.name : ''; };
  return `<div class="stk-bar">${(typeof STK_PER !== 'undefined' ? STK_PER : []).map(([k, t]) => `<button type="button" class="chip${S0.per === k ? ' on' : ''}" data-a="slPer" data-v="${k}">${t}</button>`).join('')}<span class="topsp"></span><button type="button" class="ghost small" data-a="slPaste">정산서 붙여넣기</button><button type="button" class="ghost small" data-a="nav" data-v="io">판매된 내역 등록</button><button type="button" class="ghost small" data-a="slHistXls">엑셀 내려받기</button><button type="button" class="ghost small" data-a="slCashXls">현금영수증 양식</button></div>
  <div class="sl-band"><span><small>매출</small><b>${won(rev)}</b><i>${n}개 판매</i></span><em>−</em><span><small>원가</small><b>${won(cogs)}</b><i>판매 상품 매입가</i></span><em>−</em><span><small>수수료</small><b>${won(fees)}</b><i>판매처가 뗀 금액</i></span><em>−</em><span><small>정산 차감 · 가산</small><b>${won(adj)}</b><i>배송비 · 페널티 등</i></span><em>=</em><span class="tot"><small>손익</small><b class="${prof >= 0 ? 'pos' : 'neg'}">${wonS(Math.round(prof))}</b><i>마진율 ${rate == null ? '–' : rate + '%'} · 판매 건의 손익만</i></span></div>
  <div class="stk-bar"><button type="button" class="chip${S0.res === 'all' ? ' on' : ''}" data-a="slRes" data-v="all">전체</button><button type="button" class="chip${S0.res === 'ok' ? ' on' : ''}" data-a="slRes" data-v="ok">거래 성공</button><button type="button" class="chip${S0.res === 'fail' ? ' on' : ''}" data-a="slRes" data-v="fail">거래 실패</button><input data-k="slQ" value="${esc(S0.q)}" placeholder="상품명 · 품번 · 사이즈" class="stk-q"></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">판매일</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">계정</th><th>수량</th><th>구매자 반품</th><th>개당 판매가</th><th>개당 수수료</th><th>개당 매입가</th><th>손익</th></tr></thead><tbody>
  ${LR.slice().sort((a, b) => (b.settleDate || b.date || '').localeCompare(a.settleDate || a.date || '')).slice(0, 400).map(o => { const it = itemOf(o.itemId), x = outNums(o); return `<tr><td class="l">${esc(o.settleDate || o.date || '')}</td><td class="l">${itPic(it)}${esc(it ? itName(it) : '')}</td><td class="l mono">${esc(it ? String(it.code || '').split('/')[0] : '')}</td><td class="l">${esc(o.size)}</td><td class="l">${esc(pz(o.partnerId))}</td><td>${o.qty}</td><td>${o.retQty ? `<span class="neg">${o.retQty}</span>` : '–'}</td><td>${won(x.price)}</td><td>${won(x.fee)}</td><td>${won(x.unitCost)}</td><td class="${x.margin >= 0 ? 'pos' : 'neg'}">${x.margin != null ? wonS(Math.round(x.margin)) : '–'}</td></tr>`; }).join('') || '<tr><td colspan="11" class="empty">[판매된 내역 등록]으로 한 건씩 등록하거나, [정산서 붙여넣기]로 정산 표를 그대로 넣으세요. KREAM 판매는 판매처 연동으로 자동 등록돼요.</td></tr>'}
  </tbody></table></div>`;
}

// ---------- 확인 필요 ----------
function slCheck() {
  const st = slStock(), U = Object.entries((typeof kSales !== 'undefined' && kSales.unrec) || {});
  const need = new Map(); for (const a of slBids().filter(x => !x.short && x.type !== 'fast')) { const k = slKey(a.code, a.size); const g = need.get(k) || { a, n: 0 }; g.n++; need.set(k, g); }
  const over = [...need.entries()].map(([k, g]) => ({ ...g, have: (st.get(k) || { qty: 0 }).qty })).filter(g => g.n > g.have);
  const at = typeof LKS !== 'undefined' && LKS.kream && LKS.kream.okAt;
  const rows = U.map(([id, u]) => `<tr><td class="l">${esc(String(u.name || '').slice(0, 36))}</td><td class="l mono">${esc(u.code)}</td><td class="l">${esc(u.size)}</td><td>1 <span class="small">${esc(u.date || '')} ${won(u.price)}</span></td><td>–</td><td class="l"><span class="pill bad">못 넣은 판매</span> <span class="small">${esc(u.why || '')}</span></td></tr>`).join('')
    + over.map(g => `<tr><td class="l">${esc(String(g.a.name || '').slice(0, 36))}</td><td class="l mono">${esc(g.a.code)}</td><td class="l">${esc(g.a.size)}</td><td>–</td><td>${g.n}개</td><td class="l"><span class="pill warn">재고보다 많음</span> <span class="small">재고 ${g.have}개에 입찰 ${g.n}건 — ${g.n - g.have}개 모자라요</span></td></tr>`).join('');
  return `<div class="stk-bar"><button type="button" class="ghost small" data-a="slSync">↻ 갱신 · ${at ? slAgo(at) : '아직 안 함'}</button><span class="small">못 넣은 판매 ${U.length} · 재고보다 많은 입찰 ${over.length}</span><span class="topsp"></span><button type="button" class="ghost small" data-a="slGoImp">재고 가져오기 ›</button></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th>못 넣은 판매</th><th>판매 중</th><th class="l">사유</th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="empty">판매 내역에 못 넣은 주문도, 재고보다 많이 올린 판매도 없어요.</td></tr>'}</tbody></table></div>
  ${typeof pcCheckHTML === 'function' ? pcCheckHTML() : ''}
  <p class="hint">못 넣은 판매는 재고에 매입 기록이 없어서예요 — 재고 가져오기에서 매입가를 채우면 다음 갱신 때 판매 내역으로 들어가요.</p>`;
}
function slCross() {
  return `<div class="kgrid stk-cards">${card('차감 완료', '0건', '', '최근 30일')}${card('차감 실패', '0건', '')}${card('연동 보류', '–', '')}${card('재고 복원', '0건', '', '팔린 주문이 취소되면 다시 올리라고 알려요')}</div>
  <div class="panel"><p class="hint"><b>재고 연동은 POIZON 오픈 API 승인 뒤에 켜져요.</b> 한쪽(KREAM · POIZON)에서 팔리면 다른 판매처의 같은 사이즈 등록 수량을 보유 재고에 맞춰 차감해요(팔린 수량만큼 · 판매가가 높은 순 · 10분에 정한 건수까지). 지금은 KREAM 만 연결돼 있어서 차감할 반대편이 없어요.</p></div>`;
}

// 11/23 덧붙임: '크림 · 개인' · '크림 · 입점' 메뉴 묶음 대신 계정 칩 — [KREAM 입점]을 고르면 입점 판매자 센터에서 읽어 온 표(auto.js partnerData)를 같은 탭에서 봐요
const slPOn = () => typeof LKP === 'undefined' || LKP.kPartner !== false;
const SL_PV = { on: 'pbid', ship: 'pship', hist: 'psales' };
function slPartner(v) {
  const D = (typeof partnerData !== 'undefined' && partnerData[v]) || null;
  const st = (typeof acctState !== 'undefined' && acctState.kreamp) || {};
  const head = D ? (D.head.length ? D.head : (D.rows[0] || []).map((_, i) => '칸 ' + (i + 1))) : [];
  const tbl = D && D.rows.length ? `<div class="tbl"><table class="main stk-t"><thead><tr><th class="l">계정</th>${head.map(h => `<th class="l">${esc(h)}</th>`).join('')}</tr></thead><tbody>${D.rows.map(r => `<tr><td class="l"><span class="pill mute">KREAM 입점</span></td>${r.map(c => `<td class="l">${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : '';
  const what = { pbid: '일반판매 입찰 목록', pship: '발송 대기 · 발송 요청', psales: '판매(정산) 내역', pinv: '보관판매(신청 · 보관 중)' }[v];
  return `<div class="stk-bar"><span class="small">KREAM 입점 · ${st.st === 'on' ? '로그인됨' : st.st === 'off' ? '로그인 필요' : '확인 전'}${D ? ` · ${esc(new Date(D.at).toLocaleString('ko-KR'))} 읽음 · ${D.rows.length}줄` : ''}</span><span class="topsp"></span><button type="button" class="ghost small" data-a="slPOpen">판매자 센터 열기</button><button type="button" class="ghost small" data-a="slPRead" data-v="${v}">지금 화면 읽기</button></div>
  ${tbl || `<div class="panel"><p class="empty">${D ? '그 화면에서 표를 못 찾았어요 — 목록이 보이는 화면에서 다시 읽어 주세요.' : `① [판매자 센터 열기] → 로그인 → ② 판매자 센터의 ${what} 화면으로 가서 → ③ [지금 화면 읽기]를 누르면 여기에 들어와요.`}</p></div>`}
  <p class="hint">재고와 매입 기록은 한 벌이에요 — KREAM 개인 계정과 입점 계정 어느 쪽에서 팔려도 같은 재고에서 빠져요.</p>`;
}

function vSell() {
  const S0 = slS();
  const busy = typeof XS !== 'undefined' && XS.busy;
  const right = `<button type="button" class="ghost" data-a="slLoad"${busy ? ' disabled' : ''}>↻ KREAM 입찰 불러오기</button><button type="button" class="ghost" data-a="slRules">판매 규칙</button><button type="button" class="primary" data-a="slGoStock">판매 등록 ▾</button>`;
  if (S0.acct === 'partner' && (!slPOn() || !SL_PV[S0.tab])) S0.acct = '';
  const chips = [['', '전체'], ['normal', 'KREAM'], ['fast', 'KREAM 보관'], ...(slPOn() && SL_PV[S0.tab] ? [['partner', 'KREAM 입점']] : [])].filter(([v]) => v !== 'fast' || ['on', 'short'].includes(S0.tab));
  if (S0.acct === 'fast' && !['on', 'short'].includes(S0.tab)) S0.acct = '';
  const acct = ['on', 'short', 'ship', 'hist'].includes(S0.tab) ? `<div class="stk-bar">${chips.map(([v, t]) => `<button type="button" class="chip${S0.acct === v ? ' on' : ''}" data-a="slAcct" data-v="${v}">${t}</button>`).join('')}<button type="button" class="chip" disabled title="POIZON 오픈 API 승인 뒤">POIZON</button></div>` : '';
  const body = S0.acct === 'partner' && SL_PV[S0.tab] ? () => slPartner(SL_PV[S0.tab]) : { on: slOn, short: slShort, ship: slShip, insp: slInsp, hist: slHist, check: slCheck, cross: slCross }[S0.tab] || slOn;
  // 11/22 줍픽: 위쪽 '판매 중 다른 탭에 처리할 항목이 있어요 ▾'
  const todo = [];
  try {
    const P = slPend(), ships = INV.ships || [];
    const wait = P.filter(p => /발송|요청|대기/.test(p.status || '') && !/완료|검수|입고/.test(p.status || '') && !ships.some(s => (s.ids || []).includes(p.id))).length;
    const bad = P.filter(p => /불합격|반송|보류/.test(p.status || '')).length, unrec = Object.keys((typeof kSales !== 'undefined' && kSales.unrec) || {}).length;
    if (wait && S0.tab !== 'ship') todo.push(['ship', `보낼 주문 ${wait}건`]); if (bad && S0.tab !== 'insp') todo.push(['insp', `검수 불합격 ${bad}건`]); if (unrec && S0.tab !== 'check') todo.push(['check', `못 넣은 판매 ${unrec}건`]);
    const noCode = typeof pcMissing === 'function' ? pcMissing().length : 0; if (noCode && S0.tab !== 'check') todo.push(['check', `품번 없는 상품 ${noCode}개`]);
  } catch (e) {}
  const todoBar = todo.length ? `<details class="sl-todo"><summary>${S0.tab === 'on' ? '판매 중' : '이 탭'} 말고 다른 탭에 처리할 항목이 있어요 ▾</summary>${todo.map(([k, t]) => `<button type="button" class="ghost small" data-a="slTab" data-v="${k}">${t} ›</button>`).join('')}</details>` : '';
  return `${head('일반 판매', 'KREAM 판매 입찰 · 발송 · 검수 · 판매 내역을 한 곳에서 봐요. POIZON 은 오픈 API 승인 뒤에 같이 들어와요.', right)}${typeof flash === 'function' ? flash() : ''}${todoBar}
  <div class="subtabs">${SL_TABS.map(([k, t]) => `<button type="button" data-a="slTab" data-v="${k}" aria-selected="${S0.tab === k}">${t}</button>`).join('')}</div>${acct}${body()}`;
}

// ---------- 동작 ----------
function slParse(txt, seller) {
  const lines = String(txt || '').split(/\r?\n/).map(l => l.split('\t').map(c => c.trim())).filter(r => r.some(Boolean));
  const body = lines.length && /품번|사이즈|판매일|판매가/.test(lines[0].join(' ')) ? lines.slice(1) : lines;
  const dt = s => { s = String(s || '').trim(); const m = s.match(/^(\d{4})[-./](\d{1,2})[-./](\d{1,2})/) || s.match(/^(\d{2})[.](\d{1,2})[.](\d{1,2})/); if (!m) return ''; const y = m[1].length === 2 ? '20' + m[1] : m[1]; return `${y}-${String(m[2]).padStart(2, '0')}-${String(m[3]).padStart(2, '0')}`; };
  const C = invCalc();
  return body.map(c => {
    const code = c[0] || '', size = c[1] || '', date = dt(c[2]), qty = Math.max(1, Math.floor(+String(c[3] || '1').replace(/[^\d]/g, '') || 1)), price = +String(c[4] || '').replace(/[^\d]/g, '') || 0, fee = c[5] ? +String(c[5]).replace(/[^\d]/g, '') || 0 : null;
    const it = INV.items.find(x => String(x.code || '').split('/').some(k => codeKey(k) === codeKey(code)));
    const sz = it && typeof kItemSize === 'function' ? kItemSize(it, size) : size;
    const have = it ? ((C.stock.get(it.id + '|' + sz) || { qty: 0 }).qty) : 0;
    const why = !code ? '품번이 없어요' : !date ? '판매일을 못 읽었어요' : !price ? '판매가가 없어요' : !it ? '재고에 이 품번 상품이 없어요' : have < qty ? `보유 재고 ${have}개 — 모자라요` : '';
    return { code, size: sz, date, qty, price, fee, it, why, seller };
  });
}
async function slAct(a, el) {
  const S0 = slS(), v = el.dataset.v;
  switch (a) {
    case 'slTab': S0.tab = v; S0.sub = v === 'short' ? '입찰 중' : v === 'insp' ? 'ing' : 'wait'; S0.sel = {}; break;
    case 'slAcct': S0.acct = v; break;
    case 'slPOpen': { try { await partnerTab(); IS.msg = '판매자 센터 창을 열었어요 — 로그인하고 목록 화면으로 간 다음 [지금 화면 읽기]를 누르세요'; } catch (e) { IS.msg = '판매자 센터를 못 열었어요 — ' + (e.message || e); } break; }
    case 'slPRead': { try { await xAct('pRead', el); IS.msg = (typeof XS !== 'undefined' && XS.msg) || ''; } catch (e) { IS.msg = '못 읽었어요 — ' + (e.message || e); } break; }
    case 'slSub': S0.sub = v; break;
    case 'slPer': S0.per = v; break;
    case 'slRes': S0.res = v; break;
    case 'slSel': for (const k of String(v).split(',')) S0.sel[k] = !!el.checked; break;
    case 'slSelX': S0.sel = {}; break;
    case 'slRules': if (typeof stOpen === 'function') return stOpen('rule'); route('settings'); return;   // 11/23: 설정 › 판매 규칙
    case 'slGoStock': {
      // 11/22 D2 [판매 등록 ▾] — KREAM 판매 입찰 등록: 보유 재고 · 사이즈 · 판매가 · 입찰 기간(1~180일) · 입찰가 자동 조정 같이 · 한 입찰 = 1개
      const C = invCalc(), opts = [];
      for (const [k, v] of C.stock) { if (!(v.qty > 0)) continue; const id = k.slice(0, k.indexOf('|')), size = k.slice(k.indexOf('|') + 1), it = itemOf(id); if (it) opts.push({ k, it, size, qty: v.qty, cost: Math.round(v.value / v.qty) }); }
      opts.sort((a, b) => itName(a.it).localeCompare(itName(b.it)));
      return invDialog('판매 등록 — KREAM 판매 입찰', `<p class="hint">보유 재고에서 골라 KREAM 에 판매 입찰을 걸어요. 입찰 한 건 = 1개 · 보유 재고보다 많이 걸지 않아요. 판매가를 비우면 설정 › 판매 규칙의 가격 규칙(최저가 · 최소 수익)으로 정해요. 거는 방식은 자동 입찰과 같아요(${esc((typeof AB_MODE !== 'undefined' && AB_MODE[abOpt.mode]) || abOpt.mode)}).</p>
        <div class="dgrid"><label>보유 재고<select name="k">${opts.map(o => opt(o.k, `${itName(o.it).slice(0, 36)} · ${o.size} · ${o.qty}개 · 매입 ${won(o.cost)}`)).join('')}</select></label><label>수량<input type="number" name="n" min="1" value="1"></label>
        <label>판매가(비우면 규칙대로)<input type="number" name="price" step="1000" placeholder="예: 139000"></label><label>입찰 기간<select name="days">${[1, 3, 7, 14, 30, 60, 90, 180].map(d => opt(d, d + '일', d === 180)).join('')}</select></label>
        <label class="chk"><input type="checkbox" name="adj" value="1"> 입찰가 자동 조정 같이 켜기(하한 = 최소 수익 가격)</label></div>
        <p class="hint">POIZON 판매 등록은 오픈 API 승인 뒤에 열려요.</p>`, async fd => {
        const o = opts.find(x => x.k === fd.k); if (!o) return '보유 재고를 골라 주세요';
        if (typeof ALQ === 'undefined') return '판매 등록을 쓸 수 없어요';
        const C2 = invCalc(), lot = INV.lots.filter(l => l.itemId === o.it.id && l.size === o.size && (C2.left.get(l.id) || 0) > 0).sort((a, b) => (b.at || 0) - (a.at || 0))[0];
        if (!lot) return '남은 재고를 못 찾았어요';
        ALQ.push({ lotId: lot.id, at: Date.now() - 10 * 60e3, name: itName(o.it), code: String(o.it.code || '').split('/')[0], size: o.size, qty: Math.max(1, +fd.n || 1), want: Math.max(1, +fd.n || 1), cost: o.cost, st: 'wait', manual: true, fixPrice: +fd.price || 0, days: +fd.days || 180, adj: fd.adj === '1' });
        await alSave(); try { alTick(); } catch (e) {}
        IS.msg = `${itName(o.it).slice(0, 24)} ${o.size} 판매 등록을 시작했어요 — 판매처 연동 › 자동 판매 등록에서 진행을 볼 수 있어요`; renderInv();
      }, '판매 등록');
    }
    case 'slGoImp': IS.stk = { ...(typeof stkS === 'function' ? stkS() : {}), tab: 'imp' }; return go('stock');
    case 'go': return route(v);
    case 'slLoad': if (typeof abLoadBids !== 'function') return; IS.msg = 'KREAM 판매 입찰을 불러오는 중이에요…'; renderInv(); try { await abLoadBids(); IS.msg = 'KREAM 판매 입찰을 불러왔어요'; } catch (e) { IS.msg = '불러오지 못했어요: ' + e.message; } break;
    case 'slSync': if (typeof lkSync === 'function') { IS.msg = 'KREAM 판매 내역을 갱신하는 중이에요…'; renderInv(); await lkSync(true); IS.msg = (typeof LK !== 'undefined' && LK.msg) || '갱신했어요'; } break;
    case 'slMarkShort': {
      const keys = Object.keys(S0.sel).filter(k => S0.sel[k]); if (!keys.length) break;
      return invDialog('공매도로 표시', `<p class="hint">매입 전에 건 입찰이에요 — 보유 재고와 비교하지 않고, 팔리면 '매입 필요'로 옮겨요.</p><div class="dgrid"><label>매입처<input name="from" placeholder="예: 롯데아울렛 파주점 · 무신사"></label><label>매입 예정가 (개당)<input name="cost" type="number" step="1000"></label></div>`, async fd => {
        for (const k of keys) { const b = abList.find(x => x.key === k); if (b) b.short = { at: Date.now(), from: String(fd.from || '').trim(), cost: +fd.cost || 0 }; }
        await abSave(); S0.sel = {}; IS.msg = `${keys.length}건을 공매도로 표시했어요`; renderInv();
      });
    }
    case 'slShortOff': { const b = abList.find(x => x.key === v); if (b) { delete b.short; await abSave(); } break; }
    case 'slShortAdd':
      return invDialog('공매도 추가', `<p class="hint">매입 전에 KREAM 에 판매 입찰을 걸어요. 거는 방식은 자동 입찰과 같아요(${esc((typeof AB_MODE !== 'undefined' && AB_MODE[abOpt.mode]) || abOpt.mode)}).</p><div class="dgrid"><label>품번 *<input name="code" required placeholder="예: DD1391-100" value="${esc(el.dataset.code || '')}"></label><label>사이즈 *<input name="size" required placeholder="예: 270" value="${esc(el.dataset.size || '')}"></label><label>판매가 *<input name="price" type="number" step="1000" required value="${esc(el.dataset.price || '')}"></label><label>입찰 기간<select name="days">${[30, 60, 90, 180].map(d => opt(d, d + '일', d === 180)).join('')}</select></label><label>매입처<input name="from" placeholder="예: 나이키 팩토리 김포" value="${esc(el.dataset.from || '')}"></label><label>매입 예정가 (개당)<input name="cost" type="number" step="1000" value="${esc(el.dataset.cost || '')}"></label></div>`, async fd => {
        const code = String(fd.code || '').trim(), size = String(fd.size || '').trim(), price = Math.ceil((+fd.price || 0) / 1000) * 1000;
        if (!code || !size || !(price >= 1000)) return '품번 · 사이즈 · 판매가를 넣어 주세요';
        if (typeof opsBlock === 'function' && opsBlock('abid')) return opsBlock('abid');
        const f = await kreamByCode(code).catch(() => null); if (!f || !f.pid) return 'KREAM 에서 이 품번을 못 찾았어요';
        if (abOpt.mode === 'notify') { abList.push({ key: 'normal|short-' + Date.now(), askId: '', type: 'normal', pid: String(f.pid), name: f.name || code, code, size, price, status: '공매도(직접 걸어 주세요)', on: false, floor: '', step: 1000, cost: +fd.cost || '', gone: false, short: { at: Date.now(), from: String(fd.from || ''), cost: +fd.cost || 0 }, st: "자동 입찰 방식이 '알림만'이라 KREAM 에서 직접 걸어 주세요" }); await abSave(); IS.msg = `공매도를 기록했어요 — KREAM 에서 ${size} ${won(price)} 입찰을 직접 걸어 주세요`; return renderInv(); }
        const r = await abSellPage(String(f.pid), size, '', price, +fd.days || 180, abOpt.mode === 'auto', { code, name: f.name || code });
        if (r && (r.ready || (r.submitted && r.done))) {
          abList.push({ key: 'normal|short-' + Date.now(), askId: '', type: 'normal', pid: String(f.pid), name: f.name || code, code, size, price, status: '판매 입찰 중', on: false, floor: '', step: 1000, cost: +fd.cost || '', short: { at: Date.now(), from: String(fd.from || ''), cost: +fd.cost || 0 }, st: r.ready ? 'KREAM 확인 화면까지 — 마지막 버튼은 직접' : '공매도 입찰을 걸었어요' });
          await abSave(); IS.msg = r.ready ? 'KREAM 확인 화면까지 열었어요 — 마지막 버튼은 직접 눌러 주세요' : `공매도 ${size} ${won(price)} 입찰을 걸었어요`; return renderInv();
        }
        return (r && (r.mismatch || r.error)) || '입찰을 못 걸었어요';
      }, '입찰 걸기');
    case 'slShipReg': {
      const P = slPend().filter(p => S0.sel[p.id]); if (!P.length) break;
      const cs = INV.couriers || [];
      return invDialog('발송 등록', `<p class="hint">고른 주문 ${P.length}건을 한 상자로 보내요. 택배비는 지출(택배비)로 자동 등록해요.</p><div class="dgrid"><label>창고<select name="wh">${opt('KREAM', 'KREAM')}${opt('POIZON', 'POIZON')}</select></label><label>택배사<select name="courier">${['CJ대한통운', '롯데택배', '한진택배', '우체국택배', '로젠택배', '경동택배', '대신택배', '일양로지스', 'CU 편의점택배', ...cs.map(c => c.name)].filter((x, i, A) => A.indexOf(x) === i).map(c => opt(c, c)).join('')}</select></label><label>운송장<input name="no" placeholder="스캐너로 찍어도 돼요"></label><label>보낸 날<input type="date" name="date" value="${today()}"></label><label>택배비<input type="number" name="cost" step="100" placeholder="0"></label><label>메모<input name="memo"></label></div>`, async fd => {
        if (!String(fd.no || '').trim()) return '운송장 번호를 넣어 주세요';
        INV.ships = INV.ships || []; INV.ships.push({ id: uid(), at: Date.now(), date: fd.date || today(), wh: fd.wh, courier: fd.courier, no: String(fd.no).trim(), cost: +fd.cost || 0, memo: String(fd.memo || ''), ids: P.map(p => p.id) });
        if (+fd.cost > 0) { INV.expenses = INV.expenses || []; INV.expenses.push({ id: uid(), at: Date.now(), date: fd.date || today(), cat: '택배비', amount: +fd.cost, payId: '', vat: false, memo: `${fd.courier} ${String(fd.no).trim()} (${P.length}건 발송)` }); }
        await invSave(); S0.sel = {}; IS.msg = `발송 등록했어요${+fd.cost > 0 ? ` · 택배비 ${won(+fd.cost)}를 지출로 넣었어요` : ''}`; renderInv();
      }, '발송 등록');
    }
    case 'slShipXls': if (typeof stkCsv === 'function') stkCsv([['주문번호', '상품', '품번', '사이즈', '택배사', '운송장'], ...slPend().map(p => [p.id, p.name, p.code, p.size, '', ''])], '송장넣기_양식'); return;
    case 'slHistXls': if (typeof stkCsv === 'function') stkCsv([['판매일', '상품', '품번', '사이즈', '계정', '수량', '구매자 반품', '개당 판매가', '개당 수수료', '개당 매입가', '손익'], ...INV.outs.filter(o => o.settled).map(o => { const it = itemOf(o.itemId), x = outNums(o); return [o.settleDate || o.date, it ? itName(it) : '', it ? it.code : '', o.size, (partnerOf(o.partnerId) || {}).name || '', o.qty, o.retQty || 0, x.price, x.fee, Math.round(x.unitCost), Math.round(x.margin || 0)]; })], '판매내역'); return;
    case 'slCashXls': if (typeof stkCsv === 'function') stkCsv([['거래일자', '거래구분(소득공제/지출증빙)', '고객 식별번호(휴대폰 · 사업자번호)', '공급가액', '부가세', '합계', '상품명']], '현금영수증_양식'); return;
    case 'slPaste': {
      const sells = INV.partners.filter(p => p.kind === 'sell');
      return invDialog('정산서 붙여넣기', `<p class="hint">정산서에서 품번 · 사이즈 · 판매일 · 수량 · 판매가를 복사해 붙여넣으세요. 일반 판매를 넣는 곳이라 보유 재고에서 차감해요. 수수료 칸이 있으면 여섯 번째에 — 그 값이 우선이고, 없으면 거래처 수수료 식으로 계산해요. 날짜는 2026-09-01 · 2026/09/01 · 26.9.1 모두 돼요.</p>
        <div class="dgrid"><label>판매처<select name="seller">${sells.map(p => opt(p.id, p.name)).join('')}</select></label></div><textarea name="txt" rows="8" class="br-paste" placeholder="품번\t사이즈\t판매일\t수량\t판매가\t(수수료)"></textarea><div class="sl-pv"></div>`, async (fd, form) => {
        const R = slParse(fd.txt, fd.seller), ok = R.filter(r => !r.why);
        const pv = form.querySelector('.sl-pv');
        if (!form.dataset.checked) { form.dataset.checked = '1'; pv.innerHTML = `<table class="main"><thead><tr><th class="l">품번</th><th class="l">사이즈</th><th class="l">판매일</th><th>수량</th><th>판매가</th><th class="l">상태</th></tr></thead><tbody>${R.map(r => `<tr><td class="l">${esc(r.code)}</td><td class="l">${esc(r.size)}</td><td class="l">${esc(r.date)}</td><td>${r.qty}</td><td>${won(r.price)}</td><td class="l">${r.why ? `<span class="pill bad">${esc(r.why)}</span>` : '<span class="pill ok">넣을 수 있어요</span>'}</td></tr>`).join('')}</tbody></table>`; return ok.length ? `확인해 보세요 — 넣을 수 있는 ${ok.length}줄만 들어가요. 한 번 더 누르면 등록해요` : '넣을 수 있는 줄이 없어요'; }
        let n = 0;
        for (const r of ok) { const C = invCalc(), costs = allocate(r.it.id, r.size, r.qty, C); if (!costs) continue; INV.outs.push({ id: uid(), at: Date.now() + n, date: r.date, itemId: r.it.id, size: r.size, qty: r.qty, price: r.price, partnerId: r.seller, kind: 'out', settled: true, settleDate: r.date, ship: 0, fee: r.fee != null ? r.fee : '', costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: '정산서 붙여넣기' }); n += r.qty; }
        await invSave(); IS.msg = `${n}개 판매를 넣었어요`; renderInv();
      }, '대조 · 등록');
    }
  }
  renderInv();
}
async function slShipFile(file) {
  const t = await file.text(), rows = t.replace(/^\ufeff/, '').split(/\r?\n/).filter(Boolean).map(l => { const out = []; let cur = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === ',' && !q) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out.map(x => x.trim()); });
  if (rows.length < 2) { IS.msg = '송장 파일에 줄이 없어요'; return renderInv(); }
  const H = rows[0], col = re => H.findIndex(h => re.test(h)), cId = col(/주문/), cC = col(/택배/), cN = col(/운송장|송장/);
  if (cN < 0) { IS.msg = "'운송장' 칸을 못 찾았어요 — 양식의 머리글을 그대로 두고 채워 주세요"; return renderInv(); }
  const G = new Map(); for (const r of rows.slice(1)) { const no = (r[cN] || '').replace(/\s/g, ''); if (!no) continue; const g = G.get(no) || { no, courier: cC >= 0 ? r[cC] : '', ids: [] }; if (cId >= 0 && r[cId]) g.ids.push(r[cId]); G.set(no, g); }
  INV.ships = INV.ships || [];
  for (const g of G.values()) if (!INV.ships.some(s => s.no === g.no)) INV.ships.push({ id: uid(), at: Date.now(), date: today(), wh: 'KREAM', courier: g.courier || '', no: g.no, cost: 0, memo: '엑셀로 송장 넣기', ids: g.ids });
  await invSave(); IS.msg = `송장 ${G.size}개를 발송으로 넣었어요 (같은 운송장은 한 발송으로 묶어요)`; renderInv();
}
function slInput(el, ev) {
  if (el.dataset.k === 'slShipFile') { const f = el.files && el.files[0]; if (f) slShipFile(f); return; }
  const S0 = slS();
  if (el.dataset.k === 'slQ') { S0.q = el.value; clearTimeout(slInput.t); slInput.t = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=slQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, ev.type === 'input' ? 300 : 0); }
}
