'use strict';
/* 킥스캔 개선판 1-3 — 매입처 106곳 (기존 SRC_SITES 17곳 + 아래 89곳)
   아래 매입처는 검색 주소를 미리 넣지 않고, 처음 수집할 때 홈페이지를 열어 검색칸을 찾아요(seSupFind).
   찾은 주소는 store 'srcSupUrl' 에 저장해 다음부터 바로 써요. 못 찾으면 7일 뒤 다시 찾아요.
   [k, 이름, 묶음, 홈, 브랜드(공식몰만 — 그 브랜드를 골랐을 때만 · 품목 낱말로 찾아요), 먼저 써 볼 검색 주소({q})] */
const SE_SUP = [
  // 직매입 (편집숍 · 백화점)
  ['onthespot', '온더스팟', 'direct', 'https://www.onthespot.co.kr/', null, 'https://www.onthespot.co.kr/display/search-word/result?searchWord={q}'],
  ['kasina', '카시나', 'direct', 'https://www.kasina.co.kr/', null, 'https://www.kasina.co.kr/products?keyword={q}'],
  ['hoopcity', 'HOOPCITY', 'direct', 'https://www.hoopcity.co.kr/', null, 'https://www.hoopcity.co.kr/products?keyword={q}'],
  ['fleetrunner', '플릿러너', 'direct', 'https://www.fleetrunner.co.kr/', null, 'https://www.fleetrunner.co.kr/goods/goods_search.php?keyword={q}'],
  ['brickmansion', '브릭맨션', 'direct', 'https://www.brickmansion.co.kr/', null, 'https://www.brickmansion.co.kr/product/search.html?keyword={q}'],
  ['thexshop', 'THEXSHOP', 'direct', 'https://www.thexshop.co.kr/', null, 'https://thexshop.co.kr/product/search.html?keyword={q}'],
  ['tune', 'TUNE', 'direct', 'https://tune.kr/', null, 'https://tune.kr/search?q={q}&type=product'],
  ['jamstore', 'JAMSTORE', 'direct', 'https://jamstore.co.kr/', null, 'https://jamstore.co.kr/product/search.html?keyword={q}'],
  ['premiummultishop', '프리미엄멀티샵', 'direct', 'https://www.premiummultishop.com/', null, 'https://www.premiummultishop.com/product/search.html?keyword={q}'],
  ['yconcepts', 'Y.CONCEPTS', 'direct', 'https://yconcepts.co.kr/', null, 'https://yconcepts.co.kr/product/search.html?keyword={q}'],
  ['onyourmark', 'ON YOUR MARK', 'direct', 'https://onyourmark-running.com/', null, 'https://onyourmark-running.com/product/search.html?keyword={q}'],
  ['whinheart', '히나트', 'direct', 'https://whinheart.com/', null, 'https://whinheart.com/product/search.html?keyword={q}'],
  ['shoegirlgaja', '슈걸가자', 'direct', 'https://shoegirlgaja.com/', null, 'https://shoegirlgaja.com/product/search.html?keyword={q}'],
  ['smarket', 'S.Market', 'direct', 'https://www.smarket.co.kr/', null, 'https://www.smarket.co.kr/goods/goods_search.php?keyword={q}'],
  ['thehyundai', '더현대닷컴', 'direct', 'https://hi.thehyundai.com/', null, 'https://hi.thehyundai.com/search?tab=product&q={q}'],
  ['folder', '폴더', 'direct', 'https://www.folderstyle.com/', null, 'https://www.folderstyle.com/shop/shopbrand.html?search={q}'],
  ['premiumsneakers', '프리미엄스니커즈', 'direct', 'https://premiumsneakers.kr/', null, 'https://premiumsneakers.kr/product/search.html?keyword={q}'],
  ['soccerboom', '사커붐', 'direct', 'https://soccerboom.co.kr/', null, 'https://soccerboom.co.kr/product/search.html?keyword={q}'],
  ['thesogno', '더소뇨', 'direct', 'https://sognomall.com/', null, 'https://sognomall.com/product/search.html?keyword={q}'],
  ['capostore', '카포스토어', 'direct', 'https://www.capostore.co.kr/', null, 'https://www.capostore.co.kr/goods/goods_search.php?keyword={q}'],
  ['runnersclub', '러너스클럽', 'direct', 'https://www.runnersclub.com/', null, 'https://www.runnersclub.com/goods/goods_search.php?keyword={q}'],
  ['ssaka', '싸카닷컴', 'direct', 'https://www.ssaka.com/', null, 'https://www.ssaka.com/pages/product/product-list.html?keywords={q}'],
  ['thegearshop', '더 기어샵', 'direct', 'https://thegearshop.co.kr/', null, 'https://thegearshop.co.kr/products/search?keyword={q}'],
  // 브랜드 공식몰
  ['salomon', '살로몬 공식몰', 'official', 'https://salomon.co.kr/', /살로몬|salomon/i, 'https://salomon.co.kr/search?q={q}&type=product'],
  ['fila', '휠라 공식몰', 'official', 'https://www.fila.co.kr/', /휠라|fila/i, 'https://www.fila.co.kr/search?q={q}&type=product'],
  ['mlb', 'MLB 공식몰', 'official', 'https://www.mlb-korea.com/', /^mlb|엠엘비/i, 'https://www.mlb-korea.com/search?searchText={q}'],
  ['descente', '데상트 공식몰', 'official', 'https://dk-on.com/descente', /데상트|descente/i, 'https://dk-on.com/DESCENTE/search?keyword={q}'],
  ['lecoqsportif', '르꼬끄 공식몰', 'official', 'https://dk-on.com/lecoqsportif', /르꼬끄|le ?coq/i, 'https://dk-on.com/LECOQSPORTIF/search?keyword={q}'],
  ['umbro', '엄브로 공식몰', 'official', 'https://dk-on.com/umbro', /엄브로|umbro/i, 'https://dk-on.com/UMBRO/search?keyword={q}'],
  ['reebok', '리복 공식몰', 'official', 'https://www.reebok.co.kr/', /리복|reebok/i, 'https://www.reebok.co.kr/goods/goods_search.php?keyword={q}'],
  ['timberland', '팀버랜드 공식몰', 'official', 'https://www.timberland.co.kr/', /팀버랜드|timberland/i, 'https://www.timberland.co.kr/search?q={q}'],
  ['newera', '뉴에라 공식몰', 'official', 'https://www.neweracapkorea.com/', /뉴에라|new ?era/i, 'https://www.neweracapkorea.com/shop/shopbrand.html?search=&prize1={q}'],
  ['underarmour', '언더아머 공식몰', 'official', 'https://www.underarmour.co.kr/ko-kr/', /언더아머|under ?armour/i, 'https://www.underarmour.co.kr/ko-kr/search/?q={q}&lang=ko_KR'],
  ['onitsukatiger', '오니츠카타이거 공식몰', 'official', 'https://www.onitsukatiger.com/kr/ko-kr/', /오니츠카|onitsuka/i, 'https://www.onitsukatiger.com/kr/ko-kr/catalogsearch/result/?q={q}'],
  ['onrunning', '온(On) 공식몰', 'official', 'https://www.on.com/ko-kr/', /^on$|^온$|온러닝|on ?running|클라우드/i, 'cat:{"shoes":["https://www.on.com/ko-kr/shop/shoes"],"wear":["https://www.on.com/ko-kr/shop/apparel"]}'],
  ['lacoste', '라코스테 공식몰', 'official', 'https://www.lacoste.com/kr/', /라코스테|lacoste/i, 'https://www.lacoste.com/kr/search?q={q}'],
  ['hoka', '호카 공식 스토어', 'official', 'https://brand.naver.com/hoka', /호카|hoka/i, 'https://brand.naver.com/hoka/search?q={q}'],
  ['saucony', '써코니 공식몰', 'official', 'https://www.saucony.co.kr/', /써코니|saucony/i, 'https://www.saucony.co.kr/product/search.html?banner_action=&order_by=recent&category_no=42&keyword={q}'],
  ['drmartens', '닥터마틴 공식몰', 'official', 'https://www.drmartens.co.kr/', /닥터마틴|dr\.? ?martens/i, 'https://www.drmartens.co.kr/search?q={q}'],
  ['keen', '킨 공식몰', 'official', 'https://www.keenfootwear.kr/', /^킨$|keen/i, 'https://www.keenfootwear.kr/goods/goods_search.php?keyword={q}'],
  ['mizuno', '미즈노 공식몰', 'official', 'https://kor.mizuno.com/', /미즈노|mizuno/i, 'https://kor.mizuno.com/product/search.html?keyword={q}'],
  ['stussy', '스투시 공식몰', 'official', 'https://kr.stussy.com/', /스투시|stussy/i, 'https://kr.stussy.com/search?q={q}&type=product'],
  ['discovery', '디스커버리 공식몰', 'official', 'https://www.discovery-expedition.com/', /디스커버리|discovery/i, 'https://www.discovery-expedition.com/search?searchText={q}'],
  ['brooks', '브룩스 공식몰', 'official', 'https://www.brooksrunning.co.kr/', /브룩스|brooks/i],
  ['birkenstock', '버켄스탁 공식몰', 'official', 'https://www.birkenstock.com/kr/', /버켄스탁|birkenstock/i, 'https://www.birkenstock.com/kr/search/?q={q}'],
  ['gcosmo', '지코스모(G-SHOCK)', 'official', 'https://www.gcosmo.co.kr/', /지샥|g-?shock|카시오|casio/i, 'https://www.gcosmo.co.kr/goods/goods_search.php?keyword={q}'],
  ['adererror', '아더에러 공식몰', 'official', 'https://www.adererror.com/kr/', /아더에러|ader ?error/i, 'https://www.adererror.com/kr/search?keyword={q}'],
  ['patagonia', '파타고니아 공식몰', 'official', 'https://www.patagonia.co.kr/', /파타고니아|patagonia/i, 'https://www.patagonia.co.kr/shop/search/?searchText={q}'],
  ['lego', '레고 공식몰', 'official', 'https://www.lego.com/ko-kr', /레고|lego/i, 'https://www.lego.com/ko-kr/search?q={q}'],
  ['burberry', '버버리 공식몰', 'official', 'https://kr.burberry.com/', /버버리|burberry/i, 'https://kr.burberry.com/search/?query={q}'],
  ['louisvuitton', '루이 비통 공식몰', 'official', 'https://kr.louisvuitton.com/kor-kr/homepage', /루이 ?비통|louis ?vuitton/i, 'https://kr.louisvuitton.com/kor-kr/homepage?search={q}'],
  ['prada', '프라다 공식몰', 'official', 'https://www.prada.com/kr/ko.html', /프라다|prada/i, 'cat:{"bag":["https://www.prada.com/kr/ko/mens/bags/c/10143KR","https://www.prada.com/kr/ko/womens/bags/c/10062KR"],"shoes":["https://www.prada.com/kr/ko/mens/shoes/c/10149KR","https://www.prada.com/kr/ko/womens/shoes/c/10070KR"],"wear":["https://www.prada.com/kr/ko/mens/ready-to-wear/c/10130KR","https://www.prada.com/kr/ko/womens/ready-to-wear/c/10048KR"]}'],
  ['levis', '리바이스 공식몰', 'official', 'https://levi.co.kr/', /리바이스|levi/i, 'https://levi.co.kr/search?q={q}'],
  ['thombrowne', '톰브라운 공식몰', 'official', 'https://www.thombrowne.com/ko-kr', /톰 ?브라운|thom ?browne/i, 'https://www.thombrowne.com/ko-kr/search?q={q}&type=product'],
  ['thisisneverthat', '디스이즈네버댓 공식몰', 'official', 'https://thisisneverthat.com/', /디스이즈네버댓|thisisneverthat/i, 'https://thisisneverthat.com/search?q={q}&type=product'],
  ['calvinklein', '캘빈클라인 공식몰', 'official', 'https://www.calvinklein.co.kr/ko', /캘빈 ?클라인|calvin ?klein/i, 'https://www.calvinklein.co.kr/ko/search/?lang=ko_KR&q={q}'],
  ['coach', '코치 공식몰', 'official', 'https://korea.coach.com/', /^코치$|coach/i, 'https://korea.coach.com/search?q={q}'],
  ['stoneisland', '스톤아일랜드 공식몰', 'official', 'https://www.stoneisland.com/ko-kr', /스톤 ?아일랜드|stone ?island/i, 'https://www.stoneisland.com/ko-kr/?query={q}'],
  ['longchamp', '롱샴 공식몰', 'official', 'https://www.longchamp.com/kr/ko', /롱샴|longchamp/i, 'https://www.longchamp.com/kr/ko/search?q={q}'],
  ['balenciaga', '발렌시아가 공식몰', 'official', 'https://www.balenciaga.com/ko-kr', /발렌시아가|balenciaga/i, 'https://www.balenciaga.com/ko-kr/search?q={q}'],
  ['bottegaveneta', '보테가 베네타 공식몰', 'official', 'https://www.bottegaveneta.com/ko-kr', /보테가|bottega/i, 'https://www.bottegaveneta.com/ko-kr/search?q={q}'],
  ['celine', '셀린느 공식몰', 'official', 'https://www.celine.com/ko-kr/home', /셀린느|celine/i, 'https://www.celine.com/ko-kr/search?q={q}'],
  ['ysl', '생로랑 공식몰', 'official', 'https://www.ysl.com/ko-kr', /생 ?로랑|saint ?laurent|ysl/i, 'https://www.ysl.com/ko-kr/search?q={q}'],
  ['arcteryx', '아크테릭스 공식몰', 'official', 'https://arcteryx.co.kr/', /아크테릭스|arc'?teryx/i, 'https://arcteryx.co.kr/products/category/all?search_keyword={q}'],
  ['uniqlo', '유니클로 공식몰', 'official', 'https://www.uniqlo.com/kr/ko/', /유니클로|uniqlo/i, 'https://www.uniqlo.com/kr/ko/search?q={q}'],
  // 입점몰 (여러 판매자 · 홈쇼핑)
  ['kolonmall', '코오롱몰', 'mall', 'https://www.kolonmall.com/', null, 'https://www.kolonmall.com/Search?keyword={q}'],
  ['lfmall', 'LF몰', 'mall', 'https://www.lfmall.co.kr/', null, 'https://www.lfmall.co.kr/app/search/result/{q}'],
  ['elandmall', '이랜드몰', 'mall', 'https://www.elandmall.co.kr/', null, 'https://www.elandmall.co.kr/s/srch?q={q}'],
  ['halfclub', '하프클럽', 'mall', 'https://www.halfclub.com/', null, 'https://www.halfclub.com/search/{q}'],
  ['reebonz', '리본즈', 'mall', 'https://www.reebonz.co.kr/', null, 'https://www.reebonz.co.kr/product_search?keyword={q}'],
  ['modaoutlet', '모다아울렛', 'mall', 'https://www.modaoutlet.com/', null, 'https://www.modaoutlet.com/global/search/result?keyword={q}'],
  ['gsshop', 'GS SHOP', 'mall', 'https://www.gsshop.com/', null, 'https://www.gsshop.com/shop/search/main.gs?tq={q}'],
  ['boribori', '보리보리', 'mall', 'https://m.boribori.co.kr/', null, 'https://m.boribori.co.kr/search/{q}'],
  ['cjonstyle', 'CJ온스타일', 'mall', 'https://display.cjonstyle.com/', null, 'https://display.cjonstyle.com/p/search/searchAllList?k={q}'],
  ['fashionplus', '패션플러스', 'mall', 'https://www.fashionplus.co.kr/', null, 'https://www.fashionplus.co.kr/search/goods/result?searchWord={q}'],
  ['lotteimall', '롯데홈쇼핑', 'mall', 'https://www.lotteimall.com/', null, 'https://www.lotteimall.com/search/searchMain.lotte?headerQuery={q}'],
  ['hnsmall', '홈앤쇼핑', 'mall', 'https://www.hnsmall.com/', null, 'https://www.hnsmall.com/search/search.do?query_top={q}'],
  ['skstoa', 'SK스토아', 'mall', 'https://www.skstoa.com/', null, 'https://www.skstoa.com/goods-search/page/search?keywordSearch={q}'],
  ['sstvshop', '신세계쇼핑', 'mall', 'https://www.shinsegaetvshopping.com/', null, 'https://www.shinsegaetvshopping.com/goods-search/search?searchKeyword={q}'],
  ['galleria', '갤러리아몰', 'mall', 'https://www.galleria.co.kr/', null, 'https://www.galleria.co.kr/search/totalSearch.action?searchTerm={q}'],
  ['hmall', '현대Hmall', 'mall', 'https://www.hmall.com/', null, 'https://www.hmall.com/md/pde/search?searchTerm={q}'],
  ['lookpin', '룩핀', 'mall', 'https://www.lookpin.co.kr/', null, 'https://www.lookpin.co.kr/search/results?keywords={q}'],
  ['posty', '포스티', 'mall', 'https://posty.kr/', null, 'https://posty.kr/search?query={q}'],
  ['trenbe', '트렌비', 'mall', 'https://www.trenbe.com/', null, 'https://www.trenbe.com/search?keyword={q}'],
  ['jente', '젠테', 'mall', 'https://jentestore.com/', null, 'https://jentestore.com/goods/list?keyword={q}'],
  ['eql', 'EQL', 'mall', 'https://www.eqlstore.com/', null, 'https://www.eqlstore.com/public/search/view?searchWord={q}'],
  ['premiumoutlets', '신세계 아울렛몰', 'mall', 'https://shop.premiumoutlets.co.kr/', null, 'https://shop.premiumoutlets.co.kr/main/search?searchKeyword={q}'],
  ['shinsegaev', '신세계V', 'mall', 'https://www.shinsegaev.com/', null, 'https://www.shinsegaev.com/search/totalSearch.siv?search_kwd={q}'],
  ['istockmall', '아이스탁몰', 'mall', 'https://www.istockmall.com/main', null, 'https://www.istockmall.com/search/list?searchKeyword={q}'],
  // 줍픽 목록엔 없지만 예전부터 '준비 중'이던 곳
  ['crocs', '크록스 공식몰', 'official', 'https://www.crocs.co.kr/', /크록스|crocs/i, 'https://www.crocs.co.kr/search?q={q}'],
  ['worksout', '웍스아웃', 'direct', 'https://www.worksout.co.kr/', null, 'https://www.worksout.co.kr/search/result?searchKeyword={q}'],
  ['msoutlet', '무신사 아울렛', 'direct', 'https://www.musinsa.com/main/outlet', null, 'https://www.musinsa.com/search/goods?keyword={q}&storeCode=outlet'],
  ['auction', '옥션', 'mall', 'https://www.auction.co.kr/', null, 'https://www.auction.co.kr/n/search?keyword={q}'],
  ['hiver', '하이버', 'rare', 'https://www.hiver.co.kr/', null, 'https://www.hiver.co.kr/search?q={q}'],
  ['brandi', '브랜디', 'rare', 'https://www.brandi.co.kr/', null, 'https://www.brandi.co.kr/search?q={q}']
];
const SE_SUP_RETRY = 7 * 864e5;   // 못 찾은 곳은 7일 뒤 다시
// 사이트 플랫폼별 흔한 검색 주소 (검색칸을 못 찾았을 때 차례로 열어 봐요)
const SE_SUP_TRY = ['/search?q={q}', '/search?keyword={q}', '/products/search?keyword={q}', '/product/search.html?keyword={q}', '/goods/goods_search.php?keyword={q}', '/shop/shopbrand.html?search=&prize1={q}', '/search/result?keyword={q}', '/catalogsearch/result/?q={q}'];

// 홈페이지 안에서 실행 — 검색칸이 든 폼과 사이트 플랫폼을 찾아요 (읽기만)
function kcSupSearch() {
  const out = [], NAME = /^(q|query|keyword|keywords|kwd|searchword|search_keyword|searchkeyword|sword|schword|search_text|searchterm|searchtext|word|k|tq|search|qry|key|sKeyword|search_word)$/i;
  for (const f of document.querySelectorAll('form')) {
    const inp = [...f.querySelectorAll('input')].find(i => /^(search|text|)$/i.test(i.type || '') && i.name && NAME.test(i.name));
    if (!inp) continue;
    const act = f.getAttribute('action') || '';
    if (/login|member|join|newsletter|mail|cart|order/i.test(act)) continue;
    try {
      const u = new URL(act || location.pathname, location.href);
      if (u.origin !== location.origin && !/search/i.test(u.href)) continue;
      for (const x of f.querySelectorAll('input[type=hidden]')) if (x.name && x.value != null && String(x.value).length < 40 && !/token|csrf|nonce/i.test(x.name)) u.searchParams.set(x.name, x.value);
      u.searchParams.set(inp.name, '__KSQ__');
      out.push(u.href.replace('__KSQ__', '{q}'));
    } catch (e) {}
  }
  // 11/25: 페이지에 적힌 검색 주소 견본(schema.org SearchAction — "…?keyword={search_term_string}")
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    const m = String(s.textContent || '').match(/https?:\\?\/\\?\/[^"'\s]*\{search_term_string\}[^"'\s]*/);
    if (m) { const u = m[0].replace(/\\\//g, '/').replace(/\\u0026/gi, '&').replace('{search_term_string}', '{q}').replace(/[?&]utm_[^&]*/g, ''); if (!out.includes(u)) out.unshift(u); }
  }
  const h = document.documentElement.outerHTML.slice(0, 600000).toLowerCase();
  const plat = /cafe24|ec-base|\/product\/search\.html/.test(h) ? '/product/search.html?keyword={q}' : /godomall|goods_search\.php/.test(h) ? '/goods/goods_search.php?keyword={q}'
    : /cdn\.shopify|shopify\./.test(h) ? '/search?q={q}&type=product' : /demandware|dwstatic/.test(h) ? '/search?q={q}' : /makeshop|shopbrand\.html/.test(h) ? '/shop/shopbrand.html?search=&prize1={q}' : '';
  if (plat) out.push(location.origin + plat);
  // 11/25: 이 가게 첫 화면 상품명에 많이 나오는 낱말(브랜드) — 나이키를 안 파는 곳은 이 낱말로 확인해요
  const cnt = {}, STOP = /^(new|best|sale|hot|men|women|kids|unisex|free|남성|여성|공용|남녀공용|키즈|무료|무료배송|배송|신상|신상품|할인|쿠폰|이벤트|로그인|회원|장바구니|브랜드|카테고리|전체|정품|국내|당일|단독|특가|품절|추천|관심상품|상품|상품명|좋아요|매장|리뷰|후기|상세|더보기|바로가기|구매|가격|판매가|소비자가|적립금|퀵메뉴|컬렉션|collection|shop|view|more|img|image|black|white|액세서리|홀리데이|신발|의류|가방|프로모션)$/i;
  // 상품 링크 안의 이름부터 봐요 — 메뉴의 영어 브랜드명(MACHINE …)은 검색이 안 되고 상품명은 한글(포터리 · 호카)인 가게가 있어요 (11/25 잼스토어)
  const PROD = /product_no=|\/product\/|\/products\/|goods_?no=|goodsno=|\/goods\/\d|\/goods\/view|prd_?no=|itemid=|\/item\/|\/p\/\d|\/detail/i;
  let names = [];
  for (const a of [...document.querySelectorAll('a[href]')].slice(0, 4000)) if (PROD.test(a.getAttribute('href') || '')) { names.push(a.textContent); for (const i of a.querySelectorAll('img[alt]')) names.push(i.alt); }
  if (names.filter(x => String(x || '').trim().length >= 8).length < 10) names = names.concat([...document.querySelectorAll('img[alt]')].map(i => i.alt), [...document.querySelectorAll('a')].slice(0, 3000).map(a => a.textContent));
  for (const n0 of names) {
    const n = String(n0 || '').replace(/\s+/g, ' ').trim(); if (n.length < 8 || n.length > 200) continue;
    const t = n.replace(/^(\[[^\]]*\]|\([^)]*\)|\d{2}(ss|fw|aw)|\d+%)\s*/gi, '').split(' ').find(x => x.length >= 2 && /[가-힣a-z]/i.test(x) && !/^\d/.test(x) && !/[{}]|[a-z]{2,}\.[a-z]{2,}/i.test(x) && !STOP.test(x));   // {{prd.goodsNm}} 같은 틀 글자는 빼요
    if (t) { const k = t.toLowerCase().replace(/[^\w가-힣.&'-]/g, '').replace(/_.*$/, ''); if (k.length >= 2 && !STOP.test(k) && !/^(uni|img\d*)$/.test(k)) cnt[k] = (cnt[k] || 0) + 1; }
  }
  // 두 번 넘게 나온 낱말부터 — 없으면 한 번 나온 것도 써요(상품마다 브랜드가 다른 가게 · 11/25 잼스토어)
  const words = Object.entries(cnt).sort((a, b) => b[1] - a[1]).slice(0, 2).map(x => x[0]);
  return { cands: out, origin: location.origin, words };
}

// 홈페이지 안에서 실행 — 검색칸에 낱말을 넣고 Enter (자바스크립트로 그리는 쇼핑몰은 폼이 없어서 이렇게 해야 주소가 보여요). 주문 · 로그인 칸은 안 건드려요
async function kcSupType(word) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const vis = el => { const r = el.getBoundingClientRect(), s = getComputedStyle(el); return r.width > 20 && r.height > 8 && s.visibility !== 'hidden' && s.display !== 'none' && +s.opacity !== 0; };
  const RX = /search|srch|keyword|query|검색|kwd|sword/i, BAD = /login|passw|mail|zip|post|addr|coupon|phone|member/i;
  const at = el => [el.name, el.id, typeof el.className === 'string' ? el.className : '', el.placeholder, el.getAttribute('aria-label'), el.getAttribute('title')].join(' ');
  const findInp = () => [...document.querySelectorAll('input')].filter(i => /^(search|text|)$/i.test(i.type || '') && (RX.test(at(i)) || i.type === 'search') && !BAD.test(at(i))).sort((a, b) => vis(b) - vis(a))[0];
  // 11/25: 닫힌 검색 창 속 칸(화면 밖 · 다른 것에 가려짐)은 못 쓰는 칸 — 온러닝은 돋보기를 눌러야 결과 창이 열려요
  const usable = el => { if (!vis(el)) return false; const r = el.getBoundingClientRect(), x = r.left + Math.min(r.width / 2, 40), y = r.top + r.height / 2; if (x < 0 || y < 0 || x > innerWidth || y > innerHeight) return false; const h = document.elementFromPoint(x, y); return !!h && (h === el || el.contains(h) || h.contains(el) || (h.closest && h.closest('label') === el.closest('label') && !!el.closest('label'))); };
  let inp = findInp();
  if (!inp || !usable(inp)) {   // 돋보기 단추를 눌러야 검색칸이 나오는 곳
    const btns = [...document.querySelectorAll('button, a, [role=button]')].filter(e => vis(e) && e.getBoundingClientRect().width < 160 && RX.test(at(e) + ' ' + String(e.textContent || '').trim().slice(0, 12)) && !BAD.test(at(e))).slice(0, 3);
    for (const b of btns) { try { b.click(); } catch (e) {} await sleep(900); const f = findInp(); if (f) inp = f; if (inp && usable(inp)) break; }
  }
  if (!inp) return { ok: false, why: '검색칸 없음' };
  const before = location.href;
  inp.focus();
  try { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, word); } catch (e) { inp.value = word; }
  inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true }));
  await sleep(400);
  for (const t of ['keydown', 'keypress', 'keyup']) inp.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
  await sleep(900);
  if (location.href === before && inp.form) { try { inp.form.requestSubmit ? inp.form.requestSubmit() : inp.form.submit(); } catch (e) {} }
  return { ok: true, name: inp.name || inp.id || '' };
}
// 결과 주소에서 낱말 자리를 {q} 로 — 'page=1' 같은 쪽 번호는 빼요(목록 쪽 넘김은 따로 붙여요)
//   도메인은 안 건드리고(korea.coach.com 의 coach 등) 경로 · 물음표 뒤에서 '=값' 또는 '/값' 꼴로 통째인 자리만 — 뒤쪽(검색어 칸)부터 찾아요
function seSupTpl(url, word) {
  if (!url || !word) return '';
  let u = String(url).replace(/([?&])(page|utm_[a-z]+)=[^&#]*(&|$)/gi, '$1').replace(/([?&])(page|utm_[a-z]+)=[^&#]*(&|$)/gi, '$1').replace(/[?&]$/, '');
  let o = 0; try { o = new URL(u).origin.length; } catch (e) { return ''; }
  const low = u.toLowerCase();
  for (const e of [encodeURIComponent(word), encodeURIComponent(word).replace(/%20/g, '+'), word]) {
    const el = e.toLowerCase();
    for (let j = low.lastIndexOf(el); j >= o; j = j > 0 ? low.lastIndexOf(el, j - 1) : -1) {
      const pre = u[j - 1], post = u[j + e.length];
      if (/[=\/]/.test(pre) && (post === undefined || /[&\/?#]/.test(post))) return u.slice(0, j) + '{q}' + u.slice(j + e.length);
    }
  }
  return '';
}
async function seSupTyped(mod, word) {
  try {
    await seGap(mod.k);
    const tabId = await srcNav(mod.home);
    for (let round = 0; round < 2; round++) {
      const before = (await chrome.tabs.get(tabId)).url;
      let hung = false;
      try { await execT({ target: { tabId }, func: kcSupType, args: [word] }, 8000); } catch (e) { hung = true; }   // 주소가 바뀌면 화면 쪽 실행이 끊겨요(답이 안 와요) — 8초만 기다려요
      let url = before; const end = Date.now() + 8000;
      while (Date.now() < end) { await sleep(400); const t = await chrome.tabs.get(tabId); url = t.url || ''; if (url !== before && t.status === 'complete') break; }
      const tpl = seSupTpl(url, word); if (tpl) return tpl;
      if (url === before) { if (hung) await srcKill(tabId); break; }   // 아무 일도 없었어요 (답도 없었으면 알림창 — 창을 닫아요)
      await sleep(1200);   // 검색 화면으로만 넘어간 곳 — 거기서 한 번 더
    }
  } catch (e) { console.warn('seSupTyped', mod.k, e); }
  return '';
}
// 확인용 낱말 — 일반 매입처는 브랜드 한 낱말(nike · 나이키), 공식몰은 브랜드 이름(stussy · 스투시).
// '나이키 신발'처럼 두 낱말로 찾으면 0건인 쇼핑몰이 많아요(카페24 · 고도몰은 상품명에 두 낱말이 다 있어야 나와요 — 11/25 실측 브릭맨션 0건 · '나이키' 675건)
function seSupWords(mod, kw) {
  const w = [];
  if (mod.brand) {
    const alts = String(mod.brand.source).replace(/[\^$()]/g, '').split('|').map(a => a.replace(/ \?/g, ' ').replace(/[\\?]/g, '')).filter(a => a.length >= 2);
    const en = alts.find(a => /^[a-z][a-z.' -]+$/i.test(a)), ko = alts.find(a => /[가-힣]/.test(a));
    if (en) w.push(en); if (ko) w.push(ko);
  } else {
    const b = String(kw || '').split(/\s+/)[0];
    w.push(/^[a-z]/i.test(b) ? b : 'nike'); if (b) w.push(b);
  }
  return [...new Set(w.filter(Boolean))].slice(0, 2);
}

// 매입처 하나의 검색 주소 찾기 → SE.supUrl[k] = { url, at, solo?, w? } | { fail, at }
//   solo: 두 낱말 검색은 0건이라 한 낱말로 찾아야 하는 곳(seQueries 가 따라요) · w: 공식몰에서 그때 쓸 낱말
async function seSupFind(mod, kw) {
  const C = SE.supUrl[mod.k];
  if (C && C.url) return C.url;
  // 11/26: 카테고리 목록(cat:)으로 읽는 곳은 검색 주소를 안 찾아요 — 주소는 SE_SUP 에 직접 넣어 둔 것
  if (String(mod.hint || '').startsWith('cat:')) { SE.supUrl[mod.k] = { url: mod.hint, at: Date.now() }; await store.set('srcSupUrl', SE.supUrl); return mod.hint; }
  if (C && C.fail && Date.now() - C.at < SE_SUP_RETRY) return null;
  kw = kw || '나이키 신발';
  // 공식몰은 '신발'부터 — 자기 브랜드 이름으로 찾으면 0건인 곳이 있어요 (11/25 라코스테: '라코스테' 0건 · '신발' 27건)
  const probe = mod.brand ? [...new Set([kw, ...seSupWords(mod, kw)])] : seSupWords(mod, kw), nBrand = probe.length;
  const read = async (tpl, w) => { await seGap(mod.k); return await SE_IO.list(mod, tpl.startsWith('type:') ? tpl + '#' + encodeURIComponent(w) : tpl.replace('{q}', encodeURIComponent(w))); };
  const good = (res, min) => !!(res && !res.noResult && res.cards && res.cards.length >= (min || 4));
  const dbg = x => { if (SE.supDbg) SE.supDbg.push({ k: mod.k, ...x }); };   // 시험용 기록 (평소엔 꺼져 있어요)
  const keys = res => new Set(((res && res.cards) || []).map(c => String(c.url || '').replace(/#.*$/, '').replace(/[?&](_\w*|utm_\w*)=[^&]*/g, '') || String(c.text || '').slice(0, 60)));
  // 찾은 상품 중 확인 낱말(브랜드 낱말은 영 · 한 이름 아무거나)이 들어 있는 비율
  const rel = (res, w) => {
    const al = (probe.indexOf(w) < nBrand ? probe.slice(0, nBrand) : [w]).map(a => a.toLowerCase()), cs = (res && res.cards) || [];
    return cs.filter(c => { const t = (c.text + ' ' + c.alt + ' ' + String(c.hrefs || '')).toLowerCase(); return al.some(a => t.includes(a)); }).length / (cs.length || 1);
  };
  const tryOne = async tpl => {
    let junk, sawNo = false;   // 주소마다 한 번만 읽어요
    for (const [i, w] of probe.entries()) {
      if (seStopped()) return null;
      const res = await read(tpl, w); dbg({ tpl, w, n: res && res.cards ? res.cards.length : -1, no: !!(res && res.noResult) });
      if (res && res.noResult) sawNo = true;
      if (!good(res, i < nBrand ? 4 : 3)) continue;
      // 아무 말(zqxjvkw)로 찾아도 같은 상품이 나오면 검색 결과가 아니라 첫 화면이에요 — 이 주소는 버려요 (11/25: on.com · 루이비통 첫 화면 등)
      // 다른 상품(추천)이 비슷한 수로 나오면, 찾은 상품에 확인 낱말이 거의 없을 때만 버려요 (11/25: 크기만 보고 버렸더니 레고 · 현대H몰 · 톰브라운까지 버려짐)
      // 직접 넣기(type:)는 첫 화면 상품이 같이 읽혀서 비교가 안 돼요 — 직접 확인해 넣은 주소라 그대로 믿어요
      if (tpl.startsWith('type:')) return { solo: w !== kw && !good(await read(tpl, kw)), w };
      if (junk === undefined) junk = await read(tpl, 'zqxjvkw').catch(() => null);   // 없는 말이면 알림창을 띄우는 가게도 있어요 — 못 읽으면 결과 없음으로 봐요
      if (good(junk)) {
        const a = keys(res), b = keys(junk); let same = 0; for (const x of b) if (a.has(x)) same++;
        const r = rel(res, w); dbg({ tpl, junk: b.size, n: a.size, same, rel: Math.round(r * 100) });
        // 같은 상품이면 이 낱말은 결과가 없어서 추천이 나온 것일 수도 있어요 — 다음 낱말로 (11/25 살로몬: '신발'은 추천 12개)
        // 70%: 검색이 넓게 걸리는 곳(살로몬은 아무 말도 77건 — 인기 상품이 일부 겹쳐요)은 살려요
        // 직접 확인해 넣은 주소(hint)는 화면이 통째로 같을 때만 버려요
        const hint = tpl === mod.hint;
        // 겹치는 것 말고 새 상품이 넉넉히 더 있으면 검색 결과예요 (11/25 킨: 늘 뜨는 인기 상품 10개 + 결과 9개)
        const extra = a.size - same;
        if (same >= Math.min(a.size, b.size) * (hint ? 0.95 : 0.7) && extra < Math.max(3, a.size * 0.25)) continue;
        if (!hint && !mod.brand && b.size >= a.size * 0.6 && r < 0.3) continue;
      }
      return { solo: w !== kw && !good(await read(tpl, kw)), w };
    }
    // 직접 확인해 넣은 주소가 '결과 없음' 화면을 제대로 보여 주면 검색은 되는 거예요 — 확인 낱말 상품을 안 파는 가게(잼스토어: 나이키 없음 · 상품명이 한글)
    if (tpl === mod.hint && sawNo) return { solo: true, w: '' };
    return null;
  };
  const cands = [];
  if (mod.hint) cands.push(mod.hint);
  let origin = '';
  try {
    await seGap(mod.k);
    const tabId = await srcNav(mod.home);
    const [r] = await execT({ target: { tabId }, func: kcSupSearch, args: [] }, 30000).catch(async e => { await srcKill(tabId); throw e; });
    const R = (r && r.result) || { cands: [] }; dbg({ cands: R.cands, words: R.words });
    for (const u of R.cands) if (!cands.includes(u)) cands.push(u);
    for (const w of R.words || []) if (!probe.includes(w)) probe.push(w);   // 나이키를 안 파는 가게 — 첫 화면에 많은 브랜드로도 확인
    origin = R.origin || '';
  } catch (e) { console.warn('seSupFind', mod.k, e); }
  if (!origin) try { origin = new URL(mod.home).origin; } catch (e) {}
  const save = async (tpl, ok) => { SE.supUrl[mod.k] = { url: tpl, at: Date.now(), ...(ok.solo ? { solo: true, w: mod.brand ? ok.w : '' } : {}) }; await store.set('srcSupUrl', SE.supUrl); return tpl; };
  const tried = new Set();
  const runList = async list => {
    for (const tpl of list) {
      if (seStopped() || tried.size >= 9) return null;
      if (!tpl || tried.has(tpl)) continue; tried.add(tpl);
      seSay(`${mod.label} · 검색 주소 찾는 중 (${tried.size})`);
      try { const ok = await tryOne(tpl); if (ok) return await save(tpl, ok); } catch (e) { dbg({ tpl, err: String(e && e.message || e).slice(0, 60) }); }
    }
    return null;
  };
  let got = await runList(cands.slice(0, 4)); if (got || seStopped()) return got;
  // 폼 · 견본으로 못 찾았으면 검색칸에 직접 넣어 봐요
  const typed = await seSupTyped(mod, probe[0]); dbg({ typed }); if (seStopped()) return null;
  got = await runList([typed, ...cands.slice(4)]); if (got || seStopped()) return got;
  got = await runList(SE_SUP_TRY.map(g => origin + g)); if (got || seStopped()) return got;
  SE.supUrl[mod.k] = { fail: true, at: Date.now() }; await store.set('srcSupUrl', SE.supUrl);
  return null;
}
