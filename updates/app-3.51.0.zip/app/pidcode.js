'use strict';
/* 3.42 품번 빈칸 메우기 (11/23 검수 4번)
   KREAM 입찰 · 보관판매 · 판매 내역에 모델번호가 '-'인 상품(가방 · 슬리퍼 등 크림에 모델번호가 없는 상품)은
   매입 기록과 못 맞춰서 '매입 기록 없음' · 'N개 모자람'이 잘못 떠요. KREAM 상품 번호(pid)로 품번을 찾아 채워요.
   찾는 순서: ① 내가 넣은 짝(PC) ② 재고관리 상품의 KREAM 상품 번호(kreamPid) ③ 관심 상품 ④ KREAM 상품 화면의 모델번호(읽기만 · 7일에 한 번)
   그래도 없으면 일반 판매 › 확인 필요에 '품번을 넣어 주세요' 줄로 보여요. */
let PC = {};   // pid → { code, by: 'me' | 'kream' | 'none', at }
const pcBad = c => !c || /^[-–—\s]*$/.test(String(c));
const pcPid = x => String((x && (x.pid || x.kreamPid || x.productId)) || '').trim();
function pcCode(pid) {
  pid = String(pid || ''); if (!pid) return '';
  const m = PC[pid]; if (m && m.code && !pcBad(m.code)) return m.code;
  try { const it = INV.items.find(i => String(i.kreamPid || '') === pid && !pcBad(i.code)); if (it) return String(it.code).split('/')[0].trim(); } catch (e) {}
  try { const p = (typeof products !== 'undefined' && Array.isArray(products) ? products : []).find(p => String(p.pid) === pid); const c = p && p.raw && p.raw.info && p.raw.info.code; if (!pcBad(c)) return String(c).split('/')[0].trim(); } catch (e) {}
  return '';
}
// 목록 하나 채우기 → 채운 개수
function pcFillList(L) {
  let n = 0;
  for (const x of L || []) { if (!x || !pcBad(x.code)) continue; const c = pcCode(pcPid(x)); if (c) { x.code = c; x.codeBy = 'pid'; n++; } }
  return n;
}
// 입찰(abList) · 보관판매(kInv) · 진행 중 판매 · 못 넣은 판매에 모두 적용
function pcApply() {
  let n = 0;
  try { if (typeof abList !== 'undefined') n += pcFillList(abList); } catch (e) {}
  try { if (typeof kInv !== 'undefined' && kInv) n += pcFillList(kInv.items); } catch (e) {}
  try { if (typeof kSales !== 'undefined' && kSales) { n += pcFillList(kSales.pending); n += pcFillList(Object.values(kSales.unrec || {})); } } catch (e) {}
  return n;
}
// 아직 품번이 없는 상품 (pid 마다 하나) → 확인 필요
function pcMissing() {
  const by = new Map(), add = (x, where) => { if (!x || !pcBad(x.code)) return; const pid = pcPid(x); const k = pid || 'n:' + (x.name || ''); const g = by.get(k) || { pid, name: x.name || '', where: new Set(), n: 0 }; g.where.add(where); g.n++; by.set(k, g); };
  try { if (typeof abList !== 'undefined') abList.filter(a => !a.gone).forEach(a => add(a, a.type === 'fast' ? '보관 판매 입찰' : '판매 입찰')); } catch (e) {}
  try { if (typeof kInv !== 'undefined' && kInv) (kInv.items || []).forEach(i => add(i, '보관 판매')); } catch (e) {}
  try { if (typeof kSales !== 'undefined' && kSales) { (kSales.pending || []).forEach(p => add(p, '진행 중 판매')); Object.values(kSales.unrec || {}).forEach(u => add(u, '못 넣은 판매')); } } catch (e) {}
  return [...by.values()].map(g => ({ ...g, where: [...g.where], tried: g.pid && PC[g.pid] ? PC[g.pid] : null }));
}
async function pcSave() { try { await store.set('kPidCode', PC); } catch (e) {} }
// 사용자가 직접 넣은 품번
async function pcSet(pid, code) {
  pid = String(pid || ''); code = String(code || '').trim().toUpperCase();
  if (!pid || pcBad(code)) return false;
  PC[pid] = { code, by: 'me', at: Date.now() }; await pcSave();
  pcApply(); try { await abSave(); } catch (e) {}
  return true;
}
// KREAM 상품 화면에서 모델번호 읽기 (크림 창이 비어 있을 때 · pid 마다 7일에 한 번 · 한 번에 5개까지)
let pcBusy = false;
async function pcResolve(max) {
  if (pcBusy || typeof srcNav !== 'function' || typeof execT !== 'function') return 0;
  if ((typeof XS !== 'undefined' && XS.busy) || (typeof OPS !== 'undefined' && OPS.halt)) return 0;
  const todo = pcMissing().filter(g => g.pid && !(PC[g.pid] && Date.now() - (PC[g.pid].at || 0) < 7 * 864e5)).slice(0, max || 5);
  if (!todo.length) return 0;
  pcBusy = true; let n = 0;
  try {
    for (const g of todo) {
      let code = '';
      try { const tabId = await srcNav('https://kream.co.kr/products/' + encodeURIComponent(g.pid)); const [x] = await execT({ target: { tabId }, func: kcKInfo, world: 'MAIN' }, 30000); code = String((x && x.result && x.result.code) || '').split('/')[0].trim(); } catch (e) {}
      PC[g.pid] = pcBad(code) ? { code: '', by: 'none', at: Date.now() } : { code: code.toUpperCase(), by: 'kream', at: Date.now() };
      if (!pcBad(code)) n++;
    }
  } finally { pcBusy = false; }
  await pcSave(); if (n) { pcApply(); try { await abSave(); } catch (e) {} }
  return n;
}
// 확인 필요 화면의 '품번 없는 상품' 칸
function pcCheckHTML() {
  const L = pcMissing(); if (!L.length) return '';
  const rows = L.map(g => `<tr><td class="l">${typeof itPic === 'function' ? itPic({ pid: g.pid, name: g.name }) : ''}${esc(String(g.name || '').slice(0, 40))}</td><td class="l mono">${g.pid ? `<a href="https://kream.co.kr/products/${esc(g.pid)}" target="_blank" rel="noopener">${esc(g.pid)}</a>` : '–'}</td><td class="l small">${esc(g.where.join(' · '))} ${g.n}건</td>
    <td class="l">${g.pid ? `<input class="mini" style="width:170px" placeholder="예: FV8911-010" data-k="pcCode" data-v="${esc(g.pid)}"> <button type="button" class="ghost tiny" data-a="pcSave" data-v="${esc(g.pid)}">넣기</button>` : '<span class="small">KREAM 상품 번호가 없어요</span>'}</td>
    <td class="l"><span class="pill warn">품번을 넣어 주세요</span> <span class="small">${g.tried && g.tried.by === 'none' ? 'KREAM 에도 모델번호가 없어요' : '재고에서 같은 KREAM 상품을 못 찾았어요'}</span></td></tr>`).join('');
  return `<div class="stk-bar"><b>품번 없는 상품</b> <span class="small">${L.length}개 — 품번이 없으면 매입 기록과 못 맞춰서 '매입 기록 없음' · 'N개 모자람'이 잘못 떠요. 재고관리 상품과 같은 품번을 넣어 주세요.</span></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">상품</th><th class="l">KREAM 상품 번호</th><th class="l">어디에</th><th class="l">품번</th><th class="l">사유</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
(function pcWire() {
  if (typeof document === 'undefined') return;
  const wrap = (name, after) => { try { const f = globalThis[name]; if (typeof f !== 'function') return; globalThis[name] = async function () { const r = await f.apply(this, arguments); try { after(); } catch (e) {} return r; }; } catch (e) {} };
  // 입찰 · 보관판매 · 판매 내역을 새로 읽으면 바로 채우고, 못 채운 건 크림 화면에서 찾아봐요
  const after = () => { if (pcApply()) { try { abSave(); } catch (e) {} } setTimeout(() => { pcResolve(5).catch(() => {}); }, 5000); };
  wrap('abLoadBids', after); wrap('kInvRead', after); wrap('kSalesSync', after);
  (async () => { try { PC = (await store.get('kPidCode', {})) || {}; } catch (e) {} setTimeout(() => { try { if (pcApply()) abSave(); } catch (e) {} }, 3500); })();
  document.addEventListener('click', async e => {
    const b = e.target.closest && e.target.closest('[data-a="pcSave"]'); if (!b) return;
    e.preventDefault(); e.stopPropagation();
    const inp = document.querySelector(`input[data-k="pcCode"][data-v="${CSS.escape(b.dataset.v)}"]`);
    if (await pcSet(b.dataset.v, inp && inp.value)) { try { renderInv(); } catch (er) {} } else if (inp) inp.focus();
  }, true);
})();
