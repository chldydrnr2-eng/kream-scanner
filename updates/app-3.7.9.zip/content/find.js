// 매입처 검색 결과 페이지에서 상품 카드 읽기 — chrome.scripting.executeScript로 주입 (이 함수 하나만 페이지에서 실행됨)
// 사이트마다 구조가 달라서 '사진 + 가격이 같이 들어 있는 가장 작은 덩어리'를 상품 카드로 봄.
function kcFind(opt) {
  const priceRe = /(\d{1,3}(?:,\d{3})+)\s*원?/g;
  const hasPrice = t => /\d{1,3}(?:,\d{3})+/.test(t);
  const bodyText = (document.body && document.body.innerText) || '';
  const noResult = /검색\s*결과가\s*없|결과가\s*없습니다|찾으시는\s*상품이\s*없|검색된\s*상품이\s*없|일치하는\s*상품이\s*없|총\s*0\s*(건|개)|0개의 상품/.test(bodyText);
  const seen = new Set(), bad = new Set(), cards = [];
  const PROD = /product|goods|item|catalog|\/p\/|\/t\/|\/pd\/|\.html|detail|prdtNo|itemId/i;
  // 여러 상품이 한 덩어리로 잡히면(가격이 사진 밖에 있는 사이트) 상품명과 가격이 섞이니까 버림
  const multi = el => {
    const ids = new Set([...el.querySelectorAll('a[href]')].filter(a => /^https?:/.test(a.href) && PROD.test(a.pathname + a.search) && !/search/i.test(a.pathname)).map(a => a.pathname + a.search.replace(/[?&](utm|ref|tr|src|area|click)[^&]*/g, '')));
    const imgs = [...el.querySelectorAll('img')].filter(i => i.getBoundingClientRect().width >= 60).length;
    return ids.size > 1 || imgs > 3;
  };
  const pick = el => {
    if (!el || seen.has(el)) return;
    if (bad.has(el)) return;
    if (multi(el)) { bad.add(el); return; }
    for (const s of seen) if (s.contains(el) || el.contains(s)) return;   // 겹치는 덩어리는 하나만
    seen.add(el);
    const raw = el.innerText || '';
    const text = raw.replace(/\s+/g, ' ').trim();
    // 카드 결제 예상가·적립금·보상금 같은 숫자는 판매가가 아니라서 빼고 계산
    const priceText = text.replace(/(예상가|결제\s*시|적립금?|보상|포인트|쿠폰\s*적용가?)[^\d]{0,12}\d{1,3}(?:,\d{3})+\s*원?/g, ' ');
    const nums = [...priceText.matchAll(priceRe)].map(m => +m[1].replace(/,/g, '')).filter(n => n >= 10000 && n < 20000000);
    const links = [...el.querySelectorAll('a[href]')].concat(el.closest('a[href]') ? [el.closest('a[href]')] : []).filter(x => /^https?:/.test(x.href));
    const a = links.find(x => /product|goods|item|catalog|\/p\/|\/t\/|\/pd\/|\.html|detail/i.test(x.pathname) && !/search/i.test(x.pathname));
    // 검색어가 붙은 주소(?keyword=)는 빼고 경로만 + 판매처 구분 값(siteNo 등)
    const hrefs = links.map(x => { let s = decodeURIComponent(x.pathname); for (const k of ['siteNo', 'mall_no', 'salestrNo']) { let v = ''; try { v = new URL(x.href).searchParams.get(k); } catch (e) {} if (v) s += ` ${k}=${v}`; } return s; }).join(' ').slice(0, 600);
    const img = el.querySelector('img');
    cards.push({ text: text.slice(0, 500), hrefs, url: a ? a.href.split('#')[0] : '', price: nums.length ? Math.min(...nums) : null,
      soldOut: /품절|sold\s?out|재고\s*없음|일시\s*품절/i.test(text), alt: img ? (img.alt || '').slice(0, 140) : '' });
  };
  for (const img of document.querySelectorAll('img')) {
    const r = img.getBoundingClientRect();
    if (r.width && r.width < 60) continue;   // 아이콘·로고 제외
    let e = img.parentElement;
    for (let i = 0; i < 9 && e && e !== document.body; i++) {
      const t = e.innerText || '';
      if (t.length > 900) break;
      if (hasPrice(t) && t.replace(/\s+/g, '').length > 8) { pick(e); break; }
      e = e.parentElement;
    }
    if (cards.length >= (opt && opt.max || 40)) break;
  }
  // 상품 상세로 바로 넘어간 경우(모델번호가 딱 맞으면 바로 상세로 가는 사이트가 있음)
  let page = null;
  const og = n => { const m = document.querySelector(`meta[property="${n}"]`); return m ? m.content : ''; };
  const h1 = document.querySelector('h1');
  const priceMeta = og('product:price:amount') || og('og:price:amount');
  const path = decodeURIComponent(location.pathname);
  page = { path, title: (og('og:title') || (h1 && h1.innerText) || document.title || '').slice(0, 160), price: priceMeta ? Math.round(+priceMeta) : null,
    text: ((h1 && h1.closest('section,main,div') || document.body).innerText || '').replace(/\s+/g, ' ').slice(0, 1500) };
  return { url: location.href, cards, noResult, page, ready: document.readyState };
}

// 크림 SHOP 목록(카테고리·인기순)에서 상품 카드 읽기 — 아래로 내리면서 max개까지
async function kcList(max) {
  const num = s => { const m = String(s || '').replace(/,/g, '').match(/([\d.]+)\s*(만|천)?/); return m ? Math.round(+m[1] * (m[2] === '만' ? 1e4 : m[2] === '천' ? 1e3 : 1)) : 0; };
  const read = () => {
    const out = new Map();
    for (const a of document.querySelectorAll('a[href*="/products/"]')) {
      const pid = (a.href.match(/products\/(\d+)/) || [])[1];
      if (!pid || out.has(pid)) continue;
      const t = (a.innerText || '').replace(/\s+/g, ' ').trim();
      if (!t || !/원/.test(t)) continue;
      const pr = (t.match(/([\d,]{4,})원/) || [])[1];
      const name = t.split(/\s[+-]?\d{1,3}%\s|\s[\d,]{4,}원/)[0].trim();
      const img = a.querySelector('img');
      out.set(pid, { pid, name: name.slice(0, 120), price: pr ? +pr.replace(/,/g, '') : null,
        trades: num((t.match(/거래\s*([\d.,]+\s*(만|천)?)/) || [])[1]), wish: num((t.match(/관심\s*([\d.,]+\s*(만|천)?)/) || [])[1]),
        fast: /빠른배송/.test(t), img: img ? img.currentSrc || img.src : '' });
    }
    return [...out.values()];
  };
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const none = () => /검색\s*결과가\s*없|결과가\s*없습니다|검색된\s*상품이\s*없/.test((document.body && document.body.innerText) || '');
  for (let i = 0; i < 20 && !read().length && !(i > 3 && none()); i++) await wait(500);
  let last = -1, same = 0;
  for (let i = 0; i < 40; i++) {
    const n = read().length;
    if (n >= max) break;
    if (n === last) { if (++same >= 4) break; } else same = 0;
    last = n;
    window.scrollTo(0, document.body.scrollHeight);
    await wait(900);
  }
  return read().slice(0, max);
}

// 무신사 주문 내역 읽기 — 아래로 내리면서 days일 전 주문까지
async function kcMusinsaOrders(days) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const cutoff = Date.now() - (days || 90) * 864e5;
  const toDate = s => { const m = String(s).match(/(\d{2})\.(\d{1,2})\.(\d{1,2})/); return m ? `20${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}` : ''; };
  const read = () => {
    const out = [];
    for (const a of document.querySelectorAll('a[href*="/order/order-detail/"]')) {
      const no = a.href.split('/').pop().split('?')[0];
      const title = a.closest('[class*="TitleSection"]');
      const g = title ? title.parentElement : a.parentElement;
      const lines = (g.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
      const date = toDate(lines.find(l => /^\d{2}\.\d{1,2}\.\d{1,2}/.test(l)) || '');
      const status = lines.find(l => /(준비|배송|완료|취소|반품|교환|확정|입금|결제)/.test(l) && !/주문 상세|요청|상세$/.test(l)) || '';
      const prods = [...new Set([...g.querySelectorAll('a[href*="/products/"]')].map(x => (x.href.match(/products\/(\d+)/) || [])[1]).filter(Boolean))];
      const items = [];
      lines.forEach((l, i) => {
        const m = l.match(/^(.*?)\s*\/\s*(\d+)개$/);
        if (!m) return;
        const price = +(lines.slice(i + 1, i + 3).find(x => /^[\d,]+원$/.test(x)) || '0').replace(/[^\d]/g, '');
        items.push({ brand: lines[i - 2] || '', name: lines[i - 1] || '', option: m[1], qty: +m[2], total: price, mid: prods[items.length] || prods[0] || '' });
      });
      out.push({ no, date, status, items });
    }
    return out;
  };
  let last = -1, same = 0;
  for (let i = 0; i < 60; i++) {
    const list = read();
    const oldest = list.length ? list[list.length - 1].date : '';
    if (oldest && new Date(oldest).getTime() < cutoff) break;
    if (list.length === last) { if (++same >= 4) break; } else same = 0;
    last = list.length;
    window.scrollTo(0, document.body.scrollHeight);
    await wait(1000);
  }
  return read().filter(o => !o.date || new Date(o.date).getTime() >= cutoff);
}

// 2.6.3: 무신사 상품번호 → 품번(styleNo). 주문 목록 상품명엔 품번이 없는 경우가 많아서 상품 정보를 따로 읽어요 (2026-11-12 확인)
async function kcMsStyles(ids) {
  const out = {};
  for (const id of ids || []) {
    try { const j = await (await fetch('https://goods-detail.musinsa.com/api2/goods/' + id, { credentials: 'include' })).json(); const d = (j && j.data) || {}; out[id] = String(d.styleNo || '').trim(); } catch (e) {}
  }
  return out;
}

// 무신사 랭킹 읽기 — 카테고리 탭을 누르고, 화면이 바뀌며 지워지는 목록을 내려가면서 모음
async function kcMusinsaRank(cat, max) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  if (cat) {
    const el = [...document.querySelectorAll('button')].find(x => (x.innerText || '').trim() === cat);
    if (el) { el.click(); await wait(2500); }
  }
  window.scrollTo(0, 0); await wait(800);
  const got = new Map();
  const grab = () => {
    for (const a of document.querySelectorAll('a[href*="/products/"]')) {
      const id = (a.href.match(/products\/(\d+)/) || [])[1];
      if (!id || got.has(id)) continue;
      let e = a; for (let k = 0; k < 6 && e && !/\d{1,3},\d{3}/.test(e.innerText || ''); k++) e = e.parentElement;
      const t = ((e || a).innerText || '').replace(/\s+/g, ' ').trim();
      const pr = (t.match(/([\d,]{4,})원/) || [])[1];
      if (!pr) continue;
      const img = (e || a).querySelector('img');
      got.set(id, { mid: id, text: t.slice(0, 200), price: +pr.replace(/,/g, ''), rank: +((t.match(/^(\d+)\s/) || [])[1] || 0), img: img ? img.currentSrc || img.src : '' });
    }
  };
  let stuck = 0, lastY = -1;
  for (let i = 0; i < 80 && got.size < max; i++) {
    grab();
    window.scrollBy(0, Math.round(innerHeight * 0.8)); await wait(700);
    if (scrollY === lastY) { if (++stuck >= 3) break; } else stuck = 0;
    lastY = scrollY;
  }
  grab();
  return [...got.values()].slice(0, max);
}

// ---------- 2.3: 포이즌 상품 페이지 사이즈별 가격 (kr.poizon.com/product/…) ----------
// 화면 글자에서 "사이즈: KR / 사이즈 가이드" 다음에 나오는 "사이즈 줄 → 가격 줄"을 읽어요. (2026-11 확인)
async function kcPoizon() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 20 && !/사이즈:\s*\S+\s*\n/.test(document.body.innerText); i++) await wait(400);
  const t = document.body.innerText;
  // 리뷰에도 '사이즈: KR 280' 같은 글이 있어서, 바로 다음 줄이 '사이즈 가이드'인 곳(구매 사이즈 고르는 칸)을 찾아요
  let i = t.search(/사이즈:\s*\S+\s*\n\s*사이즈 가이드/);
  if (i < 0) i = t.lastIndexOf('사이즈:');
  const sizes = [];
  if (i >= 0) {
    const lines = t.slice(i).split('\n').map(s => s.trim()).filter(Boolean).slice(0, 160);
    for (let k = 1; k < lines.length - 1; k++) {
      if (/^(발 길이|구매\s|관련 추천|정 사이즈)/.test(lines[k])) break;
      const pm = lines[k + 1].match(/^([\d,]+|--)\s*원$/);
      if (!pm || /원$/.test(lines[k]) || lines[k] === '사이즈 가이드' || lines[k].length > 24 || !/^[\dA-Z]/i.test(lines[k])) continue;
      sizes.push({ label: lines[k], kr: (lines[k].match(/^[\dA-Z.]+/i) || [lines[k]])[0], price: pm[1] === '--' ? null : +pm[1].replace(/,/g, '') });
      k++;
    }
  }
  const og = document.querySelector('meta[property="og:title"]');
  return { url: location.href, title: document.title, name: og ? og.content : '', sizes };
}
function kcPoizonLinks() {
  return [...document.querySelectorAll('a[href*="/product/"]')].map(a => ({ url: a.href.split('?')[0], text: (a.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 140) })).filter((x, i, arr) => x.text && arr.findIndex(y => y.url === x.url) === i).slice(0, 8);
}

// ---------- 2.3: 무신사 상품 사이즈별 재고·가격 (무신사 화면이 쓰는 주소, 2026-11 확인) ----------
async function kcMsStock(goodsNo) {
  const api = 'https://goods-detail.musinsa.com/api2/goods/' + goodsNo;
  const o = await (await fetch(api + '/options?goodsSaleType=SALE', { credentials: 'include' })).json();
  const d = o && o.data; if (!d) throw new Error('옵션을 못 읽었어요');
  const vals = (d.basic || []).flatMap(b => (b.optionValues || []).filter(v => !v.isDeleted).map(v => v.no));
  const inv = await (await fetch(api + '/options/v2/prioritized-inventories', { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ optionValueNos: vals }) })).json();
  const names = {}; for (const it of d.optionItems || []) if (!it.isDeleted) names[it.no] = { label: (it.optionValues || []).map(v => v.name).join(' / '), size: ((it.optionValues || []).slice(-1)[0] || {}).name || '', active: it.activated, extra: it.price || 0 };
  const sizes = ((inv && inv.data) || []).map(x => { const n = names[x.productVariantId] || {}; const dd = x.domesticDelivery || {}; return { id: x.productVariantId, label: n.label || String(x.productVariantId), size: n.size, out: !!x.outOfStock || n.active === false, qty: x.remainQuantity, extra: n.extra || 0, ship: dd.deliveryType || '', release: dd.willReleaseDate || '' }; });
  let meta = {};
  try { const nd = document.getElementById('__NEXT_DATA__'); const g = JSON.parse(nd.textContent).props.pageProps.meta.data; meta = { name: g.goodsNm, brand: g.brandInfo && (g.brandInfo.brandName || g.brandInfo.brand), price: g.goodsPrice, img: g.thumbnailImageUrl }; } catch (e) {}
  if (!meta.name) { const og = document.querySelector('meta[property="og:title"]'); meta.name = og ? og.content : document.title; }
  return { goodsNo: String(goodsNo), url: location.href, ...meta, sizes };
}
async function kcMsSearch(max) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 16 && !document.querySelector('a[href*="/products/"]'); i++) await wait(400);
  await wait(800);
  const out = new Map();
  for (const a of document.querySelectorAll('a[href*="/products/"]')) {
    const no = (a.href.match(/products\/(\d+)/) || [])[1]; if (!no) continue;
    const box = a.closest('li,article,[class*=item],[class*=Item]') || a.parentElement;
    const t = (box ? box.innerText : a.innerText || '').replace(/\s+/g, ' ').trim();
    const cur = out.get(no) || { no, text: '' };
    if (t.length > cur.text.length) cur.text = t.slice(0, 160);
    const img = (box || a).querySelector('img'); if (img && !cur.img) cur.img = img.currentSrc || img.src;
    out.set(no, cur);
  }
  return [...out.values()].filter(x => x.text).slice(0, max || 12).map(x => ({ ...x, price: +((x.text.match(/([\d,]{4,})원/) || [])[1] || '0').replace(/,/g, '') || null }));
}

// ---------- 2.3: 크림 마이페이지 탭 돌기 (판매/구매/보관 내역) ----------
// 데이터는 hook-my.js 가 페이지 응답을 받아 적어요. 여기서는 탭을 차례로 누르고 아래로 내려서 다 불러오게만 해요.
async function kcKreamWalk(labels) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  await wait(1500);
  const done = [];
  const scrollAll = async () => { let h = 0; for (let i = 0; i < 12; i++) { window.scrollTo(0, document.body.scrollHeight); await wait(700); if (document.body.scrollHeight === h) break; h = document.body.scrollHeight; } };
  await scrollAll();
  for (const lb of labels || []) {
    const el = [...document.querySelectorAll('a,button,li,[role=tab]')].find(e => e.children.length < 6 && (e.innerText || '').replace(/\s+/g, ' ').trim().startsWith(lb));
    if (!el) continue;
    el.click(); done.push(lb); await wait(1800); await scrollAll();
  }
  return { url: location.href, done, text: document.body.innerText.slice(0, 3000) };
}

// ---------- 2.3.1: 무신사 '작성 가능한 후기' (무신사 후기 화면이 쓰는 주소, 2026-11 확인) ----------
async function kcMsReviews(from, to) {
  const base = 'https://goods.musinsa.com/api2/review/v1/mypage';
  const cnt = await (await fetch(base + '/reviews/status-count', { credentials: 'include' })).json();
  const list = [];
  for (let page = 1; page <= 10; page++) {
    const j = await (await fetch(`${base}/orders?page=${page}&size=20&searchFromYmd=${from}&searchToYmd=${to}&timestamp=${Date.now()}`, { credentials: 'include' })).json();
    const d = (j && j.data) || {};
    list.push(...(d.list || []));
    if (!d.hasNextPage) break;
  }
  return { count: cnt && cnt.data, list, login: !/로그인 \/ 회원가입/.test(document.body.innerText) };
}

// ---------- 2.4: 구매처 주문 내역 읽기 (여러 쇼핑몰 공통) ----------
// 주문 내역 화면에서 '상품 사진 + 가격'이 같이 있는 가장 작은 덩어리를 상품 한 줄로 보고,
// 그 안이나 위쪽 묶음에서 주문일·상태·수량·옵션·주문번호를 찾아요. 사이트마다 화면이 달라서 결과는 미리보기에서 확인해요.
async function kcOrders(opt) {
  opt = opt || {};
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const DATE = /(20\d\d|(?<![\d,])\d\d)\s*[.\-\/년]\s*(\d{1,2})\s*[.\-\/월]\s*(\d{1,2})(?![\d,])/;   // 2026.11.11 · 26.11.11 · 2026년 11월 11일
  const PRICE = /([\d]{1,3}(?:,\d{3})+|\d{4,})\s*원/g;
  const STATUS = /(취소\s*(처리\s*)?중|결제\s*취소|반품\s*(처리\s*|진행\s*)?중|환불\s*(처리\s*)?중|주문\s*확인\s*중|주문\s*확인|결제\s*확인|발송\s*대기|주문\s*접수|주문\s*완료|결제\s*완료|입금\s*대기|입금\s*확인|상품\s*준비\s*중|배송\s*준비\s*중|발송\s*준비|출고\s*완료|배송\s*시작|배송\s*중|배송\s*완료|구매\s*확정|구매\s*결정|취소\s*완료|취소\s*요청|취소\s*접수|주문\s*취소|반품\s*완료|반품\s*요청|반품\s*접수|교환\s*완료|교환\s*요청|환불\s*완료)/;
  const EMPTY = /(주문|구매)\s*내역이\s*없|내역이\s*없습니다|주문하신\s*상품이\s*없/;
  const BTN = /^(장바구니|장바구니 담기|배송\s*조회|주문\s*상세|주문\s*상세보기|상세\s*보기|리뷰|후기|문의|재구매|다시 구매|구매확정|구매 확정|교환|반품|취소|주문\s*·\s*배송\s*취소|배송지 변경|영수증|선물|더보기|판매자 문의|문의하기)/;
  for (let i = 0; i < 24; i++) { const t = document.body.innerText; if (DATE.test(t) && PRICE.test(t) || EMPTY.test(t)) break; PRICE.lastIndex = 0; await wait(500); }
  PRICE.lastIndex = 0;
  for (let i = 0; i < (opt.scroll || 3); i++) { window.scrollTo(0, document.body.scrollHeight); await wait(900); }
  window.scrollTo(0, 0);
  const vis = el => { const r = el.getBoundingClientRect(); return r.width >= 36 && r.height >= 36; };
  const skipArea = el => el.closest('header,footer,nav,[class*=gnb],[class*=Gnb],[class*=footer],[class*=Footer],[class*=recommend],[class*=Recommend],[class*=banner],[class*=Banner]');
  const hasPrice = t => { PRICE.lastIndex = 0; return PRICE.test(t); };
  const used = [];
  const cards = [];
  for (const img of document.querySelectorAll('img')) {
    if (!vis(img) || skipArea(img)) continue;
    let el = img.parentElement;
    for (let d = 0; d < 9 && el && el !== document.body; d++, el = el.parentElement) {
      const t = el.innerText || '';
      if (t.length > 1600) { el = null; break; }
      if (hasPrice(t) && t.replace(/\s+/g, '').length > 8) break;
    }
    if (!el || el === document.body || used.some(u => u.contains(el) || el.contains(u))) continue;
    if ([...el.querySelectorAll('img')].filter(vis).length > 2) continue;   // 여러 상품이 한 덩어리면 건너뜀
    used.push(el); cards.push({ el, img });
  }
  const dateNodes = []; { const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { const m = n.nodeValue.match(DATE); if (m && !(n.parentElement && n.parentElement.closest('header,footer,select,option,input,[class*=calendar],[class*=Calendar],[class*=period],[class*=Period]'))) dateNodes.push({ n, t: m[0] }); } }
  const dEls = [...document.querySelectorAll('[data-kc-durl]')];
  const stNodes = []; { const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { const v = n.nodeValue.trim(); if (!v || v.length > 30) continue; const m = v.match(STATUS); if (!m || (n.parentElement && n.parentElement.closest('button,[role=button],header,footer,select,option'))) continue;
    // 배송 단계 표시(배송준비 · 배송중 · 배송완료가 나란히 있는 진행 막대)는 상태가 아니에요
    let bar = false; for (let i = 0, a = n.parentElement; i < 3 && a && a !== document.body; i++, a = a.parentElement) { const t = a.innerText || ''; const g = new RegExp(STATUS.source, 'g'); if (t.length < 50 && (t.match(g) || []).length >= 2 && t.replace(g, '').replace(/\s+/g, '').length <= 8) { bar = true; break; } }
    if (!bar) stNodes.push({ n, m }); } }
  const up = (el, re, n) => { for (let i = 0, a = el; i < (n || 6) && a && a !== document.body; i++, a = a.parentElement) { const m = (a.innerText || '').match(re); if (m) return { m, a }; } return null; };
  const rows = [];
  for (const { el, img } of cards) {
    const text = (el.innerText || '').trim();
    const lines = text.split('\n').map(s => s.trim()).filter(Boolean);
    // 날짜: 덩어리 안에 없으면 화면 순서상 이 상품 바로 앞에 나온 날짜(주문 묶음 머리)
    let date = '';
    const dm = text.match(DATE);
    if (dm) date = dm[0];
    else { let last = ''; for (const dn of dateNodes) { if (dn.n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) last = dn.t; else break; } date = last; }
    const d = date.match(DATE); const ymd = d ? `${d[1].length === 2 ? '20' + d[1] : d[1]}-${d[2].padStart(2, '0')}-${d[3].padStart(2, '0')}` : '';
    // 상태: '구매확정'처럼 버튼에 적힌 글자보다 화면에 적힌 상태를 먼저 봐요
    // 2.6.2: 쿠팡처럼 한 주문 안에 상태가 여러 개(배송중 · 취소완료 · 상품준비중…)인 곳은, 이 상품 바로 앞에 적힌 상태가 이 상품 것이에요.
    //        (같은 주문 묶음 날짜 뒤에 있는 것만, 버튼 글자는 빼고)
    const inSt = stNodes.find(x => el.contains(x.n));
    let near = null;
    if (!inSt) { const gd = dateNodes.filter(dn => (dn.n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) && !el.contains(dn.n)).pop();
      for (const x of stNodes) { if (!(x.n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) || el.contains(x.n)) break; if (!gd || (gd.n.compareDocumentPosition(x.n) & Node.DOCUMENT_POSITION_FOLLOWING)) near = x; } }
    let btnHit = null;
    const stOf = root => { const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { const m = n.nodeValue.match(STATUS); if (!m) continue; if (n.parentElement && n.parentElement.closest('button,[role=button]')) { btnHit = btnHit || m; continue; } return m; } return null; };
    let st = stOf(el); for (let i = 0, a2 = el.parentElement; !st && i < 4 && a2 && a2 !== document.body; i++, a2 = a2.parentElement) st = stOf(a2);
    if (!st) st = btnHit;
    if (inSt) st = inSt.m; else if (near) st = near.m;
    const ono = (text.match(/주문\s*번호\s*[:：]?\s*([0-9A-Z\-]{6,})/i) || ((up(el, /주문\s*번호\s*[:：]?\s*([0-9A-Z\-]{6,})/i, 6) || {}).m) || [])[1] || '';
    const paid = text.match(/(결제|판매|주문|구매|실결제)\s*금액[^\d]{0,12}([\d,]{4,})\s*원/);
    PRICE.lastIndex = 0; const prices = [...text.matchAll(PRICE)].map(m => +m[1].replace(/,/g, '')).filter(n => n >= 100);
    const price = paid ? +paid[2].replace(/,/g, '') : prices.length ? prices[prices.length - 1] : null;
    const qLine = lines.find(l => /^\d{1,3}\s*개$/.test(l));
    const qm = text.match(/수량\s*[:：]?\s*(\d{1,3})/) || (qLine && qLine.match(/(\d+)/)) || text.match(/(?:^|\s|\/)(\d{1,3})\s*개(?!입|월)(?!\S)/m);
    const nameCands = lines.filter(l => !DATE.test(l) && !STATUS.test(l) && !BTN.test(l) && !/^[\d,]+\s*원/.test(l) && !/^(수량|옵션|주문\s*번호|판매금액|결제금액|배송비|할인|쿠폰|정상가|판매가|도착|내일|오늘)/.test(l) && /[가-힣A-Za-z]/.test(l) && l.length >= 4);
    const alt = (img.alt || '').trim();
    let name = alt.length > 6 && !/^(상품|이미지|product|image|thumbnail|썸네일)/i.test(alt) ? alt : (nameCands.sort((a, b) => b.length - a.length)[0] || '');
    let optLine = lines.find(l => /^(옵션|사이즈|size|색상|컬러)\s*[:：]?/i.test(l) || / \/ |:\s*\S/.test(l) && l !== name && l.length < 80) || '';
    if (!optLine) { const nx = lines[lines.indexOf(name) + 1] || ''; if (nx && nx.length < 60 && !DATE.test(nx) && !STATUS.test(nx) && !BTN.test(nx) && !/^[\d,]+\s*원|^(수량|판매금액|결제금액|배송|도착|내일|오늘)/.test(nx)) optLine = nx; }
    const a = el.querySelector('a[href]') || el.closest('a[href]');
    // 주문상세 주소: 이 상품 안에 있거나, 같은 주문 묶음 머리(사이에 다른 날짜가 없는 바로 앞)에 있는 '주문상세'
    let det = el.querySelector('[data-kc-durl]');
    if (!det) { let last = null; for (const x of dEls) { if (x.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) last = x; else break; }
      if (last && !dateNodes.some(dn => (last.compareDocumentPosition(dn.n) & Node.DOCUMENT_POSITION_FOLLOWING) && (dn.n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) && !el.contains(dn.n))) det = last; }
    rows.push({ detail: det ? det.dataset.kcDurl : '', date: ymd, status: st ? st[0].replace(/\s+/g, '') : '', name: name.slice(0, 160), opt: optLine.replace(/^(옵션|사이즈|size)\s*[:：]?\s*/i, '').slice(0, 80), qty: qm ? +qm[1] : 1, price, orderNo: ono, url: a ? a.href : '', text: text.slice(0, 400) });
  }
  const body = document.body.innerText;
  return { url: location.href, title: document.title, rows, empty: EMPTY.test(body) && !rows.length, loginNeeded: /로그인|login/i.test(location.href) || (/아이디|비밀번호/.test(body) && /로그인/.test(body) && !rows.length) };
}

// ---------- 2.6.1: 주문 목록의 '주문상세' 주소 표시 (사이트 화면 쪽에서 실행: world MAIN) ----------
// 링크면 그 주소, 쿠팡처럼 주문번호가 화면 데이터에만 있으면 주소 틀(tpl)에 넣고, 지그재그처럼 누르면 새 창이 뜨는 곳은
// 새 창을 막고 열려던 주소만 받아 둬요. 표시는 data-kc-durl 속성으로 남겨서 kcOrders가 읽어요. (2026-11-11 지그재그·쿠팡·G마켓 확인)
async function kcTagDetails(tpl, scroll) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 20 && !/주문\s*상세|상세\s*보기/.test(document.body.innerText); i++) await wait(500);
  for (let i = 0; i < (scroll || 0); i++) { window.scrollTo(0, document.body.scrollHeight); await wait(900); }
  window.scrollTo(0, 0);
  const RE = /^(주문\s*상세(\s*보기)?|상세\s*보기)$/;
  const els = [...document.querySelectorAll('a,button,span,div,p,strong')].filter(e => e.childElementCount <= 2 && RE.test((e.innerText || '').trim()) && !e.closest('header,footer,nav'));
  const list = els.filter(e => !els.some(o => o !== e && e.contains(o)));
  const idOf = el => {
    for (let d = 0, a = el; d < 10 && a; d++, a = a.parentElement) {
      const k = Object.keys(a).find(k => k.startsWith('__reactFiber')); if (!k) continue;
      let f = a[k];
      for (let j = 0; j < 8 && f; j++, f = f.return) {
        const p = f.memoizedProps; if (!p || typeof p !== 'object') continue;
        for (const v of [p, p.order, p.data, p.item]) { if (!v || typeof v !== 'object') continue; const id = v.orderId ?? v.orderNo ?? v.orderNumber ?? v.order_number ?? v.ordNo; if (id != null && /^[\w-]{5,}$/.test(String(id))) return String(id); }
      }
    }
    return '';
  };
  const orig = window.open, caught = []; let n = 0, moved = false;
  window.open = u => { caught.push(String(u)); return null; };
  try {
    for (const el of list) {
      if (el.dataset.kcDurl) { n++; continue; }
      const a = el.closest('a[href]'); const h = a ? a.getAttribute('href') || '' : '';
      if (a && h && !/^(javascript:|#)/.test(h)) { el.dataset.kcDurl = a.href; n++; continue; }
      if (tpl) { const id = idOf(el); if (id) { el.dataset.kcDurl = tpl.replace('{id}', id); n++; } continue; }
      const before = location.href; caught.length = 0;
      el.click(); await wait(150);
      if (location.href !== before) { moved = true; break; }   // 같은 창에서 넘어가는 곳은 더 누르지 않아요
      if (caught[0]) { el.dataset.kcDurl = new URL(caught[0], location.href).href; n++; }
    }
  } finally { window.open = orig; }
  return { n, total: list.length, moved };
}

// ---------- 2.6.1: 주문상세 화면에서 실제 결제한 금액 읽기 ----------
// 우선순위: 즉시 할인가(무신사 카드 즉시할인) → 최종 결제금액 → 총 결제금액 → 실결제금액 → 결제 금액
// (2026-11-11 확인: 지그재그 '총 결제 금액', 쿠팡 '총 결제금액', G마켓 '총 결제금액', 무신사 '결제 금액'·'즉시 할인가')
async function kcOrderPaid() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 30 && !/결제\s*금액|결제금액/.test(document.body.innerText); i++) await wait(500);
  await wait(400);
  const lines = document.body.innerText.split('\n').map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const num = s => { const m = String(s).match(/^(-?)\s*(\d{1,3}(?:,\d{3})+|\d+)\s*원?$/); return m ? +m[2].replace(/,/g, '') * (m[1] ? -1 : 1) : null; };
  const after = re => {
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(re); if (!m) continue;
      const rest = lines[i].slice(m[0].length).trim();
      const cands = [rest, ...lines.slice(i + 1, i + 4)];
      for (let j = 0; j < cands.length; j++) {
        const c = cands[j]; if (!c) continue;
        if (/^\d{1,3}\s*%$/.test(c) || /^\d{1,3}\s*개$/.test(c)) continue;
        const v = num(c); if (v != null) return { v, label: m[0] };
        if (j > 0) break;
      }
    }
    return null;
  };
  const P = [/^즉시\s*할인가/, /^(총\s*)?최종\s*결제\s*금액/, /^총\s*결제\s*금액/, /^실\s*결제\s*금액/, /^결제\s*금액/];
  let paid = null; for (const re of P) { paid = after(re); if (paid && paid.v > 0) break; paid = null; }
  const goods = after(/^(총\s*)?상품\s*(금액|가격|합계)/);
  const ship = (lines.find(l => /^배송비/.test(l)) || '').includes('무료') ? { v: 0 } : after(/^배송비/);
  let points = 0;
  lines.forEach((l, i) => { if (/^(적립금|포인트|마일리지|쿠팡캐시|스마일캐시|캐시|예치금|머니)\s*(사용)?$/.test(l)) { const v = num(lines[i + 1] || ''); if (v && v < 0) points += -v; } });
  const ono = (document.body.innerText.match(/주문\s*번호\s*[:：]?\s*([0-9A-Z-]{6,})/i) || [])[1] || '';
  const body = document.body.innerText;
  return { url: location.href, paid: paid ? paid.v : 0, label: paid ? paid.label : '', goods: goods ? goods.v : 0, ship: ship ? ship.v : 0, points, orderNo: ono, loginNeeded: /login|로그인/i.test(location.pathname) || (/아이디|비밀번호/.test(body) && /로그인/.test(body) && !paid) };
}

// ---------- 2.5.1: ABC마트·그랜드스테이지 상품 화면에서 스타일코드 읽기 ("스타일코드 : HV8150 색상코드 : 003" → HV8150-003) ----------
async function kcArtCode() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 16 && !/스타일\s*코드/.test(document.body.innerText); i++) await wait(400);
  const t = document.body.innerText;
  const st = (t.match(/스타일\s*코드\s*[:：]?\s*([A-Z0-9][A-Z0-9-]{2,})/i) || [])[1] || '';
  const co = (t.match(/색상\s*코드\s*[:：]?\s*([A-Z0-9]{2,4})\b/i) || [])[1] || '';
  return { style: st, color: co, code: st && /^\d{3}$/.test(co) && !st.includes('-') ? `${st}-${co}` : st };
}

// ---------- 2.6: 크림 보관 신청 (보관 상품 선택 → 사이즈 수량 → 신청 계속) — 2026-11-11 화면 확인 ----------
// 보관 상품 선택 화면(/search/stock)에서 모델번호로 검색해서 그 상품을 눌러요. 상품 번호는 바뀐 주소(/inventory/번호)에서 읽어요.
async function kcStockFind(codes) {
  // 3.7.5: 모델번호가 여러 개('A/B/C')면 하나씩 검색하고, 하이픈·띄어쓰기 차이는 무시해요. 못 찾으면 검색 결과 후보를 알려줘요.
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const key = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
  const list = [...new Set([].concat(codes || []).flatMap(c => String(c).split('/')).map(c => c.trim()).filter(c => key(c).length >= 4))];
  const want = new Set(list.map(key));
  let inp = null; for (let i = 0; i < 20 && !(inp = document.querySelector('input[placeholder*="모델번호"],input[type=search]')); i++) await wait(300);
  if (!inp) return { error: '검색칸을 못 찾았어요' };
  const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  const cands = [];
  const tokens = a => a.innerText.split(/[\n/,]+/).map(x => key(x)).filter(Boolean);
  for (const code of list) {
    inp.focus(); set.call(inp, code); inp.dispatchEvent(new Event('input', { bubbles: true }));
    await wait(250);
    inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    inp.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    let a = null;
    for (let i = 0; i < 16; i++) { await wait(400); a = [...document.querySelectorAll('a.item_link')].find(x => tokens(x).some(t => want.has(t))); if (a) break; }
    if (a) { const name = a.innerText.split('\n').map(s => s.trim()).filter(Boolean).slice(1, 3).join(' / '); setTimeout(() => a.click(), 50); return { found: true, name, by: code }; }
    for (const x of [...document.querySelectorAll('a.item_link')].slice(0, 3)) { const t = x.innerText.split('\n').map(s => s.trim()).filter(Boolean).slice(0, 3).join(' · ').slice(0, 60); if (t && !cands.includes(t)) cands.push(t); }
  }
  return { found: false, tried: list, cands: cands.slice(0, 3) };
}
function kcStockSizes() {
  return [...document.querySelectorAll('.inventory_size_item .size')].map(e => e.innerText.trim());
}
// MAIN world 에서 실행. 크림 보관 신청 2단계 (2026-11-11 화면 확인):
//  1) 사이즈별 + 버튼으로 수량 → '신청 계속'  2) 같은 주소에서 '신청 내역' 요약(신청 상품·모델번호, "270 X 1개", 신청 수량 N건, 총 결제금액)
//  3) '보증금 결제하기' (등록된 카드로 자동 결제). 요약이 기대값과 한 글자라도 다르면 누르지 않아요.
async function kcStockApply(size, qty, codes, final) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const key = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
  const norm = s => String(s || '').toUpperCase().replace(/\s+/g, '');
  window.__kcMsgs = [];
  window.alert = m => { window.__kcMsgs.push(String(m)); };
  window.confirm = m => { window.__kcMsgs.push('[확인창] ' + String(m)); return false; };   // 모르는 확인창은 '취소'
  const said = () => { const pop = [...document.querySelectorAll('[class*=toast],[class*=modal],[class*=layer],[class*=popup],[class*=alert],[class*=snackbar],[role=dialog],[role=alert]')].filter(e => e.offsetParent && (e.innerText || '').trim()).map(e => e.innerText.trim().replace(/\s+/g, ' ').slice(0, 160)); return [...window.__kcMsgs, ...pop].filter((x, i, a) => a.indexOf(x) === i).slice(0, 4); };
  for (let i = 0; i < 25 && !document.querySelector('.inventory_size_item'); i++) await wait(300);
  const items = [...document.querySelectorAll('.inventory_size_item')];
  if (!items.length) return { error: '사이즈 고르는 화면이 아니에요', said: said() };
  // 0. 화면 위쪽 상품 모델번호가 맞는지
  const head = document.body.innerText.slice(0, 1500);
  if (!codes.some(c => key(head).includes(key(c)))) return { mismatch: `화면의 상품 모델번호가 ${codes.join('/')} 와 달라요` };
  const row = items.find(r => norm((r.querySelector('.size') || {}).innerText) === norm(size));
  if (!row) return { error: `사이즈 ${size} 칸이 없어요`, sizes: items.map(r => (r.querySelector('.size') || {}).innerText.trim()) };
  const btn = (r, k) => [...r.querySelectorAll('button')].find(b => b.querySelector('.ico-count-' + k));
  for (const r of items) { if (r === row) continue; const inp = r.querySelector('input'); for (let k = 0; k < 40 && inp && +inp.value > 0; k++) { btn(r, 'minus').click(); await wait(80); } }
  const inp = row.querySelector('input');
  for (let k = 0; k < 40 && +inp.value > qty; k++) { btn(row, 'minus').click(); await wait(80); }
  for (let k = 0; k < 40 && +inp.value < qty; k++) { btn(row, 'plus').click(); await wait(150); }
  await wait(300);
  const others = items.filter(r => r !== row && +(r.querySelector('input') || {}).value > 0).length;
  if (+inp.value !== qty || others) return { mismatch: `수량을 정확히 맞추지 못했어요 (${size}: ${inp.value}개, 다른 사이즈 ${others}칸)` };
  const go = [...document.querySelectorAll('a,button')].find(b => /신청\s*계속/.test(b.innerText));
  if (!go) return { error: "'신청 계속' 버튼이 없어요" };
  if (go.disabled || go.classList.contains('disabled')) return { blocked: true, said: ["'신청 계속'이 눌리지 않는 상태"].concat(said()) };
  go.click();
  // 1단계 결과: 요약 화면(보증금 결제하기) 또는 막힘 안내
  let pay = null;
  for (let i = 0; i < 25; i++) { await wait(300); pay = [...document.querySelectorAll('a,button')].find(b => /보증금\s*결제하기/.test(b.innerText)); if (pay || window.__kcMsgs.length) break; }
  if (!pay) return { blocked: true, step: 1, said: said() };
  // 2단계 확인: 요약 내용이 기대값과 똑같은지 (모델번호·사이즈·수량·신청 건수·결제금액)
  const t = document.body.innerText;
  const a = t.indexOf('신청 상품'), b = t.indexOf('반송');
  const box = a >= 0 ? t.slice(a, b > a ? b : a + 400) : '';
  const lines = [...box.matchAll(/(?:^|\n)[ \t]*([^\n]*?\S)\s*X\s*(\d+)\s*개/g)].map(m => ({ s: m[1], q: +m[2] }));   // 3.7.5: 'US 7'처럼 띄어쓴 사이즈도
  const cnt = +((t.match(/신청\s*수량\s*(\d+)\s*건/) || [])[1] || 0);
  const total = +(((t.match(/총\s*결제\s*금액\s*([\d,]+)\s*원/) || [])[1] || '0').replace(/,/g, ''));
  const dep = +(((t.match(/보증금\s*\n?\s*([\d,]+)\s*원/) || [])[1] || '3000').replace(/,/g, ''));
  const problems = [];
  if (!codes.some(c => key(box).includes(key(c)))) problems.push('요약의 모델번호가 달라요');
  if (lines.length !== 1) problems.push(`요약에 사이즈 줄이 ${lines.length}개예요`);
  else { const ls = norm(lines[0].s), ns = norm(size); if (!(ls === ns || (ls.endsWith(ns) && !/[0-9A-Z.]$/.test(ls.slice(0, -ns.length))))) problems.push(`요약 사이즈가 ${lines[0].s}예요`); if (lines[0].q !== qty) problems.push(`요약 수량이 ${lines[0].q}개예요`); }
  if (!new RegExp('총\\s*' + qty + '\\s*개').test(box)) problems.push('요약의 총 개수가 달라요');
  if (cnt !== qty) problems.push(`신청 수량이 ${cnt}건이에요`);
  if (!total || total !== dep * qty) problems.push(`총 결제금액이 ${total.toLocaleString()}원이에요 (예상 ${(dep * qty).toLocaleString()}원)`);
  if (problems.length) return { mismatch: problems.join(' · ') };
  if (!final) return { ready: true, total };
  const before = location.href, beforeText = t.length;
  pay.click();
  for (let i = 0; i < 40; i++) { await wait(300); if (location.href !== before || window.__kcMsgs.length || !document.body.contains(pay) || /신청이?\s*완료|완료되었습니다|신청되었습니다/.test(document.body.innerText)) break; }
  await wait(1200);
  const after = document.body.innerText;
  const done = /신청이?\s*완료|완료되었습니다|신청되었습니다|보관\s*신청\s*완료/.test(after) || /\/my\/inventory|complete|success|result/.test(location.href);
  return { submitted: true, done, total, url: location.href.split('?')[0], said: said(), changed: location.href !== before || after.length !== beforeText };
}

// ---------- 3.4: 판매입찰 가격 바꾸기 (MAIN world) ----------
// 크림 판매 흐름(2026-11 크림 웹 코드 확인): 판매 입찰은 ask-requests 화면 단계(가격 입력 → 확인)로 진행되고, 입찰 변경은 같은 흐름에 ask_id 를 붙여 열려요.
// 실제 변경 화면은 아직 못 봐서, 글자로 버튼을 찾고 마지막 버튼 전에 화면의 가격·사이즈가 넣은 값과 같은지 반드시 확인해요.
// o = { target, from, size, code, final, list }
async function kcAskChange(o) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const txt = e => (e.innerText || e.value || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
  const norm = s => String(s || '').toUpperCase().replace(/\s+/g, '');
  const fmt = n => Number(n).toLocaleString('ko-KR');
  const digits = s => +(String(s || '').replace(/[^\d]/g, '') || 0);
  window.__kcMsgs = [];
  window.alert = m => { window.__kcMsgs.push(String(m)); };
  window.confirm = m => { window.__kcMsgs.push('[확인창] ' + String(m)); return false; };
  const said = () => { const pop = [...document.querySelectorAll('[class*=toast],[class*=modal],[class*=layer],[class*=popup],[class*=alert],[class*=snackbar],[role=dialog],[role=alert]')].filter(e => e.offsetParent && (e.innerText || '').trim()).map(e => e.innerText.trim().replace(/\s+/g, ' ').slice(0, 160)); return [...window.__kcMsgs, ...pop].filter((x, i, a) => a.indexOf(x) === i).slice(0, 4); };
  const clickables = () => [...document.querySelectorAll('a,button,[role=button]')].filter(vis);
  const find = (re, not) => clickables().find(e => { const t = txt(e); return t.length < 30 && re.test(t) && !(not && not.test(t)); });
  const NOT = /주소|배송지|카드|계좌|결제\s*수단|프로필|비밀번호|알림|쿠폰/;
  const CHG = /입찰\s*(가격\s*)?(변경|수정)|판매\s*희망가\s*(변경|수정)|가격\s*(변경|수정)|^변경(하기)?$|^수정(하기)?$/;
  for (let i = 0; i < 20 && (!document.body || document.body.innerText.length < 200); i++) await wait(400);
  await wait(800);
  // 0. 목록에서 들어온 경우: 사이즈와 지금 입찰가가 같이 보이는 가장 작은 줄을 눌러요
  if (o.list) {
    const cands = [...document.querySelectorAll('a,li,[role=button],div')].filter(e => vis(e) && e.innerText && e.innerText.length < 400)
      .filter(e => { const t = e.innerText; return t.includes(fmt(o.from)) && norm(t).includes(norm(o.size)); });
    const row = cands.sort((a, b) => a.innerText.length - b.innerText.length)[0];
    if (!row) return { error: 'nochg', why: '목록에서 그 입찰(사이즈·가격)을 못 찾았어요', url: location.href };
    (row.closest('a') || row).click();
    for (let i = 0; i < 20 && !find(CHG, NOT); i++) await wait(400);
  }
  // 1. 입찰 변경 버튼
  let chg = null;
  for (let i = 0; i < 15 && !(chg = find(CHG, NOT)); i++) await wait(400);
  if (!chg) return { error: 'nochg', url: location.href, said: said() };
  // 상세 화면이면 사이즈·지금 가격이 맞는지 먼저 확인
  const pageT = document.body.innerText;
  if (!norm(pageT).includes(norm(o.size))) return { mismatch: `화면에 사이즈 ${o.size}가 안 보여요` };
  chg.click();
  // 2. 가격 칸
  let inp = null;
  for (let i = 0; i < 25 && !inp; i++) {
    await wait(400);
    const all = [...document.querySelectorAll('input')].filter(e => vis(e) && !e.readOnly && !e.disabled && /^(text|number|tel|)$/i.test(e.getAttribute('type') || 'text'));
    inp = all.find(e => /희망가|판매가|입찰가|가격|price/i.test((e.placeholder || '') + ' ' + (e.name || '') + ' ' + (e.getAttribute('aria-label') || '') + ' ' + ((e.closest('div,label,section') || {}).innerText || '').slice(0, 80))) || (all.length === 1 ? all[0] : null);
  }
  if (!inp) return { error: '가격 넣는 칸을 못 찾았어요', url: location.href, said: said() };
  const setV = v => { inp.focus(); const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); d.set.call(inp, ''); inp.dispatchEvent(new Event('input', { bubbles: true })); d.set.call(inp, String(v)); inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); inp.dispatchEvent(new Event('blur', { bubbles: true })); };
  setV(o.target); await wait(700);
  if (digits(inp.value) !== o.target) { setV(fmt(o.target)); await wait(700); }
  if (digits(inp.value) !== o.target) return { mismatch: `가격 칸에 ${inp.value}가 들어갔어요 (넣으려던 값 ${fmt(o.target)})` };
  // 3. 계속 → 확인 화면
  const NEXT = /^(판매\s*입찰\s*계속|입찰\s*계속|변경\s*계속|계속|다음|다음\s*단계)$/;
  const FINAL = /^(판매\s*입찰(하기)?|입찰\s*변경(하기)?|변경(하기|완료)|가격\s*변경(하기)?|확인)$/;
  const nx = find(NEXT);
  if (nx) {
    if (nx.disabled || nx.classList.contains('disabled')) return { blocked: true, said: ["'계속'이 눌리지 않는 상태"].concat(said()) };
    nx.click();
  }
  let fin = null;
  for (let i = 0; i < 25; i++) { await wait(400); fin = find(FINAL, NOT); if ((fin && fin !== nx) || window.__kcMsgs.length) break; }
  if (!fin) return { blocked: true, step: 'review', said: said(), url: location.href };
  // 4. 확인 화면 검사: 새 가격과 사이즈가 보여야 하고, 모델번호를 알면 그것도
  const t = document.body.innerText;
  const problems = [];
  if (!t.includes(fmt(o.target))) problems.push(`확인 화면에 ${fmt(o.target)}원이 안 보여요`);
  if (!norm(t).includes(norm(o.size))) problems.push(`확인 화면에 사이즈 ${o.size}가 안 보여요`);
  const code = String(o.code || '').split('/').map(c => c.trim()).find(c => /\d/.test(c));
  if (code && !norm(t).includes(norm(code))) problems.push(`확인 화면에 모델번호 ${code}가 안 보여요`);
  if (problems.length) return { mismatch: problems.join(' · ') };
  if (!o.final) return { ready: true };
  // 필수 동의 체크 (판매 입찰 확인 화면의 안내 동의)
  for (const c of [...document.querySelectorAll('input[type=checkbox]')].filter(c => !c.checked && !c.disabled)) { const lb = c.closest('label') || c.parentElement; (vis(c) ? c : lb).click(); await wait(120); }
  await wait(400);
  if (fin.disabled || fin.classList.contains('disabled')) return { blocked: true, step: 'final', said: ['마지막 버튼이 눌리지 않는 상태 (동의 체크 확인 필요)'].concat(said()) };
  const before = location.href;
  fin.click();
  for (let i = 0; i < 40; i++) { await wait(300); if (location.href !== before || window.__kcMsgs.length || !document.body.contains(fin) || /완료|변경되었습니다|입찰되었습니다|등록되었습니다/.test(document.body.innerText)) break; }
  await wait(1200);
  const after = document.body.innerText;
  const done = /입찰\s*(이\s*)?(완료|변경)|변경\s*(이\s*)?완료|변경되었습니다|입찰되었습니다|등록되었습니다|판매\s*입찰\s*완료/.test(after);
  return { submitted: true, done, url: location.href.split('?')[0], said: said() };
}

// ---------- 2.7: 로그인 상태 · 자동 로그인 (계정 연결) ----------
// 화면이 로그인 화면인지 봐요: 주소에 login/signin, 보이는 비밀번호 칸, '로그인이 필요' 문구. '로그아웃'이 보이면 로그인된 상태.
async function kcLoginState() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 16 && (!document.body || document.body.innerText.length < 150) && !(i >= 3 && document.readyState === 'complete'); i++) await wait(400);
  await wait(300);
  const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const t = document.body ? document.body.innerText : '';
  const pw = [...document.querySelectorAll('input[type=password]')].filter(vis).length;
  const loginUrl = /(log-?in|sign-?in|\/auth\/|member\/login|memberlogin|account\/login)/i.test(location.href);
  const logout = /로그아웃|log\s*out|sign\s*out/i.test(t);
  const askLogin = /로그인\s*(이\s*)?필요|로그인\s*후\s*이용|로그인\s*해\s*주세요|로그인하세요/.test(t);
  const captcha = /자동\s*입력\s*방지|보안\s*문자|captcha|로봇이\s*아닙니다|인증\s*번호|본인\s*인증|휴대폰\s*인증|2단계\s*인증|새로운\s*기기/i.test(t) || !!document.querySelector('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],[class*=captcha i]');
  return { url: location.href, needLogin: pw > 0 || (loginUrl && !logout) || (askLogin && !logout), pw, captcha };
}
// 로그인 화면에서 아이디·비밀번호를 넣고 로그인 버튼을 눌러요 (사이트 화면 쪽에서 실행: world MAIN)
// 보안문자·인증이 보이면 넣지 않고 멈춰요. 아이디 로그인 칸이 숨어 있으면('이메일로 로그인' 등) 한 번 눌러서 열어 봐요.
async function kcLoginFill(id, pw) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const txt = e => (e.innerText || e.value || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
  const OPEN = /^(이메일|아이디|ID|일반\s*회원|통합\s*회원|이메일\s*로그인|아이디\s*로그인|이메일로\s*(로그인|시작|계속)|아이디로\s*로그인|다른\s*방법으로\s*로그인|이메일\/아이디)/i;
  let pwEl = null, opened = 0;
  for (let i = 0; i < 24; i++) {
    pwEl = [...document.querySelectorAll('input[type=password]')].find(vis);
    if (pwEl) break;
    if ((i === 4 || i === 10) && opened < 2) { const b = [...document.querySelectorAll('a,button,[role=button],label')].find(e => vis(e) && OPEN.test(txt(e))); if (b) { b.click(); opened++; } }
    await wait(500);
  }
  const body = document.body ? document.body.innerText : '';
  if (!pwEl) return { ok: false, why: /로그아웃/.test(body) && !/(log-?in|sign-?in)/i.test(location.href) ? 'already' : 'nopw' };
  if (/자동\s*입력\s*방지|보안\s*문자|captcha|로봇이\s*아닙니다/i.test(body) || document.querySelector('iframe[src*="recaptcha"],iframe[src*="hcaptcha"]')) return { ok: false, why: 'captcha' };
  const scope = pwEl.form || pwEl.closest('[class*=login i],[class*=Login],[id*=login i],section,main') || document.body;
  const cands = [...scope.querySelectorAll('input')].filter(e => vis(e) && /^(text|email|tel|)$/i.test(e.getAttribute('type') || 'text') && !e.readOnly);
  let idEl = cands.filter(e => e.compareDocumentPosition(pwEl) & Node.DOCUMENT_POSITION_FOLLOWING).pop() || cands[0];
  if (!idEl) idEl = [...document.querySelectorAll('input')].filter(e => vis(e) && /^(text|email|tel|)$/i.test(e.getAttribute('type') || 'text')).filter(e => e.compareDocumentPosition(pwEl) & Node.DOCUMENT_POSITION_FOLLOWING).pop();
  if (!idEl) return { ok: false, why: 'nopw' };
  const setV = (el, v) => { el.focus(); const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); d.set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); el.dispatchEvent(new Event('blur', { bubbles: true })); };
  setV(idEl, id); await wait(150); setV(pwEl, pw); await wait(400);
  // 3.4.2: '로그인 상태 유지 · 자동 로그인' 체크가 있으면 켜요 (껐다 켜도 로그인이 안 풀리게)
  try {
    const KEEP = /(로그인\s*(상태\s*)?유지|자동\s*로그인|로그인\s*기억|keep\s*(me\s*)?(logged|signed)|remember\s*me|stay\s*signed)/i;
    for (const cb of document.querySelectorAll('input[type=checkbox]')) {
      if (cb.checked) continue;
      const lab = (cb.labels && cb.labels[0]) || cb.closest('label') || cb.parentElement;
      const t = ((lab && lab.innerText) || '') + ' ' + (cb.getAttribute('aria-label') || '') + ' ' + (cb.id || '') + ' ' + (cb.name || '');
      if (!KEEP.test(t) && !/(keep|auto_?login|autologin|remember|persist)/i.test((cb.id || '') + (cb.name || ''))) continue;
      const lv = lab && vis(lab) ? lab : null;
      if (vis(cb)) cb.click(); else if (lv) lv.click(); else { cb.checked = true; cb.dispatchEvent(new Event('change', { bubbles: true })); }
      await wait(150);
      if (!cb.checked) { cb.checked = true; cb.dispatchEvent(new Event('input', { bubbles: true })); cb.dispatchEvent(new Event('change', { bubbles: true })); }
    }
  } catch (e) {}
  const btns = [...scope.querySelectorAll('button,input[type=submit],a,[role=button]')].filter(vis);
  const btn = btns.find(e => /^(로그인|로그인하기|LOGIN|Log in|Sign in|확인)$/i.test(txt(e))) || btns.find(e => (e.getAttribute('type') || '').toLowerCase() === 'submit');
  if (btn) btn.click();
  else if (pwEl.form) { if (pwEl.form.requestSubmit) pwEl.form.requestSubmit(); else pwEl.form.submit(); }
  else { pwEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true })); }
  return { ok: true, clicked: btn ? txt(btn).slice(0, 20) : 'enter' };
}

// ---------- 3.3: 아무 화면의 표 읽기 (크림 판매자 센터처럼 아직 구조를 모르는 화면용) ----------
function kcTableRead() {
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const T = s => (s || '').replace(/\s+/g, ' ').trim();
  let best = null;
  for (const t of document.querySelectorAll('table')) { if (!vis(t)) continue; const n = t.querySelectorAll('tbody tr').length || t.querySelectorAll('tr').length - 1; if (!best || n > best.n) best = { t, n }; }
  if (best && best.n > 0) {
    const head = [...best.t.querySelectorAll('thead th, thead td')].map(x => T(x.innerText));
    const trs = [...best.t.querySelectorAll('tbody tr')].length ? [...best.t.querySelectorAll('tbody tr')] : [...best.t.querySelectorAll('tr')].slice(1);
    return { url: location.href, title: document.title, kind: 'table', head, rows: trs.filter(vis).map(tr => [...tr.children].map(td => T(td.innerText))).slice(0, 500) };
  }
  const rr = [...document.querySelectorAll('[role=row]')].filter(vis);
  if (rr.length > 1) { const cells = r => [...r.querySelectorAll('[role=cell],[role=gridcell],[role=columnheader]')].map(c => T(c.innerText)); return { url: location.href, title: document.title, kind: 'grid', head: cells(rr[0]), rows: rr.slice(1).map(cells).slice(0, 500) }; }
  const items = [...document.querySelectorAll('li,[class*=item],[class*=Item],[class*=row],[class*=Row],[class*=card],[class*=Card]')].filter(e => vis(e) && /[\d,]{3,}\s*원/.test(e.innerText) && e.innerText.length < 500);
  const top = items.filter(e => !items.some(o => o !== e && e.contains(o)));
  return { url: location.href, title: document.title, kind: 'list', head: [], rows: top.slice(0, 300).map(e => [T(e.innerText)]) };
}
// ---------- 3.3: 무신사 후기 — 내 후기 화면에서 그 주문의 '후기 작성'을 눌러요 (world MAIN) ----------
async function kcMsReviewOpen(no, name) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 20 && !/후기/.test(document.body.innerText); i++) await wait(400);
  await wait(800);
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const BTN = /^(후기\s*(작성|쓰기)(하기)?|리뷰\s*(작성|쓰기)(하기)?|작성하기)$/;
  const btns = [...document.querySelectorAll('a,button,[role=button]')].filter(e => vis(e) && BTN.test((e.innerText || '').replace(/\s+/g, ' ').trim()));
  const key = [String(no || ''), String(name || '').slice(0, 14)].filter(Boolean);
  let hit = null;
  for (const b of btns) { let a = b; for (let d = 0; d < 7 && a; d++, a = a.parentElement) { const t = a.innerText || ''; if (key.some(k => k && t.includes(k))) { hit = b; break; } } if (hit) break; }
  if (!hit && btns.length === 1) hit = btns[0];
  if (!hit) return { ok: false, why: btns.length ? 'match' : 'nobtn', n: btns.length };
  const href = hit.closest('a[href]') && hit.closest('a[href]').href;
  hit.click();
  return { ok: true, href: href || '' };
}
// 후기 화면에 내가 쓴 글과 별점을 넣어요 (등록은 직접 눌러요)
async function kcReviewFill(text, stars) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  let ta = null;
  for (let i = 0; i < 30; i++) { ta = [...document.querySelectorAll('textarea')].filter(vis).sort((a, b) => b.getBoundingClientRect().height - a.getBoundingClientRect().height)[0]; if (ta) break; await wait(400); }
  if (!ta) return { ok: false, why: 'notext' };
  const setV = (el, v) => { el.focus(); const d = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value'); d.set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  let star = false;
  const n = Math.max(1, Math.min(5, +stars || 5));
  const lab = [...document.querySelectorAll('[aria-label],[title]')].filter(vis).find(e => new RegExp(`^\\s*(별점\\s*)?${n}\\s*(점|개|stars?)`).test(e.getAttribute('aria-label') || e.getAttribute('title') || ''));
  if (lab) { lab.click(); star = true; }
  else {
    const groups = [...document.querySelectorAll('[class*=star i],[class*=rating i],[class*=Star],[class*=Rating]')].filter(vis);
    for (const g of groups) { const kids = [...g.querySelectorAll('button,label,input[type=radio],svg,span,i')].filter(vis); if (kids.length >= 5 && kids.length <= 12) { const k = kids.length >= 10 ? kids[n * 2 - 1] : kids[n - 1]; if (k) { (k.closest('button,label') || k).click(); star = true; break; } } }
  }
  setV(ta, text);
  ta.scrollIntoView({ block: 'center' });
  return { ok: true, star, len: text.length };
}

// 3.7: 화면이 비었는지 보기 (웨일 연결에서도 이름으로 불러요)
function kcPageInfo() { return { n: document.documentElement.outerHTML.length, title: document.title, url: location.href }; }
