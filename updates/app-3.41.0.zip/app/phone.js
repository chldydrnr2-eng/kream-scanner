'use strict';
/* 킥스캔 3.37 — 휴대폰 보기
   PC 킥스캔이 정리한 요약(이번 달 실적 · 판매 · 재고 · 시세)을 킥스캔 계정 서버(ks_snap)에 올려요.
   휴대폰 브라우저에서 같은 계정으로 로그인하면 보기만 할 수 있어요(사이트 m/).
   바뀐 뒤 20초 동안 더 안 바뀌면 묶어서 올려요(계속 바뀌어도 5분에 한 번은 올려요). 실패해도 다른 기능에는 영향 없어요. */
const PHONE_WAIT = 20000, PHONE_MAXWAIT = 5 * 60000;
const PHONE_URL0 = 'https://chldydrnr2-eng.github.io/kream-scanner/m/';
// 위 주소의 QR(버전 4 · M) — 33줄, 줄마다 33칸을 16진수로
const PHONE_QR = '1fcd7667f,1055aaf41,17423215d,174ba845d,175e8025d,104b44e41,1fd55557f,69d900,1549bfa12,a2811de3,1afd88da7,da433b11,1afd00dca,1619a296d,2ca88dbb,1a32aa952,5e489bc8,1818d91e3,19d654945,2882ff71,14eab7bca,996bf1cb,13433b873,c86dda60,1d6c3b9f1,109071b,1fc519357,1049f0d10,175bc1df8,174a22a11,175804c1d,10486db92,1fd20af93';
const PH = { kinds: new Set(), t: null, first: 0, busy: false, st: null };
const phoneLic = () => (typeof window !== 'undefined' && window.kcApp && window.kcApp.lic && window.kcApp.lic.snapPut) ? window.kcApp.lic : null;
const phoneOn = () => !!phoneLic() && !(typeof S !== 'undefined' && S && +S.phone === 0);   // 기본은 켜짐
const r0 = n => Math.round(+n || 0);

// 저장소에 무엇이 저장됐는지 보고 올릴 종류를 골라요 (store.set 끝에서 불러요)
function phoneSnapHook(key) {
  key = String(key || '');
  if (key === 'inv' || key.startsWith('inv@')) phoneSnapSoon(['summary', 'sales', 'stock']);
  else if (key === 'kreamSales') phoneSnapSoon(['summary', 'sales']);
  else if (key === 'products' || key === 'finder') phoneSnapSoon(['market', 'summary']);
}
function phoneSnapSoon(kinds) {
  if (!phoneOn()) return;
  for (const k of kinds || ['summary', 'sales', 'stock', 'market']) PH.kinds.add(k);
  const now = Date.now(); if (!PH.first) PH.first = now;
  clearTimeout(PH.t);
  PH.t = setTimeout(phoneSnapFlush, Math.max(0, Math.min(PHONE_WAIT, PH.first + PHONE_MAXWAIT - now)));
}
async function phoneSnapFlush() {
  PH.t = null; PH.first = 0;
  if (PH.busy) { PH.t = setTimeout(phoneSnapFlush, PHONE_WAIT); return; }
  const L = phoneLic(); if (!L || !phoneOn()) { PH.kinds.clear(); return; }
  const kinds = [...PH.kinds]; PH.kinds.clear(); if (!kinds.length) return;
  PH.busy = true;
  try {
    const st = await L.snapState().catch(() => null);
    if (!st || !st.on || !st.login) return;
    if (st.missing && st.retryAt > Date.now()) return;   // 서버 표가 아직 없으면 6시간마다만
    for (const k of kinds) {
      let data = null; try { data = phoneData(k); } catch (e) { try { kcErrPush('휴대폰 보기 ' + k + ': ' + e.message, 'phone.js'); } catch (x) {} continue; }
      const r = await L.snapPut(k, data).catch(() => null);
      if (r && r.missing) break;
    }
  } catch (e) {} finally { PH.busy = false; phoneRowPaint(); }
}
function phoneData(kind) {
  return kind === 'summary' ? phoneSummary() : kind === 'sales' ? phoneSales() : kind === 'stock' ? phoneStock() : kind === 'market' ? phoneMarket() : {};
}
const phoneInv = () => typeof INV !== 'undefined' && INV && Array.isArray(INV.outs);
const phoneBiz = () => { try { return typeof bizCur === 'function' ? bizCur().name : ''; } catch (e) { return ''; } };
function phoneWeekStart() { const d = new Date(today() + 'T00:00:00'); const w = (d.getDay() + 6) % 7; d.setDate(d.getDate() - w); return fmtD(d); }

// ---------- summary: 이번 달 · 지난달 실적, 재고, 오늘 · 이번 주 판매 ----------
function phoneSummary() {
  const t = today(), o = { v: 1, at: Date.now(), biz: phoneBiz(), bizN: (typeof BIZ !== 'undefined' && BIZ.list) ? BIZ.list.length : 1 };
  if (phoneInv()) {
    const fig = (a, b) => { const f = monthFigures(a, b); return { sold: f.sold, rev: r0(f.rev), margin: r0(f.margin), fees: r0(f.fees), buy: r0(f.buy) }; };
    const pm = new Date(t.slice(0, 7) + '-01T00:00:00'); pm.setMonth(pm.getMonth() - 1); const ps = fmtD(pm);
    o.month = { m: t.slice(0, 7), ...fig(monthStart(t), monthEnd(t)) };
    o.prev = { m: ps.slice(0, 7), ...fig(monthStart(ps), monthEnd(ps)) };
    o.months = []; const d0 = new Date(t.slice(0, 7) + '-01T00:00:00');
    for (let i = 5; i >= 0; i--) { const d = new Date(d0); d.setMonth(d.getMonth() - i); const s = fmtD(d); const f = monthFigures(monthStart(s), monthEnd(s)); o.months.push({ m: s.slice(0, 7), sold: f.sold, rev: r0(f.rev), margin: r0(f.margin) }); }
    const C = invCalc(); let qty = 0, value = 0; const skus = new Set();
    for (const [k, s] of C.stock) { qty += s.qty; value += s.value; skus.add(k.split('|')[0]); }
    o.stock = { skus: skus.size, qty, value: r0(value) };
    const ws = phoneWeekStart(); let td = 0, wk = 0, tdRev = 0;
    for (const x of INV.outs) { const d = x.settleDate || x.date, n = x.qty - (x.retQty || 0); if (d === t) { td += n; if (x.settled) tdRev += (x.price - (x.disc || 0)) * n; } if (d >= ws && d <= t) wk += n; }
    o.today = { sold: td, rev: r0(tdRev) }; o.week = { sold: wk, from: ws };
    o.pre = INV.outs.filter(x => x.kind === 'pre' && !x.settled).length;
  }
  if (typeof kSales !== 'undefined' && kSales) { o.pending = (kSales.pending || []).length; o.unrec = Object.keys(kSales.unrec || {}).length; o.pendingAt = kSales.pendingAt || 0; }
  if (typeof products !== 'undefined') o.products = products.length;
  return o;
}
// ---------- sales: 최근 판매 200건(크림 정산 + 재고관리 출고), 진행 중, 재고 미등록 ----------
function phoneSales() {
  const o = { v: 1, at: Date.now(), biz: phoneBiz(), rows: [], pending: [], unrec: [] };
  if (phoneInv()) {
    const outs = INV.outs.slice().sort((a, b) => String(b.settleDate || b.date).localeCompare(String(a.settleDate || a.date)) || (b.at || 0) - (a.at || 0)).slice(0, 200);
    o.rows = outs.map(x => {
      const it = itemOf(x.itemId), n = outNums(x), p = partnerOf(x.partnerId), ks = String(x.kreamSaleId || '');
      return { d: x.settleDate || x.date, n: itName(it), c: it ? it.code || '' : '', sz: x.size || '', q: n.net, p: x.settled ? r0(n.price) : 0, fee: x.settled ? r0(n.fee) : 0, cost: r0(n.unitCost), m: n.margin == null ? null : r0(n.margin),
        ch: (p && p.name) || (ks ? '크림' : '기타'), k: ks ? (ks.startsWith('S') ? '보관 판매' : '일반 판매') : x.kind === 'pre' ? '우선출고' : '출고', st: !n.net ? '반품' : x.settled ? '정산완료' : '정산 대기' };
    });
    o.total = INV.outs.length;
  }
  if (typeof kSales !== 'undefined' && kSales) {
    o.pending = (kSales.pending || []).slice(0, 100).map(r => ({ d: String(r.date || '').slice(0, 10), n: r.name || r.code || '', c: r.code || '', sz: r.size || '', p: r0(r.price), pay: r0(r.payout), st: r.status || '진행 중' }));
    o.pendingAt = kSales.pendingAt || 0;
    const have = new Set(phoneInv() ? INV.outs.map(x => String(x.kreamSaleId || '')).filter(Boolean) : []);
    o.unrec = Object.entries(kSales.unrec || {}).filter(([id]) => !have.has(id)).map(([, u]) => ({ d: u.date || '', n: u.name || u.code || '', c: u.code || '', sz: u.size || '', p: r0(u.price), pay: r0(u.payout), k: u.kind || '', why: String(u.why || '').slice(0, 80) }))
      .sort((a, b) => String(b.d).localeCompare(String(a.d))).slice(0, 100);
  }
  return o;
}
// ---------- stock: 상품 · 사이즈별 재고 수량 · 평균 매입가 (최대 500줄) ----------
function phoneStock() {
  const o = { v: 1, at: Date.now(), biz: phoneBiz(), rows: [] };
  if (!phoneInv()) return o;
  const C = invCalc(); const rows = [];
  for (const [k, s] of C.stock) {
    const [id, size] = k.split('|'); const it = itemOf(id);
    rows.push({ n: itName(it), c: it ? it.code || '' : '', b: it ? it.brand || '' : '', sz: size, q: s.qty, avg: s.qty ? r0(s.value / s.qty) : 0, v: r0(s.value) });
  }
  rows.sort((a, b) => a.n.localeCompare(b.n, 'ko') || String(a.sz).localeCompare(String(b.sz), 'ko', { numeric: true }));
  o.total = rows.length; o.rows = rows.slice(0, 500);
  return o;
}
// ---------- market: 내 상품 시세 · 마진(최대 200개) + 최근 찾기 결과 상위 50개 ----------
function phoneMarket() {
  const o = { v: 1, at: Date.now(), mine: [], find: null };
  if (typeof products !== 'undefined') {
    o.mine = products.slice(0, 200).map(p => {
      let a = null; try { a = typeof analyze === 'function' ? analyze(p) : null; } catch (e) {}
      const info = (p.raw && p.raw.info) || {};
      return { n: info.name || ('크림 상품 ' + p.pid), c: info.code || '', cost: r0(p.cost), sell: a ? r0(a.sell) : null, settle: a ? r0(a.settle) : null, m: a && a.margin != null && +p.cost ? r0(a.margin) : null,
        vd: a && a.verdict ? a.verdict[1] : '', vk: a && a.verdict ? a.verdict[0] : '', e7: a ? r0(a.est7) : null, at: p.at || 0, err: p.err ? String(p.err).slice(0, 60) : '' };
    });
    o.mineTotal = products.length;
  }
  if (typeof finder !== 'undefined' && finder && Array.isArray(finder.items) && finder.items.length) {
    const G = { go: 0, near: 1, pricey: 2, none: 3 };
    const items = finder.items.slice().sort((a, b) => (G[a.grade] ?? 3) - (G[b.grade] ?? 3) || (b.margin ?? -1e12) - (a.margin ?? -1e12) || (b.est7 || 0) - (a.est7 || 0)).slice(0, 50);
    o.find = { at: finder.at || 0, what: finder.mode === 'musinsa' ? '무신사 랭킹' : finder.mode === 'scan' ? (finder.scan || '쇼핑몰 찾기') : finder.mode === 'list' ? '목록 조사' : '크림 인기 상품', stage: finder.stage || '', total: finder.items.length,
      items: items.map(it => ({ n: String(it.name || '').slice(0, 80), c: it.code || '', sell: r0(it.sell), settle: r0(it.settle), e7: r0(it.est7), src: it.best ? String(it.best.label || it.best.name || '').slice(0, 30) : '', buy: it.best ? r0(it.best.min) : null, m: it.margin == null ? null : r0(it.margin), g: it.grade || 'none' })) };
  }
  return o;
}

// ---------- 설정 화면: 켜기 · 끄기, 주소 · QR, 마지막 올린 시각 ----------
function phoneQrSvg() {
  const R = PHONE_QR.split(',').map(h => parseInt(h, 16).toString(2).padStart(33, '0'));
  let d = ''; R.forEach((row, y) => { for (let x = 0; x < row.length; x++) if (row[x] === '1') d += `M${x + 2} ${y + 2}h1v1h-1z`; });
  return `<svg class="phone-qr" viewBox="0 0 37 37" role="img" aria-label="휴대폰 보기 주소 QR"><rect width="37" height="37" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}
const phoneAgo = t => { if (!t) return ''; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? '방금' : m < 60 ? m + '분 전' : m < 1440 ? Math.round(m / 60) + '시간 전' : new Date(t).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }); };
async function phoneRowPaint() {
  const box = typeof $ === 'function' ? $('#phoneRow') : null; if (!box) return;
  const L = phoneLic(); if (!L) { box.hidden = true; return; }
  const st = PH.st = await L.snapState().catch(() => null);
  if (!st || !st.on) { box.hidden = true; return; }
  box.hidden = false;
  const url = st.url || PHONE_URL0, on = phoneOn();
  const state = !on ? '꺼져 있어요' : !st.login ? '킥스캔에 로그인하면 올려요' : st.missing ? '서버 준비 전이에요 — 준비되면 저절로 올라가요' : st.err ? '마지막 시도: ' + st.err : st.at ? '마지막으로 올린 때: ' + phoneAgo(st.at) : '아직 올린 적 없어요 — 곧 올라가요';
  box.innerHTML = `<div class="phone-txt"><label class="phone-sw"><input type="checkbox" id="s_phone"${on ? ' checked' : ''}> <b>휴대폰 보기에 올리기</b></label>
    <p class="hint">이번 달 실적 · 최근 판매 · 재고 · 시세 요약을 킥스캔 계정 서버에 올려서, 휴대폰에서 같은 계정으로 로그인해 볼 수 있어요(보기만 돼요). 매출 · 매입가 같은 장사 정보가 서버에 저장되고, 내 계정으로 로그인해야만 보여요. 끄면 서버에 올린 것도 지워요.</p>
    <p class="hint">휴대폰에서 <a href="#" id="phoneLink">${esc(url)}</a> 를 열고 '홈 화면에 추가'를 누르면 앱처럼 써요.</p>
    <p class="hint" id="phoneState">${esc(state)}</p></div>${url === PHONE_URL0 ? phoneQrSvg() : ''}`;
}
function phoneBind() {
  const box = $('#phoneRow'); if (!box || box.dataset.bound) return; box.dataset.bound = '1';
  box.addEventListener('click', e => {
    if (e.target.closest('#phoneLink')) { e.preventDefault(); const u = (PH.st && PH.st.url) || PHONE_URL0; try { if (window.kcApp && window.kcApp.openExt) window.kcApp.openExt(u).catch(() => {}); } catch (x) {} }
  });
  box.addEventListener('change', async e => {
    if (e.target.id !== 's_phone') return;
    S.phone = e.target.checked ? 1 : 0; await store.set('settings', S);
    if (S.phone) phoneSnapSoon(); else { clearTimeout(PH.t); PH.kinds.clear(); const L = phoneLic(); if (L && L.snapClear) await L.snapClear().catch(() => null); }
    phoneRowPaint();
  });
}
function phoneInit() {
  try {
    phoneBind(); phoneRowPaint();
    const sb = $('#btnSettings'); if (sb) sb.addEventListener('click', () => phoneRowPaint());
    const L = phoneLic(); if (!L) return;
    const q = new URLSearchParams(location.search);
    if (q.get('orders') === '1' || q.get('track') === '1') return;   // 자동 작업용으로 잠깐 열린 창은 처음 올리기를 안 해요
    // 켜고 30초쯤 뒤 한 번 전부 올려요 (휴대폰에서 'PC에서 한 번 켜 두면 나와요'가 되게)
    setTimeout(() => phoneSnapSoon(['summary', 'sales', 'stock', 'market']), 10000);
    if (window.kcApp.lic.onChange) window.kcApp.lic.onChange(st => { if (st && (st.state === 'ok' || st.state === 'grace' || st.state === 'blocked')) phoneSnapSoon(); phoneRowPaint(); });
  } catch (e) {}
}
document.addEventListener('DOMContentLoaded', () => setTimeout(phoneInit, 1500));
