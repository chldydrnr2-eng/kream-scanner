/* 킥스캔 — 보관 판매 (줍픽 오피스 보관 판매: 입고 검수 · 보관 중 · 판매 내역 · 발송 내역 · 확인 필요)
   KREAM 보관판매 내역(auto.js kInv — 보관판매 관리에서 불러온 것) · 재고관리 우선출고(INV.outs kind 'pre') · 매입 기록(INV.lots)을 맞춰 봐요.
   POIZON 창고(보관) 재고는 오픈 API 승인 뒤(단계 3)에 같은 표에 들어와요. */
const STO_TABS = [['req', '신청 기록'], ['insp', '입고 검수'], ['keep', '보관 중'], ['hist', '판매 내역'], ['sent', '발송 내역'], ['check', '확인 필요']];
const stoS = () => IS.sto || (IS.sto = { tab: 'keep', sub: 'ing', per: 'm3' });
// KREAM 보관 상태 → 입고 검수(ing) · 입고 불합격(bad) · 보관 중(keep) · 판매 완료(sold) · 끝(out)
function stoKind(i) {
  const s = String(i.status || ''), n = String(i.statusName || '');
  if (/^(canceled|retrieved)$/.test(s) || /취소|회수|반송 완료/.test(n)) return 'out';
  if (/^(sold|payout_completed)$/.test(s) || /판매 완료|정산/.test(n)) return 'sold';
  if (s === 'return_on_failure' || /불합격|반송|보류/.test(n)) return 'bad';
  if (/pending/.test(s) || /신청|발송|입고 대기|검수|이동|배송/.test(n)) return 'ing';
  return 'keep';
}
function stoItems(kind) { return (typeof kInv !== 'undefined' && kInv && kInv.items ? kInv.items : []).filter(i => stoKind(i) === kind); }
function stoGroup(L) { const G = new Map(); for (const i of L) { const k = codeKey(i.code) + '|' + ckey(i.size); const g = G.get(k) || { i, n: 0 }; g.n++; G.set(k, g); } return [...G.values()]; }
function stoInsp() {
  const S0 = stoS(), ing = stoItems('ing'), bad = stoItems('bad'), L = S0.sub === 'bad' ? bad : ing;
  return `<div class="stk-bar"><button type="button" class="chip${S0.sub !== 'bad' ? ' on' : ''}" data-a="stoSub" data-v="ing">검수 중 ${ing.length}</button><button type="button" class="chip${S0.sub === 'bad' ? ' on' : ''}" data-a="stoSub" data-v="bad">입고 불합격 ${bad.length}</button><span class="small">창고로 가는 중 ${ing.length}개</span></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">상품</th><th class="l">상품명</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">구분</th><th class="l">계정</th><th>수량</th><th class="l">검수 결과</th></tr></thead><tbody>
  ${stoGroup(L).map(g => `<tr><td></td><td class="l">${esc(String(g.i.name || '').slice(0, 40))}</td><td class="l mono">${esc(g.i.code || '')}</td><td class="l">${esc(g.i.sizeName || g.i.size || '')}</td><td class="l">보관 판매</td><td class="l">KREAM</td><td>${g.n}</td><td class="l"><span class="pill ${S0.sub === 'bad' ? 'bad' : 'warn'}">${esc(g.i.statusName || g.i.status || '')}</span></td></tr>`).join('') || `<tr><td colspan="8" class="empty">${S0.sub === 'bad' ? '입고 불합격된 재고가 없어요' : '보관 판매 재고는 보관판매 매크로로 신청하거나 KREAM 보관을 보내면 여기 보이고, 창고가 검수를 마치면 보관 중으로 옮겨져요.'}</td></tr>`}
  </tbody></table></div>${S0.sub === 'bad' ? '<p class="hint">POIZON 입고 불합격 → [하자 판매]로 옮기기는 POIZON 오픈 API 승인 뒤에 돼요.</p>' : ''}`;
}
function stoKeep() {
  const keep = stoGroup(stoItems('keep')), st = typeof slStock === 'function' ? slStock() : new Map();
  let cost = 0, sell = 0, noRec = 0, n = 0;
  const pre = INV.outs.filter(o => o.kind === 'pre' && !o.settled);
  const rows = keep.map(g => {
    const k = codeKey(g.i.code) + '|' + ckey(g.i.size);
    const it = typeof kItemOf === 'function' ? kItemOf(g.i.code, g.i.pid) : null;
    const po = it ? pre.filter(o => o.itemId === it.id) : [];
    const pq = po.reduce((t, o) => t + (o.qty - (o.retQty || 0)), 0), unit = po.length ? po.reduce((t, o) => t + outNums(o).unitCost * (o.qty - (o.retQty || 0)), 0) / (pq || 1) : (st.get(k) ? st.get(k).cost / st.get(k).qty : null);
    const price = +g.i.price || +(g.i.ask || 0) || null, net = price ? price - (typeof feeOf === 'function' ? feeOf(price) : 0) : null;
    n += g.n; if (unit != null) { cost += unit * g.n; if (net != null) sell += net * g.n; } else noRec += g.n;
    return `<tr><td class="l">${esc(String(g.i.name || '').slice(0, 40))}</td><td class="l mono">${esc(g.i.code || '')}</td><td class="l">${esc(g.i.sizeName || g.i.size || '')}</td><td>${g.n}</td><td class="l">KREAM 창고</td><td>${price ? won(price) : '–'}</td><td>${unit != null ? won(unit) : '<span class="small">매입 기록 없음</span>'}</td><td class="${net != null && unit != null && net - unit < 0 ? 'neg' : 'pos'}">${net != null && unit != null ? wonS(Math.round((net - unit) * g.n)) : '–'}</td><td class="l"><span class="pill mute">${esc(g.i.statusName || '보관 중')}</span></td></tr>`;
  }).join('');
  return `<div class="kgrid stk-cards">${card('매입 원가', won(cost), '', `보관 중 ${n}개`)}${card('예상 판매가', sell ? won(sell) : '–', 'acc', '판매가가 있는 재고 · 수수료 뺀 값')}${card('= 예상 손익', sell ? wonS(Math.round(sell - cost)) : '–', sell - cost >= 0 ? 'pos' : 'neg')}${card('매입 기록 없음', noRec + '건', noRec ? 'warn' : '', noRec ? '재고 › 재고 가져오기에서 매입가를 채워 주세요' : 'KREAM 창고 재고가 모두 매입 기록에 있어요')}</div>
  <div class="stk-bar"><span class="small">KREAM 보관판매 ${typeof kInv !== 'undefined' && kInv && kInv.at ? new Date(kInv.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' 기준' : '— 아직 안 불러왔어요'}</span><span class="topsp"></span><button type="button" class="ghost small" data-a="stoLoad">↻ KREAM 보관 불러오기</button>${noRec ? '<button type="button" class="ghost small" data-a="stoImp">재고 가져오기 ›</button>' : ''}</div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th>수량</th><th class="l">창고</th><th>판매가</th><th>매입가</th><th>예상 손익</th><th class="l">상태</th></tr></thead><tbody>${rows || '<tr><td colspan="9" class="empty">보관 중인 재고가 없어요 — [↻ KREAM 보관 불러오기]를 눌러 보세요</td></tr>'}</tbody></table></div>
  <p class="hint">KREAM 보관 판매 신청은 실제 재고 수량을 넘지 않게 해요(보관판매 매크로).</p>`;
}
function stoHist() {
  // 보관 판매로 팔린 것 = 재고관리 판매 중 크림 보관 정산(우선출고에서 정산) 또는 KREAM 보관 판매 완료
  const S0 = stoS(), since = typeof stkSince === 'function' ? stkSince(S0.per) : '';
  const L = INV.outs.filter(o => o.settled && /보관/.test(o.memo || '') && (!since || (o.settleDate || o.date || '') >= since));
  let rev = 0, cogs = 0, fees = 0, n = 0; for (const o of L) { const x = outNums(o); rev += x.rev; cogs += x.cogs; fees += x.fees; n += x.net; }
  const prof = rev - cogs - fees;
  return `<div class="stk-bar">${(typeof STK_PER !== 'undefined' ? STK_PER : []).map(([k, t]) => `<button type="button" class="chip${S0.per === k ? ' on' : ''}" data-a="stoPer" data-v="${k}">${t}</button>`).join('')}</div>
  <div class="sl-band"><span><small>매출</small><b>${won(rev)}</b><i>${n}개 판매</i></span><em>−</em><span><small>원가</small><b>${won(cogs)}</b><i>판매 상품 매입가</i></span><em>−</em><span><small>수수료</small><b>${won(fees)}</b><i>판매처가 뗀 금액</i></span><em>=</em><span class="tot"><small>손익</small><b class="${prof >= 0 ? 'pos' : 'neg'}">${wonS(Math.round(prof))}</b><i>마진율 ${rev ? Math.round(prof / rev * 1000) / 10 + '%' : '–'}</i></span></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">판매일</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th>수량</th><th>개당 판매가</th><th>개당 수수료</th><th>개당 매입가</th><th>손익</th></tr></thead><tbody>
  ${L.map(o => { const it = itemOf(o.itemId), x = outNums(o); return `<tr><td class="l">${esc(o.settleDate || o.date || '')}</td><td class="l">${esc(it ? itName(it) : '')}</td><td class="l mono">${esc(it ? String(it.code || '').split('/')[0] : '')}</td><td class="l">${esc(o.size)}</td><td>${o.qty}</td><td>${won(x.price)}</td><td>${won(x.fee)}</td><td>${won(x.unitCost)}</td><td class="${x.margin >= 0 ? 'pos' : 'neg'}">${wonS(Math.round(x.margin || 0))}</td></tr>`; }).join('') || '<tr><td colspan="9" class="empty">보관 판매로 정산된 판매가 아직 없어요 — 판매처 연동의 새 판매 확인 때 자동으로 들어와요</td></tr>'}
  </tbody></table></div>`;
}
function stoSent() {
  const L = (INV.ships || []).filter(s => s.storage);
  return `<div class="stk-bar"><span class="topsp"></span><button type="button" class="primary small" data-a="stoShip">발송 등록</button></div>
  <div class="tbl"><table class="main"><thead><tr><th class="l">보낸 날</th><th class="l">택배</th><th>포함 상품 수량</th><th class="l">창고</th><th>택배비</th><th class="l">메모</th></tr></thead><tbody>
  ${L.slice().reverse().map(s => `<tr><td class="l">${esc(s.date)}</td><td class="l">${esc(s.courier)} <span class="mono small">${esc(s.no)}</span></td><td>${s.n || 0}개</td><td class="l">${esc(s.wh || '')}</td><td>${s.cost ? won(s.cost) : '–'}</td><td class="l small">${esc(s.memo || '')}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">[발송 등록]으로 보관 판매 재고를 판매처 창고로 보내면 여기에 남아요.</td></tr>'}
  </tbody></table></div>`;
}
function stoCheck() {
  const bad = stoItems('bad'), keep = stoGroup(stoItems('keep')), st = typeof slStock === 'function' ? slStock() : new Map();
  const noRec = keep.filter(g => { const it = typeof kItemOf === 'function' ? kItemOf(g.i.code, g.i.pid) : null; return !it || !(st.get(codeKey(g.i.code) + '|' + ckey(g.i.size)) || INV.outs.some(o => o.kind === 'pre' && o.itemId === it.id)); });
  const rows = noRec.map(g => `<tr><td class="l">${esc(String(g.i.name || '').slice(0, 40))}</td><td class="l mono">${esc(g.i.code)}</td><td class="l">${esc(g.i.sizeName || g.i.size)}</td><td>${g.n}</td><td class="l"><span class="pill warn">매입 기록 없음</span> <span class="small">재고 가져오기에서 매입가를 채워 주세요</span></td></tr>`).join('')
    + bad.map(i => `<tr><td class="l">${esc(String(i.name || '').slice(0, 40))}</td><td class="l mono">${esc(i.code)}</td><td class="l">${esc(i.sizeName || i.size)}</td><td>1</td><td class="l"><span class="pill bad">${esc(i.statusName || '입고 불합격')}</span></td></tr>`).join('');
  return `<div class="tbl"><table class="main stk-t"><thead><tr><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th>수량</th><th class="l">사유</th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="empty">보관 판매에서 확인할 것이 없어요.</td></tr>'}</tbody></table></div>`;
}
// 줍픽 KREAM 보관(PC) 단계 칸 5개: 보관 신청 → 신청 기록(7일) → 발송 → 입고 검수 → 보관 중
const STO_D7 = 7 * 864e5;
function stoLog7() { return (typeof stockLog !== 'undefined' ? stockLog : []).filter(x => x && Date.now() - x.t <= STO_D7); }
function stoSteps() {
  const Q = typeof stockQ !== 'undefined' ? stockQ : [], left = Q.filter(e => e.on).reduce((t, e) => t + Math.max(0, typeof sqLeft === 'function' ? sqLeft(e) : 0), 0);
  const log = stoLog7(), done = log.filter(x => /신청 완료|내역에 맞춤/.test(x.result || '')).reduce((t, x) => t + (+x.qty || 0), 0);
  const sent = (INV.ships || []).filter(x => x.storage && Date.now() - (x.at || 0) <= STO_D7).reduce((t, x) => t + (+x.n || 0), 0);
  const run = typeof SQ !== 'undefined' && SQ.run, S0 = stoS(), bad = stoItems('bad').length;
  const st = [['macro', '보관 신청', left ? `${left}개 남음` : '대기 없음', run ? '신청 중' : ''], ['req', '신청 기록', `7일 ${done}개`, ''], ['sent', '발송', `7일 ${sent}개`, ''],
    ['insp', '입고 검수', `${stoItems('ing').length}개`, bad ? `불합격 ${bad}` : ''], ['keep', '보관 중', `${stoItems('keep').length}개`, '']];
  return `<div class="sto-steps">${st.map(([k, t, n, w], i) => `<button type="button" class="sto-step${S0.tab === k ? ' on' : ''}" data-a="${k === 'macro' ? 'stoMacro' : 'stoTab'}" data-v="${k}"><em>${i + 1}</em><b>${t}</b><span>${n}</span>${w ? `<small class="pill ${k === 'insp' ? 'bad' : 'ok'}">${w}</small>` : ''}</button>`).join('<i class="sto-arr">›</i>')}</div>`;
}
function stoReq() {
  const L = stoLog7(), run = typeof SQ !== 'undefined' && SQ.run;
  const cls = r => /신청 완료/.test(r) ? 'ok' : /맞춤/.test(r) ? 'mute' : /불일치|실패|오류/.test(r) ? 'bad' : 'warn';
  return `<div class="stk-bar">${run ? `<span class="pill ok">보관 신청 진행 중</span> <span class="small">${esc((typeof SQ !== 'undefined' && SQ.msg) || '')}</span><button type="button" class="ghost small" data-a="stoStop">멈춤</button>` : '<span class="small">지금 진행 중인 보관 신청은 없어요</span>'}</div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th class="l">시각</th><th class="l">상품명</th><th class="l">품번</th><th class="l">사이즈</th><th>수량</th><th>보증금</th><th class="l">결과</th></tr></thead><tbody>
  ${L.map(x => { const d = new Date(x.t); return `<tr><td class="l">${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}</td><td class="l">${esc(String(x.name || '').slice(0, 40))}</td><td class="l mono">${esc(x.code || '')}</td><td class="l">${esc(x.size || '')}</td><td>${+x.qty || 0}</td><td>${x.total ? won(x.total) : '–'}</td><td class="l"><span class="pill ${cls(x.result || '')}">${esc(x.result || '')}</span>${x.said ? `<div class="small">${esc(x.said)}</div>` : ''}</td></tr>`; }).join('') || '<tr><td colspan="7" class="empty">최근 7일 보관 신청 기록이 없어요. 보관판매 매크로에서 신청하면 여기에 남아요.</td></tr>'}
  </tbody></table></div><p class="hint">이 PC 에서 한 보관 신청만 보여요(7일). 그 전 기록은 보관판매 매크로의 '보관 신청 내역'에 있어요.</p>`;
}
function vStorage() {
  const S0 = stoS(), body = { req: stoReq, insp: stoInsp, keep: stoKeep, hist: stoHist, sent: stoSent, check: stoCheck }[S0.tab] || stoKeep;
  return `${head('보관 판매', 'KREAM 보관 판매 재고의 입고 검수 · 보관 중 · 판매 · 발송을 봐요. POIZON 창고는 오픈 API 승인 뒤에 들어와요.', '<button type="button" class="ghost" data-a="stoMacro">보관판매 매크로 ›</button>')}${typeof flash === 'function' ? flash() : ''}
  ${stoSteps()}<div class="subtabs">${STO_TABS.map(([k, t]) => `<button type="button" data-a="stoTab" data-v="${k}" aria-selected="${S0.tab === k}">${t}</button>`).join('')}</div>
  <div class="stk-bar"><button type="button" class="chip on">전체</button><button type="button" class="chip">KREAM</button><button type="button" class="chip" disabled title="POIZON 오픈 API 승인 뒤">POIZON</button></div>${body()}`;
}
async function stoAct(a, el) {
  const S0 = stoS(), v = el.dataset.v;
  switch (a) {
    case 'stoTab': S0.tab = v; S0.sub = 'ing'; break;
    case 'stoSub': S0.sub = v; break;
    case 'stoPer': S0.per = v; break;
    case 'stoMacro': return route('kmacro');
    case 'stoStop': if (typeof SQ !== 'undefined') { SQ.run = false; if (typeof sqSet === 'function') sqSet('멈췄어요'); } IS.msg = '보관 신청을 멈췄어요 — 지금 하던 한 건이 끝나면 멈춰요'; break;
    case 'stoImp': IS.stk = { ...(typeof stkS === 'function' ? stkS() : {}), tab: 'imp' }; return go('stock');
    case 'stoLoad': if (typeof kInvRead !== 'function') return; IS.msg = 'KREAM 보관판매 내역을 불러오는 중이에요…'; renderInv(); try { await kInvRead(); IS.msg = 'KREAM 보관판매 내역을 불러왔어요'; } catch (e) { IS.msg = '불러오지 못했어요: ' + e.message; } break;
    case 'stoShip': {
      const cs = INV.couriers || [];
      return invDialog('보관 판매 발송 등록', `<p class="hint">주문 없이 판매처 창고로 보내는 상자예요. 택배비는 지출(택배비)로 자동 등록해요.</p><div class="dgrid"><label>창고<select name="wh">${opt('KREAM', 'KREAM')}${opt('POIZON', 'POIZON')}</select></label><label>택배사<select name="courier">${['CJ대한통운', '롯데택배', '한진택배', '우체국택배', '로젠택배', '경동택배', '대신택배', '일양로지스', 'CU 편의점택배', ...cs.map(c => c.name)].filter((x, i, A) => A.indexOf(x) === i).map(c => opt(c, c)).join('')}</select></label><label>운송장<input name="no"></label><label>상자에 넣은 수량<input type="number" name="n" min="1" value="1"></label><label>보낸 날<input type="date" name="date" value="${today()}"></label><label>택배비<input type="number" name="cost" step="100"></label><label>메모<input name="memo"></label></div>`, async fd => {
        if (!String(fd.no || '').trim()) return '운송장 번호를 넣어 주세요';
        INV.ships = INV.ships || []; INV.ships.push({ id: uid(), at: Date.now(), storage: true, date: fd.date || today(), wh: fd.wh, courier: fd.courier, no: String(fd.no).trim(), n: +fd.n || 1, cost: +fd.cost || 0, memo: String(fd.memo || '') });
        if (+fd.cost > 0) { INV.expenses = INV.expenses || []; INV.expenses.push({ id: uid(), at: Date.now(), date: fd.date || today(), cat: '택배비', amount: +fd.cost, payId: '', vat: false, memo: `보관 판매 발송 ${fd.courier} ${String(fd.no).trim()} (${+fd.n || 1}개)` }); }
        await invSave(); IS.msg = '보관 판매 발송을 등록했어요'; renderInv();
      }, '발송 등록');
    }
  }
  renderInv();
}
