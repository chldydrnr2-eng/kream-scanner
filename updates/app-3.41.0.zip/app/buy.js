'use strict';
/* 킥스캔 3.32 — 이용권 결제 화면
   플랜(Basic · PRO · VIP) 비교 → 이용 기간(30 · 180 · 365일) → 주문서 확인 → 결제하기.
   결제하기: 프로그램 안 토스페이먼츠 결제창(3.33). 결제 준비가 안 된 판이면 예전 '구매 링크' · 카카오 문의로 안내해요.
   3.36.6(점검 D): 플랜을 바꿔 사면 남은 기간을 가격 비율로 바꿔 계산(서버 ks-pay 와 같은 식) · 낮은 플랜은 지금 이용권이 끝난 뒤에 ·
   가상계좌 입금 계좌 표시 · 상황별 맨 위 문구 · 사업자 정보와 약관 링크(판매자 공개 설정 shop.json) */
const BUY_PLANS = [
  { k: 'basic', t: 'Basic', d: '크림 자동화 · 재고관리', p: 17900 },
  { k: 'vip', t: 'VIP', d: 'Basic + PRO 전부', p: 44900, best: true },
  { k: 'pro', t: 'PRO', d: '소싱 자동화 기능', p: 34900 }
];
const BUY_FEAT = [   // [기능, basic, vip, pro, 새 기능]
  ['나이키 · 무신사 주문내역 관리', 1, 1, 1, 1],
  ['크림 기능 전부 (입찰 · 자동 입찰 · 보관 · 매크로 · 발송 · 정산)', 1, 1, 0],
  ['재고관리 전부 (입출고 · 입고예정 · 우선출고 · 반품 · 장부 · 부가세)', 1, 1, 0],
  ['크림 / 포이즌 동시 분석', 0, 1, 1],
  ['소싱 (랭킹 분석 · 예약 · 재고 입고)', 0, 1, 1, 1],
  ['쇼핑몰 26곳 재고조회 · 가격 · 재입고 추적', 0, 1, 1, 1],
  ['무신사 후기 자동 작성', 0, 1, 1],
  ['발매 정보 · 내 상품 시세 · 마진', 0, 1, 1]
];
const BUY_DAYS = [[30, 0], [180, 5], [365, 10]];
const BUY = { plan: 'vip', days: 30, agree: false, st: null, wait: null };
const buyPrice = (plan, days) => { const P = BUY_PLANS.find(p => p.k === plan); const disc = (BUY_DAYS.find(d => d[0] === days) || [0, 0])[1]; return Math.floor(P.p * buyMon(days) * (1 - disc / 100) / 100) * 100; };
const buyMon = d => d >= 365 ? 12 : d / 30;   // 365일 = 12개월 값
const buyLeft = st => { if (!st || !st.expires) return null; const d = Math.ceil((new Date(st.expires) - Date.now()) / 864e5); return isNaN(d) ? null : d; };
// 플랜 이름 (서버 값은 소문자 basic · pro · vip) → 화면 표기
const buyPlanName = p => { const c = String(p || '').toLowerCase(); const hit = BUY_PLANS.find(x => c.includes(x.k)); return hit ? hit.t : (p ? String(p) : '이용권'); };
const buyPlanKey = p => { const c = String(p || '').toLowerCase(); const hit = BUY_PLANS.find(x => c.includes(x.k)); return hit ? hit.k : (c ? 'vip' : ''); };   // 모르는 이름은 VIP처럼 (서버 규칙과 같게)
const buyFmtD = d => { const x = d instanceof Date ? d : new Date(d); return isNaN(x) ? '' : `${x.getFullYear()}.${x.getMonth() + 1}.${x.getDate()}`; };

// ---- 판매자 공개 설정(shop.json) — 앱이 켤 때 읽어서 window.KS_SHOP 에 둬요. 비어 있는 칸은 화면에 안 보여요 ----
const buyHttps = u => /^https:\/\/\S+$/i.test(String(u || '').trim()) ? String(u).trim() : '';
function shopGet(k) {
  const H = (typeof window !== 'undefined' && window.KS_SHOP) || {}, s = (typeof S !== 'undefined' && S) || {};
  if (k === 'kakao') return buyHttps(H.kakao) || buyHttps(s.kakaoUrl);
  if (k === 'terms') return buyHttps(H.terms) || buyHttps(s.termsUrl);
  if (k === 'buy') return buyHttps(s.buyUrl);
  return buyHttps(H[k]);
}
// 사업자 정보 · 약관 링크 줄 (구매창 아래)
function shopFootHtml() {
  const B = ((typeof window !== 'undefined' && window.KS_SHOP) || {}).biz || {};
  const f = [['상호', B.name], ['대표', B.ceo], ['사업자등록번호', B.regNo], ['통신판매업 신고', B.mailOrderNo], ['주소', B.addr], ['전화', B.tel], ['이메일', B.email]].filter(x => String(x[1] || '').trim());
  const links = [['terms', '이용약관'], ['privacy', '개인정보처리방침'], ['refund', '환불 규정']].filter(x => shopGet(x[0]));
  if (!f.length && !links.length) return '';
  return `<footer class="buy-biz">${f.length ? `<p>${f.map(x => `<span>${x[0]} ${esc(x[1])}</span>`).join('')}</p>` : ''}${links.length ? `<p class="buy-biz-l">${links.map(x => `<a href="#" data-blink="${x[0]}">${x[1]}</a>`).join('')}</p>` : ''}</footer>`;
}

// ---- 계산: 서버(ks-pay grant)와 같은 식 ----
// 같은 플랜 = 남은 기간 뒤에 이어 붙여요 · 비싼 플랜으로 바꾸면 남은 기간 × (지금 플랜 가격 ÷ 새 플랜 가격)을 오늘부터 다시 세고 산 기간을 더해요
// 싼 플랜(예: VIP → Basic)은 지금 이용권이 끝난 뒤에 살 수 있어요
function buyCalc(st, plan, days) {
  const now = Date.now(), P30 = k => (BUY_PLANS.find(p => p.k === k) || BUY_PLANS[1]).p;
  const cur = st && st.plan ? buyPlanKey(st.plan) : '', exp = st && st.expires ? new Date(st.expires).getTime() : 0;
  const left = cur && exp > now ? exp - now : 0;
  if (!left) return { kind: cur && exp ? '재구매' : '신규 구매', expires: new Date(now + days * 864e5) };
  if (cur === plan) return { kind: '기간 연장', expires: new Date(exp + days * 864e5), leftDays: Math.ceil(left / 864e5) };
  if (P30(plan) < P30(cur)) return { kind: '구매 불가', block: `지금 이용권(${buyPlanName(cur)})이 끝난 뒤에 살 수 있어요 (${buyFmtD(exp)}까지)`, leftDays: Math.ceil(left / 864e5) };
  const conv = left * P30(cur) / P30(plan);
  return { kind: plan === 'vip' ? '업그레이드' : '플랜 변경', cur, expires: new Date(now + conv + days * 864e5), leftDays: Math.ceil(left / 864e5), convDays: Math.round(conv / 864e5) };
}
function buyKind(st) { return buyCalc(st, BUY.plan, BUY.days).kind; }
// 맨 위 문구: 상황(이용 중 · 기간 끝남 · 이용권 없음 · PC 수 초과 · 인터넷 안 됨)에 맞게
function buyTopHtml(st) {
  const left = buyLeft(st), nm = st && st.plan ? buyPlanName(st.plan) : '';
  if (!st || st.state === 'off') return { on: false, h: '플랜과 이용 기간을 고르세요' };
  if (st.state === 'ok' || st.state === 'grace') return { on: true, h: `현재 <b>${esc(nm || '이용권')}</b> 이용 중${left != null ? ` · 잔여 <b>${Math.max(0, left)}일</b> (${buyFmtD(st.expires)}까지)` : ''}` };
  if (st.state === 'offline') return { on: false, h: '인터넷 연결을 확인해 주세요 — 연결되면 결제할 수 있어요' };
  if (st.state === 'blocked' && st.reason === 'device_limit') return { on: false, h: '이 계정은 다른 PC에서 쓰고 있어요 — <b>이용권을 새로 사지 않아도 돼요.</b> 로그인 화면의 \'다른 PC 등록 해제하고 여기서 쓰기\'를 눌러 주세요' };
  if (st.state === 'blocked' && (st.reason === 'expired' || (left != null && left <= 0))) return { on: false, h: `${nm ? `<b>${esc(nm)}</b> ` : ''}이용 기간이 끝났어요${st.expires ? ` (${buyFmtD(st.expires)})` : ''} — 결제하면 바로 다시 쓸 수 있어요` };
  if (st.state === 'blocked') return { on: false, h: '아직 이용권이 없어요 — 플랜과 기간을 고르고 결제하면 바로 쓸 수 있어요' };
  return { on: false, h: '로그인하면 이용권을 살 수 있어요' };
}
function buyWaitHtml() {
  const w = BUY.wait; if (!w) return '';
  return `<div class="buy-wait" role="status"><b>가상계좌 입금을 기다리고 있어요</b><dl>${w.account ? `<dt>입금 계좌</dt><dd>${esc((w.bank ? w.bank + ' ' : '') + w.account)}</dd>` : ''}<dt>입금할 금액</dt><dd>${won(w.amount)}</dd>${w.dueText ? `<dt>입금 기한</dt><dd>${esc(w.dueText)}</dd>` : ''}</dl><p>입금하면 이용권이 자동으로 반영돼요.${w.account ? '' : ' 계좌는 토스페이먼츠 안내 문자 · 메일에서 확인해 주세요.'}</p></div>`;
}
function buyRender() {
  const M = document.getElementById('buyModal'); if (!M) return;
  const st = BUY.st, P = BUY_PLANS.find(p => p.k === BUY.plan), amt = buyPrice(BUY.plan, BUY.days);
  const top = buyTopHtml(st), C = buyCalc(st, BUY.plan, BUY.days);
  const ck = v => v ? '<span class="b-ok" aria-label="포함">✓</span>' : '<span class="b-no" aria-label="미포함">✕</span>';
  const tl = ['terms', 'privacy', 'refund'].filter(k => shopGet(k));
  const kakao = shopGet('kakao'), legacyBuy = shopGet('buy');
  const hint = BUY.ready ? '토스페이먼츠 결제창에서 결제해요. 결제가 끝나면 이용권이 바로 반영돼요.' : legacyBuy ? '결제 페이지가 열려요. 결제가 끝나면 이 창에서 \'이용권 다시 확인\'을 누르세요.' : kakao ? '결제하기를 누르면 카카오 문의로 연결돼요.' : '지금은 결제를 준비하고 있어요. 잠시 뒤에 다시 열어 주세요.';
  let warn = '';
  if (C.block) warn = `<p class="buy-warn bad">${esc(C.block)}</p>`;
  else if (C.convDays != null) warn = `<p class="buy-warn">지금 ${esc(buyPlanName(C.cur))} ${C.leftDays}일이 남았어요. 결제하면 남은 기간을 가격 비율로 바꿔 <b>${P.t} ${C.convDays}일</b>로 계산하고, 산 ${BUY.days}일을 더해요.${C.cur === 'basic' && BUY.plan === 'pro' ? ' PRO에는 크림 · 재고관리 기능이 없어요.' : ''}</p>`;
  M.querySelector('.buy-body').innerHTML = `
    <div class="buy-main">
      <div class="buy-cur ${top.on ? '' : 'off'}">${top.h}</div>
      <div class="buy-note"><b>Basic과 PRO는 제공 기능이 다른 이용권이에요.</b> 크림 자동화 · 재고관리는 Basic, 소싱(분석 · 재고조회 · 추적)은 PRO에 들어 있어요. 둘 다 쓰려면 VIP를 고르세요.</div>
      <div class="buy-tbl"><table><thead><tr><th class="l"><b>플랜 선택 · 기능 비교</b><small>플랜을 눌러 고르세요</small></th>${BUY_PLANS.map(p => `<th class="b-col${BUY.plan === p.k ? ' on' : ''}" data-bp="${p.k}" tabindex="0" role="button" aria-pressed="${BUY.plan === p.k}"><span class="b-name">${p.t}${p.best ? ' <i>추천</i>' : ''}</span><small>${esc(p.d)}</small><b class="b-pr">${won(p.p)}</b><small>/ 30일</small><span class="b-pick">${BUY.plan === p.k ? '선택됨' : '선택하기'}</span></th>`).join('')}</tr></thead>
        <tbody>${BUY_FEAT.map(f => `<tr><td class="l">${esc(f[0])}${f[4] ? ' <em class="b-new">신규</em>' : ''}</td>${['basic', 'vip', 'pro'].map((k, i) => `<td class="${BUY.plan === k ? 'on' : ''}">${ck(f[i + 1])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
      <h3 class="buy-h">이용 기간</h3>
      <div class="buy-days">${BUY_DAYS.map(([d, disc]) => `<button type="button" class="${BUY.days === d ? 'on' : ''}" data-bd="${d}"><span>${d}일</span><em class="${disc ? 'sale' : ''}">${disc ? disc + '% 할인' : '할인 없음'}</em><b>${won(buyPrice(BUY.plan, d))}</b>${disc ? `<small>한 달 ${won(Math.round(buyPrice(BUY.plan, d) / buyMon(d) / 100) * 100)}</small>` : '<small>&nbsp;</small>'}</button>`).join('')}</div>
      <div class="buy-rule"><b>결제 기준</b><ul><li>결제가 확인되면 바로 이용권이 반영돼요.</li><li>같은 플랜을 연장하면 지금 남은 기간 뒤에 이어서 붙어요.</li><li>더 높은 플랜으로 바꾸면 남은 기간을 가격 비율로 바꿔서 새 플랜 기간에 더해요. (예: Basic 30일 남음 → VIP 약 12일 + 산 기간)</li><li>더 낮은 플랜은 지금 이용권이 끝난 뒤에 살 수 있어요.</li><li>한 계정으로 등록한 PC에서 쓸 수 있어요 (PC를 바꾸면 설정 → 이 PC 등록 해제).</li></ul></div>
      ${shopFootHtml()}
    </div>
    <aside class="buy-side"><h3>주문서</h3>
      <dl><dt>상품명</dt><dd>${P.t} 이용권</dd><dt>결제 유형</dt><dd>${C.kind}</dd><dt>이용 기간</dt><dd>${BUY.days}일</dd>${C.expires ? `<dt>예상 만료일</dt><dd>${buyFmtD(C.expires)}</dd>` : ''}${st && st.email ? `<dt>계정</dt><dd>${esc(st.email)}</dd>` : ''}</dl>
      ${warn}${buyWaitHtml()}<div class="buy-amt"><span>결제 금액</span><b>${won(amt)}</b></div>
      <label class="chk buy-agree"><input type="checkbox" id="buyAgree"${BUY.agree ? ' checked' : ''}><span>이용약관, 개인정보 수집 및 이용, 디지털콘텐츠 제공 개시 및 환불 규정을 확인했어요.${tl.length ? ' ' + tl.map(k => `<a href="#" data-blink="${k}">${{ terms: '약관', privacy: '개인정보', refund: '환불 규정' }[k]} 보기</a>`).join(' · ') : ''}</span></label>
      <button type="button" class="primary buy-go" id="buyGo"${BUY.agree && !C.block ? '' : ' disabled'}>${won(amt)} 결제하기</button>
      <p class="hint" id="buyMsg">${hint}</p>
      <button type="button" class="ghost tiny" id="buyRecheck">이용권 다시 확인</button>
    </aside>`;
}
function buyOpenUrl(u) { try { if (window.kcApp && window.kcApp.openExt) return window.kcApp.openExt(u); } catch (e) {} try { (typeof chrome !== 'undefined' && chrome.tabs ? chrome.tabs.create({ url: u }) : window.open(u, '_blank')); } catch (e) {} }
async function buyOpen(plan) {
  let M = document.getElementById('buyModal');
  if (!M) {
    M = document.createElement('div'); M.id = 'buyModal'; M.className = 'buy-dim'; M.hidden = true;
    M.innerHTML = `<div class="buy-box" role="dialog" aria-modal="true" aria-labelledby="buyTitle"><div class="buy-head"><span class="buy-ico">${typeof ico === 'function' ? ico('receipt') : ''}</span><div><h2 id="buyTitle">이용권 결제</h2><p>플랜과 이용 기간을 고르세요</p></div><button type="button" class="buy-x" aria-label="닫기">✕</button></div><div class="buy-body"></div></div>`;
    document.body.appendChild(M);
    M.addEventListener('click', async e => {
      if (e.target === M || e.target.closest('.buy-x')) return buyClose();
      const bp = e.target.closest('[data-bp]'); if (bp) { BUY.plan = bp.dataset.bp; return buyRender(); }
      const bd = e.target.closest('[data-bd]'); if (bd) { BUY.days = +bd.dataset.bd; return buyRender(); }
      const bl = e.target.closest('[data-blink]'); if (bl) { e.preventDefault(); const u = shopGet(bl.dataset.blink); if (u) buyOpenUrl(u); return; }
      if (e.target.id === 'buyAgree') { BUY.agree = e.target.checked; const g = document.getElementById('buyGo'); if (g) g.disabled = !BUY.agree || !!buyCalc(BUY.st, BUY.plan, BUY.days).block; return; }
      if (e.target.id === 'buyRecheck') {
        const m = document.getElementById('buyMsg');
        try {
          if (window.kcApp && window.kcApp.lic) {
            m.textContent = '확인 중…'; const before = BUY.st && BUY.st.expires; BUY.st = await window.kcApp.lic.check();
            if (BUY.wait && BUY.st && BUY.st.state === 'ok' && BUY.st.expires !== before) BUY.wait = null;   // 입금이 반영됐어요
            buyRender(); document.getElementById('buyMsg').textContent = BUY.st && BUY.st.state === 'ok' ? '이용권이 확인됐어요.' : BUY.st && BUY.st.state === 'offline' ? '인터넷 연결을 확인해 주세요.' : '아직 반영 전이에요. 잠시 뒤 다시 눌러 주세요.';
          } else m.textContent = '프로그램에서만 확인돼요.';
        } catch (er) { m.textContent = '확인하지 못했어요: ' + (er.message || er); }
        return;
      }
      if (e.target.closest('#buyGo')) {
        if (!BUY.agree) return;
        const P = BUY_PLANS.find(p => p.k === BUY.plan), amt = buyPrice(BUY.plan, BUY.days);
        const C = buyCalc(BUY.st, BUY.plan, BUY.days); if (C.block) { document.getElementById('buyMsg').textContent = C.block; return; }
        let ready = false; try { ready = !!(window.kcApp && window.kcApp.lic && window.kcApp.lic.payReady && await window.kcApp.lic.payReady()); } catch (er) {}
        if (ready) {   // 3.33: 프로그램 안 토스페이먼츠 결제창
          const g = document.getElementById('buyGo'), m = document.getElementById('buyMsg'); g.disabled = true; m.textContent = '결제 창을 여는 중…';
          let r; try { r = await window.kcApp.lic.pay(BUY.plan, BUY.days); } catch (er) { r = { ok: false, message: er.message || String(er) }; }
          try { BUY.st = await window.kcApp.lic.state(); } catch (er) {}
          if (r && r.ok && r.status === 'done') { BUY.wait = null; buyRender(); document.getElementById('buyMsg').innerHTML = '<b class="pos">결제가 완료돼서 이용권이 반영됐어요.</b>'; }
          else if (r && r.ok && r.status === 'waiting') { BUY.wait = { bank: r.bank || '', account: r.account || '', amount: r.amount || amt, dueText: r.dueText || '' }; buyRender(); document.getElementById('buyMsg').textContent = '가상계좌로 입금하면 이용권이 자동으로 반영돼요. 입금한 뒤 \'이용권 다시 확인\'을 눌러도 돼요.'; }
          else { buyRender(); document.getElementById('buyMsg').textContent = (r && r.cancel) ? '결제를 취소했어요.' : '결제가 끝나지 않았어요' + (r && r.message ? ': ' + r.message : ''); }
          return;
        }
        const legacyBuy = shopGet('buy'), kakao = shopGet('kakao');
        if (legacyBuy) { const u = new URL(legacyBuy); u.searchParams.set('plan', P.t); u.searchParams.set('days', BUY.days); u.searchParams.set('amount', amt); buyOpenUrl(u.toString()); document.getElementById('buyMsg').textContent = '결제 페이지를 열었어요. 결제가 끝나면 \'이용권 다시 확인\'을 누르세요.'; }
        else if (kakao) { buyOpenUrl(kakao); document.getElementById('buyMsg').textContent = `카카오 문의를 열었어요. '${P.t} ${BUY.days}일 (${won(amt)})'로 문의해 주세요.`; }
        else document.getElementById('buyMsg').textContent = '지금은 결제할 수 없어요. 잠시 뒤에 다시 해 주세요.';
      }
    });
    M.addEventListener('keydown', e => { if (e.key === 'Escape') buyClose(); const bp = e.target.closest && e.target.closest('[data-bp]'); if (bp && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); BUY.plan = bp.dataset.bp; buyRender(); } });
  }
  try { BUY.st = window.kcApp && window.kcApp.lic ? await window.kcApp.lic.state() : null; } catch (e) { BUY.st = null; }
  try { BUY.ready = !!(window.kcApp && window.kcApp.lic && window.kcApp.lic.payReady && await window.kcApp.lic.payReady()); } catch (e) { BUY.ready = false; }
  if (plan && BUY_PLANS.some(p => p.k === plan)) BUY.plan = plan;   // 3.33: 잠긴 메뉴에서 연 경우 그 플랜을 골라 둬요
  else if (BUY.st && BUY.st.plan) { const hit = buyPlanKey(BUY.st.plan); if (hit) BUY.plan = hit; }
  buyRender(); M.hidden = false; document.body.classList.add('buy-on'); setTimeout(() => { try { M.querySelector('.buy-x').focus(); } catch (e) {} }, 30);
}
function buyClose() { const M = document.getElementById('buyModal'); if (M) M.hidden = true; document.body.classList.remove('buy-on'); }
