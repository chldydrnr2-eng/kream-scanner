'use strict';
/* 킥스캔 개선판 1-5 · 1-7 — 재고 시세(크림 · 포이즌) · 예상 실수령 · 예상 손익 · 추천 판매처 · 수익 알림
   시세는 '크림 / 포이즌 동시 분석' 기록(dualHist)을 같이 써요 — 거기서 조회한 품번은 재고 화면에도 바로 보여요.
   상품 · 재고 [시세 갱신]은 재고 있는 품번을 하나씩 동시 분석으로 돌려요(12시간 안에 본 품번은 건너뛰어요). */
const MKT_FRESH = 6 * 3600e3;   // 11/22: 줍픽처럼 6시간에 한 번
const MKT_LABEL = { kream: '크림', poizon: '포이즌' };

function mktEntry(it) {
  if (typeof dualHist === 'undefined' || !it || !it.code) return null;
  const k = ckey(it.code);
  return dualHist.find(h => String((h.kream && h.kream.code) || h.q || '').split('/').some(x => ckey(x) === k) || (it.pid && h.kream && String(h.kream.pid) === String(it.pid))) || null;
}
// 사이즈 하나의 시세 → { kSell 크림 예상 판매가, kNet 크림 정산, pz 포이즌 가격, pzNet 포이즌 정산, best, net, n7, at }
function mktSize(it, size) {
  const h = mktEntry(it); if (!h) return null;
  const r = (h.rows || []).find(x => ckey(x.size) === ckey(size)); if (!r) return null;
  const kNet = r.settle != null ? +r.settle : null, pzNet = r.pz ? r.pz - (typeof pzFee === 'function' ? pzFee(r.pz) : 0) : null;
  if (kNet == null && pzNet == null) return null;
  const best = pzNet != null && (kNet == null || pzNet > kNet) ? 'poizon' : 'kream';
  return { at: h.at, kSell: r.sell ?? r.minAsk ?? null, kNet, pz: r.pz || null, pzNet, best, net: best === 'poizon' ? pzNet : kNet, n7: r.n7 || 0 };
}
// 상품 하나의 재고 전체 → { qty 시세 있는 수량, net 예상 실수령 합, profit 예상 손익 합, best 더 남는 쪽, rows }
function mktItem(it, C) {
  const st = itemStock(it, C); let qty = 0, net = 0, profit = 0; const by = {}, rows = [];
  for (const [size, x] of Object.entries(st.by || {})) {
    if (!x || !(x.qty > 0)) continue;
    const m = mktSize(it, size), cost = x.value / x.qty;
    rows.push({ size, qty: x.qty, cost, m, unit: m ? m.net - cost : null });
    if (!m) continue;
    qty += x.qty; net += m.net * x.qty; profit += (m.net - cost) * x.qty; by[m.best] = (by[m.best] || 0) + (m.net - cost) * x.qty;
  }
  const h = mktEntry(it);
  return { qty, net, profit, rows, at: h ? h.at : 0, best: qty ? Object.keys(by).sort((a, b) => by[b] - by[a])[0] : null };
}
const mktAgo = t => { if (!t) return ''; const m = Math.round((Date.now() - t) / 60000); return m < 60 ? `${Math.max(1, m)}분 전` : m < 1440 ? `${Math.round(m / 60)}시간 전` : `${Math.round(m / 1440)}일 전`; };

// 상품 상세 패널의 시세 칸
function mktBox(it, C) {
  const M = mktItem(it, C), a = +it.alertWon || 0;
  const alert = `<label class="mkt-al">개당 남는 돈이 <input type="number" class="mini" style="width:96px" min="0" step="1000" data-k="mktAlert" data-id="${it.id}" value="${a || ''}" placeholder="예: 30000">원 이상이면 알림</label>`;
  const btn = `<button type="button" class="ghost tiny" data-a="mktOne" data-id="${it.id}">이 상품 시세 갱신</button>`;
  if (!M.at) return `<div class="box"><h3>시세 · 예상 손익</h3><p class="hint">아직 이 품번 시세가 없어요. 위의 <b>시세 갱신</b>이나 ${btn}을 누르면 크림 · 포이즌에서 가져와요.</p>${alert}</div>`;
  const R = M.rows.sort((x, y) => sizeSort(x.size, y.size)).map(r => { const m = r.m; return `<tr><td class="l"><b>${esc(r.size)}</b></td><td>${r.qty}</td><td>${won(r.cost)}</td><td>${m && m.kSell ? won(m.kSell) : '–'}</td><td>${m && m.kNet != null ? won(m.kNet) : '–'}</td><td>${m && m.pz ? won(m.pz) : '–'}</td><td>${m && m.pzNet != null ? won(m.pzNet) : '–'}</td><td class="l">${m ? `<span class="pill ${m.best === 'poizon' ? 'acc' : 'ok'}">${MKT_LABEL[m.best]}</span>` : '<span class="small">시세 없음</span>'}</td><td class="${r.unit > 0 ? 'pos' : r.unit < 0 ? 'neg' : ''}">${r.unit == null ? '–' : wonS(Math.round(r.unit))}${a && r.unit >= a ? ' <span class="pill warn">알림</span>' : ''}</td></tr>`; }).join('');
  return `<div class="box"><h3>시세 · 예상 손익 <span class="small">${mktAgo(M.at)} 조회</span></h3>
    <table class="srct"><thead><tr><th class="l">사이즈</th><th>재고</th><th>평균 매입가</th><th>크림 예상가</th><th>크림 정산</th><th>포이즌</th><th>포이즌 정산</th><th class="l">추천</th><th>개당 손익</th></tr></thead><tbody>${R || '<tr><td colspan="9" class="small">재고가 없어요</td></tr>'}</tbody></table>
    <div class="toolbar">${alert}${btn}</div><p class="hint">정산은 판매가에서 수수료를 뺀 금액이에요(포이즌 수수료는 동시 분석 설정값). 추천은 더 많이 남는 쪽이에요.</p></div>`;
}

// 재고 있는 품번 시세를 차례로 갱신 (동시 분석과 같은 방식 · 크림 창이 잠깐 쓰여요)
async function invMktRefresh(ids) {
  if (typeof runDual !== 'function') return;
  if (typeof canUse === 'function' && !canUse('dual')) { IS.msg = '시세 갱신은 크림 / 포이즌 동시 분석을 쓰는 이용권에서 돼요'; return renderInv(); }
  if (IS.mkt) { IS.mkt.stop = true; IS.msg = '시세 갱신을 멈추는 중이에요 (지금 품번까지만 해요)'; return renderInv(); }
  const C = invCalc();
  const L = ids ? INV.items.filter(it => ids.includes(it.id) && it.code) : INV.items.filter(it => { if (!it.code || !(itemStock(it, C).qty > 0)) return false; const h = mktEntry(it); return !(h && Date.now() - h.at < MKT_FRESH); });
  if (!L.length) { IS.msg = '재고 품번 시세가 모두 12시간 안에 조회한 거예요'; return renderInv(); }
  IS.mkt = { i: 0, n: L.length, stop: false }; let ok = 0;
  try {
    for (const it of L) {
      if (IS.mkt.stop) break;
      IS.mkt.i++; IS.mkt.cur = it.code; IS.msg = `시세 갱신 중 ${IS.mkt.i}/${L.length} — ${it.code} (크림 창을 닫지 마세요)`; renderInv();
      while (XS.busy) await sleep(1000);
      const before = (mktEntry(it) || {}).at || 0;
      XS.dualQ = it.code; XS.dualCost = '';
      await runDual();
      if (((mktEntry(it) || {}).at || 0) > before) ok++;
      await sleep(600);
    }
  } finally {
    const stopped = IS.mkt && IS.mkt.stop; IS.mkt = null;
    IS.msg = `시세 갱신 ${stopped ? '멈춤' : '끝'} — ${ok}/${L.length}개 품번 받았어요${ok < L.length ? ' (못 받은 건 크림 · 포이즌에서 품번을 못 찾았거나 로그인이 풀린 거예요)' : ''}`;
    await invMktCheck(); renderInv();
  }
}

// 수익 알림: 개당 남는 돈이 정한 금액 이상인 사이즈 (재고 있는 것만)
function mktHits(C) {
  const H = [];
  for (const it of INV.items) {
    const a = +it.alertWon || 0; if (!a) continue;
    for (const r of mktItem(it, C).rows) if (r.m && r.unit >= a) H.push({ it, size: r.size, unit: Math.round(r.unit), where: r.m.best, at: r.m.at });
  }
  return H;
}
// 새 시세가 들어올 때(동시 분석 · 시세 갱신 뒤) 한 번씩 알림 종에 쌓아요 — 같은 시세로는 다시 안 울려요
async function invMktCheck() {
  if (typeof INV === 'undefined' || !INV.items) return;
  const H = mktHits(invCalc()); let ch = false;
  for (const h of H) {
    h.it.alertSeen = h.it.alertSeen || {};
    if (h.it.alertSeen[h.size] === h.at) continue;
    h.it.alertSeen[h.size] = h.at; ch = true;
    if (typeof notiAdd === 'function') notiAdd(`수익 알림 — ${itName(h.it)} ${h.size}`, `${MKT_LABEL[h.where]}에 팔면 개당 ${wonS(h.unit)} 남아요 (알림 기준 ${won(h.it.alertWon)})`);
  }
  if (ch) await invSave();
}
