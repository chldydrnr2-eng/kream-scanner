/* 킥스캔 — 수익 알림 (줍픽 상품 창 시세 차트 [수익 알림] · 프로필 설정 › 수익 알림 목록)
   상품 창(소싱 상세)에서 사이즈 · 판매처 · 조건(수익 N원 이상 / 판매가 N원 이상 / 판매가 N원 이하)을 정해 두면
   3시간마다 KREAM 최저 판매가를 확인해서 닿으면 알림 종(+ 윈도우 알림)으로 알려요. 같은 알림은 하루에 한 번만.
   저장: 'profitAlerts' = [{ id, code, pid, name, size, seller, kind: profit|ge|le, value, cost, last, lastAt, firedAt, on }] */
let PA = [];
const PA_KIND = { profit: '수익', ge: '판매가 이상', le: '판매가 이하' };
async function paSave() { try { await store.set('profitAlerts', PA); } catch (e) {} }
function paCondTxt(a) { return a.kind === 'profit' ? `개당 수익 ${won(a.value)} 이상` : a.kind === 'ge' ? `판매가 ${won(a.value)} 이상` : `판매가 ${won(a.value)} 이하`; }
// 상품 창 [수익 알림] — row: 소싱 결과 줄 · C: srcCalcRow 결과
function paOpen(row, C) {
  const sizes = (C && C.sizes && C.sizes.length ? C.sizes : Object.keys((row.kream && row.kream.sizes) || {}).map(size => ({ size }))).map(s => s.size);
  const best = C && (C.rec[0] || C.sizes.find(s => s.best)) || {};
  const cost = best.buy || (C && C.buy) || '';
  invDialog('수익 알림', `<p class="hint">정해 둔 수익 · 가격에 닿으면 알림 종과 윈도우 알림으로 알려요(3시간마다 확인 · 같은 알림은 하루 한 번). 폰 알림은 폰 앱이 나오면 같이 와요.</p>
    <div class="dgrid"><label>상품<input value="${esc(String(row.name || row.code).slice(0, 60))}" readonly></label><label>사이즈<select name="size">${sizes.map(s => opt(s, s, s === best.size)).join('')}</select></label>
    <label>판매처<select name="seller">${opt('kream', 'KREAM')}</select></label><label>조건<select name="kind">${opt('profit', '개당 수익이 이 값 이상')}${opt('ge', '판매가가 이 값 이상')}${opt('le', '판매가가 이 값 이하')}</select></label>
    <label>값 (원)<input type="number" name="value" step="1000" required placeholder="예: 20000"></label><label>매입가 (수익 계산용)<input type="number" name="cost" step="1000" value="${esc(cost)}"></label></div>`, async fd => {
    const value = Math.round(+fd.value || 0); if (!(value > 0)) return '값을 넣어 주세요';
    PA.unshift({ id: uid(), at: Date.now(), code: row.code || '', pid: String(row.pid || (row.kream && row.kream.pid) || ''), name: String(row.name || row.code || '').slice(0, 80), size: fd.size, seller: fd.seller || 'kream', kind: fd.kind, value, cost: +fd.cost || 0, last: null, lastAt: 0, firedAt: 0, on: true });
    await paSave(); paPaint();
    const m = document.getElementById('srDetMsg'); if (m) m.textContent = `수익 알림을 걸었어요 — ${fd.size} · ${paCondTxt(PA[0])}`;
  }, '알림 걸기');
}
// 3시간마다 확인
async function paCheck(force) {
  if (!PA.some(a => a.on) || typeof collectOne !== 'function' || !(window.kcApp && window.kcApp.ops)) return;
  if (!force && typeof SE !== 'undefined' && SE.busy) return;
  const byPid = new Map(); for (const a of PA.filter(x => x.on && x.seller === 'kream')) { let pid = a.pid; if (!pid && a.code && typeof kreamByCode === 'function') { const f = await kreamByCode(a.code).catch(() => null); pid = a.pid = f && f.pid ? String(f.pid) : ''; } if (pid) (byPid.get(pid) || byPid.set(pid, []).get(pid)).push(a); }
  for (const [pid, L] of byPid) {
    const p = { id: 'pa', pid, raw: null };
    try { await collectOne(p, { days: 14, maxPages: 2, lite: true }); } catch (e) { continue; }
    for (const a of L) {
      const m = typeof abMarket === 'function' ? abMarket(p.raw, a.size, false) : {}; const price = m.minAsk;
      a.lastAt = Date.now(); if (!price) { a.last = null; continue; }
      const net = price - (typeof feeOf === 'function' ? feeOf(price) : 0) - (+((typeof S !== 'undefined' && S.ship) || 0)) - (+a.cost || 0);
      a.last = a.kind === 'profit' ? net : price;
      const hit = a.kind === 'profit' ? net >= a.value : a.kind === 'ge' ? price >= a.value : price <= a.value;
      if (hit && Date.now() - (a.firedAt || 0) > 20 * 3600e3) {
        a.firedAt = Date.now();
        const t = `수익 알림 — ${a.name.slice(0, 30)} ${a.size}`, msg = `KREAM 최저 판매가 ${won(price)}${a.kind === 'profit' ? ` · 개당 수익 ${won(net)}` : ''} (${paCondTxt(a)})`;
        try { if (typeof notiAdd1 === 'function') await notiAdd1(t, msg); notiBadge(); } catch (e) {}
        try { chrome.notifications.create('pa-' + a.id + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: t, message: msg }); } catch (e) {}
      }
    }
    await sleep(1500 + Math.random() * 1500);
  }
  await paSave(); paPaint();
}
// 설정 › 판매 설정 아래 '수익 알림' 목록 (줍픽 프로필 설정 › 수익 알림)
function paPaint() {
  const box = document.getElementById('paBox'); if (!box) return;
  box.innerHTML = `<div class="st-hrow"><h3 class="st-h">수익 알림 <i class="se-q" title="상품 창(소싱 결과 상세)의 [수익 알림]으로 걸어요">?</i></h3><button type="button" class="ghost small" id="paNow">지금 확인</button></div>
  <div class="st-card"><div class="tbl"><table class="main"><thead><tr><th class="l">등록일</th><th class="l">상품</th><th class="l">사이즈</th><th class="l">판매처</th><th class="l">조건</th><th>마지막 값</th><th class="l">마지막 알림</th><th></th></tr></thead><tbody>
  ${PA.map(a => `<tr><td class="l">${new Date(a.at).toLocaleDateString('ko-KR')}</td><td class="l">${esc(a.name)}<div class="small mono">${esc(a.code)}</div></td><td class="l">${esc(a.size)}</td><td class="l">KREAM</td><td class="l">${esc(paCondTxt(a))}</td><td>${a.last != null ? won(a.last) : '–'}${a.lastAt ? `<div class="small">${new Date(a.lastAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</div>` : ''}</td><td class="l small">${a.firedAt ? new Date(a.firedAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '–'}</td><td><button type="button" class="ghost tiny" data-pa-on="${a.id}">${a.on ? '끄기' : '켜기'}</button><button type="button" class="x" data-pa-del="${a.id}" aria-label="삭제">×</button></td></tr>`).join('') || '<tr><td colspan="8" class="empty">상품 창의 [수익 알림]으로 걸어요 — 정해 둔 수익 · 가격에 닿으면 알려 드려요</td></tr>'}
  </tbody></table></div></div>`;
}
(function paWire() {
  // 소싱 상세 창 버튼 줄에 [수익 알림]
  const add = () => {
    const bar = document.querySelector('[data-srfav2]'); if (!bar || bar.parentElement.querySelector('[data-pa-open]')) return;
    bar.insertAdjacentHTML('afterend', '<button type="button" class="ghost" data-pa-open title="정해 둔 수익 · 가격에 닿으면 알려 드려요">수익 알림</button>');
  };
  new MutationObserver(() => add()).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('click', async e => {
    if (e.target.closest('[data-pa-open]')) {
      const id = window.srOpenId || (document.querySelector('tr.sr-on') || {}).dataset?.srid;
      const row = typeof SE !== 'undefined' && SE.rows ? (SE.rows.find(r => r.id === id) || null) : null;
      if (!row) { const m = document.getElementById('srDetMsg'); if (m) m.textContent = '상품을 다시 열고 눌러 주세요'; return; }
      let C = null; try { C = srcCalcRow(row, await seCalcCfg(), seCalcEnv()); } catch (x) {}
      return paOpen(row, C);
    }
    const d = e.target.closest('[data-pa-del]'); if (d) { PA = PA.filter(a => a.id !== d.dataset.paDel); await paSave(); return paPaint(); }
    const o = e.target.closest('[data-pa-on]'); if (o) { const a = PA.find(x => x.id === o.dataset.paOn); if (a) a.on = !a.on; await paSave(); return paPaint(); }
    if (e.target.closest('#paNow')) { e.target.textContent = '확인 중…'; await paCheck(true).catch(() => {}); return paPaint(); }
  });
})();
(async function paBoot() {
  try { PA = (await store.get('profitAlerts', [])) || []; } catch (e) {}
  const pane = document.querySelector('.st-pane[data-stp="sell"] .st-col'); if (pane && !document.getElementById('paBox')) pane.insertAdjacentHTML('beforeend', '<div id="paBox"></div>');
  paPaint();
  setTimeout(() => paCheck().catch(() => {}), 5 * 60e3);
  setInterval(() => paCheck().catch(() => {}), 3 * 3600e3);
})();
