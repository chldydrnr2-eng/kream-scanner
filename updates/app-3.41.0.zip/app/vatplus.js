/* 킥스캔 — 정산 · 부가세 보강 (줍픽 정산·부가세)
   - 부가세 하위 탭: 판매처 · 지출 · 매입처별 · 카드별(신용카드매출전표등 수령명세서용) · 신고 준비(체크리스트 7가지) · 계산 근거(식 + 실제 숫자)
   - 정산: 안 맞는 거래 경고 띠에 [어느 거래인지 보기 ›] → 일반 판매 › 확인 필요
   fin.js 의 finVatGeneral · finVatPeriod · finVatCalc · finSettleView 를 그대로 쓰고 아래에 덧붙여요. */
const VP_TABS = [['sell', '판매처 · 지출'], ['buy', '매입처별'], ['card', '카드별'], ['prep', '신고 준비'], ['why', '계산 근거']];
function vpGroup(L, key) { const G = new Map(); for (const x of L) { const k = key(x); const g = G.get(k) || { k, n: 0, g: 0, sup: 0, tax: 0 }; g.n++; g.g += x.g; g.sup += x.sup; g.tax += x.tax; G.set(k, g); } return [...G.values()].sort((a, b) => b.g - a.g); }
function vpTable(rows, label) {
  return `<div class="tbl"><table class="main"><thead><tr><th class="l">${label}</th><th>건수</th><th>합계금액</th><th>공급가액</th><th>세액</th></tr></thead><tbody>${rows.map(g => `<tr><td class="l">${esc(g.k || '–')}</td><td>${g.n}건</td><td>${wonS(g.g)}</td><td>${wonS(g.sup)}</td><td>${g.tax ? wonS(g.tax) : '<span class="sub">–</span>'}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">이 기간에 기록이 없어요</td></tr>'}</tbody></table></div>`;
}
function vpExtra(V, R) {
  const P = finVatPeriod(V), D = finVatCalc(R, P), t = IS.vpTab || 'sell';
  const pn = x => { const p = x.r.partnerId ? partnerOf(x.r.partnerId) : null; return p ? p.name : (x.r.partner || x.r.cat || x.r.kind); };
  let body = '';
  if (t === 'sell') body = vpTable(vpGroup(D.L.filter(x => x.side === 'out' || /지출|택배비/.test(x.r.kind)), x => `${x.side === 'out' ? '매출' : '지출'} · ${pn(x)}`), '판매처 · 지출 항목');
  else if (t === 'buy') body = vpTable(vpGroup(D.L.filter(x => x.side === 'in' && /매입/.test(x.r.kind)), pn), '매입처');
  else if (t === 'card') {
    const C = D.L.filter(x => x.side === 'in' && x.tx && (x.r.payId || x.r.pay));
    const name = x => { const p = x.r.payId ? payOf(x.r.payId) : null; return p ? `${p.name}${p.issuer ? ' (' + p.issuer + ')' : ''}${p.last4 ? ' · 끝 ' + p.last4 : ''}` : (x.r.pay || '결제수단 없음'); };
    body = `<p class="hint">신용카드매출전표등 수령명세서에 카드별로 그대로 옮겨 적어요 — 공제되는 매입 · 지출 중 결제수단이 있는 것만이에요.</p>${vpTable(vpGroup(C, name), '결제 카드')}`;
  } else if (t === 'prep') {
    const inAll = D.L.filter(x => x.side === 'in' && /매입/.test(x.r.kind)), inOk = inAll.filter(x => x.tx);
    const zero = D.L.filter(x => x.zero), noProof = D.L.filter(x => x.side === 'in' && /지출/.test(x.r.kind) && !x.tx);
    const unrec = typeof kSales !== 'undefined' && kSales.unrec ? Object.keys(kSales.unrec).length : 0;
    const rets = D.L.filter(x => x.r.kind === '매입반품').length;
    const biz = typeof BIZ !== 'undefined' && BIZ && (BIZ.list || []).find(b => b.id === BIZ.cur);
    const item = (ok, t1, t2) => `<li class="${ok === true ? 'ok' : ok === false ? 'bad' : 'mid'}"><b>${ok === true ? '✓' : ok === false ? '!' : '·'} ${t1}</b><span class="small">${t2}</span></li>`;
    body = `<ol class="vp-prep">
      ${item(inAll.length ? inOk.length === inAll.length : null, '매입 증빙', `사업자 번호로 받은 카드전표 · 현금영수증만 공제돼요 — 이 기간 매입 ${inAll.length}건 중 증빙 있음 ${inOk.length}건. 카드별 탭을 수령명세서에 그대로 옮겨요`)}
      ${item(zero.length ? null : true, '수출 증빙 (영세율)', zero.length ? `영세율 매출 ${zero.length}건 — POIZON 판매자 센터(PC) › 재무 관리 › 수출 통관 자료의 목록통관 파일이 있어야 영세율이 돼요(발송 전에 세금 환급 정보 등록 · 심사 3영업일)` : '영세율 매출이 없어요')}
      ${item(null, '판매 수수료 세금계산서', 'KREAM 판매 수수료는 세금계산서로 매입세액 공제 — KREAM 판매자 센터에서 발행 내역을 확인해요')}
      ${item(unrec ? false : true, '정산과 판매 내역 대조', unrec ? `장부에 못 넣은 KREAM 판매 ${unrec}건 — 일반 판매 › 확인 필요에서 고쳐요` : '판매처 정산과 판매 내역이 맞아요')}
      ${item(noProof.length ? false : true, '지출 증빙', noProof.length ? `증빙 없는 지출 ${noProof.length}건 — 공제에서 빠져요` : '증빙 없는 지출이 없어요')}
      ${item(true, '매입 반품 반영', `이 기간 매입 반품 ${rets}건 — 반품한 날 매입에서 빠져요`)}
      ${item(biz && biz.type ? true : false, '사업자 정보', biz && biz.type ? `${esc(biz.name || '')} · ${esc(biz.type)}` : '재고관리 왼쪽 위 사업자에서 사업자 유형을 넣어 주세요')}
    </ol>`;
  } else {
    const taxOut = D.L.filter(x => x.side === 'out' && x.tx).reduce((s, x) => s + x.g, 0), taxIn = D.L.filter(x => x.side === 'in' && x.tx).reduce((s, x) => s + x.g, 0);
    body = `<div class="vp-why"><p><b>매출세액</b> = 과세 매출 합계 ÷ 11 = ${wonS(taxOut)} ÷ 11 = <b>${won(D.outT)}</b></p>
      <p><b>매입세액</b> = 공제되는 매입 · 수수료 · 지출 합계 ÷ 11 = ${wonS(taxIn)} ÷ 11 = <b>${won(D.inT)}</b></p>
      <p><b>${D.outT - D.inT >= 0 ? '납부 예상' : '환급 예상'}</b> = 매출세액 − 매입세액 = ${won(D.outT)} − ${won(D.inT)} = <b class="${D.outT - D.inT >= 0 ? 'neg' : 'pos'}">${wonS(D.outT - D.inT)}</b></p>
      <p class="small">영세율 매출(POIZON 등 수출)은 세액 0원이고, 증빙 없는 매입 · 지출은 공제에서 빠져요. 합계금액은 부가세 포함 금액이라 ÷ 11 로 세액을 구해요.</p></div>`;
  }
  return `<div class="vp-box"><div class="subtabs">${VP_TABS.map(([k, x]) => `<button type="button" data-a="vpTab" data-v="${k}" aria-selected="${t === k}">${x}</button>`).join('')}</div>${body}</div>`;
}
async function vpAct(a, el) {
  if (a === 'vpTab') { IS.vpTab = el.dataset.v; return renderInv(); }
  if (a === 'vpCheck') { IS.sl = { ...(typeof slS === 'function' ? slS() : {}), tab: 'check' }; return go('sell'); }
}
(function vpWire() {
  if (typeof finVatGeneral === 'function') { const f = finVatGeneral; finVatGeneral = function (V, R, yearSel, bars) { const h = f(V, R, yearSel, bars); try { return h + vpExtra(V, R); } catch (e) { return h; } }; }
  if (typeof finSettleView === 'function') { const f = finSettleView; finSettleView = function (a, b) { const h = f(a, b); return /장부에 없어요/.test(h) ? h.replace(/(<div class="kw-warn">(?:(?!<\/div>).)*장부에 없어요(?:(?!<\/div>).)*<\/div>)/s, '$1<div class="row-btns"><button type="button" class="ghost small" data-a="vpCheck">어느 거래인지 보기 ›</button></div>') : h; }; }
})();
