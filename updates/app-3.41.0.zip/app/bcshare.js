/* 킥스캔 — 공유 바코드 (서버 ks_bc_vote · docs/supabase/barcode-share.sql)
   - 재고에 있는 바코드(바코드 입고 · 폰 스캔)를 공유 바코드 표에 올려요 → 다른 킥스캔 사용자 폰도 처음 찍는 바코드를 바로 찾아요
   - 나이키 공식몰(KR) 상품 정보에 사이즈마다 바코드(GTIN)가 있어요 → 재고 품번 · 폰이 시세를 물어본 품번의 바코드를 미리 채워요
     · 재고 상품의 빈 바코드 칸도 같이 채워요(이미 있는 값은 안 바꿔요)
   - 바코드는 14자리로 맞춰요(매장 UPC-A 12자리 · EAN-13 · GTIN-14 가 같은 상품) */
const BCS = { busy: false, st: null, q: [] };
const BCS_NIKE_DAY = 300, BCS_NIKE_GAP = 2500, BCS_NIKE_AGAIN = 30 * 864e5;
const bcsKey = s => { const d = String(s || '').replace(/\D/g, ''); return d.length >= 8 && d.length <= 14 ? d.padStart(14, '0') : ''; };
const bcsNikeCode = c => /^([A-Z]{2}\d{4}|\d{6})-\d{3}$/.test(String(c || '').trim().toUpperCase());
async function bcsLoad() { if (!BCS.st) BCS.st = Object.assign({ sent: {}, nike: {}, day: '', n: 0, put: 0, nikeN: 0, filled: 0, err: '' }, (await store.get('bcShare', {})) || {}); return BCS.st; }
async function bcsSave() { try { const S = BCS.st, k = Object.keys(S.sent); if (k.length > 20000) for (const x of k.slice(0, k.length - 20000)) delete S.sent[x]; await store.set('bcShare', S); } catch (e) {} }
async function bcsPut(rows) {
  let n = 0;
  for (let i = 0; i < rows.length; i += 300) n += +(await clRpc('ks_bc_put', { p_rows: rows.slice(i, i + 300) })) || 0;
  return n;
}
// 나이키 공식몰 KR 상품 정보 → { 사이즈(KR 표기): GTIN }
async function bcsNike(code) {
  if (!(window.kcApp && window.kcApp.nk)) throw new Error('이 판에서는 나이키 바코드를 못 받아요');
  const r = await window.kcApp.nk.feed(code);
  if (!r || !r.ok) throw new Error((r && r.err) || '나이키에서 못 받았어요');
  return { name: r.name || '', sizes: r.sizes || {} };
}
// 재고 바코드 → 공유 표 (새로 생기거나 바뀐 것만)
function bcsInvRows() {
  const S = BCS.st, rows = [];
  for (const it of (typeof INV !== 'undefined' && INV.items) || []) {
    const code = String(it.code || '').split('/')[0].trim(); if (!code || code.length < 3 || /^TMP|^임시/i.test(code)) continue;
    for (const [size, b] of Object.entries(it.barcodes || {})) {
      const k = bcsKey(b); if (!k || !size) continue;
      const sig = code.toUpperCase() + '|' + size; if (S.sent[k] === sig) continue;
      rows.push({ barcode: k, code, size: String(size), name: String(it.name || '').slice(0, 120), brand: String(it.brand || '').slice(0, 40), src: 'pc' });
    }
  }
  return rows;
}
function bcsQueue(code) { const c = String(code || '').trim().toUpperCase(); if (bcsNikeCode(c) && !BCS.q.includes(c)) BCS.q.unshift(c); }
function bcsNikeTodo() {
  const S = BCS.st, L = [...BCS.q];
  for (const it of (typeof INV !== 'undefined' && INV.items) || []) {
    const c = String(it.code || '').split('/')[0].trim().toUpperCase(); if (!bcsNikeCode(c) || L.includes(c)) continue;
    const full = (it.sizes || []).length && (it.sizes || []).every(s => (it.barcodes || {})[s]);
    if (!full) L.push(c);
  }
  return L.filter(c => !S.nike[c] || Date.now() - S.nike[c] > BCS_NIKE_AGAIN || BCS.q.includes(c));
}
async function bcsTick() {
  if (BCS.busy || typeof clOn !== 'function' || !clOn() || typeof INV === 'undefined') return;
  const S = await bcsLoad(); if (S.notReady && Date.now() - (S.notReadyAt || 0) < 60 * 60e3 && !BCS.q.length) return;
  BCS.busy = true;
  try {
    // 1) 재고 바코드 올리기
    const rows = bcsInvRows();
    if (rows.length) { S.put += await bcsPut(rows); for (const r of rows) S.sent[r.barcode] = r.code.toUpperCase() + '|' + r.size; }
    // 2) 나이키 공식 바코드 (하루 300 품번 · 품번마다 30일에 한 번)
    const d = new Date().toISOString().slice(0, 10); if (S.day !== d) { S.day = d; S.n = 0; }
    const todo = bcsNikeTodo().slice(0, 6); let fill = false;
    for (const c of todo) {
      if (S.n >= BCS_NIKE_DAY) break;
      S.n++; BCS.q = BCS.q.filter(x => x !== c);
      let N; try { N = await bcsNike(c); } catch (e) { S.err = '나이키: ' + e.message; break; }
      S.nike[c] = Date.now();
      const ent = Object.entries(N.sizes);
      if (ent.length) {
        const R = ent.map(([size, g]) => ({ barcode: g, code: c, size, name: String(N.name || '').slice(0, 120), brand: '나이키', src: 'pc' }));
        S.put += await bcsPut(R); S.nikeN++;
        for (const r of R) S.sent[r.barcode] = c + '|' + r.size;
        for (const it of INV.items) if (String(it.code || '').split('/').some(x => x.trim().toUpperCase() === c)) {
          it.barcodes = it.barcodes || {};
          for (const [size, g] of ent) if (!it.barcodes[size] && !Object.values(it.barcodes).some(v => bcsKey(v) === g)) { it.barcodes[size] = g; S.filled++; fill = true; }
        }
      }
      await new Promise(r => setTimeout(r, BCS_NIKE_GAP));
    }
    if (fill && typeof invSave === 'function') await invSave();
    S.err = ''; S.notReady = false; S.at = Date.now();
  } catch (e) {
    S.err = String(e.message || e).slice(0, 160); if (e.notReady) { S.notReady = true; S.notReadyAt = Date.now(); }
  } finally { BCS.busy = false; await bcsSave(); }
}
function bcsLine() {
  const S = BCS.st; if (!S) return '';
  return `공유 바코드 — 올린 ${(S.put || 0).toLocaleString('ko-KR')}개 · 나이키 공식 바코드 ${(S.nikeN || 0).toLocaleString('ko-KR')}개 품번 · 재고 바코드 칸 채움 ${(S.filled || 0).toLocaleString('ko-KR')}개` + (S.notReady ? ' · 서버 준비 전(barcode-share.sql)' : S.err ? ' · ' + S.err : '');
}
(function bcsBoot() {
  // 폰이 시세를 물어본 품번은 나이키 바코드를 먼저 채워요
  if (typeof clQuote === 'function') { const q0 = clQuote; clQuote = async function (r) { try { bcsQueue(r && r.data && r.data.code); } catch (e) {} return q0.apply(this, arguments); }; }
  if (typeof clCard === 'function') { const c0 = clCard; clCard = function () { const h = c0.apply(this, arguments); const L = bcsLine(); return L && typeof h === 'string' ? h + `<p class="hint">${esc(L)}</p>` : h; }; }
  const go = () => { setTimeout(() => bcsTick().catch(() => {}), 20000); setInterval(() => bcsTick().catch(() => {}), 120000); };
  if (typeof document !== 'undefined') { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go(); }
})();
