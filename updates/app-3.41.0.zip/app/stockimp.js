/* 킥스캔 — 재고 가져오기 (줍픽 재고 › 재고 가져오기 /purchases/import)
   KREAM 에 판매 입찰로 걸었거나(판매 중) · 보관 판매로 보냈거나(보관) · 팔렸는데(판매 완료) 킥스캔에 매입 기록이 없는 재고를 모아요.
   매입가 · 매입일 · 매장을 채운 줄만 재고로 가져와요. 판매 완료 줄은 가져오면 다음 판매 내역 갱신 때 매출로 들어가요. */
function stkImpRows() {
  const C = invCalc(), S0 = stkS(), have = new Map();
  for (const [k, s] of C.stock) {
    const id = k.slice(0, k.indexOf('|')), size = k.slice(k.indexOf('|') + 1), it = itemOf(id); if (!it) continue;
    for (const c of String(it.code || '').split('/')) { const kk = codeKey(c) + '|' + ckey(size); have.set(kk, (have.get(kk) || 0) + s.qty); }
  }
  const listed = new Map();
  const add = (code, size, name, where) => { if (codeKey(code).length < 4) return; const kk = codeKey(code) + '|' + ckey(size); const g = listed.get(kk) || { code, size, name, n: 0, where: new Set() }; g.n++; g.where.add(where); listed.set(kk, g); };
  if (typeof abList !== 'undefined') for (const a of abList) if (!a.gone && a.code && a.size) add(a.code, a.size, a.name, a.type === 'fast' ? '보관' : '판매 중');
  if (typeof kInv !== 'undefined' && kInv && kInv.items) for (const i of kInv.items) if (i.code && i.size && !/sold|payout|cancel|return|종료|완료|취소|반송/i.test(`${i.status} ${i.statusName || ''}`)) add(i.code, i.size, i.name, '보관');
  const rows = [];
  for (const [kk, g] of listed) { const short = g.n - (have.get(kk) || 0); if (short > 0) rows.push({ key: 'L' + kk, code: g.code, size: g.size, name: g.name || g.code, where: [...g.where].join(' · '), qty: short }); }
  if (typeof kSales !== 'undefined') for (const [id, u] of Object.entries(kSales.unrec || {})) if (codeKey(u.code).length >= 4) rows.push({ key: 'U' + id, code: u.code, size: u.size, name: u.name, where: '판매 완료', qty: 1, sold: u.price, sdate: u.date });
  const imp = S0.imp = S0.imp || {};
  for (const r of rows) { const v = imp[r.key] || {}; r.cost = v.cost || ''; r.date = v.date || ''; r.part = v.part || ''; r.ready = +r.cost > 0 && !!r.date && !!r.part; }
  const W = S0.impWhere || 'all', T = S0.impSt || 'all';
  return rows.filter(r => W === 'all' || (W === 'sold' ? r.where === '판매 완료' : r.where !== '판매 완료')).filter(r => T === 'all' || (T === 'ready' ? r.ready : !r.ready));
}
function stkImp() {
  const S0 = stkS(), rows = stkImpRows(), ps = INV.partners.filter(p => p.kind === 'buy'), sel = S0.impSel = S0.impSel || {};
  const ready = rows.filter(r => r.ready), selN = rows.filter(r => sel[r.key]).length;
  const chip = (k, v, t) => `<button type="button" class="chip${(S0[k] || 'all') === v ? ' on' : ''}" data-a="stkImpF" data-k="${k}" data-v="${v}">${t}</button>`;
  const at = typeof kInv !== 'undefined' && kInv && kInv.at ? ` (보관 ${new Date(kInv.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })})` : '';
  const row = r => `<tr><td><input type="checkbox" data-a="stkImpSel" data-v="${esc(r.key)}"${sel[r.key] ? ' checked' : ''}></td><td class="l">${esc(String(r.name).slice(0, 40))}</td><td class="l mono">${esc(r.code)}</td><td class="l">${esc(r.size)}</td>
    <td class="l">${esc(r.where)}${r.sold ? `<div class="small">${esc(r.sdate || '')} ${won(r.sold)}에 팔림</div>` : ''}</td><td>${r.qty}</td>
    <td><input type="number" step="1000" class="mini" style="width:100px" data-k="stkImpV" data-f="cost" data-v="${esc(r.key)}" value="${esc(r.cost)}" placeholder="매입가"></td>
    <td><input type="date" class="mini" data-k="stkImpV" data-f="date" data-v="${esc(r.key)}" value="${esc(r.date)}"></td>
    <td class="l"><select class="mini" data-k="stkImpV" data-f="part" data-v="${esc(r.key)}"><option value="">선택</option>${ps.map(p => `<option value="${p.id}"${r.part === p.id ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}</select></td>
    <td class="l">${r.ready ? '<span class="pill ok">준비됨</span>' : '<span class="pill warn">빈칸 있음</span>'}</td></tr>`;
  return `<div class="stk-bar"><button type="button" class="ghost small" data-a="stkTab" data-v="now">‹ 재고 현황</button><b>재고 가져오기</b><span class="small">가져올 재고 ${rows.length}건 · ${rows.reduce((t, r) => t + r.qty, 0)}개</span><span class="topsp"></span><button type="button" class="ghost small" data-a="stkImpXls">엑셀 내려받기</button><button type="button" class="primary small" data-a="stkImpGo"${ready.length ? '' : ' disabled'}>준비된 ${ready.reduce((t, r) => t + r.qty, 0)}개 가져오기</button></div>
  <p class="hint">판매처에 등록했거나 보관 판매로 보냈거나 판매됐는데 킥스캔에 매입 기록이 없는 재고예요. 매입가 · 매입일 · 매장을 채운 항목만 재고로 가져와요 · KREAM 판매 입찰 · 보관 판매 · 판매 내역 기준${at}</p>
  <div class="stk-bar">${chip('impWhere', 'all', '전체')}${chip('impWhere', 'have', '보유 재고')}${chip('impWhere', 'sold', '판매 완료')}<span class="stk-sep"></span>${chip('impSt', 'all', '상태 전체')}${chip('impSt', 'blank', '빈칸 있음')}${chip('impSt', 'ready', '준비됨')}
    <span class="topsp"></span><span class="small">선택한 ${selN}건에</span><select data-k="stkImpBulkPart"><option value="">매장</option>${ps.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select><input type="date" data-k="stkImpBulkDate" value="${esc(S0.impBulkDate || today())}"><button type="button" class="ghost small" data-a="stkImpFill"${selN ? '' : ' disabled'}>채우기</button><button type="button" class="ghost small" data-a="stkImpSelX"${selN ? '' : ' disabled'}>선택 해제</button></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th><input type="checkbox" data-a="stkImpAll" aria-label="모두 선택"></th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">있는 곳</th><th>수량</th><th>매입가</th><th>매입일</th><th class="l">매장</th><th class="l">상태</th></tr></thead><tbody>
  ${rows.map(row).join('') || '<tr><td colspan="10" class="empty">가져올 재고가 없어요 — KREAM 판매 입찰 · 보관 판매 재고가 모두 매입 기록과 맞아요. (자동 입찰 [내 입찰 불러오기] · 보관판매 관리 불러오기를 하면 목록이 새로워져요)</td></tr>'}
  </tbody></table></div>`;
}
async function stkImpAct(a, el) {
  const S0 = stkS(), sel = S0.impSel = S0.impSel || {}, rows = stkImpRows();
  if (a === 'stkImpF') { S0[el.dataset.k] = el.dataset.v; return renderInv(); }
  if (a === 'stkImpSel') { sel[el.dataset.v] = !!el.checked; return renderInv(); }
  if (a === 'stkImpAll') { for (const r of rows) sel[r.key] = !!el.checked; return renderInv(); }
  if (a === 'stkImpSelX') { S0.impSel = {}; return renderInv(); }
  if (a === 'stkImpFill') {
    const part = (document.querySelector('[data-k=stkImpBulkPart]') || {}).value || '', date = (document.querySelector('[data-k=stkImpBulkDate]') || {}).value || '';
    for (const r of rows) if (sel[r.key]) { const v = S0.imp[r.key] = S0.imp[r.key] || {}; if (part) v.part = part; if (date) v.date = date; }
    IS.msg = '선택한 줄에 채웠어요 — 매입가를 넣으면 준비돼요'; return renderInv();
  }
  if (a === 'stkImpXls') return stkCsv([['상품', '품번', '사이즈', '있는 곳', '수량', '매입가', '매입일', '매장'], ...rows.map(r => [r.name, r.code, r.size, r.where, r.qty, r.cost, r.date, r.part ? stkPartName(r.part) : ''])], '재고가져오기');
  if (a === 'stkImpGo') {
    const R = rows.filter(r => r.ready); let n = 0;
    for (const r of R) {
      let it = INV.items.find(x => String(x.code || '').split('/').some(c => codeKey(c) === codeKey(r.code)));
      if (!it && typeof brNewItem === 'function') it = brNewItem(r.code, r.name, '');
      if (!it) continue;
      const p = partnerOf(r.part);
      INV.lots.push({ id: uid(), at: Date.now() + n, date: r.date, itemId: it.id, size: String(r.size), qty: r.qty, cost: +r.cost, partnerId: r.part, payId: '', memo: `재고 가져오기 (${r.where})`, src: 'import', returnDue: r.where === '판매 중' ? addDays(r.date, retDaysOf(p, it)) : '', retQty: 0, exQty: 0, events: [] });
      delete S0.imp[r.key]; n += r.qty;
    }
    await invSave(); IS.msg = `${n}개를 재고로 가져왔어요${R.some(r => r.where === '판매 완료') ? ' — 판매 완료 줄은 다음 판매 내역 갱신 때 매출로 들어가요' : ''}`; S0.impSel = {}; return renderInv();
  }
}
function stkImpInput(el, ev) {
  const S0 = stkS(), k = el.dataset.k, v = el.value;
  if (k === 'stkImpV' && ev.type === 'change') { const imp = S0.imp = S0.imp || {}; const r = imp[el.dataset.v] = imp[el.dataset.v] || {}; r[el.dataset.f] = el.dataset.f === 'cost' ? (+v || '') : v; renderInv(); }
  if (k === 'stkImpBulkDate') S0.impBulkDate = v;
}
