/* 킥스캔 — 소싱 구매 → 쇼핑몰 주문 자동 연결 (작업지시서 E · 대조표 H12 · C15, 11/22)
   1. 소싱 결과의 [구매 ↗]를 누르면 구매 기록(store 'sourcing_buy_intents')을 남겨요 — 품번 · 사이즈(구매 계획) · 매입처 · 매입가 · 개당 수익 · 권장 수량 · 실행 번호 · 누른 시각
   2. 쇼핑몰 주문 자동 입고(inv.js importRows) 때 같은 매입처 + 같은 품번 + 누른 뒤 14일 안의 주문이면 그 기록과 이어요
      — 사이즈는 주문 기준, 매입가는 실제 결제액, 소싱 결과 스냅샷(lot.bi)을 붙여 소싱 › 성과에 바로 잡혀요
   3. 3일이 지나도 맞는 주문이 없으면 알림 종에 "○○ 구매하셨나요? [매입 등록] · [안 샀어요]" (매입처 로그인이 풀렸으면 [로그인]도) · 14일 지나면 저절로 닫아요
   4. [매입 등록]을 직접 누르면 매입 등록 창(buyreg.js)에 상품 · 매입처 · 구매 계획 첫 사이즈 1개 · '권장 N · 재고 N'을 채워 열어요
   5. 손으로 넣은 매입이 나중에 쇼핑몰 주문과 맞으면 새로 입고하지 않고 결제액만 주문 기준으로 고쳐요(biMergeManual — 중복 금지) */
const BI = { L: null, dirty: false };
const BI_KEY = 'sourcing_buy_intents', BI_ASK = 3 * 864e5, BI_TTL = 14 * 864e5;
// 소싱 매입처 주소 → 주문 읽기 매입처(inv.js ORDER_SITES)
const BI_HOST = [[/musinsa\.com/, 'musinsa'], [/zigzag\.kr/, 'zigzag'], [/gmarket\.co\.kr/, 'gmarket'], [/11st\.co\.kr/, '11st'], [/ssg\.com/, 'ssg'], [/lotteon\.com/, 'lotte'], [/29cm\.co\.kr/, '29cm'],
  [/wconcept\.co\.kr/, 'wconcept'], [/rexmonde\.com/, 'rexmonde'], [/nike\.com/, 'nike'], [/ssfshop\.com/, 'ssf'], [/a-rt\.com|grandstage/, 'abc'], [/4910\.kr/, '4910']];
function biSiteOf(b) {
  b = b || {}; const u = String(b.url || '');
  for (const [re, k] of BI_HOST) if (re.test(u)) return k;
  return typeof ORDER_SITES !== 'undefined' && ORDER_SITES.some(s => s.k === b.site) ? b.site : '';
}
const biDayOf = t => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const biLive = i => i && /^(open|linked|manual)$/.test(i.st) && Date.now() - i.at < BI_TTL;
async function biLoad() { if (!BI.L) { try { BI.L = (await store.get(BI_KEY, [])) || []; } catch (e) { BI.L = []; } biTidy(); } return BI.L; }
async function biSave() { if (!BI.L) return; BI.dirty = false; try { await store.set(BI_KEY, BI.L.slice(0, 400)); } catch (e) {} }
// 14일 지난 열린 기록은 저절로 닫아요
function biTidy() { for (const i of BI.L || []) if (i.st === 'open' && Date.now() - i.at >= BI_TTL) { i.st = 'expired'; i.closedAt = Date.now(); BI.dirty = true; } }

// 1. 구매 기록 — how: 'buy'([구매 ↗]) · 'manual'([매입 등록])
async function biRecord(r, C, run, how) {
  await biLoad(); if (!r) return null;
  const ck = codeKey(r.code || ''); if (!ck) return null;
  const b = (C && C.offer) || (r.buy || [])[0] || {}, site = biSiteOf(b);
  // 같은 품번 · 매입처를 하루 안에 또 누르면 같은 기록을 써요
  let x = BI.L.find(i => i.ck === ck && i.site === site && biLive(i) && Date.now() - i.at < 864e5);
  if (!x) {
    x = { id: uid(), ck, code: r.code, name: String(r.name || r.code).slice(0, 90), brand: r.brand || '', img: r.img || '', site, siteLabel: b.label || '', url: b.url || '',
      price: C && C.buy != null ? Math.round(C.buy) : (b.price || null), profit: C && C.avg != null ? Math.round(C.avg) : null, recQ: (C && C.qty) || 0,
      sizes: ((C && C.rec) || []).map(s => ({ size: String(s.size), q: s.q })), runId: (run && (run.id || run.startedAt)) || '', at: Date.now(), st: how === 'manual' ? 'manual' : 'open', lots: [], linkedQ: 0, how };
    BI.L.unshift(x);
  } else if (how === 'manual' && x.st === 'open') x.st = 'manual';
  await biSave(); return x;
}
// 입고(lot)에 구매 기록 스냅샷을 붙여요 — 성과(perf.js)가 이걸로 소싱 매입을 바로 알아요
function biAttach(lot, i, auto) {
  if (!lot || !i) return;
  lot.bi = { id: i.id, at: i.at, price: i.price, profit: i.profit, recQ: i.recQ, runId: i.runId, site: i.siteLabel, name: i.name, auto: !!auto };
  if (!i.lots.includes(lot.id)) { i.lots.push(lot.id); i.linkedQ = (i.linkedQ || 0) + (+lot.qty || 0); }
  if (auto && i.st === 'open') i.st = 'linked';
  i.lastAt = Date.now(); BI.dirty = true;
}
function biAttachId(lot, id, auto) { const i = (BI.L || []).find(x => x.id === id); if (i) biAttach(lot, i, auto); }

// 2. 자동 연결: 같은 매입처 + 같은 품번(색 포함) + [구매] 누른 날 ~ 14일 안의 주문
function biFind(it, site, date) {
  if (!BI.L || !it) return null;
  const codes = String(it.code || '').split('/').map(codeKey).filter(Boolean), base = typeof ordBase === 'function' ? ordBase(site) : site;
  return BI.L.find(i => biLive(i) && i.site && i.site === base && codes.includes(i.ck) && (!date || (date >= biDayOf(i.at) && date <= biDayOf(i.at + BI_TTL)))) || null;
}
function biOnOrderLot(lot, it, site, date) { const i = biFind(it, site, date); if (i) biAttach(lot, i, true); return i; }
// 5. 손으로 넣은 매입(매입 등록 창 · 입고 화면 · 폰 · 엑셀)이 쇼핑몰 주문과 같으면 새 입고 대신 그 매입을 주문 결제액으로 고쳐요
//    같은 상품 · 사이즈 · 수량 · 매입처(비어 있으면 소싱에서 넣은 것만) · 날짜 ±3일 · 아직 주문과 안 이은 것
function biMergeManual(it, size, x, p, date, unit) {
  if (typeof INV === 'undefined' || !it) return null;
  const q = +x.qty || 1, dd = (a, b) => Math.abs((new Date(a) - new Date(b)) / 864e5);
  const l = INV.lots.find(l => !l.srcKey && /^(manual|pc|phone|excel)$/.test(l.src || '') && l.itemId === it.id && String(l.size) === String(size) && +l.qty === q
    && (l.partnerId === (p && p.id) || (!l.partnerId && l.bi)) && l.date && dd(l.date, date) <= 3);
  if (!l) return null;
  l.srcKey = x.key; l.ordNo = x.orderNo || ''; l.ordId = x.ordId || x.orderNo || '';
  if (unit > 0 && unit !== +l.cost) { l.costManual = l.cost; l.cost = unit; }
  if (!l.partnerId && p) l.partnerId = p.id;
  l.memo = (l.memo ? l.memo + ' · ' : '') + `${typeof siteLabel === 'function' ? siteLabel(x.site) : x.site} 주문${x.orderNo ? ' ' + x.orderNo : ''}과 맞춰 결제액으로 고침`;
  return l;
}

// 3. 사람에게 묻기: [구매] 누르고 3일이 지나도 맞는 주문이 없는 것
function biAsks() { return (BI.L || []).filter(i => i.st === 'open' && !(i.linkedQ > 0) && Date.now() - i.at >= BI_ASK && Date.now() - i.at < BI_TTL); }
function biAskOf(code) { const ck = codeKey(code || ''); return !!ck && biAsks().some(i => i.ck === ck); }
// 소싱 결과 표 상품 옆 '매입 N개 · 자동'
function biTag(code) {
  const ck = codeKey(code || ''); if (!ck || !BI.L) return '';
  const L = BI.L.filter(i => i.ck === ck && i.linkedQ > 0); if (!L.length) return '';
  const q = L.reduce((t, i) => t + i.linkedQ, 0), auto = L.some(i => i.st === 'linked');
  return `매입 ${q}개${auto ? ' · 자동' : ''}`;
}
async function biNo(id) { await biLoad(); const i = BI.L.find(x => x.id === id); if (i) { i.st = 'no'; i.closedAt = Date.now(); await biSave(); } }
// 4. 수동 [매입 등록]: 매입 등록 창에 상품 · 매입처 · 첫 사이즈 1개 · '권장 N · 재고 N'
async function biToReg(i) {
  if (!i || typeof brOpen !== 'function' || typeof INV === 'undefined') return false;
  let it = INV.items.find(x => String(x.code || '').split('/').some(c => codeKey(c) === i.ck));
  if (!it && typeof brNewItem === 'function') { it = brNewItem(i.code, i.name, i.brand); if (i.img) it.img = i.img; }
  if (!it) return false;
  if (i.st === 'open') { i.st = 'manual'; BI.dirty = true; }
  brOpen('one');
  const s0 = (i.sizes || [])[0] || { size: '', q: 0 };
  let have = 0; try { const st = invCalc().stock.get(it.id + '|' + s0.size); have = st ? st.qty : 0; } catch (e) {}
  BR.q = it.code || i.code; BR.hit = { it }; BR.bi = i.id;
  BR.sizes = [{ size: s0.size, qty: 1, cost: i.price ? String(i.price) : '', hint: `권장 ${s0.q || 0} · 재고 ${have}` }];
  const nm = s => String(s || '').replace(/\s/g, '');
  const pt = brBuyParts().find(p => nm(p.name) === nm(i.siteLabel)) || (i.site && typeof sitePartner === 'function' && typeof ORDER_SITES !== 'undefined' && ORDER_SITES.some(s => s.k === i.site) ? sitePartner(i.site) : null);
  if (pt) BR.part = pt.id;
  BR.msg = '소싱에서 고른 상품이에요 — 산 사이즈 · 수량 · 결제액을 확인하고 [매입 등록]을 눌러 주세요';
  brPaint(); await biSave(); return true;
}

// 알림 종: '구매 확인' 묶음 + 숫자
(function biBell() {
  if (typeof document === 'undefined') return;
  setTimeout(() => biLoad().then(() => { if (BI.dirty) biSave(); if (typeof notiBadge === 'function') notiBadge(); }), 1500);
  setInterval(() => { if (!BI.L) return; biTidy(); if (BI.dirty) biSave(); }, 30 * 60e3);
  if (typeof notiShow === 'function') {
    const n0 = notiShow;
    notiShow = async function (open) {
      await n0(open);
      const P = document.getElementById('notiPanel'); if (!open || !P) return;
      await biLoad(); const A = biAsks(); if (!A.length) return;
      const off = k => typeof acctState !== 'undefined' && acctState[k] && acctState[k].st === 'off';
      P.insertAdjacentHTML('afterbegin', `<div class="wk-todo bi-ask"><b>구매 확인 ${A.length}개</b>${A.slice(0, 8).map(i => `<div class="wk-todo-r bi-r"><span class="pill warn">확인</span><span><b>${esc(i.name)}</b> 구매하셨나요? <small>${esc(i.siteLabel || '')} · [구매] ${Math.floor((Date.now() - i.at) / 864e5)}일 전</small>${off(i.site) ? `<br><small class="neg">${esc(i.siteLabel || i.site)} 로그인이 풀려 주문을 못 가져왔어요</small>` : ''}</span>
        <span class="bi-btns">${off(i.site) ? `<button type="button" class="linkbtn" data-bi="login">로그인</button>` : ''}<button type="button" class="linkbtn" data-bi="reg" data-id="${esc(i.id)}">매입 등록</button><button type="button" class="linkbtn" data-bi="no" data-id="${esc(i.id)}">안 샀어요</button></span></div>`).join('')}</div>`);
      P.querySelectorAll('[data-bi]').forEach(b => b.addEventListener('click', async e => {
        e.stopPropagation(); const a = b.dataset.bi, i = BI.L.find(x => x.id === b.dataset.id);
        if (a === 'login') { notiShow(false); return route('acct'); }
        if (a === 'no') { await biNo(b.dataset.id); notiBadge(); return notiShow(true); }
        if (a === 'reg') { notiShow(false); if (!(await biToReg(i))) alertBox('재고관리를 아직 못 불러왔어요. 잠시 뒤 다시 눌러 주세요.'); notiBadge(); }
      }));
    };
  }
  if (typeof notiBadge === 'function') {
    const b0 = notiBadge;
    notiBadge = async function () { await b0(); try { const n = biAsks().length, b = document.getElementById('tBellN'); if (b && n) { const cur = parseInt(b.textContent, 10) || 0; b.hidden = false; b.textContent = cur + n > 9 ? '9+' : String(cur + n); const bell = document.getElementById('tBell'); if (bell) bell.classList.add('has'); } } catch (e) {} };
  }
})();
if (typeof module !== 'undefined') module.exports = { BI, biSiteOf, biFind, biMergeManual, biAsks, biTag, biAttach };
