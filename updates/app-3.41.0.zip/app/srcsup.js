'use strict';
/* 킥스캔 개선판 1-3 — 매입처 106곳 (기존 SRC_SITES 17곳 + 아래 89곳)
   아래 매입처는 검색 주소를 미리 넣지 않고, 처음 수집할 때 홈페이지를 열어 검색칸을 찾아요(seSupFind).
   찾은 주소는 store 'srcSupUrl' 에 저장해 다음부터 바로 써요. 못 찾으면 7일 뒤 다시 찾아요.
   [k, 이름, 묶음, 홈, 브랜드(공식몰만 — 그 브랜드를 골랐을 때만 · 품목 낱말로 찾아요), 먼저 써 볼 검색 주소({q})] */
const SE_SUP = [
  // 직매입 (편집숍 · 백화점)
  ['onthespot', '온더스팟', 'direct', 'https://www.onthespot.co.kr/'],
  ['kasina', '카시나', 'direct', 'https://www.kasina.co.kr/'],
  ['hoopcity', 'HOOPCITY', 'direct', 'https://www.hoopcity.co.kr/'],
  ['fleetrunner', '플릿러너', 'direct', 'https://www.fleetrunner.co.kr/'],
  ['brickmansion', '브릭맨션', 'direct', 'https://www.brickmansion.co.kr/'],
  ['thexshop', 'THEXSHOP', 'direct', 'https://www.thexshop.co.kr/'],
  ['tune', 'TUNE', 'direct', 'https://tune.kr/'],
  ['jamstore', 'JAMSTORE', 'direct', 'https://jamstore.co.kr/'],
  ['premiummultishop', '프리미엄멀티샵', 'direct', 'https://www.premiummultishop.com/'],
  ['yconcepts', 'Y.CONCEPTS', 'direct', 'https://yconcepts.co.kr/'],
  ['onyourmark', 'ON YOUR MARK', 'direct', 'https://onyourmark-running.com/'],
  ['whinheart', '히나트', 'direct', 'https://whinheart.com/'],
  ['shoegirlgaja', '슈걸가자', 'direct', 'https://shoegirlgaja.com/'],
  ['smarket', 'S.Market', 'direct', 'https://www.smarket.co.kr/'],
  ['thehyundai', '더현대닷컴', 'direct', 'https://hi.thehyundai.com/'],
  ['folder', '폴더', 'direct', 'https://www.folderstyle.com/'],
  ['premiumsneakers', '프리미엄스니커즈', 'direct', 'https://premiumsneakers.kr/'],
  ['soccerboom', '사커붐', 'direct', 'https://soccerboom.co.kr/'],
  ['thesogno', '더소뇨', 'direct', 'https://sognomall.com/'],
  ['capostore', '카포스토어', 'direct', 'https://www.capostore.co.kr/'],
  ['runnersclub', '러너스클럽', 'direct', 'https://www.runnersclub.com/'],
  ['ssaka', '싸카닷컴', 'direct', 'https://www.ssaka.com/'],
  ['thegearshop', '더 기어샵', 'direct', 'https://thegearshop.co.kr/'],
  // 브랜드 공식몰
  ['salomon', '살로몬 공식몰', 'official', 'https://salomon.co.kr/', /살로몬|salomon/i],
  ['fila', '휠라 공식몰', 'official', 'https://www.fila.co.kr/', /휠라|fila/i],
  ['mlb', 'MLB 공식몰', 'official', 'https://www.mlb-korea.com/', /^mlb|엠엘비/i],
  ['descente', '데상트 공식몰', 'official', 'https://dk-on.com/descente', /데상트|descente/i],
  ['lecoqsportif', '르꼬끄 공식몰', 'official', 'https://dk-on.com/lecoqsportif', /르꼬끄|le ?coq/i],
  ['umbro', '엄브로 공식몰', 'official', 'https://dk-on.com/umbro', /엄브로|umbro/i],
  ['reebok', '리복 공식몰', 'official', 'https://www.reebok.co.kr/', /리복|reebok/i],
  ['timberland', '팀버랜드 공식몰', 'official', 'https://www.timberland.co.kr/', /팀버랜드|timberland/i],
  ['newera', '뉴에라 공식몰', 'official', 'https://www.neweracapkorea.com/', /뉴에라|new ?era/i],
  ['underarmour', '언더아머 공식몰', 'official', 'https://www.underarmour.co.kr/ko-kr/', /언더아머|under ?armour/i],
  ['onitsukatiger', '오니츠카타이거 공식몰', 'official', 'https://www.onitsukatiger.com/kr/ko-kr/', /오니츠카|onitsuka/i],
  ['onrunning', '온(On) 공식몰', 'official', 'https://www.on.com/ko-kr/', /^on$|^온$|온러닝|on ?running|클라우드/i],
  ['lacoste', '라코스테 공식몰', 'official', 'https://www.lacoste.com/kr/', /라코스테|lacoste/i],
  ['hoka', '호카 공식 스토어', 'official', 'https://brand.naver.com/hoka', /호카|hoka/i, 'https://brand.naver.com/hoka/search?q={q}'],
  ['saucony', '써코니 공식몰', 'official', 'https://www.saucony.co.kr/', /써코니|saucony/i],
  ['drmartens', '닥터마틴 공식몰', 'official', 'https://www.drmartens.co.kr/', /닥터마틴|dr\.? ?martens/i],
  ['keen', '킨 공식몰', 'official', 'https://www.keenfootwear.kr/', /^킨$|keen/i],
  ['mizuno', '미즈노 공식몰', 'official', 'https://kor.mizuno.com/', /미즈노|mizuno/i],
  ['stussy', '스투시 공식몰', 'official', 'https://kr.stussy.com/', /스투시|stussy/i, 'https://kr.stussy.com/search?q={q}&type=product'],
  ['discovery', '디스커버리 공식몰', 'official', 'https://www.discovery-expedition.com/', /디스커버리|discovery/i],
  ['brooks', '브룩스 공식몰', 'official', 'https://www.brooksrunning.co.kr/', /브룩스|brooks/i],
  ['birkenstock', '버켄스탁 공식몰', 'official', 'https://www.birkenstock.com/kr/', /버켄스탁|birkenstock/i],
  ['gcosmo', '지코스모(G-SHOCK)', 'official', 'https://www.gcosmo.co.kr/', /지샥|g-?shock|카시오|casio/i],
  ['adererror', '아더에러 공식몰', 'official', 'https://www.adererror.com/kr/', /아더에러|ader ?error/i],
  ['patagonia', '파타고니아 공식몰', 'official', 'https://www.patagonia.co.kr/', /파타고니아|patagonia/i],
  ['lego', '레고 공식몰', 'official', 'https://www.lego.com/ko-kr', /레고|lego/i, 'https://www.lego.com/ko-kr/search?q={q}'],
  ['burberry', '버버리 공식몰', 'official', 'https://kr.burberry.com/', /버버리|burberry/i],
  ['louisvuitton', '루이 비통 공식몰', 'official', 'https://kr.louisvuitton.com/kor-kr/homepage', /루이 ?비통|louis ?vuitton/i],
  ['prada', '프라다 공식몰', 'official', 'https://www.prada.com/kr/ko.html', /프라다|prada/i],
  ['levis', '리바이스 공식몰', 'official', 'https://levi.co.kr/', /리바이스|levi/i],
  ['thombrowne', '톰브라운 공식몰', 'official', 'https://www.thombrowne.com/ko-kr', /톰 ?브라운|thom ?browne/i],
  ['thisisneverthat', '디스이즈네버댓 공식몰', 'official', 'https://thisisneverthat.com/', /디스이즈네버댓|thisisneverthat/i],
  ['calvinklein', '캘빈클라인 공식몰', 'official', 'https://www.calvinklein.co.kr/ko', /캘빈 ?클라인|calvin ?klein/i],
  ['coach', '코치 공식몰', 'official', 'https://korea.coach.com/', /^코치$|coach/i],
  ['stoneisland', '스톤아일랜드 공식몰', 'official', 'https://www.stoneisland.com/ko-kr', /스톤 ?아일랜드|stone ?island/i],
  ['longchamp', '롱샴 공식몰', 'official', 'https://www.longchamp.com/kr/ko', /롱샴|longchamp/i],
  ['balenciaga', '발렌시아가 공식몰', 'official', 'https://www.balenciaga.com/ko-kr', /발렌시아가|balenciaga/i],
  ['bottegaveneta', '보테가 베네타 공식몰', 'official', 'https://www.bottegaveneta.com/ko-kr', /보테가|bottega/i],
  ['celine', '셀린느 공식몰', 'official', 'https://www.celine.com/ko-kr/home', /셀린느|celine/i],
  ['ysl', '생로랑 공식몰', 'official', 'https://www.ysl.com/ko-kr', /생 ?로랑|saint ?laurent|ysl/i],
  ['arcteryx', '아크테릭스 공식몰', 'official', 'https://arcteryx.co.kr/', /아크테릭스|arc'?teryx/i],
  ['uniqlo', '유니클로 공식몰', 'official', 'https://www.uniqlo.com/kr/ko/', /유니클로|uniqlo/i, 'https://www.uniqlo.com/kr/ko/search?q={q}'],
  // 입점몰 (여러 판매자 · 홈쇼핑)
  ['kolonmall', '코오롱몰', 'mall', 'https://www.kolonmall.com/'],
  ['lfmall', 'LF몰', 'mall', 'https://www.lfmall.co.kr/'],
  ['elandmall', '이랜드몰', 'mall', 'https://www.elandmall.co.kr/'],
  ['halfclub', '하프클럽', 'mall', 'https://www.halfclub.com/'],
  ['reebonz', '리본즈', 'mall', 'https://www.reebonz.co.kr/'],
  ['modaoutlet', '모다아울렛', 'mall', 'https://www.modaoutlet.com/'],
  ['gsshop', 'GS SHOP', 'mall', 'https://www.gsshop.com/', null, 'https://www.gsshop.com/shop/search/main.gs?tq={q}'],
  ['boribori', '보리보리', 'mall', 'https://m.boribori.co.kr/'],
  ['cjonstyle', 'CJ온스타일', 'mall', 'https://display.cjonstyle.com/', null, 'https://display.cjonstyle.com/p/search/searchAllList?k={q}'],
  ['fashionplus', '패션플러스', 'mall', 'https://www.fashionplus.co.kr/'],
  ['lotteimall', '롯데홈쇼핑', 'mall', 'https://www.lotteimall.com/'],
  ['hnsmall', '홈앤쇼핑', 'mall', 'https://www.hnsmall.com/'],
  ['skstoa', 'SK스토아', 'mall', 'https://www.skstoa.com/'],
  ['sstvshop', '신세계쇼핑', 'mall', 'https://www.shinsegaetvshopping.com/'],
  ['galleria', '갤러리아몰', 'mall', 'https://www.galleria.co.kr/'],
  ['hmall', '현대Hmall', 'mall', 'https://www.hmall.com/'],
  ['lookpin', '룩핀', 'mall', 'https://www.lookpin.co.kr/'],
  ['posty', '포스티', 'mall', 'https://posty.kr/'],
  ['trenbe', '트렌비', 'mall', 'https://www.trenbe.com/'],
  ['jente', '젠테', 'mall', 'https://jentestore.com/'],
  ['eql', 'EQL', 'mall', 'https://www.eqlstore.com/'],
  ['premiumoutlets', '신세계 아울렛몰', 'mall', 'https://shop.premiumoutlets.co.kr/'],
  ['shinsegaev', '신세계V', 'mall', 'https://www.shinsegaev.com/'],
  ['istockmall', '아이스탁몰', 'mall', 'https://www.istockmall.com/main'],
  // 줍픽 목록엔 없지만 예전부터 '준비 중'이던 곳
  ['crocs', '크록스 공식몰', 'official', 'https://www.crocs.co.kr/', /크록스|crocs/i],
  ['worksout', '웍스아웃', 'direct', 'https://www.worksout.co.kr/'],
  ['msoutlet', '무신사 아울렛', 'direct', 'https://www.musinsa.com/main/outlet'],
  ['auction', '옥션', 'mall', 'https://www.auction.co.kr/', null, 'https://www.auction.co.kr/n/search?keyword={q}'],
  ['hiver', '하이버', 'rare', 'https://www.hiver.co.kr/'],
  ['brandi', '브랜디', 'rare', 'https://www.brandi.co.kr/']
];
const SE_SUP_RETRY = 7 * 864e5;   // 못 찾은 곳은 7일 뒤 다시
// 사이트 플랫폼별 흔한 검색 주소 (검색칸을 못 찾았을 때 차례로 열어 봐요)
const SE_SUP_TRY = ['/search?q={q}', '/search?keyword={q}', '/product/search.html?keyword={q}', '/goods/goods_search.php?keyword={q}', '/shop/shopbrand.html?search=&prize1={q}', '/search/result?keyword={q}', '/catalogsearch/result/?q={q}'];

// 홈페이지 안에서 실행 — 검색칸이 든 폼과 사이트 플랫폼을 찾아요 (읽기만)
function kcSupSearch() {
  const out = [], NAME = /^(q|query|keyword|keywords|kwd|searchword|search_keyword|searchkeyword|sword|schword|search_text|searchterm|searchtext|word|k|tq|search|qry|key|sKeyword|search_word)$/i;
  for (const f of document.querySelectorAll('form')) {
    const inp = [...f.querySelectorAll('input')].find(i => /^(search|text|)$/i.test(i.type || '') && i.name && NAME.test(i.name));
    if (!inp) continue;
    const act = f.getAttribute('action') || '';
    if (/login|member|join|newsletter|mail|cart|order/i.test(act)) continue;
    try {
      const u = new URL(act || location.pathname, location.href);
      if (u.origin !== location.origin && !/search/i.test(u.href)) continue;
      for (const x of f.querySelectorAll('input[type=hidden]')) if (x.name && x.value != null && String(x.value).length < 40 && !/token|csrf|nonce/i.test(x.name)) u.searchParams.set(x.name, x.value);
      u.searchParams.set(inp.name, '__KSQ__');
      out.push(u.href.replace('__KSQ__', '{q}'));
    } catch (e) {}
  }
  const h = document.documentElement.outerHTML.slice(0, 600000).toLowerCase();
  const plat = /cafe24|ec-base|\/product\/search\.html/.test(h) ? '/product/search.html?keyword={q}' : /godomall|goods_search\.php/.test(h) ? '/goods/goods_search.php?keyword={q}'
    : /cdn\.shopify|shopify\./.test(h) ? '/search?q={q}&type=product' : /demandware|dwstatic/.test(h) ? '/search?q={q}' : /makeshop|shopbrand\.html/.test(h) ? '/shop/shopbrand.html?search=&prize1={q}' : '';
  if (plat) out.push(location.origin + plat);
  return { cands: out, origin: location.origin };
}

// 매입처 하나의 검색 주소 찾기 → SE.supUrl[k] = { url, at } | { fail, at }
async function seSupFind(mod, kw) {
  const C = SE.supUrl[mod.k];
  if (C && C.url) return C.url;
  if (C && C.fail && Date.now() - C.at < SE_SUP_RETRY) return null;
  const q = encodeURIComponent(kw || '운동화');
  const tryOne = async tpl => {
    await seGap(mod.k);
    const res = await SE_IO.list(mod, tpl.replace('{q}', q));
    return res && !res.noResult && res.cards && res.cards.length >= 4;
  };
  const cands = [];
  if (mod.hint) cands.push(mod.hint);
  try {
    await seGap(mod.k);
    const tabId = await srcNav(mod.home);
    const [r] = await execT({ target: { tabId }, func: kcSupSearch, args: [] });
    const R = (r && r.result) || { cands: [] };
    for (const u of R.cands) if (!cands.includes(u)) cands.push(u);
    const origin = R.origin || new URL(mod.home).origin;
    for (const g of SE_SUP_TRY) if (cands.length < 7 && !cands.includes(origin + g)) cands.push(origin + g);
  } catch (e) { console.warn('seSupFind', mod.k, e); }
  for (const tpl of cands.slice(0, 7)) {
    if (seStopped()) return null;
    seSay(`${mod.label} · 검색 주소 찾는 중`);
    try { if (await tryOne(tpl)) { SE.supUrl[mod.k] = { url: tpl, at: Date.now() }; await store.set('srcSupUrl', SE.supUrl); return tpl; } } catch (e) {}
  }
  SE.supUrl[mod.k] = { fail: true, at: Date.now() }; await store.set('srcSupUrl', SE.supUrl);
  return null;
}
