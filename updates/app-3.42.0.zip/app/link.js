/* 킥스캔 — 판매처 연동 (줍픽 PC '판매처 연동' 화면 + 오피스 '판매처 연동' 창을 한 화면으로)
   - '이 PC' 카드: 자동 작업 상태 · [긴급 정지] [다시 시작] [판매처 연동 끄기]
   - 판매처 카드: KREAM · KREAM 입점 · POIZON · POIZON BBC — 상태 배지 · 마지막 갱신 · 자동 갱신 · 경고 띠 · [어떻게 동작하나요]
   - 새 판매 확인: KREAM 판매 내역(kSalesSync)을 5분마다(5분~1시간에서 골라요) 불러와 재고 · 매출에 반영해요.
     잇따라 3번 실패하면 한 시간마다로 늦추고, 한 번 성공하면 원래 주기로 돌아와요. 긴급 정지 중에도 판매 내역 갱신은 계속해요.
   저장: 'linkPref' = { off, every(분) } · 'linkSt' = { kream: { at, okAt, n, pend, err, fails } } */
const LINK_EVERY = [[5, '5분마다'], [10, '10분마다'], [30, '30분마다'], [60, '한 시간마다']];
let LKP = { off: false, every: 5 }, LKS = { kream: {} };
const LK = { busy: false, msg: '', edit: null, pz: null, t0: Date.now() };

const lkAgo = t => { if (!t) return ''; const m = Math.floor((Date.now() - t) / 60e3); return m < 1 ? '방금' : m < 60 ? `${m}분 전` : m < 1440 ? `${Math.floor(m / 60)}시간 전` : `${Math.floor(m / 1440)}일 전`; };
const lkHm = t => t ? new Date(t).toLocaleString('ko-KR', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';
const lkEveryTxt = m => (LINK_EVERY.find(x => x[0] === m) || [0, `${m}분마다`])[1];
function lkEvery() { return ((LKS.kream || {}).fails || 0) >= 3 ? 60 : (+LKP.every || 5); }
async function lkSave() { try { await store.set('linkSt', LKS); } catch (e) {} }
async function lkPrefSave() { try { await store.set('linkPref', LKP); } catch (e) {} }
const lkSt = k => (typeof acctState !== 'undefined' && acctState[k]) || {};
// KREAM 을 한 번이라도 연결한 PC 에서만 자동으로 돌려요 (로그인한 적 없거나 아이디 · 비밀번호가 없으면 건드리지 않아요)
const lkKreamUsed = () => lkSt('kream').st === 'on' || !!(LKS.kream && LKS.kream.okAt) || (typeof acctCanAuto === 'function' && acctCanAuto('kream'));

// ---------- 새 판매 확인 (KREAM 판매 내역 갱신) ----------
async function lkSync(manual) {
  if (LK.busy) return;
  if (typeof kSalesSync !== 'function') return;
  const K = LKS.kream = LKS.kream || {};
  LK.busy = true; K.running = Date.now(); if (manual) LK.msg = 'KREAM 판매 내역을 불러오는 중이에요…'; lkPaint();
  try {
    // 로그인이 풀려 있으면 아이디 · 비밀번호를 저장한 곳만 먼저 다시 로그인해요
    if (lkSt('kream').st === 'off' && typeof acctCanAuto === 'function' && acctCanAuto('kream')) { try { await acctLogin('kream', { quiet: true }); } catch (e) {} }
    const r = await kSalesSync();
    K.okAt = Date.now(); K.n = r.n; K.pend = ((typeof kSales !== 'undefined' && kSales.pending) || []).length; K.err = ''; K.fails = 0; K.skips = (r.skips || []).length;
    if (typeof acctSetState === 'function' && lkSt('kream').st !== 'on') { try { await acctSetState('kream', 'on', ''); } catch (e) {} }
    if (manual) LK.msg = `KREAM 판매 내역을 불러왔어요 — 새로 반영 ${r.n}건 · 진행 중 ${K.pend}건${K.skips ? ` · 반영 못 한 ${K.skips}건은 일반 판매 › 확인 필요에서 볼 수 있어요` : ''}`;
  } catch (e) {
    K.err = String((e && e.message) || e).slice(0, 200); K.fails = (K.fails || 0) + 1;
    if (/로그인/.test(K.err) && typeof acctSetState === 'function') { try { await acctSetState('kream', 'off', 'KREAM 로그인이 풀려 판매 내역을 불러오지 못했어요'); } catch (x) {} }
    if (manual) LK.msg = 'KREAM 판매 내역을 못 불러왔어요: ' + K.err;
  } finally {
    K.at = Date.now(); K.running = 0; LK.busy = false; await lkSave(); lkPaint();
    try { renderSide(); } catch (e) {}
  }
}
// 30초마다 — 정한 주기가 됐으면 불러와요
async function lkTick() {
  if (LKP.off || LK.busy || !OPS_APP) return;
  if (Date.now() - LK.t0 < 2 * 60e3) return;   // 켜고 2분은 기다려요
  if (typeof canUse === 'function' && !canUse('ksell')) return;
  if (!lkKreamUsed()) return;
  const K = LKS.kream || {};
  if (Date.now() < (K.at || 0) + lkEvery() * 60e3) return;
  // 소싱이 KREAM 을 쓰는 동안은 30분에 한 번만 (KREAM 이 요청을 거절하지 않게)
  if (typeof SE !== 'undefined' && SE.busy && Date.now() - (K.at || 0) < 30 * 60e3) return;
  await lkSync(false);
}

// ---------- 화면 ----------
function lkBadge(t, c) { return `<span class="lk-bd ${c || ''}"><i></i>${t}</span>`; }
function lkLoginBadge(k) { const s = lkSt(k).st; return s === 'on' ? lkBadge('로그인됨', 'ok') : s === 'off' ? lkBadge('로그인 안 됨', 'warn') : lkBadge('확인 전', ''); }
function lkAutoTxt() {
  const on = [];
  try { if (typeof AB !== 'undefined' && AB.run) on.push('입찰가 자동 조정'); } catch (e) {}
  try { if (typeof SQ !== 'undefined' && SQ.run) on.push('보관 자동 신청'); } catch (e) {}
  try { if (typeof SE !== 'undefined' && (SE.scheds || []).some(s => s.on)) on.push('소싱 예약'); } catch (e) {}
  return on;
}
function lkCredBox(k) {
  if (LK.edit !== k) return '';
  const A = acctOf(k), C = (acctData && acctData[k]) || {};
  if (!acctVault) return `<div class="lk-cred"><p class="small">아이디 · 비밀번호는 PIN 으로 암호화해서 이 PC 에만 저장해요. 먼저 <b>계정 연결 · 로그인</b>에서 PIN 을 만들어 주세요.</p><div class="row-btns"><button type="button" class="ghost small" data-x="lkAcct">계정 연결 열기</button></div></div>`;
  if (!acctData) return `<div class="lk-cred"><p class="small">저장된 계정이 잠겨 있어요 — PIN 을 넣어 열어 주세요.</p><div class="row-btns"><input type="password" inputmode="numeric" id="lkPin" placeholder="PIN" style="max-width:140px"><button type="button" class="primary small" data-x="lkPin">열기</button></div></div>`;
  return `<div class="lk-cred"><div class="lk-credf"><input id="lkId" value="${esc(C.id || '')}" placeholder="${esc(A.label)} 아이디(이메일)" autocomplete="off"><input id="lkPw" type="password" value="${esc(C.pw || '')}" placeholder="비밀번호" autocomplete="new-password">
    <button type="button" class="primary small" data-x="lkCredSave" data-i="${k}">저장</button>${C.id ? `<button type="button" class="ghost small" data-x="lkCredDel" data-i="${k}">지우기</button>` : ''}</div>
    <p class="small">이 PC 에만 암호화해서 저장해요 — 서버로 보내지 않아요. 로그인이 풀리면 이걸로 다시 로그인해요. 네이버 · Apple · 휴대폰 번호로 로그인한 계정은 자동 로그인이 안 돼요 — [로그인 창 열기]로 직접 로그인해 주세요.</p></div>`;
}
// 3.42 (11/23 검수 1번): 옛 메뉴 '계정 연결 · 로그인'을 판매처 연동 안 '매입처(쇼핑몰) 로그인' 구역으로 — 상태만 모아 보여 주고 관리는 계정 연결 화면
function lkShops() {
  const L = (typeof ACCTS !== 'undefined' ? ACCTS : []).filter(A => !['kream', 'kreamp'].includes(A.k));
  if (!L.length) return '';
  const st = k => lkSt(k).st, off = L.filter(A => st(A.k) === 'off'), on = L.filter(A => st(A.k) === 'on');
  const chip = A => `<span class="lk-bd ${st(A.k) === 'on' ? 'ok' : st(A.k) === 'off' ? 'warn' : ''}" title="${st(A.k) === 'on' ? '로그인됨' : st(A.k) === 'off' ? '로그인 필요' : '확인 전'}"><i></i>${esc(A.label)}</span>`;
  return `<section class="panel lk-card" id="lkShops">
    <div class="lk-ch"><h3>매입처(쇼핑몰) 로그인</h3>${off.length ? lkBadge(`로그인 필요 ${off.length}곳`, 'warn') : on.length ? lkBadge(`로그인됨 ${on.length}곳`, 'ok') : lkBadge('확인 전', '')}</div>
    <p class="lk-desc">쇼핑몰 주문을 불러와 매입으로 넣고(구매처 주문 입고 · 소싱 구매 자동 연결), 소싱 때 회원가 · 쿠폰가를 읽으려면 매입처에 로그인돼 있어야 해요. 예전 '계정 연결 · 로그인' 메뉴가 여기로 왔어요.</p>
    <div class="lk-shops">${L.map(chip).join('')}</div>
    <div class="row-btns"><button type="button" class="primary small" data-x="lkAcct">매입처 로그인 관리</button></div>
  </section>`;
}
function vLink() {
  const K = LKS.kream || {}, halt = !!OPS.halt, off = !!LKP.off, auto = lkAutoTxt();
  const ks = lkSt('kream'), kp = lkSt('kreamp'), pz = LK.pz;
  const pcBadge = off ? lkBadge('꺼져 있음', 'bad') : halt ? lkBadge('긴급 정지 중', 'bad') : lkBadge('켜져 있음', 'ok');
  const autoLine = off ? '판매처 연동이 꺼져 있어요 — 판매 내역 갱신 · 자동 작업을 이 PC 에서 하지 않아요'
    : halt ? '긴급 정지 중 — 입찰가 자동 조정 · 보관 자동 신청 같은 판매처에 쓰는 작업만 멈췄어요 · 판매 내역 갱신은 계속해요'
    : auto.length ? `자동 작업 실행 중 — ${auto.join(' · ')}` : '자동 작업 대기 중 — 켜 둔 자동 작업이 없어요 (자동 입찰 · 보관판매 매크로 · 소싱 예약에서 켜요)';
  // KREAM 상태 글
  const kFail = (K.fails || 0) >= 3, kOff = ks.st === 'off';
  const kLast = K.running ? '지금 불러오는 중…' : K.okAt ? `${lkAgo(K.okAt)} 갱신 · 진행 중 ${K.pend || 0}건${K.n ? ` · 새로 반영 ${K.n}건` : ''}` : K.at ? '아직 못 불러왔어요' : '아직 갱신 전이에요';
  const kAuto = off ? '꺼짐' : `${lkEveryTxt(+LKP.every || 5)}${kFail ? ' (잇따라 실패해 지금은 한 시간마다)' : ''}`;
  const kDesc = kOff ? `KREAM 로그인이 풀려 멈췄어요${kFail ? ' · 잇따라 실패해 지금은 한 시간마다 확인해요' : ''}` : K.err ? `마지막 갱신이 실패했어요 — ${K.err}` : !lkKreamUsed() ? 'KREAM 에 로그인하면 판매 내역 갱신이 시작돼요' : `KREAM 판매 내역(진행 중 · 정산 완료 · 보관 판매)을 ${lkEveryTxt(lkEvery())} 불러와 재고 · 매출에 반영해요`;
  const pzSet = pz && pz.set, pzB = !pz ? lkBadge('확인 전', '') : !pzSet ? lkBadge('연결 대기', 'warn') : pz.status === 'on' ? lkBadge('연결됨', 'ok') : pz.status === 'err' ? lkBadge('오류', 'bad') : lkBadge('키 저장됨', '');
  const row = (name, badge, btns, desc, meta, warn, extra) => `<div class="lk-row">
      <div class="lk-rh"><div class="lk-rn"><b>${name}</b>${badge}</div><div class="lk-btns">${btns}</div></div>
      ${desc ? `<p class="lk-desc">${desc}</p>` : ''}
      ${meta ? `<div class="lk-meta">${meta.map(([l, v]) => `<div><small>${l}</small><b>${v}</b></div>`).join('')}</div>` : ''}
      ${warn || ''}${extra || ''}</div>`;
  const kWarn = kOff ? `<div class="lk-warn"><p>KREAM 로그인이 풀려 판매 내역을 불러오지 못했어요. 네이버 · Apple 로 로그인한 계정은 자동 로그인이 안 돼요 — [로그인 창 열기]로 직접 로그인해 주세요</p><button type="button" class="primary small" data-x="lkLogin" data-i="kream">다시 로그인하기</button></div>` : '';
  return `${xHead('판매처 연동', 'KREAM · POIZON 판매 내역 갱신 · 판매 입찰 · 보관 신청 작업을 이 PC 가 맡아요.')}
  ${LK.msg ? `<p class="iflash">${esc(LK.msg)}</p>` : ''}
  <div class="lk">
  <section class="panel lk-card">
    <div class="lk-ch"><h3>이 PC</h3>${pcBadge}</div>
    <p class="lk-auto">${esc(autoLine)}</p>
    <p class="lk-desc">KREAM · POIZON 판매 내역 갱신 · 판매 입찰 · 보관 신청 작업을 이 PC 가 맡고 있어요. 창을 닫아도 트레이에서 계속 실행돼요.</p>
    <div class="row-btns"><button type="button" class="ghost lk-halt" data-x="lkHalt"${halt ? ' disabled' : ''}>긴급 정지</button><button type="button" class="ghost" data-x="lkResume"${halt ? '' : ' disabled'}>다시 시작</button><button type="button" class="ghost" data-x="lkOff">${off ? '판매처 연동 켜기' : '판매처 연동 끄기'}</button></div>
  </section>
  <section class="panel lk-card">
    <div class="lk-ch"><h3>판매처</h3><label class="lk-ev">새 판매 확인 <select id="lkEvery">${LINK_EVERY.map(([m, t]) => `<option value="${m}"${+LKP.every === m ? ' selected' : ''}>${t}</option>`).join('')}</select></label></div>
    ${row('KREAM', kOff ? lkBadge('KREAM 로그인 필요', 'warn') : lkLoginBadge('kream'),
      `<button type="button" class="ghost small" data-x="lkCred" data-i="kream">아이디·비밀번호</button><button type="button" class="ghost small" data-x="lkCheck" data-i="kream">로그인 확인</button><button type="button" class="ghost small" data-x="lkOpen" data-i="kream">로그인 창 열기</button><button type="button" class="ghost small" data-x="lkSync"${LK.busy ? ' disabled' : ''}>${LK.busy ? '불러오는 중…' : 'KREAM 데이터 갱신'}</button>`,
      esc(kDesc), [['마지막 갱신', esc(kLast)], ['자동 갱신', esc(kAuto)], ['자동 작업', off ? '꺼짐' : halt ? '긴급 정지' : auto.length ? '켜짐' : '꺼짐']], kWarn, lkCredBox('kream'))}
    ${LKP.kPartner === false ? '' : row('KREAM 입점', kp.st === 'on' ? lkBadge('로그인됨', 'ok') : kp.st === 'off' ? lkBadge('로그인 안 됨', 'warn') : lkBadge('연결 전', ''),
      `${kp.st ? '<button type="button" class="ghost small" data-x="lkCheck" data-i="kreamp">로그인 확인</button>' : ''}<button type="button" class="ghost small" data-x="lkOpen" data-i="kreamp">입점 로그인</button>`,
      kp.st === 'on' ? `입점 센터에 연결돼 있어요${kp.at ? ` · ${lkAgo(kp.at)} 확인` : ''} — 왼쪽 메뉴 크림 · 입점에서 입찰 · 보관 · 발송을 관리해요` : '아직 확인 전이에요 — [입점 로그인]에서 입점 센터에 로그인하면 이 PC 에 입점 계정이 연결돼요<br>사업자(입점) 계정이 있을 때만 로그인해 주세요 — 없으면 그대로 두면 돼요.', null, '', '')}
    ${row('POIZON', pzB,
      `<button type="button" class="ghost small" data-x="lkPzKey">${pzSet ? '키 바꾸기' : 'App Key 넣기'}</button>${pzSet ? '<button type="button" class="ghost small" data-x="lkPzTest">연결 시험</button>' : ''}`,
      !pz ? 'POIZON 연결 상태를 확인하는 중이에요' : !pzSet ? 'POIZON 오픈 API 심사 중이에요 — 승인되면 설정 › 판매처에 App Key · App Secret 을 넣어 주세요. 그 전까지 소싱은 KREAM 만으로 판정해요' : pz.status === 'err' ? esc(pz.err || 'POIZON 연결에 문제가 있어요') : `POIZON 오픈 API 로 연결돼 있어요 · App Key 끝 ${esc(pz.tail || '')} · 오늘 조회 ${(pz.today || 0).toLocaleString('ko-KR')} / ${(pz.max || 20000).toLocaleString('ko-KR')}`,
      [['마지막 갱신', pzSet && pz.status === 'on' ? '소싱 시세 조회에 쓰는 중' : '–'], ['자동 갱신', '새 주문 10분마다 · 전체 한 시간마다 (판매 내역은 API 승인 뒤)'], ['연결 기한', pzSet ? '키를 지울 때까지' : '–']], '', '')}
    ${row('POIZON BBC', lkBadge('연결 전', ''), '<button type="button" class="ghost small" disabled title="POIZON 오픈 API 승인 뒤에 연결할 수 있어요">POIZON 키로 연결</button>',
      'BBC(보세 창고) 판매자 계정이 <b>따로 있는 분만</b> 연결하세요 — 위 POIZON 과 같은 방법(오픈 API 키)이에요. 한 시간마다 BBC 주문 · 정산을 불러와 POIZON 판매 내역에 [BBC] 표시로 넣어요. 발송 알리기 · 판매 등록 바꾸기는 BBC 판매자 센터에서 직접 해 주세요. (POIZON 오픈 API 승인 뒤에 열려요)', null, '', '')}
  </section>
  ${lkShops()}
  <details class="panel lk-how"><summary>어떻게 동작하나요</summary><ol>
    <li><b>KREAM</b> 은 이 PC(킥스캔 프로그램)가 꼭 있어야 해요 — 프로그램이 여는 작업용 크롬에서 KREAM 판매 내역 화면의 주문 · 입찰을 불러와요. 창을 닫아도 트레이에서 계속 돌고, ${lkEveryTxt(+LKP.every || 5)}(5분~1시간 중 선택) 갱신해요. 잇따라 실패하면 한 시간마다로 늦춰요.</li>
    <li><b>POIZON</b> 은 POIZON 오픈 API 키(판매자 본인 키)로 연결해요 — 승인되면 주문 · 검수 결과 · 불합격 사유 · 정산을 한 시간마다(새 주문은 10분마다) 불러와요. 지금은 심사 중이라 소싱 시세 조회 자리만 준비돼 있어요.</li>
    <li>불러온 판매는 재고관리 장부 · 매출에 자동으로 반영돼요(정산 완료 기준). 반영 못 한 판매는 사유와 함께 따로 모아 보여 줘요.</li>
    <li>판매처 아이디 · 비밀번호는 이 PC 에만 PIN 으로 암호화해서 둬요 — 서버로 보내지 않아요. KREAM 은 로그인이 하루 지나면 풀릴 수 있어서, 저장해 둔 곳만 자동으로 다시 로그인해요.</li>
    <li><b>긴급 정지</b>는 판매처에 쓰는 자동 작업(입찰가 자동 조정 · 보관 자동 신청)만 멈추고 판매 내역 갱신은 계속해요. <b>판매처 연동 끄기</b>는 이 PC 에서 판매 내역 갱신까지 모두 멈춰요.</li>
  </ol></details>
  </div>`;
}
function lkPaint() { try { if (typeof xView !== 'undefined' && xView === 'link' && typeof curView !== 'undefined' && curView === 'link') renderX(); } catch (e) {} }
async function lkPzRefresh() { try { LK.pz = window.kcApp && window.kcApp.pz ? await window.kcApp.pz.state() : { set: false }; } catch (e) { LK.pz = { set: false }; } }

async function lkAct(a, el) {
  const k = el.dataset.i;
  switch (a) {
    case 'lkHalt': await opsHalt(); LK.msg = '긴급 정지했어요 — 판매처에 쓰는 자동 작업을 멈췄어요. 판매 내역 갱신은 계속해요'; return lkPaint();
    case 'lkResume': await opsResume(); LK.msg = '다시 시작했어요. 자동 입찰은 자동 입찰 화면에서 다시 켜 주세요'; return lkPaint();
    case 'lkOff': LKP.off = !LKP.off; await lkPrefSave(); LK.msg = LKP.off ? '판매처 연동을 껐어요 — 이 PC 에서 판매 내역 갱신 · 판매처 자동 작업을 하지 않아요' : '판매처 연동을 켰어요'; try { renderSide(); } catch (e) {} return lkPaint();
    case 'lkSync': return lkSync(true);
    case 'lkCred': LK.edit = LK.edit === k ? null : k; return lkPaint();
    case 'lkAcct': return route('acct');
    case 'lkPin': { const p = ($('#lkPin') || {}).value || ''; try { await acctUnlock(p, true); LK.msg = '열었어요'; } catch (e) { LK.msg = e.message; } return lkPaint(); }
    case 'lkCredSave': {
      if (!acctData) return;
      const id = String(($('#lkId') || {}).value || '').trim(), pw = String(($('#lkPw') || {}).value || '');
      if (!id || !pw) { LK.msg = '아이디와 비밀번호를 넣어 주세요'; return lkPaint(); }
      acctData[k] = { ...(acctData[k] || {}), id, pw, auto: true }; await acctSeal(); LK.edit = null; LK.msg = `${acctOf(k).label} 아이디 · 비밀번호를 저장했어요 (이 PC 에만 암호화)`; return lkPaint();
    }
    case 'lkCredDel': if (acctData) { delete acctData[k]; await acctSeal(); } LK.edit = null; LK.msg = '저장한 아이디 · 비밀번호를 지웠어요'; return lkPaint();
    case 'lkCheck': LK.msg = '로그인 확인 중…'; lkPaint(); { const s = await acctCheck(k).catch(() => null); LK.msg = s ? `${acctOf(k).label}: ${s.needLogin ? '로그인 안 됨 — [로그인 창 열기]로 로그인해 주세요' : '로그인됨'}` : '확인하지 못했어요 — 잠시 뒤 다시 눌러 주세요'; } return lkPaint();
    case 'lkOpen': LK.msg = `${acctOf(k).label} 로그인 창을 열었어요. 로그인을 끝내면 자동으로 확인하고 창을 닫아요`; lkPaint(); await acctOpenWin(k); return lkPaint();
    case 'lkLogin': if (typeof acctCanAuto === 'function' && acctCanAuto(k)) { LK.msg = '다시 로그인하는 중…'; lkPaint(); const r = await acctLogin(k).catch(e => ({ ok: false, why: e.message })); LK.msg = r && r.ok ? 'KREAM 에 다시 로그인했어요' : `자동 로그인이 안 됐어요${r && r.why ? ` — ${r.why}` : ''} · [로그인 창 열기]로 직접 로그인해 주세요`; if (r && r.ok) lkSync(true); return lkPaint(); } return lkAct('lkOpen', el);
    case 'lkPzKey': route('settings'); setTimeout(() => { try { stTab('sell'); const e = $('#pzKey'); if (e) { e.scrollIntoView({ block: 'center' }); e.focus(); } } catch (x) {} }, 300); return;
    case 'lkPzTest': LK.msg = 'POIZON 연결 시험 중…'; lkPaint(); try { await window.kcApp.pz.call('/api/v1/intl-commodity/intl/sku/sku-basic-info/by-article-number', { articleNumber: 'DD1391-100', region: 'KR', sellerStatusEnable: true }, true); LK.msg = 'POIZON 연결됨 — 다음 조회부터 POIZON 이 붙어요'; } catch (e) { LK.msg = 'POIZON: ' + (e.message || e); } await lkPzRefresh(); return lkPaint();
  }
}

// ---------- 붙이기: 메뉴 · 화면 · 왼쪽 표시 ----------
(function lkWire() {
  if (typeof X_VIEWS !== 'undefined') X_VIEWS.link = () => vLink();
  // 다른 화면(계정 연결)에서 로그인 상태가 바뀌면 이 화면도 다시 그려요
  if (typeof renderAcct === 'function') { const ra = renderAcct; renderAcct = function () { ra(); lkPaint(); }; }
  // 왼쪽 메뉴: 확인할 것이 있으면 주황 점 (로그인 풀림 · 잇따라 실패 · POIZON 오류)
  if (typeof sideBadge === 'function') {
    const sb = sideBadge;
    sideBadge = function (k) {
      if (k === 'link') {
        if (LKP.off) return '<span class="sbadge off">OFF</span>';
        const warn = lkSt('kream').st === 'off' || ((LKS.kream || {}).fails || 0) >= 3 || (LK.pz && LK.pz.status === 'err');
        return warn ? '<span class="lk-dot" title="확인할 것이 있어요"></span>' : '';
      }
      return sb(k);
    };
  }
})();
async function lkInit() {
  try { LKP = { ...LKP, ...((await store.get('linkPref', {})) || {}) }; LKS = { kream: {}, ...((await store.get('linkSt', {})) || {}) }; } catch (e) {}
  if (LKS.kream) LKS.kream.running = 0;
  await lkPzRefresh();
  const m = $('#xMain');
  if (m) {
    m.addEventListener('click', e => { const el = e.target.closest('[data-x^="lk"]'); if (el) { e.stopPropagation(); lkAct(el.dataset.x, el).catch(err => { LK.msg = '오류: ' + err.message; lkPaint(); }); } }, true);
    m.addEventListener('change', e => { if (e.target.id === 'lkEvery') { LKP.every = +e.target.value || 5; lkPrefSave(); LK.msg = `새 판매 확인을 ${lkEveryTxt(LKP.every)}로 바꿨어요`; lkPaint(); } });
  }
  setInterval(() => { lkTick().catch(() => {}); }, 30000);
  setInterval(() => { lkPzRefresh().then(() => { if (curView === 'link') lkPaint(); try { renderSide(); } catch (e) {} }); }, 60000);
  setInterval(() => { if (typeof curView !== 'undefined' && curView === 'link' && !document.querySelector('.lk-cred input:focus')) lkPaint(); }, 30000);   // 'N분 전' 글자
  try { renderSide(); } catch (e) {}
}
if (typeof document !== 'undefined') { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(lkInit, 500)); else setTimeout(lkInit, 500); }

// ---------- 설정 › 판매 설정 › 판매처 (줍픽 설정 › 판매처) · 판매처 로그인 · 작업용 크롬 ----------
// POIZON 수수료는 크림 / 포이즌 동시 분석과 같은 값(DO.pz)을 써요 — 의류 · 신발(wear) · 가방 · 잡화(acc)
function lkSellPaint() {
  const set = (id, v) => { const e = $('#' + id); if (e && document.activeElement !== e) e.value = v; };
  if (typeof DO !== 'undefined' && DO.pz) {
    const w = DO.pz.wear || {}, a = DO.pz.acc || {};
    set('lkpz_rate', w.rate ?? 10); set('lkpz_min', w.min ?? 15000); set('lkpz_max', w.max ?? 0); set('lkpz_amin', a.min ?? 18000); set('lkpz_arate', a.rate ?? 14);
    const m = LKP.pzMode || ['normal', 'fast'];
    const n = $('#lkpz_normal'), f = $('#lkpz_fast'); if (n) n.checked = m.includes('normal'); if (f) f.checked = m.includes('fast');
    const pre = $('#lkpzPre'); if (pre && typeof pzFee === 'function') pre.innerHTML = `30만 원 판매 시 예상 수수료 <b>${pzFee(300000, 'wear').toLocaleString('ko-KR')}원</b> · 가방 · 잡화는 <b>${pzFee(300000, 'acc').toLocaleString('ko-KR')}원</b>`;
  }
  set('lkk_personal', LKP.kPersonal === false ? '0' : '1'); set('lkk_partner', LKP.kPartner === false ? '0' : '1');
  set('lk_keep', LKP.keep === false ? '0' : '1'); set('lk_relogin', LKP.relogin === false ? '0' : '1');
  set('lkpz_szmin', +LKP.pzSzMin || 0); set('lkk_szmin', +LKP.kSzMin || 0);
  set('lkk_prate', LKP.kpRate ?? ''); set('lkk_pbase', LKP.kpBase ?? '');
  const pr = $('#lkkPRow'); if (pr) pr.hidden = LKP.kPartner === false;
  const pa = $('#lkk_prate'), pb = $('#lkk_pbase'); if (pa && typeof S !== 'undefined') pa.placeholder = S.rate; if (pb && typeof S !== 'undefined') pb.placeholder = S.base;
  const kp = $('#lkkPre'); if (kp && typeof feeOf === 'function') kp.innerHTML = `30만 원 판매 시 예상 수수료 <b>${feeOf(300000).toLocaleString('ko-KR')}원</b> (부가세 포함)`
    + (LKP.kPartner !== false && lkHasPFee() ? ` · 입점 계정은 <b>${feeOfP(300000).toLocaleString('ko-KR')}원</b>` : '');
  try { if (typeof stSwSync === 'function') stSwSync(); } catch (e) {}
}
// 입점(사업자) 계정 수수료 — 비워 두면 개인 계정과 같아요 (줍픽 설정 › 판매처 › 입점 수수료)
function lkHasPFee() { return (LKP.kpRate != null && LKP.kpRate !== '') || (LKP.kpBase != null && LKP.kpBase !== ''); }
function feeOfP(price) {
  const has = v => v != null && v !== '';
  return typeof feeOf === 'function' ? feeOf(price, { rate: has(LKP.kpRate) ? LKP.kpRate : null, base: has(LKP.kpBase) ? LKP.kpBase : null }) : 0;
}
// 판매처 비교 표에서 사이즈를 숨길 30일 판매 기준 (0 이면 안 숨김)
function lkSzMin(seller) { return Math.max(0, Math.round(+(seller === 'poizon' ? LKP.pzSzMin : LKP.kSzMin) || 0)); }
function lkKeepApply() { for (const k of ['kream', 'kreamp']) { const A = (typeof ACCTS !== 'undefined' ? ACCTS : []).find(x => x.k === k); if (A) A.keepAlive = LKP.keep === false ? 0 : 20; } }
// 입점 계정을 안 쓰면 왼쪽 메뉴의 '크림 · 입점' 묶음을 숨겨요
function lkMenuApply() {
  const nav = $('#autoNav'); if (!nav) return;
  const off = LKP.kPartner === false;
  nav.querySelectorAll('[data-view^="p"]').forEach(b => { if (/^p(bid|inv|macro|ship|sales)$/.test(b.dataset.view)) b.hidden = off; });
  nav.querySelectorAll('.sgrp').forEach(g => { if (g.textContent.trim() === '크림 · 입점') g.hidden = off; });
}
(function lkWire2() {
  if (typeof renderSide === 'function') { const rs = renderSide; renderSide = function () { rs.apply(this, arguments); try { lkMenuApply(); } catch (e) {} }; }
})();
function lkSetBind() {
  const st = $('#settings'); if (!st || st.__lk) return; st.__lk = 1;
  st.addEventListener('change', async e => {
    const t = e.target, id = t && t.id || '';
    if (/^lkpz_(rate|min|max|amin|arate)$/.test(id) && typeof DO !== 'undefined') {
      const v = Math.max(0, +t.value || 0), k = id.slice(5);
      if (k === 'amin') DO.pz.acc.min = v; else if (k === 'arate') DO.pz.acc.rate = v; else DO.pz.wear[k] = v;
      if (k === 'max') DO.pz.acc.max = v;
      if (typeof dualSave === 'function') await dualSave(); return lkSellPaint();
    }
    if (id === 'lkpz_normal' || id === 'lkpz_fast') { const m = []; if ($('#lkpz_normal').checked) m.push('normal'); if ($('#lkpz_fast').checked) m.push('fast'); if (!m.length) { t.checked = true; return; } LKP.pzMode = m; return lkPrefSave(); }
    if (id === 'lkk_personal' || id === 'lkk_partner') { LKP[id === 'lkk_personal' ? 'kPersonal' : 'kPartner'] = t.value === '1'; await lkPrefSave(); try { renderSide(); } catch (x) {} lkSellPaint(); return lkPaint(); }
    if (id === 'lkpz_szmin' || id === 'lkk_szmin') { LKP[id === 'lkpz_szmin' ? 'pzSzMin' : 'kSzMin'] = Math.max(0, Math.round(+t.value || 0)); await lkPrefSave(); return lkSellPaint(); }
    if (id === 'lkk_prate' || id === 'lkk_pbase') { const k = id === 'lkk_prate' ? 'kpRate' : 'kpBase'; if (t.value === '') delete LKP[k]; else LKP[k] = Math.max(0, +t.value || 0); await lkPrefSave(); return lkSellPaint(); }
    if (id === 'lk_keep') { LKP.keep = t.value === '1'; lkKeepApply(); return lkPrefSave(); }
    if (id === 'lk_relogin') { LKP.relogin = t.value === '1'; return lkPrefSave(); }
    if (/^s_(rate|base|max)$/.test(id)) setTimeout(lkSellPaint, 400);
  });
  st.addEventListener('click', async e => {
    if (e.target.closest('#lkPeek')) { try { const r = await window.kcApp.ops.peek(10); e.target.textContent = r && r.hidden === false ? '창이 이미 보여요' : '10초 동안 보여 줘요'; setTimeout(() => { e.target.textContent = '창 잠깐 보기'; }, 10000); } catch (x) { e.target.textContent = '못 열었어요'; } return; }
    if (e.target.closest('#lkChrome')) { try { await chrome.tabs.create({ url: 'https://kream.co.kr/my', active: true }); } catch (x) { window.open('https://kream.co.kr/my', '_blank'); } return; }
  });
}
(function lkBoot2() {
  const go = () => setTimeout(() => { lkKeepApply(); lkSetBind(); lkSellPaint(); try { lkMenuApply(); } catch (e) {} }, 1500);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
})();
