/* 킥스캔 — 판매 규칙 (줍픽 설정 › 판매 규칙 · 공식 가이드 auto-list)
   I8 자동 판매 등록: 매입(입고)을 등록하면 정한 규칙대로 KREAM 에 판매 입찰을 걸어요.
     - 판매가 = 최저가(−N원) 또는 최소 수익 가격, 1,000원 단위로 올림 · 수익 = 판매가 − 수수료 − 발송비 − 매입가
     - KREAM 은 입찰 한 건 = 1개 · 보유 재고보다 많이 걸지 않아요(abNewRows 의 남은 수량)
     - 매입 등록 뒤 2분 동안은 [이번엔 올리지 않기]로 뺄 수 있어요 · 못 올린 매입은 이유(최소 수익 미달 · 지금 가격 모름 · 올리다 실패)를 남겨요
     - 거는 방식은 자동 입찰과 같아요(abOpt.mode): 알림만 / 확인 화면까지(마지막 버튼은 직접) / 끝까지 자동
     - 긴급 정지 · 휴가 모드 · 판매처 연동 끄기 중엔 쉬어요(opsBlock('abid'))
   I10 자동 재등록: 입찰마다 켜 두면 마감이 가까워질 때 같은 가격으로 180일 다시 걸어요(abExtend 를 그 입찰만)
   저장: 'alOpt' · 'alQ' */
const AL_DEF = { on: false, how: 'low', under: 0, short: 'notify', minKind: 'won', minWon: 10000, minPct: 10, adj: false, days: 180, since: 0 };
let ALO = { ...AL_DEF }, ALQ = [];
const AL = { busy: false, msg: '' };
const AL_WAIT = 2 * 60e3;
async function alSave() { ALQ = ALQ.slice(-200); try { await store.set('alOpt', ALO); await store.set('alQ', ALQ); } catch (e) {} }

// ---------- 가격 계산 ----------
function alNet(p, cost, it) { return p - (typeof feeOf === 'function' ? feeOf(p, null, it) : Math.floor(p * 0.066)) - (+((typeof S !== 'undefined' && S.ship) || 0)) - (+cost || 0); }
function alMinProfit(cost) { return ALO.minKind === 'pct' ? Math.ceil((+cost || 0) * (+ALO.minPct || 0) / 100) : (+ALO.minWon || 0); }
function alMinPrice(cost, it) {   // 최소 수익을 넘는 가장 낮은 1,000원 단위 판매가
  const need = alMinProfit(cost); let p = Math.max(1000, Math.ceil((+cost || 0) / 1000) * 1000);
  for (let i = 0; i < 2000; i++, p += 1000) if (alNet(p, cost, it) >= need) return p;
  return null;
}
// → { price, net, pMin, why(못 올리는 이유) }
function alPrice(cost, minAsk, it) {
  const pMin = alMinPrice(cost, it), need = alMinProfit(cost);
  if (ALO.how === 'profit') return pMin ? { price: pMin, net: alNet(pMin, cost, it), pMin } : { why: '최소 수익 가격을 못 정했어요' };
  if (!(minAsk > 0)) return { why: '지금 가격 모름 — KREAM 에 이 사이즈 판매 입찰이 없어요', pMin };
  let price = Math.ceil((minAsk - (+ALO.under || 0)) / 1000) * 1000;
  if (alNet(price, cost, it) < need) {
    if (ALO.short === 'raise' && pMin) price = pMin;
    else return { why: `최소 수익 미달 — 최저가 ${won(minAsk)}으로 올리면 수익 ${won(alNet(price, cost, it))}(기준 ${won(need)})`, pMin };
  }
  return { price, net: alNet(price, cost, it), pMin };
}

// ---------- 새 매입 찾기 (재고 저장할 때마다) ----------
function alScan() {
  if (!ALO.on || typeof INV === 'undefined') return;
  let n = 0;
  for (const l of INV.lots || []) {
    if (!(+l.qty > 0) || (l.at || 0) <= (ALO.since || 0) || /^(adjust|exchange)$/.test(l.src || '')) continue;
    if (ALQ.some(q => q.lotId === l.id)) continue;
    const it = typeof itemOf === 'function' ? itemOf(l.itemId) : null;
    ALQ.push({ lotId: l.id, at: Date.now(), name: it ? itName(it) : '', code: it ? String(it.code || '').split('/')[0] : '', size: l.size, qty: +l.qty, cost: +l.cost || 0, st: 'wait' }); n++;
  }
  if (n) { alSave(); try { lkPaint(); } catch (e) {} }
}
// 한 매입 처리
async function alRun(q) {
  const l = (INV.lots || []).find(x => x.id === q.lotId), it = l && itemOf(l.itemId);
  if (!l || !it) { q.st = 'skip'; q.why = '매입 기록이 지워졌어요'; return; }
  const k = it.id + '|' + l.size;
  let r0 = abNewRows().find(x => x.k === k);
  if (!r0 || r0.free < 1) { q.st = 'skip'; q.why = r0 ? `보유 ${r0.have}개에 이미 입찰 ${r0.asked}건 — 재고보다 많이 걸지 않아요` : '보유 재고가 없어요'; return; }
  let pid = r0.pid;
  if (!pid) { const f = await kreamByCode(String(it.code || '').split('/')[0]).catch(() => null); pid = f && f.pid ? String(f.pid) : ''; }
  if (!pid) { q.st = 'fail'; q.why = 'KREAM 에서 이 품번 상품을 못 찾았어요'; return; }
  const p = { id: 'al', pid, raw: null };
  await collectOne(p, { days: Math.max(+S.win || 14, 14), maxPages: 4 });
  const m = abMarket(p.raw, l.size, false);
  const pr = q.fixPrice ? { price: Math.ceil(+q.fixPrice / 1000) * 1000, net: alNet(Math.ceil(+q.fixPrice / 1000) * 1000, +l.cost || 0, it), pMin: alMinPrice(+l.cost || 0, it) } : alPrice(+l.cost || 0, m.minAsk, it);
  q.minAsk = m.minAsk; q.pMin = pr.pMin;
  if (!pr.price) { q.st = 'fail'; q.why = pr.why; return; }
  q.price = pr.price; q.net = pr.net;
  const n = Math.min(q.want ? +q.want : +l.qty || 1, r0.free);
  if (abOpt.mode === 'notify') { q.st = 'note'; q.why = `올릴 가격 ${won(pr.price)} × ${n}개 · 개당 수익 ${won(pr.net)} — 자동 입찰 방식이 '알림만'이라 직접 올려 주세요`; return; }
  abNew[k] = { pid, price: pr.price, days: +q.days || +ALO.days || 180, ksize: l.size };
  let done = 0;
  for (let i = 0; i < n; i++) {
    const msg = await abPlaceNew(k);
    if (/확인 화면/.test(msg || '')) { q.st = 'review'; q.why = `${won(pr.price)} — KREAM 확인 화면까지 열었어요. 마지막 버튼은 직접 눌러 주세요`; return; }
    done++;
    if (q.adj != null ? q.adj : ALO.adj) { const a = [...abList].reverse().find(x => /^normal\|new-/.test(x.key) && String(x.pid) === String(pid) && !x.alSet); if (a) { a.on = true; a.floor = pr.pMin || ''; a.cost = +l.cost || ''; a.alSet = true; await abSave(); } }
    await sleep(2500 + Math.random() * 2000);
  }
  q.st = 'done'; q.n = done; q.why = `${won(pr.price)} × ${done}개 입찰을 걸었어요 · 개당 수익 ${won(pr.net)}${ALO.adj ? ' · 입찰가 자동 조정 켬(하한 = 최소 수익 가격)' : ''}`;
}
async function alTick() {
  if (AL.busy || !OPS_APP) return;
  // 재고 현황 [KREAM 에 올리기](manual)는 자동 판매 등록을 꺼 둬도 올려요
  const q = ALQ.find(x => x.st === 'wait' && (x.manual || (ALO.on && Date.now() - x.at > AL_WAIT))); if (!q) return;
  const why = typeof opsBlock === 'function' ? opsBlock('abid') : '';
  if (why) { AL.msg = `자동 판매 등록 쉬는 중 — ${why}`; return; }
  if (typeof SE !== 'undefined' && SE.busy) return;   // 소싱이 KREAM 을 쓰는 동안은 기다려요
  AL.busy = true; q.st = 'run'; AL.msg = ''; try { lkPaint(); } catch (e) {}
  try { await alRun(q); } catch (e) { q.st = 'fail'; q.why = '올리다 실패 — ' + String(e.message || e).slice(0, 120); }
  finally { q.t = Date.now(); AL.busy = false; await alSave(); try { lkPaint(); renderSide(); } catch (e) {} }
}

// ---------- I10 자동 재등록: 켠 입찰만 마감이 가까우면 같은 가격으로 180일 ----------
async function alReTick() {
  if (!OPS_APP || typeof abList === 'undefined' || (typeof opsBlock === 'function' && opsBlock('abid'))) return;
  const L = abList.filter(it => it.reAuto && !it.gone && it.type !== 'fast' && it.askId && abDaysLeft(it) != null && abDaysLeft(it) <= (+abOpt.extDays || 7));
  for (const it of L) { try { await abExtend(it.key); } catch (e) {} }
  if (L.length) try { abRender(); } catch (e) {}
}

// ---------- 화면: 판매처 연동 아래 '자동 판매 등록' 카드 · 설정 › 판매 규칙 ----------
const AL_ST = { wait: ['대기', ''], run: ['올리는 중', 'ok'], done: ['올림', 'ok'], review: ['확인 화면', 'warn'], note: ['알림만', 'warn'], fail: ['못 올림', 'bad'], skip: ['건너뜀', ''] };
function alCard() {
  const L = ALQ.slice(-12).reverse();
  const head = ALO.on ? lkBadge('켜짐', 'ok') : lkBadge('꺼짐', '');
  const rule = `${ALO.how === 'profit' ? '최소 수익 가격으로' : `최저가${+ALO.under ? `보다 ${won(+ALO.under)} 낮게` : '로'}`} · 최소 수익 ${ALO.minKind === 'pct' ? ALO.minPct + '%' : won(+ALO.minWon || 0)}${ALO.how !== 'profit' ? ` · 미달이면 ${ALO.short === 'raise' ? '최소 수익 가격으로' : '올리지 않고 알림'}` : ''} · ${ALO.days || 180}일${ALO.adj ? ' · 입찰가 자동 조정 같이 켬' : ''} · 방식 ${(typeof AB_MODE !== 'undefined' && AB_MODE[abOpt.mode]) || abOpt.mode}`;
  return `<section class="panel lk-card">
    <div class="lk-ch"><h3>자동 판매 등록</h3>${head}</div>
    <p class="lk-desc">매입을 등록하면 정한 규칙대로 KREAM 에 판매 입찰을 걸어요 — ${esc(rule)}. 매입 등록 뒤 2분 안에 [이번엔 올리지 않기]로 뺄 수 있어요. 규칙은 설정 › 판매 규칙에서 바꿔요.</p>
    ${AL.msg ? `<p class="lk-desc"><b>${esc(AL.msg)}</b></p>` : ''}
    ${L.length ? `<table class="lk-al"><thead><tr><th class="l">매입</th><th class="l">사이즈</th><th>매입가</th><th>판매가</th><th class="l">상태</th><th></th></tr></thead><tbody>${L.map(q => { const s = AL_ST[q.st] || [q.st, '']; return `<tr><td class="l">${esc(String(q.name || q.code).slice(0, 34))}</td><td class="l">${esc(q.size)}</td><td>${won(q.cost)}</td><td>${q.price ? won(q.price) : '–'}</td><td class="l">${lkBadge(s[0], s[1])}${q.why ? `<small class="lk-why">${esc(q.why)}</small>` : ''}</td><td>${q.st === 'wait' ? `<button type="button" class="ghost tiny" data-x="lkAlSkip" data-i="${esc(q.lotId)}">이번엔 올리지 않기</button>` : q.st === 'fail' ? `<button type="button" class="ghost tiny" data-x="lkAlRetry" data-i="${esc(q.lotId)}">다시 시도</button>` : ''}</td></tr>`; }).join('')}</tbody></table>` : `<p class="lk-desc">${ALO.on ? '켠 뒤 새로 등록한 매입이 아직 없어요' : '꺼져 있어요 — 켜면 그 뒤에 등록하는 매입부터 올려요'}</p>`}
  </section>`;
}
// 설정 › 판매 규칙 › 자동 판매 등록 (예시 계산기 포함)
function alSetHTML() {
  const o = (v, t, cur) => `<option value="${v}"${String(cur) === String(v) ? ' selected' : ''}>${t}</option>`;
  return `<div class="al-set">
    <div class="st-row"><div class="st-l"><b>자동 판매 등록</b><small>매입 등록 뒤 KREAM 에 판매 입찰을 걸어요</small></div><select id="al_on" class="st-hsel" tabindex="-1" aria-hidden="true">${o(1, '켬', ALO.on ? 1 : 0)}${o(0, '끔', ALO.on ? 1 : 0)}</select><button type="button" class="dl-sw st-sw" data-sw="al_on" role="switch" aria-label="자동 판매 등록"><i></i></button></div>
    <div class="st-row"><div class="st-l"><b>판매가</b><small>1,000원 단위로 올림</small></div><div class="st-btns"><select id="al_how">${o('low', '최저가로', ALO.how)}${o('profit', '최소 수익으로', ALO.how)}</select><select id="al_under"${ALO.how === 'profit' ? ' disabled' : ''}>${[0, 1000, 2000, 3000, 5000, 10000].map(v => o(v, v ? `최저가보다 ${v.toLocaleString('ko-KR')}원 낮게` : '최저가와 같게', +ALO.under || 0)).join('')}</select></div></div>
    <div class="st-row"><div class="st-l"><b>최소 수익</b><small>판매가 − 수수료 − 발송비 − 매입가</small></div><div class="st-btns"><select id="al_minKind">${o('won', '원', ALO.minKind)}${o('pct', '% (매입가 기준)', ALO.minKind)}</select><label class="st-num"><input type="number" id="al_minV" value="${ALO.minKind === 'pct' ? ALO.minPct : ALO.minWon}" step="${ALO.minKind === 'pct' ? 1 : 1000}"><span>${ALO.minKind === 'pct' ? '%' : '원'}</span></label></div></div>
    <div class="st-row"><div class="st-l"><b>최소 수익 미달이면</b><small>최저가로 걸면 최소 수익이 안 남을 때</small></div><select id="al_short"${ALO.how === 'profit' ? ' disabled' : ''}>${o('notify', '올리지 않고 알림', ALO.short)}${o('raise', '최소 수익 가격으로 올리기', ALO.short)}</select></div>
    <div class="st-row"><div class="st-l"><b>입찰 기간</b><small>KREAM 1~180일</small></div><select id="al_days">${[30, 60, 90, 180].map(v => o(v, v + '일', ALO.days || 180)).join('')}</select></div>
    <div class="st-row"><div class="st-l"><b>입찰가 자동 조정 같이 켜기</b><small>건 입찰을 자동 입찰에 넣고 하한가 = 최소 수익 가격</small></div><select id="al_adj" class="st-hsel" tabindex="-1" aria-hidden="true">${o(1, '켬', ALO.adj ? 1 : 0)}${o(0, '끔', ALO.adj ? 1 : 0)}</select><button type="button" class="dl-sw st-sw" data-sw="al_adj" role="switch" aria-label="입찰가 자동 조정 같이 켜기"><i></i></button></div>
    <div class="st-row al-calc"><div class="st-l"><b>예시 계산기</b><small>매입가와 지금 KREAM 최저가를 넣어 보세요</small></div><div class="st-btns"><label class="st-num"><input type="number" id="al_cCost" value="${ALO.cCost || 100000}" step="1000"><span>매입가</span></label><label class="st-num"><input type="number" id="al_cAsk" value="${ALO.cAsk || 139000}" step="1000"><span>최저가</span></label></div><p class="al-res" id="alCalc">${alCalcTxt()}</p></div>
  </div>`;
}
function alCalcTxt() {
  const c = +ALO.cCost || 100000, a = +ALO.cAsk || 139000, r = alPrice(c, a);
  if (!r.price) return `<span class="se-bad">${esc(r.why)}</span>${r.pMin ? ` · 최소 수익 가격은 ${won(r.pMin)}` : ''}`;
  return `판매가 <b>${won(r.price)}</b> → 수수료 ${won(feeOf(r.price))}${+S.ship ? ` · 발송비 ${won(+S.ship)}` : ''} → 수익 <b class="${r.net > 0 ? 'se-ok' : 'se-bad'}">${won(r.net)}</b>${r.pMin ? ` · 최소 수익 가격 ${won(r.pMin)}` : ''}`;
}
function alSetPaint() { const b = $('#alSetBox'); if (b) { b.innerHTML = alSetHTML(); try { stSwSync(); } catch (e) {} } }
function alSetBind() {
  const st = $('#settings'); if (!st || st.__al) return; st.__al = 1;
  st.addEventListener('change', async e => {
    const t = e.target, id = t && t.id || ''; if (!/^al_/.test(id)) return;
    const v = t.value;
    if (id === 'al_on') { ALO.on = v === '1'; if (ALO.on) ALO.since = Date.now(); }
    else if (id === 'al_adj') ALO.adj = v === '1';
    else if (id === 'al_how') ALO.how = v; else if (id === 'al_under') ALO.under = +v || 0; else if (id === 'al_short') ALO.short = v; else if (id === 'al_days') ALO.days = +v || 180;
    else if (id === 'al_minKind') ALO.minKind = v;
    else if (id === 'al_minV') { if (ALO.minKind === 'pct') ALO.minPct = Math.max(0, +v || 0); else ALO.minWon = Math.max(0, +v || 0); }
    else if (id === 'al_cCost') ALO.cCost = +v || 0; else if (id === 'al_cAsk') ALO.cAsk = +v || 0;
    await alSave();
    if (/^al_c/.test(id)) { const c = $('#alCalc'); if (c) c.innerHTML = alCalcTxt(); } else alSetPaint();
    try { lkPaint(); } catch (x) {}
  });
}

(function alWire() {
  // 재고를 저장할 때마다 새 매입을 찾아요
  if (typeof invSave === 'function') { const f = invSave; invSave = async function () { const r = await f.apply(this, arguments); try { alScan(); } catch (e) {} return r; }; }
  // 판매처 연동 화면 아래에 자동 판매 등록 카드
  if (typeof vLink === 'function') { const v = vLink; vLink = function () { const h = v(); const i = h.lastIndexOf('<details class="panel lk-how">'); return i > 0 ? h.slice(0, i) + alCard() + h.slice(i) : h + alCard(); }; }
  if (typeof lkAct === 'function') {
    const a0 = lkAct;
    lkAct = async function (a, el) {
      const q = ALQ.find(x => x.lotId === el.dataset.i);
      if (a === 'lkAlSkip') { if (q && q.st === 'wait') { q.st = 'skip'; q.why = '이번엔 올리지 않기'; await alSave(); } return lkPaint(); }
      if (a === 'lkAlRetry') { if (q) { q.st = 'wait'; q.at = Date.now() - AL_WAIT; q.why = ''; await alSave(); alTick(); } return lkPaint(); }
      return a0(a, el);
    };
  }
  // 자동 재등록 칸: 자동 입찰 표에서 입찰마다 켜고 꺼요
  if (typeof abInput === 'function') { const ai = abInput; abInput = async function (el, ev) { if (el && el.dataset && el.dataset.xk === 'abReAuto') { const it = abList.find(x => x.key === el.dataset.i); if (it) { it.reAuto = !!el.checked; await abSave(); abRender(); } return; } return ai(el, ev); }; }
})();
async function alInit() {
  try { ALO = { ...AL_DEF, ...((await store.get('alOpt', {})) || {}) }; ALQ = (await store.get('alQ', [])) || []; } catch (e) {}
  for (const q of ALQ) if (q.st === 'run') q.st = 'wait';
  alSetBind(); alSetPaint();
  setInterval(() => { alTick().catch(() => {}); }, 30000);
  setInterval(() => { alReTick().catch(() => {}); }, 6 * 3600e3);
  setTimeout(() => { alReTick().catch(() => {}); }, 10 * 60e3);
}
if (typeof document !== 'undefined') { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(alInit, 900)); else setTimeout(alInit, 900); }

// ---------- I11 휴가 모드: 켜면 지금 판매 입찰을 기억 → 끄면 같은 값으로 다시 올려요 (줍픽 가이드 automation) ----------
// KREAM 입찰을 지우는 자동화는 실제 입찰로 시험한 뒤 넣어요 — 지금은 켤 때 내릴 목록과 KREAM 판매 입찰 화면을 열어 드리고(직접 [입찰 지우기]),
// 끌 때는 검증된 '입찰 걸기'(abSellPage · 자동 입찰 방식 그대로)로 기억한 값을 판매가 낮은 순 · 보유 재고까지 다시 올려요. 못 올린 건 알림 종 '휴가 뒤 다시 못 올린 판매'.
async function vacSnap() {
  const L = (typeof abList !== 'undefined' ? abList : []).filter(a => !a.gone && a.type !== 'fast' && a.pid && a.price);
  const snap = { at: Date.now(), bids: L.map(a => ({ pid: a.pid, code: a.code || '', name: a.name || '', size: a.size, price: +a.price, on: !!a.on, floor: a.floor || '', step: a.step || 1000, cost: a.cost || '' })) };
  await store.set('vacSnap', snap); return snap;
}
async function vacRestore() {
  const snap = await store.get('vacSnap', null); if (!snap || !(snap.bids || []).length) return { n: 0, fails: [] };
  try { if (typeof abLoadBids === 'function') await abLoadBids(); } catch (e) {}
  const live = new Set((typeof abList !== 'undefined' ? abList : []).filter(a => !a.gone).map(a => String(a.pid) + '|' + a.size + '|' + a.price));
  const todo = snap.bids.filter(b => !live.has(String(b.pid) + '|' + b.size + '|' + b.price)).sort((a, b) => a.price - b.price);
  let n = 0; const fails = [];
  for (const b of todo) {
    if (typeof opsBlock === 'function' && OPS.halt) { fails.push(`${b.name} ${b.size}: 긴급 정지 중`); continue; }
    // 보유 재고보다 많이 올리지 않아요
    const it = typeof INV !== 'undefined' ? INV.items.find(x => String(x.code || '').split('/').some(c => codeKey(c) === codeKey(b.code))) : null;
    const row = it ? abNewRows().find(x => x.it.id === it.id && String(x.size) === String(b.size)) : null;
    if (row && row.free < 1) { fails.push(`${b.name} ${b.size}: 보유 재고만큼 이미 걸려 있어요`); continue; }
    if (abOpt.mode === 'notify') { fails.push(`${b.name} ${b.size} ${won(b.price)}: 자동 입찰 방식이 '알림만'이라 직접 올려 주세요`); continue; }
    try {
      const r = await abSellPage(String(b.pid), String(b.size), '', b.price, 180, abOpt.mode === 'auto', it || { code: b.code, name: b.name });
      if (r && r.submitted && r.done) { n++; abList.push({ key: 'normal|vac-' + Date.now() + n, askId: '', type: 'normal', pid: String(b.pid), name: b.name, code: b.code, size: b.size, price: b.price, status: '판매 입찰 중', on: b.on, floor: b.floor, step: b.step, cost: b.cost, st: '휴가 뒤 다시 올림' }); await abSave(); }
      else if (r && r.ready) { fails.push(`${b.name} ${b.size} ${won(b.price)}: KREAM 확인 화면까지 — 마지막 버튼은 직접`); break; }
      else fails.push(`${b.name} ${b.size} ${won(b.price)}: ${(r && (r.mismatch || r.error)) || '못 올렸어요'}`);
    } catch (e) { fails.push(`${b.name} ${b.size}: ${e.message}`); }
    await sleep(2500 + Math.random() * 2000);
  }
  await store.set('vacFails', fails);
  if (fails.length && typeof notiAdd1 === 'function') { await notiAdd1(`휴가 뒤 다시 못 올린 판매 ${fails.length}건`, fails.slice(0, 3).join(' · ')); try { notiBadge(); } catch (e) {} }
  await store.set('vacSnap', null);
  return { n, fails };
}
(function vacWire() {
  if (typeof opsSetVac !== 'function') return;
  const v0 = opsSetVac;
  opsSetVac = async function (on) {
    if (on) {
      const s = await vacSnap();
      await v0(true);
      if (s.bids.length) {
        invDialog('휴가 모드를 켰어요', `<p class="hint">자동 입찰 · 자동 판매 등록 · 자동 재등록 · 예약은 쉬고 판매 내역 갱신만 돌아요. 지금 KREAM 판매 입찰 <b>${s.bids.length}건</b>(가격 · 사이즈 · 자동 조정)을 기억해 뒀어요 — 휴가 모드를 끄면 같은 값으로 다시 올려요(보유 재고까지 · 판매가 낮은 순).</p>
          <p class="hint">휴가 동안 팔리지 않게 하려면 KREAM 판매 입찰 화면에서 [입찰 지우기]로 내려 주세요.</p><div class="tbl" style="max-height:220px;overflow:auto"><table class="main"><tbody>${s.bids.map(b => `<tr><td class="l">${esc(String(b.name).slice(0, 30))}</td><td class="l">${esc(b.size)}</td><td>${won(b.price)}</td></tr>`).join('')}</tbody></table></div>`, async () => { try { await chrome.tabs.create({ url: 'https://kream.co.kr/my/selling', active: true }); } catch (e) { window.open('https://kream.co.kr/my/selling', '_blank'); } }, 'KREAM 판매 입찰 열기');
      }
      return;
    }
    await v0(false);
    const snap = await store.get('vacSnap', null);
    if (snap && (snap.bids || []).length && typeof queueJob === 'function') {
      queueJob(async () => { const r = await vacRestore(); try { opsSay(`휴가 뒤 다시 올렸어요 ${r.n}건${r.fails.length ? ` · 못 올린 ${r.fails.length}건은 알림 종에` : ''}`); } catch (e) {} }, { label: '휴가 뒤 판매 다시 올리기' });
    }
  };
})();

// ---------- D3 KREAM 판매 입찰 표: 칩(판매 입찰 · 끝난 입찰 · 자동 재등록) · 한꺼번에 켜고 끄기 (줍픽 PC 일반 판매) ----------
(function abBarWire() {
  if (typeof vAutoBid !== 'function') return;
  const v0 = vAutoBid;
  vAutoBid = function () {
    const h = v0(); if (typeof abList === 'undefined') return h;
    const live = abList.filter(a => !a.gone), gone = abList.length - live.length, re = live.filter(a => a.reAuto).length, on = live.filter(a => a.on).length;
    const bar = `<div class="stk-bar ab-bar"><span class="chip on">판매 입찰 ${live.length}</span><span class="chip">끝난 입찰 ${gone}</span><span class="chip">자동 조정 ${on}</span><span class="chip">자동 재등록 ${re}</span><span class="topsp"></span>
      <button type="button" class="ghost small" data-x="abBulk" data-i="onAll" title="하한가를 넣은 입찰만 켜요">자동 조정 모두 켜기</button><button type="button" class="ghost small" data-x="abBulk" data-i="offAll">자동 조정 모두 끄기</button><button type="button" class="ghost small" data-x="abBulk" data-i="reAll">자동 재등록 모두 켜기</button><button type="button" class="ghost small" data-x="abBulk" data-i="reNone">자동 재등록 모두 끄기</button></div>`;
    const i = h.indexOf('</div>', h.indexOf('class="ihead"'));
    const j = i > 0 ? h.indexOf('</div>', i + 6) : -1;   // ihead 닫힘 뒤
    return j > 0 ? h.slice(0, j + 6) + bar + h.slice(j + 6) : bar + h;
  };
  if (typeof xAct === 'function') {
    const x0 = xAct;
    xAct = async function (a, el) {
      if (a !== 'abBulk') return x0(a, el);
      const k = el.dataset.i, live = abList.filter(x => !x.gone); let n = 0, skip = 0;
      for (const it of live) {
        if (k === 'onAll') { if (abRound(it.floor, true) > 0) { if (!it.on) n++; it.on = true; } else skip++; }
        if (k === 'offAll') { if (it.on) n++; it.on = false; }
        if (k === 'reAll' && it.type !== 'fast') { if (!it.reAuto) n++; it.reAuto = true; }
        if (k === 'reNone') { if (it.reAuto) n++; it.reAuto = false; }
      }
      await abSave(); abSet(`${n}건을 바꿨어요${skip ? ` · 하한가가 없는 ${skip}건은 자동 조정을 못 켰어요` : ''}`); return renderX();
    };
  }
})();
