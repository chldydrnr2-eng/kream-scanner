'use strict';
// 크림스캐너 화면(app.html)에 확장 프로그램용 chrome.* 기능을 똑같은 모양으로 넣어 줘요.
const { ipcRenderer } = require('electron');
const { pathToFileURL } = require('url');
const path = require('path');
const arg = n => (process.argv.find(x => x.startsWith('--' + n + '=')) || '').slice(n.length + 3);
const ROOT = arg('kc-root'), VER = arg('kc-ver');
const call = (ns, m, ...a) => ipcRenderer.invoke('kc', ns, m, a);
const noop = { addListener() {} };
window.__KC_APP = true;
window.kcApp = { info: () => call('app', 'info'), applyUpdate: b => call('app', 'applyUpdate', b), resetUpdate: () => call('app', 'resetUpdate'),
  checkUpdate: () => call('app', 'checkUpdate'), updateState: () => call('app', 'updateState'), restartNow: () => call('app', 'restartNow'), probe: o => call('app', 'probe', o), fixSite: o => call('app', 'fixSite', o), clearLogin: o => call('app', 'clearLogin', o), setUA: o => call('app', 'setUA', o), setSsrStrip: o => call('app', 'setSsrStrip', o), openInstaller: u => call('app', 'openInstaller', u),
  onUpdate: fn => ipcRenderer.on('kc-update', (e, st) => fn(st)) };
window.chrome = {
  storage: { local: { get: k => call('storage', 'get', k === undefined ? null : k), set: o => call('storage', 'set', o), remove: k => call('storage', 'remove', k) }, onChanged: noop },
  scripting: { executeScript: o => call('scripting', 'executeScript', { target: o.target, args: o.args || [], world: o.world, func: String(o.func) }) },
  windows: { create: o => call('windows', 'create', o), get: id => call('windows', 'get', id), update: (id, o) => call('windows', 'update', id, o), remove: id => call('windows', 'remove', id) },
  tabs: { get: id => call('tabs', 'get', id), update: (id, o) => call('tabs', 'update', id, o), create: o => call('tabs', 'create', o), query: o => call('tabs', 'query', o), reload: (id, o) => call('tabs', 'reload', id, o || {}), sendMessage: (id, m) => call('tabs', 'sendMessage', id, m) },
  notifications: { create: (id, o) => call('notifications', 'create', id, o), onClicked: noop },
  alarms: { create: (n, a) => call('alarms', 'create', n, a), clear: n => call('alarms', 'clear', n), onAlarm: noop },
  runtime: { getManifest: () => ({ version: VER, name: '크림스캐너' }), getURL: p => pathToFileURL(path.join(ROOT, p.split('?')[0])).href + (p.includes('?') ? p.slice(p.indexOf('?')) : ''), onMessage: noop, id: 'kream-scanner-app' }
};
