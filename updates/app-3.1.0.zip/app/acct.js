'use strict';
/* 크림스캐너 2.7 — 계정 연결
   쇼핑몰·크림 계정의 로그인 상태(ONLINE/OFFLINE)를 보고, 풀린 곳은 저장해 둔 아이디·비밀번호로 다시 로그인해요.
   아이디·비밀번호는 PIN으로 암호화(AES-GCM, PBKDF2 25만 회)해서 이 PC 크림스캐너 저장소에만 둬요.
   백업 파일·휴대폰 보내기·엑셀에는 들어가지 않아요. 보안문자·문자인증·간편로그인(네이버·카카오)은 자동으로 하지 않고 알려만 줘요. */

const ACCTS = [
  { k: 'musinsa', label: '무신사', check: 'https://www.musinsa.com/order/order-list' },
  { k: 'kream', label: '크림', check: 'https://kream.co.kr/my', login: 'https://kream.co.kr/login' },
  { k: 'zigzag', label: '지그재그' }, { k: 'coupang', label: '쿠팡' }, { k: 'gmarket', label: 'G마켓' },
  { k: 'abc', label: 'ABC마트 · 그랜드스테이지' }, { k: '11st', label: '11번가' }, { k: 'ssg', label: 'SSG · 신세계' },
  { k: 'lotte', label: '롯데ON' }, { k: '29cm', label: '29CM' }, { k: 'wconcept', label: 'W컨셉' },
  { k: 'rexmonde', label: '렉스몬드' }, { k: 'nike', label: '나이키' }, { k: 'ssf', label: 'SSF샵' }
];
const acctOf = k => { const A = ACCTS.find(a => a.k === k); if (!A) return null; const S = (typeof ORDER_SITES !== 'undefined' && ORDER_SITES.find(s => s.k === k)) || {}; return { ...A, check: A.check || S.url, login: A.login || A.check || S.url }; };

let acctVault = null;      // 저장된 암호문 { salt, iv, ct }
let acctKey = null;        // 풀린 열쇠 (이 화면이 열려 있는 동안만)
let acctData = null;       // 풀린 내용 { [k]: { id, pw, auto } }
let acctState = {};        // { [k]: { st: 'on'|'off'|'?', at, msg } }
const AC = { msg: '', edit: {}, show: {}, busy: false };

const b64 = u8 => btoa(String.fromCharCode(...new Uint8Array(u8)));
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function acctDerive(pin, salt) {
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(String(pin)), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
}
async function acctSeal() {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, acctKey, new TextEncoder().encode(JSON.stringify(acctData || {})));
  acctVault = { ...acctVault, iv: b64(iv), ct: b64(ct) };
  await store.set('acctVault', acctVault);
}
async function acctOpen(key) {
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(acctVault.iv) }, key, unb64(acctVault.ct));
  acctKey = key; acctData = JSON.parse(new TextDecoder().decode(pt));
}
async function acctCreate(pin, remember) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  acctVault = { salt: b64(salt), v: 1 };
  acctKey = await acctDerive(pin, salt); acctData = {};
  await acctSeal(); await acctRemember(remember);
}
async function acctUnlock(pin, remember) {
  const key = await acctDerive(pin, unb64(acctVault.salt));
  try { await acctOpen(key); } catch (e) { throw new Error('PIN이 맞지 않아요'); }
  await acctRemember(remember);
}
// 'PIN 기억': 자동 동기화(크림스캐너가 혼자 돌릴 때)에도 로그인하려면 열쇠를 이 PC에 둬야 해요
async function acctRemember(on) {
  if (on) await store.set('acctKey', b64(await crypto.subtle.exportKey('raw', acctKey)));
  else await store.set('acctKey', null);
}
async function acctInit() {
  acctVault = await store.get('acctVault', null);
  acctState = await store.get('acctState', {});
  const raw = await store.get('acctKey', null);
  if (acctVault && raw) { try { await acctOpen(await crypto.subtle.importKey('raw', unb64(raw), 'AES-GCM', true, ['encrypt', 'decrypt'])); } catch (e) { acctKey = null; acctData = null; } }
}
const acctCreds = k => acctData && acctData[k] && acctData[k].id && acctData[k].pw ? acctData[k] : null;
const acctCanAuto = k => !!(acctCreds(k) && acctData[k].auto !== false);
async function acctSetState(k, st, msg) { acctState[k] = { st, at: Date.now(), msg: msg || '' }; await store.set('acctState', acctState); }

// 로그인 상태 확인: 주문 화면을 열어서 로그인 화면으로 넘어가는지 봐요
async function acctCheck(k) {
  const A = acctOf(k); if (!A || !A.check) return null;
  const tabId = await srcNav(A.check);
  const [r] = await execT({ target: { tabId }, func: kcLoginState }, 30000);
  const s = r && r.result;
  if (!s) { await acctSetState(k, '?', '확인 못 함'); return null; }
  await acctSetState(k, s.needLogin ? 'off' : 'on', s.needLogin ? '' : '');
  return s;
}
// 자동 로그인: 로그인 화면에서 아이디·비밀번호를 넣고 로그인 버튼을 눌러요. 보안문자·인증이 뜨면 멈추고 창을 앞으로 가져와요.
async function acctLogin(k, o) {
  o = o || {};
  const A = acctOf(k), C = acctCreds(k);
  if (!A) return { ok: false, why: '모르는 사이트' };
  if (!C) return { ok: false, why: '저장된 아이디·비밀번호가 없어요' };
  let tabId = await srcNav(A.login);
  await sleep(800);
  const [f] = await execT({ target: { tabId }, func: kcLoginFill, args: [C.id, C.pw], world: 'MAIN' }, 40000);
  const r = f && f.result;
  if (!r || !r.ok) {
    if (r && r.why === 'already') { await acctSetState(k, 'on'); return { ok: true }; }
    const why = r && r.why === 'captcha' ? '보안문자·인증이 떠서 직접 로그인해 주세요' : r && r.why === 'nopw' ? '아이디·비밀번호 입력칸을 못 찾았어요 (간편로그인만 되는 계정일 수 있어요)' : '로그인 화면을 못 읽었어요';
    await acctSetState(k, 'off', why);
    if (work.winId && !o.quiet) { try { await chrome.windows.update(work.winId, { focused: true }); } catch (e) {} }
    return { ok: false, why, keepOpen: r && r.why === 'captcha' };
  }
  await sleep(4000);
  // 로그인 뒤 화면에 인증 요구가 떴는지 먼저 봐요
  const [m] = await execT({ target: { tabId }, func: kcLoginState }, 30000);
  if (m && m.result && m.result.captcha && m.result.needLogin) {
    await acctSetState(k, 'off', '추가 인증(보안문자·문자인증)이 필요해요 — 창에서 직접 마무리해 주세요');
    try { await chrome.windows.update(work.winId, { focused: true }); } catch (e) {}
    return { ok: false, why: '추가 인증이 필요해요', keepOpen: true };
  }
  const s = await acctCheck(k);
  if (s && !s.needLogin) return { ok: true };
  await acctSetState(k, 'off', '로그인이 안 됐어요 — 아이디·비밀번호를 확인해 주세요');
  return { ok: false, why: '로그인이 안 됐어요 (아이디·비밀번호 확인)' };
}

// ---------- 화면 ----------
function vAcct() {
  const locked = acctVault && !acctData, none = !acctVault;
  const pinBar = none
    ? `<div class="panel acct-pin"><h2>PIN 만들기</h2><p class="hint">아이디·비밀번호를 암호화할 PIN(숫자 4자리 이상)을 정해요. PIN은 어디에도 저장되지 않으니 잊지 않게 해 주세요(잊으면 계정 정보를 다시 넣어야 해요).</p>
       <div class="row-btns"><input type="password" inputmode="numeric" data-ak="pin" placeholder="PIN" style="max-width:160px"><input type="password" inputmode="numeric" data-ak="pin2" placeholder="PIN 한 번 더" style="max-width:160px">
       <label class="chk"><input type="checkbox" data-ak="remember" checked> 이 PC에서 PIN 기억 (자동 동기화 때도 자동 로그인)</label><button type="button" class="primary" data-ac="pinMake">만들기</button></div></div>`
    : locked
      ? `<div class="panel acct-pin"><h2>잠겨 있어요</h2><p class="hint">PIN을 넣으면 저장된 계정으로 자동 로그인할 수 있어요.</p>
         <div class="row-btns"><input type="password" inputmode="numeric" data-ak="pin" placeholder="PIN" style="max-width:160px"><label class="chk"><input type="checkbox" data-ak="remember" checked> 이 PC에서 PIN 기억</label><button type="button" class="primary" data-ac="pinOpen">열기</button></div></div>`
      : '';
  const cards = ACCTS.map(A0 => {
    const A = acctOf(A0.k), st = acctState[A.k] || {}, C = (acctData && acctData[A.k]) || {}, E = AC.edit[A.k] || {};
    const pill = st.st === 'on' ? '<span class="acct-st on">● ONLINE</span>' : st.st === 'off' ? '<span class="acct-st off">● OFFLINE</span>' : '<span class="acct-st">● 확인 전</span>';
    const dis = acctData ? '' : ' disabled';
    return `<div class="acct-card${st.st === 'on' ? ' is-on' : st.st === 'off' ? ' is-off' : ''}">
      <div class="acct-top"><div><b>${esc(A.label)}</b>${st.at ? `<span class="small"> · ${new Date(st.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })} 확인</span>` : ''}</div>${pill}</div>
      ${st.msg ? `<p class="small neg">${esc(st.msg)}</p>` : ''}
      <label>아이디<input data-ak="id" data-i="${A.k}" value="${esc(E.id ?? C.id ?? '')}" autocomplete="off" placeholder="${esc(A.label)} 아이디"${dis}></label>
      <label>비밀번호<span class="acct-pw"><input type="${AC.show[A.k] ? 'text' : 'password'}" data-ak="pw" data-i="${A.k}" value="${esc(E.pw ?? C.pw ?? '')}" autocomplete="new-password" placeholder="비밀번호"${dis}><button type="button" class="ghost" data-ac="eye" data-i="${A.k}" title="보이기/숨기기"${dis}>${AC.show[A.k] ? '숨김' : '보기'}</button></span></label>
      <div class="row-btns"><label class="chk"><input type="checkbox" data-ak="auto" data-i="${A.k}"${(E.auto ?? C.auto) !== false ? ' checked' : ''}${dis}> 자동 로그인</label></div>
      <div class="row-btns acct-btns"><button type="button" class="ghost" data-ac="save" data-i="${A.k}"${dis}>저장</button><button type="button" class="ghost" data-ac="check" data-i="${A.k}"${AC.busy || AC.wait ? ' disabled' : ''}>상태 확인</button><button type="button" class="ghost" data-ac="open" data-i="${A.k}" title="네이버·카카오 간편로그인처럼 직접 로그인할 때">직접 로그인</button>
        <button type="button" class="primary" data-ac="login" data-i="${A.k}"${AC.busy || AC.wait ? ' disabled' : ''}>${acctCreds(A.k) ? '자동 로그인' : '로그인 창 열기'}</button>${C.id ? `<button type="button" class="ghost acct-del" data-ac="forget" data-i="${A.k}"${dis}>지우기</button>` : ''}</div>
    </div>`;
  }).join('');
  return `${xHead('계정 연결', '쇼핑몰·크림 계정을 저장해 두면, 주문 동기화 때 로그인이 풀린 곳은 자동으로 다시 로그인해요.', `<button type="button" class="primary" data-ac="checkAll"${AC.busy || AC.wait ? ' disabled' : ''}>전체 상태 확인</button>`)}
  ${AC.msg ? `<p class="iflash">${esc(AC.msg)}</p>` : ''}
  <div class="panel"><p class="hint"><b>안내:</b> 아이디·비밀번호는 PIN으로 암호화해서 <b>이 PC 크림스캐너에만</b> 저장돼요(백업 파일·휴대폰 보내기·엑셀에 안 들어가요). 보안문자·문자인증이 뜨거나 네이버·카카오 간편로그인만 쓰는 계정(크림 네이버 로그인 등)은 <b>'직접 로그인'</b>을 눌러 열린 창에서 한 번 로그인하고 창을 닫으면 돼요. 로그인은 계속 유지되고, 닫으면 상태를 자동으로 확인해요. ${acctData ? `<button type="button" class="ghost" data-ac="lock">지금 잠그기</button> <button type="button" class="ghost acct-del" data-ac="wipe">계정 정보 전부 지우기</button>` : ''}</p></div>
  ${pinBar}
  <div class="acct-grid">${cards}</div>`;
}
function renderAcct() { if (typeof xView !== 'undefined' && xView === 'acct') renderX(); }
async function acctAct(a, el) {
  const k = el.dataset.i, v = (s) => { const e = document.querySelector(`[data-ak="${s}"]`); return e ? (e.type === 'checkbox' ? e.checked : e.value) : ''; };
  const set = t => { AC.msg = t; renderAcct(); };
  switch (a) {
    case 'pinMake': { const p = v('pin'); if (!/^\d{4,}$/.test(p)) return set('PIN은 숫자 4자리 이상으로 해 주세요'); if (p !== v('pin2')) return set('두 PIN이 달라요'); await acctCreate(p, v('remember')); return set('PIN을 만들었어요. 이제 계정마다 아이디·비밀번호를 넣고 저장을 누르세요.'); }
    case 'pinOpen': try { await acctUnlock(v('pin'), v('remember')); return set('열었어요'); } catch (e) { return set(e.message); }
    case 'lock': acctKey = null; acctData = null; await store.set('acctKey', null); return set('잠갔어요 (자동 동기화 때 자동 로그인도 꺼져요)');
    case 'wipe': if (!AC.wipeAsk) { AC.wipeAsk = true; return set('한 번 더 누르면 저장된 계정 정보와 PIN이 전부 지워져요'); } AC.wipeAsk = false; acctVault = null; acctKey = null; acctData = null; await store.set('acctVault', null); await store.set('acctKey', null); return set('전부 지웠어요');
    case 'eye': AC.show[k] = !AC.show[k]; return renderAcct();
    case 'save': { if (!acctData) return set('먼저 PIN을 만들거나 열어 주세요'); const E = AC.edit[k] || {}, C = acctData[k] || {}; acctData[k] = { id: String(E.id ?? C.id ?? '').trim(), pw: String(E.pw ?? C.pw ?? ''), auto: (E.auto ?? C.auto) !== false }; delete AC.edit[k]; await acctSeal(); return set(`${acctOf(k).label} 계정을 저장했어요`); }
    case 'forget': { if (!acctData) return; delete acctData[k]; delete AC.edit[k]; await acctSeal(); return set(`${acctOf(k).label} 계정 정보를 지웠어요`); }
    case 'check': return acctRun(async () => { set(`${acctOf(k).label} 확인 중…`); const s = await acctCheck(k); AC.msg = s ? `${acctOf(k).label}: ${s.needLogin ? 'OFFLINE (로그인 필요)' : 'ONLINE'}` : '확인 못 했어요'; }, `${acctOf(k).label} 상태 확인`);
    case 'checkAll': return acctRun(async () => { for (const A of ACCTS) { AC.msg = `${A.label} 확인 중…`; jobSay(AC.msg); renderAcct(); try { await acctCheck(A.k); } catch (e) { await acctSetState(A.k, '?', '확인 못 함'); } } const off = ACCTS.filter(A => (acctState[A.k] || {}).st === 'off').map(A => A.label); AC.msg = off.length ? `로그인 필요: ${off.join(', ')}` : '전부 로그인돼 있어요'; }, '전체 계정 상태 확인');
    case 'open': return acctOpenWin(k);
    case 'login': {
      if (!acctCreds(k)) return acctOpenWin(k);
      return acctRun(async () => { set(`${acctOf(k).label} 로그인 중…`); const r = await acctLogin(k); AC.msg = r.ok ? `${acctOf(k).label} 로그인 완료` : `${acctOf(k).label}: ${r.why}`; AC.keep = r.keepOpen; }, `${acctOf(k).label} 로그인`);
    }
  }
}
// 3.0.2: 로그인 창을 열어 두고, 창을 닫으면 로그인됐는지 자동으로 확인해요 (네이버·카카오 간편로그인용)
async function acctOpenWin(k) {
  const A = acctOf(k); let tab = null;
  try { tab = await chrome.tabs.create({ url: A.login }); } catch (e) { window.open(A.login, '_blank'); }
  AC.msg = `${A.label} 로그인 창을 열었어요. 그 창에서 로그인(네이버로 로그인 등)을 끝내고 창을 닫으면, 자동으로 상태를 확인해요.`; renderAcct();
  if (!tab || !(tab.id > 0)) return;
  const t0 = Date.now();
  while (Date.now() - t0 < 20 * 60000) { await sleep(2000); try { await chrome.tabs.get(tab.id); } catch (e) { break; } }
  return acctRun(async () => { const s = await acctCheck(k); AC.msg = s ? `${A.label}: ${s.needLogin ? 'OFFLINE — 아직 로그인이 안 됐어요' : 'ONLINE — 로그인됐어요'}` : '확인 못 했어요'; }, `${A.label} 상태 확인`);
}
function acctRun(fn, label) {
  if (AC.busy || AC.wait) { AC.msg = '이미 계정 작업이 진행 중이에요. 끝나면 다시 눌러 주세요.'; return renderAcct(); }
  AC.wait = 1; AC.keep = false;
  if (jobBusy) AC.msg = `앞의 작업(${jobNow || '작업'})이 끝나면 바로 시작해요. 기다리기 싫으면 위쪽 '중지'를 누르세요.`;
  renderAcct();
  return queueJob(async () => {
    AC.wait = 0; AC.busy = true; renderAcct();
    try { await fn(); } catch (e) { AC.msg = '멈췄어요: ' + e.message; } finally { AC.busy = false; if (!AC.keep && typeof closeWork === 'function') await closeWork(); renderAcct(); }
  }, { label: label || '계정 연결', onSkip: () => { AC.wait = 0; AC.busy = false; AC.msg = '취소했어요'; renderAcct(); } });
}
function acctInput(el) {
  const k = el.dataset.i, f = el.dataset.ak; if (!k) return;
  AC.edit[k] = AC.edit[k] || {}; AC.edit[k][f] = el.type === 'checkbox' ? el.checked : el.value;
}
function acctBind() {
  const m = $('#xMain'); if (!m) return;
  m.addEventListener('click', e => { const el = e.target.closest('[data-ac]'); if (el) acctAct(el.dataset.ac, el).catch(err => { AC.msg = '오류: ' + err.message; renderAcct(); }); });
  m.addEventListener('input', e => { const el = e.target.closest('[data-ak]'); if (el) acctInput(el); });
  m.addEventListener('change', e => { const el = e.target.closest('[data-ak]'); if (el) acctInput(el); });
}

// 주문 동기화에서 씀: 로그인이 풀려 있으면(자동 로그인 켠 계정만) 다시 로그인하고 한 번 더 시도
async function acctEnsure(k, quiet) {
  if (!acctCanAuto(k)) return false;
  const r = await acctLogin(k, { quiet });
  return r.ok;
}
