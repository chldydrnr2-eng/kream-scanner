'use strict';
/* 킥스캔 — 자동화 모드 추가 메뉴
   크림·포이즌 동시 분석 / 무신사 상품 재고조회 / 사이즈 가격·재입고 추적 / 주문내역 관리 / 크림 판매·구매·보관·발송 내역 */

const XS = { msg: '', busy: false, dual: null, dualQ: '', dualCost: '', ms: null, msList: null, msQ: '', km: {}, kTab: {}, kRaw: false };
let msHist = [], msTracks = [], dualHist = [], rvDraft = {}, bidCmp = {}, partnerData = {};
const xMain = () => $('#xMain');
const xSet = t => { XS.msg = t; const e = $('#xMsg'); if (e) { e.textContent = t; e.hidden = !t; } };
const xHead = (t, d, right = '') => `<div class="ihead"><div><h2>${t}</h2>${d ? `<p class="hint">${d}</p>` : ''}</div><div class="row-btns">${right}</div></div><p class="iflash" id="xMsg"${XS.msg ? '' : ' hidden'}>${esc(XS.msg)}</p>`;
const ckey = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
async function closeWork() { if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; } }
async function inTab(tabId, func, args, world) { const [r] = await execT(world ? { target: { tabId }, func, args: args || [], world } : { target: { tabId }, func, args: args || [] }); return r && r.result; }
function needExt() { if (!HAS_CHROME || !chrome.scripting) { xSet('킥스캔 안에서만 돼요'); return false; } return true; }
function xRun(fn) {
  if (XS.busy) { xSet('앞의 작업이 끝나면 다시 눌러 주세요'); return; }
  XS.busy = true; renderX();
  return queueJob(async () => { try { await fn(); } catch (e) { xSet('멈췄어요: ' + e.message); } finally { XS.busy = false; if (XS.keepWork) { XS.keepWork = false; work = { winId: null, tabId: null }; } else await closeWork(); renderX(); } }, { label: (AUTO_MENU.find(m => m[0] === xView) || [])[1] || '작업', onSkip: () => { XS.busy = false; xSet('취소했어요'); renderX(); } });
}

// ---------- 크림 · 포이즌 동시 분석 (3.20 다시 만듦) ----------
const DUAL_DEF = () => ({ conv: true, pk: true, pp: true, deep: false, pzCat: 'wear', pz: { wear: { rate: 10, min: 15000, fix: 0 }, acc: { rate: 10, min: 15000, fix: 0 } }, disc: '', mr: { on: false, v: 10, m: 'ge' }, mg: { on: false, v: 10000, m: 'ge' } });
let DO = DUAL_DEF();
const dualSave = () => store.set('dualOpt', DO);
const fmtIn = v => { const t = String(v ?? ''); if (!t.trim()) return ''; const n = num(t); return n && !/[.]/.test(t) ? n.toLocaleString('ko-KR') : t; };
// 품번 자동 변환: 띄어쓰기·밑줄·빠진 하이픈을 브랜드 품번 모양으로 맞춰요
function codeNorm(q) {
  let s = String(q || '').trim();
  if (!s || /^https?:|kream\.co\.kr|^\d{2,8}$/i.test(s)) return s;
  s = s.toUpperCase().replace(/[_\s]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  const f = s.replace(/-/g, ''); let m;
  if ((m = f.match(/^([A-Z]{2}\d{4})(\d{3})$/))) return m[1] + '-' + m[2];          // 나이키 · 조던 (DD1391-100)
  if ((m = f.match(/^(\d{4}[A-Z]\d{3})(\d{3})$/))) return m[1] + '-' + m[2];        // 아식스 (1201A019-108)
  if ((m = f.match(/^(\d{6})(\d{3})$/))) return m[1] + '-' + m[2];                  // 예전 나이키 (555088-134)
  return s;
}
const dualQ = () => DO.conv ? codeNorm(XS.dualQ) : String(XS.dualQ || '').trim();
const pzFee = p => { if (!p) return 0; const c = DO.pz[DO.pzCat] || DO.pz.wear; return Math.floor((Math.max(+c.min || 0, p * (+c.rate || 0) / 100) + (+c.fix || 0)) / 10) * 10; };
const dualCostFinal = () => { const c = num(XS.dualCost), d = Math.min(100, Math.max(0, num(DO.disc))); return c ? Math.round(c * (1 - d / 100)) : 0; };
function dualHit(m, fc) {
  if (m == null || !fc || (!DO.mr.on && !DO.mg.on)) return null;
  const r = m / fc * 100; let ok = true;
  if (DO.mr.on) ok = ok && (DO.mr.m === 'ge' ? r >= +DO.mr.v : r < +DO.mr.v);
  if (DO.mg.on) ok = ok && (DO.mg.m === 'ge' ? m >= +DO.mg.v : m < +DO.mg.v);
  return ok;
}
function vDual() {
  const D = XS.dual, fc = dualCostFinal(), conv = dualQ(), busy = XS.busy && XS.dualBusy;
  const kSt = (typeof acctState !== 'undefined' && acctState.kream && acctState.kream.st) || '';
  const pf = (k, label, on) => `<button type="button" class="dl-pf ${k}${on ? ' on' : ''}" data-x="dualPf" data-v="${k}" aria-pressed="${on}"><span class="dl-logo ${k}">${k === 'pk' ? 'KREAM' : 'POIZON'}</span>${label}</button>`;
  const seg = (act, cur, opts) => `<div class="dl-seg">${opts.map(([v, t]) => `<button type="button" data-x="${act}" data-v="${v}" aria-pressed="${cur === v}">${t}</button>`).join('')}</div>`;
  const sw = (act, on, label) => `<button type="button" class="dl-sw${on ? ' on' : ''}" data-x="${act}" role="switch" aria-checked="${on}"><i></i>${label}</button>`;
  const pc = DO.pz[DO.pzCat];
  const fltr = (key, icon, label, unit, o) => `<div class="dl-card dl-flt${o.on ? ' on' : ''}"><div class="dl-flt-h">${ico(icon)}<b>${label}</b>${sw('dualFlt', o.on, '').replace('data-x="dualFlt"', `data-x="dualFlt" data-v="${key}"`)}</div>
    <div class="dl-flt-b"><label class="dl-num"><input data-xk="dualFltV" data-i="${key}" inputmode="numeric" value="${esc(fmtIn(o.v))}"${o.on ? '' : ' disabled'}><span>${unit}</span></label>${seg('dualFltM', o.m, [['ge', '기준 이상'], ['lt', '기준 미만']]).replace(/data-x="dualFltM"/g, `data-x="dualFltM" data-i="${key}"`)}</div></div>`;
  const recent = dualHist.slice(0, 20).map(h => `<div class="dl-rec"><button type="button" class="dl-rec-b" data-x="dualLoad" data-i="${h.at}"><b>${esc((h.kream && h.kream.code) || h.q)}</b><small>${esc((h.kream && h.kream.name) || (h.poizon && (h.poizon.name || h.poizon.title)) || '')}</small><em>${new Date(h.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</em></button><button type="button" class="dl-rec-x" data-x="dualDel" data-i="${h.at}" aria-label="기록 지우기">×</button></div>`).join('');
  const hero = `<div class="dl-hero"><div class="dl-main">
    <div class="dl-top"><h3>${ico('scale')}품번으로 두 곳 시세 한 번에</h3><div class="dl-conn"><span class="dl-cchip ${kSt === 'on' ? 'ok' : kSt === 'off' ? 'bad' : ''}"><span class="dl-logo pk">KREAM</span>${kSt === 'on' ? '로그인됨' : kSt === 'off' ? '로그인 필요' : '확인 전'}</span><span class="dl-cchip ok"><span class="dl-logo pp">POIZON</span>로그인 없이 조회</span></div></div>
    <label class="dl-search">${ico('search')}<input data-xk="dualQ" value="${esc(XS.dualQ)}" placeholder="품번 · 크림 링크 · 크림 상품번호 (예: DD1391-100)" autocomplete="off"></label>
    <div class="dl-row"><label class="dl-chk"><input type="checkbox" data-xk="dualConv"${DO.conv ? ' checked' : ''}> 품번 자동 변환</label>${DO.conv && conv && conv !== String(XS.dualQ).trim() ? `<span class="dl-conv">→ <b>${esc(conv)}</b>로 찾아요</span>` : ''}</div>
    <div class="dl-row dl-ctl"><span class="dl-lab">조회할 곳</span>${pf('pk', '크림', DO.pk)}${pf('pp', '포이즌', DO.pp)}<span class="dl-div"></span>${sw('dualDeep', DO.deep, '세부 검색')}<span class="dl-hint">${DO.deep ? '크림 30일 · 거래 더 많이 (1~2분)' : '크림 14일 (30초~1분)'}</span><span class="topsp"></span>
      <button type="button" class="primary dl-go" data-x="dualRun"${XS.busy ? ' disabled' : ''}>${ico('search')}${busy ? '조회 중…' : '시세 조회'}</button></div>
    <div class="dl-cards3">
      <div class="dl-card"><div class="dl-ch"><span class="dl-logo pk">KREAM</span><b>크림 수수료</b><span class="dl-tag">설정 기준</span></div><p class="dl-big">${S.rate}% + ${won(S.base)} <small>VAT 별도 · 최대 ${won(S.max)}</small></p><p class="dl-sub">위쪽 설정에서 바꿔요. 이벤트 상품은 크림에서 확인하세요.</p></div>
      <div class="dl-card"><div class="dl-ch"><span class="dl-logo pp">POIZON</span><b>포이즌 수수료</b></div>${seg('dualPzCat', DO.pzCat, [['wear', '의류 · 신발'], ['acc', '잡화']])}
        <div class="dl-pzf"><label class="dl-num"><input data-xk="dualPzRate" inputmode="decimal" value="${esc(pc.rate)}"><span>%</span></label><label class="dl-num"><em>최소</em><input data-xk="dualPzMin" inputmode="numeric" value="${esc(fmtIn(pc.min))}"><span>원</span></label><label class="dl-num"><em>+</em><input data-xk="dualPzFix" inputmode="numeric" value="${esc(fmtIn(pc.fix))}"><span>원</span></label></div>
        <p class="dl-sub">판매가 × ${esc(pc.rate)}% (최소 ${won(+pc.min)})${+pc.fix ? ' + ' + won(+pc.fix) : ''}. 포이즌 앱에서 본 값으로 고쳐 두면 기억해요.</p></div>
      <div class="dl-card"><div class="dl-ch"><span class="dl-logo won">₩</span><b>매입가</b></div><div class="dl-pzf"><label class="dl-num wide"><input data-xk="dualCost" inputmode="numeric" value="${esc(fmtIn(XS.dualCost))}" placeholder="100,000"><span>원</span></label><label class="dl-num"><em>할인</em><input data-xk="dualDisc" inputmode="decimal" value="${esc(DO.disc)}" placeholder="0"><span>%</span></label></div>
        <p class="dl-final">최종 매입가 <b>${fc ? won(fc) : '–'}</b></p></div>
    </div>
    <div class="dl-cards2">${fltr('mr', 'percent', '마진율', '%', DO.mr)}${fltr('mg', 'receipt', '마진금', '원', DO.mg)}</div>
  </div>
  <aside class="dl-side"><div class="dl-side-h">${ico('cal')}<b>최근 검색</b>${dualHist.length ? `<button type="button" class="linkbtn" data-x="dualClear">전부 지우기</button>` : ''}</div><div class="dl-recs">${recent || '<p class="dl-none">검색 기록이 없어요</p>'}</div></aside></div>`;

  // 결과
  const skel = n => `<div class="dl-skel">${Array.from({ length: n }, () => '<i></i>').join('')}</div>`;
  const empty = t => `<div class="dl-empty">${ico('search')}<span>${t}</span></div>`;
  let kBody, pBody, cmp = '', sum = '', meta = { k: '', p: '' };
  if (busy) { kBody = DO.pk ? skel(6) : empty('크림은 조회 안 함'); pBody = DO.pp ? skel(6) : empty('포이즌은 조회 안 함'); }
  else if (!D) { kBody = empty('품번을 넣고 시세 조회를 눌러 주세요'); pBody = empty('품번을 넣고 시세 조회를 눌러 주세요'); }
  else {
    const R = D.rows.map(r => { const ps = r.pz != null ? r.pz - pzFee(r.pz) : null; const km = fc && r.settle != null ? r.settle - fc : null, pm = fc && ps != null ? ps - fc : null; return { ...r, ps, km, pm, kh: dualHit(km, fc), ph: dualHit(pm, fc) }; });
    const mg = (m, h) => m == null ? '<td>–</td>' : `<td class="dl-m ${m > 0 ? 'pos' : m < 0 ? 'neg' : ''}${h === true ? ' hit' : ''}"><b>${wonS(m)}</b><small>${(m / fc * 100).toFixed(1)}%</small></td>`;
    const rowCls = h => h === true ? ' class="hit"' : h === false ? ' class="dim"' : '';
    const kR = R.filter(r => r.settle != null || r.sell != null || r.minAsk != null), pR = R.filter(r => r.pz != null);
    kBody = D.kream ? (kR.length ? `<div class="dl-tw"><table><thead><tr><th class="l">사이즈</th><th>7일 거래</th><th>판매가<small>최근 체결</small></th><th>최저 판매입찰</th><th>정산</th>${fc ? '<th>마진</th>' : ''}</tr></thead><tbody>${kR.map(r => `<tr${rowCls(r.kh)}><td class="l"><b>${esc(r.size)}</b></td><td>${r.n7 || 0}건</td><td>${won(r.sell)}</td><td>${won(r.minAsk)}</td><td><b>${won(r.settle)}</b></td>${fc ? mg(r.km, r.kh) : ''}</tr>`).join('')}</tbody></table></div>` : empty('크림 거래 내역이 없어요')) : empty('크림은 조회 안 함');
    pBody = D.poizon ? (pR.length ? `<div class="dl-tw"><table><thead><tr><th class="l">사이즈</th><th>구매가<small>포이즌 화면</small></th><th>수수료</th><th>정산</th>${fc ? '<th>마진</th>' : ''}</tr></thead><tbody>${pR.map(r => `<tr${rowCls(r.ph)}><td class="l"><b>${esc(r.size)}</b></td><td>${won(r.pz)}</td><td class="sub">−${won(pzFee(r.pz))}</td><td><b>${won(r.ps)}</b></td>${fc ? mg(r.pm, r.ph) : ''}</tr>`).join('')}</tbody></table></div>` : empty('포이즌 사이즈 가격이 없어요')) : empty(D.pTried ? '포이즌에서 같은 품번을 못 찾았어요' : '포이즌은 조회 안 함');
    meta.k = D.kream ? `<b>${esc(D.kream.name)}</b><small>${esc(D.kream.code)} · 7일 ${D.kream.n7}건 · <a href="https://kream.co.kr/products/${esc(D.kream.pid)}" target="_blank" rel="noopener">크림에서 열기</a></small>` : '';
    meta.p = D.poizon ? `<b>${esc(D.poizon.name || D.poizon.title)}</b>${D.poizon.ok ? '' : ' <span class="pill warn">품번 확인 필요</span>'}<small><a href="${esc(D.poizon.url)}" target="_blank" rel="noopener">포이즌에서 열기</a></small>` : '';
    const both = R.filter(r => r.settle != null && r.ps != null);
    if (both.length) cmp = `<div class="dl-res dl-cmp"><div class="dl-rh">${ico('swap')}<b>사이즈별 비교</b><span class="dl-hint">정산 기준 · 어디에 파는 게 더 남는지</span></div><div class="dl-tw"><table><thead><tr><th class="l">사이즈</th><th>크림 정산</th><th>포이즌 정산</th><th>차이<small>포이즌 − 크림</small></th><th>더 남는 곳</th></tr></thead><tbody>${both.map(r => { const d = r.ps - r.settle; return `<tr><td class="l"><b>${esc(r.size)}</b></td><td>${won(r.settle)}</td><td>${won(r.ps)}</td><td class="${d > 0 ? 'pos' : d < 0 ? 'neg' : ''}">${wonS(d)}</td><td>${d === 0 ? '<span class="pill mute">같음</span>' : `<span class="dl-win ${d > 0 ? 'pp' : 'pk'}">${d > 0 ? '포이즌' : '크림'}</span>`}</td></tr>`; }).join('')}</tbody></table></div></div>`;
    const bestK = kR.filter(r => r.settle != null).sort((x, y) => y.settle - x.settle)[0], bestP = pR.sort((x, y) => y.ps - x.ps)[0];
    const all = [...kR.filter(r => r.settle != null).map(r => ({ w: '크림', s: r.size, v: r.settle, m: r.km })), ...pR.map(r => ({ w: '포이즌', s: r.size, v: r.ps, m: r.pm }))].sort((x, y) => y.v - x.v);
    const hits = (DO.mr.on || DO.mg.on) && fc ? R.reduce((n, r) => n + (r.kh ? 1 : 0) + (r.ph ? 1 : 0), 0) : null;
    sum = `<div class="kgrid">${card('크림 최고 정산', bestK ? won(bestK.settle) : '–', 'acc', bestK ? bestK.size + ' 사이즈' : '')}${card('포이즌 최고 정산', bestP ? won(bestP.ps) : '–', 'warn', bestP ? bestP.size + ' 사이즈' : '')}${card('가장 남는 곳', all[0] ? `${all[0].w} ${all[0].s}` : '–', 'pos', all[0] ? (all[0].m != null ? '마진 ' + wonS(all[0].m) : '정산 ' + won(all[0].v)) : '')}${card('기준 통과', hits == null ? '꺼짐' : hits + '개', hits ? 'pos' : '', hits == null ? '마진율 · 마진금 기준을 켜면 세어요' : '크림 + 포이즌 사이즈 수')}</div>`;
  }
  const res = `${sum}<div class="dl-two"><div class="dl-res pk"><div class="dl-rh"><span class="dl-logo pk">KREAM</span><b>크림 시세</b>${meta.k ? `<div class="dl-meta">${meta.k}</div>` : ''}</div>${kBody}</div>
    <div class="dl-res pp"><div class="dl-rh"><span class="dl-logo pp">POIZON</span><b>포이즌 시세</b>${meta.p ? `<div class="dl-meta">${meta.p}</div>` : ''}</div>${pBody}</div></div>${cmp}
    ${D && !busy ? `<p class="hint">${new Date(D.at).toLocaleString('ko-KR')} 조회 · 크림 정산은 설정한 수수료, 포이즌 정산은 위 포이즌 수수료로 계산해요.</p>` : ''}`;
  return `${xHead('크림 / 포이즌 동시 분석', '품번 하나로 크림과 포이즌의 사이즈별 시세 · 정산 · 마진을 나란히 봐요.')}<div class="dual">${hero}${res}</div>`;
}
async function runDual() {
  const raw = String(XS.dualQ || '').trim(); if (!raw) return xSet('품번을 넣어 주세요');
  if (!DO.pk && !DO.pp) return xSet('조회할 곳을 하나 이상 골라 주세요');
  const q = dualQ();
  if (!needExt()) return;
  XS.dualBusy = true;
  xRun(async () => {
    try {
      let pid = (q.match(/products\/(\d+)/) || [])[1] || (/^\d{2,8}$/.test(q) ? q : '');
      let kream = null, a = { sizes: [] }, codes = [q];
      if (DO.pk || pid) {
        if (!pid) {
          xSet('크림에서 품번 검색 중…');
          const tabId = await srcNav(`https://kream.co.kr/search?keyword=${encodeURIComponent(q)}`);
          const list = await inTab(tabId, kcList, [3]);
          if (!list || !list.length) throw new Error('크림에서 못 찾았어요' + (DO.conv && q !== raw ? ` (${q}로 찾음 — 품번 자동 변환을 끄고 다시 해 보세요)` : ''));
          pid = list[0].pid;
        }
        xSet(`크림 시세 모으는 중… ${DO.deep ? '(세부 검색 · 1~2분) ' : ''}크림 창을 닫지 마세요`);
        const p = { id: 'dual', pid, cost: dualCostFinal(), raw: null };
        await collectOne(p, DO.deep ? { days: 30, maxPages: 10 } : { days: Math.max(14, +S.win || 14), maxPages: 4 });
        a = analyze(p); const info = p.raw.info || {};
        codes = String(info.code || q).split('/').map(s => s.trim()).filter(Boolean);
        kream = DO.pk ? { pid, name: info.name || '', code: info.code || '', n7: a.n7 } : null;
        if (!DO.pk) a = { sizes: [] };
      }
      let poizon = null;
      if (DO.pp) {
        const code = codes.find(c => /\d/.test(c)) || q;
        if (/^https?:/i.test(code)) throw new Error('포이즌만 조회할 땐 품번을 넣어 주세요');
        xSet('포이즌에서 같은 품번 찾는 중…');
        try {
          const tabId = await srcNav(`https://kr.poizon.com/search?keyword=${encodeURIComponent(code)}`);
          await sleep(2000);
          const links = await inTab(tabId, kcPoizonLinks) || [];
          for (const l of links.slice(0, 3)) {
            await srcNav(l.url);
            const r = await inTab(work.tabId, kcPoizon);
            if (!r || !r.sizes.length) continue;
            r.ok = codes.some(c => ckey(r.title + ' ' + r.name).includes(ckey(c)));
            if (r.ok || !poizon) poizon = r;
            if (r.ok) break;
          }
        } catch (e) { xSet('포이즌 조회 실패: ' + e.message); }
      }
      const pz = {}; if (poizon) for (const s of poizon.sizes) if (s.price) { const k = ckey(s.kr); pz[k] = pz[k] == null ? s.price : Math.min(pz[k], s.price); }
      const keys = new Map(); for (const x of a.sizes) keys.set(ckey(x.o), x.o); for (const k of Object.keys(pz)) if (!keys.has(k)) keys.set(k, (poizon.sizes.find(s => ckey(s.kr) === k) || {}).kr || k);
      const rows = [...keys.entries()].map(([k, label]) => { const x = a.sizes.find(s => ckey(s.o) === k) || {}; return { size: label, n7: x.n7 || 0, sell: x.sell ?? null, minAsk: x.minAsk ?? null, settle: x.settle ?? null, pz: pz[k] ?? null }; }).sort((x, y) => sizeSort(x.size, y.size));
      XS.dual = { at: Date.now(), q: raw, cost: XS.dualCost, kream, pTried: DO.pp, poizon: poizon ? { url: poizon.url, name: poizon.name, title: poizon.title, ok: poizon.ok } : null, rows };
      dualHist = [XS.dual, ...dualHist.filter(h => h.q !== raw)].slice(0, 20); await store.set('dualHist', dualHist);
      xSet(`조회 끝 — 크림 ${kream ? a.sizes.length : 0}개 사이즈, 포이즌 ${poizon ? poizon.sizes.filter(s => s.price).length : 0}개 사이즈`);
    } finally { XS.dualBusy = false; }
  });
}

// ---------- 상품 재고조회 (무신사 · 지그재그 · ABC마트/그랜드스테이지) ----------
// 3.8.0: 사이트가 늘었고, '주문 가능 수량'(사이즈별 몇 개까지 살 수 있는지)을 보여줘요
const msNo = q => (String(q).match(/musinsa\.com\/(?:products|app\/goods)\/(\d+)/) || [])[1] || (/^\d{5,9}$/.test(String(q).trim()) ? String(q).trim() : '');
const STOCK_SITES = { musinsa: '무신사', zigzag: '지그재그', abc: 'ABC마트 · 그랜드스테이지' };
// 3.26: 주소만 넣으면 읽는 쇼핑몰 (✓ = 실제 상품 페이지로 확인함, 나머지는 공통 방식으로 시도)
// 3.29: 실제 상품 페이지에서 사이즈 · 품절을 읽어 확인한 쇼핑몰만 1로 표시해요 (1 = 화면에 보여주고 지원)
// 확인 못 한 곳(점검 중 · 구매 창에서만 옵션이 나오는 곳)은 0으로 두고 목록에는 보이지 않아요. 폴더 · 반스 · 호카 · 살로몬 · 11번가 · G마켓 · 옥션은 접속 불가 또는 판매 구조가 달라 뺐어요.
const GEN_SITES = [
  ['nike', '나이키', /(^|\.)nike\.com$/, 1], ['tnf', '노스페이스', /thenorthfacekorea\.co\.kr$/, 1], ['nb', '뉴발란스', /nbkorea\.com$/, 1], ['ssf', 'SSF샵', /ssfshop\.com$/, 1], ['kolon', '코오롱몰', /kolonmall\.com$/, 1],
  ['29cm', '29CM', /29cm\.co\.kr$/, 1], ['wconcept', 'W컨셉', /wconcept\.co\.kr$/, 1], ['lfmall', 'LF몰', /lfmall\.co\.kr$/, 1], ['lotteon', '롯데ON', /lotteon\.com$/, 1], ['ssg', 'SSG', /ssg\.com$/, 1], ['halfclub', '하프클럽', /halfclub\.com$/, 1],
  ['adidas', '아디다스', /adidas\.co\.kr$/, 1], ['sivillage', '신세계V(SI빌리지)', /(sivillage|shinsegaev)\.com$/, 1], ['eql', 'EQL', /eqlstore\.com$/, 1], ['kasina', '카시나', /kasina\.co\.kr$/, 1],
  ['shoemarker', '슈마커', /shoemarker\.co\.kr$/, 1], ['worksout', '웍스아웃', /worksout\.co\.kr$/, 1], ['hfashion', 'H패션몰', /hfashionmall\.com$/, 1], ['converse', '컨버스', /converse\.co\.kr$/, 1],
  ['puma', '푸마', /(^|\.)puma\.com$/, 1], ['asics', '아식스', /asics\.co\.kr$/, 1],
  ['handsome', '더한섬닷컴', /thehandsome\.com$/, 0], ['ably', '에이블리', /a-bly\.com$/, 1], ['hyundai', '더현대Hi', /thehyundai\.com$/, 1]
];
for (const [k, n] of GEN_SITES) STOCK_SITES[k] = n;
// 3.28: 쇼핑몰 표시 — 각 회사 로고 그림은 쓰지 않고, 킥스캔이 만든 글자 배지(약자 + 색)로 구분해요
const SITE_BADGE = { musinsa: ['M', '#111', '#3a3a3a'], zigzag: ['Z', '#ff2f86', '#ff7bb3'], abc: ['ABC', '#d0111b', '#f0454d'], nike: ['N', '#111', '#444'], tnf: ['TNF', '#c8102e', '#e94457'], nb: ['NB', '#b3112c', '#e0405a'], ssf: ['SSF', '#1c1c1c', '#4a4a4a'], kolon: ['K', '#1a1a1a', '#4b4b4b'],
  '29cm': ['29', '#111', '#3a3a3a'], wconcept: ['W', '#111', '#3a3a3a'], lfmall: ['LF', '#111', '#3a3a3a'], lotteon: ['ON', '#e0001b', '#ff4a5c'], ssg: ['SSG', '#e8402d', '#ff7a4d'], halfclub: ['H', '#ff5f00', '#ff9a4d'], adidas: ['A', '#111', '#444'],
  handsome: ['TH', '#2b2b2b', '#5a5a5a'], sivillage: ['SI', '#111', '#454545'], eql: ['EQL', '#2a2a2a', '#5c5c5c'], ably: ['a', '#ff3d6e', '#ff7f9f'], kasina: ['KS', '#111', '#444'], folder: ['F', '#1f1f1f', '#555'], shoemarker: ['S', '#f5c400', '#ffd84d', '#111'],
  worksout: ['WO', '#111', '#444'], hfashion: ['H', '#222', '#555'], converse: ['C', '#111', '#444'], vans: ['V', '#c8102e', '#e94457'], puma: ['P', '#111', '#444'], asics: ['AS', '#0b2a6f', '#2c56b8'], hoka: ['HK', '#1e3a8a', '#4f6fd1'],
  salomon: ['SA', '#111', '#444'], '11st': ['11', '#ff0038', '#ff5577'], gmarket: ['G', '#00b33c', '#3ad46b'], auction: ['A', '#e4002b', '#ff4d6a'], hyundai: ['H', '#24543a', '#3f8a62'] };
const SITE_DOM = { musinsa: 'musinsa.com', zigzag: 'zigzag.kr', abc: 'abcmart.a-rt.com', nike: 'nike.com', tnf: 'www.thenorthfacekorea.co.kr', nb: 'nbkorea.com', ssf: 'ssfshop.com', kolon: 'kolonmall.com', '29cm': '29cm.co.kr', wconcept: 'wconcept.co.kr', lfmall: 'lfmall.co.kr', lotteon: 'lotteon.com', ssg: 'ssg.com', halfclub: 'halfclub.com', adidas: 'adidas.co.kr', handsome: 'thehandsome.com', sivillage: 'shinsegaev.com', eql: 'eqlstore.com', ably: 'a-bly.com', kasina: 'kasina.co.kr', folder: 'folderstyle.com', shoemarker: 'shoemarker.co.kr', worksout: 'worksout.co.kr', hfashion: 'www.hfashionmall.com', converse: 'converse.co.kr', vans: 'vans.co.kr', puma: 'puma.com', asics: 'asics.co.kr', hoka: 'www.hoka.com', salomon: 'salomon.com', '11st': '11st.co.kr', gmarket: 'gmarket.co.kr', auction: 'auction.co.kr', hyundai: 'thehyundai.com' };
// 3.28.1: 쇼핑몰 아이콘은 각 사이트가 공개한 사이트 아이콘(파비콘)을 그때그때 불러와 보여줘요. 못 불러오면 글자 배지로 보여요.
const favOff = t => { const em = t.parentElement; t.remove(); if (em) em.classList.remove('img'); };
document.addEventListener('error', e => { const t = e.target; if (t && t.tagName === 'IMG' && t.classList.contains('ms-fav')) favOff(t); }, true);
document.addEventListener('load', e => { const t = e.target; if (!t || t.tagName !== 'IMG' || !t.classList.contains('ms-fav')) return; if (t.naturalWidth <= 16) favOff(t); else if (t.parentElement) t.parentElement.classList.add('ld'); }, true);   // 아이콘이 없으면 구글이 기본 지구본(16px)을 줘요 → 글자 배지로
const siteIco = k => { const b = SITE_BADGE[k] || [String(STOCK_SITES[k] || '?').slice(0, 1), '#64748b', '#94a3b8']; const d = SITE_DOM[k]; return `<em class="ms-ico${b[0].length > 2 ? ' sm' : ''}${d ? ' img' : ''}" style="--c1:${b[1]};--c2:${b[2]};--ct:${b[3] || '#fff'}" aria-hidden="true">${d ? `<img class="ms-fav" src="https://www.google.com/s2/favicons?domain=${d}&sz=64" alt="" loading="lazy" referrerpolicy="no-referrer">` : ''}<span>${esc(b[0])}</span></em>`; };
const genSiteOf = u => { try { const h = new URL(u).hostname; return GEN_SITES.find(x => x[2].test(h)) || null; } catch (e) { return null; } };
function stockTarget(q, site) {
  q = String(q || '').trim();
  let m;
  if ((m = q.match(/zigzag\.kr\/(?:catalog\/)?products\/(\d+)/))) return { site: 'zigzag', no: m[1] };
  if ((m = q.match(/((?:abcmart|grandstage)\.a-rt\.com)\/.*?prdtNo=(\d+)/))) return { site: 'abc', no: m[2], host: m[1] };
  if (msNo(q) && (site === 'musinsa' || /musinsa/.test(q))) return { site: 'musinsa', no: msNo(q) };
  { const g = /^https?:\/\//.test(q) && genSiteOf(q); if (g) return { site: g[0], url: q.split('#')[0], generic: true }; }
  if (/^\d{6,12}$/.test(q)) return site === 'zigzag' ? { site, no: q } : site === 'abc' ? { site, no: q, host: q.startsWith('10') ? 'grandstage.a-rt.com' : 'abcmart.a-rt.com' } : { site: 'musinsa', no: q };
  return null;
}
// 주문 가능 수량 칸
function orderable(s, R) {
  if (s.out) return '<span class="pill bad">품절 · 0개</span>';
  if (R.generic && s.qty == null) return `<span class="pill ok">구매 가능</span>${s.note ? ` <span class="small">재고 ${esc(s.note)}</span>` : ''}`;
  const cap = R.maxOrder ? ` <span class="small">(${R.maxScope === 'id' ? '아이디당' : '한 번에'} 최대 ${R.maxOrder}개)</span>` : '';
  if (s.qty != null) { const n = R.maxOrder ? Math.min(s.qty, R.maxOrder) : s.qty; return `<span class="pill ${s.qty <= 3 ? 'warn' : 'ok'}"><b>${n}개</b> 주문 가능</span>${R.maxOrder && s.qty > R.maxOrder ? ` <span class="small">(재고 ${s.qty}개 · ${R.maxScope === 'id' ? '아이디당' : '한 번에'} 최대 ${R.maxOrder}개)</span>` : ''}`; }
  if (s.min) return R.maxOrder && R.maxOrder < s.min ? `<span class="pill ok"><b>${R.maxOrder}개</b> 주문 가능</span> <span class="small">(재고 ${s.min}개 이상 · ${R.maxScope === 'id' ? '아이디당' : '한 번에'} 최대 ${R.maxOrder}개)</span>` : `<span class="pill ok"><b>${s.min}개 이상</b></span>${cap}`;
  return `<span class="pill ok">넉넉함</span>${cap}`;
}
function stockText(s) { return s.out ? '<span class="pill bad">품절</span>' : s.qty != null ? `<span class="pill ${s.qty <= 3 ? 'warn' : 'ok'}">${s.qty}개 남음</span>` : '<span class="pill ok">있음</span>'; }
function vMsStock() {
  const R = XS.ms, site = XS.msSite || 'musinsa';
  const list = XS.msList ? `<div class="panel"><h2>검색 결과 (${esc(STOCK_SITES[XS.msListSite] || '')})</h2><div class="sug">${XS.msList.map(x => `<button type="button" data-x="msPick" data-i="${esc(x.url || x.no)}"><b>${x.no}</b> ${esc(x.text.slice(0, 90))}</button>`).join('') || '<p class="hint">결과가 없어요</p>'}</div></div>` : '';
  let res = '';
  if (R) {
    const pr = R.price || {}, rs = R.site || 'musinsa';
    const hint = rs === 'musinsa' ? '무신사는 남은 수량을 <b>5개 이하일 때만</b> 숫자로 알려줘요. 그 위는 \'6개 이상\'으로 나와요.'
      : rs === 'zigzag' ? '지그재그는 남은 수량이 <b>적을 때만</b> 숫자로 알려줘요(많으면 \'넉넉함\'). 직진배송이 품절이어도 일반배송으로 살 수 있는 옵션이 있으니 그건 지그재그 화면에서 확인해 주세요.'
      : rs === 'abc' ? 'ABC마트·그랜드스테이지는 사이즈별 <b>실제 재고 수량</b>을 그대로 보여줘요.' : rs === 'nike' ? '나이키는 사이즈별 재고를 <b>많음 · 보통 · 적음 · 품절</b>로만 알려줘요 (정확한 개수는 안 알려줘요).' : `${esc(STOCK_SITES[rs] || '')}는 상품 화면에 보이는 대로 <b>구매 가능 / 품절</b>을 읽어요. 정확한 남은 개수는 쇼핑몰이 보여줄 때만 나와요.`;
    res = `<div class="panel"><div class="toolbar"><div><h2>${esc(R.brand ? R.brand + ' ' : '')}${esc(R.name || '')}</h2><p class="hint ms-hs">${siteIco(rs)}${esc(STOCK_SITES[rs])} · 상품번호 ${esc(R.goodsNo)} · ${new Date(R.at).toLocaleString('ko-KR')} 조회</p></div>
      <div class="row-btns"><a class="ghost" href="${esc(R.url || 'https://www.musinsa.com/products/' + R.goodsNo)}" target="_blank" rel="noopener">${esc(STOCK_SITES[rs])}에서 열기</a><button type="button" class="primary" data-x="msTrackAdd">추적에 추가</button><button type="button" class="ghost" data-x="msXl">엑셀</button></div></div>
      <div class="kgrid">${rs === 'musinsa' ? `${card('판매가', won(pr.salePrice))}${card('정가', won(pr.normalPrice), '', pr.discountRate ? pr.discountRate + '% 할인' : '')}${card('쿠폰 적용가', won(pr.couponPrice))}${card('최대 혜택가', won(pr.finalPrice || pr.couponPrice), 'pos', '무신사 화면 기준')}` : `${card('판매가', won(pr.salePrice))}${pr.normalPrice ? card('정가', won(pr.normalPrice)) : ''}`}${R.generic ? '' : card('구매 제한', R.maxOrder ? `${R.maxScope === 'id' ? '아이디당' : '한 번에'} ${R.maxOrder}개` : '없음')}${card('재고 있는 옵션', `${R.sizes.filter(s => !s.out).length} / ${R.sizes.length}`)}</div>
      <div class="tbl"><table><thead><tr><th class="l">옵션</th><th class="l">주문 가능 수량</th><th class="l">배송</th>${rs === 'musinsa' ? '<th>출고 예정</th><th>추가금</th>' : '<th>가격</th>'}</tr></thead><tbody>${R.sizes.map(s => `<tr${s.out ? ' class="mute"' : ''}><td class="l"><b>${esc(s.label)}</b></td><td class="l">${orderable(s, R)}</td><td class="l small">${esc(s.ship === 'NORMAL' ? '일반' : s.ship || '')}</td>${rs === 'musinsa' ? `<td>${esc(s.release || '')}</td><td>${s.extra ? '+' + won(s.extra) : ''}</td>` : `<td>${s.price ? won(s.price) : s.extra ? '+' + won(s.extra) : ''}</td>`}</tr>`).join('')}</tbody></table></div>
      <p class="hint">${hint}</p></div>`;
  }
  const chips = `<div class="ms-sites"><span class="sub">지원 쇼핑몰 ${3 + GEN_SITES.filter(x => x[3]).length}곳</span>${[['musinsa', '무신사', 1], ['zigzag', '지그재그', 1], ['abc', 'ABC마트', 1], ...GEN_SITES.filter(x => x[3]).map(x => [x[0], x[1], x[3]])].map(([k, n, ok]) => `<span class="ms-site${ok ? ' ok' : ''}${(R && R.site === k) ? ' on' : ''}" title="${esc(n)} · ${ok ? '확인된 쇼핑몰' : '공통 방식으로 시도 (시험)'}">${siteIco(k)}${esc(n)}${ok ? '' : '<i>시험</i>'}</span>`).join('')}</div>`;
  return `${xHead('상품 재고조회', '쇼핑몰 상품의 사이즈별 재고 · 품절 여부와 가격을 실시간으로 조회해요. 상품 주소를 붙여 넣으면 쇼핑몰은 알아서 골라요.')}
  <div class="panel"><div class="ioq"><select data-xk="msSite" aria-label="검색할 쇼핑몰">${['musinsa', 'zigzag', 'abc'].map(k => opt(k, STOCK_SITES[k], site === k)).join('')}</select><input data-xk="msQ" value="${esc(XS.msQ)}" placeholder="상품 주소, 상품번호, 또는 품번·상품명"><button type="button" class="primary" data-x="msRun"${XS.busy ? ' disabled' : ''}>조회</button></div>
    <p class="hint">상품 주소를 넣으면 쇼핑몰은 알아서 골라요. 상품번호 · 품번 · 상품명 검색은 무신사 · 지그재그 · ABC마트에서 돼요.</p>${chips}</div>${list}${res}
  <div class="panel"><div class="toolbar"><h2>조회 기록</h2><div class="row-btns">${msHist.length ? '<button type="button" class="ghost" data-x="msHistXl">엑셀</button><button type="button" class="ghost" data-x="msHistClear">기록 지우기</button>' : ''}</div></div>
    <div class="tbl"><table><thead><tr><th class="l">조회</th><th class="l">쇼핑몰</th><th class="l">상품</th><th>가격</th><th class="l">재고 있는 옵션</th><th></th></tr></thead><tbody>${msHist.slice(0, 50).map(h => `<tr><td class="l small">${new Date(h.at).toLocaleString('ko-KR')}</td><td class="l small"><span class="ms-hs">${siteIco(h.site || 'musinsa')}${esc(STOCK_SITES[h.site || 'musinsa'])}</span></td><td class="l name"><b>${esc(h.name || h.goodsNo)}</b><span class="code">${esc(h.goodsNo)}</span></td><td>${won(h.price && (h.price.finalPrice || h.price.salePrice))}</td><td class="l small">${esc(h.sizes.filter(s => !s.out).map(s => (s.size || s.label) + (s.qty != null ? `(${s.qty})` : '')).join(', ') || '전부 품절')}</td><td><button type="button" class="ghost tiny" data-x="msAgain" data-i="${esc(h.url || h.goodsNo)}">다시 조회</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">조회 기록이 없어요</td></tr>'}</tbody></table></div></div>`;
}
async function msLookup(no) {
  const tabId = await srcNav('https://www.musinsa.com/products/' + no);
  await sleep(800);
  const r = await inTab(tabId, kcMsStock, [no]);
  if (!r) throw new Error('재고를 못 읽었어요');
  r.at = Date.now();
  return r;
}
async function stockLookup(t) {
  if (t.url && GEN_SITES.some(x => x[0] === t.site)) {
    if (!(GEN_SITES.find(x => x[0] === t.site) || [])[3]) throw new Error(`${STOCK_SITES[t.site]}는 아직 사이즈 읽기 확인이 끝나지 않아 지원하지 않아요 — 같은 상품을 다른 지원 쇼핑몰 주소로 넣어 주세요`);
    const tabId = await srcNav(t.url); await sleep(1500);
    const r = await inTab(tabId, kcGenStock, [t.site], 'MAIN');
    if (!r) throw new Error('재고를 못 읽었어요');
    if (r.needLogin) throw new Error(`${STOCK_SITES[t.site]}는 로그인해야 사이즈를 볼 수 있어요 — 계정 연결 메뉴에서 ${STOCK_SITES[t.site]}에 로그인해 주세요`);
    if (!r.sizes.length) throw new Error((GEN_SITES.find(x => x[0] === t.site) || [])[3] ? `${STOCK_SITES[t.site]} 상품 페이지에서 사이즈 정보를 못 읽었어요 — 상품 상세 화면 주소인지 확인해 주세요` : `${STOCK_SITES[t.site]}는 아직 지원하지 않는 쇼핑몰이에요`);
    r.goodsNo = r.goodsNo || t.url; r.at = Date.now(); return r;
  }
  if (t.site === 'musinsa') return msLookup(t.no);
  const url = t.site === 'zigzag' ? 'https://zigzag.kr/catalog/products/' + t.no : `https://${t.host || 'grandstage.a-rt.com'}/product/new?prdtNo=${t.no}`;
  const tabId = await srcNav(url);
  await sleep(800);
  const r = await inTab(tabId, t.site === 'zigzag' ? kcZzStock : kcArtStock, [t.no]);
  if (!r) throw new Error('재고를 못 읽었어요');
  r.at = Date.now();
  return r;
}
function runMs(q) {
  q = (q || XS.msQ).trim(); if (!q) return xSet('상품 주소나 품번을 넣어 주세요');
  if (!needExt()) return;
  const site = XS.msSite || 'musinsa';
  xRun(async () => {
    const t = stockTarget(q, site);
    if (!t) {
      xSet(`${STOCK_SITES[site]} 검색 중…`);
      const url = site === 'zigzag' ? 'https://zigzag.kr/search?keyword=' + encodeURIComponent(q) : site === 'abc' ? 'https://grandstage.a-rt.com/display/search-word/result?searchWord=' + encodeURIComponent(q) : 'https://www.musinsa.com/search/goods?keyword=' + encodeURIComponent(q);
      const tabId = await srcNav(url);
      XS.msList = (site === 'musinsa' ? await inTab(tabId, kcMsSearch, [12]) : await inTab(tabId, kcShopSearch, [site, 12])) || [];
      if (site === 'musinsa') XS.msList.forEach(x => { x.url = 'https://www.musinsa.com/products/' + x.no; });
      XS.msListSite = site; XS.ms = null;
      await closeWork();
      return xSet(XS.msList.length ? `${XS.msList.length}개 찾았어요 — 조회할 상품을 고르세요` : `${STOCK_SITES[site]}에서 못 찾았어요`);
    }
    xSet(`${STOCK_SITES[t.site]} 재고 조회 중…`);
    XS.ms = await stockLookup(t); XS.msList = null;
    await closeWork();
    const key = h => (h.site || 'musinsa') + h.goodsNo;
    msHist = [XS.ms, ...msHist.filter(h => key(h) !== key(XS.ms))].slice(0, 100); await store.set('msHist', msHist);
    const inS = XS.ms.sizes.filter(s => !s.out);
    xSet(`조회 끝 — 옵션 ${XS.ms.sizes.length}개 중 ${inS.length}개 주문 가능${inS.some(s => s.qty != null) ? ` · 수량이 나온 옵션 합계 ${inS.reduce((a, s) => a + (s.qty || 0), 0)}개` : ''}`);
  });
}

// ---------- 사이즈 가격 · 재입고 추적 (무신사) ----------
function vMsTrack() {
  const rows = msTracks.map(t => {
    const last = t.last || {};
    const watch = t.sizes.length ? t.sizes.join(', ') : '전체';
    return `<tr><td><input type="checkbox" data-xk="trOn" data-i="${t.id}"${t.on ? ' checked' : ''} aria-label="추적 켜기"></td><td class="l name"><b>${esc(t.name || t.goodsNo)}</b><span class="code">${esc(STOCK_SITES[t.site || 'musinsa'] || '')} · ${esc(t.goodsNo)}</span></td><td class="l">${esc(watch)}</td><td class="l">${t.mode === 'price' ? '가격' : t.mode === 'restock' ? '재입고' : '가격 + 재입고'}</td><td>${t.target ? won(t.target) : '–'}</td>
      <td>${last.price ? won(last.price) : '–'}</td><td class="l small">${last.inStock ? esc(last.inStock.join(', ') || '없음') : '–'}</td><td class="l small">${t.at ? new Date(t.at).toLocaleString('ko-KR') : '아직'}</td>
      <td><div class="act"><button type="button" class="ghost" data-x="trEdit" data-i="${t.id}">수정</button><button type="button" class="ghost" data-x="trDel" data-i="${t.id}">삭제</button></div></td></tr>
      ${(t.log || []).length ? `<tr class="detail"><td colspan="9"><span class="small">${t.log.slice(-6).reverse().map(l => `${new Date(l.t).toLocaleString('ko-KR')} — ${esc(l.m)}`).join(' · ')}</span></td></tr>` : ''}`;
  }).join('');
  return `${xHead('상품 가격 · 재입고 추적', '원하는 가격 이하로 내려가거나, 품절이던 사이즈가 다시 들어오면 PC 알림을 띄워요. 무신사 · 지그재그 · ABC마트/그랜드스테이지', `<button type="button" class="ghost" data-x="trRun"${XS.busy || !msTracks.length ? ' disabled' : ''}>지금 한 번 확인</button>`)}
  <div class="panel"><h2 style="margin:0 0 10px">추적할 상품 추가</h2><div class="ioq"><input data-xk="trQ" value="${esc(XS.trQ || '')}" placeholder="상품 주소를 붙여넣으세요 (무신사 · 지그재그 · ABC마트/그랜드스테이지)" aria-label="추적할 상품 주소"><button type="button" class="primary" data-x="trAddUrl"${XS.busy ? ' disabled' : ''}>상품 불러오기</button></div>
    <p class="hint">주소를 넣고 '상품 불러오기'를 누르면 사이즈 목록이 나와요. 볼 사이즈·희망가를 고르면 추가돼요. 무신사는 상품번호만 넣어도 돼요.</p></div>
  <div class="panel"><div class="grid-set"><label>확인 간격 (위쪽 '설정'의 가격 추적 간격과 같아요)<select data-xk="trHours">${[0, 3, 6, 12, 24].map(h => opt(h, h ? (h === 24 ? '하루에 한 번' : h + '시간마다') : '끔', +S.trackHours === h)).join('')}</select></label></div>
    <p class="hint">'상품 재고조회'에서 조회한 상품도 '추적에 추가'로 넣을 수 있어요. PC와 킥스캔가 켜져 있어야 돌아요(창을 닫아도 작업 표시줄 트레이에서 계속 돌아요). 확인할 때 작은 쇼핑몰 창이 잠깐 열려요.</p></div>
  <div class="tbl"><table><thead><tr><th>켜기</th><th class="l">상품</th><th class="l">볼 사이즈</th><th class="l">알림</th><th>희망가</th><th>마지막 가격</th><th class="l">재고 있는 사이즈</th><th class="l">마지막 확인</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="9" class="empty">추적 중인 상품이 없어요</td></tr>'}</tbody></table></div>`;
}
// ---------- 3.17.1: 사용 가이드 ----------
// 3.31: 사용 가이드(GUIDE2 · vGuide)는 guide.js 에 있어요

// ---------- 3.16.1: 발매 정보 (슈프라이즈) ----------
let drops = { at: 0, now: [], soon: [], seen: [] };
const DROP_TABS = { now: ['발매 중', 'https://www.shoeprize.com/release'], soon: ['발매 예정', 'https://www.shoeprize.com/release/upcoming'] };
function vDrops() {
  const tab = XS.dropTab || 'now', L = drops[tab] || [], seen = new Set(drops.seenBefore || []);
  const q = String(XS.dropQ || '').trim().toLowerCase();
  const rows = L.filter(x => !q || (x.brand + ' ' + x.name + ' ' + x.code).toLowerCase().includes(q));
  const card = x => `<div class="drop"><a class="drop-img" href="${esc(x.href)}" target="_blank" rel="noopener">${x.img ? `<img src="${esc(String(x.img).replace(/([?&]w=)\d+/, '$1300'))}" alt="" loading="lazy">` : ''}</a><div class="drop-b"><span class="drop-brand">${esc(x.brand)}${!seen.has(x.href) && drops.seenBefore ? ' <span class="pill ok">NEW</span>' : ''}</span><b>${esc(x.name)}</b>${x.code ? `<span class="code">${esc(x.code)}</span>` : ''}<span class="drop-det">${esc(x.detail)}</span></div><div class="drop-side"><span class="drop-date">${esc(x.date)}</span><div class="row-btns"><a class="ghost tiny" href="${esc(x.href)}" target="_blank" rel="noopener">발매처 보기</a>${x.code ? `<a class="ghost tiny" href="https://kream.co.kr/search?keyword=${encodeURIComponent(x.code)}" target="_blank" rel="noopener">크림 시세</a>` : ''}</div></div></div>`;
  return `${xHead('발매 정보', '슈프라이즈(shoeprize.com)에 올라온 한정판 발매 · 응모 정보를 모아 봐요. 품번이 있으면 크림 시세로 바로 가요.', `<button type="button" class="primary" data-x="dropLoad"${XS.busy ? ' disabled' : ''}>${drops.at ? '새로 불러오기' : '발매 정보 불러오기'}</button>`)}
  <div class="panel"><div class="toolbar"><div class="segtabs">${Object.entries(DROP_TABS).map(([k, [t]]) => `<button type="button" class="${tab === k ? 'on' : ''}" data-x="dropTab" data-v="${k}">${t} <small>${(drops[k] || []).length}</small></button>`).join('')}</div><input data-xk="dropQ" value="${esc(XS.dropQ || '')}" placeholder="브랜드 · 상품명 · 품번 검색" style="max-width:280px"></div>
    ${drops.at ? `<p class="hint">${new Date(drops.at).toLocaleString('ko-KR')} 기준 · 출처: 슈프라이즈</p>` : ''}
    ${rows.length ? `<div class="drops">${rows.map(card).join('')}</div>` : `<p class="empty">${drops.at ? '이 목록에 지금 올라온 발매 정보가 없어요.' : '<b>발매 정보 불러오기</b>를 누르세요. 작은 창이 잠깐 열려요.'}</p>`}</div>`;
}
async function runDrops(auto) {
  const prev = new Set([...(drops.now || []), ...(drops.soon || [])].map(x => x.href));
  const out = {};
  for (const [k, [t, url]] of Object.entries(DROP_TABS)) {
    if (!auto) xSet(`슈프라이즈 ${t} 불러오는 중…`);
    const tabId = await srcNav(url); await sleep(1500);
    const r = await inTab(tabId, kcShoePrize, []);
    out[k] = (r && r.items) || [];
  }
  await closeWork();
  const all = [...out.now, ...out.soon], fresh = prev.size ? all.filter(x => !prev.has(x.href)) : [];
  drops = { at: Date.now(), now: out.now, soon: out.soon, seenBefore: prev.size ? [...prev] : null };
  await store.set('drops', drops);
  if (fresh.length) { try { chrome.notifications.create('drop-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: `새 발매 정보 ${fresh.length}개`, message: fresh.slice(0, 3).map(x => x.name).join(' · ').slice(0, 180), priority: 1 }); } catch (e) {} }
  if (!auto) xSet(`발매 중 ${out.now.length}개 · 발매 예정 ${out.soon.length}개${fresh.length ? ` · 새로 올라온 것 ${fresh.length}개` : ''}`);
}

// 3.14.1: 추적 화면에서 주소로 바로 추가 (무신사 · 지그재그 · ABC마트/그랜드스테이지)
const trHost = u => { try { return new URL(u).host; } catch (e) { return undefined; } };
function trAddUrl() {
  const q = String(XS.trQ || '').trim();
  if (!q) return xSet('추적할 상품 주소를 넣어 주세요');
  const t0 = stockTarget(q, 'musinsa');
  if (!t0) return xSet(`상품 주소를 알아보지 못했어요 — 상품 상세 화면의 주소를 넣어 주세요 (지원: 무신사 · 지그재그 · ABC마트 · ${GEN_SITES.filter(x => x[3]).map(x => x[1]).join(' · ')})`);
  if (!needExt()) return;
  xRun(async () => {
    xSet(`${STOCK_SITES[t0.site]} 상품 불러오는 중…`);
    const R = await stockLookup(t0); await closeWork();
    if (!R || !R.sizes || !R.sizes.length) return xSet('사이즈 정보를 못 읽었어요 — 품절이거나 주소가 맞는지 확인이 필요해요');
    const t = msTracks.find(x => x.goodsNo === R.goodsNo && (x.site || 'musinsa') === t0.site) || { id: uid(), site: t0.site, host: t0.host || (t0.site === 'abc' ? trHost(R.url) : undefined), url: t0.generic ? t0.url : undefined, goodsNo: R.goodsNo, name: `${R.brand ? R.brand + ' ' : ''}${R.name || ''}`.trim(), sizes: [], mode: 'both', target: 0, on: true, log: [] };
    XS.trQ = '';
    xSet(`${t.name || t.goodsNo} — 볼 사이즈와 희망가를 골라 주세요`);
    trackDialog(t, R);
  });
}
function trackDialog(t, R) {
  const sizes = R ? R.sizes.map(s => s.size || s.label) : (t.allSizes || t.sizes);
  invDialog(t.id ? '추적 수정' : '추적에 추가', `<p class="hint">${esc(t.name || t.goodsNo)}</p><div class="dgrid"><label>알림<select name="mode">${opt('both', '가격 + 재입고', t.mode === 'both')}${opt('price', '가격만', t.mode === 'price')}${opt('restock', '재입고만', t.mode === 'restock')}</select></label><label>희망가 (이 가격 이하면 알림)<input type="number" name="target" min="0" value="${t.target || ''}"></label>
    <div class="wide"><span class="small">볼 사이즈 (안 고르면 전체)</span><div class="chips">${sizes.map(s => `<label class="chk chip"><input type="checkbox" name="s_${esc(s)}"${t.sizes.includes(s) ? ' checked' : ''}> ${esc(s)}</label>`).join('')}</div></div></div>`, async fd => {
    t.mode = fd.mode; t.target = Math.round(num(fd.target)); t.sizes = sizes.filter(s => fd['s_' + s] === 'on'); t.allSizes = sizes;
    if (!msTracks.includes(t)) msTracks.unshift(t);
    await store.set('msTracks', msTracks);
    // 3.14.1: 확인 간격이 '끔'이면 추가해도 아무 일도 안 일어나서, 처음 추가할 때 6시간마다로 켜요
    if (!(+S.trackHours > 0)) { S.trackHours = 6; await store.set('settings', S); try { await setTrackAlarm(); } catch (e) {} const sh = $('#s_trackHours'); if (sh) sh.value = '6'; xSet('추가했어요 — 확인 간격을 6시간마다로 켰어요 (아래에서 바꿀 수 있어요)'); }
    else xSet('추가했어요');
    renderX();
  });
}
async function runMsTrack(auto) {
  const list = msTracks.filter(t => t.on);
  if (!list.length) { if (!auto) xSet('켜 둔 추적이 없어요'); return; }
  let hits = 0;
  for (const [i, t] of list.entries()) {
    if (!auto) xSet(`${i + 1} / ${list.length} 확인 중 — ${t.name || t.goodsNo}`);
    try {
      const r = await stockLookup({ site: t.site || 'musinsa', no: t.goodsNo, host: t.host, url: t.url });
      const price = r.price ? (r.price.finalPrice || r.price.couponPrice || r.price.salePrice) : null;
      const watch = s => !t.sizes.length || t.sizes.includes(s.size || s.label);
      const inStock = r.sizes.filter(s => !s.out && watch(s)).map(s => s.size || s.label);
      const before = t.last || {};
      const msgs = [];
      if (t.mode !== 'restock' && t.target && price && price <= t.target && !(before.price && before.price <= t.target)) msgs.push(`희망가 이하 ${won(price)}`);
      if (t.mode !== 'restock' && before.price && price && price <= before.price - 1000) msgs.push(`가격 내림 ${won(before.price)} → ${won(price)}`);
      if (t.mode !== 'price' && before.inStock) { const back = inStock.filter(s => !before.inStock.includes(s)); if (back.length) msgs.push(`재입고 ${back.join(', ')}`); }
      t.last = { price, inStock }; t.at = Date.now(); t.name = t.name || r.name;
      t.log = (t.log || []).concat([{ t: Date.now(), m: msgs.length ? msgs.join(' · ') : `${won(price)} · 재고 ${inStock.length}개 사이즈` }]).slice(-40);
      if (msgs.length) { hits++; try { chrome.notifications.create('ms-' + t.id + '-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: `${STOCK_SITES[t.site || 'musinsa'] || '추적'} — ${(t.name || '').slice(0, 30)}`, message: msgs.join(' · '), priority: 2 }); } catch (e) {} }
    } catch (e) { t.log = (t.log || []).concat([{ t: Date.now(), m: '확인 실패: ' + e.message }]).slice(-40); }
    await store.set('msTracks', msTracks);
  }
  await closeWork();
  if (!auto) xSet(`끝 — ${list.length}개 확인, 알림 ${hits}개`);
}

// ---------- 주문내역 관리 (무신사) ----------
function vOrders() {
  const L = records.filter(r => r.musinsaId || /^ms-/.test(r.id)).sort((a, b) => String(b.buyDate).localeCompare(String(a.buyDate)));
  const done = new Set((typeof INV !== 'undefined' ? INV.lots : []).map(l => l.srcKey).filter(Boolean));
  const total = L.reduce((s, r) => s + (+r.cost || 0) * (+r.qty || 1), 0);
  return `${xHead('주문내역 관리 (무신사)', '무신사 주문을 기간별로 불러와서 보고, 엑셀로 받거나 재고관리에 입고해요.', `<select data-xk="ordDays"><option value="7">최근 7일</option><option value="30">최근 1개월</option><option value="90" selected>최근 3개월</option><option value="180">최근 6개월</option></select><button type="button" class="primary" data-x="ordSync"${XS.busy ? ' disabled' : ''}>주문 동기화</button><button type="button" class="ghost" data-x="ordXl"${L.length ? '' : ' disabled'}>엑셀 다운로드</button><button type="button" class="ghost" data-x="ordInv">재고관리 입고 모드</button>`)}
  <div class="kgrid k3">${card('주문 상품', L.length + '개')}${card('결제 금액 합계', won(total))}${card('재고 입고 안 한 것', L.filter(r => !done.has(r.id)).length + '개', L.some(r => !done.has(r.id)) ? 'warn' : '')}</div>
  <div class="tbl"><table><thead><tr><th class="l">주문일</th><th class="l">상품</th><th class="l">옵션</th><th>수량</th><th>개당 결제</th><th class="l">상태</th><th class="l">재고</th></tr></thead><tbody>${L.map(r => `<tr><td class="l">${esc(r.buyDate)}</td><td class="l name"><b>${esc(r.name)}</b><span class="code">${esc(String(r.memo || '').match(/주문 (\S+)/)?.[1] || '')}</span></td><td class="l">${esc(r.size)}</td><td>${r.qty || 1}</td><td>${won(+r.cost)}</td><td class="l small">${esc(String(r.memo || '').replace(/^무신사 주문 \S+ · /, ''))}</td><td class="l">${done.has(r.id) ? '<span class="pill ok">입고함</span>' : '<span class="pill mute">안 함</span>'}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">아직 불러온 주문이 없어요. <b>주문 동기화</b>를 누르세요 (무신사에 로그인돼 있어야 해요).</td></tr>'}</tbody></table></div>
  <p class="hint">무신사 후기는 왼쪽 <b>후기 자동 작성</b>에서 모아 봐요.</p>`;
}
// 3.15.1: 후기 자동 작성 · 등록 — 구매확정된 주문에 별점 5점, 상품 상태·포장·배송 만족 취지의 글을 만들어 등록해요
const RV_A = ['상품 상태 깨끗하고 정품 그대로 잘 받았어요.', '주문한 그대로 문제없이 잘 받았습니다.', '하자 없이 깔끔한 상태로 도착했어요.', '사진이랑 똑같은 제품으로 잘 받았어요.', '박스랑 구성품 모두 이상 없이 왔어요.', '새 상품 상태 그대로 꼼꼼하게 포장돼서 왔어요.'];
const RV_B = ['배송도 빨라서 좋았어요.', '포장도 꼼꼼해서 만족합니다.', '배송이 생각보다 빨리 와서 좋았습니다.', '포장 상태도 좋고 배송도 빨랐어요.', '주문하고 금방 받아서 좋았어요.', '받아보니 마음에 들어요.'];
const RV_C = ['다음에도 무신사에서 구매할게요.', '만족스러운 구매였습니다.', '좋은 가격에 잘 산 것 같아요.', '믿고 살 수 있어서 좋네요.', '전체적으로 만족합니다.', '재구매 의사 있어요.'];
function rvMakeText(no, name, opt) {
  let h = 0; for (const c of String(no) + String(name)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  const pick = (a, k) => a[(h >>> k) % a.length];
  const sz = String(opt || '').trim() && String(opt).length <= 20 ? ` ${String(opt).trim()} 사이즈 주문했고` : '';
  return `${sz ? sz.trim() + ' ' : ''}${pick(RV_A, 0)} ${pick(RV_B, 5)} ${pick(RV_C, 11)}`.replace(/\s+/g, ' ').trim();
}
async function rvSubmitOne(r, D) {
  let tabId = await srcNav('https://www.musinsa.com/mypage/myreview');
  const o = await inTab(tabId, kcMsReviewOpen, [r.no, r.name], 'MAIN');
  if (!o || !o.ok) return { ok: false, msg: o && o.why === 'nobtn' ? '후기 작성 버튼 없음 (이미 썼거나 기간 지남)' : '그 주문의 작성 버튼을 못 찾음' };
  await sleep(2500);
  tabId = work.tabId;
  const f = await inTab(tabId, kcReviewFill, [D.text, D.star || 5], 'MAIN');
  if (!f || !f.ok) return { ok: false, msg: '후기 글 칸을 못 찾음' };
  if (!f.star) return { ok: false, msg: '별점을 못 골라서 등록하지 않음' };
  await sleep(700);
  const sb = await inTab(tabId, kcReviewSubmit, [], 'MAIN');
  return sb && sb.ok ? { ok: true, msg: '등록됨' } : { ok: false, msg: (sb && sb.msg) || '등록 버튼을 못 누름' };
}
async function rvRunAll(only) {
  const R = XS.rv; if (!R) return xSet('먼저 작성 가능한 후기를 불러와 주세요');
  const rows = rvRows(R).filter(r => !only || r.no === only).filter(r => !(rvDraft[r.no] || {}).done);
  if (!rows.length) return xSet('등록할 후기가 없어요');
  let ok = 0, fail = 0;
  for (const [i, r] of rows.entries()) {
    if (XS.stop) break;
    const D = rvDraft[r.no] = { star: 5, ...(rvDraft[r.no] || {}) };
    if (!String(D.text || '').trim()) D.text = rvMakeText(r.no, r.name, r.opt);
    xSet(`${i + 1} / ${rows.length} 후기 등록 중 — ${r.name.slice(0, 24)}`);
    let res; try { res = await rvSubmitOne(r, D); } catch (e) { res = { ok: false, msg: e.message }; }
    D.res = res.msg; D.done = !!res.ok; D.at = Date.now(); res.ok ? ok++ : fail++;
    await store.set('rvDraft', rvDraft); renderX();
    await sleep(3000 + Math.random() * 3000);
  }
  await closeWork();
  xSet(`후기 등록 끝 — 등록 ${ok}개${fail ? ` · 실패 ${fail}개 (줄마다 이유가 적혀 있어요)` : ''}`);
}
const rvRows = R => R ? R.list.map(o => { const f = kFlat(o); const pk = keys => kPick(f, keys); return { name: pk(['goodsName', 'goodsNm', 'productName', 'name']), brand: pk(['brandName', 'brandNm']), opt: pk(['optionName', 'optionValue', 'option', 'goodsOption']), no: pk(['orderNo', 'ordNo', 'orderOptionNo']), date: pk(['orderDate', 'ordDate', 'purchaseDate', 'deliveryCompleteDate']), point: pk(['maxPoint', 'point', 'rewardPoint', 'savePoint', 'reviewPoint', 'expectedPoint']), until: pk(['writableEndDate', 'endDate', 'deadline', 'writeEndDate', 'expireDate']) }; }) : [];
// 후기 도우미: 작성 가능한 후기 목록을 불러와서 보여주고, 후기 화면을 바로 열어요. 글을 만들어 등록까지 해요.
function vReviews() {
  const R = XS.rv;
  const rows = rvRows(R); for (const r of rows) { const D = rvDraft[r.no] = { star: 5, ...(rvDraft[r.no] || {}) }; if (!String(D.text || '').trim()) D.text = rvMakeText(r.no, r.name, r.opt); }
  const left = rows.filter(r => !(rvDraft[r.no] || {}).done).length;
  return `<div class="panel"><div class="toolbar"><div><h2 style="display:block">후기 자동 작성 · 등록</h2><p class="hint">구매확정된 주문의 후기를 <b>별점 5점</b>과 상품 상태·포장·배송 만족 글로 자동으로 써서 <b>등록까지</b> 해요. 글은 주문마다 다르게 만들어지고, 등록 전에 고칠 수 있어요.</p></div>
    <div class="row-btns"><button type="button" class="${R ? 'ghost' : 'primary'}" data-x="rvLoad"${XS.busy ? ' disabled' : ''}>작성 가능한 후기 불러오기</button>${R && left ? `<button type="button" class="primary" data-x="rvAll"${XS.busy ? ' disabled' : ''}>${left}개 전부 자동 등록</button>` : ''}<a class="ghost" href="https://www.musinsa.com/mypage/myreview" target="_blank" rel="noopener">후기 화면 열기</a><a class="ghost" href="https://www.musinsa.com/order/order-list" target="_blank" rel="noopener">구매확정 (주문 내역)</a></div></div>
    ${R ? `<p class="hint">${new Date(R.at).toLocaleString('ko-KR')} · 작성 가능 ${R.count ? R.count.writableCount : R.list.length}개 · 작성한 후기 ${R.count ? R.count.totalCount : '–'}개</p>
    ${rows.length ? `<div class="tbl"><table><thead><tr><th class="l">상품</th><th class="l">옵션</th><th class="l">주문일</th><th>적립금</th><th class="l">작성 마감</th><th></th></tr></thead><tbody>${rows.map(r => `<tr><td class="l name"><b>${esc(r.brand ? r.brand + ' ' : '')}${esc(r.name)}</b><span class="code">${esc(r.no)}</span></td><td class="l">${esc(r.opt)}</td><td class="l small">${esc(String(r.date).slice(0, 10))}</td><td>${r.point ? won(num(r.point)) : '–'}</td><td class="l small">${esc(String(r.until).slice(0, 10))}</td><td><a class="ghost tiny" href="https://www.musinsa.com/mypage/myreview" target="_blank" rel="noopener">후기 쓰기</a></td></tr>
      <tr class="rvdraft"><td colspan="6" class="l"><div class="row-btns"><select data-xk="rvStar" data-i="${esc(r.no)}">${[5, 4, 3, 2, 1].map(n => opt(n, '★'.repeat(n) + ' ' + n + '점', +((rvDraft[r.no] || {}).star || 5) === n)).join('')}</select>
        <textarea data-xk="rvText" data-i="${esc(r.no)}" rows="2" placeholder="후기 글" style="flex:1;min-width:240px">${esc((rvDraft[r.no] || {}).text || '')}</textarea>
        ${(rvDraft[r.no] || {}).done ? '<span class="pill ok">등록됨</span>' : `<button type="button" class="primary" data-x="rvOne" data-i="${esc(r.no)}"${XS.busy ? ' disabled' : ''}>등록</button><button type="button" class="ghost tiny" data-x="rvFill" data-i="${esc(r.no)}" data-n="${esc(r.name)}"${XS.busy ? ' disabled' : ''}>넣기만</button>`}</div>${(rvDraft[r.no] || {}).res && !(rvDraft[r.no] || {}).done ? `<p class="small neg">지난 시도: ${esc(rvDraft[r.no].res)}</p>` : ''}</td></tr>`).join('')}</tbody></table></div>
      <details class="srcmore"><summary>받은 원본 데이터 보기 (표가 이상하면 이 내용을 보내 주세요)</summary><textarea rows="6" readonly>${esc(JSON.stringify(R.list.slice(0, 5), null, 1).slice(0, 8000))}</textarea></details>` : '<p class="empty">지금 후기를 쓸 수 있는 주문이 없어요. 배송이 끝난 주문이 생기면 여기에 나와요.</p>'}` : ''}
    <p class="hint">구매확정은 되돌릴 수 없어서 버튼으로 자동 처리하지 않아요. '구매확정 (주문 내역)'으로 무신사 화면을 열어 직접 눌러 주세요.</p></div>`;
}

// ---------- 크림 판매 · 구매 · 보관 · 발송 ----------
const KM = {
  ksell: { t: '판매 내역 · 입찰', page: 'selling', tabs: ['판매 입찰', '진행 중', '종료'], d: '내 판매 입찰(일반 판매), 진행 중, 종료된 판매를 불러와요.' },
  kbuy: { t: '구매 내역', page: 'buying', tabs: ['입찰 중', '진행 중', '종료'], d: '크림에서 구매 입찰·진행·종료된 내역을 불러와요.' },
  kinv: { t: '보관판매', page: 'inventory', tabs: ['신청', '보관 중', '종료'], d: '보관 신청·보관 중·종료 내역을 불러와요.' },
  kship: { t: '발송관리', page: 'selling', tabs: ['진행 중'], d: '판매가 체결돼서 크림으로 보내야 하는 상품을 모아 봐요.' }
};
KM.ksell.t = '일반판매 입찰 & 관리'; KM.kinv.t = '보관판매 관리';
// 3.2: 취소·반송·불합격·페널티처럼 문제가 생긴 건만 모아 봐요
const K_TROUBLE = /취소|반송|회수|불합격|패널티|페널티|거절|실패|반품|미입고|검수\s*보류|보류/;
const KPICK = {
  name: ['translated_name', 'name', 'product_name', 'title'], code: ['style_code', 'model_number', 'model_no'], size: ['option', 'size', 'option_name', 'size_name'],
  price: ['price', 'ask_price', 'bid_price', 'amount', 'sell_price', 'total_amount', 'settlement_amount'], status: ['status_display', 'display_status', 'status_text', 'status_name', 'status_title', 'status'],
  date: ['date_created', 'created_at', 'date_updated', 'order_date', 'date'], exp: ['date_expires', 'expires_at', 'expired_at', 'due_date', 'deadline'], pid: ['product_id'], id: ['id', 'order_id', 'ask_id', 'bid_id', 'item_id', 'uuid']
};
function kFlat(o, depth = 0, out = {}, pre = '') {
  if (depth > 3 || !o || typeof o !== 'object') return out;
  for (const [k, v] of Object.entries(o)) {
    if (v == null) continue;
    if (typeof v !== 'object') { out[pre + k] = v; if (!(k in out)) out[k] = v; }
    else if (!Array.isArray(v)) kFlat(v, depth + 1, out, pre + k + '.');
  }
  return out;
}
function kPick(f, keys) { for (const k of keys) if (f[k] != null && f[k] !== '') return f[k]; for (const k of keys) { const hit = Object.keys(f).find(x => x.endsWith('.' + k)); if (hit && f[hit] !== '') return f[hit]; } return ''; }
function kArrays(o, depth = 0, out = []) {
  if (depth > 4 || !o || typeof o !== 'object') return out;
  if (Array.isArray(o)) { if (o.length && o.every(x => x && typeof x === 'object' && !Array.isArray(x)) && Object.keys(o[0]).length >= 3) out.push(o); else o.forEach(x => kArrays(x, depth + 1, out)); return out; }
  for (const v of Object.values(o)) kArrays(v, depth + 1, out);
  return out;
}
// 3.10.44: 크림 판매 내역(/api/o/asks)이 화면 조각(display_type) 모양으로 바뀌었어요 → 조각에서 판매 번호 · 상품명 · 사이즈 · 가격 · 날짜를 읽어요
function kSduiRows(cap) {
  const out = [];
  for (const c of cap || []) {
    const m = String(c.url).match(/\/asks\/?\?.*tab=(\w+)/); if (!m || !c.data || !Array.isArray(c.data.items)) continue;
    const tab = m[1];
    for (const it of c.data.items) {
      if (!it || !/product_list_info/.test(String(it.display_type || ''))) continue;
      const s = JSON.stringify(it), id = (s.match(/\/my\/selling\/(\d+)/) || [])[1]; if (!id) continue;
      const texts = []; const walk = o => { if (!o || typeof o !== 'object') return; if (o.default_variation && typeof o.default_variation.text === 'string') texts.push({ t: o.default_variation.text.trim(), type: o.text_type || o.default_variation.text_type || '' }); for (const k in o) if (k !== 'default_variation') walk(o[k]); }; walk(it);
      const T = texts.filter(x => x.t);
      const price = T.find(x => /^[\d,]+\s*원$/.test(x.t)), date = T.find(x => x.type === 'date' || /^\d{4}-\d{2}-\d{2}T/.test(x.t));
      const name = T.find(x => x !== price && x !== date && /[가-힣A-Za-z]{2}/.test(x.t) && x.t.length >= 6);
      const rest = T.filter(x => x !== price && x !== date && x !== name);
      const size = rest.find(x => x.t.length <= 12 && !/완료|중|대기|취소|만료|정산|발송|검수/.test(x.t));
      const status = rest.find(x => /완료|중|대기|취소|만료|정산|발송|검수|입찰/.test(x.t));
      out.push({ id, name: name ? name.t : '', size: size ? size.t : '', price: price ? +price.t.replace(/[^\d]/g, '') : '', status: status ? status.t : (tab === 'bidding' ? '판매 입찰 중' : tab === 'pending' ? '진행 중' : '종료'), date: date ? date.t.slice(0, 10) : '', exp: tab === 'bidding' && date ? date.t.slice(0, 10) : '', tab, pid: '', code: '' });
    }
  }
  return out;
}
function kRows(cap) {
  { const sd = kSduiRows(cap); if (sd.length) { const info = (typeof abAskInfo !== 'undefined' && abAskInfo) || {}; return sd.map(r => ({ ...r, ...(info[r.id] || {}), price: r.price, size: r.size || (info[r.id] || {}).size || '' })); } }
  const rows = new Map();
  for (const c of cap || []) {
    if (/counts|filters/.test(c.url)) continue;
    for (const arr of kArrays(c.data)) for (const o of arr) {
      const f = kFlat(o);
      const r = {}; for (const [k, keys] of Object.entries(KPICK)) r[k] = kPick(f, keys);
      if (!r.name && !r.price) continue;
      r.price = num(r.price) || null; r.src = c.url.replace(/^https:\/\/api\.kream\.co\.kr/, '');
      r.pid = String(r.pid || f['product.id'] || f['release.id'] || '');
      rows.set(String(r.id || JSON.stringify(f).slice(0, 200)), r);
    }
  }
  return [...rows.values()];
}
function kCounts(text) { const m = String(text || '').replace(/\s+/g, ' ').match(/((?:판매 입찰|입찰 중|진행 중|종료|신청|보관 중|전체|발송요청|발송완료|입고대기|입고완료|검수 중|검수완료|창고이동)\s*\d+)/g); return m ? [...new Set(m)].slice(0, 14) : []; }
// 3.22: 판매 입찰 · 구매 · 발송 — 검색 · 상태 탭 · 크림 숫자와 비교 · 매입가 / 정산 예상 / 예상 마진
function kCostOf(r, C) {
  try { if (typeof INV === 'undefined' || !r.code) return null; const it = kItemOf(r.code, r.pid); if (!it) return null; const sz = kItemSize(it, r.size); const st = itemStock(it, C); const x = sz && st.by[sz]; if (x && x.qty) return Math.round(x.value / x.qty); const lots = INV.lots.filter(l => l.itemId === it.id && (!sz || l.size === sz) && l.cost > 0); return lots.length ? Math.round(lots.reduce((a, l) => a + l.cost, 0) / lots.length) : null; } catch (e) { return null; }
}
const kDday = d => { if (!d) return null; const t = new Date(String(d).slice(0, 10) + 'T00:00:00'); if (isNaN(t)) return null; return Math.round((t - new Date(today() + 'T00:00:00')) / 864e5); };
function kTabOf(r) { const st = String(r.status || ''); if (/종료|완료|취소|만료|정산/.test(st)) return 'end'; const d = kDday(r.exp); if (d != null && d <= 3) return 'soon'; return 'live'; }
function vKream(v) {
  const K = KM[v], D = XS.km[K.page];
  let all = D ? kRows(D.cap) : [];
  if (v === 'kship') all = all.filter(r => /발송|배송|입고 대기|체결/.test(String(r.status)));
  const F = (XS.kf = XS.kf || {})[v] = (XS.kf[v] || { q: '', tab: 'all' });
  const C = typeof invCalc === 'function' && typeof INV !== 'undefined' ? invCalc() : null;
  const R = all.map(r => { const cost = v === 'ksell' && C ? kCostOf(r, C) : null, settle = v === 'ksell' && r.price ? r.price - feeOf(r.price) : null; return { ...r, cost, settle, margin: cost != null && settle != null ? settle - cost : null, tab: kTabOf(r), dd: kDday(r.exp) }; });
  const base = R.filter(r => kSearchHit(r, F.q));
  const cnt = k => k === 'all' ? base.length : base.filter(r => r.tab === k).length;
  let rows = base.filter(r => F.tab === 'all' || r.tab === F.tab);
  // 3.30: 묶어보기 — 같은 상품 · 사이즈 · 가격 · 상태를 한 줄로 (×개수)
  const canGroup = v === 'ksell' || v === 'kinv';
  if (canGroup && F.group) { const G = new Map(); for (const r of rows) { const k = [r.name, r.code, r.size, r.price, r.status].join('|'); const g = G.get(k); if (g) { g.n++; if (r.dd != null && (g.dd == null || r.dd < g.dd)) { g.dd = r.dd; g.exp = r.exp; } } else G.set(k, { ...r, n: 1 }); } rows = [...G.values()]; }
  if (canGroup && F.hideWait) rows = rows.filter(r => !/대기/.test(String(r.status)));
  // 크림 화면 숫자와 읽은 줄 수 비교
  const counts = D ? kCounts(D.text) : [];
  const kSum = counts.filter(c => !/^전체/.test(c)).reduce((a, c) => a + (+(c.match(/\d+$/) || [0])[0]), 0);
  const stale = D && Date.now() - D.at > 30 * 60e3;
  const warn = D && kSum > all.length ? `<div class="kw-warn">${ico('refresh')}<span><b>크림과 수가 달라요.</b> 프로그램 ${all.length}건 / 실제 크림 ${kSum}건 — <b>크림에서 불러오기</b>를 다시 눌러 주세요.</span></div>` : stale ? `<div class="kw-warn soft">${ico('cal')}<span>${Math.round((Date.now() - D.at) / 60e3)}분 전에 불러온 내역이에요. 바뀐 게 있을 수 있어요.</span></div>` : '';
  const ddPill = r => r.dd == null ? '<span class="sub">–</span>' : `<span class="pill ${r.dd < 0 ? 'mute' : r.dd <= 1 ? 'bad' : r.dd <= 3 ? 'warn' : 'mute'}">${r.dd < 0 ? '만료' : r.dd === 0 ? '오늘' : 'D-' + r.dd}</span><small class="sub"> ${esc(String(r.exp).slice(5, 10).replace('-', '.'))}</small>`;
  const head = `<th class="l">상품</th><th class="l">사이즈</th><th>${v === 'ksell' ? '내 입찰가' : '가격'}</th>${v === 'ksell' ? '<th class="l">크림 최저가</th><th>포이즌</th><th>매입가</th><th>정산 예상</th><th>예상 마진</th>' : ''}<th class="l">상태</th><th class="l">${v === 'kship' ? '발송 기한' : '만료'}</th>${v === 'ksell' ? '<th></th>' : '<th class="l">날짜</th>'}`;
  const tbl = rows.length ? `<div class="tbl kh-tbl"><table><thead><tr>${head}</tr></thead><tbody>${rows.map(r => `<tr${r.tab === 'soon' ? ' class="kw-soon"' : ''}><td class="l name"><b>${esc(r.name)}</b>${r.n > 1 ? ` <span class="pill acc">×${r.n}</span>` : ''}<span class="code">${esc(r.code)}</span></td><td class="l">${esc(r.size)}</td><td><b>${won(r.price)}</b></td>${v === 'ksell' ? `${bidCell(r)}<td>${r.cost != null ? won(r.cost) : '<span class="sub">–</span>'}</td><td>${won(r.settle)}</td><td class="${r.margin > 0 ? 'pos' : r.margin < 0 ? 'neg' : ''}">${r.margin != null ? `<b>${wonS(r.margin)}</b>` : '<span class="sub">–</span>'}</td>` : ''}<td class="l">${kStPill(r.status)}</td><td class="l small">${ddPill(r)}</td>${v === 'ksell' ? `<td>${r.pid ? `<a class="ghost tiny" href="https://kream.co.kr/products/${esc(r.pid)}" target="_blank" rel="noopener">상품</a> <a class="ghost tiny" href="https://kream.co.kr/my/selling" target="_blank" rel="noopener">입찰 변경</a>` : ''}</td>` : `<td class="l small">${esc(String(r.date).slice(0, 16).replace('T', ' '))}</td>`}</tr>`).join('')}</tbody></table></div>`
    : `<div class="panel dl-empty">${ico(v === 'kship' ? 'truck' : 'gavel')}<span>${D ? (all.length ? '이 탭 · 검색어에 맞는 줄이 없어요.' : '크림에 내역이 없어요.') : '<b>크림에서 불러오기</b>를 누르세요. 크림에 로그인돼 있어야 해요.'}</span></div>`;
  const live = R.filter(r => r.tab !== 'end');
  const kpis = v === 'ksell' ? `${card('진행 중 입찰', live.length + '건', 'acc')}${card('입찰 금액 합계', won(live.reduce((a, r) => a + (+r.price || 0), 0)), 'violet')}${card('정산 예상 합계', won(live.reduce((a, r) => a + (r.settle || 0), 0)), 'warn')}${card('만료 임박 (3일)', R.filter(r => r.tab === 'soon').length + '건', R.some(r => r.tab === 'soon') ? 'neg' : '')}`
    : `${card(v === 'kship' ? '발송할 건' : '전체', all.length + '건', 'acc')}${card('금액 합계', won(all.reduce((a, r) => a + (+r.price || 0), 0)), 'violet')}${card('기한 임박 (3일)', R.filter(r => r.tab === 'soon').length + '건', R.some(r => r.tab === 'soon') ? 'neg' : '')}`;
  return `${xHead(K.t, K.d, `<button type="button" class="primary" data-x="kLoad" data-v="${v}"${XS.busy ? ' disabled' : ''}>${ico('refresh')}크림에서 불러오기</button>${all.length ? `<button type="button" class="ghost" data-x="kXl" data-v="${v}">엑셀</button>` : ''}${v === 'ksell' && all.length ? `<button type="button" class="ghost" data-x="bidCmp"${XS.busy ? ' disabled' : ''}>최저가 · 포이즌 비교</button><button type="button" class="ghost" data-x="kToPre">종료된 판매 → 우선출고 정산</button>` : ''}<a class="ghost" href="https://kream.co.kr/my/${K.page}" target="_blank" rel="noopener">크림에서 열기</a>`)}
  ${warn}
  <div class="panel kh-bar"><div class="kh-row"><span class="sub">${D ? `마지막 불러옴 ${new Date(D.at).toLocaleString('ko-KR')}${counts.length ? ' · 크림 화면: ' + esc(counts.join(' · ')) : ''}` : '아직 불러온 내역이 없어요'}</span></div>
    <label class="dl-search kh-q">${ico('search')}<input data-xk="kfQ" data-i="${v}" value="${esc(F.q)}" placeholder="상품명 · 품번 · 사이즈 · 상태 검색" autocomplete="off"></label>
    <div class="kh-row"><div class="kh-tabs2">${[['all', '전체'], ['live', '진행 중'], ['soon', v === 'kship' ? '기한 임박' : '만료 임박'], ['end', '종료']].map(([k, t]) => `<button type="button" class="${F.tab === k ? 'on' : ''}" data-x="kfTab" data-i="${v}" data-v="${k}">${t} <span>${cnt(k)}</span></button>`).join('')}</div>${canGroup ? `<label class="chk"><input type="checkbox" data-x="kfGroup" data-i="${v}"${F.group ? ' checked' : ''}> 묶어보기 (같은 상품 · 사이즈 · 가격)</label><label class="chk"><input type="checkbox" data-x="kfWait" data-i="${v}"${F.hideWait ? ' checked' : ''}> 대기 중인 줄 숨기기</label>` : ''}</div></div>
  <div class="kgrid">${kpis}</div>
  ${tbl}
  ${v === 'ksell' && all.length ? '<p class="hint"><b>매입가</b>는 재고관리의 같은 품번 · 사이즈 평균 매입가, <b>정산 예상</b>은 설정한 크림 수수료로 계산해요. <b>최저가 · 포이즌 비교</b>를 누르면 지금 크림 최저가와 포이즌 가격이 채워져요(상품 15개까지). 입찰가 바꾸기는 크림 화면에서 해요.</p>' : ''}
  ${v === 'kinv' ? `<div class="panel"><p class="hint">보관 신청을 자동으로 넣는 매크로는 왼쪽 <b>보관판매 매크로</b>에 있어요. <button type="button" class="ghost" data-x="goView" data-v="kmacro">매크로 열기</button></p></div>` : ''}
  ${D && D.cap.length ? `<details class="srcmore"${XS.kRaw ? ' open' : ''}><summary>받은 원본 데이터 보기 (화면이 이상하면 이 내용을 보내 주세요)</summary><textarea rows="8" readonly>${esc(JSON.stringify(D.cap.map(c => ({ url: c.url, data: c.data })), null, 1).slice(0, 20000))}</textarea></details>` : ''}
  <p class="hint">${v === 'kship' ? '송장 입력 · 발송 처리는 크림 화면에서 해요. 발송 기한을 넘기면 페널티가 있어요.' : ''}</p>`;
}
// ---------- 3.10.34: 크림 판매 정산 → 재고관리 매출 (판매가 · 크림 수수료 · 정산금액 · 매입원가) ----------
// 일반 판매: 크림 마이페이지 → 판매 내역 '종료'의 정산완료 건을 하나씩 열어(크림 화면이 불러오는 판매 상세) 판매가와 정산금액을 읽어요.
// 보관 판매: 보관판매 내역에서 판매완료 · 정산완료가 된 상품은 '크림 보관'(우선출고)을 그 판매가로 정산해요.
// 읽기만 해요. 한 번 넣은 판매는 크림 판매 번호로 기억해서 두 번 넣지 않아요.
let kSales = { done: [], skip: {} };
const kOutOf = (it, size, kind, settled) => INV.outs.filter(o => o.itemId === it.id && o.size === size && o.kind === kind && !!o.settled === settled);
function kSplitOne(o) {   // 여러 개짜리 출고에서 1개를 떼어 새 출고로 (정산은 1개씩)
  if ((+o.qty || 0) <= 1) return o;
  const c0 = (o.costs || [])[0]; const one = { ...o, id: uid(), at: Date.now(), qty: 1, costs: c0 ? [{ ...c0, qty: 1 }] : [], events: [] };
  o.qty -= 1; if (c0) { c0.qty -= 1; if (c0.qty <= 0) o.costs.shift(); }
  INV.outs.push(one); return one;
}
async function kSaleRecord(x) {
  // x: { id, code, size, price, payout, date, storage }
  const it = kItemOf(x.code, x.pid); if (!it) return { skip: '재고관리에 같은 모델번호 상품이 없어요' };
  const size = kItemSize(it, x.size); if (!size) return { skip: `재고관리 상품에 ${x.size} 사이즈가 없어요` };
  const kream = INV.partners.find(p => p.id === 'p-kream') || INV.partners.find(p => p.kind === 'sell');
  const fee = x.payout > 0 ? Math.max(0, x.price - x.payout) : '';
  const date = String(x.date || today()).slice(0, 10);
  if (x.storage) {
    const pre = kOutOf(it, size, 'pre', false)[0];
    if (!pre) return { skip: '정산할 크림 보관 출고가 없어요' };
    const o = kSplitOne(pre); Object.assign(o, { settled: true, settleDate: date, price: x.price, fee, kreamSaleId: x.id, memo: String(o.memo || '') + ' · 크림 보관 판매 정산(자동)' });
    return { ok: true };
  }
  let have = (invCalc().stock.get(it.id + '|' + size) || { qty: 0 }).qty;
  if (have < 1) {   // 예전에 '재고 수량 직접 수정'으로 뺀 게 있으면(판매한 걸 직접 뺀 경우) 그걸 이 판매로 바꿔요
    const l = INV.lots.find(l => l.itemId === it.id && l.size === size && (l.adjQty || 0) > 0);
    if (l) { l.adjQty -= 1; (l.events = l.events || []).push({ t: '조정 → 크림 판매', d: today(), q: 1 }); have = 1; }
  }
  if (have < 1) return { skip: '재고관리에 남은 재고가 없어요 (입고가 빠졌거나 다른 데로 나갔어요)' };
  const costs = allocate(it.id, size, 1, invCalc()); if (!costs) return { skip: '재고를 못 잡았어요' };
  INV.outs.push({ id: uid(), at: Date.now(), date, itemId: it.id, size, qty: 1, price: x.price, partnerId: kream ? kream.id : '', kind: 'out', settled: true, settleDate: date, ship: 0, fee, costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: '크림 판매 정산(자동)', kreamSaleId: x.id });
  return { ok: true };
}
async function kSalesSync() {
  if (typeof INV === 'undefined') throw new Error('재고관리를 먼저 열어 주세요');
  const known = new Set([...INV.outs.map(o => o.kreamSaleId).filter(Boolean).map(String), ...kSales.done.map(String)]);
  let n = 0; const skips = [];
  // 1) 일반 판매
  const slot = { winId: null, tabId: null };
  try {
    const t = await srcNav('https://kream.co.kr/my/selling?tab=finished', slot); await sleep(5000);
    const tu = await chrome.tabs.get(t).catch(() => null); if (tu && /\/login/.test(tu.url || '')) throw new Error('크림 로그인이 풀려 있어요');
    const g = await chrome.tabs.sendMessage(t, { cmd: 'kc-my' }).catch(() => null);
    const raw = JSON.stringify(((g && g.cap) || []).filter(c => /\/asks\/?\?.*tab=finished/.test(c.url)).map(c => c.data));
    const ids = [...new Set([...raw.matchAll(/kream\.co\.kr\/my\/selling\/(\d+)/g)].map(m => m[1]))].filter(id => !known.has('A' + id));
    for (const id of ids.slice(0, 40)) {
      await srcNav(`https://kream.co.kr/my/selling/${id}`, slot); await sleep(3500);
      const g2 = await chrome.tabs.sendMessage(slot.tabId, { cmd: 'kc-my' }).catch(() => null);
      const c = ((g2 && g2.cap) || []).find(c => new RegExp('/asks/' + id + '(\\?|$)').test(c.url));
      const d = c && c.data; if (!d) { skips.push(`판매 ${id}: 상세를 못 읽었어요`); continue; }
      if (d.status !== 'payout_completed') continue;   // 정산완료만
      const pb = d.price_breakdown || {}, rel = (d.product || {}).release || {};
      const x = { id: 'A' + id, code: rel.style_code || '', pid: d.product_id || '', size: typeof d.option === 'string' ? d.option : ((d.product_option || {}).key || ''), price: +pb.price || +d.price || 0, payout: +pb.total_payout || 0, date: d.date_paid || d.date_updated || d.date_created };
      const r = await kSaleRecord(x);
      if (r.ok) { n++; kSales.done.push(x.id); } else { kSales.skip[x.id] = `${rel.translated_name || rel.name || x.code} ${x.size} ${won(x.price)}: ${r.skip}`; skips.push(kSales.skip[x.id]); }
    }
  } finally { if (slot.winId) { try { await chrome.windows.remove(slot.winId); } catch (e) {} } }
  // 2) 보관 판매 (판매완료 · 정산완료)
  try { await kInvRead(); } catch (e) {}
  if (kInv && kInv.items) for (const i of kInv.items.filter(i => /^(sold|payout_completed)$/.test(i.status) && !known.has('S' + i.id))) {
    const x = { id: 'S' + i.id, code: i.code, pid: i.pid, size: i.size, price: +i.price || 0, payout: +i.payout || 0, date: i.date, storage: true };
    if (!x.price) { skips.push(`보관 판매 ${i.name} ${i.sizeName || i.size}: 판매가를 못 읽었어요`); continue; }
    const r = await kSaleRecord(x);
    if (r.ok) { n++; kSales.done.push(x.id); } else { kSales.skip[x.id] = `${i.name} ${i.sizeName || i.size}: ${r.skip}`; skips.push(kSales.skip[x.id]); }
  }
  kSales.done = kSales.done.slice(-3000);
  await invSave(); await store.set('kreamSales', kSales);
  return { n, skips };
}
// 3.10.33: 보관판매 관리 — 크림 마이페이지 보관판매 내역을 상품·사이즈·상태별로 (매크로 비교와 같은 방식으로 읽어요)
function vKInv() {
  const K = KM.kinv, L = kInv && kInv.items ? kInv.items : null;
  const stOrder = ['발송요청', '발송완료', '입고대기', '입고완료', '검수 중', '검수완료', '창고이동', '판매대기', '판매 중', '판매완료', '보관만료', '회수 중', '정산완료', '취소완료', '불합격 반송', '회수완료'];
  const cnt = {}; if (L) for (const i of L) { const n = i.statusName || i.status; cnt[n] = (cnt[n] || 0) + 1; }
  const names = Object.keys(cnt).sort((a, b) => (stOrder.indexOf(a) + 99) % 199 - (stOrder.indexOf(b) + 99) % 199);
  const f = XS.kinvSt || '';
  const g = new Map(); if (L) for (const i of L) { const n = i.statusName || i.status; if (f ? n !== f : KINV_OUT.test(i.status)) continue; const k = [i.code, i.name, i.sizeName || i.size, n].join('|'); const x = g.get(k) || { code: i.code, name: i.name, size: i.sizeName || i.size, st: n, out: KINV_OUT.test(i.status), q: 0, d: '' }; x.q++; if (String(i.date) > x.d) x.d = String(i.date); g.set(k, x); }
  const rows = [...g.values()].sort((a, b) => a.name.localeCompare(b.name) || String(a.size).localeCompare(String(b.size), 'ko', { numeric: true }));
  const live = L ? L.filter(i => !KINV_OUT.test(i.status)).length : 0;
  return `${xHead(K.t, '크림 마이페이지 → 보관판매의 신청 · 보관 중 · 종료 내역을 상품 · 사이즈 · 상태별로 보여줘요. 읽기만 해요.', `<button type="button" class="primary" data-x="kInvLoad"${SQ.kinvBusy || SQ.run ? ' disabled' : ''}>${SQ.kinvBusy ? '읽는 중…' : '크림에서 불러오기'}</button>${L ? '<button type="button" class="ghost" data-x="kInvXl">엑셀</button>' : ''}<a class="ghost" href="https://kream.co.kr/my/inventory" target="_blank" rel="noopener">크림에서 열기</a>`)}
  ${SQ.kinvMsg ? `<p class="iflash${/못|풀려|오류|실패/.test(SQ.kinvMsg) ? ' neg' : ''}">${esc(SQ.kinvMsg)}</p>` : ''}
  ${L ? `<div class="panel"><p class="hint">${new Date(kInv.at).toLocaleString('ko-KR')} 불러옴 · 크림 보관 <b>${live}개</b> (취소 · 반송 · 회수 ${L.length - live}개 따로)</p>
    <div class="chips"><button type="button" class="chip${!f ? ' on' : ''}" data-x="kinvSt" data-v="">진행 중 전체 ${live}</button>${names.map(n => `<button type="button" class="chip${f === n ? ' on' : ''}" data-x="kinvSt" data-v="${esc(n)}">${esc(n)} ${cnt[n]}</button>`).join('')}</div></div>
  <div class="panel">${rows.length ? `<div class="tbl"><table><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th class="l">상태</th><th>개수</th><th class="l">최근 신청일</th></tr></thead><tbody>${rows.map(r => `<tr class="${r.out ? 'err' : ''}"><td class="l name"><b>${esc(r.name)}</b><span class="code">${esc(r.code && r.code !== '-' ? r.code : '모델번호 없음')}</span></td><td class="l"><b>${esc(r.size)}</b></td><td class="l"><span class="pill ${r.out ? 'bad' : /판매완료|정산완료/.test(r.st) ? 'ok' : 'mute'}">${esc(r.st)}</span></td><td><b>${r.q}</b></td><td class="l small">${esc(String(r.d).slice(0, 10))}</td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">이 상태의 상품이 없어요.</p>'}</div>`
  : `<div class="panel"><p class="empty"><b>크림에서 불러오기</b>를 누르세요. 크림에 로그인돼 있어야 해요.</p></div>`}
  <div class="panel"><p class="hint">보관 신청을 자동으로 넣는 매크로와 재고관리 맞추기는 왼쪽 <b>보관판매 매크로</b>에 있어요. <button type="button" class="ghost" data-x="goView" data-v="kmacro">매크로 열기</button></p></div>`;
}
function runKream(v) {
  if (!needExt()) return;
  const K = KM[v];
  xRun(async () => {
    xSet('크림 ' + K.t + ' 여는 중… (작은 창이 열려요)');
    const tabId = await srcNav('https://kream.co.kr/my/' + K.page);
    const walk = await inTab(tabId, kcKreamWalk, [K.tabs]);
    if (/login/.test((walk && walk.url) || '')) throw new Error('크림 로그인이 필요해요');
    const got = await Promise.race([chrome.tabs.sendMessage(tabId, { cmd: 'kc-my' }), sleep(15000).then(() => null)]).catch(() => null);
    XS.km[K.page] = { at: Date.now(), cap: (got && got.cap) || [], text: walk ? walk.text : '' };
    await store.set('kreamMy', XS.km);
    const n = kRows(XS.km[K.page].cap).length;
    xSet(`불러왔어요 — ${n}건`);
  });
}

// 3.2: 여러 내역을 한 번에 (판매·구매·보관)
function runKreamMany(pages) {
  if (!needExt()) return;
  xRun(async () => {
    let n = 0;
    for (const page of pages) {
      if (page === 'inventory') { xSet(`크림 보관판매 읽는 중… (${pages.indexOf(page) + 1}/${pages.length})`); try { const r = await kInvRead(); n += r.items.length; } catch (e) { xSet('보관판매를 못 읽었어요: ' + e.message); } continue; }   // 3.10.33
      const v = Object.keys(KM).find(k => KM[k].page === page); const K = KM[v];
      xSet(`크림 ${K.t} 여는 중… (${pages.indexOf(page) + 1}/${pages.length})`);
      const tabId = await srcNav('https://kream.co.kr/my/' + page);
      const walk = await inTab(tabId, kcKreamWalk, [K.tabs]);
      if (/login/.test((walk && walk.url) || '')) throw new Error('크림 로그인이 필요해요 — 계정 연결에서 크림을 로그인해 주세요');
      const got = await Promise.race([chrome.tabs.sendMessage(tabId, { cmd: 'kc-my' }), sleep(15000).then(() => null)]).catch(() => null);
      XS.km[page] = { at: Date.now(), cap: (got && got.cap) || [], text: walk ? walk.text : '' };
      n += kRows(XS.km[page].cap).length;
    }
    await store.set('kreamMy', XS.km);
    xSet(`불러왔어요 — ${n}건`);
  });
}
// ---------- 화면 ----------
// ---------- 보관 신청 매크로 (재고 → 크림 보관 가능 확인 → 1~2개씩 '신청 계속' 반복) ----------
// 크림 화면 확인(2026-11-11): 보관 신청하기 → /search/stock 에서 모델번호 검색 → /inventory/상품번호 → 사이즈별 + 버튼 → '신청 계속'
const SQ = { run: false, timer: null, msg: '' };
let stockQ = [], stockOpt = { chunk: 1, gap: 7, cap: 2000, final: true }, stockTries = { d: '', n: 0 };
// 3.7.5: 줄마다 '넣을 수량'(내 재고 이하)을 정해요. 안 정했으면 재고 전부.
const sqWant = e => Math.max(0, Math.min(e.want == null ? e.total : +e.want, e.total));
const sqLeft = e => sqWant(e) - (e.passed || 0);
// 3.10.23: 화면엔 '남은 재고'(지금 재고관리에 있는 수)와 '더 넣을 수량'으로 보여줘요. 안에서는 목표(want) = 신청 완료 + 더 넣을 수량.
const sqHave = (e, C) => { try { C = C || invCalc(); return e.itemId ? (C.stock.get(e.itemId + '|' + e.size) || { qty: 0 }).qty : Math.max(0, (e.total || 0) - (e.passed || 0)); } catch (x) { return Math.max(0, (e.total || 0) - (e.passed || 0)); } };
// 3.7.5: 재고 사이즈 ↔ 크림 보관 사이즈 맞추기. 'XL(105)'→XL, '2XL'→XXL, FREE→ONE SIZE 처럼 확실한 것만 자동으로, 나머지(예: 270 ↔ US 7)는 직접 골라요.
function sizeKey(x) {
  let k = String(x || '').toUpperCase().replace(/\s+/g, '').replace(/\(.*?\)/g, '');
  if (/^(FREE|F|ONESIZE|OS|ONE|FREESIZE)$/.test(k)) return 'ONESIZE';
  const m = k.match(/^(\d)XL$/); if (m) k = 'X'.repeat(+m[1]) + 'L';
  if (/^(XXS|XS|S|M|L|XL|XXL|XXXL|XXXXL)$/.test(k)) return k;
  return k;
}
function matchKSize(size, list) {
  if (!list || !list.length) return size;
  const ex = list.filter(k => String(k).trim().toUpperCase() === String(size).trim().toUpperCase()); if (ex.length === 1) return ex[0];
  const sk = sizeKey(size); const m = list.filter(k => sizeKey(k) === sk); return m.length === 1 ? m[0] : '';
}
const sqReady = e => !!e.pid && !!(e.ksize || !(e.ksizes && e.ksizes.length));
// ---------- 3.10.19: 크림 보관판매 내역 ↔ 매크로 기록 · 재고관리 비교 ----------
// 크림 실제 수 = 보관판매에 들어간 상품 수(취소완료 · 불합격 반송 · 회수완료는 빼요 — 그건 다시 내 손에 돌아온 것).
let kInv = null;   // { at, items:[{code,size,status,statusName,name}], counts }
const KINV_OUT = /^(canceled|return_on_failure|retrieved)$/;
const kInvCodes = e => [...new Set([e.code, ...(e.codes || [])].map(c => codeKey(c)).filter(Boolean))];
function kInvOf(e) {
  if (!kInv || !kInv.items) return null;
  // 3.10.37: 재고관리 상품의 모델번호 전부(A/B) + 모델번호 없는 크림 상품은 연결한 상품 번호로도 맞춰요
  const it = e.itemId && typeof INV !== 'undefined' ? itemOf(e.itemId) : null;
  const cs = [...new Set([...kInvCodes(e), ...(it ? String(it.code || '').split('/').map(c => codeKey(c)).filter(Boolean) : [])])], sz = sizeKey(e.ksize || e.size), sz2 = sizeKey(e.size);
  const L = kInv.items.filter(i => (cs.includes(codeKey(i.code)) || kCodeParts(i.code).some(x => cs.includes(x)) || (it && kPidOk(it, i.code && i.code !== '-' ? i.code : '', i.pid))) && (sizeKey(i.size) === sz || sizeKey(i.size) === sz2 || sizeKey(i.sizeName) === sz));
  const live = L.filter(i => !KINV_OUT.test(i.status));
  const by = {}; for (const i of live) by[i.statusName || i.status] = (by[i.statusName || i.status] || 0) + 1;
  return { n: live.length, out: L.length - live.length, by };
}
const sqPreQty = e => (typeof INV === 'undefined' || !e.itemId) ? 0 : INV.outs.filter(o => o.itemId === e.itemId && o.size === e.size && o.kind === 'pre').reduce((a, o) => a + (+o.qty || 0) - (+o.retQty || 0), 0);
async function kInvRead() {
  const slot = { winId: null, tabId: null };
  try {
    const t = await srcNav('https://kream.co.kr/my/inventory', slot);
    await sleep(2500);
    const tu = await chrome.tabs.get(t).catch(() => null);
    if (tu && /kream\.co\.kr\/login/.test(tu.url || '')) throw new Error('크림 로그인이 풀려 있어요 — 계정 연결에서 크림 로그인을 다시 해 주세요');
    // 3.10.20: 업데이트 직후엔 킥스캔 확장이 아직 새 파일을 안 읽었을 수 있어요 → 킥스캔가 킥스캔 확장을 다시 읽게 하는 동안(최대 1분) 기다렸다가 다시 해요
    let x = null;
    for (let i = 0; i < 4; i++) {
      try { [x] = await execT({ target: { tabId: t }, func: kcKreamInvAll, world: 'MAIN' }, 120000); break; }
      catch (er) { if (!/없는 기능|kcKreamInvAll/.test(er.message) || i === 3) throw er; SQ.kinvMsg = '킥스캔 확장이 새 버전을 읽는 중이라 잠깐 기다려요… (최대 1분)'; try { renderX(); } catch (e2) {} await sleep(20000); }
    }
    const r = x && x.result;
    if (!r) throw new Error('크림 보관판매 내역을 못 읽었어요');
    if (r.error) throw new Error(r.error);
    if (r.short) throw new Error(`크림 보관 내역 ${r.short}개를 다 못 읽었어요 — 다시 눌러 주세요 (다 읽어야 비교해요)`);
    kInv = { at: Date.now(), items: r.items, counts: r.counts, via: r.via };
    await store.set('kreamInvSnap', kInv);
    return kInv;
  } finally { if (slot.winId) { try { await chrome.windows.remove(slot.winId); } catch (e) {} } }
}
// 3.10.21: 크림 보관판매 전체(수작업으로 올린 것 포함) ↔ 재고관리. 모델번호(없으면 크림 상품 번호)와 사이즈로 맞춰요.
// 3.10.37: 크림 상품 번호로 잇는 건 크림에 모델번호가 없는 상품('-')이거나 사장님이 직접 연결한 경우만 (검색으로 잘못 잡힌 색상 다른 상품과 안 섞이게)
const kPidOk = (it, code, pid) => !!(pid && it.kreamPid && String(it.kreamPid) === String(pid) && (!code || it.kreamPidBy === 'user'));
// 3.10.40: 크림 모델번호에도 '/'가 들어가요(예: B-RGW12GWS-RYK/RYN) → 양쪽을 '/'로 나눠서 한 조각이라도 똑같으면 같은 상품 (5글자 이상 조각만)
const kCodeParts = c => String(c || '').split('/').map(x => codeKey(x)).filter(x => x.length >= 5);
const kCodeSame = (a, b) => { const A = kCodeParts(a), B = new Set(kCodeParts(b)); return codeKey(a) && codeKey(a) === codeKey(b) || A.some(x => B.has(x)); };
const kItemOf = (code, pid) => INV.items.find(it => (code && kCodeSame(code, it.code)) || kPidOk(it, code, pid));
const kItemSize = (it, size) => it ? ((it.sizes || []).find(s => sizeKey(s) === sizeKey(size)) || '') : '';
const kPreOf = (itemId, size) => INV.outs.filter(o => o.itemId === itemId && o.size === size && o.kind === 'pre').reduce((a, o) => a + (+o.qty || 0) - (+o.retQty || 0), 0);
function kAlignRows() {
  if (!kInv || !kInv.items || typeof INV === 'undefined') return [];
  const g = new Map();
  for (const i of kInv.items) {
    if (KINV_OUT.test(i.status)) continue;
    const code = i.code && i.code !== '-' ? i.code : '';
    const key = (code ? codeKey(code) : 'P' + i.pid) + '|' + sizeKey(i.size);
    let r = g.get(key); if (!r) g.set(key, r = { key, code, pid: i.pid, name: i.name, size: i.size, sizeName: i.sizeName, n: 0, by: {} });
    r.n++; r.by[i.statusName || i.status] = (r.by[i.statusName || i.status] || 0) + 1;
  }
  const C = invCalc(), seen = new Set();
  const out = [...g.values()].map(r => { const it = kItemOf(r.code, r.pid), size = kItemSize(it, r.size); if (it && size) seen.add(it.id + '|' + size); const pre = it && size ? kPreOf(it.id, size) : 0, have = it && size ? (C.stock.get(it.id + '|' + size) || { qty: 0 }).qty : 0; return { ...r, it, isize: size, pre, have }; });
  // 재고관리엔 크림 보관으로 나갔는데 크림엔 없는 것
  for (const o of INV.outs) { if (o.kind !== 'pre') continue; const k2 = o.itemId + '|' + o.size; if (seen.has(k2)) continue; seen.add(k2); const it = itemOf(o.itemId); if (!it) continue; const pre = kPreOf(it.id, o.size); if (pre <= 0) continue; out.push({ key: 'I' + k2, code: String(it.code || '').split('/')[0], pid: it.kreamPid || '', name: itName(it), size: o.size, sizeName: o.size, n: 0, by: {}, it, isize: o.size, pre, have: (C.stock.get(k2) || { qty: 0 }).qty }); }
  return out.map(r => ({ ...r, diff: r.n - r.pre, stale: !!(r.it && INV.outs.some(o => o.itemId === r.it.id && o.size === r.isize && o.kind === 'pre' && (o.at || 0) > kInv.at)) })).map(r => r.stale && r.diff < 0 ? { ...r, diff: 0, staleNote: true } : r);   // 3.10.36: 크림을 읽은 뒤 매크로가 신청한 건 다음에 읽을 때 맞춰봐요
}
// 재고관리 '크림 보관' 출고를 want개로 맞춰요. 모자라는 재고는 cost(매입가)로 입고를 같이 만들어요(크림에 직접 올린 상품).
async function invAlign(r, cost) {
  let it = r.it;
  if (!it) {
    it = { id: uid(), code: r.code || ('KREAM-' + r.pid), name: String(r.name || '').slice(0, 80), brand: '', cat: '', sub: '', sizes: [], barcodes: {}, memo: '크림 보관판매에서 불러옴', created: Date.now(), auto: 'kream', kreamPid: r.pid };
    INV.items.unshift(it);
  } else if (!it.kreamPid && r.pid) it.kreamPid = r.pid;
  const size = r.isize || kItemSize(it, r.size) || String(r.size || 'FREE');
  if (!(it.sizes || []).includes(size)) (it.sizes = it.sizes || []).push(size);
  const kream = INV.partners.find(p => p.id === 'p-kream') || INV.partners.find(p => p.kind === 'sell');
  const pre = kPreOf(it.id, size), want = r.n;
  if (want > pre) {
    const need = want - pre, have = (invCalc().stock.get(it.id + '|' + size) || { qty: 0 }).qty;
    if (have < need) {
      // 3.10.30: 매입가는 안 넣어도 돼요 — 비우면 같은 상품 최근 매입가, 그것도 없으면 0원(나중에 상품 화면에서 고칠 수 있어요)
      const given = cost !== '' && cost != null && num(cost) >= 0, last = kLastCost(it), c = given ? num(cost) : (+last || 0);
      INV.lots.push({ id: uid(), at: Date.now(), date: today(), itemId: it.id, size, qty: need - have, cost: c, partnerId: '', payId: '', memo: `크림 보관판매에 맞춰 입고 (크림에 직접 올린 상품)${given ? '' : c ? ' · 매입가는 최근 매입가로' : ' · 매입가 미입력'}`, src: 'kream', returnDue: '', confirmed: true, retQty: 0, exQty: 0, events: [] });
    }
    const costs = allocate(it.id, size, need, invCalc());
    if (!costs) throw new Error('재고를 못 잡았어요');
    INV.outs.push({ id: uid(), at: Date.now(), date: today(), itemId: it.id, size, qty: need, price: 0, partnerId: kream ? kream.id : '', kind: 'pre', settled: false, settleDate: '', ship: 0, fee: '', costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: '크림 보관판매 내역에 맞춤' });
  } else if (want < pre) {
    const cut = pre - want; const L = INV.outs.filter(o => o.itemId === it.id && o.size === size && o.kind === 'pre' && !o.settled).sort((a, b) => (b.at || 0) - (a.at || 0));
    const rm = []; let got = 0; for (const o of L) { if (got >= cut) break; rm.push(o); got += (+o.qty || 0) - (+o.retQty || 0); }
    if (got < cut) throw new Error('이미 정산한 보관 출고가 있어서 줄일 수 없어요 — 재고관리에서 직접 확인해 주세요');
    INV.outs = INV.outs.filter(o => !rm.includes(o));
    const back = got - cut;
    if (back > 0) { const costs = allocate(it.id, size, back, invCalc()); if (costs) INV.outs.push({ id: uid(), at: Date.now(), date: today(), itemId: it.id, size, qty: back, price: 0, partnerId: kream ? kream.id : '', kind: 'pre', settled: false, settleDate: '', ship: 0, fee: '', costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: '크림 보관판매 내역에 맞춤' }); }
  }
  await invSave();
  // 매크로 줄도 같이 맞춰요
  const e = stockQ.find(x => x.itemId === it.id && x.size === size);
  if (e && (e.passed || 0) !== want) { const before = e.passed || 0; e.passed = want; e.total = Math.max(e.total || 0, want); if (sqLeft(e) <= 0) e.on = false; e.status = `크림 보관 내역에 맞춤 (기록 ${before}개 → 크림 ${want}개)`; sqRecord(e, want - before, { total: 0 }, `크림 내역에 맞춤 ${before}→${want}`); await sqSave(); await store.set('stockLog', stockLog); }
  return { it, size, want, pre };
}
// 매크로 기록 · 재고관리 '크림 보관' 출고를 크림 실제 수에 맞춰요 (사장님이 버튼을 두 번 눌렀을 때만)
async function kInvFix(e) {
  const k = kInvOf(e); if (!k) throw new Error('먼저 크림 보관 내역을 불러와 주세요');
  if (e.doneAt && kInv && e.doneAt > kInv.at) throw new Error('크림 내역을 읽은 뒤에 신청한 게 있어요 — 크림 보관 내역을 다시 불러온 다음에 맞춰 주세요');
  if (typeof INV !== 'undefined' && e.itemId) { const it = itemOf(e.itemId); if (it) { await invAlign({ it, isize: e.size, size: e.size, n: k.n, pid: '', code: e.code, name: e.name }, null); e.passed = k.n; e.total = Math.max(e.total || 0, k.n); if (sqLeft(e) <= 0) e.on = false; await sqSave(); return; } }
  const want = k.n, before = e.passed || 0, pre = sqPreQty(e);
  if (typeof INV !== 'undefined' && e.itemId && want !== pre) {
    const kream = INV.partners.find(p => p.id === 'p-kream') || INV.partners.find(p => p.kind === 'sell');
    if (want > pre) {
      const costs = allocate(e.itemId, e.size, want - pre, invCalc());
      if (!costs) { const have = (invCalc().stock.get(e.itemId + '|' + e.size) || { qty: 0 }).qty; throw new Error(`재고관리 재고가 ${have}개뿐이라 ${want - pre}개를 더 뺄 수 없어요 — 크림에는 ${want}개가 들어가 있어요. 입고가 빠졌는지 확인해 주세요`); }
      INV.outs.push({ id: uid(), at: Date.now(), date: today(), itemId: e.itemId, size: e.size, qty: want - pre, price: 0, partnerId: kream ? kream.id : '', kind: 'pre', settled: false, settleDate: '', ship: 0, fee: '', costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: '크림 보관판매 내역에 맞춤' });
    } else {
      const cut = pre - want; const L = INV.outs.filter(o => o.itemId === e.itemId && o.size === e.size && o.kind === 'pre' && !o.settled).sort((a, b) => (b.at || 0) - (a.at || 0));
      const rm = []; let got = 0; for (const o of L) { if (got >= cut) break; rm.push(o); got += (+o.qty || 0) - (+o.retQty || 0); }
      if (got < cut) throw new Error('이미 정산한 보관 출고가 있어서 줄일 수 없어요 — 재고관리에서 직접 확인해 주세요');
      INV.outs = INV.outs.filter(o => !rm.includes(o));
      const back = got - cut;
      if (back > 0) { const costs = allocate(e.itemId, e.size, back, invCalc()); if (costs) INV.outs.push({ id: uid(), at: Date.now(), date: today(), itemId: e.itemId, size: e.size, qty: back, price: 0, partnerId: kream ? kream.id : '', kind: 'pre', settled: false, settleDate: '', ship: 0, fee: '', costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: '크림 보관판매 내역에 맞춤' }); }
    }
    await invSave();
  }
  e.passed = want; e.total = Math.max(e.total || 0, want);
  if (sqLeft(e) <= 0) e.on = false;
  e.status = `크림 보관 내역에 맞춤 (기록 ${before}개 → 크림 ${want}개)`;
  sqRecord(e, want - before, { total: 0 }, `크림 내역에 맞춤 ${before}→${want}`);
  await sqSave(); await store.set('stockLog', stockLog);
}
// 모델번호가 없는 크림 상품을 재고관리 상품과 이어 줄 후보 (이름에 같은 낱말이 있는 상품)
function kLinkCands(name) {
  const tok = t => String(t || '').toLowerCase().replace(/[()\[\]\/·,]/g, ' ').split(/\s+/).filter(w => w.length >= 2 && !/^(w|m|the|x|및|남성|여성|공용)$/.test(w));
  const ks = new Set(tok(name)); if (!ks.size) return [];
  return INV.items.map(it => ({ it, n: tok(itName(it) + ' ' + (it.name || '')).filter(w => ks.has(w)).length })).filter(x => x.n > 0).sort((a, b) => b.n - a.n).slice(0, 8).map(x => x.it);
}
// 3.10.29: 같은 상품의 최근 매입가 (입고를 새로 만들 때 기본값)
const kLastCost = it => { if (!it || typeof INV === 'undefined') return ''; const L = INV.lots.filter(l => l.itemId === it.id && !['exchange', 'return', 'adjust'].includes(l.src) && +l.cost > 0).sort((a, b) => (b.at || 0) - (a.at || 0)); return L.length ? Math.round(+L[0].cost) : ''; };
// 크림 보관 내역을 읽으면, 재고가 있는 줄은 재고관리에서 '크림 보관'으로 자동으로 빼요 (크림에 실제로 들어간 수만큼만)
async function kAutoAlign() {
  if (stockOpt.kAuto === false || typeof INV === 'undefined') return { n: 0, q: 0 };
  let n = 0, q = 0;
  // 3.10.31: 크림에 들어간 수가 재고보다 많으면, 있는 재고는 전부 크림에 간 것 → 있는 만큼은 자동으로 빼요 (모자란 만큼만 직접 반영)
  for (const r of kAlignRows().filter(r => r.diff > 0 && r.it && r.have > 0 && !kAlignHide.includes(r.key))) { const take = Math.min(r.have, r.diff); try { await invAlign({ ...r, n: r.pre + take }, null); n++; q += take; } catch (e) {} }
  return { n, q };
}
// 3.10.25: 쉽게 — '크림에 보관 중인데 재고관리에서는 아직 안 빠진 상품'만 접어서 보여주고, 줄마다 숨기기 · 재고 있는 줄은 한 번에 빼기
let kAlignHide = [];
function kAlignPanel() {
  if (!kInv) return '';
  const all = kAlignRows(), bad = all.filter(r => r.diff !== 0), hid = bad.filter(r => kAlignHide.includes(r.key)), show = SQ.alAll ? all : bad.filter(r => SQ.alShowHid || !kAlignHide.includes(r.key));
  const easy = bad.filter(r => r.diff > 0 && r.it && r.have >= r.diff && !kAlignHide.includes(r.key));
  const todo = (r) => {
    if (r.diff === 0) return '<span class="pill ok">맞아요</span>';
    if (r.diff < 0) return `재고관리엔 크림 보관이 ${-r.diff}개 더 많아요<br><button type="button" class="ghost tiny" data-x="kAlign" data-i="${esc(r.key)}">${SQ.alAsk === r.key ? '한 번 더 누르면 반영' : `${-r.diff}개 재고로 되돌리기`}</button>`;
    const lack = Math.max(0, r.diff - (r.it ? r.have : 0)), take = r.diff - lack;
    if (!lack) return `재고에서 <b>${r.diff}개</b> 빼면 맞아요<br><button type="button" class="ghost tiny" data-x="kAlign" data-i="${esc(r.key)}">${SQ.alAsk === r.key ? '한 번 더 누르면 빼요' : `재고에서 ${r.diff}개 빼기`}</button>`;
    return `${take ? `재고 ${take}개를 빼고, ` : ''}재고관리에 없는 <b>${lack}개</b>는 재고로 새로 넣고 같이 빼요<br><input class="cost-in" inputmode="numeric" style="width:110px" placeholder="매입가 (안 넣어도 돼요)" data-xk="alCost" data-i="${esc(r.key)}" value="${esc((SQ.alCost || {})[r.key] ?? kLastCost(r.it))}">${kLastCost(r.it) && (SQ.alCost || {})[r.key] == null ? '<span class="small"> (최근 매입가)</span>' : ''} <button type="button" class="ghost tiny" data-x="kAlign" data-i="${esc(r.key)}">${SQ.alAsk === r.key ? '한 번 더 누르면 반영' : '반영'}</button>`;
  };
  const tr = show.map(r => {
    const cands = r.it ? [] : kLinkCands(r.name);
    return `<tr class="${r.diff === 0 ? 'sq-done' : ''}"><td class="l name"><b>${esc(r.name)}</b><span class="code">${esc(r.code || (r.it && r.it.code) || ('크림 상품 ' + r.pid))}</span>${r.it ? '' : `<div class="small neg">재고관리에서 같은 상품을 못 찾았어요</div><div><select data-xk="alLink" data-i="${esc(r.key)}"><option value="">재고관리에 있는 상품이면 골라 주세요…</option>${cands.map(it => `<option value="${it.id}">${esc(itName(it).slice(0, 40))} (${esc(it.code)})</option>`).join('')}<option value="__all">목록에 없으면 → 전체 상품에서 고르기</option></select></div>`}${SQ.alPick === r.key ? `<div><select data-xk="alLink" data-i="${esc(r.key)}"><option value="">전체 상품…</option>${INV.items.map(it => `<option value="${it.id}">${esc(itName(it).slice(0, 40))} (${esc(it.code)})</option>`).join('')}</select></div>` : ''}</td>
      <td class="l"><b>${esc(r.sizeName || r.size)}</b></td><td><b>${r.n}</b><div class="small">${esc(Object.entries(r.by).map(([a, b]) => `${a} ${b}`).join(' · '))}</div></td><td>${r.it ? r.have : '–'}</td>
      <td class="l small">${todo(r)}</td><td>${r.diff ? `<button type="button" class="x" data-x="kAlignHide" data-i="${esc(r.key)}" title="${kAlignHide.includes(r.key) ? '다시 보이기' : '이 줄 숨기기'}" aria-label="숨기기">${kAlignHide.includes(r.key) ? '↺' : '×'}</button>` : ''}</td></tr>`;
  }).join('');
  const open = SQ.alOpen ?? false;
  return `<details class="kalign"${open ? ' open' : ''} data-xk="alOpen"><summary><b>재고관리에 아직 안 빠진 크림 보관 상품</b> <span class="${bad.length - hid.length ? 'neg' : 'muted'}">${bad.length - hid.length ? `${bad.length - hid.length}줄` : '없어요'}</span>${hid.length ? ` <span class="muted">(숨김 ${hid.length})</span>` : ''} <span class="muted small">— 크림에 직접 올린 것 포함 · 눌러서 보기</span></summary>
    <p class="hint">크림에 보관으로 들어간 상품은 재고관리에서도 빠져 있어야 재고가 맞아요. 아래는 크림엔 들어가 있는데 재고관리에선 아직 재고로 남아 있는(또는 입고가 없는) 상품이에요. 줄마다 '할 일'대로 누르면 재고관리가 크림과 맞춰져요. 버튼은 실수 방지로 두 번 눌러야 돼요. 상관없는 줄은 ×로 숨길 수 있어요.</p>
    <div class="row-btns"><label class="chk"><input type="checkbox" data-xk="kAuto"${stockOpt.kAuto === false ? '' : ' checked'}> 크림 내역 읽을 때 재고 있는 줄은 자동으로 빼기</label>${easy.length ? `<button type="button" class="ghost" data-x="kAlignEasy">${SQ.alEasyAsk ? `한 번 더 누르면 ${easy.length}줄 반영` : `재고 있는 줄 ${easy.length}개 한 번에 빼기`}</button>` : ''}<label class="chk"><input type="checkbox" data-xk="alAll"${SQ.alAll ? ' checked' : ''}> 맞는 줄도 보기</label>${hid.length ? `<label class="chk"><input type="checkbox" data-xk="alShowHid"${SQ.alShowHid ? ' checked' : ''}> 숨긴 줄 보기</label>` : ''}</div>
    ${show.length ? `<div class="tbl"><table><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th>크림에 보관</th><th>재고관리 남은 재고</th><th class="l">할 일</th><th></th></tr></thead><tbody>${tr}</tbody></table></div>` : '<p class="iflash">크림 보관판매와 재고관리가 전부 맞아요.</p>'}</details>`;
}
function sqCmpPanel() {
  const rows = stockQ.map(e => ({ e, k: kInvOf(e), pre: sqPreQty(e) })).filter(x => (x.e.passed || 0) > 0 || x.pre > 0 || (x.k && (x.k.n || x.k.out)));
  const used = new Set(); if (kInv) for (const { e } of rows.concat(stockQ.map(e => ({ e })))) { const cs = kInvCodes(e); kInv.items.forEach((i, n) => { if (cs.includes(codeKey(i.code))) used.add(n); }); }
  const other = {}; if (kInv) kInv.items.forEach((i, n) => { if (used.has(n) || KINV_OUT.test(i.status)) return; const key = `${i.code && i.code !== '-' ? i.code : '모델번호 없음'} · ${i.name.slice(0, 30)} · ${i.sizeName || i.size}`; other[key] = (other[key] || 0) + 1; });
  const bad = rows.filter(x => x.k && !(kInv && x.e.doneAt && x.e.doneAt > kInv.at) && (x.k.n !== (x.e.passed || 0) || x.k.n !== x.pre));
  const tr = rows.map(({ e, k, pre }) => { const stale = k && kInv && e.doneAt && e.doneAt > kInv.at; const ok = k && k.n === (e.passed || 0) && k.n === pre; const over = k && k.n > (e.passed || 0);
    return `<tr class="${!k || stale ? '' : ok ? 'sq-done' : 'err'}"><td class="l name"><b>${esc(e.name || e.code)}</b><span class="code">${esc(e.code)}</span></td><td class="l"><b>${esc(e.ksize || e.size)}</b></td>
      <td><b>${k ? k.n : '–'}</b>${k && Object.keys(k.by).length ? `<div class="small">${esc(Object.entries(k.by).map(([a, b]) => `${a} ${b}`).join(' · '))}</div>` : ''}${k && k.out ? `<div class="small">취소·반송 ${k.out}</div>` : ''}</td>
      <td>${e.passed || 0}</td><td>${pre}</td><td>${sqWant(e)}</td>
      <td class="l small">${!k ? '크림 내역을 불러와 주세요' : ok ? '<span class="pill ok">맞아요</span>' : stale ? `<span class="pill mute">크림 내역을 읽은 뒤(${new Date(kInv.at).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })})에 신청한 게 있어요 — 다시 불러오면 맞춰봐요</span>` : `<span class="pill bad">${over ? `크림이 ${k.n - (e.passed || 0)}개 더 많아요` : k.n < (e.passed || 0) ? `기록이 ${(e.passed || 0) - k.n}개 더 많아요` : '재고관리 출고 수가 달라요'}</span> <button type="button" class="ghost tiny" data-x="kInvFix" data-i="${e.id}">${SQ.fixAsk === e.id ? `한 번 더 누르면 ${k.n}개로 맞춰요` : '크림 수에 맞추기'}</button>`}</td></tr>`; }).join('');
  const sum = !kInv ? '아직 안 읽었어요' : bad.length ? `<span class="neg">다른 줄 ${bad.length}개</span>` : '<span class="pos">전부 맞아요</span>';
  return `<details class="panel kcmp"${SQ.cmpOpen ? ' open' : ''}><summary><b>크림 보관 내역과 비교</b> · ${sum}${kInv ? ` <span class="muted small">(${new Date(kInv.at).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}에 읽음)</span>` : ''} <span class="muted small">— 눌러서 보기</span></summary><div class="toolbar"><div><h2 style="display:block">크림 보관 내역과 비교</h2><p class="hint">크림 마이페이지 → 보관판매의 실제 상품 수(신청 · 보관 중 · 판매 완료 포함, 취소완료 · 불합격 반송 · 회수완료 제외)를 모델번호 · 사이즈별로 세서, 매크로 기록 · 재고관리 '크림 보관' 출고와 비교해요. 읽기만 하고 크림에서 아무것도 바꾸지 않아요.${kInv ? ` 마지막으로 읽은 시각: <b>${new Date(kInv.at).toLocaleString('ko-KR')}</b> (크림 ${kInv.items.filter(i => !KINV_OUT.test(i.status)).length}개)` : ''}</p></div>
    <div class="row-btns"><button type="button" class="primary" data-x="kInvLoad"${SQ.run || SQ.kinvBusy ? ' disabled' : ''}>${SQ.kinvBusy ? '읽는 중…' : '크림 보관 내역 불러와서 비교'}</button></div></div>
    ${SQ.kinvMsg ? `<p class="iflash${/못|풀려|오류|실패/.test(SQ.kinvMsg) ? ' neg' : ''}">${esc(SQ.kinvMsg)}</p>` : ''}
    ${kInv && bad.length ? `<p class="iflash neg"><b>다른 줄 ${bad.length}개</b> — 크림 수가 기록보다 많은 줄은 매크로를 돌리면 재고보다 많이 들어갈 수 있어서, 실행할 때 자동으로 막아요. '크림 수에 맞추기'를 두 번 누르면 매크로 기록과 재고관리 '크림 보관' 출고를 크림 실제 수로 고쳐요.</p>` : kInv && rows.length ? '<p class="iflash">모든 줄이 크림과 맞아요.</p>' : ''}
    ${rows.length ? `<div class="tbl tstick"><table><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th>크림 실제</th><th>매크로 기록</th><th>재고관리 보관 출고</th><th title="신청 완료 + 더 넣을 수량">목표</th><th class="l">결과</th></tr></thead><tbody>${tr}</tbody></table></div>` : '<p class="empty">매크로에 신청 기록이 있는 줄이 없어요.</p>'}
    ${kAlignPanel()}</details>`;
}
function vStockMacro() {
  const C = typeof invCalc === 'function' ? invCalc() : null;
  const doneRows = stockQ.filter(e => (e.passed || 0) > 0);
  // 3.10.41: 보관 신청이 끝난 줄(신청 완료 · 더 넣을 것 없음)은 아래 '보관 완료'로 따로 접어 둬요
  const sqDoneRow = e => (e.passed || 0) > 0 && (sqLeft(e) <= 0 || sqHave(e, C) <= 0);
  const rowOf = e => `<tr${(e.passed || 0) > 0 ? ` class="${sqLeft(e) <= 0 ? 'sq-done' : 'sq-part'}"` : ''}><td><input type="checkbox" data-xk="sqOn" data-i="${e.id}"${e.on ? ' checked' : ''}${sqReady(e) ? '' : ' disabled'} aria-label="실행"></td><td class="l name"><b>${esc(e.name || e.code)}</b><span class="code">${esc(e.code)}</span></td><td class="l"><b>${esc(e.size)}</b></td><td>${sqHave(e, C)}</td><td><input type="number" class="num" style="width:64px" min="0" max="${sqHave(e, C)}" step="1" value="${Math.max(0, Math.min(sqWant(e) - (e.passed || 0), sqHave(e, C)))}" data-xk="sqWant" data-i="${e.id}" aria-label="더 넣을 수량"></td><td>${e.passed || 0}</td>
    <td class="l">${e.pid ? `<a href="https://kream.co.kr/inventory/${esc(e.pid)}" target="_blank" rel="noopener">보관 가능</a>${e.ksizes && e.ksizes.length ? ` <select data-xk="sqKSize" data-i="${e.id}" aria-label="크림 사이즈"><option value="">크림 사이즈 고르기</option>${e.ksizes.map(k => `<option value="${esc(k)}"${e.ksize === k ? ' selected' : ''}>${esc(k)}</option>`).join('')}</select>` : ''}` : e.pid === '' ? `<span class="pill bad">못 찾음</span><div><input class="mini" style="width:150px" placeholder="크림 상품 링크 붙여넣기" data-xk="sqPid" data-i="${e.id}" title="크림에서 이 상품 화면 주소(kream.co.kr/products/번호)를 복사해서 붙여넣으면 그 상품으로 바로 확인해요"></div>` : '<span class="pill mute">확인 전</span>'}</td>
    <td class="l small">${(e.passed || 0) > 0 ? `<span class="pill ok">✓ 보관 신청 ${e.passed}개${sqLeft(e) <= 0 ? ' · 완료' : ` · 남은 ${sqLeft(e)}개`}</span> ` : ''}${esc((e.passed || 0) > 0 && /^신청 완료/.test(e.status || '') ? '' : e.status || '')}${e.tries ? ` · 시도 ${e.tries}번` : ''}${sqLeft(e) > 0 ? ` <button type="button" class="ghost tiny" data-x="sqMark" data-i="${e.id}" title="크림에서 신청됐는데 여기 안 잡혔을 때">${SQ.markAsk === e.id ? '한 번 더 누르면 +1' : '성공 +1'}</button>` : ''}</td><td><button type="button" class="x" data-x="sqDel" data-i="${e.id}" aria-label="삭제">×</button></td></tr>`;
  const rank = e => e.on ? 0 : sqReady(e) ? 1 : e.pid ? 2 : e.pid === '' ? 3 : 4;
  // 3.10.43: 재고도 없고 신청한 것도 없는 줄(구매 취소 등)은 표에서 빼요
  const sqEmpty = e => !(e.passed > 0) && sqHave(e, C) <= 0, emptyN = stockQ.filter(e => !sqDoneRow(e) && sqEmpty(e)).length;
  const rows = stockQ.filter(e => !sqDoneRow(e) && !sqEmpty(e)).sort((a, b) => rank(a) - rank(b)).map(rowOf).join(''), doneQ = stockQ.filter(sqDoneRow), doneRowsHtml = doneQ.map(rowOf).join('');
  const today0 = today(); const tries = stockTries.d === today0 ? stockTries.n : 0;
  return `<div class="panel"><div class="toolbar"><div><h2 style="display:block">보관 신청 매크로</h2><p class="hint">재고관리에 있는 상품을 크림 보관 신청에 넣어요. 같은 상품은 ${stockOpt.chunk}개씩 나눠서 '신청 계속'을 누르고, 막히면 1초 뒤 한 번 더 누르고, 그다음 ${stockOpt.gap}~${stockOpt.gap + 2}초 쉬었다가 다시 눌러요.</p></div>
    <div class="row-btns"><button type="button" class="ghost" data-x="sqLoad"${SQ.run ? ' disabled' : ''}>재고에서 불러오기</button>${stockQ.length ? `<button type="button" class="ghost" data-x="sqAll" data-v="1"${SQ.run ? ' disabled' : ''}>보관 가능 모두 선택</button><button type="button" class="ghost" data-x="sqAll" data-v="0"${SQ.run ? ' disabled' : ''}>모두 해제</button>` : ''}<button type="button" class="ghost" data-x="sqCheck"${SQ.run || XS.busy ? ' disabled' : ''}>보관 가능 확인</button>${SQ.run ? '<button type="button" class="primary danger" data-x="sqStop">중지</button>' : `<button type="button" class="primary" data-x="sqRun"${stockQ.some(e => e.on && e.pid && sqLeft(e) > 0) ? '' : ' disabled'}>실행</button>`}</div></div>
    <details class="sq-opt"${SQ.optOpen ? ' open' : ''}><summary class="small">매크로 설정 — ${stockOpt.chunk}개씩 · ${stockOpt.gap}~${stockOpt.gap + 2}초 · ${stockOpt.final ? '결제까지 자동' : '요약 확인까지만'} · 오늘 ${tries}번 시도 <span class="muted">(눌러서 바꾸기)</span></summary>
    <div class="row-btns"><label>한 번에 넣을 수량<select data-xk="sqChunk">${[1, 2].map(n => opt(n, n + '개씩', stockOpt.chunk === n)).join('')}</select></label>
      <label>다시 누르는 간격<select data-xk="sqGap">${[7, 10, 15, 30].map(n => opt(n, `${n}~${n + 2}초`, stockOpt.gap === n)).join('')}</select></label>
      <label class="chk"><input type="checkbox" data-xk="sqFinal"${stockOpt.final ? ' checked' : ''}> 최종 신청(보증금 결제)까지 자동</label>
      <label>하루 최대 시도<select data-xk="sqCap">${[500, 1000, 2000, 4000].map(n => opt(n, n + '번', stockOpt.cap === n)).join('')}</select></label>
      <span class="hint">오늘 ${tries}번 시도</span></div></details>
    <p class="iflash" id="sqMsg"${SQ.msg ? '' : ' hidden'}>${esc(SQ.msg)}</p>
    ${doneRows.length ? `<details class="sq-donebox"${SQ.succOpen ? ' open' : ''}><summary><b>✓ 보관 신청 성공</b> <span class="muted">${doneRows.length}줄 · ${doneRows.reduce((a, e) => a + e.passed, 0)}개 — 눌러서 보기</span></summary>
      <div class="tbl"><table><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th>신청 완료</th><th>목표</th><th class="l">마지막 성공</th></tr></thead><tbody>${doneRows.map(e => `<tr><td class="l name"><b>${esc(e.name || e.code)}</b><span class="code">${esc(e.code)}</span></td><td class="l">${esc(e.ksize || e.size)}</td><td><b>${e.passed}개</b></td><td>${sqWant(e)}개${sqLeft(e) <= 0 ? ' <span class="pill ok">완료</span>' : ''}</td><td class="l small">${e.doneAt ? new Date(e.doneAt).toLocaleString('ko-KR') : ''}</td></tr>`).join('')}</tbody></table></div></details>` : ''}
    ${stockQ.length ? `<div class="tbl tstick"><table><thead><tr><th>선택</th><th class="l">상품</th><th class="l">사이즈</th><th title="재고관리에 지금 남은 수 (크림에 신청한 건 이미 빠져 있어요)">남은 재고</th><th title="남은 재고 중에 크림에 더 넣을 수">더 넣을 수량</th><th>신청 완료</th><th class="l">크림 보관</th><th class="l">상태</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="9" class="empty">진행 중인 줄이 없어요 — 전부 보관 완료됐어요</td></tr>'}</tbody></table></div>${emptyN ? `<p class="hint">재고가 0개라 넣을 게 없는 줄 ${emptyN}개는 숨겼어요 (구매 취소 · 판매 등). 재고가 다시 들어오면 나타나요.</p>` : ''}${doneQ.length ? `<details class="sq-donelist"${SQ.doneOpen ? ' open' : ''}><summary><b>✓ 보관 완료 ${doneQ.length}줄</b> <span class="muted">(${doneQ.reduce((a, e) => a + (e.passed || 0), 0)}개 · 크림에 다 넣은 상품 — 눌러서 보기)</span></summary><div class="tbl tstick"><table><thead><tr><th>선택</th><th class="l">상품</th><th class="l">사이즈</th><th>남은 재고</th><th>더 넣을 수량</th><th>신청 완료</th><th class="l">크림 보관</th><th class="l">상태</th><th></th></tr></thead><tbody>${doneRowsHtml}</tbody></table></div></details>` : ''}` : `<p class="empty">${C ? '<b>재고에서 불러오기</b>를 누르세요. 재고관리 → 상품 · 재고에 있는 상품이 사이즈별로 들어와요.' : ''}</p>`}
    <details><summary class="small muted">매크로가 어떻게 신청하나요 (안전장치 설명)</summary><p class="hint">마지막 단계(필수 동의 → 신청)에서 크림이 '신규 보관 신청 제한'으로 거절하면, 그 화면에 그대로 있으면서 동의 체크 → 신청을 다시 누르는 간격마다 반복해요. 매번 결제 전에 크림 요약 화면을 읽어서 <b>모델번호 · 사이즈 · 수량 · 신청 건수 · 결제금액(건당 3,000원)</b>이 넣은 값과 똑같은지 확인해요. 하나라도 다르면 결제하지 않고 매크로 전체를 멈춰요. 결제 버튼을 누르면 뜨는 <b>필수 동의</b> 칸은 전부 체크하고 결제해요(동의한 항목은 아래 내역에 남겨요 · 다 못 채우면 결제 안 하고 멈춰요). 결제 버튼을 누른 뒤 결과가 분명하지 않을 때도 두 번 신청되지 않게 멈춰요. '최종 신청까지 자동'을 끄면 요약 확인까지만 하고 크림 창을 띄워 줘요. 크림은 매크로를 허용하지 않아서 신규 보관 신청이 제한될 수 있어요.</p></details></div>
  ${vStockLog()}`;
}
const sqSet = t => { SQ.msg = t; const e = $('#sqMsg'); if (e) { e.textContent = t; e.hidden = !t; } };
async function sqSave() { await store.set('stockQ', stockQ); await store.set('stockOpt', stockOpt); await store.set('stockTries', stockTries); }
async function sqLoad() {
  if (typeof INV === 'undefined') return;
  const C = invCalc(); let add = 0;
  for (const it of INV.items) {
    const st = itemStock(it, C);
    for (const [size, x] of Object.entries(st.by)) {
      if (!(x.qty > 0)) continue;
      const ex = stockQ.find(e => e.itemId === it.id && e.size === size);
      if (ex) { ex.total = x.qty + (ex.passed || 0); continue; }   // 3.10.16: 신청 성공분은 재고에서 이미 빠져 있어요 → 넣을 수 있는 전체 = 남은 재고 + 이미 신청한 수
      stockQ.push({ id: uid(), itemId: it.id, code: String(it.code).split('/')[0].trim(), name: itName(it), size, total: x.qty, want: x.qty, passed: 0, on: false, pid: undefined, status: '', tries: 0 });   // 3.7.5: 처음엔 선택 안 함 — 넣을 것만 고르세요
      add++;
    }
  }
  await sqSave(); sqSet(add ? `재고 ${add}줄을 넣었어요. '보관 가능 확인' → 넣을 상품만 체크하고 수량을 정한 뒤 '실행'을 누르세요.` : '새로 넣을 재고가 없어요 (재고관리 → 상품 · 재고에 재고가 있어야 해요)');
  renderX();
}
// 3.10.26: 모델번호로 못 찾는 상품 — ① 모델번호 칸의 괄호·앞글자 등을 정리해서 여러 모양으로 찾고 ② 크림 상품 번호를 알면(직접 넣은 링크 · 크림 보관 내역 · 예전 연결) 검색 없이 바로 그 상품으로 가요.
function sqCodeVariants(list) {
  const out = [];
  for (const raw of list) {
    for (const c0 of String(raw || '').split('/')) {
      const c = c0.trim(); if (!c) continue; out.push(c);
      for (const m of c.match(/[A-Za-z0-9][A-Za-z0-9-]{4,}/g) || []) if (/\d/.test(m)) out.push(m);   // 'TB1 (TB110073001)' → TB110073001
      const seg = c.split('-'); if (seg.length >= 3 && seg[0].length <= 2) out.push(seg.slice(1).join('-'));   // 'B-RGW12GWS-RYK' → RGW12GWS-RYK
    }
  }
  return [...new Set(out.map(x => x.trim()).filter(x => codeKey(x).length >= 4))];
}
// 3.10.36: 검색 없이 바로 가는 건 사장님이 직접 넣은 크림 링크(또는 비교 표에서 직접 연결)만 — 크림 보관 내역에서 짐작하지 않아요(색상 다른 상품을 잘못 고를 수 있어서)
function sqKnownPid(e, it, codes) {
  if (e.forcePid) return String(e.forcePid);
  if (it && it.kreamPid && it.kreamPidBy === 'user') return String(it.kreamPid);
  return '';
}
function sqCheck(only) {
  if (!needExt()) return;
  // 3.7.5: 아직 확인 안 했거나 '대상 아님'·'사이즈 못 맞춤'인 줄도 다시 확인해요. 상품마다 모델번호를 전부(A/B/C) 넣어서 찾아요.
  const todo = stockQ.filter(e => only ? e.id === only : (!e.pid || !sqReady(e) || !e.ksizes));
  const groups = [...new Set(todo.map(e => e.itemId || e.code))];
  if (!groups.length) return sqSet('다시 확인할 줄이 없어요 (전부 보관 가능)');
  xRun(async () => {
    for (const [i, g] of groups.entries()) {
      const rows = stockQ.filter(e => (e.itemId || e.code) === g);
      const it = typeof itemOf === 'function' && rows[0].itemId ? itemOf(rows[0].itemId) : null;
      const codes0 = [...new Set([rows[0].code, ...String((it && it.code) || '').split('/')].map(c => String(c).trim()).filter(Boolean))];
      // 3.10.28: 상품명에 '모델번호 + 색상 번호'(예: AMI 'BFUSW235 730 430')가 이어서 적혀 있으면 그 전체를 먼저 찾아요 (크림 모델번호가 그 모양)
      const full = []; const nm = String((it && it.name) || rows[0].name || '');
      for (const c of codes0) { const m = nm.match(new RegExp(c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '((?:[\\s-]+[0-9A-Z]{2,4}){1,3})(?=\\s|$)', 'i')); if (m) full.push((c + m[1]).replace(/\s+/g, ' ').trim()); }
      const codes = sqCodeVariants([...full, ...codes0]);
      let pid = '', sizes = [], tabId = null, r = null, via = '';
      const known = sqKnownPid(rows.find(e => e.forcePid) || rows[0], it, codes);
      if (known) {
        sqSet(`${i + 1} / ${groups.length} 크림 상품 ${known}번으로 바로 확인 중…`);
        tabId = await srcNav(`https://kream.co.kr/inventory/${known}`); await sleep(1500);
        sizes = await inTab(tabId, kcStockSizes).catch(() => []) || [];
        if (sizes.length) { pid = known; via = '크림 상품 번호'; }
      }
      if (!pid) {
        sqSet(`${i + 1} / ${groups.length} 크림 보관 상품에서 ${codes.join(' / ')} 찾는 중…`);
        tabId = await srcNav('https://kream.co.kr/search/stock');
        r = await inTab(tabId, kcStockFind, [codes]).catch(e => ({ error: e.message }));
        if (r && r.found) { for (let k = 0; k < 20; k++) { await sleep(400); const t = await chrome.tabs.get(tabId); const m = (t.url || '').match(/\/inventory\/(\d+)/); if (m) { pid = m[1]; break; } } }
        if (pid) { await sleep(1200); sizes = await inTab(tabId, kcStockSizes).catch(() => []) || []; }
      }
      // 크림 화면에 적힌 모델번호가 우리 것과 모양이 다르면(또는 크림에 모델번호가 없으면) 크림 화면 글자로 확인하게 해요 — 상품 번호로 정확히 찾은 경우만
      let vcodes = codes;
      if (pid && tabId) {
        const h = await inTab(tabId, kcStockHead).catch(() => null);
        if (via && h && !codes.some(c => codeKey(h.head).includes(codeKey(c)))) { const extra = h.code && h.code !== '-' ? h.code : h.en; if (extra) vcodes = [...codes, extra]; }
      }
      for (const e of rows) {
        e.pid = pid; e.codes = vcodes; e.ksizes = sizes; delete e.forcePid;
        if (pid) {
          const k = matchKSize(e.size, sizes);
          if (!e.ksize || !sizes.includes(e.ksize)) e.ksize = k || '';
          e.status = (!sizes.length ? '' : e.ksize ? (e.ksize !== e.size ? `크림 사이즈 ${e.ksize}로 신청` : '') : `크림 사이즈를 골라 주세요 (재고 ${e.size} → 크림: ${sizes.slice(0, 6).join(', ')}${sizes.length > 6 ? '…' : ''})`) + (via ? ` · ${via}로 찾음` : '');
          if (!sqReady(e)) e.on = false;
        } else {
          e.ksize = ''; e.on = false;
          e.status = r && r.error ? r.error : r && r.ambiguous ? `같은 모델번호 상품이 크림에 여러 개(색상별) 있어서 고르지 않았어요 (${(r.cands || []).join(' | ')}) — 맞는 색상의 크림 상품 링크를 넣어 주세요` : `크림 보관 신청 검색에서 못 찾았어요 (${(r && r.tried || codes).join(', ')}로 찾음${r && r.cands && r.cands.length ? ` · 검색 결과: ${r.cands.join(' | ')}` : ''}) — 크림 상품 링크를 넣어 주세요`;
        }
      }
      await sqSave();
    }
    if (typeof invSave === 'function') { try { await invSave(); } catch (e) {} }
    sqSet(`확인 끝 — 보관 가능 ${stockQ.filter(e => sqReady(e)).length}줄 · 크림 사이즈 골라야 함 ${stockQ.filter(e => e.pid && !sqReady(e)).length}줄 · 못 찾음 ${stockQ.filter(e => e.pid === '').length}줄`);
  });
}
function sqNext() { const L = stockQ.filter(e => e.on && sqReady(e) && sqLeft(e) > 0); if (!L.length) return null; L.sort((a, b) => (a.last || 0) - (b.last || 0)); return L[0]; }
let stockLog = [];   // 보관 신청 내역 (이 PC 기록)
function sqRecord(e, q, r, result) {
  stockLog.unshift({ t: Date.now(), code: e.code, name: e.name, size: e.size, qty: q, pid: e.pid, total: r && r.total || q * 3000, result, said: ((r && r.agreed && r.agreed.length ? ['동의: ' + r.agreed.join(', ')] : []).concat(r && r.said || [])).join(' / ').slice(0, 200) });
  stockLog = stockLog.slice(0, 500);
}
// 신청에 성공한 수량은 재고관리에서 '크림 보관'으로 내보내요(우선출고 · 매출처 크림). 팔리면 우선출고 정산에서 판매가를 넣어요.
async function sqToInventory(e, q) {
  if (typeof INV === 'undefined' || !e.itemId) return;
  const C = invCalc(); const costs = allocate(e.itemId, e.size, q, C);
  if (!costs) return;
  const kream = INV.partners.find(p => p.id === 'p-kream') || INV.partners.find(p => p.kind === 'sell');
  INV.outs.push({ id: uid(), at: Date.now(), date: today(), itemId: e.itemId, size: e.size, qty: q, price: 0, partnerId: kream ? kream.id : '', kind: 'pre', settled: false, settleDate: '', ship: 0, fee: '', costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: '크림 보관 신청 (매크로)' });
  await invSave();
}
async function sqRun() {
  if (!needExt() || SQ.run) return;
  SQ.run = true; SQ.started = Date.now(); SQ.work = SQ.work || { winId: null, tabId: null };
  // 3.10.19: 실행 전에 크림 보관판매 내역을 읽어서, 크림에 이미 들어간 수가 매크로 기록보다 많은 줄이 있으면 시작하지 않아요 (재고보다 많이 들어가는 것 막기)
  if (stockOpt.final) {
    sqSet('실행 전에 크림 보관판매 내역과 수량을 맞춰 보는 중…'); renderX();
    try { await kInvRead(); await kAutoAlign(); }
    catch (er) { sqSet('크림 보관판매 내역을 못 읽어서 시작하지 않았어요 — ' + er.message); SQ.run = false; renderX(); return; }
    const over = stockQ.filter(e => e.on && sqLeft(e) > 0).map(e => ({ e, k: kInvOf(e) })).filter(x => x.k && x.k.n > (x.e.passed || 0));
    if (over.length) { sqSet(`시작하지 않았어요 — 크림에 이미 기록보다 많이 들어간 줄이 있어요: ${over.map(x => `${x.e.ksize || x.e.size} 크림 ${x.k.n}개 · 기록 ${x.e.passed || 0}개`).join(', ')}. 위 '크림 보관 내역과 비교'에서 맞춘 뒤 실행해 주세요.`); SQ.run = false; renderX(); return; }
  }
  for (const e of stockQ) if (e.on && sqLeft(e) > 0 && !/^신청 완료/.test(e.status || '')) e.status = '차례 기다리는 중';   // 3.9.5: 예전 메시지 지우기
  renderX();
  let backoff = 0, okN = 0, quickNext = true;   // 3.10.3: 막히면 1초 뒤 한 번 더 → 그다음 7~9초 쉬기
  try {
    while (SQ.run) {
      // 3.9.7: 마지막 결제 화면까지 간 줄은 그 화면에서 계속 이어서 신청해요(처음으로 안 돌아감)
      const st0 = SQ.stick && stockQ.find(x => x.id === SQ.stick.id && x.on && sqLeft(x) > 0);
      if (!st0) SQ.stick = null;
      const e = st0 || sqNext(); if (!e) { sqSet(okN ? `끝났어요 — ${okN}건 신청 완료. 아래 '보관 신청 내역'을 보세요.` : '실행할 줄이 없어요 (전부 끝났거나 꺼져 있어요)'); break; }
      const d = today(); if (stockTries.d !== d) stockTries = { d, n: 0 };
      if (stockTries.n >= stockOpt.cap) { sqSet(`오늘 최대 시도(${stockOpt.cap}번)에 닿아서 멈췄어요`); break; }
      const q = Math.min(stockOpt.chunk, sqLeft(e));
      // 신청 직전에 재고를 다시 확인 (그새 출고·반품됐으면 신청하지 않아요)
      if (typeof INV !== 'undefined' && e.itemId) { const have = (invCalc().stock.get(e.itemId + '|' + e.size) || { qty: 0 }).qty; if (have < q) { e.on = false; e.status = `재고가 ${have}개뿐이라 멈췄어요`; await sqSave(); continue; } }
      sqSet(`${e.name} ${e.size} — ${q}개 신청 중 (오늘 ${stockTries.n + 1}번째 시도)`);
      let r;
      try {
        let tabId = null, resume = false;
        if (st0 && SQ.stick.tabId && SQ.work.tabId === SQ.stick.tabId) { const tt = await chrome.tabs.get(SQ.work.tabId).catch(() => null); if (tt && /kream\.co\.kr\/inventory\//.test(tt.url || '')) { tabId = SQ.work.tabId; resume = true; } }
        if (!tabId) { SQ.stick = null; tabId = await srcNav(`https://kream.co.kr/inventory/${e.pid}`, SQ.work); await sleep(900); }
        // 3.10.16: 크림 로그인이 풀려 로그인 화면이면 시도하지 않고 멈춰요 (예전엔 로그인 화면에서 계속 '신청 중'으로 돌았어요)
        const tu = await chrome.tabs.get(tabId).catch(() => null);
        if (tu && /kream\.co\.kr\/login/.test(tu.url || tu.pendingUrl || '')) throw Object.assign(new Error('login'), { kcLogin: true });
        const [x] = await execT({ target: { tabId }, func: kcStockApply, args: [e.ksize || e.size, q, e.codes && e.codes.length ? e.codes : [e.code], !!stockOpt.final, stockOpt.gap, resume], world: 'MAIN' }, 115000);
        if (x && x.result && x.result.step === 'final') SQ.stick = { id: e.id, tabId }; else SQ.stick = null;
        r = x && x.result;
      } catch (err) { r = err && err.kcLogin ? { login: true } : { error: err.message, lost: true }; }
      if (r && r.login) {
        e.status = '크림 로그인이 풀려서 멈춤';
        sqSet('크림 로그인이 풀려서 멈췄어요 — 신청은 하지 않았어요. 계정 연결에서 크림 로그인을 다시 한 뒤 실행을 눌러 주세요.');
        try { chrome.notifications.create('sqlg-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: '크림 보관 매크로 — 멈춤', message: '크림 로그인이 풀렸어요. 계정 연결에서 크림 로그인을 다시 해 주세요.', priority: 2, requireInteraction: true }); } catch (x) {}
        SQ.run = false; break;
      }
      // 3.9.8: 결제 뒤 화면이 넘어가면 결과를 못 받을 수 있어요 → 크림 화면이 '신청 완료'인지 다시 확인해서 성공으로 세요
      if (stockOpt.final && r && (r.lost || (r.submitted && !r.done))) {
        try {
          const tid = SQ.work.tabId;
          if (r.lost && tid) { try { await execT({ target: { tabId: tid }, func: kcStockAbort, world: 'MAIN' }, 10000); } catch (x4) {} }   // 3.10.9: 안 보이게 계속 돌던 실행 멈추기
          await sleep(1500);
          const [c] = tid ? await execT({ target: { tabId: tid }, func: kcStockDoneCheck, world: 'MAIN' }, 20000) : [null];
          const cr = c && c.result;
          const mk = cr && cr.marker;
          if (cr && cr.done) r = { submitted: true, done: true, total: q * 3000, said: ['결과 화면 확인: ' + cr.url], checked: true };
          // 3.10.5: 결제(신청) 버튼을 누른 표시가 있고(2분 안) 거절 표시가 없는데 화면이 처음(사이즈 고르기)으로 돌아갔으면 = 크림이 신청을 받고 화면을 새로 연 것
          else if (cr && !cr.pay && mk && !mk.rej && Date.now() - mk.t < 120000 && String(mk.size) === String(e.ksize || e.size)) { r = { submitted: true, done: true, total: q * 3000, said: ['결제 뒤 크림 화면이 처음으로 돌아가서 신청 완료로 판단'], checked: true }; try { await execT({ target: { tabId: tid }, func: kcStockClearMark, world: 'MAIN' }, 10000); } catch (x3) {} }
          else if (r.lost) r.said = [(cr && cr.head) || ''];
        } catch (x2) {}
      }

      const nT = Math.max(1, (r && r.finalTries) || 0); stockTries.n += nT; e.tries = (e.tries || 0) + nT; e.last = Date.now();
      const said = r && r.said ? r.said.join(' / ') : '';
      if (r && r.mismatch) {   // 모델번호·사이즈·수량이 하나라도 다르면 바로 전체 멈춤
        e.on = false; e.status = '멈춤 — ' + r.mismatch; sqRecord(e, q, r, '확인 불일치로 신청 안 함'); await sqSave();
        try { chrome.notifications.create('sqm-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: '크림 보관 매크로 — 멈춤', message: `${e.name} ${e.size}: ${r.mismatch}`, priority: 2, requireInteraction: true }); } catch (x) {}
        sqSet(`멈췄어요 — ${e.name} ${e.size}: ${r.mismatch}. 신청하지 않았어요.`); SQ.run = false; break;
      }
      if (r && r.ready) { e.status = `최종 확인까지 통과 (결제 전에서 멈춤 — '최종 신청까지 자동'이 꺼져 있어요)`; sqRecord(e, q, r, '확인 통과 · 결제 안 함'); await sqSave(); try { await chrome.windows.update(SQ.work.winId, { focused: true, state: 'normal' }); } catch (x) {} SQ.work = { winId: null, tabId: null }; sqSet(`${e.name} ${e.size} ${q}개 — 요약 화면까지 통과했어요. 앞에 띄운 크림 창에서 확인 후 '보증금 결제하기'를 눌러 주세요.`); SQ.run = false; break; }
      if (r && r.submitted) {
        if (r.done) {
          e.passed = (e.passed || 0) + q; e.doneAt = Date.now(); e.status = `신청 완료 ${e.passed}/${e.total}개 (${new Date().toLocaleTimeString('ko-KR')})`; okN++;
          if (sqLeft(e) <= 0) e.on = false;   // 3.8.6: 정한 수량을 다 넣은 줄은 선택 해제
          sqRecord(e, q, r, '신청 완료'); await sqToInventory(e, q); await sqSave();
          try { chrome.notifications.create('sqok-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: '크림 보관 신청 완료', message: `${e.name} ${e.size} ${q}개 · 보증금 ${won(r.total)}`, priority: 2 }); } catch (x) {}
          backoff = 0;
        } else {   // 결제 버튼은 눌렸는데 결과를 확신할 수 없으면 두 번 신청되지 않게 멈춰요
          e.on = false; e.status = `결제 버튼 누른 뒤 결과 확인 필요${said ? ': ' + said.slice(0, 80) : ''}`; sqRecord(e, q, r, '결과 확인 필요'); await sqSave();
          try { chrome.notifications.create('sqq-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: '크림 보관 매크로 — 확인 필요', message: `${e.name} ${e.size}: 신청됐는지 크림 보관판매 내역에서 확인해 주세요`, priority: 2, requireInteraction: true }); } catch (x) {}
          try { await chrome.windows.update(SQ.work.winId, { focused: true, state: 'normal' }); } catch (x) {} SQ.work = { winId: null, tabId: null };
          sqSet(`${e.name} ${e.size}: 결제 버튼을 누른 뒤 결과가 분명하지 않아 멈췄어요. 크림 보관판매 내역에서 확인해 주세요 (두 번 신청되지 않게).`); SQ.run = false; break;
        }
      } else if (r && r.lost && stockOpt.final) {   // 3.9.2: 결과를 못 받았으면(시간 초과 등) 결제됐을 수도 있어서 두 번 신청되지 않게 멈춰요
        e.on = false; e.status = `결과를 못 받았어요(${String(r.error).slice(0, 40)}) — 크림 보관판매 내역에서 신청됐는지 확인해 주세요`; sqRecord(e, q, r, '결과 확인 필요'); await sqSave();
        sqSet(`${e.name} ${e.size}: 크림 창에서 결과를 못 받아서 멈췄어요 (두 번 신청되지 않게). 크림 보관판매 내역에서 확인해 주세요.`); SQ.run = false; break;
      } else if (r && r.blocked && (r.step === 'agree' || r.step === 'confirm')) {   // 3.8.6~7: 동의·모델번호 확인 창을 못 넘기면 결제 안 하고 멈춰요
        if (r.dom) { try { await store.set('stockDebug', { t: Date.now(), code: e.code, size: e.size, said, dom: r.dom }); } catch (x) {} }
        e.on = false; e.status = `${r.step === 'confirm' ? '확인 창' : '필수 동의'} 넘기기 실패${said ? ': ' + said.slice(0, 100) : ''}`; sqRecord(e, q, r, (r.step === 'confirm' ? '확인 창' : '동의') + ' 실패 · 결제 안 함'); await sqSave();
        try { await chrome.windows.update(SQ.work.winId, { focused: true, state: 'normal' }); } catch (x) {} SQ.work = { winId: null, tabId: null };
        sqSet(`${e.name} ${e.size}: 크림 ${r.step === 'confirm' ? '확인 창' : '필수 동의 창'}을 넘기지 못해서 결제하지 않고 멈췄어요. 앞에 띄운 크림 창에서 확인해 주세요.`); SQ.run = false; break;
      } else {
        // 3.9.5: 크림이 거절한 이유 + 마지막 시도 시각을 보여줘요 (상태가 계속 바뀌는 게 보이게)
        const why = (said || '').split(' / ').filter(x => !/모델번호를\s*확인하셨나요/.test(x)).join(' / ');
        e.status = r && r.error ? '오류: ' + r.error : `${r && r.step === 'final' ? '최종 신청에서 ' : ''}크림 거절${why ? ': ' + why.slice(0, 80) : ''} · ${new Date().toLocaleTimeString('ko-KR')} 시도 · ${stockOpt.gap}~${stockOpt.gap + 2}초 뒤 다시`;
        if (r && r.dom) { try { await store.set('stockDebug', { t: Date.now(), code: e.code, size: e.size, said, dom: r.dom }); } catch (x) {} }
        if (/너무 많은 요청|요청이 많|과도한|비정상적|일시적으로\s*(이용|접속|요청)이?\s*제한/.test(said)) { backoff = Math.min(backoff + 1, 3); e.status += ` — ${backoff}분 쉬어요`; } else backoff = 0;
      }
      await sqSave(); renderX();
      if (r && r.quickNext !== undefined) quickNext = r.quickNext;
      const blockedNow = !!(r && (r.blocked || r.error) && !r.submitted);
      const waitMs = backoff ? backoff * 60000 : (blockedNow && quickNext) ? 1000 : (stockOpt.gap + Math.random() * 2) * 1000;
      if (blockedNow && !backoff) quickNext = !quickNext; else quickNext = true;
      const end = Date.now() + waitMs;
      while (SQ.run && Date.now() < end) await sleep(250);
    }
  } finally { SQ.run = false; if (SQ.work && SQ.work.winId) { try { await chrome.windows.remove(SQ.work.winId); } catch (x) {} SQ.work = { winId: null, tabId: null }; } await sqSave(); await store.set('stockLog', stockLog); if (okN) { try { await kInvRead(); } catch (x) {} } renderX(); }   // 3.10.36: 신청이 있었으면 끝나고 크림 내역을 다시 읽어 비교 표를 새로 해요
}
function vStockLog() {
  if (!stockLog.length) return '';
  return `<details class="panel"${SQ.logOpen ? ' open' : ''} data-open="logOpen"><summary><b>보관 신청 내역</b> <span class="muted">${stockLog.length}건 — 눌러서 보기</span></summary><div class="toolbar"><h2>보관 신청 내역 <span class="muted">${stockLog.length}건</span></h2><div class="row-btns"><button type="button" class="ghost" data-x="sqLogXl">엑셀</button><button type="button" class="ghost" data-x="kLoad" data-v="kinv">크림 보관판매 내역 새로고침</button></div></div>
    <div class="tbl"><table><thead><tr><th class="l">시각</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>보증금</th><th class="l">결과</th><th class="l">크림 안내</th></tr></thead><tbody>${stockLog.slice(0, 100).map(l => `<tr><td class="l small">${new Date(l.t).toLocaleString('ko-KR')}</td><td class="l name"><b>${esc(l.name)}</b><span class="code">${esc(l.code)}</span></td><td class="l">${esc(l.size)}</td><td>${l.qty}</td><td>${won(l.total)}</td><td class="l"><span class="pill ${/^신청 완료/.test(l.result) ? 'ok' : /불일치|확인 필요/.test(l.result) ? 'bad' : 'mute'}">${esc(l.result)}</span></td><td class="l small">${esc(l.said)}</td></tr>`).join('')}</tbody></table></div>
    <p class="hint">신청 완료된 수량은 재고관리에서 '우선출고 · 크림 보관 신청'으로 빠져요(같은 재고를 두 번 신청하지 않게). 팔리면 재고관리 → 우선출고 정산에서 판매가를 넣으세요.</p></details>`;
}

// ---------- 3.2: 보관판매 매크로 (따로 메뉴) ----------
// 3.22: 재고에 없어도 크림에서 상품을 찾아 바로 매크로에 넣기 + 대기 / 완료 요약
function vKmFind() {
  const K = XS.kmS = XS.kmS || { q: '', list: [], inp: {} };
  const wait = stockQ.filter(e => sqLeft(e) > 0 && (e.passed || 0) < sqWant(e)), on = stockQ.filter(e => e.on && sqLeft(e) > 0), done = stockQ.filter(e => (e.passed || 0) > 0);
  const tries = stockTries.d === today() ? stockTries.n : 0;
  const res = K.list.map(r => { const I = K.inp[r.pid] || {}; return `<tr><td class="l"><div class="km-prod">${r.img ? `<img src="${esc(r.img)}" alt="" loading="lazy">` : '<i></i>'}<span><b>${esc(r.name)}</b><small>#${esc(r.pid)}${r.fast ? ' · 빠른배송' : ''}</small></span></div></td><td>${r.trades ? r.trades.toLocaleString('ko-KR') : '–'}</td><td>${r.wish ? r.wish.toLocaleString('ko-KR') : '–'}</td><td>${won(r.price)}</td>
    <td><div class="km-add"><input data-xk="kmSize" data-i="${esc(r.pid)}" value="${esc(I.size || '')}" placeholder="사이즈"><input data-xk="kmQty" data-i="${esc(r.pid)}" inputmode="numeric" value="${esc(I.qty || '1')}" aria-label="수량"><button type="button" class="primary small" data-x="kmAdd" data-i="${esc(r.pid)}">넣기</button></div></td></tr>`; }).join('');
  return `<div class="km-grid"><div class="panel km-find"><div class="km-h">${ico('search')}<b>크림에서 상품 찾아 넣기</b><span class="hint">재고관리에 없는 상품도 바로 매크로에 넣어요</span></div>
    <div class="km-sbar"><label class="dl-search">${ico('search')}<input data-xk="kmQ" value="${esc(K.q)}" placeholder="상품명 · 품번 (예: 마뗑킴 토트백, DD1391-100)" autocomplete="off"></label><button type="button" class="primary dl-go" data-x="kmSearch"${XS.busy ? ' disabled' : ''}>${ico('search')}검색</button></div>
    ${K.list.length ? `<div class="tbl km-res"><table><thead><tr><th class="l">상품</th><th>거래</th><th>관심</th><th>즉시 구매가</th><th>사이즈 · 수량</th></tr></thead><tbody>${res}</tbody></table></div>` : `<div class="dl-empty">${ico('cube')}<span>${K.at ? '검색 결과가 없어요' : '상품명이나 품번으로 검색하면 크림 상품이 나와요'}</span></div>`}</div>
    <div class="panel km-side"><div class="km-h">${ico('zap')}<b>매크로 목록</b><span class="hint">${wait.length}줄 대기 · ${done.length}줄 신청 성공</span></div>
      <div class="km-stats"><div><span>실행 대상</span><b>${on.length}<small>줄</small></b></div><div><span>남은 수량</span><b>${wait.reduce((a, e) => a + sqLeft(e), 0)}<small>개</small></b></div><div class="ok"><span>신청 성공</span><b>${done.reduce((a, e) => a + (e.passed || 0), 0)}<small>개</small></b></div><div><span>오늘 시도</span><b>${tries}<small>번</small></b></div></div>
      <div class="km-run ${SQ.run ? 'on' : ''}"><i></i>${SQ.run ? '매크로 실행 중' : '대기 중'}${SQ.run && SQ.started ? ` · <span data-kmclock="${SQ.started}">${kmClock(SQ.started)}</span>` : ''}</div>
      <div class="km-list">${on.slice(0, 8).map(e => `<div><b>${esc(e.name || e.code)}</b><small>${esc(e.ksize || e.size)} · ${e.passed || 0}/${sqWant(e)}개</small></div>`).join('') || '<p class="hint">아래 표에서 실행할 줄을 고르면 여기에 보여요</p>'}</div></div></div>`;
}
const kmClock = t => { const s = Math.max(0, Math.floor((Date.now() - t) / 1000)); return [Math.floor(s / 3600), Math.floor(s / 60) % 60, s % 60].map(n => String(n).padStart(2, '0')).join(':'); };
setInterval(() => { document.querySelectorAll('[data-kmclock]').forEach(el => { el.textContent = kmClock(+el.dataset.kmclock); }); }, 1000);
function vKMacro() {
  return `${xHead('보관판매 매크로', '재고관리에 있는 상품, 또는 크림에서 직접 찾은 상품을 크림 보관 신청에 1~2개씩 나눠서 넣어요. 모델번호·사이즈·수량이 하나라도 다르면 결제하지 않고 멈춰요.', `<a class="ghost" href="https://kream.co.kr/my/inventory" target="_blank" rel="noopener">크림 보관판매 열기</a>`)}${vKmFind()}${vStockMacro()}${sqCmpPanel()}`;
}
// ---------- 3.2: 판매 · 구매 내역 (한 화면에) ----------
function kTable(rows, extra) {
  return rows.length ? `<div class="tbl"><table><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th>가격</th><th class="l">상태</th><th class="l">날짜</th>${extra ? '<th class="l">구분</th>' : ''}</tr></thead><tbody>${rows.map(r => `<tr><td class="l name"><b>${esc(r.name)}</b><span class="code">${esc(r.code)}</span></td><td class="l">${esc(r.size)}</td><td>${won(r.price)}</td><td class="l">${esc(r.status)}</td><td class="l small">${esc(String(r.date).slice(0, 16).replace('T', ' '))}</td>${extra ? `<td class="l"><span class="pill mute">${esc(r.kind || '')}</span></td>` : ''}</tr>`).join('')}</tbody></table></div>` : '';
}
// 3.21: 기간 · 검색 · 사업자 구분 · 엑셀
const kDay = d => String(d || '').slice(0, 10);
const kAgo = n => { const d = new Date(); d.setDate(d.getDate() - n); return fmtD(d); };
function kHistRange() { const H = XS.hist = XS.hist || { from: kAgo(30), to: today(), q: '', biz: typeof bizCur === 'function' && bizCur().type === '간이' ? 'simple' : 'gen' }; return H; }
function kSearchHit(r, q) { q = String(q || '').trim().toLowerCase(); if (!q) return true; const k = ckey(q); return `${r.name} ${r.code} ${r.size} ${r.status}`.toLowerCase().includes(q) || (k.length >= 3 && ckey(r.code).includes(k)); }
const kStPill = st => { st = String(st || ''); const c = /취소|불합격|페널티|패널티|거절|실패|반송/.test(st) ? 'bad' : /완료|정산|확정/.test(st) ? 'ok' : /회수|보류|대기|중/.test(st) ? 'warn' : 'mute'; return `<span class="pill ${c}">${esc(st || '–')}</span>`; };
function vKHist() {
  const B0 = XS.km.buying, H = kHistRange(), tab = XS.histTab || 'sell';
  const sold = typeof INV !== 'undefined' ? INV.outs.filter(o => o.kreamSaleId).sort((a, b) => String(b.settleDate).localeCompare(String(a.settleDate))) : [];
  const sAll = sold.map(o => { const it = itemOf(o.itemId), n = outNums(o); return { o, name: itName(it), code: it ? it.code : '', size: o.size, price: o.price, fee: n.fee, settle: o.price - n.fee, cost: n.unitCost, margin: n.margin, status: '정산완료', date: o.settleDate, kind: String(o.kreamSaleId).startsWith('S') ? '보관 판매' : '일반 판매' }; });
  const bAll = B0 ? kRows(B0.cap) : [];
  const inR = r => { const d = kDay(r.date); return !d || ((!H.from || d >= H.from) && (!H.to || d <= H.to)); };
  const sr = sAll.filter(r => inR(r) && kSearchHit(r, H.q)), br = bAll.filter(r => inR(r) && kSearchHit(r, H.q));
  const rows = tab === 'sell' ? sr : br;
  const sum = rows.reduce((s, r) => s + (+r.price || 0), 0);
  const quick = [[7, '최근 7일'], [30, '최근 30일'], [90, '최근 90일']].map(([n, t]) => `<button type="button" class="kq${H.from === kAgo(n) && H.to === today() ? ' on' : ''}" data-x="histDays" data-v="${n}">${t}</button>`).join('');
  const vat = r => H.biz === 'gen' ? Math.round(r.price - r.price / 1.1) : Math.round(r.price * 0.15 * 0.1);
  const table = tab === 'sell'
    ? (rows.length ? `<div class="tbl kh-tbl"><table><thead><tr><th class="l">정산일</th><th class="l">상품</th><th class="l">사이즈</th><th class="l">구분</th><th>판매가</th><th>수수료</th><th>정산금</th><th>매입가</th><th>마진</th><th>예상 부가세<small>${H.biz === 'gen' ? '일반 · 판매가의 1/11' : '간이 · 소매 15% × 10%'}</small></th></tr></thead><tbody>${rows.map(r => `<tr><td class="l small">${esc(kDay(r.date))}</td><td class="l name"><b>${esc(r.name)}</b><span class="code">${esc(r.code)}</span></td><td class="l">${esc(r.size)}</td><td class="l"><span class="pill ${r.kind === '보관 판매' ? 'warn' : 'mute'}">${esc(r.kind)}</span></td><td>${won(r.price)}</td><td class="sub">−${won(r.fee)}</td><td><b>${won(r.settle)}</b></td><td>${won(r.cost)}</td><td class="${r.margin > 0 ? 'pos' : r.margin < 0 ? 'neg' : ''}"><b>${wonS(r.margin)}</b></td><td class="sub">${won(vat(r))}</td></tr>`).join('')}</tbody></table></div>` : '')
    : kTable(rows, false);
  const empty = tab === 'sell' ? (sAll.length ? '이 기간 · 검색어에 맞는 판매가 없어요.' : '매출에 넣은 크림 판매가 아직 없어요. 위의 <b>판매 정산 → 매출에 넣기</b>를 누르세요.') : (B0 ? (bAll.length ? '이 기간 · 검색어에 맞는 구매가 없어요.' : '내역이 없어요.') : '<b>크림에서 둘 다 불러오기</b>를 누르세요. 크림에 로그인돼 있어야 해요.');
  const preN = typeof INV !== 'undefined' ? INV.outs.filter(o => o.kind === 'pre' && !o.settled).length : 0;
  return `${xHead('판매 · 구매 내역', '크림 판매(정산 완료)와 구매 내역을 기간별로 보고, 엑셀로 받아요.', `<button type="button" class="primary" data-x="kSales"${SQ.salesBusy ? ' disabled' : ''}>${SQ.salesBusy ? '정산 읽는 중…' : '판매 정산 → 매출에 넣기'}</button><button type="button" class="ghost" data-x="kLoadMany" data-v="selling,buying"${XS.busy ? ' disabled' : ''}>크림에서 둘 다 불러오기</button>`)}
  ${SQ.salesMsg ? `<p class="iflash${/못|풀려|실패|없어요/.test(SQ.salesMsg) ? ' neg' : ''}">${esc(SQ.salesMsg)}</p>` : ''}
  <div class="kh-tabs"><button type="button" class="${tab === 'sell' ? 'on' : ''}" data-x="histTab" data-v="sell">${ico('receipt')}판매 내역 <span>${sr.length}</span></button><button type="button" class="${tab === 'buy' ? 'on' : ''}" data-x="histTab" data-v="buy">${ico('bag')}구매 내역 <span>${br.length}</span></button></div>
  <div class="panel kh-bar">
    <div class="kh-row"><span class="kh-lab">${ico('cal')}${tab === 'sell' ? '정산 기간' : '기간'}</span><input type="date" data-xk="histFrom" value="${esc(H.from)}"><span class="sub">~</span><input type="date" data-xk="histTo" value="${esc(H.to)}">${quick}<button type="button" class="kq" data-x="histDays" data-v="0">전체</button></div>
    <div class="kh-row">${tab === 'sell' ? `<button type="button" class="kh-xl" data-x="histXl"${rows.length ? '' : ' disabled'}>${ico('sheet')}판매 내역 엑셀</button><div class="dl-seg kh-biz"><button type="button" data-x="histBiz" data-v="gen" aria-pressed="${H.biz === 'gen'}">일반사업자</button><button type="button" data-x="histBiz" data-v="simple" aria-pressed="${H.biz === 'simple'}">간이사업자</button></div><button type="button" class="kh-pre" data-x="histPre">${ico('zap')}우선출고 대량 정산${preN ? ` <span>${preN}</span>` : ''}</button>` : `<button type="button" class="kh-xl" data-x="histXl"${rows.length ? '' : ' disabled'}>${ico('sheet')}구매 내역 엑셀</button>`}</div>
    <label class="dl-search kh-q">${ico('search')}<input data-xk="histQ" value="${esc(H.q)}" placeholder="품번 · 상품명 · 사이즈 · 상태 검색" autocomplete="off"></label>
  </div>
  <div class="kgrid">${tab === 'sell' ? `${card('판매 건수', rows.length + '건', 'acc')}${card('판매 금액', won(sum), 'violet')}${card('정산금 합계', won(rows.reduce((a, r) => a + r.settle, 0)), 'warn')}${card('마진 합계', wonS(rows.reduce((a, r) => a + (r.margin || 0), 0)), rows.reduce((a, r) => a + (r.margin || 0), 0) >= 0 ? 'pos' : 'neg')}` : `${card('구매 건수', rows.length + '건', 'acc')}${card('금액 합계', won(sum), 'violet')}${card('불러온 시각', B0 ? new Date(B0.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '–')}`}</div>
  ${table || `<div class="panel dl-empty">${ico('receipt')}<span>${empty}</span></div>`}
  ${tab === 'sell' ? `<p class="hint">예상 부가세는 참고용이에요 (일반사업자: 판매가 ÷ 11, 간이사업자: 소매업 부가가치율 15% × 10%). 실제 신고는 세무사나 홈택스 기준을 따르세요. 현금영수증 일괄 발행 양식은 아직 없어요.</p>` : ''}`;
}
// ---------- 3.21: 취소 · 반송 관리 (상태별 탭 · 처리 결과 · 검색) ----------
const KC_TABS = [['all', '전체'], ['cancel', '일반 취소'], ['fail', '보관 불합격'], ['back', '보관 회수중'], ['backed', '보관 회수완료'], ['etc', '반송 · 페널티 · 기타']];
function kcTab(r) {
  const st = String(r.status || '');
  if (r.kind === '보관') { if (/회수/.test(st)) return /완료/.test(st) ? 'backed' : 'back'; if (/불합격|검수\s*(보류|불)|반송/.test(st)) return 'fail'; }
  if (/취소/.test(st)) return 'cancel';
  return 'etc';
}
function vKCancel() {
  const inv = kInv && kInv.items ? kInv.items.map(i => ({ name: i.name, code: i.code, size: i.sizeName || i.size, price: '', status: i.statusName || i.status, date: i.date, exp: '', kind: '보관' })) : [];
  const all = [['selling', '판매'], ['buying', '구매']].flatMap(([p, kind]) => XS.km[p] ? kRows(XS.km[p].cap).map(r => ({ ...r, kind })) : []).concat(inv);
  const trouble = all.filter(r => K_TROUBLE.test(String(r.status))).map(r => ({ ...r, tab: kcTab(r) })).sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const C = XS.kc = XS.kc || { tab: 'all', st: '', q: '' };
  const sts = [...new Set(trouble.map(r => String(r.status)))].sort();
  if (C.st && !sts.includes(C.st)) C.st = '';
  const base = trouble.filter(r => (!C.st || String(r.status) === C.st) && kSearchHit(r, C.q));
  const cnt = k => k === 'all' ? base.length : base.filter(r => r.tab === k).length;
  const rows = base.filter(r => C.tab === 'all' || r.tab === C.tab);
  const any = ['selling', 'buying'].some(p => XS.km[p]) || !!kInv;
  const last = Math.max(0, ...['selling', 'buying'].map(p => XS.km[p] ? XS.km[p].at || 0 : 0), kInv ? kInv.at || 0 : 0);
  const table = rows.length ? `<div class="tbl kh-tbl"><table><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th class="l">구분</th><th class="l">상태</th><th>가격</th><th class="l">날짜</th></tr></thead><tbody>${rows.map(r => `<tr><td class="l name"><b>${esc(r.name)}</b><span class="code">${esc(r.code)}</span></td><td class="l">${esc(r.size)}</td><td class="l"><span class="pill mute">${esc(r.kind)}</span></td><td class="l">${kStPill(r.status)}</td><td>${r.price ? won(r.price) : '–'}</td><td class="l small">${esc(String(r.date || '').slice(0, 16).replace('T', ' '))}</td></tr>`).join('')}</tbody></table></div>` : '';
  return `${xHead('취소 · 반송 관리', '판매 · 구매 · 보관 내역에서 취소 · 불합격 · 회수 · 페널티처럼 처리해야 할 건만 모아 봐요.', `<button type="button" class="primary" data-x="kLoadMany" data-v="selling,buying,inventory"${XS.busy ? ' disabled' : ''}>${ico('refresh')}크림에서 전부 불러오기</button>`)}
  <div class="panel kh-bar"><div class="kh-row"><span class="sub">${last ? '마지막 불러옴 ' + new Date(last).toLocaleString('ko-KR') : '아직 불러온 내역이 없어요'}</span></div>
    <label class="dl-search kh-q">${ico('search')}<input data-xk="kcQ" value="${esc(C.q)}" placeholder="상품명 · 품번 · 사이즈 · 상태 검색" autocomplete="off"></label>
    <div class="kh-row"><div class="kh-tabs2">${KC_TABS.map(([k, t]) => `<button type="button" class="${C.tab === k ? 'on' : ''}" data-x="kcTab" data-v="${k}">${t} <span>${cnt(k)}</span></button>`).join('')}</div><span class="topsp"></span><select data-xk="kcSt" aria-label="처리 결과"><option value="">모든 처리 결과</option>${sts.map(s => `<option value="${esc(s)}"${C.st === s ? ' selected' : ''}>${esc(s)}</option>`).join('')}</select></div></div>
  <div class="kgrid">${card('처리할 건', trouble.length + '건', trouble.length ? 'warn' : '')}${card('보관 불합격', trouble.filter(r => r.tab === 'fail').length + '건', trouble.some(r => r.tab === 'fail') ? 'neg' : '')}${card('보관 회수중', trouble.filter(r => r.tab === 'back').length + '건', trouble.some(r => r.tab === 'back') ? 'warn' : '')}${card('확인한 내역', all.length + '건', 'acc')}</div>
  ${table || `<div class="panel dl-empty">${ico('undo')}<span>${any ? (trouble.length ? '이 탭 · 검색어에 맞는 건이 없어요.' : '취소 · 반송된 건이 없어요.') : '<b>크림에서 전부 불러오기</b>를 누르세요. 크림에 로그인돼 있어야 해요.'}</span>${any ? '' : `<button type="button" class="ghost" data-x="kLoadMany" data-v="selling,buying,inventory">불러오기</button>`}</div>`}
  <p class="hint">반송 상품을 다시 재고로 넣거나 판매 반품으로 처리하는 건 재고관리 → <b>반품 · 교환</b>에서 해요.</p>`;
}
// ---------- 3.2: 나이키 주문내역 ----------
function vNike() {
  const rows = typeof ordRows === 'function' ? ordRows().filter(x => x.site === 'nike') : [];
  const C = (typeof ordCache !== 'undefined' && ordCache.nike) || null;
  return `${xHead('나이키 주문내역', '나이키 공식몰 주문을 불러와서 보고, 재고관리에 입고해요.', `<button type="button" class="primary" data-x="nikeSync"${XS.busy ? ' disabled' : ''}>나이키 주문 불러오기</button><button type="button" class="ghost" data-x="goInv" data-v="nike">재고관리에서 입고</button><a class="ghost" href="https://www.nike.com/kr/orders" target="_blank" rel="noopener">나이키에서 열기</a>`)}
  <div class="kgrid k3">${card('주문 상품', rows.length + '개')}${card('입고 안 한 것', rows.filter(x => !x.done && !x.cancel).length + '개', rows.some(x => !x.done && !x.cancel) ? 'warn' : '')}${card('불러온 시각', C ? new Date(C.at).toLocaleString('ko-KR') : '–')}</div>
  ${C && C.msg ? `<p class="iflash">${esc(C.msg)}</p>` : ''}
  <div class="tbl"><table><thead><tr><th class="l">주문일</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th>수량</th><th>매입가</th><th class="l">상태</th><th class="l">재고</th></tr></thead><tbody>${rows.map(x => `<tr class="${x.cancel ? 'err' : ''}"><td class="l">${esc(x.date)}</td><td class="l name"><b>${esc(x.name)}</b></td><td class="l">${esc(x.code || '')}</td><td class="l">${esc(x.size)}</td><td>${x.qty}</td><td>${won(x.unit)}</td><td class="l small">${esc(x.status)}</td><td class="l">${x.done ? '<span class="pill ok">입고함</span>' : x.cancel ? '<span class="pill bad">취소</span>' : '<span class="pill mute">안 함</span>'}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">아직 불러온 주문이 없어요. <b>나이키 주문 불러오기</b>를 누르세요 (나이키에 로그인돼 있어야 해요 — 계정 연결에서 확인).</td></tr>'}</tbody></table></div>`;
}
function vReviewPage() { return `${xHead('후기 자동 작성', '무신사 후기를 쓸 수 있는 주문을 모아서, 별점 5점과 후기 글을 자동으로 만들어 등록해요.')}${vReviews()}`; }
// ---------- 3.3: 크림 · 입점 (판매자 센터 partner.kream.co.kr) ----------
// 판매자 센터 화면 구조를 아직 실제로 못 봤어요. 그래서 판매자 센터 창을 열어 두고, 원하는 화면에서 '지금 화면 읽기'를 누르면 그 화면의 표를 그대로 가져와요.
const PM = {
  pbid: { t: '일반판매 입찰 & 관리 (입점)', d: '판매자 센터의 일반판매 입찰 목록 화면을 열고 \'지금 화면 읽기\'를 누르면 표를 가져와요.' },
  pinv: { t: '보관판매 관리 (입점)', d: '판매자 센터의 보관판매(신청·보관 중) 화면을 읽어 와요.' },
  pmacro: { t: '보관판매 매크로 (입점)', d: '입점 계정의 보관 신청 화면을 한 번 읽어 두면, 그 화면 구조에 맞춰 개인 계정처럼 1~2개씩 자동 신청하도록 맞춰 넣을 수 있어요.' },
  pship: { t: '발송관리 (입점)', d: '판매자 센터의 발송 대기·발송 요청 화면을 읽어 와요.' },
  psales: { t: '판매내역 (입점)', d: '판매자 센터의 판매(정산) 내역 화면을 읽어 와요.' }
};
const PARTNER_URL = 'https://partner.kream.co.kr';
function vPartner(v) {
  const P = PM[v], D = partnerData[v];
  const st = (typeof acctState !== 'undefined' && acctState.kreamp) || {};
  const tbl = D && D.rows.length ? `<div class="tbl"><table><thead><tr>${(D.head.length ? D.head : D.rows[0].map((_, i) => '칸 ' + (i + 1))).map(h => `<th class="l">${esc(h)}</th>`).join('')}</tr></thead><tbody>${D.rows.map(r => `<tr>${r.map(c => `<td class="l">${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : '';
  return `${xHead(P.t, P.d, `<button type="button" class="primary" data-x="pOpen">판매자 센터 열기</button><button type="button" class="ghost" data-x="pRead" data-v="${v}"${XS.busy ? ' disabled' : ''}>지금 화면 읽기</button>${tbl ? `<button type="button" class="ghost" data-x="pXl" data-v="${v}">엑셀</button>` : ''}`)}
  <div class="kgrid k3">${card('입점 계정', st.st === 'on' ? '로그인됨' : st.st === 'off' ? '로그인 필요' : '확인 전', st.st === 'off' ? 'warn' : '')}${card('읽은 줄', D ? D.rows.length + '줄' : '–')}${card('읽은 화면', D ? new Date(D.at).toLocaleString('ko-KR') : '–')}</div>
  ${D ? `<p class="hint">읽은 주소: ${esc(D.url)} · ${esc(D.title || '')}</p>` : ''}
  ${tbl || `<div class="panel"><p class="empty">${D ? '그 화면에서 표를 못 찾았어요. 목록이 보이는 화면에서 다시 눌러 주세요.' : '① <b>판매자 센터 열기</b> → 로그인(이메일 + 문자 인증) → ② 이 메뉴에 맞는 화면으로 이동 → ③ <b>지금 화면 읽기</b>'}</p></div>`}
  ${v === 'pmacro' ? '<div class="panel"><p class="hint">입점 계정 보관 신청은 화면 구조를 아직 못 봐서 <b>자동 신청은 아직 안 돼요</b>. 판매자 센터의 보관 신청 화면을 열고 \'지금 화면 읽기\'를 한 번 눌러 두면, 그 내용을 보고 개인 계정 매크로처럼(모델번호·사이즈·수량 검사 후 1~2개씩) 맞춰 넣을게요.</p></div>' : ''}`;
}
async function partnerTab() {
  if (XS.pwin) { try { await chrome.windows.get(XS.pwin.winId); return XS.pwin.tabId; } catch (e) { XS.pwin = null; } }
  const w = await chrome.windows.create({ url: PARTNER_URL, type: 'popup', width: 1280, height: 900, focused: true });
  XS.pwin = { winId: w.id, tabId: w.tabs[0].id };
  return XS.pwin.tabId;
}
// ---------- 3.3: 일반판매 입찰 — 크림 최저가 · 포이즌 가격 비교 ----------
async function runBidCompare(withPz) {
  const D = XS.km.selling; if (!D) return xSet('먼저 크림에서 불러오기를 눌러 주세요');
  const rows = kRows(D.cap).filter(r => r.pid);
  const pids = [...new Set(rows.map(r => r.pid))].slice(0, 15);
  if (!pids.length) return xSet('비교할 판매 입찰이 없어요');
  xRun(async () => {
    let i = 0;
    for (const pid of pids) {
      i++; xSet(`크림 최저가 확인 중… (${i}/${pids.length})`);
      const p = { id: 'bid', pid, raw: null };
      try { await collectOne(p, { days: 7, maxPages: 2 }); } catch (e) { bidCmp[pid] = { at: Date.now(), err: e.message }; continue; }
      const a = analyze(p), info = p.raw.info || {};
      const sizes = {}; for (const x of a.sizes) sizes[ckey(x.o)] = { minAsk: x.minAsk ?? null, sell: x.sell ?? null };
      let pz = {};
      if (withPz) {
        const code = String(info.code || '').split('/').map(t => t.trim()).find(c => /\d/.test(c));
        if (code) {
          xSet(`포이즌 가격 확인 중… (${i}/${pids.length})`);
          try {
            const tabId = await srcNav(`https://kr.poizon.com/search?keyword=${encodeURIComponent(code)}`); await sleep(1800);
            const links = await inTab(tabId, kcPoizonLinks) || [];
            if (links[0]) { await srcNav(links[0].url); const r = await inTab(work.tabId, kcPoizon); if (r) for (const z of r.sizes) if (z.price) { const k = ckey(z.kr); pz[k] = pz[k] == null ? z.price : Math.min(pz[k], z.price); } }
          } catch (e) {}
        }
      }
      bidCmp[pid] = { at: Date.now(), name: info.name || '', sizes, pz };
    }
    await store.set('bidCmp', bidCmp);
    xSet(`비교 끝 — ${pids.length}개 상품`);
  });
}
function bidCell(r) {
  const C = bidCmp[r.pid]; if (!C) return '<td class="l small">–</td><td class="l small">–</td>';
  if (C.err) return `<td class="l small neg" colspan="2">${esc(C.err)}</td>`;
  const k = ckey(r.size), x = C.sizes[k] || {}, pz = C.pz ? C.pz[k] : null;
  const min = x.minAsk, me = +r.price || 0;
  const rank = min == null ? '<span class="pill mute">최저가 없음</span>' : me && me <= min ? '<span class="pill ok">내가 최저가</span>' : `<span class="pill warn">최저가 ${won(min)} · ${won(me - min)} 비쌈</span>`;
  return `<td class="l">${rank}</td><td>${pz ? won(pz) : '–'}</td>`;
}
const X_VIEWS = { guide: () => vGuide(), drops: vDrops, pbid: () => vPartner('pbid'), pinv: () => vPartner('pinv'), pmacro: () => vPartner('pmacro'), pship: () => vPartner('pship'), psales: () => vPartner('psales'), acct: () => vAcct(), kmacro: vKMacro, khist: vKHist, kcancel: vKCancel, nike: vNike, reviews: vReviewPage, dual: vDual, msstock: vMsStock, mstrack: vMsTrack, orders: vOrders, kauto: () => vAutoBid(), ksell: () => vKream('ksell'), kbuy: () => vKream('kbuy'), kinv: vKInv, kship: () => vKream('kship') };
let xView = 'dual';
function renderX(v) {
  if (v && v !== xView) { xView = v; if (!XS.busy) XS.msg = ''; }
  const m = xMain(); if (!m || $('#tab-x').hidden) return;
  m.innerHTML = (X_VIEWS[xView] || vDual)();
}
async function xAct(a, el) {
  if (/^ab[A-Z]/.test(a)) return abAct(a, el);
  const i = el.dataset.i;
  switch (a) {
    case 'dualRun': return runDual();
    case 'dualLoad': { const h = dualHist.find(x => String(x.at) === i); if (h) { XS.dual = h; XS.dualQ = h.q; XS.dualCost = h.cost || ''; } return renderX(); }
    case 'dualDel': dualHist = dualHist.filter(x => String(x.at) !== i); await store.set('dualHist', dualHist); return renderX();
    case 'dualClear': dualHist = []; await store.set('dualHist', dualHist); return renderX();
    case 'dualPf': { const k = el.dataset.v; DO[k] = !DO[k]; if (!DO.pk && !DO.pp) DO[k === 'pk' ? 'pp' : 'pk'] = true; await dualSave(); return renderX(); }
    case 'dualDeep': DO.deep = !DO.deep; await dualSave(); return renderX();
    case 'dualPzCat': DO.pzCat = el.dataset.v === 'acc' ? 'acc' : 'wear'; await dualSave(); return renderX();
    case 'dualFlt': { const o = DO[el.dataset.v]; if (o) { o.on = !o.on; await dualSave(); } return renderX(); }
    case 'dualFltM': { const o = DO[i]; if (o) { o.m = el.dataset.v === 'lt' ? 'lt' : 'ge'; await dualSave(); } return renderX(); }
    case 'msRun': return runMs();
    case 'msPick': XS.msQ = i; return runMs(i);
    case 'msAgain': XS.msQ = i; return runMs(i);
    case 'trAddUrl': return trAddUrl();
    case 'guideM': XS.guideM = el.dataset.v; XS.guideI = -1; renderX(); return;
    case 'guideGo': XS.guideI = +el.dataset.v; renderX(); try { document.querySelector('.guide-body').scrollIntoView({ block: 'start' }); } catch (e) {} return;
    case 'guideOpen': return route(el.dataset.v);
    case 'guideWiz': return window.wizOpen ? window.wizOpen() : null;
    case 'dropLoad': if (!needExt()) return; return xRun(() => runDrops(false));
    case 'dropTab': XS.dropTab = el.dataset.v; return renderX();
    case 'msTrackAdd': { const R = XS.ms; const t = msTracks.find(x => x.goodsNo === R.goodsNo && (x.site || 'musinsa') === (R.site || 'musinsa')) || { id: uid(), site: R.site || 'musinsa', host: R.site === 'abc' ? trHost(R.url) : undefined, url: R.generic ? R.url : undefined, goodsNo: R.goodsNo, name: `${R.brand ? R.brand + ' ' : ''}${R.name || ''}`.trim(), sizes: [], mode: 'both', target: 0, on: true, log: [] }; return trackDialog(t, R); }
    case 'msXl': { const R = XS.ms; const cnt = s => s.out ? 0 : s.qty != null ? (R.maxOrder ? Math.min(s.qty, R.maxOrder) : s.qty) : s.min ? s.min + '개 이상' : '넉넉함'; return xlDownload([{ name: '재고', rows: [['쇼핑몰', '상품번호', '상품', '옵션', '재고', '주문 가능 수량', '구매 제한', '출고 예정', '판매가', '최대 혜택가'], ...R.sizes.map(s => [STOCK_SITES[R.site || 'musinsa'], R.goodsNo, R.name, s.label, s.out ? '품절' : '있음', cnt(s), R.maxOrder ? (R.maxScope === 'id' ? '아이디당 ' : '한 번에 ') + R.maxOrder + '개' : '', s.release || '', s.price || (R.price ? R.price.salePrice : ''), R.price ? (R.price.finalPrice || R.price.couponPrice || '') : ''])], widths: [12, 12, 40, 20, 8, 14, 14, 12, 10, 12] }], `재고조회_${R.goodsNo}_${today()}.xlsx`); }
    case 'msHistXl': return xlDownload([{ name: '조회기록', rows: [['조회 시각', '쇼핑몰', '상품번호', '상품', '가격', '재고 있는 옵션(수량)', '품절 옵션'], ...msHist.map(h => [new Date(h.at).toLocaleString('ko-KR'), STOCK_SITES[h.site || 'musinsa'], h.goodsNo, h.name, h.price ? (h.price.finalPrice || h.price.salePrice) : '', h.sizes.filter(s => !s.out).map(s => (s.size || s.label) + (s.qty != null ? `(${s.qty})` : '')).join(', '), h.sizes.filter(s => s.out).map(s => s.size || s.label).join(', ')])], widths: [20, 12, 12, 40, 12, 40, 40] }], `재고조회_기록_${today()}.xlsx`);
    case 'msHistClear': msHist = []; await store.set('msHist', msHist); return renderX();
    case 'trRun': if (!needExt()) return; return xRun(() => runMsTrack(false));
    case 'trEdit': { const t = msTracks.find(x => x.id === i); return trackDialog(t, null); }
    case 'trDel': msTracks = msTracks.filter(x => x.id !== i); await store.set('msTracks', msTracks); return renderX();
    case 'ordSync': { if (!needExt()) return; const days = +(document.querySelector('[data-xk=ordDays]') || {}).value || 90; return xRun(async () => { xSet('무신사 주문 불러오는 중… (작은 창이 열려요)'); await importMusinsaOrders(days); xSet(($('#impMsg') && $('#impMsg').textContent || '').replace(/ 휴대폰에서 보려면.*$/, '')); }); }
    case 'ordXl': { const L = records.filter(r => r.musinsaId || /^ms-/.test(r.id)); return xlDownload([{ name: '무신사주문', rows: [['주문일', '주문번호', '상품', '옵션', '수량', '개당 결제금액', '결제 합계', '상태'], ...L.map(r => [r.buyDate, String(r.memo || '').match(/주문 (\S+)/)?.[1] || '', r.name, r.size, +r.qty || 1, +r.cost || 0, (+r.cost || 0) * (+r.qty || 1), String(r.memo || '').replace(/^무신사 주문 \S+ · /, '')])], widths: [12, 22, 44, 14, 6, 12, 12, 16] }], `무신사주문_${today()}.xlsx`); }
    case 'ordInv': return route('inv:ms');
    case 'rvLoad': {
      if (!needExt()) return;
      return xRun(async () => {
        xSet('무신사 후기 목록 불러오는 중… (작은 창이 열려요)');
        const tabId = await srcNav('https://www.musinsa.com/mypage/myreview');
        await sleep(1200);
        const d0 = new Date(); d0.setMonth(d0.getMonth() - 6);
        const f = d => d.toISOString().slice(0, 10);
        const r = await inTab(tabId, kcMsReviews, [f(d0), today()]);
        if (!r) throw new Error('목록을 못 읽었어요');
        if (!r.login) throw new Error('무신사 로그인이 필요해요');
        XS.rv = { at: Date.now(), count: r.count, list: r.list };
        xSet(`작성 가능한 후기 ${r.count ? r.count.writableCount : r.list.length}개`);
      });
    }
    case 'kLoad': return runKream(el.dataset.v);
    case 'kLoadMany': return runKreamMany(String(el.dataset.v).split(','));
    case 'bidCmp': return runBidCompare(true);
    case 'pOpen': { await partnerTab(); return xSet('판매자 센터 창을 열었어요. 로그인하고 원하는 화면으로 간 다음 \'지금 화면 읽기\'를 누르세요.'); }
    case 'pRead': {
      const v = el.dataset.v;
      if (!XS.pwin) return xSet('먼저 \'판매자 센터 열기\'를 눌러 주세요');
      let r = null; try { r = await inTab(XS.pwin.tabId, kcTableRead); } catch (e) { XS.pwin = null; return xSet('판매자 센터 창이 닫혔어요. 다시 열어 주세요'); }
      if (!r) return xSet('화면을 못 읽었어요');
      if (/login|signin|auth/i.test(r.url)) return xSet('판매자 센터에 로그인해 주세요');
      partnerData[v] = { at: Date.now(), url: r.url, title: r.title, head: r.head, rows: r.rows };
      await store.set('partnerData', partnerData);
      xSet(`${r.rows.length}줄 읽었어요`); return renderX();
    }
    case 'pXl': { const D = partnerData[el.dataset.v]; if (!D) return; const head = D.head.length ? D.head : D.rows[0].map((_, i) => '칸 ' + (i + 1)); return xlDownload([{ name: '입점', rows: [head, ...D.rows], widths: head.map(() => 18) }], `크림입점_${PM[el.dataset.v].t.split(' (')[0].replace(/\W+/g, '')}_${today()}.xlsx`); }
    case 'rvAll': if (!needExt()) return; return xRun(() => rvRunAll(null));
    case 'rvOne': if (!needExt()) return; return xRun(() => rvRunAll(el.dataset.i));
    case 'rvFill': {
      if (!needExt()) return;
      const no = el.dataset.i, nm = el.dataset.n, D = rvDraft[no] || {};
      if (!String(D.text || '').trim()) return xSet('후기 글을 먼저 적어 주세요');
      return xRun(async () => {
        xSet('무신사 후기 화면 여는 중…');
        let tabId = await srcNav('https://www.musinsa.com/mypage/myreview');
        const o = await inTab(tabId, kcMsReviewOpen, [no, nm], 'MAIN');
        if (!o || !o.ok) throw new Error(o && o.why === 'nobtn' ? '후기 작성 버튼을 못 찾았어요 — 무신사 후기 화면에서 직접 눌러 주세요' : '그 주문의 후기 작성 버튼을 못 찾았어요');
        await sleep(2500);
        tabId = work.tabId;
        const f = await inTab(tabId, kcReviewFill, [D.text, D.star || 5], 'MAIN');
        if (!f || !f.ok) throw new Error('후기 글 칸을 못 찾았어요 — 열린 창에 직접 붙여 넣어 주세요');
        XS.keepWork = true;
        try { await chrome.windows.update(work.winId, { focused: true, state: 'normal' }); } catch (e) {}
        xSet(`후기 글을 넣었어요${f.star ? ' (별점도)' : ' — 별점은 직접 골라 주세요'}. 열린 무신사 창에서 내용을 확인하고 '등록'을 눌러 주세요.`);
      });
    }
    case 'histTab': XS.histTab = el.dataset.v; return renderX();
    case 'histDays': { const H = kHistRange(), n = +el.dataset.v; if (n) { H.from = kAgo(n); H.to = today(); } else { H.from = ''; H.to = ''; } return renderX(); }
    case 'histBiz': kHistRange().biz = el.dataset.v === 'simple' ? 'simple' : 'gen'; return renderX();
    case 'histPre': return route('inv:pre');
    case 'histXl': {
      const H = kHistRange(), tab = XS.histTab || 'sell', inR = r => { const d = kDay(r.date); return !d || ((!H.from || d >= H.from) && (!H.to || d <= H.to)); };
      const per = `${H.from || '처음'}~${H.to || '오늘'}`;
      if (tab === 'sell') {
        const L = INV.outs.filter(o => o.kreamSaleId).map(o => { const it = itemOf(o.itemId), n = outNums(o); return { o, it, n, date: o.settleDate, name: itName(it), code: it ? it.code : '', size: o.size, status: '' }; }).filter(r => inR(r) && kSearchHit(r, H.q));
        const head = ['정산일', '구분', '상품', '품번', '사이즈', '판매가', '수수료', '정산금', '매입가', '마진', H.biz === 'gen' ? '공급가액' : '예상 부가세(간이)', H.biz === 'gen' ? '부가세' : ''];
        return xlDownload([{ name: '판매 내역', rows: [head, ...L.map(r => { const p = r.o.price, vat = H.biz === 'gen' ? [Math.round(p / 1.1), p - Math.round(p / 1.1)] : [Math.round(p * 0.015), '']; return [r.date, String(r.o.kreamSaleId).startsWith('S') ? '보관 판매' : '일반 판매', r.name, r.code, r.size, p, r.n.fee, p - r.n.fee, Math.round(r.n.unitCost), Math.round(r.n.margin), ...vat]; })] }], `크림 판매 내역 ${per}.xlsx`);
      }
      const L = (XS.km.buying ? kRows(XS.km.buying.cap) : []).filter(r => inR(r) && kSearchHit(r, H.q));
      return xlDownload([{ name: '구매 내역', rows: [['날짜', '상품', '품번', '사이즈', '가격', '상태'], ...L.map(r => [kDay(r.date), r.name, r.code, r.size, r.price, r.status])] }], `크림 구매 내역 ${per}.xlsx`);
    }
    case 'kfTab': { const F = (XS.kf = XS.kf || {})[i] = (XS.kf[i] || { q: '', tab: 'all' }); F.tab = el.dataset.v; return renderX(); }
    case 'kfGroup': case 'kfWait': { const F = (XS.kf = XS.kf || {})[i] = (XS.kf[i] || { q: '', tab: 'all' }); F[a === 'kfGroup' ? 'group' : 'hideWait'] = !F[a === 'kfGroup' ? 'group' : 'hideWait']; return renderX(); }
    case 'kcTab': (XS.kc = XS.kc || { tab: 'all', st: '', q: '' }).tab = el.dataset.v; return renderX();
    case 'goView': return route(el.dataset.v);
    case 'goInv': { if (typeof IS !== 'undefined') { IS.ms.site = el.dataset.v; } return route('inv:ms'); }
    case 'nikeSync': { if (!needExt()) return; return xRun(async () => { xSet('나이키 주문 읽는 중… (작은 창이 열려요)'); const r = await ordSync({ only: ['nike'], quiet: true }); xSet(IS.ms.msg || '불러왔어요'); }); }
    case 'sqLoad': return sqLoad();
    case 'sqAll': { const on = el.dataset.v === '1'; for (const e of stockQ) e.on = on && sqReady(e) && sqLeft(e) > 0; await sqSave(); sqSet(on ? `보관 가능한 ${stockQ.filter(e => e.on).length}줄을 선택했어요` : '모두 해제했어요'); return renderX(); }
    case 'sqLogXl': return xlDownload([{ name: '보관신청내역', rows: [['시각', '모델번호', '상품', '사이즈', '수량', '보증금', '결과', '크림 안내'], ...stockLog.map(l => [new Date(l.t).toLocaleString('ko-KR'), l.code, l.name, l.size, l.qty, l.total, l.result, l.said])], widths: [20, 16, 36, 8, 6, 10, 18, 40] }], `크림_보관신청내역_${today()}.xlsx`);
    case 'sqCheck': return sqCheck();
    case 'kmSearch': {
      const K = XS.kmS = XS.kmS || { q: '', list: [], inp: {} }, q = String(K.q || '').trim();
      if (!q) return xSet('상품명이나 품번을 넣어 주세요');
      if (!needExt()) return;
      return xRun(async () => { xSet('크림에서 검색 중…'); const tabId = await srcNav(`https://kream.co.kr/search?keyword=${encodeURIComponent(DO.conv ? codeNorm(q) : q)}`); K.list = (await inTab(tabId, kcList, [20])) || []; K.at = Date.now(); xSet(`크림 검색 결과 ${K.list.length}개 — 사이즈와 수량을 넣고 '넣기'를 누르세요`); });
    }
    case 'kmAdd': {
      const K = XS.kmS, r = K && K.list.find(x => x.pid === i); if (!r) return;
      const I = K.inp[i] || {}, size = String(I.size || '').trim(), qty = Math.max(1, Math.min(50, Math.floor(num(I.qty) || 1)));
      if (!size) return xSet('사이즈를 넣어 주세요 (예: 270, L, ONE SIZE)');
      const ex = stockQ.find(e => !e.itemId && e.forcePid === i && sizeKey(e.size) === sizeKey(size));
      if (ex) { ex.total = (ex.passed || 0) + qty; ex.want = ex.total; ex.status = `직접 넣은 수량 ${qty}개로 바꿈`; }
      else stockQ.push({ id: uid(), itemId: null, manual: true, code: `크림#${i}`, name: r.name, size, total: qty, want: qty, passed: 0, on: false, pid: undefined, forcePid: i, status: '크림에서 직접 넣음', tries: 0 });
      await sqSave(); xSet(`${r.name} ${size} ${qty}개를 매크로 목록에 넣었어요 — 크림 사이즈를 확인하는 중…`);
      const e = ex || stockQ[stockQ.length - 1]; renderX(); return sqCheck(e.id);
    }
    case 'sqRun': sqRun().catch(e => sqSet('멈췄어요: ' + e.message)); return renderX();   // 3.10.11: 작업 줄에 안 서고 바로 따로 돌아요(수집 등과 같이 돌게)
    case 'sqStop': SQ.run = false; sqSet('멈췄어요'); return renderX();
    case 'kInvLoad': {
      if (!needExt() || SQ.kinvBusy) return; SQ.kinvBusy = true;
      try { let ch = 0; for (const it of INV.items) { const parts = String(it.code || '').split('/').map(x => x.trim()).filter(Boolean); const u = [...new Set(parts)]; if (u.length !== parts.length) { it.code = u.join('/'); ch++; } } if (ch) await invSave(); } catch (x) {}   // 3.10.40: 연결하면서 겹쳐 붙은 모델번호 정리 SQ.kinvMsg = '크림 보관판매 내역 읽는 중… (뒤에서 크림 창이 잠깐 열려요)'; renderX();
      try { const r = await kInvRead(); const a = await kAutoAlign(); SQ.kinvMsg = `불러왔어요 — 크림 보관판매 ${r.items.filter(i => !KINV_OUT.test(i.status)).length}개 (취소·반송 ${r.items.filter(i => KINV_OUT.test(i.status)).length}개 제외)${a.n ? ` · 재고가 있는 ${a.n}줄(${a.q}개)은 재고관리에서 크림 보관으로 자동으로 뺐어요` : ''}`; }
      catch (er) { SQ.kinvMsg = '못 읽었어요: ' + er.message; }
      SQ.kinvBusy = false; return renderX();
    }
    case 'kSales': {
      if (!needExt() || SQ.salesBusy) return; SQ.salesBusy = true; SQ.salesMsg = '크림 판매 정산 읽는 중… (뒤에서 크림 창이 잠깐 열려요)'; renderX();
      try { const r = await kSalesSync(); const had = INV.outs.filter(o => o.kreamSaleId).length - r.n; SQ.salesMsg = `${r.n ? `판매 ${r.n}건을 매출에 넣었어요 (재고관리 → 매출 장부에서 볼 수 있어요)` : `새로 정산완료된 판매는 없어요${had > 0 ? ` — 이미 넣은 판매 ${had}건은 아래 목록에 있어요` : ''}`}${r.skips.length ? ` · 못 넣은 것: ${r.skips.slice(0, 4).join(' / ')}${r.skips.length > 4 ? ` 외 ${r.skips.length - 4}건` : ''}` : ''}`; }
      catch (er) { SQ.salesMsg = '못 읽었어요: ' + er.message; }
      SQ.salesBusy = false; return renderX();
    }
    case 'kinvSt': XS.kinvSt = el.dataset.v || ''; return renderX();
    case 'kInvXl': { if (!kInv) return; return xlDownload([{ name: '크림보관판매', rows: [['상품', '모델번호', '사이즈', '상태', '신청일', '크림 상품번호'], ...kInv.items.map(i => [i.name, i.code, i.sizeName || i.size, i.statusName || i.status, String(i.date).slice(0, 10), i.pid])], widths: [40, 18, 10, 12, 12, 12] }], `크림_보관판매_${today()}.xlsx`); }
    case 'kAlignHide': { kAlignHide = kAlignHide.includes(i) ? kAlignHide.filter(x => x !== i) : [...kAlignHide, i]; await store.set('kAlignHide', kAlignHide); return renderX(); }
    case 'kAlignEasy': {
      if (!SQ.alEasyAsk) { SQ.alEasyAsk = true; return renderX(); }
      SQ.alEasyAsk = false; let n = 0; const fail = [];
      for (const r of kAlignRows().filter(r => r.diff > 0 && r.it && r.have >= r.diff && !kAlignHide.includes(r.key))) { try { await invAlign(r, null); n++; } catch (er) { fail.push(r.name.slice(0, 20) + ': ' + er.message); } }
      SQ.kinvMsg = `${n}줄 재고에서 뺐어요${fail.length ? ` · 못 한 줄: ${fail.join(' / ')}` : ''}`; return renderX();
    }
    case 'kAlign': {
      if (SQ.alAsk !== i) { SQ.alAsk = i; return renderX(); }
      SQ.alAsk = null;
      const r = kAlignRows().find(x => x.key === i); if (!r) { SQ.kinvMsg = '그 줄을 못 찾았어요 — 다시 불러와 주세요'; return renderX(); }
      try { const o = await invAlign(r, (SQ.alCost || {})[i] ?? kLastCost(r.it)); SQ.kinvMsg = `${r.name.slice(0, 30)} ${r.sizeName || r.size}: 재고관리 보관 출고 ${o.pre}개 → ${o.want}개로 맞췄어요`; } catch (er) { SQ.kinvMsg = '못 맞췄어요: ' + er.message; }
      return renderX();
    }
    case 'kInvFix': {
      const e = stockQ.find(x => x.id === i); if (!e) return;
      if (SQ.fixAsk !== i) { SQ.fixAsk = i; return renderX(); }
      SQ.fixAsk = null;
      try { await kInvFix(e); SQ.kinvMsg = `${e.name || e.code} ${e.ksize || e.size}: 크림 ${e.passed}개로 맞췄어요`; } catch (er) { SQ.kinvMsg = '못 맞췄어요: ' + er.message; }
      return renderX();
    }
    case 'sqDel': stockQ = stockQ.filter(e => e.id !== i); await sqSave(); return renderX();
    case 'sqMark': {   // 3.9.8: 크림에서는 신청됐는데 매크로가 못 잡았을 때 직접 +1 (재고관리에도 '크림 보관'으로 빠져요)
      const e = stockQ.find(x => x.id === i); if (!e) return;
      if (SQ.markAsk !== i) { SQ.markAsk = i; return renderX(); }
      SQ.markAsk = null; e.passed = (e.passed || 0) + 1; e.doneAt = Date.now(); e.status = `신청 완료 ${e.passed}/${e.total}개 (직접 표시)`; if (sqLeft(e) <= 0) e.on = false;
      sqRecord(e, 1, { total: 3000 }, '신청 완료 (직접 표시)'); await sqToInventory(e, 1); await sqSave(); await store.set('stockLog', stockLog); return renderX();
    }
    case 'kXl': { const v = el.dataset.v, D = XS.km[KM[v].page]; let rows = kRows(D.cap); if (v === 'kship') rows = rows.filter(r => /발송|배송|입고 대기|체결/.test(String(r.status))); return xlDownload([{ name: KM[v].t.slice(0, 20), rows: [['상품', '품번', '사이즈', '가격', '상태', '날짜', '만료/기한'], ...rows.map(r => [r.name, r.code, r.size, r.price || '', r.status, r.date, r.exp])], widths: [40, 16, 8, 12, 14, 18, 18] }], `크림_${KM[v].t.replace(/\W+/g, '')}_${today()}.xlsx`); }
    case 'kToPre': {
      const rows = kRows(XS.km.selling.cap).filter(r => r.price && /종료|완료|정산/.test(String(r.status)) && r.code && r.size);
      if (!rows.length) return xSet('정산할 종료된 판매가 없어요 (품번·사이즈·가격이 있는 줄만 써요)');
      IS.pre.kreamText = rows.map(r => `${String(r.code).split('/')[0].trim()}  ${r.size}  ${r.price}`).join('\n');
      IS.pre.kream = { rows: matchPre(parseSaleLines(IS.pre.kreamText), '크림') };
      return route('inv:pre');
    }
  }
}
async function xInput(el, ev) {
  if (/^ab[A-Z]/.test(el.dataset.xk || '')) return abInput(el, ev);
  const k = el.dataset.xk, v = el.type === 'checkbox' ? el.checked : el.value;
  if (k === 'kfQ') { const F = (XS.kf = XS.kf || {})[el.dataset.i] = (XS.kf[el.dataset.i] || { q: '', tab: 'all' }); F.q = v; clearTimeout(xInput.kf); xInput.kf = setTimeout(() => { const pos = el.selectionStart; renderX(); const e2 = document.querySelector('[data-xk=kfQ]'); if (e2) { e2.focus(); try { e2.setSelectionRange(pos, pos); } catch (e) {} } }, 300); return; }
  if (k === 'kmQ') { (XS.kmS = XS.kmS || { q: '', list: [], inp: {} }).q = v; return; }
  if (k === 'kmSize' || k === 'kmQty') { const K = XS.kmS = XS.kmS || { q: '', list: [], inp: {} }; const I = K.inp[el.dataset.i] = K.inp[el.dataset.i] || {}; I[k === 'kmSize' ? 'size' : 'qty'] = v; return; }
  if (/^(histFrom|histTo|histQ|kcQ|kcSt)$/.test(k || '')) {
    const H = kHistRange(), C = XS.kc = XS.kc || { tab: 'all', st: '', q: '' };
    if (k === 'histFrom') H.from = v; else if (k === 'histTo') H.to = v; else if (k === 'histQ') H.q = v; else if (k === 'kcQ') C.q = v; else C.st = v;
    clearTimeout(xInput.kh); xInput.kh = setTimeout(() => { const had = document.activeElement === el, pos = el.selectionStart; renderX(); const e2 = document.querySelector(`[data-xk="${k}"]`); if (e2 && had && e2.type === 'text' || e2 && had && !e2.type) { e2.focus(); try { e2.setSelectionRange(pos, pos); } catch (e) {} } }, /Q$/.test(k) ? 300 : 0);
    return;
  }
  if (/^dual(Conv|Disc|PzRate|PzMin|PzFix|FltV|Cost|Q)$/.test(k || '')) {
    if (k === 'dualQ') XS.dualQ = v; else if (k === 'dualCost') XS.dualCost = v; else if (k === 'dualConv') DO.conv = !!v; else if (k === 'dualDisc') DO.disc = v;
    else if (k === 'dualPzRate') DO.pz[DO.pzCat].rate = num(v); else if (k === 'dualPzMin') DO.pz[DO.pzCat].min = num(v); else if (k === 'dualPzFix') DO.pz[DO.pzCat].fix = num(v);
    else if (k === 'dualFltV' && DO[el.dataset.i]) DO[el.dataset.i].v = num(v);
    if (k !== 'dualQ' && k !== 'dualCost') dualSave();
    // 다시 그리되 입력 중인 칸의 커서는 지켜요
    clearTimeout(xInput.dl); xInput.dl = setTimeout(() => { if (XS.busy) return; const pos = el.value.length - (el.selectionStart || 0), sel = `[data-xk="${k}"]${el.dataset.i ? `[data-i="${el.dataset.i}"]` : ''}`, had = document.activeElement === el; renderX(); const e2 = document.querySelector(sel); if (e2 && had && e2.type !== 'checkbox') { e2.focus(); try { const p2 = Math.max(0, e2.value.length - pos); e2.setSelectionRange(p2, p2); } catch (e) {} } }, k === 'dualConv' ? 0 : 450);
    return;
  }
  if (k === 'dualCost') XS.dualCost = v; else if (k === 'msQ') XS.msQ = v; else if (k === 'trQ') XS.trQ = v; else if (k === 'dropQ') { XS.dropQ = v; clearTimeout(xInput.dq); xInput.dq = setTimeout(() => { renderX(); const e = document.querySelector('[data-xk=dropQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, 350); } else if (k === 'msSite') XS.msSite = v;
  else if (k === 'rvText' || k === 'rvStar') { const no = el.dataset.i; rvDraft[no] = { ...(rvDraft[no] || {}), [k === 'rvText' ? 'text' : 'star']: k === 'rvStar' ? +v : v }; clearTimeout(xInput.t); xInput.t = setTimeout(() => store.set('rvDraft', rvDraft), 400); }
  else if (k === 'sqKSize' && ev.type === 'change') { const e = stockQ.find(x => x.id === el.dataset.i); if (e) { e.ksize = v; e.status = v ? (v !== e.size ? `크림 사이즈 ${v}로 신청 (직접 고름)` : '') : '크림 사이즈를 골라 주세요'; if (!v) e.on = false; await sqSave(); renderX(); } }
  else if (k === 'sqWant' && ev.type === 'change') { const e = stockQ.find(x => x.id === el.dataset.i); if (e) { const have = sqHave(e), p0 = e.passed || 0; const m = Math.max(0, Math.min(Math.floor(+v || 0), have)); e.total = p0 + have; const n = p0 + m; e.want = n; if (m !== +v) el.value = m; if (sqLeft(e) <= 0) e.on = false; else if (n > 0 && sqReady(e)) e.on = true; await sqSave(); renderX(); } }
  else if (k === 'alCost') { (SQ.alCost = SQ.alCost || {})[el.dataset.i] = v; }
  else if (k === 'alAll' && ev.type === 'change') { SQ.alAll = v; renderX(); }
  else if (k === 'alShowHid' && ev.type === 'change') { SQ.alShowHid = v; renderX(); }
  else if (k === 'kAuto' && ev.type === 'change') { stockOpt.kAuto = !!v; await sqSave(); if (v) { const a = await kAutoAlign(); SQ.kinvMsg = a.n ? `재고가 있는 ${a.n}줄(${a.q}개)을 크림 보관으로 뺐어요` : SQ.kinvMsg; } renderX(); }
  else if (k === 'alLink' && ev.type === 'change') {
    const key = el.dataset.i; if (!v) return; if (v === '__all') { SQ.alPick = key; return renderX(); }
    const r = kAlignRows().find(x => x.key === key), it = itemOf(v); if (!r || !it) return;
    if (r.pid) { it.kreamPid = r.pid; it.kreamPidBy = 'user'; }   // 3.10.40: 모델번호를 덧붙이지 않고 크림 상품 번호로만 이어요
    SQ.alPick = null; await invSave(); SQ.kinvMsg = `${r.name.slice(0, 30)} → 재고관리 '${itName(it).slice(0, 30)}'와 연결했어요`; renderX();
  }
  else if (k === 'sqPid' && ev.type === 'change') { const e = stockQ.find(x => x.id === el.dataset.i); const m = String(v).match(/(?:products|inventory)\/(\d{3,})/) || String(v).trim().match(/^(\d{3,})$/); if (!e) return; if (!m) { sqSet('크림 상품 주소(kream.co.kr/products/숫자)나 상품 번호를 넣어 주세요'); return; } for (const x of stockQ.filter(x => (x.itemId || x.code) === (e.itemId || e.code))) x.forcePid = m[1]; const it = e.itemId ? itemOf(e.itemId) : null; if (it) { it.kreamPid = m[1]; it.kreamPidBy = 'user'; try { await invSave(); } catch (x) {} } await sqSave(); sqCheck(e.id); }
  else if (k === 'sqOn' && ev.type === 'change') { const e = stockQ.find(x => x.id === el.dataset.i); if (e) { e.on = v; await sqSave(); renderX(); } }
  else if (k === 'sqFinal' && ev.type === 'change') { stockOpt.final = v; await sqSave(); sqSet(v ? '최종 신청(보증금 결제)까지 자동으로 해요 — 요약이 넣은 값과 다르면 결제하지 않아요' : '요약 확인까지만 하고 결제는 직접 눌러요'); }
  else if ((k === 'sqChunk' || k === 'sqGap' || k === 'sqCap') && ev.type === 'change') { stockOpt[{ sqChunk: 'chunk', sqGap: 'gap', sqCap: 'cap' }[k]] = Math.max(k === 'sqGap' ? 7 : 1, +v); await sqSave(); renderX(); }
  else if (k === 'trOn' && ev.type === 'change') { const t = msTracks.find(x => x.id === el.dataset.i); t.on = v; await store.set('msTracks', msTracks); }
  else if (k === 'trHours' && ev.type === 'change') { S.trackHours = +v; await store.set('settings', S); await setTrackAlarm(); const s = $('#s_trackHours'); if (s) s.value = String(S.trackHours); xSet(+v ? '저장했어요 — 그 간격마다 상품 시세 추적과 무신사 추적을 같이 확인해요' : '자동 확인을 껐어요'); }
}
async function autoInit() {
  msHist = await store.get('msHist', []); msTracks = await store.get('msTracks', []); dualHist = await store.get('dualHist', []); { const o = await store.get('dualOpt', null); DO = Object.assign(DUAL_DEF(), o || {}); DO.pz = Object.assign(DUAL_DEF().pz, (o && o.pz) || {}); DO.mr = Object.assign(DUAL_DEF().mr, (o && o.mr) || {}); DO.mg = Object.assign(DUAL_DEF().mg, (o && o.mg) || {}); }
  XS.km = await store.get('kreamMy', {});
  rvDraft = await store.get('rvDraft', {}); drops = await store.get('drops', drops) || drops; bidCmp = await store.get('bidCmp', {}); partnerData = await store.get('partnerData', {});
  stockLog = await store.get('stockLog', []);
  if (typeof abInit === 'function') await abInit();
  kInv = await store.get('kreamInvSnap', null);
  kAlignHide = await store.get('kAlignHide', []);
  kSales = await store.get('kreamSales', { done: [], skip: {} });
  stockQ = await store.get('stockQ', []); stockOpt = { ...stockOpt, ...(await store.get('stockOpt', {})) }; stockTries = await store.get('stockTries', stockTries);
  // 3.10.36: 3.10.26~3.10.35는 모델번호가 비슷한(앞뒤 글자가 다른) 상품도 골라서 색상이 다른 상품이 잡힐 수 있었어요 → 검색으로 찾았던 크림 상품은 지우고 다시 확인하게 해요 (직접 넣은 링크는 그대로)
  if (!stockOpt.pidFix36) {
    for (const e of stockQ) if (e.pid) { e.pid = undefined; e.ksizes = undefined; e.on = false; e.status = '다시 확인 필요 — 색상까지 똑같은 상품만 고르게 바꿨어요. 보관 가능 확인을 눌러 주세요 (색상별 상품이 여러 개면 크림 링크를 넣어야 해요)'; }
    stockOpt.pidFix36 = true; await sqSave();
  }
  const m = xMain();
  m.addEventListener('click', e => { const el = e.target.closest('[data-x]'); if (el) xAct(el.dataset.x, el).catch(err => xSet('오류: ' + err.message)); });
  m.addEventListener('toggle', e => { if (e.target && e.target.classList && e.target.classList.contains('kalign')) SQ.alOpen = e.target.open; if (e.target && e.target.classList && e.target.classList.contains('sq-donelist')) SQ.doneOpen = e.target.open; const cl = e.target && e.target.classList; if (cl && cl.contains('kcmp')) SQ.cmpOpen = e.target.open; if (cl && cl.contains('sq-opt')) SQ.optOpen = e.target.open; if (cl && cl.contains('sq-donebox')) SQ.succOpen = e.target.open; if (e.target && e.target.dataset && e.target.dataset.open === 'logOpen') SQ.logOpen = e.target.open; if (e.target && e.target.dataset && e.target.dataset.abopen === 'new' && typeof AB !== 'undefined') AB.newOpen = e.target.open; }, true);
  m.addEventListener('input', e => { const el = e.target.closest('[data-xk]'); if (el) xInput(el, e); });
  m.addEventListener('change', e => { const el = e.target.closest('[data-xk]'); if (el) xInput(el, e); });
  m.addEventListener('keydown', e => { const el = e.target.closest('[data-xk]'); if (!el || e.key !== 'Enter') return; if (el.dataset.xk === 'dualQ' || el.dataset.xk === 'dualCost') runDual(); if (el.dataset.xk === 'kmQ') xAct('kmSearch', el); if (el.dataset.xk === 'msQ') runMs(); if (el.dataset.xk === 'trQ') trAddUrl(); });
}
