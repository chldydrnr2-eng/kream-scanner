'use strict';
/* 킥스캔 3.32 — 이용권 결제 화면
   플랜(Basic · PRO · VIP) 비교 → 이용 기간(30 · 180 · 365일) → 주문서 확인 → 결제하기.
   결제하기: 설정의 '이용권 구매 링크'(결제 페이지)로 고른 플랜 · 기간 · 금액을 넘겨 열어요. 링크가 없으면 카카오 문의로 안내해요.
   (프로그램 안 카드 결제는 결제대행(토스페이먼츠 등) 가맹 후 연결 — BUY_PG 에 키가 생기면 켜요) */
const BUY_PLANS = [
  { k: 'basic', t: 'Basic', d: '크림 자동화 · 재고관리', p: 17900 },
  { k: 'vip', t: 'VIP', d: 'Basic + PRO 전부', p: 44900, best: true },
  { k: 'pro', t: 'PRO', d: '소싱 자동화 기능', p: 34900 }
];
const BUY_FEAT = [   // [기능, basic, vip, pro, 새 기능]
  ['나이키 · 무신사 주문내역 관리', 1, 1, 1, 1],
  ['크림 기능 전부 (입찰 · 자동 입찰 · 보관 · 매크로 · 발송 · 정산)', 1, 1, 0],
  ['재고관리 전부 (입출고 · 입고예정 · 우선출고 · 반품 · 장부 · 부가세)', 1, 1, 0],
  ['크림 / 포이즌 동시 분석', 0, 1, 1],
  ['아이템 찾기 · 랭킹 분석', 0, 1, 1],
  ['쇼핑몰 26곳 재고조회 · 가격 · 재입고 추적', 0, 1, 1, 1],
  ['무신사 후기 자동 작성', 0, 1, 1],
  ['발매 정보 · 내 상품 시세 · 마진', 0, 1, 1]
];
const BUY_DAYS = [[30, 0], [180, 5], [365, 10]];
const BUY = { plan: 'vip', days: 30, agree: false, st: null };
const buyPrice = (plan, days) => { const P = BUY_PLANS.find(p => p.k === plan); const disc = (BUY_DAYS.find(d => d[0] === days) || [0, 0])[1]; return Math.floor(P.p * buyMon(days) * (1 - disc / 100) / 100) * 100; };
const buyMon = d => d >= 365 ? 12 : d / 30;   // 365일 = 12개월 값
const buyLeft = st => { if (!st || !st.expires) return null; const d = Math.ceil((new Date(st.expires) - Date.now()) / 864e5); return isNaN(d) ? null : d; };
function buyKind(st) {
  if (!st || !['ok', 'grace', 'blocked'].includes(st.state) || !st.plan) return '신규 구매';
  const cur = String(st.plan).toLowerCase(), left = buyLeft(st);
  if (left != null && left <= 0) return '재구매';
  if (cur.includes(BUY.plan)) return '기간 연장';
  if (cur.includes('vip')) return '기간 연장';   // VIP가 낮은 플랜을 사면 연장으로 봐요
  return BUY.plan === 'vip' ? '업그레이드' : '플랜 변경';
}
function buyRender() {
  const M = document.getElementById('buyModal'); if (!M) return;
  const st = BUY.st, left = buyLeft(st), P = BUY_PLANS.find(p => p.k === BUY.plan), amt = buyPrice(BUY.plan, BUY.days);
  const on = st && ['ok', 'grace'].includes(st.state);
  const cur = on ? `현재 <b>${esc(st.plan || '이용권')}</b> 이용 중${left != null ? ` · 잔여 <b>${left}일</b>` : ''}` : (st && st.state === 'blocked' ? '이용 기간이 끝났어요 — 이용권을 구매하면 바로 다시 쓸 수 있어요' : '아직 이용권이 없어요');
  const ck = v => v ? '<span class="b-ok" aria-label="포함">✓</span>' : '<span class="b-no" aria-label="미포함">✕</span>';
  M.querySelector('.buy-body').innerHTML = `
    <div class="buy-main">
      <div class="buy-cur ${on ? '' : 'off'}">${cur}</div>
      <div class="buy-note"><b>Basic과 PRO는 제공 기능이 다른 이용권이에요.</b> 크림 자동화 · 재고관리는 Basic, 소싱(분석 · 재고조회 · 추적)은 PRO에 들어 있어요. 둘 다 쓰려면 VIP를 고르세요.</div>
      <div class="buy-tbl"><table><thead><tr><th class="l"><b>플랜 선택 · 기능 비교</b><small>플랜을 눌러 고르세요</small></th>${BUY_PLANS.map(p => `<th class="b-col${BUY.plan === p.k ? ' on' : ''}" data-bp="${p.k}" tabindex="0" role="button" aria-pressed="${BUY.plan === p.k}"><span class="b-name">${p.t}${p.best ? ' <i>추천</i>' : ''}</span><small>${esc(p.d)}</small><b class="b-pr">${won(p.p)}</b><small>/ 30일</small><span class="b-pick">${BUY.plan === p.k ? '선택됨' : '선택하기'}</span></th>`).join('')}</tr></thead>
        <tbody>${BUY_FEAT.map(f => `<tr><td class="l">${esc(f[0])}${f[4] ? ' <em class="b-new">신규</em>' : ''}</td>${['basic', 'vip', 'pro'].map((k, i) => `<td class="${BUY.plan === k ? 'on' : ''}">${ck(f[i + 1])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
      <h3 class="buy-h">이용 기간</h3>
      <div class="buy-days">${BUY_DAYS.map(([d, disc]) => `<button type="button" class="${BUY.days === d ? 'on' : ''}" data-bd="${d}"><span>${d}일</span><em class="${disc ? 'sale' : ''}">${disc ? disc + '% 할인' : '할인 없음'}</em><b>${won(buyPrice(BUY.plan, d))}</b>${disc ? `<small>한 달 ${won(Math.round(buyPrice(BUY.plan, d) / buyMon(d) / 100) * 100)}</small>` : '<small>&nbsp;</small>'}</button>`).join('')}</div>
      <div class="buy-rule"><b>결제 기준</b><ul><li>결제가 확인되면 바로 이용권이 반영돼요.</li><li>연장은 지금 남은 기간 뒤에 이어서 붙어요.</li><li>업그레이드는 만료일은 그대로 두고 등급만 바뀌어요.</li><li>한 계정으로 등록한 PC에서 쓸 수 있어요 (PC를 바꾸면 설정 → 이 PC 등록 해제).</li></ul></div>
    </div>
    <aside class="buy-side"><h3>주문서</h3>
      <dl><dt>상품명</dt><dd>${P.t} 이용권</dd><dt>결제 유형</dt><dd>${buyKind(st)}</dd><dt>이용 기간</dt><dd>${BUY.days}일</dd>${st && st.email ? `<dt>계정</dt><dd>${esc(st.email)}</dd>` : ''}</dl>
      <div class="buy-amt"><span>결제 금액</span><b>${won(amt)}</b></div>
      <label class="chk buy-agree"><input type="checkbox" id="buyAgree"${BUY.agree ? ' checked' : ''}> 이용약관, 개인정보 수집 및 이용, 디지털콘텐츠 제공 개시 및 환불 규정을 확인했어요.${S.termsUrl ? ` <a href="#" data-bterms>약관 보기</a>` : ''}</label>
      <button type="button" class="primary buy-go" id="buyGo"${BUY.agree ? '' : ' disabled'}>${won(amt)} 결제하기</button>
      <p class="hint" id="buyMsg">${S.buyUrl ? '결제 페이지가 열려요. 결제가 끝나면 이 창에서 \'이용권 다시 확인\'을 누르세요.' : '결제 페이지 준비 중이에요 — 결제하기를 누르면 카카오 문의로 연결돼요.'}</p>
      <button type="button" class="ghost tiny" id="buyRecheck">이용권 다시 확인</button>
    </aside>`;
}
function buyOpenUrl(u) { try { if (window.kcApp && window.kcApp.openExt) return window.kcApp.openExt(u); } catch (e) {} try { (typeof chrome !== 'undefined' && chrome.tabs ? chrome.tabs.create({ url: u }) : window.open(u, '_blank')); } catch (e) {} }
async function buyOpen() {
  let M = document.getElementById('buyModal');
  if (!M) {
    M = document.createElement('div'); M.id = 'buyModal'; M.className = 'buy-dim'; M.hidden = true;
    M.innerHTML = `<div class="buy-box" role="dialog" aria-modal="true" aria-labelledby="buyTitle"><div class="buy-head"><span class="buy-ico">${typeof ico === 'function' ? ico('receipt') : ''}</span><div><h2 id="buyTitle">이용권 결제</h2><p>플랜과 이용 기간을 고르세요</p></div><button type="button" class="buy-x" aria-label="닫기">✕</button></div><div class="buy-body"></div></div>`;
    document.body.appendChild(M);
    M.addEventListener('click', async e => {
      if (e.target === M || e.target.closest('.buy-x')) return buyClose();
      const bp = e.target.closest('[data-bp]'); if (bp) { BUY.plan = bp.dataset.bp; return buyRender(); }
      const bd = e.target.closest('[data-bd]'); if (bd) { BUY.days = +bd.dataset.bd; return buyRender(); }
      if (e.target.closest('[data-bterms]')) { e.preventDefault(); return buyOpenUrl(S.termsUrl); }
      if (e.target.id === 'buyAgree') { BUY.agree = e.target.checked; const g = document.getElementById('buyGo'); if (g) g.disabled = !BUY.agree; return; }
      if (e.target.id === 'buyRecheck') { const m = document.getElementById('buyMsg'); try { if (window.kcApp && window.kcApp.lic) { m.textContent = '확인 중…'; BUY.st = await window.kcApp.lic.check(); buyRender(); document.getElementById('buyMsg').textContent = BUY.st && BUY.st.state === 'ok' ? '이용권이 확인됐어요.' : '아직 반영 전이에요. 잠시 뒤 다시 눌러 주세요.'; } else m.textContent = '프로그램에서만 확인돼요.'; } catch (er) { m.textContent = '확인 실패: ' + (er.message || er); } return; }
      if (e.target.closest('#buyGo')) {
        if (!BUY.agree) return;
        const P = BUY_PLANS.find(p => p.k === BUY.plan), amt = buyPrice(BUY.plan, BUY.days);
        if (/^https?:\/\//.test(S.buyUrl || '')) { const u = new URL(S.buyUrl); u.searchParams.set('plan', P.t); u.searchParams.set('days', BUY.days); u.searchParams.set('amount', amt); buyOpenUrl(u.toString()); document.getElementById('buyMsg').textContent = '결제 페이지를 열었어요. 결제가 끝나면 \'이용권 다시 확인\'을 누르세요.'; }
        else if (/^https?:\/\//.test(S.kakaoUrl || '')) { buyOpenUrl(S.kakaoUrl); document.getElementById('buyMsg').textContent = `카카오 문의를 열었어요. '${P.t} ${BUY.days}일 (${won(amt)})'로 문의해 주세요.`; }
        else document.getElementById('buyMsg').textContent = '결제 링크가 아직 없어요. 설정 → \'이용권 구매 링크\'에 결제 페이지 주소를 넣어 주세요.';
      }
    });
    M.addEventListener('keydown', e => { if (e.key === 'Escape') buyClose(); const bp = e.target.closest && e.target.closest('[data-bp]'); if (bp && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); BUY.plan = bp.dataset.bp; buyRender(); } });
  }
  try { BUY.st = window.kcApp && window.kcApp.lic ? await window.kcApp.lic.state() : null; } catch (e) { BUY.st = null; }
  if (BUY.st && BUY.st.plan) { const c = String(BUY.st.plan).toLowerCase(); const hit = BUY_PLANS.find(p => c.includes(p.k)); if (hit) BUY.plan = hit.k; }
  buyRender(); M.hidden = false; document.body.classList.add('buy-on'); setTimeout(() => { try { M.querySelector('.buy-x').focus(); } catch (e) {} }, 30);
}
function buyClose() { const M = document.getElementById('buyModal'); if (M) M.hidden = true; document.body.classList.remove('buy-on'); }
