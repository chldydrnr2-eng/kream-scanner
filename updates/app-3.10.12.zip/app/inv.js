'use strict';
/* 크림스캐너 — 재고관리 (입고·출고·우선출고·반품·장부·부가세)
   데이터는 이 PC 확장 프로그램 저장소(inv)에만 있어요. 백업은 '데이터 초기화' 화면에서 받아요. */

const INV_DEF = () => ({
  v: 1,
  partners: [
    { id: 'p-kream', kind: 'sell', name: '크림', biz: '크림 주식회사', tax: '과세', feeMode: 'kream', feeRate: 6, feeFix: 2500, vat: '포함' },
    { id: 'p-poizon', kind: 'sell', name: '포이즌', biz: '', tax: '영세', feeMode: 'custom', feeRate: 0, feeFix: 0, vat: '포함' },
    { id: 'p-ms', kind: 'buy', name: '무신사', biz: '주식회사 무신사', tax: '과세', returnDays: 7 },
    { id: 'p-nike', kind: 'buy', name: '나이키 공식몰', biz: '나이키코리아', tax: '과세', returnDays: 30 }
  ],
  pays: [],
  couriers: [{ id: 'c-cj', name: 'CJ대한통운', box: { 극소: '', 소: '', 중: '', 대: '', 특대: '' } }],
  cats: { 신발: ['스니커즈', '러닝화', '부츠', '샌들·슬리퍼'], 의류: ['아우터', '상의', '하의'], 잡화: ['가방', '모자', '기타'] },
  brands: ['나이키', '조던', '뉴발란스', '아디다스', '아식스', '노스페이스'],
  items: [], lots: [], outs: [], ledger: [], poizonMap: {},
  opt: { returnDays: 7, staleDays: 30, soon: 3, autoIn: true, autoHours: 0, ordSites: null, ordDays: 30, optV: 2 }
});
let INV = INV_DEF();
let invView = 'home';
const IS = {   // 화면마다 잠깐 들고 있는 상태
  io: { mode: 'in', date: '', partnerId: '', payId: '', rows: [], bc: false, multi: true, q: '', msg: '' },
  items: { q: '', brand: '', cat: '', only: false, open: '' },
  base: 'partners', ret: 'buy', xl: null, ms: { sel: new Set(), msg: '' }, pre: { sel: new Set(), price: {}, kream: null, poizon: null, msg: '' },
  lg: { from: '', to: '', kind: '', partner: '', pay: '', size: 50, page: 0 }, vat: { year: 0, half: 0 }, msg: ''
};

// ---------- 공통 ----------
const fmtD = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + n); return fmtD(d); };
const dday = s => Math.round((new Date(s + 'T00:00:00') - new Date(today() + 'T00:00:00')) / 864e5);
const num = v => { const n = +String(v ?? '').replace(/[^\d.-]/g, ''); return isFinite(n) ? n : 0; };
const opt = (v, label, sel) => `<option value="${esc(v)}"${sel ? ' selected' : ''}>${esc(label)}</option>`;
const itemOf = id => INV.items.find(x => x.id === id);
const partnerOf = id => INV.partners.find(x => x.id === id);
const payOf = id => INV.pays.find(x => x.id === id);
const itName = it => it ? `${it.brand ? it.brand + ' ' : ''}${it.name || it.code}` : '(지운 상품)';
const codeKey = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
const wonS = n => (n < 0 ? '−' : '') + won(Math.abs(n));
const monthStart = (d = today()) => d.slice(0, 7) + '-01';
const monthEnd = (d = today()) => { const x = new Date(d.slice(0, 7) + '-01T00:00:00'); x.setMonth(x.getMonth() + 1); x.setDate(0); return fmtD(x); };
const inRange = (d, a, b) => !!d && (!a || d >= a) && (!b || d <= b);
async function invSave() { await store.set('inv', INV); }
function partnerFee(p, price) {
  if (!price || !p) return 0;
  if (p.feeMode === 'kream') return feeOf(price);
  if (p.feeMode === 'none') return 0;
  let f = price * (+p.feeRate || 0) / 100 + (+p.feeFix || 0);
  if (p.vat === '별도') f *= 1.1;
  return Math.floor(f / 10) * 10;
}
const feeText = p => p.kind !== 'sell' ? '–' : p.feeMode === 'kream' ? `크림 계산식 (설정: ${S.rate}% + ${won(S.base)}, VAT 별도)` : p.feeMode === 'none' ? '수수료 없음' : `${+p.feeRate || 0}% + ${won(+p.feeFix || 0)} · VAT ${p.vat || '포함'}`;

// 재고 계산: 입고 묶음(lot)마다 남은 개수 = 입고 − 반품 − 교환 − 출고에 쓰인 개수 (출고는 먼저 들어온 것부터 꺼내요)
function invCalc() {
  const used = new Map();
  for (const o of INV.outs) for (const c of o.costs || []) used.set(c.lotId, (used.get(c.lotId) || 0) + c.qty);
  const left = new Map(), stock = new Map();
  for (const l of INV.lots) {
    const n = l.qty - (l.retQty || 0) - (l.exQty || 0) - (l.adjQty || 0) - (used.get(l.id) || 0);   // adjQty: 3.7.5 재고 수량 직접 수정(줄임)
    left.set(l.id, n);
    if (n > 0) { const k = l.itemId + '|' + l.size; const s = stock.get(k) || { qty: 0, value: 0 }; s.qty += n; s.value += n * l.cost; stock.set(k, s); }
  }
  return { used, left, stock };
}
function itemStock(it, C) {
  let qty = 0, value = 0; const by = {};
  for (const [k, s] of C.stock) { const [id, size] = k.split('|'); if (id === it.id) { qty += s.qty; value += s.value; by[size] = s; } }
  return { qty, value, by };
}
function allocate(itemId, size, qty, C) {
  const lots = INV.lots.filter(l => l.itemId === itemId && l.size === size && C.left.get(l.id) > 0).sort((a, b) => a.date.localeCompare(b.date) || a.at - b.at);
  const costs = []; let need = qty;
  for (const l of lots) { if (!need) break; const take = Math.min(need, C.left.get(l.id)); costs.push({ lotId: l.id, qty: take, cost: l.cost }); C.left.set(l.id, C.left.get(l.id) - take); need -= take; }
  return need ? null : costs;
}
function outNums(o) {
  const net = o.qty - (o.retQty || 0);
  const cq = (o.costs || []).reduce((s, c) => s + c.qty, 0);
  const unitCost = cq ? (o.costs.reduce((s, c) => s + c.qty * c.cost, 0) / cq) : 0;
  if (!o.settled) return { net, unitCost, price: 0, fee: 0, rev: 0, fees: 0, cogs: unitCost * net, ship: +o.ship || 0, margin: null };
  const fee = o.fee !== '' && o.fee != null ? +o.fee : partnerFee(partnerOf(o.partnerId), o.price);
  const price = o.price - (o.disc || 0);
  const rev = price * net, fees = fee * net, cogs = unitCost * net, ship = +o.ship || 0;
  return { net, unitCost, price, fee, rev, fees, cogs, ship, margin: rev - fees - cogs - ship };
}
function beep(ok) {
  try { const a = new (window.AudioContext || window.webkitAudioContext)(); const o = a.createOscillator(), g = a.createGain(); o.frequency.value = ok ? 1320 : 220; g.gain.value = 0.08; o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + (ok ? 0.08 : 0.25)); setTimeout(() => a.close(), 400); } catch (e) {}
}
function xlDownload(sheets, name) {
  const blob = XL.write(sheets);
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
// 나이키 남성 기준 (브랜드마다 조금씩 달라요)
const US_M = { 220: ['4', '36'], 225: ['4.5', '36.5'], 230: ['5', '37.5'], 235: ['5.5', '38'], 240: ['6', '38.5'], 245: ['6.5', '39'], 250: ['7', '40'], 255: ['7.5', '40.5'], 260: ['8', '41'], 265: ['8.5', '42'], 270: ['9', '42.5'], 275: ['9.5', '43'], 280: ['10', '44'], 285: ['10.5', '44.5'], 290: ['11', '45'], 295: ['11.5', '45.5'], 300: ['12', '46'], 305: ['12.5', '47'], 310: ['13', '47.5'] };
const SIZE_PRESETS = { '남성 신발 250~300': [250, 255, 260, 265, 270, 275, 280, 285, 290, 295, 300], '여성 신발 220~260': [220, 225, 230, 235, 240, 245, 250, 255, 260], '공용 신발 220~300': [220, 225, 230, 235, 240, 245, 250, 255, 260, 265, 270, 275, 280, 285, 290, 295, 300], '의류 XS~XXL': ['XS', 'S', 'M', 'L', 'XL', 'XXL'], '의류 90~110': [90, 95, 100, 105, 110], 'FREE': ['FREE'] };

// ---------- 화면 틀 ----------
const INV_MENU = [
  ['home', '홈'], ['base', '기본정보'], ['items', '상품 · 재고'], ['io', '입출고'], ['excel', '엑셀 대량 입고'], ['ms', '구매처 주문 입고'],
  ['pre', '우선출고 정산'], ['ret', '반품 · 교환'], ['ledger', '장부 · 정산'], ['vat', '부가세 예상'], ['reset', '백업 · 초기화']
];
function renderInv() {
  const nav = $('#invNav'); if (!nav) return;
  const C = invCalc();
  const preN = INV.outs.filter(o => o.kind === 'pre' && !o.settled).length;
  const soonN = INV.lots.filter(l => !l.confirmed && C.left.get(l.id) > 0 && l.returnDue && dday(l.returnDue) <= INV.opt.soon).length;
  const tt = $('#viewTitle'); if (tt && typeof curMode !== 'undefined' && curMode === 'inv') tt.textContent = '재고관리 · ' + ((INV_MENU.find(m => m[0] === invView) || [])[1] || '');
  const IIC = { home: 'home', base: 'info', items: 'tag', io: 'swap', excel: 'sheet', ms: 'cart', pre: 'zap', ret: 'ret', ledger: 'book', vat: 'percent', reset: 'shield' };
  nav.innerHTML = INV_MENU.map(([k, t]) => `<button type="button" data-v="${k}" aria-current="${k === invView}">${typeof ico === 'function' ? ico(IIC[k]) : ''}<span class="lbl">${t}</span>${k === 'pre' && preN ? ` <span class="cnt">${preN}</span>` : ''}${k === 'ret' && soonN ? ` <span class="cnt warn">${soonN}</span>` : ''}${k === 'ms' && +INV.opt.autoHours > 0 ? '<span class="sbadge on">자동</span>' : ''}</button>`).join('');
  const V = { home: vHome, base: vBase, items: vItems, io: vIO, excel: vExcel, ms: vMs, pre: vPre, ret: vRet, ledger: vLedger, vat: vVat, reset: vReset }[invView] || vHome;
  $('#invMain').innerHTML = V(C);
  if (invView === 'io') { const q = $('#ioQ'); if (q && IS.io.bc) q.focus(); }
}
function go(v) { if (typeof route === 'function') return route('inv:' + v); invView = v; IS.msg = ''; renderInv(); window.scrollTo(0, 0); }
const card = (label, val, cls = '', sub = '') => `<div class="kcard"><span>${label}</span><b class="${cls}">${val}</b>${sub ? `<small>${sub}</small>` : ''}</div>`;
const head = (t, d, right = '') => `<div class="ihead"><div><h2>${t}</h2>${d ? `<p class="hint">${d}</p>` : ''}</div><div class="row-btns">${right}</div></div>`;
const flash = () => IS.msg ? `<p class="iflash">${esc(IS.msg)}</p>` : '';

// ---------- 홈 ----------
function monthFigures(a, b) {
  let sold = 0, rev = 0, fees = 0, margin = 0, buy = 0;
  for (const o of INV.outs) if (o.settled && inRange(o.settleDate, a, b)) { const n = outNums(o); sold += n.net; rev += n.rev; fees += n.fees; margin += n.margin; }
  for (const l of INV.lots) if (l.src !== 'exchange' && l.src !== 'return' && l.src !== 'adjust' && inRange(l.date, a, b)) buy += l.cost * (l.qty - (l.retQty || 0));
  return { sold, rev, fees, margin, buy };
}
function invAlerts(C) {
  const A = [];
  for (const l of INV.lots) {
    if (l.confirmed || !(C.left.get(l.id) > 0) || !l.returnDue) continue;
    const d = dday(l.returnDue); if (d > INV.opt.soon) continue;
    A.push({ lv: d < 0 ? 'mute' : d <= 1 ? 'bad' : 'warn', t: `${d < 0 ? '반품 기한 지남' : d === 0 ? '오늘 반품 마감' : `반품 마감 D-${d}`} · ${itName(itemOf(l.itemId))} ${l.size} (${partnerOf(l.partnerId)?.name || ''})`, go: 'ret' });
  }
  const pre = INV.outs.filter(o => o.kind === 'pre' && !o.settled);
  if (pre.length) A.push({ lv: 'warn', t: `우선출고 ${pre.length}건이 정산 대기 중이에요`, go: 'pre' });
  const stale = INV.lots.filter(l => C.left.get(l.id) > 0 && dday(l.date) <= -INV.opt.staleDays);
  if (stale.length) A.push({ lv: 'mute', t: `${INV.opt.staleDays}일 넘게 안 팔린 재고 ${stale.reduce((s, l) => s + C.left.get(l.id), 0)}개`, go: 'items' });
  return A;
}
function vHome(C) {
  const t = today();
  const inToday = INV.lots.filter(l => l.date === t && !['exchange', 'return', 'adjust'].includes(l.src)).reduce((s, l) => s + l.qty, 0);
  const outToday = INV.outs.filter(o => o.date === t).reduce((s, o) => s + o.qty, 0);
  const pre = INV.outs.filter(o => o.kind === 'pre' && !o.settled);
  let skus = new Set(), qty = 0, value = 0;
  for (const [k, s] of C.stock) { skus.add(k.split('|')[0]); qty += s.qty; value += s.value; }
  const M = monthFigures(monthStart(), monthEnd());
  const A = invAlerts(C);
  // 최근 6개월 마진 막대
  const months = []; const d0 = new Date(t.slice(0, 7) + '-01T00:00:00');
  for (let i = 5; i >= 0; i--) { const d = new Date(d0); d.setMonth(d.getMonth() - i); const s = fmtD(d); months.push({ m: s.slice(0, 7), ...monthFigures(monthStart(s), monthEnd(s)) }); }
  const mx = Math.max(1, ...months.map(m => Math.abs(m.margin)));
  const neg = months.some(m => m.margin < 0), base = neg ? 100 : 130, hmax = neg ? 62 : 96;
  const bars = months.map((m, i) => { const h = Math.round(Math.abs(m.margin) / mx * hmax); const x = 28 + i * 68; return `<rect x="${x}" y="${m.margin >= 0 ? base - h : base}" width="34" height="${Math.max(h, 1)}" rx="3" class="${m.margin >= 0 ? 'b-pos' : 'b-neg'}"><title>${m.m} 마진 ${wonS(m.margin)} · 판매 ${m.sold}개</title></rect><text x="${x + 17}" y="${m.margin >= 0 ? base - h - 6 : base + h + 14}" text-anchor="middle" class="b-val">${m.margin ? (Math.abs(m.margin) >= 10000 ? (m.margin < 0 ? '−' : '') + (Math.abs(m.margin) < 100000 ? Math.round(Math.abs(m.margin) / 1000) / 10 : Math.round(Math.abs(m.margin) / 10000)) + '만' : wonS(m.margin)) : ''}</text><text x="${x + 17}" y="${neg ? 186 : 152}" text-anchor="middle" class="b-lab">${+m.m.slice(5)}월</text>`; }).join('');
  return `${head('홈', '오늘 입출고, 재고, 이번 달 실적, 알림을 한눈에 봐요.', `<button type="button" class="primary" data-a="quick" data-v="in">입고 등록</button><button type="button" class="ghost" data-a="quick" data-v="out">출고 등록</button><button type="button" class="ghost" data-a="quick" data-v="pre">우선출고</button><button type="button" class="ghost" data-a="nav" data-v="items">상품 관리</button><button type="button" class="ghost" data-a="nav" data-v="ledger">장부</button><button type="button" class="ghost" data-a="sendMobile">휴대폰으로 보내기</button>`)}
  ${flash()}
  <div class="kgrid">${card('오늘 입고', inToday + '개', 'pos')}${card('오늘 출고', outToday + '개', 'acc')}${card('우선출고 정산 대기', pre.length + '건', pre.length ? 'warn' : '')}${card('반품 기한 임박', A.filter(a => a.go === 'ret' && a.lv !== 'mute').length + '건', A.some(a => a.go === 'ret' && a.lv === 'bad') ? 'neg' : '')}</div>
  <div class="igrid2">
    <div class="box"><h3>재고 현황</h3><dl class="kv"><dt>재고 있는 상품</dt><dd>${skus.size}종</dd><dt>전체 재고</dt><dd>${qty}개</dd><dt>재고 자산 (매입가 기준)</dt><dd><b>${won(value)}</b></dd></dl></div>
    <div class="box"><h3>${+t.slice(5, 7)}월 실적</h3><dl class="kv"><dt>판매</dt><dd>${M.sold}개 · ${won(M.rev)}</dd><dt>매입</dt><dd>${won(M.buy)}</dd><dt>수수료</dt><dd>${won(M.fees)}</dd><dt>판매 마진 (판매 − 수수료 − 매입원가 − 택배비)</dt><dd><b class="${M.margin >= 0 ? 'pos' : 'neg'}">${wonS(M.margin)}</b></dd></dl></div>
  </div>
  <div class="igrid2">
    <div class="box"><h3>최근 6개월 판매 마진</h3><svg viewBox="0 0 440 ${neg ? 196 : 162}" class="ichart" role="img" aria-label="최근 6개월 판매 마진"><line x1="10" x2="430" y1="${base}" y2="${base}" class="b-axis"/>${bars}</svg></div>
    <div class="box"><h3>알림</h3>${A.length ? `<ul class="alerts">${A.slice(0, 12).map(a => `<li><span class="pill ${a.lv}">${a.lv === 'bad' ? '급함' : a.lv === 'warn' ? '확인' : '참고'}</span> <button type="button" class="linkbtn" data-a="nav" data-v="${a.go}">${esc(a.t)}</button></li>`).join('')}</ul>` : '<p class="hint">지금 처리할 알림이 없어요.</p>'}</div>
  </div>`;
}

// ---------- 기본정보 ----------
function vBase() {
  const tabs = [['partners', '거래처'], ['cats', '분류 · 브랜드'], ['pays', '결제수단'], ['couriers', '택배사'], ['opt', '기본값']];
  let body = '';
  if (IS.base === 'partners') {
    const row = p => `<tr><td class="l"><b>${esc(p.name)}</b><div class="small">${esc(p.biz || '')}</div></td><td class="l">${p.kind === 'buy' ? '매입처' : '매출처'}</td><td class="l">${esc(p.tax)}</td><td class="l">${esc(feeText(p))}</td><td>${p.kind === 'buy' ? (p.returnDays ?? INV.opt.returnDays) + '일' : '–'}</td><td><div class="act"><button type="button" class="ghost" data-a="partnerEdit" data-id="${p.id}">수정</button><button type="button" class="ghost" data-a="partnerDel" data-id="${p.id}">삭제</button></div></td></tr>`;
    body = `<div class="row-btns"><button type="button" class="primary" data-a="partnerEdit" data-id="">거래처 추가</button><span class="hint">매입처 = 사 오는 곳, 매출처 = 파는 곳. 매출처 수수료는 출고·정산할 때 자동으로 빠져요.</span></div>
    <div class="tbl"><table><thead><tr><th class="l">거래처명 · 상호</th><th class="l">구분</th><th class="l">과세</th><th class="l">수수료</th><th>반품 기한</th><th></th></tr></thead><tbody>${INV.partners.map(row).join('')}</tbody></table></div>`;
  } else if (IS.base === 'cats') {
    body = `<div class="igrid2"><div class="box"><h3>분류 (대분류 → 소분류)</h3>${Object.entries(INV.cats).map(([c, subs]) => `<div class="catrow"><b>${esc(c)}</b> <button type="button" class="x" data-a="catDel" data-c="${esc(c)}" aria-label="${esc(c)} 삭제">×</button><div class="chips">${subs.map(s => `<span class="chip">${esc(s)}<button type="button" class="x" data-a="subDel" data-c="${esc(c)}" data-s="${esc(s)}" aria-label="${esc(s)} 삭제">×</button></span>`).join('')}<input class="mini" data-k="subAdd" data-c="${esc(c)}" placeholder="소분류 추가 후 Enter"></div></div>`).join('')}
      <input class="mini" data-k="catAdd" placeholder="대분류 추가 후 Enter"></div>
      <div class="box"><h3>브랜드</h3><div class="chips">${INV.brands.map(b => `<span class="chip">${esc(b)}<button type="button" class="x" data-a="brandDel" data-s="${esc(b)}" aria-label="${esc(b)} 삭제">×</button></span>`).join('')}</div><input class="mini" data-k="brandAdd" placeholder="브랜드 추가 후 Enter"></div></div>`;
  } else if (IS.base === 'pays') {
    body = `<div class="row-btns"><button type="button" class="primary" data-a="payEdit" data-id="">결제수단 추가</button><span class="hint">카드·계좌 번호는 넣지 마세요. 이름과 끝 4자리면 충분해요.</span></div>
    <div class="tbl"><table><thead><tr><th class="l">종류</th><th class="l">이름</th><th class="l">끝 4자리</th><th class="l">부가세 증빙</th><th></th></tr></thead><tbody>${INV.pays.map(p => `<tr><td class="l">${esc(p.type)}</td><td class="l"><b>${esc(p.name)}</b></td><td class="l">${esc(p.last4 || '')}</td><td class="l">${p.proof === false ? '없음' : '있음'}</td><td><div class="act"><button type="button" class="ghost" data-a="payEdit" data-id="${p.id}">수정</button><button type="button" class="ghost" data-a="payDel" data-id="${p.id}">삭제</button></div></td></tr>`).join('') || '<tr><td colspan="5" class="empty">아직 없어요</td></tr>'}</tbody></table></div>`;
  } else if (IS.base === 'couriers') {
    const B = ['극소', '소', '중', '대', '특대'];
    body = `<div class="row-btns"><button type="button" class="primary" data-a="courierEdit" data-id="">택배사 추가</button><span class="hint">박스 크기별 비용을 넣어 두면 출고할 때 골라서 넣을 수 있어요.</span></div>
    <div class="tbl"><table><thead><tr><th class="l">택배사</th>${B.map(b => `<th>${b}</th>`).join('')}<th></th></tr></thead><tbody>${INV.couriers.map(c => `<tr><td class="l"><b>${esc(c.name)}</b></td>${B.map(b => `<td>${c.box[b] ? won(+c.box[b]) : '–'}</td>`).join('')}<td><div class="act"><button type="button" class="ghost" data-a="courierEdit" data-id="${c.id}">수정</button><button type="button" class="ghost" data-a="courierDel" data-id="${c.id}">삭제</button></div></td></tr>`).join('')}</tbody></table></div>`;
  } else {
    body = `<div class="box"><div class="grid-set">
      <label>기본 반품 기한 (입고일부터, 일)<input type="number" min="0" data-k="opt" data-o="returnDays" value="${INV.opt.returnDays}"></label>
      <label>반품 기한 임박 알림 (남은 일수)<input type="number" min="0" data-k="opt" data-o="soon" value="${INV.opt.soon}"></label>
      <label>장기 재고 기준 (입고 후, 일)<input type="number" min="1" data-k="opt" data-o="staleDays" value="${INV.opt.staleDays}"></label></div>
      <p class="hint">매입처마다 반품 기한을 따로 정하면 그 값이 먼저 쓰여요. 크림 수수료 계산식은 위쪽 '설정'의 수수료율·기본료를 같이 써요.</p></div>`;
  }
  return `${head('기본정보', '거래처·분류·결제수단·택배사를 등록해 두면 입출고와 장부에서 골라 써요.')}${flash()}
  <div class="subtabs">${tabs.map(([k, t]) => `<button type="button" data-a="baseTab" data-v="${k}" aria-selected="${IS.base === k}">${t}</button>`).join('')}</div>${body}`;
}

// ---------- 상품 · 재고 ----------
function itemsFiltered(C) {
  const F = IS.items, q = F.q.trim().toLowerCase();
  return INV.items.filter(it => {
    if (F.brand && it.brand !== F.brand) return false;
    if (F.cat && it.cat !== F.cat) return false;
    if (q && !(`${it.code} ${it.name} ${it.brand} ${Object.values(it.barcodes || {}).join(' ')}`.toLowerCase().includes(q))) return false;
    if (F.only && !itemStock(it, C).qty) return false;
    return true;
  });
}
function vItems(C) {
  const F = IS.items, list = itemsFiltered(C);
  const bcAll = {}; for (const it of INV.items) for (const v of Object.values(it.barcodes || {})) if (v) bcAll[v] = (bcAll[v] || 0) + 1;
  let tq = 0, tv = 0;
  const rows = list.map(it => {
    const st = itemStock(it, C); tq += st.qty; tv += st.value;
    const sizes = (it.sizes || []).map(s => { const n = st.by[s] ? st.by[s].qty : 0; return `<span class="sz-chip${n ? ' on' : ''}">${esc(s)}${n ? ` <b>${n}</b>` : ''}</span>`; }).join('');
    const open = F.open === it.id;
    return `<tr class="item" data-a="itemOpen" data-id="${it.id}"><td class="l name"><b>${esc(itName(it))}</b><span class="code">${esc(it.code)}</span></td><td class="l">${esc([it.cat, it.sub].filter(Boolean).join(' · '))}</td><td class="l"><div class="sz-wrap">${sizes || '<span class="small">사이즈 없음</span>'}</div></td><td><b class="n">${st.qty}</b></td><td>${st.qty ? won(st.value / st.qty) : '–'}</td><td>${won(st.value)}</td>
      <td><div class="act"><button type="button" class="ghost" data-a="itemIn" data-id="${it.id}">입고</button><button type="button" class="ghost" data-a="itemOut" data-id="${it.id}">출고</button><button type="button" class="ghost" data-a="itemEdit" data-id="${it.id}">수정</button><button type="button" class="ghost" data-a="itemDel" data-id="${it.id}">삭제</button></div></td></tr>
      ${open ? `<tr class="detail"><td colspan="7">${itemDetail(it, C, bcAll)}</td></tr>` : ''}`;
  }).join('');
  return `${head('상품 · 재고', '상품을 누르면 사이즈별 재고·바코드·입출고 이력이 보여요.', `<button type="button" class="primary" data-a="ordQuick">구매처 주문 불러와서 자동 입고</button><button type="button" class="ghost" data-a="itemEdit" data-id="">상품 추가</button><button type="button" class="ghost" data-a="sizeSortAll">사이즈 전체 정렬</button><button type="button" class="ghost" data-a="itemsXl">엑셀 다운로드</button>`)}
  ${flash()}
  <div class="filters"><input type="search" data-k="itemsQ" value="${esc(F.q)}" placeholder="품번 · 상품명 · 바코드 검색">
    <select data-k="itemsBrand"><option value="">브랜드 전체</option>${[...new Set(INV.items.map(i => i.brand).filter(Boolean))].sort().map(b => opt(b, b, F.brand === b)).join('')}</select>
    <select data-k="itemsCat"><option value="">분류 전체</option>${Object.keys(INV.cats).map(c => opt(c, c, F.cat === c)).join('')}</select>
    <label class="chk"><input type="checkbox" data-k="itemsOnly"${F.only ? ' checked' : ''}> 재고 있는 것만</label></div>
  <div class="kgrid">${card('상품', list.length + '종')}${card('재고', tq + '개')}${card('재고 자산', won(tv))}${card('중복 바코드', Object.values(bcAll).filter(n => n > 1).length + '개', Object.values(bcAll).some(n => n > 1) ? 'neg' : '')}</div>
  <div class="tbl"><table class="main"><thead><tr><th class="l">상품</th><th class="l">분류</th><th class="l">사이즈별 재고</th><th>재고</th><th>평균 매입가</th><th>재고 금액</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="7" class="empty">상품이 없어요. 위의 <b>구매처 주문 불러와서 자동 입고</b>를 누르면 무신사·지그재그·ABC마트 등에서 산 상품이 재고로 들어와요.<br><span class="small">어느 구매처를 볼지·자동 동기화 간격은 <button type="button" class="linkbtn" data-a="nav" data-v="ms"><b>구매처 주문 입고</b></button> 메뉴에서 정해요. 직접 넣으려면 <b>상품 추가</b>나 <b>엑셀 대량 입고</b>.</span></td></tr>`}</tbody></table></div>`;
}
// 3.7.5: 재고 수량 직접 수정 — 늘리면 '재고 조정' 입고(평균 매입가), 줄이면 최근 입고분부터 조정 수량으로 빼요 (장부·매입 합계에는 안 잡힘)
async function stockSet(itemId, size, want) {
  want = Math.max(0, Math.floor(+want || 0));
  const C = invCalc(); const cur = (C.stock.get(itemId + '|' + size) || { qty: 0, value: 0 });
  const diff = want - cur.qty; if (!diff) return 0;
  if (diff > 0) {
    const mine = INV.lots.filter(l => l.itemId === itemId && l.src !== 'adjust').sort((a, b) => b.date.localeCompare(a.date));
    const lastLot = mine.find(l => l.size === size) || mine[0];   // 그 사이즈 입고가 없으면 같은 상품 최근 매입가
    const cost = cur.qty ? Math.round(cur.value / cur.qty) : lastLot ? lastLot.cost : 0;
    INV.lots.push({ id: uid(), at: Date.now(), date: today(), itemId, size, qty: diff, cost, partnerId: '', src: 'adjust', confirmed: true, retQty: 0, exQty: 0, events: [], memo: '재고 수량 직접 수정' });
  } else {
    let need = -diff;
    const lots = INV.lots.filter(l => l.itemId === itemId && l.size === size && C.left.get(l.id) > 0).sort((a, b) => b.date.localeCompare(a.date) || b.at - a.at);
    for (const l of lots) { if (!need) break; const take = Math.min(need, C.left.get(l.id)); l.adjQty = (l.adjQty || 0) + take; need -= take; }
  }
  await invSave(); return diff;
}
// 3.7.8/3.7.9: 입고 삭제 — 출고에 쓰였으면 그 출고도 같이 지워요(확인 창에 보여줘요).
//        구매처 주문에서 들어온 입고면 그 주문을 기억해서 다음 동기화 때 다시 안 들어와요.
function lotDelete(id, C, say) {
  const l = INV.lots.find(x => x.id === id); if (!l) return renderInv();
  const used = C.used.get(id) || 0;
  // 3.7.9: 출고에 쓰였어도 지울 수 있어요 — 그 출고도 같이 지워요
  const usedOuts = used > 0 ? INV.outs.filter(o => (o.costs || []).some(c => c.lotId === id)) : [];
  const fromOrder = l.srcKey ? '<p class="small">구매처 주문에서 자동으로 들어온 입고예요. 지우면 다음 동기화 때 다시 들어오지 않아요. 다시 넣으려면 입출고 메뉴에서 직접 입고하면 돼요.</p>' : '';
  const outNote = usedOuts.length ? `<p><b>이 입고를 쓴 출고 ${usedOuts.length}건(${usedOuts.reduce((s2, o) => s2 + o.qty, 0)}개)도 같이 지워져요</b> — ${usedOuts.slice(0, 3).map(o => `${esc(o.date)} ${esc(partnerOf(o.partnerId)?.name || (o.kind === 'pre' ? '보관 신청' : '출고'))}`).join(', ')}${usedOuts.length > 3 ? ' 외' : ''}. 매출 장부에서도 빠져요.</p>` : '';
  return invDialog('입고 삭제', `<p>${esc(itName(itemOf(l.itemId)))} ${esc(l.size)} ×${l.qty} (${esc(l.date)}, ${won(l.cost)}) 입고를 지울까요? 재고에서 빠지고 매입 장부에서도 빠져요.</p>${outNote}${fromOrder}`, async () => {
    if (usedOuts.length) { const del = new Set(usedOuts); INV.outs = INV.outs.filter(o => !del.has(o)); }
    INV.lots = INV.lots.filter(x => x !== l);
    if (l.srcKey) { INV.skipKeys = [...new Set([...(INV.skipKeys || []), l.srcKey])].slice(-5000); }
    await invSave(); IS.msg = '입고를 지웠어요'; renderInv();
  }, '삭제');
}
function itemDetail(it, C, bcAll) {
  const st = itemStock(it, C);
  const shoes = (it.sizes || []).some(s => US_M[s]);
  const sz = (it.sizes || []).map(s => { const x = st.by[s]; const b = (it.barcodes || {})[s] || ''; return `<tr><td class="l"><b>${esc(s)}</b></td>${shoes ? `<td class="l small">${US_M[s] ? `US ${US_M[s][0]} · EU ${US_M[s][1]}` : ''}</td>` : ''}<td><input type="number" class="mini" style="width:64px" min="0" step="1" data-k="stockSet" data-id="${it.id}" data-s="${esc(s)}" value="${x ? x.qty : 0}" title="재고 수량을 직접 고쳐요"></td><td>${x ? won(x.value / x.qty) : '–'}</td><td class="l"><input class="mini bc${b && bcAll[b] > 1 ? ' dup' : ''}" data-k="bc" data-id="${it.id}" data-s="${esc(s)}" value="${esc(b)}" placeholder="바코드"></td></tr>`; }).join('');
  const lots = INV.lots.filter(l => l.itemId === it.id).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
  const outs = INV.outs.filter(o => o.itemId === it.id).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
  return `<div class="det"><div class="det-top">
    <div class="box"><h3>사이즈별 재고 · 바코드</h3><table class="srct"><thead><tr><th class="l">사이즈</th>${shoes ? '<th class="l">변환 (나이키 남성 기준)</th>' : ''}<th>재고</th><th>평균 매입가</th><th class="l">바코드</th></tr></thead><tbody>${sz}</tbody></table><p class="hint">재고 숫자를 고치면 바로 반영돼요 (늘리면 '재고 조정' 입고, 줄이면 가장 최근 입고분에서 빼요 — 매입·매출 장부에는 안 잡혀요). 바코드를 넣으면 입출고에서 스캐너로 바로 찾아요. 빨간 칸은 다른 상품과 겹치는 바코드예요.</p></div>
    <div class="box"><h3>정보</h3><dl class="kv"><dt>품번</dt><dd>${esc(it.code)}</dd><dt>분류</dt><dd>${esc([it.cat, it.sub].filter(Boolean).join(' · ') || '–')}</dd><dt>크림 상품번호</dt><dd>${it.pid ? `<a href="https://kream.co.kr/products/${esc(it.pid)}" target="_blank" rel="noopener">${esc(it.pid)}</a>` : '–'}</dd><dt>메모</dt><dd>${esc(it.memo || '–')}</dd></dl></div></div>
    <div class="igrid2"><div class="box"><h3>입고 이력</h3><table class="srct"><thead><tr><th class="l">입고일</th><th class="l">사이즈</th><th>수량</th><th>남음</th><th>매입가</th><th class="l">매입처</th><th></th></tr></thead><tbody>${lots.map(l => `<tr><td class="l">${l.date}</td><td class="l">${esc(l.size)}</td><td>${l.qty}${l.retQty ? ` <span class="small">(반품 ${l.retQty})</span>` : ''}${l.exQty ? ` <span class="small">(교환 ${l.exQty})</span>` : ''}${l.adjQty ? ` <span class="small">(조정 −${l.adjQty})</span>` : ''}</td><td>${Math.max(0, C.left.get(l.id))}</td><td>${won(l.cost)}</td><td class="l">${esc(partnerOf(l.partnerId)?.name || (l.src === 'return' ? '판매 반품' : l.src === 'adjust' ? '재고 조정' : ''))}</td><td><button type="button" class="ghost tiny" data-a="lotDel" data-id="${l.id}"${(C.used.get(l.id) || 0) > 0 ? ' title="출고에 쓰인 입고예요"' : ''}>삭제</button></td></tr>`).join('') || '<tr><td colspan="7" class="small">없음</td></tr>'}</tbody></table></div>
    <div class="box"><h3>출고 이력</h3><table class="srct"><thead><tr><th class="l">출고일</th><th class="l">사이즈</th><th>수량</th><th>판매가</th><th>마진</th><th class="l">매출처</th></tr></thead><tbody>${outs.map(o => { const n = outNums(o); return `<tr><td class="l">${o.date}</td><td class="l">${esc(o.size)}</td><td>${o.qty}${o.retQty ? ` <span class="small">(반품 ${o.retQty})</span>` : ''}</td><td>${o.settled ? won(o.price) : '<span class="pill warn">정산 전</span>'}</td><td class="${n.margin > 0 ? 'pos' : n.margin < 0 ? 'neg' : ''}">${n.margin == null ? '–' : wonS(n.margin)}</td><td class="l">${esc(partnerOf(o.partnerId)?.name || '')}</td></tr>`; }).join('') || '<tr><td colspan="6" class="small">없음</td></tr>'}</tbody></table></div></div></div>`;
}
function itemForm(it) {
  it = it || { code: '', name: '', brand: '', cat: '', sub: '', sizes: [], memo: '', pid: '' };
  const cats = Object.keys(INV.cats);
  return `<div class="dgrid"><label>품번 (모델번호) *<input name="code" required value="${esc(it.code)}" placeholder="예: DD1391-100"${it.id && (INV.lots.some(l => l.itemId === it.id) || INV.outs.some(o => o.itemId === it.id)) ? ' readonly title="입출고 기록이 있어서 품번은 못 바꿔요"' : ''}></label>
    <label>상품명<input name="name" value="${esc(it.name)}" placeholder="예: 덩크 로우 블랙 화이트"></label>
    <label>브랜드<input name="brand" list="invBrands" value="${esc(it.brand)}"></label>
    <label>크림 상품번호<input name="pid" value="${esc(it.pid || '')}" placeholder="kream.co.kr/products/ 뒤 숫자"></label>
    <label>대분류<select name="cat"><option value="">선택 안 함</option>${cats.map(c => opt(c, c, it.cat === c)).join('')}</select></label>
    <label>소분류<select name="sub"><option value="">선택 안 함</option>${cats.flatMap(c => INV.cats[c].map(s => `<option value="${esc(s)}" data-c="${esc(c)}"${it.sub === s ? ' selected' : ''}>${esc(c)} · ${esc(s)}</option>`)).join('')}</select></label>
    <label class="wide">사이즈 (쉼표로 구분, 최소 1개) *<input name="sizes" required value="${esc((it.sizes || []).join(', '))}" placeholder="예: 250, 255, 260 또는 S, M, L"></label>
    <div class="wide row-btns">${Object.keys(SIZE_PRESETS).map(k => `<button type="button" class="ghost tiny" data-preset="${esc(k)}">${esc(k)}</button>`).join('')}</div>
    <label class="wide">메모<input name="memo" value="${esc(it.memo || '')}"></label></div>
    <datalist id="invBrands">${INV.brands.map(b => `<option value="${esc(b)}">`).join('')}</datalist>
    <div class="row-btns"><button type="button" class="ghost tiny" data-kfill>크림에서 상품명 찾기</button><span class="hint" data-kmsg>품번을 넣고 누르면 크림 검색 결과에서 이름·상품번호를 채워요.</span></div>`;
}
function parseSizes(s) { return [...new Set(String(s || '').split(/[,，/\s]+/).map(x => x.trim()).filter(Boolean))]; }
function saveItemFrom(fd, old) {
  const code = String(fd.code || '').trim(); if (!code) return '품번을 넣어 주세요';
  const sizes = parseSizes(fd.sizes); if (!sizes.length) return '사이즈를 1개 이상 넣어 주세요';
  const dup = INV.items.find(x => codeKey(x.code) === codeKey(code) && (!old || x.id !== old.id));
  if (dup) return `같은 품번이 이미 있어요: ${itName(dup)}`;
  if (old) {
    const usedSizes = new Set([...INV.lots.filter(l => l.itemId === old.id).map(l => l.size), ...INV.outs.filter(o => o.itemId === old.id).map(o => o.size)]);
    for (const s of usedSizes) if (!sizes.includes(s)) sizes.push(s);
  }
  const brand = String(fd.brand || '').trim();
  if (brand && !INV.brands.includes(brand)) INV.brands.push(brand);
  const it = old || { id: uid(), barcodes: {}, created: Date.now() };
  Object.assign(it, { code, name: String(fd.name || '').trim(), brand, cat: fd.cat || '', sub: fd.sub || '', sizes, memo: fd.memo || '', pid: String(fd.pid || '').replace(/\D/g, '') });
  if (!old) INV.items.unshift(it);
  return it;
}
function openItemDialog(it, after) {
  invDialog(it ? '상품 수정' : '상품 추가', itemForm(it), async fd => {
    const r = saveItemFrom(fd, it); if (typeof r === 'string') return r;
    await invSave(); IS.msg = `${itName(r)} 저장했어요`; if (after) after(r); renderInv();
  });
  const dlg = $('#invDlg');
  dlg.querySelectorAll('[data-preset]').forEach(b => b.addEventListener('click', () => { dlg.querySelector('[name=sizes]').value = SIZE_PRESETS[b.dataset.preset].join(', '); }));
  const sub = dlg.querySelector('[name=sub]'), cat = dlg.querySelector('[name=cat]');
  sub.addEventListener('change', () => { const o = sub.selectedOptions[0]; if (o && o.dataset.c) cat.value = o.dataset.c; });
  dlg.querySelector('[data-kfill]').addEventListener('click', async () => {
    const code = dlg.querySelector('[name=code]').value.trim(), m = dlg.querySelector('[data-kmsg]');
    if (!code) { m.textContent = '품번부터 넣어 주세요'; return; }
    const local = products.find(p => p.raw && p.raw.info && codeKey(p.raw.info.code).includes(codeKey(code)));
    if (local) { const i = local.raw.info; dlg.querySelector('[name=name]').value = i.name || ''; dlg.querySelector('[name=pid]').value = local.pid; if (i.brand) dlg.querySelector('[name=brand]').value = i.brand; m.textContent = '내 상품에 있는 크림 정보로 채웠어요'; return; }
    if (!HAS_CHROME || !chrome.scripting) { m.textContent = '크림스캐너 안에서만 돼요'; return; }
    m.textContent = '크림 검색 중… (작은 창이 열렸다 닫혀요)';
    try {
      const tabId = await srcNav(`https://kream.co.kr/search?keyword=${encodeURIComponent(code)}`);
      await sleep(1500);
      const [r] = await execT({ target: { tabId }, func: kcList, args: [3] });
      const k = ((r && r.result) || [])[0];
      if (!k) m.textContent = '크림에서 못 찾았어요. 직접 넣어 주세요.';
      else { dlg.querySelector('[name=name]').value = k.name || ''; dlg.querySelector('[name=pid]').value = k.pid || ''; if (k.brand) dlg.querySelector('[name=brand]').value = k.brand; m.textContent = `크림 검색 첫 결과로 채웠어요: ${k.name} — 품번이 맞는지 한 번 보세요`; }
    } catch (e) { m.textContent = '검색 실패: ' + e.message; }
    if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  });
}

// ---------- 입출고 ----------
function ioPartners(mode) { return INV.partners.filter(p => p.kind === (mode === 'in' ? 'buy' : 'sell')); }
function ioDefaults() {
  const io = IS.io; if (!io.date) io.date = today();
  const ps = ioPartners(io.mode); if (!ps.some(p => p.id === io.partnerId)) io.partnerId = ps[0] ? ps[0].id : '';
}
function ioSearch(q) {
  q = q.trim().toLowerCase(); if (!q) return [];
  const k = codeKey(q);
  return INV.items.filter(it => codeKey(it.code).includes(k) && k.length >= 2 || `${it.name} ${it.brand}`.toLowerCase().includes(q) || Object.values(it.barcodes || {}).includes(q)).slice(0, 8);
}
function findBarcode(code) { for (const it of INV.items) for (const [s, b] of Object.entries(it.barcodes || {})) if (b && b === code) return { it, size: s }; return null; }
function ioAddRow(it, size) {
  const io = IS.io;
  const same = io.rows.find(r => r.itemId === it.id && r.size === size && size);
  if (same && io.multi) { same.qty = (+same.qty || 0) + 1; }
  else {
    const lastCost = INV.lots.filter(l => l.itemId === it.id).sort((a, b) => b.at - a.at)[0];
    io.rows.push({ key: uid(), itemId: it.id, size: size || '', qty: 1, price: io.mode === 'in' && lastCost ? lastCost.cost : '', ship: '', memo: '' });
  }
  saveDraft();
}
function saveDraft() { store.set('invDraft', { mode: IS.io.mode, date: IS.io.date, partnerId: IS.io.partnerId, payId: IS.io.payId, rows: IS.io.rows }); }
function vIO(C) {
  ioDefaults();
  const io = IS.io, M = io.mode;
  const title = { in: '입고', out: '출고', pre: '우선출고' }[M];
  const sug = ioSearch(io.q);
  const boxes = INV.couriers.flatMap(c => Object.entries(c.box).filter(([, v]) => +v).map(([b, v]) => ({ label: `${c.name} ${b}`, v: +v })));
  let total = 0;
  const rows = io.rows.map((r, i) => {
    const it = itemOf(r.itemId); if (!it) return '';
    const have = (C.stock.get(it.id + '|' + r.size) || { qty: 0 }).qty;
    const q = +r.qty || 0; total += (M === 'pre' ? 0 : num(r.price) * q);
    const short = M !== 'in' && r.size && have < q;
    return `<tr><td>${i + 1}</td><td class="l name"><b>${esc(itName(it))}</b><span class="code">${esc(it.code)}</span></td>
      <td><select data-k="ioRow" data-f="size" data-i="${r.key}"><option value="">사이즈</option>${(it.sizes || []).map(s => opt(s, s + (M !== 'in' ? ` (재고 ${(C.stock.get(it.id + '|' + s) || { qty: 0 }).qty})` : ''), r.size === s)).join('')}</select></td>
      <td><input type="number" min="1" class="cost-in" data-k="ioRow" data-f="qty" data-i="${r.key}" value="${esc(r.qty)}">${short ? `<div class="small neg">재고 ${have}개</div>` : ''}</td>
      ${M === 'pre' ? '' : `<td><input inputmode="numeric" class="cost-in" data-k="ioRow" data-f="price" data-i="${r.key}" value="${esc(r.price)}" placeholder="${M === 'in' ? '매입가' : '판매가'}">${M === 'out' && num(r.price) ? `<div class="small">수수료 ${won(partnerFee(partnerOf(io.partnerId), num(r.price)))}</div>` : ''}</td>`}
      ${M === 'in' ? '' : `<td><input inputmode="numeric" class="cost-in" list="invBoxes" data-k="ioRow" data-f="ship" data-i="${r.key}" value="${esc(r.ship)}" placeholder="택배비"></td>`}
      <td><input class="mini" data-k="ioRow" data-f="memo" data-i="${r.key}" value="${esc(r.memo)}" placeholder="메모"></td>
      <td><button type="button" class="x" data-a="ioDel" data-i="${r.key}" aria-label="줄 삭제">×</button></td></tr>`;
  }).join('');
  // 최근 이력
  const a = IS.lg.from || monthStart(), b = IS.lg.to || monthEnd();
  const hist = [
    ...INV.lots.filter(l => inRange(l.date, addDays(today(), -30), '9999') && !['exchange', 'return', 'adjust'].includes(l.src)).map(l => ({ d: l.date, at: l.at, t: '입고', it: itemOf(l.itemId), size: l.size, qty: l.qty, price: l.cost, p: partnerOf(l.partnerId), id: l.id, k: 'lot' })),
    ...INV.outs.filter(o => inRange(o.date, addDays(today(), -30), '9999')).map(o => ({ d: o.date, at: o.at, t: o.kind === 'pre' ? (o.settled ? '우선출고 · 정산됨' : '우선출고') : '출고', it: itemOf(o.itemId), size: o.size, qty: o.qty, price: o.settled ? o.price : null, p: partnerOf(o.partnerId), id: o.id, k: 'out' }))
  ].sort((x, y) => y.d.localeCompare(x.d) || y.at - x.at).slice(0, 60);
  void a; void b;
  return `${head('입출고', '입고·출고·우선출고(판매가 나중에 정해지는 출고)를 한 화면에서 등록해요. 적던 내용은 다른 메뉴에 갔다 와도 남아요.')}
  ${flash()}
  <div class="subtabs">${[['in', '입고'], ['out', '출고'], ['pre', '우선출고']].map(([k, t]) => `<button type="button" data-a="ioMode" data-v="${k}" aria-selected="${M === k}">${t}</button>`).join('')}</div>
  <div class="panel">
    <div class="grid-set"><label>거래일<input type="date" data-k="io" data-f="date" value="${esc(io.date)}"></label>
      <label>${M === 'in' ? '매입처' : '매출처'}<select data-k="io" data-f="partnerId">${ioPartners(M).map(p => opt(p.id, p.name, p.id === io.partnerId)).join('')}</select></label>
      ${M === 'in' ? `<label>결제수단<select data-k="io" data-f="payId"><option value="">선택 안 함</option>${INV.pays.map(p => opt(p.id, `${p.type} · ${p.name}${p.last4 ? ' ' + p.last4 : ''}`, p.id === io.payId)).join('')}</select></label>` : `<div class="hint" style="align-self:end">${M === 'pre' ? '판매가 없이 먼저 내보내요. 나중에 <b>우선출고 정산</b>에서 판매가를 넣어요.' : '판매가를 넣으면 매출처 수수료가 자동으로 빠져요.'}</div>`}</div>
    <div class="ioq"><input id="ioQ" data-k="ioQ" value="${esc(io.q)}" placeholder="${io.bc ? '바코드를 스캔하세요 (끝내려면 Esc)' : '품번 · 상품명 · 바코드로 상품 찾기 (Enter = 첫 번째 결과)'}" autocomplete="off"${io.bc ? ' class="bcmode"' : ''}>
      <button type="button" class="${io.bc ? 'primary' : 'ghost'}" data-a="ioBc">바코드 ${io.bc ? '켜짐' : '꺼짐'}</button>
      <button type="button" class="ghost" data-a="ioMulti" title="복수: 같은 상품을 다시 찍으면 수량 +1 / 단건: 매번 새 줄">${io.multi ? '복수 등록' : '단건 등록'}</button>
      <button type="button" class="ghost" data-a="itemEdit" data-id="" data-then="io">새 상품</button></div>
    ${sug.length && !io.bc ? `<div class="sug">${sug.map(it => `<button type="button" data-a="ioPick" data-id="${it.id}"><b>${esc(it.code)}</b> ${esc(itName(it))}</button>`).join('')}</div>` : ''}
    ${io.msg ? `<p class="hint ${/못|없|부족/.test(io.msg) ? 'neg' : 'pos'}">${esc(io.msg)}</p>` : ''}
    <div class="tbl"><table><thead><tr><th>#</th><th class="l">상품</th><th>사이즈</th><th>수량</th>${M === 'pre' ? '' : `<th>${M === 'in' ? '매입가 (개당)' : '판매가 (개당)'}</th>`}${M === 'in' ? '' : '<th>택배비 (합계)</th>'}<th class="l">메모</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="8" class="empty">위에서 상품을 찾아 넣으세요.</td></tr>`}</tbody></table></div>
    <datalist id="invBoxes">${boxes.map(x => `<option value="${x.v}">${esc(x.label)}</option>`).join('')}</datalist>
    <div class="toolbar"><span class="hint" id="ioSum">${io.rows.length}줄 · ${io.rows.reduce((s, r) => s + (+r.qty || 0), 0)}개${M === 'pre' ? '' : ` · 합계 ${won(total)}`}</span><div class="row-btns"><button type="button" class="ghost" data-a="ioClear">비우기</button><button type="button" class="primary" data-a="ioSave">${title} 등록 완료</button></div></div>
  </div>
  <div class="panel"><h2>최근 30일 입출고</h2>
    <div class="tbl"><table><thead><tr><th class="l">날짜</th><th class="l">구분</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>단가</th><th class="l">거래처</th><th></th></tr></thead><tbody>${hist.map(h => `<tr><td class="l">${h.d}</td><td class="l"><span class="pill ${h.t === '입고' ? 'ok' : h.t === '우선출고' ? 'warn' : 'mute'}">${h.t}</span></td><td class="l">${esc(itName(h.it))}</td><td class="l">${esc(h.size)}</td><td>${h.qty}</td><td>${h.price == null ? '–' : won(h.price)}</td><td class="l">${esc(h.p?.name || '')}</td><td><button type="button" class="ghost tiny" data-a="histDel" data-k="${h.k}" data-id="${h.id}">삭제</button></td></tr>`).join('') || '<tr><td colspan="8" class="empty">최근 30일 기록이 없어요</td></tr>'}</tbody></table></div></div>`;
}
async function ioSave() {
  const io = IS.io, M = io.mode;
  const rows = io.rows.filter(r => itemOf(r.itemId));
  if (!rows.length) { io.msg = '등록할 줄이 없어요'; return renderInv(); }
  for (const [i, r] of rows.entries()) {
    if (!r.size) { io.msg = `${i + 1}번 줄 사이즈를 골라 주세요`; return renderInv(); }
    if (!(+r.qty >= 1)) { io.msg = `${i + 1}번 줄 수량을 넣어 주세요`; return renderInv(); }
    if (M === 'out' && !num(r.price)) { io.msg = `${i + 1}번 줄 판매가가 없어요. 판매가를 모르면 '우선출고'로 등록하세요`; return renderInv(); }
  }
  if (!io.partnerId) { io.msg = '거래처를 골라 주세요 (기본정보에서 추가)'; return renderInv(); }
  const p = partnerOf(io.partnerId);
  if (M === 'in') {
    for (const r of rows) {
      const it = itemOf(r.itemId); if (!it.sizes.includes(r.size)) it.sizes.push(r.size);
      INV.lots.push({ id: uid(), at: Date.now(), date: io.date, itemId: r.itemId, size: r.size, qty: +r.qty, cost: num(r.price), partnerId: io.partnerId, payId: io.payId, memo: r.memo, src: 'manual', returnDue: addDays(io.date, p.returnDays ?? INV.opt.returnDays), confirmed: false, retQty: 0, exQty: 0, events: [] });
    }
  } else {
    const C = invCalc(); const made = [];
    for (const [i, r] of rows.entries()) {
      const costs = allocate(r.itemId, r.size, +r.qty, C);
      if (!costs) { const have = (invCalc().stock.get(r.itemId + '|' + r.size) || { qty: 0 }).qty; io.msg = `${i + 1}번 줄 재고 부족 — ${itName(itemOf(r.itemId))} ${r.size} 재고 ${have}개 (같은 상품 여러 줄이면 합계로 봐요)`; return renderInv(); }
      made.push({ id: uid(), at: Date.now() + i, date: io.date, itemId: r.itemId, size: r.size, qty: +r.qty, price: M === 'out' ? num(r.price) : 0, partnerId: io.partnerId, kind: M, settled: M === 'out', settleDate: M === 'out' ? io.date : '', ship: num(r.ship), fee: '', costs, retQty: 0, disc: 0, events: [], confirmed: false, memo: r.memo });
    }
    INV.outs.push(...made);
  }
  const n = rows.reduce((s, r) => s + +r.qty, 0);
  io.rows = []; io.q = ''; io.msg = `${{ in: '입고', out: '출고', pre: '우선출고' }[M]} ${rows.length}줄 · ${n}개 등록했어요`;
  await invSave(); saveDraft(); renderInv();
}

// ---------- 엑셀 대량 입고 ----------
const XL_COLS = { code: /품번|모델\s*번호|모델명?코드|스타일\s*코드|style|sku|article|货号/i, name: /상품\s*명|^상품$|제품\s*명|name/i, size: /사이즈|옵션|size|尺码/i, qty: /수량|qty|개수/i, cost: /매입\s*가|단가|매입\s*금액|구매\s*가|가격|cost|price/i, date: /거래\s*일|매입\s*일|구매\s*일|주문\s*일|날짜|date/i, brand: /브랜드|brand/i, memo: /메모|비고|memo/i };
function xlTemplate() {
  xlDownload([
    { name: '입고양식', rows: [['품번', '상품명', '사이즈', '수량', '매입가', '거래일', '브랜드', '메모'], ['DD1391-100', '덩크 로우 블랙 화이트', '270', 1, 129000, today(), '나이키', ''], ['MR530KA', '530 스틸 그레이', '260', 2, 82000, today(), '뉴발란스', '쿠폰 적용']], widths: [16, 30, 8, 6, 10, 12, 12, 20] },
    { name: '작성 가이드', rows: [['항목', '설명'], ['품번 (필수)', '모델번호. 같은 품번은 같은 상품으로 묶여요.'], ['상품명', '처음 등록되는 상품일 때 필요해요. 이미 있는 품번이면 비워도 돼요.'], ['사이즈 (필수)', '250, 270, M, XL 처럼'], ['수량 (필수)', '숫자'], ['매입가', '개당 금액. 비우면 미리보기에서 넣을 수 있어요.'], ['거래일', '2026-11-11 형식. 비우면 오늘'], ['매입처·결제수단', '엑셀에 쓰지 않아요. 올린 뒤 미리보기 화면에서 골라요.'], ['파일 형식', '.xlsx 또는 .csv (옛날 .xls 는 안 돼요)']], widths: [18, 70] }
  ], '크림스캐너_입고양식.xlsx');
}
async function xlLoad(file) {
  try {
    const rows = await XL.readFile(file);
    let hi = rows.findIndex(r => r.some(v => XL_COLS.code.test(String(v))) && r.some(v => XL_COLS.size.test(String(v))));
    if (hi < 0) throw new Error('첫 줄에서 "품번"과 "사이즈" 칸을 못 찾았어요. 양식 다운로드로 받은 파일 형식에 맞춰 주세요.');
    const H = rows[hi].map(v => String(v).trim()); const col = {};
    for (const [k, re] of Object.entries(XL_COLS)) col[k] = H.findIndex((h, i) => re.test(h) && !Object.values(col).includes(i));
    const buy = INV.partners.find(p => p.kind === 'buy');
    const out = [];
    for (const r of rows.slice(hi + 1)) {
      const g = k => col[k] >= 0 ? r[col[k]] : '';
      const code = String(g('code') || '').trim(); if (!code) continue;
      const it = INV.items.find(x => codeKey(x.code) === codeKey(code));
      const row = { k: uid(), sel: true, code, name: String(g('name') || '').trim(), brand: String(g('brand') || '').trim(), size: String(g('size') ?? '').trim(), qty: Math.round(num(g('qty'))) || 1, cost: num(g('cost')), date: XL.dateOf(g('date')) || today(), memo: String(g('memo') || ''), partnerId: buy ? buy.id : '', payId: '', isNew: !it };
      if (!row.size) row.err = '사이즈 없음'; else if (!it && !row.name) row.err = '새 상품인데 상품명 없음';
      out.push(row);
    }
    if (!out.length) throw new Error('읽을 줄이 없어요');
    IS.xl = { file: file.name, rows: out, msg: '' };
  } catch (e) { IS.xl = { file: file.name, rows: [], msg: e.message }; }
  renderInv();
}
function vExcel() {
  const X = IS.xl;
  const buys = INV.partners.filter(p => p.kind === 'buy');
  const rows = X && X.rows.length ? X.rows.map(r => `<tr class="${r.err ? 'err' : ''}"><td><input type="checkbox" data-k="xlRow" data-f="sel" data-i="${r.k}"${r.sel && !r.err ? ' checked' : ''}${r.err ? ' disabled' : ''}></td><td class="l"><b>${esc(r.code)}</b>${r.isNew ? ' <span class="pill warn">새 상품</span>' : ''}<div class="small">${esc(r.brand ? r.brand + ' ' : '')}${esc(r.name)}</div>${r.err ? `<div class="small neg">${esc(r.err)}</div>` : ''}</td><td class="l">${esc(r.size)}</td><td>${r.qty}</td>
    <td><input inputmode="numeric" class="cost-in" data-k="xlRow" data-f="cost" data-i="${r.k}" value="${r.cost || ''}"></td><td><input type="date" data-k="xlRow" data-f="date" data-i="${r.k}" value="${esc(r.date)}"></td>
    <td><select data-k="xlRow" data-f="partnerId" data-i="${r.k}">${buys.map(p => opt(p.id, p.name, p.id === r.partnerId)).join('')}</select></td>
    <td><select data-k="xlRow" data-f="payId" data-i="${r.k}"><option value="">–</option>${INV.pays.map(p => opt(p.id, p.name, p.id === r.payId)).join('')}</select></td></tr>`).join('') : '';
  const selN = X ? X.rows.filter(r => r.sel && !r.err).length : 0;
  return `${head('엑셀 대량 입고', '엑셀(.xlsx)이나 CSV로 여러 상품을 한 번에 입고해요. 매입처·결제수단은 올린 뒤 여기서 골라요.', `<button type="button" class="ghost" data-a="xlTpl">양식 다운로드</button>`)}
  ${flash()}
  <label class="drop" data-drop><input type="file" accept=".xlsx,.xlsm,.csv" data-k="xlFile" hidden><b>파일을 끌어다 놓거나 눌러서 고르세요</b><span class="hint">.xlsx · .xlsm · .csv (옛날 .xls 는 엑셀에서 .xlsx 로 다시 저장)</span>${X ? `<span class="small">${esc(X.file)}</span>` : ''}</label>
  ${X && X.msg ? `<p class="iflash neg">${esc(X.msg)}</p>` : ''}
  ${X && X.rows.length ? `<div class="panel"><div class="toolbar"><div class="row-btns"><span class="hint">선택한 줄에 일괄 적용:</span>
      <select data-k="xlBulk" data-f="partnerId"><option value="">매입처</option>${buys.map(p => opt(p.id, p.name)).join('')}</select>
      <select data-k="xlBulk" data-f="payId"><option value="">결제수단</option>${INV.pays.map(p => opt(p.id, p.name)).join('')}</select>
      <input type="date" data-k="xlBulk" data-f="date" title="거래일"></div>
      <div class="row-btns"><button type="button" class="ghost" data-a="xlAll">전체 선택/해제</button><button type="button" class="primary" data-a="xlSave"${selN ? '' : ' disabled'}>선택 ${selN}줄 입고 저장</button></div></div>
    <div class="tbl"><table><thead><tr><th></th><th class="l">품번 · 상품</th><th class="l">사이즈</th><th>수량</th><th>매입가 (개당 실결제)</th><th>거래일</th><th>매입처</th><th>결제수단</th></tr></thead><tbody>${rows}</tbody></table></div></div>` : ''}`;
}
async function xlSave() {
  const X = IS.xl; if (!X) return;
  const sel = X.rows.filter(r => r.sel && !r.err); let newItems = 0, n = 0;
  for (const r of sel) {
    let it = INV.items.find(x => codeKey(x.code) === codeKey(r.code));
    if (!it) { it = { id: uid(), code: r.code, name: r.name, brand: r.brand, cat: '', sub: '', sizes: [], barcodes: {}, memo: '', created: Date.now(), auto: 'order' }; INV.items.unshift(it); newItems++; if (r.brand && !INV.brands.includes(r.brand)) INV.brands.push(r.brand); }
    if (!it.sizes.includes(r.size)) it.sizes.push(r.size);
    const p = partnerOf(r.partnerId);
    INV.lots.push({ id: uid(), at: Date.now() + n, date: r.date, itemId: it.id, size: r.size, qty: r.qty, cost: r.cost, partnerId: r.partnerId, payId: r.payId, memo: r.memo, src: 'excel', returnDue: addDays(r.date, p && p.returnDays != null ? p.returnDays : INV.opt.returnDays), confirmed: false, retQty: 0, exQty: 0, events: [] });
    n += r.qty;
  }
  X.rows = X.rows.filter(r => !(r.sel && !r.err));
  IS.msg = `${sel.length}줄 · ${n}개 입고했어요${newItems ? ` (새 상품 ${newItems}종 등록)` : ''}`;
  await invSave(); renderInv();
}

// ---------- 구매처 주문 입고 (무신사 + 다른 쇼핑몰) ----------
// 주문 내역 화면 주소 (2026-11-11 로그인한 화면에서 확인). 무신사는 전용 읽기, 나머지는 공통 읽기(kcOrders)를 써요.
const ORDER_SITES = [
  { k: 'musinsa', label: '무신사', partner: '무신사', ok: '확인' },
  { k: 'zigzag', label: '지그재그', url: 'https://zigzag.kr/checkout/orders', ok: '확인' },
  { k: 'gmarket', label: 'G마켓', url: 'https://my.gmarket.co.kr/ko/pc/list/all', ok: '확인' },
  { k: '11st', label: '11번가', url: 'https://buy.11st.co.kr/my11st/order/OrderList.tmall', ok: '빈 화면 확인' },
  { k: 'ssg', label: 'SSG · 신세계', partner: 'SSG', url: 'https://pay.ssg.com/myssg/orderInfo.ssg?viewType=Ssg', ok: '빈 화면 확인' },
  { k: 'lotte', label: '롯데ON', url: 'https://www.lotteon.com/p/order/mylotte/orderDeliveryList', ok: '빈 화면 확인' },
  { k: '29cm', label: '29CM', url: 'https://www.29cm.co.kr/order/my-order/list', ok: '빈 화면 확인' },
  { k: 'wconcept', label: 'W컨셉', url: 'https://www.wconcept.co.kr/MyPage/MyOrderList', ok: '빈 화면 확인' },
  { k: 'rexmonde', label: '렉스몬드', url: 'https://www.rexmonde.com/mypage/order_list', ok: '빈 화면 확인' },
  { k: 'nike', label: '나이키', partner: '나이키 공식몰', url: 'https://www.nike.com/kr/orders', ok: '화면만 확인' },
  { k: 'ssf', label: 'SSF샵', url: 'https://www.ssfshop.com/secured/mypage/myPage', ok: '로그인 안 됨' },
  { k: 'abc', label: 'ABC마트 · 그랜드스테이지', partner: 'ABC마트', url: 'https://abcmart.a-rt.com/mypage/claim/claim-order-main', detail: id => `https://abcmart.a-rt.com/product/new?prdtNo=${id}`, ok: '확인' },
  // 3.8.1: 4910 웹 주문내역 (로그인 안 돼 있으면 홈으로 넘어가요 → 로그인 필요로 봐요)
  { k: '4910', label: '4910', url: 'https://4910.kr/order', mustPath: '/order', ok: '처음 주문 읽기 확인 중' }
];
const ORD_SKIP = /취소|반품|환불|교환완료/;
// 3.0.1: 처음엔 실제 주문으로 확인한 곳만 켜 둬요(나머지는 체크하면 같이 봐요). 안 쓰는 곳까지 돌면 동기화가 오래 걸려요.
const ORD_DEFAULT = ['musinsa', 'zigzag', 'gmarket', 'abc'];   // 3.3: 쿠팡은 뺐어요
// 설치 프로그램에서는 쿠팡이 접속 자체를 막아요(Access Denied) — 쿠팡 주문은 크림스캐너 확장이나 직접 입력으로
let ordCache = {};   // { site: { at, rows, msg } }
const ordSize = (opt, name, code) => {
  let o = String(opt || '').replace(/\s*\d{1,3}\s*개\s*$/, '').replace(/\(\s*[+-]?[\d,]+\s*원\s*\)/g, '').trim();
  if (code && codeKey(o).startsWith(codeKey(code))) o = o.slice(o.toUpperCase().indexOf(String(code).slice(-3).toUpperCase()) + 3).trim();
  const seg = o.split('/').map(x => x.trim()).filter(Boolean).pop() || '';
  const m = seg.match(/\b(\d{3}(?:\.\d)?|[2-4]?X{0,3}[SML]|XS|XXL|FREE|F)\b(\(\d{2,3}\))?/i) || String(name || '').match(/\b(2[2-9]\d|3[0-2]\d)\b/);
  return m ? m[0].toUpperCase() : seg.slice(0, 12);
};
const ordCode = name => {
  const t = String(name || '').toUpperCase();
  const paren = (t.match(/\(([A-Z0-9][A-Z0-9-]{4,})\)/) || [])[1];
  if (paren && /\d/.test(paren) && /[A-Z]/.test(paren)) return paren;
  const ms = typeof msCode === 'function' ? msCode(name) : '';
  if (ms) return ms;
  const c = (t.match(/[A-Z0-9][A-Z0-9-]{4,}/g) || []).filter(x => /\d/.test(x) && /[A-Z]/.test(x) && !/^\d+[A-Z]{1,2}$/.test(x));
  return c.find(x => x.includes('-')) || c[0] || '';
};
function ordRows() {
  const out = [];
  for (const r of records.filter(r => r.musinsaId || /^ms-/.test(r.id))) {
    const status = String(r.memo || '').replace(/^무신사 주문 \S+ · /, '');
    out.push({ site: 'musinsa', key: r.id, date: r.buyDate || '', name: r.name || '', opt: r.size || '', size: String(r.size || '').split('/').pop().trim(), qty: +r.qty || 1, unit: +r.cost || 0, listUnit: r.listCost != null ? +r.listCost : +r.cost || 0, paidOk: !!r.paidOk, needPaid: false, status, orderNo: (String(r.memo || '').match(/주문 (\S+)/) || [])[1] || '', code: r.code || msCode(r.name) || '', fallback: 'MS-' + (r.musinsaId || r.id.split('-')[1]) });
  }
  for (const S of ORDER_SITES) {
    const C = ordCache[S.k]; if (!C) continue;
    const seen = {};
    for (const r of C.rows) {
      const base = [S.k, r.orderNo || r.date, r.name, r.opt, r.price].join('|'); seen[base] = (seen[base] || 0) + 1;
      const code = r.code || ordCode(r.name);
      const q = Math.max(1, r.qty || 1), listUnit = r.price ? Math.round(r.price / q) : 0;
      // 3.10.7: 주문번호 — 목록에 없으면 주문상세에서 읽은 번호, 그것도 없으면 주문상세 주소(주문마다 하나)를 주문 구분용으로 써요
      const pcx = (ordCache.paid || {})[r.detail] || {};
      const ordId = r.orderNo || pcx.orderNo || (r.detail ? 'D:' + String(r.detail).replace(/^https?:\/\/[^/]+/, '').split('#')[0] : '');
      out.push({ ordId, site: S.k, key: base + '|' + seen[base], date: r.date, name: r.name, opt: r.opt, size: ordSize(r.opt, r.name, code), qty: r.qty || 1, unit: r.paid ? Math.round(r.paid / q) : listUnit, listUnit, paidOk: !!r.paid, needPaid: !!r.detail && !r.paid, status: r.status, orderNo: r.orderNo, code, fallback: (S.k + '-' + (r.orderNo || r.date.replace(/-/g, ''))).toUpperCase() });
    }
  }
  const done = new Set(INV.lots.map(l => l.srcKey).filter(Boolean));
  const skip = new Set(INV.skipKeys || []);   // 3.7.8: 입고를 지운 주문은 다시 안 들여와요
  const ck = new Set(ordCache.cancelKeys || []);
  out.forEach(x => { x.done = done.has(x.key) || skip.has(x.key); x.deleted = skip.has(x.key); x.cancel = ORD_SKIP.test(x.status) || ck.has(x.key); });
  ordDedupe(out);
  return out;
}
// 3.10.7: 같은 주문이 재고에 두 번 들어오지 않게 막아요 (보관 신청은 재고 수만큼만 하니까 재고가 틀리면 안 돼요)
//  ① 주문번호가 같은 주문이 다른 아이디 칸(예: 지그재그 #2와 #5)에 둘 다 보이면 = 같은 아이디로 두 칸에 로그인한 것 → 한 칸 것만 써요
//  ② 주문 목록의 가격·상품명 표시가 바뀌어 주문 키가 달라져도, (구매처·주문번호·사이즈)로 이미 입고된 수량만큼은 '이미 입고됨'으로 봐요
const ordBase = k => String(k).split('~')[0];
const ordSz = s => String(s || '').trim().toUpperCase().replace(/\s+/g, '');
let ordDupWarn = [];
function ordDedupe(out) {
  ordDupWarn = [];
  const idOf = x => { const o = x.ordId || x.orderNo; return o ? [ordBase(x.site), String(o).trim(), ordSz(x.size)].join('|') : ''; };
  // ① 다른 아이디 칸의 같은 주문
  const owner = new Map();
  for (const x of out) { const id = idOf(x); if (!id) continue; if (!owner.has(id)) owner.set(id, x.site); }
  for (const x of out) {
    const id = idOf(x); if (!id) continue; const o = owner.get(id);
    if (o !== x.site) { if (!x.done) { x.done = true; x.dup = true; } const w = `${siteLabel(o)} · ${siteLabel(x.site)}${x.orderNo ? ` (주문 ${x.orderNo})` : ''}`; if (!ordDupWarn.includes(w)) ordDupWarn.push(w); }
  }
  // ② 이미 입고된 수량 (예전 키로 들어간 입고도 포함)
  const imported = new Map();
  for (const l of INV.lots) {
    if (!l.srcKey || !(l.src === 'order' || l.src === 'musinsa')) continue;
    const no = l.ordId || l.ordNo || (String(l.memo || '').match(/주문 (\S+)/) || [])[1]; if (!no) continue;
    const site = l.src === 'musinsa' ? 'musinsa' : ordBase(String(l.srcKey).split('|')[0]);
    const id = [site, no, ordSz(l.size)].join('|'); imported.set(id, (imported.get(id) || 0) + (+l.qty || 0));
  }
  const doneQty = new Map();
  for (const x of out) { const id = idOf(x); if (!id || !x.done || x.dup || x.deleted) continue; doneQty.set(id, (doneQty.get(id) || 0) + (+x.qty || 1)); }
  const extra = new Map([...imported].map(([id, q]) => [id, q - (doneQty.get(id) || 0)]));
  for (const x of out) {
    const id = idOf(x); if (!id || x.done || x.cancel) continue;
    const e = extra.get(id) || 0; const q = +x.qty || 1;
    if (e >= q) { x.done = true; x.dup = true; extra.set(id, e - q); }
  }
}
function siteLabel(k) { return (ORDER_SITES.find(s => s.k === k) || {}).label || k; }
function sitePartner(k) {
  const S = ORDER_SITES.find(s => s.k === k) || { label: k };
  const name = S.partner || S.label;
  let p = INV.partners.find(x => x.kind === 'buy' && (x.name === name || x.name === S.label));
  if (!p) { p = { id: 'p-' + k, kind: 'buy', name, biz: '', tax: '과세', returnDays: INV.opt.returnDays }; INV.partners.push(p); }
  return p;
}
function vMs() {
  const M = IS.ms; M.sites = M.sites || new Set((INV.opt.ordSites || ORD_DEFAULT).filter(k => ORDER_SITES.some(S => S.k === k))); M.edit = M.edit || {};
  const all = ordRows();
  const view = all.filter(x => !x.done && (M.showCancel || !x.cancel) && (!M.site || x.site === M.site));
  const siteChips = ORDER_SITES.map(S => { const C = S.k === 'musinsa' ? null : ordCache[S.k]; const n = all.filter(x => x.site === S.k && !x.done && !x.cancel).length; return `<label class="chk chip"><input type="checkbox" data-k="ordSite" data-i="${S.k}"${M.sites.has(S.k) ? ' checked' : ''}> ${esc(S.label)}${n ? ` <b>${n}</b>` : ''}${C && C.msg ? ` <span class="small neg">${esc(C.msg)}</span>` : ''}${C && /로그인/.test(C.msg || '') ? ` <button type="button" class="linkbtn small" data-a="goAcct">로그인하기 ↗</button>` : ''}</label>`; }).join('');
  const val = (x, f) => (M.edit[x.key] || {})[f] ?? x[f];
  return `${head('구매처 주문 입고', '무신사·지그재그·쿠팡·G마켓·11번가·SSG·롯데ON·29CM·W컨셉·렉스몬드·나이키·SSF·ABC마트(그랜드스테이지 포함) 주문 내역을 불러와서 골라 입고해요. 이미 입고한 주문은 빠져요.')}${flash()}
  <div class="panel"><div class="chips">${siteChips}</div>
    <div class="row-btns"><select data-k="msDays">${[[30, '최근 1개월'], [90, '최근 3개월'], [180, '최근 6개월']].map(([v, t]) => opt(v, t, (M.days || 90) === v)).join('')}</select><button type="button" class="primary" data-a="msSync">고른 곳 주문 동기화</button><span class="hint">${esc(M.msg || '각 사이트에 크림스캐너 안에서 로그인돼 있어야(계정 연결 메뉴) 해요. 사이트마다 작은 창이 차례로 열렸다 닫혀요.')}</span></div>
    <p class="hint">사이트마다 화면이 달라서 상품명·옵션·가격을 화면 글자에서 읽어요. 매입가는 주문마다 <b>주문상세</b>를 열어 쿠폰·할인·적립금·카드 즉시할인까지 빠진 <b>실제 결제금액</b>으로 넣어요(한 주문에 상품이 여러 개면 목록 가격 비율로 나눠요). 처음 동기화는 주문 수만큼 시간이 더 걸리고, 한 번 읽은 주문은 기억해요.</p></div>
  <div class="panel"><h2>자동 입고</h2>
    <div class="row-btns"><label class="chk"><input type="checkbox" data-k="autoIn"${INV.opt.autoIn ? ' checked' : ''}> 동기화하면 바로 재고에 넣기</label>
      <label>자동 동기화<select data-k="autoHours">${[[0, '끔 (버튼 누를 때만)'], [1, '1시간마다'], [3, '3시간마다'], [6, '6시간마다'], [12, '12시간마다'], [24, '하루에 한 번']].map(([v, t]) => opt(v, t, +INV.opt.autoHours === v)).join('')}</select></label>
      ${INV.opt.lastOrdSync ? `<span class="hint">마지막 동기화 ${new Date(INV.opt.lastOrdSync).toLocaleString('ko-KR')}</span>` : ''}</div>
    <p class="hint">자동으로 넣는 건 <b>품번·사이즈·매입가를 다 읽은 주문</b>만이에요(쿠팡 생활용품처럼 사이즈가 없는 주문은 아래 표에 '확인 필요'로 남아요). 입고한 주문이 나중에 구매처에서 취소·반품되면, 아직 출고 안 한 수량은 재고에서 자동으로 빠져요(장부에 매입반품으로 기록). 자동 동기화는 위에서 체크한 구매처만, 최근 1개월 주문을 봐요. PC와 크림스캐너가 켜져 있어야 돌아가요(창을 닫아도 작업 표시줄 트레이에서 계속 돌아요).</p></div>
  <div class="panel"><div class="toolbar"><div class="row-btns"><label>구매처<select data-k="ms" data-f="site"><option value="">전체</option>${ORDER_SITES.map(S => opt(S.k, S.label, M.site === S.k)).join('')}</select></label>
     <label>결제수단<select data-k="ms" data-f="payId"><option value="">선택 안 함</option>${INV.pays.map(p => opt(p.id, p.name, p.id === M.payId)).join('')}</select></label>
     <label>분류 일괄<select data-k="ms" data-f="cat"><option value="">선택 안 함</option>${Object.entries(INV.cats).flatMap(([c, ss]) => [opt(c + '|', c, M.cat === c + '|'), ...ss.map(s => opt(c + '|' + s, `${c} · ${s}`, M.cat === c + '|' + s))]).join('')}</select></label>
     <label class="chk"><input type="checkbox" data-k="ordCancel"${M.showCancel ? ' checked' : ''}> 취소·반품도 보기</label></div>
     <div class="row-btns"><button type="button" class="ghost" data-a="msAll">전체 선택/해제</button><button type="button" class="primary" data-a="msSave">선택 ${view.filter(x => M.sel.has(x.key)).length}건 입고 등록</button></div></div>
   ${view.length ? `<div class="tbl"><table><thead><tr><th></th><th class="l">구매처</th><th class="l">주문일</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th>수량</th><th>매입가 (개당 실결제)</th><th class="l">상태</th></tr></thead><tbody>${view.map(x => `<tr class="${x.cancel ? 'err' : ''}"><td><input type="checkbox" data-k="msSel" data-i="${esc(x.key)}"${M.sel.has(x.key) ? ' checked' : ''}${x.cancel ? ' disabled' : ''}></td><td class="l"><span class="pill mute">${esc(siteLabel(x.site))}</span></td><td class="l">${esc(x.date)}</td><td class="l name"><b>${esc(x.name)}</b><span class="small">${esc(x.opt)}</span></td>
     <td class="l"><input class="mini" data-k="ordEdit" data-f="code" data-i="${esc(x.key)}" value="${esc(val(x, 'code'))}" placeholder="${esc(x.fallback)}"></td><td class="l"><input class="mini" style="width:80px" data-k="ordEdit" data-f="size" data-i="${esc(x.key)}" value="${esc(val(x, 'size'))}"></td><td>${x.qty}</td>
     <td><input class="cost-in" inputmode="numeric" data-k="ordEdit" data-f="unit" data-i="${esc(x.key)}" value="${esc(val(x, 'unit') || '')}">${x.paidOk && x.listUnit && x.listUnit !== x.unit ? `<span class="small" title="주문 목록에 보이던 가격">목록 <s>${won(x.listUnit)}</s></span>` : x.paidOk ? '<span class="small">결제금액 확인</span>' : x.needPaid ? '<span class="small neg">결제금액 확인 전</span>' : ''}</td><td class="l small">${esc(x.status)}</td></tr>`).join('')}</tbody></table></div>
   <p class="hint">품번 칸이 비면 임시코드(구매처-주문번호)로 들어가요. 나중에 상품 · 재고에서 고칠 수 있어요. 매입처는 구매처 이름으로 자동으로 잡혀요(없으면 기본정보에 새로 만들어요).</p>`
   : `<p class="empty">${all.length ? '입고할 주문이 없어요 (모두 입고했거나 취소·반품이에요).' : '아직 불러온 주문이 없어요. 위에서 구매처를 고르고 <b>주문 동기화</b>를 누르세요.'}</p>`}</div>
  ${ordDupWarn.length ? `<div class="panel"><p class="iflash neg"><b>같은 주문이 두 아이디 칸에 같이 보여요</b> — 두 칸에 같은 아이디로 로그인했을 수 있어요. 재고에는 한 번만 넣었어요: ${esc(ordDupWarn.slice(0, 6).join(' / '))}${ordDupWarn.length > 6 ? ` 외 ${ordDupWarn.length - 6}건` : ''}. 계정 연결에서 각 칸의 아이디를 확인해 주세요.</p></div>` : ''}
  <div class="panel"><h2>구매처별 확인 상태</h2><p class="hint">${ORDER_SITES.map(S => `${esc(S.label)}: ${esc(S.ok)}${ordCache[S.k] ? ` · ${new Date(ordCache[S.k].at).toLocaleString('ko-KR')} ${ordCache[S.k].rows.length}건` : ''}`).join(' / ')}</p>
    <p class="hint">'확인' = 실제 주문으로 읽기를 맞춰 봤어요. '빈 화면 확인' = 주문이 없어서 화면 주소만 확인했어요(첫 주문이 생기면 표를 한 번 봐 주세요). 에이블리는 웹에 주문 화면이 없어서(앱 전용), 페이코는 결제 내역만 있어서 연결하지 않았어요.</p></div>`;
}
// 자동 입고 기준: 품번과 사이즈를 읽었고 매입가가 있는 주문만 (생활용품처럼 사이즈가 없는 주문은 '확인 필요'로 남겨요)
const SIZE_OK = /^(\d{2,3}(\.5)?|[2-4]?X{0,3}[SML](\(\d{2,3}\))?|XS|XXL|XXXL|FREE|F|ONE ?SIZE|OS)$/i;
const autoOk = x => !!(SIZE_OK.test(String(x.size).trim()) && x.unit > 0 && !x.needPaid);   // 2.6.3: 품번을 못 읽어도 사이즈·실결제금액이 있으면 임시코드로 넣어요(나중에 고칠 수 있어요)   // 2.6.1: 주문상세 결제금액을 못 읽은 건 자동으로 안 넣어요
async function importRows(L, o) {
  o = o || {}; const M = IS.ms;
  const [cat, sub] = (o.cat || '|').split('|'); let n = 0, newItems = 0;
  for (const x of L) {
    const E = (M.edit || {})[x.key] || {};
    const code = String(E.code ?? x.code).trim() || x.fallback;
    let it = INV.items.find(i => codeKey(i.code) === codeKey(code));
    if (!it) { const nm = String(x.name || '').replace(/^\[[^\]]+\]\s*/, ''); const br = (String(x.name).match(/^\[([^\]]+)\]/) || [])[1] || nm.split(' ')[0]; it = { id: uid(), code, name: nm.replace(br, '').trim().replace(/\s*\/\s*[A-Z0-9-]+.*$/i, '').slice(0, 80), brand: br, cat: cat || '', sub: sub || '', sizes: [], barcodes: {}, memo: '', created: Date.now(), auto: 'order' }; INV.items.unshift(it); newItems++; if (br && !INV.brands.includes(br) && br.length < 20) INV.brands.push(br); }
    else if (cat && !it.cat) { it.cat = cat; it.sub = sub; }
    const size = String(E.size ?? x.size).trim() || 'FREE'; if (!it.sizes.includes(size)) it.sizes.push(size);
    const p = sitePartner(x.site);
    const date = x.date || today();
    INV.lots.push({ id: uid(), at: Date.now() + n, date, itemId: it.id, size, qty: +x.qty || 1, cost: num(E.unit ?? x.unit), partnerId: p.id, payId: o.payId || '', memo: `${siteLabel(x.site)} 주문${x.orderNo ? ' ' + x.orderNo : ''}${x.status ? ' · ' + x.status : ''}${o.auto ? ' · 자동 입고' : ''}`, ordNo: x.orderNo || '', ordId: x.ordId || x.orderNo || '', src: x.site === 'musinsa' ? 'musinsa' : 'order', srcKey: x.key, returnDue: addDays(date, p.returnDays != null ? p.returnDays : INV.opt.returnDays), confirmed: false, retQty: 0, exQty: 0, events: [] });
    n++;
  }
  await invSave();
  return { n, newItems };
}
// 입고한 뒤에 구매처에서 취소·반품된 주문은 재고에서 빼요(아직 출고 안 한 수량만)
function syncCancels() {
  const C = invCalc(); let n = 0, removed = 0;
  const cancelled = new Set([...ordRows().filter(x => x.cancel).map(x => x.key), ...(ordCache.cancelKeys || [])]);
  const drop = new Set();
  for (const l of INV.lots) {
    if (!l.srcKey || !cancelled.has(l.srcKey)) continue;
    const left = C.left.get(l.id) || 0, autoRet = (l.events || []).filter(e => e.auto === 'cancel').reduce((s, e) => s + (+e.q || 0), 0);
    const other = (l.events || []).some(e => e.auto !== 'cancel') || (l.exQty || 0) > 0 || (C.used.get(l.id) || 0) > 0;
    // 2.6.2: 아무것도 안 나간 취소 주문은 입고 자체를 지워요(재고·장부에서 완전히 빠짐)
    if (!other && left + autoRet === l.qty) { drop.add(l.id); removed += l.qty - autoRet; continue; }
    if (autoRet || !(left > 0)) continue;
    l.retQty = (l.retQty || 0) + left; (l.events = l.events || []).push({ t: '반품', d: today(), q: left, auto: 'cancel' }); n += left;
  }
  if (drop.size) {
    const gone = INV.lots.filter(l => drop.has(l.id));
    INV.lots = INV.lots.filter(l => !drop.has(l.id));
    // 그 주문 때문에 새로 만들어진 상품(다른 입고·출고가 없는 것)도 같이 지워요
    for (const l of gone) {
      const it = INV.items.find(i => i.id === l.itemId); if (!it) continue;
      if (INV.lots.some(x => x.itemId === it.id) || INV.outs.some(o => o.itemId === it.id)) continue;
      if (it.auto === 'order' || (!it.memo && Math.abs((it.created || 0) - (l.at || 0)) < 60000)) INV.items = INV.items.filter(i => i !== it);
    }
  }
  return n + removed;
}
// 2.6.1: 주문상세 화면을 열어 실제 결제금액을 읽고, 같은 주문(같은 상세 주소)의 상품들에 목록 가격 비율로 나눠요.
// 읽은 결과는 ordCache.paid[주소]에 기억(못 읽은 건 하루 뒤 다시). 한 번 동기화에 새로 여는 주문은 최대 40건.
const PAID_MAX = 40;
function paidSplit(g, P) {
  if (!P || !(P.paid > 0)) return false;
  const sum = g.reduce((s, x) => s + (+x.price || 0), 0); if (!sum) return false;
  const ratio = P.paid / sum;
  if (ratio < 0.15 || ratio > 1.6) { g.forEach(x => { x.paid = 0; x.paidWarn = `상세 ${P.paid}원 ↔ 목록 합계 ${sum}원이 너무 달라요`; }); return false; }
  let left = P.paid;
  g.forEach((x, i) => { const v = i === g.length - 1 ? left : Math.round((+x.price || 0) * ratio); x.paid = v; left -= v; x.paidFrom = P.label || ''; x.points = P.points || 0; });
  return true;
}
async function readPaid(url) {
  const pc = (ordCache.paid = ordCache.paid || {});
  const c = pc[url];
  if (c && (c.paid > 0 || Date.now() - c.at < 864e5)) return c;
  const t2 = await srcNav(url);
  const [r] = await execT({ target: { tabId: t2 }, func: kcOrderPaid }, 40000);
  const v = r && r.result;
  pc[url] = v && v.paid > 0 ? { paid: v.paid, goods: v.goods, points: v.points || 0, label: v.label, orderNo: v.orderNo || '', at: Date.now() } : { paid: 0, at: Date.now(), login: !!(v && v.loginNeeded) };
  return pc[url];
}
async function ordPaid(S, rows, M) {
  const groups = {}; rows.forEach(x => { if (x.detail) (groups[x.detail] = groups[x.detail] || []).push(x); });
  const pc = (ordCache.paid = ordCache.paid || {});
  let opened = 0, left = 0, i = 0; const urls = Object.keys(groups);
  for (const u of urls) {
    i++;
    const g = groups[u];
    if (g.every(x => ORD_SKIP.test(x.status))) continue;
    const cached = pc[u] && (pc[u].paid > 0 || Date.now() - pc[u].at < 864e5);
    if (!cached && opened >= PAID_MAX) { left++; continue; }
    if (!cached) { opened++; if (M) { M.msg = `${S.label} 주문상세에서 결제금액 읽는 중… (${i}/${urls.length})`; if (typeof jobSay === 'function') jobSay(M.msg); } }
    try { paidSplit(g, await readPaid(u)); } catch (e) {}
  }
  return { opened, left };
}
// 이미 입고한 주문인데 매입가가 목록 가격 그대로면(직접 고치지 않았으면) 실결제금액으로 바꿔요
function ordFixLots() {
  const by = new Map(ordRows().filter(x => x.paidOk).map(x => [x.key, x])); let n = 0;
  for (const l of INV.lots) {
    if (!l.srcKey || !(l.src === 'order' || l.src === 'musinsa')) continue;
    const x = by.get(l.srcKey); if (!x || !x.unit || l.cost === x.unit || l.paidFixed) continue;
    if (x.listUnit && Math.round(l.cost) !== Math.round(x.listUnit)) continue;   // 직접 고친 매입가는 그대로
    l.listCost = l.cost; l.cost = x.unit; l.paidFixed = true; l.memo = String(l.memo || '') + ' · 실결제금액 반영'; n++;
  }
  return n;
}
async function ordSync(o) {
  o = o || {};
  const M = IS.ms; M.sites = M.sites || new Set((INV.opt.ordSites || ORD_DEFAULT).filter(k => ORDER_SITES.some(S => S.k === k)));
  const sites = o.only ? ORDER_SITES.filter(S => o.only.includes(S.k)) : ORDER_SITES.filter(S => M.sites.has(S.k)), days = M.days || (o.quiet ? INV.opt.ordDays || 30 : 90);
  const from = addDays(today(), -days);
  // 3.4.2: 읽기 전에 로그인부터 확인해요. 풀린 곳은 저장한 계정으로 먼저 다시 로그인 (프로그램에서는 여러 곳을 동시에 빠르게 확인)
  if (typeof acctFast === 'function' && acctFast() && typeof acctCheck === 'function') {
    M.msg = '로그인 상태 확인 중…'; if (typeof jobSay === 'function') jobSay(M.msg); if (!o.quiet) renderInv();
    const ks = sites.map(S => S.k).filter(k => acctOf(k) && acctOf(k).check);
    const st = await Promise.all(ks.map(k => acctCheck(k).catch(() => null)));
    for (let i = 0; i < ks.length; i++) {
      if (!(st[i] && st[i].needLogin) || !acctCanAuto(ks[i])) continue;
      M.msg = `${acctOf(ks[i]).label} 로그인이 풀려서 다시 로그인하는 중…`; if (typeof jobSay === 'function') jobSay(M.msg); if (!o.quiet) renderInv();
      try { await acctEnsure(ks[i], true); } catch (e) {}
    }
  }
  try { for (const S of sites) {
    navPart = S.part || '';
    M.msg = `${S.label} 주문 읽는 중…`; if (typeof jobSay === 'function') jobSay(M.msg); if (!o.quiet) renderInv();
    try {
      if (S.k === 'musinsa') {
        const before = records.length; let ok = true;
        await importMusinsaOrders(days);
        if (/로그인/.test(($('#impMsg') || {}).textContent || '')) ok = false;
        // 2.7: 무신사 로그인이 풀렸으면 저장된 계정으로 다시 로그인하고 한 번 더
        if (!ok && typeof acctEnsure === 'function') { M.msg = '무신사 로그인이 풀려서 다시 로그인하는 중…'; if (!o.quiet) renderInv(); if (await acctEnsure('musinsa', o.quiet)) await importMusinsaOrders(days); }
        if (typeof acctSetState === 'function') await acctSetState('musinsa', /로그인/.test(($('#impMsg') || {}).textContent || '') ? 'off' : 'on');
        continue;
      }
      const readSite = async () => {
        let tabId = await srcNav(S.url);
        await sleep(1200);
        if (S.mustPath) { const t = await chrome.tabs.get(tabId).catch(() => null); try { if (t && !new URL(t.url).pathname.startsWith(S.mustPath)) return { rows: [], loginNeeded: true }; } catch (e) {} }
        // 2.6.1: '주문상세' 주소를 먼저 표시해 둬요 (지그재그처럼 누르면 새 창이 뜨는 곳은 새 창을 막고 주소만 받아요)
        try { const [t] = await execT({ target: { tabId }, func: kcTagDetails, args: [S.dtpl || '', 4], world: 'MAIN' }, 60000); if (t && t.result && t.result.moved) { tabId = await srcNav(S.url); await sleep(1200); } } catch (e) {}
        const [r] = await execT({ target: { tabId }, func: kcOrders, args: [{ scroll: 4 }] });
        return r && r.result;
      };
      let res = await readSite();
      // 2.7: 로그인이 풀려 있으면 계정 연결에 저장한 아이디로 다시 로그인하고 한 번 더 읽어요
      if (res && res.loginNeeded && !(res.rows || []).length && typeof acctEnsure === 'function' && acctCanAuto(S.k)) {
        M.msg = `${S.label} 로그인이 풀려서 다시 로그인하는 중…`; if (!o.quiet) renderInv();
        if (await acctEnsure(S.k, o.quiet)) res = await readSite();
      }
      if (res && typeof acctSetState === 'function') await acctSetState(S.k, res.loginNeeded && !(res.rows || []).length ? 'off' : 'on');
      if (!res) throw new Error('못 읽었어요');
      const rows = (res.rows || []).filter(x => !x.date || x.date >= from);
      // 주문 목록에 품번이 없는 곳(ABC마트 등)은 상품 화면을 열어 스타일코드를 읽어요 (한 번 읽은 건 기억)
      if (S.detail) {
        const map = (ordCache.codes = ordCache.codes || {});
        for (const x of rows.filter(x => !ordCode(x.name)).slice(0, 15)) {
          const id = (String(x.url).match(/goProductDetail\('(\d+)'/) || String(x.url).match(/prdtNo=(\d+)/) || [])[1]; if (!id) continue;
          if (!map[S.k + id]) { try { const t2 = await srcNav(S.detail(id)); const [c] = await execT({ target: { tabId: t2 }, func: kcArtCode }); map[S.k + id] = (c && c.result && c.result.code) || '-'; } catch (e) {} }
          if (map[S.k + id] && map[S.k + id] !== '-') x.code = map[S.k + id];
        }
      }
      const pd = await ordPaid(S, rows, M);
      ordCache[S.k] = { at: Date.now(), rows, msg: res.loginNeeded && !rows.length ? '로그인 필요' : res.empty ? '' : !rows.length ? '못 읽음' : pd.left ? `결제금액 ${pd.left}건 남음(다음 동기화 때 이어서)` : '' };
    } catch (e) { ordCache[S.k] = { at: Date.now(), rows: (ordCache[S.k] || {}).rows || [], msg: '실패: ' + e.message }; }
    await store.set('ordCache', ordCache);
  } } finally { navPart = ''; }
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  const fixed = ordFixLots();
  const back = syncCancels();
  let rows = ordRows().filter(x => !x.done && !x.cancel), auto = { n: 0, newItems: 0 };
  if (INV.opt.autoIn || o.auto) { const ok = rows.filter(autoOk); if (ok.length) auto = await importRows(ok, { payId: M.payId, cat: M.cat, auto: true }); rows = ordRows().filter(x => !x.done && !x.cancel); }
  if (back || fixed) await invSave();
  rows.forEach(x => M.sel.add(x.key));
  const lost = typeof acctState !== 'undefined' ? sites.filter(S => acctState[S.k] && acctState[S.k].st === 'off').map(S => S.label) : [];
  M.msg = `${lost.length ? `⚠ 로그인 필요: ${lost.join(', ')} (계정 연결에서 '직접 로그인' 한 번 해 주세요) · ` : ''}동기화 끝 — ${auto.n ? `자동 입고 ${auto.n}건${auto.newItems ? `(새 상품 ${auto.newItems}종)` : ''} · ` : ''}${fixed ? `이미 입고한 ${fixed}건 매입가를 실결제금액으로 고침 · ` : ''}${back ? `취소·반품된 주문 ${back}개 재고에서 뺌 · ` : ''}${INV.opt.autoIn || o.auto ? '확인 필요' : '입고 안 한 주문'} ${rows.length}건`;
  INV.opt.lastOrdSync = Date.now(); await invSave();
  if (!o.quiet) renderInv();
  return { auto: auto.n, back, left: rows.length };
}
async function msSave() {
  const M = IS.ms, L = ordRows().filter(x => !x.done && !x.cancel && M.sel.has(x.key));
  if (!L.length) { IS.msg = '입고할 주문을 골라 주세요'; return renderInv(); }
  const r = await importRows(L, { payId: M.payId, cat: M.cat });
  M.sel.clear(); IS.msg = `주문 ${r.n}건 입고했어요${r.newItems ? ` (새 상품 ${r.newItems}종)` : ''}`;
  renderInv();
}
async function setOrderAlarm() {
  if (!HAS_CHROME || !chrome.alarms) return;
  await chrome.alarms.clear('ks-orders');
  if (+INV.opt.autoHours > 0) chrome.alarms.create('ks-orders', { periodInMinutes: +INV.opt.autoHours * 60, delayInMinutes: +INV.opt.autoHours * 60 });
}

// ---------- 우선출고 정산 ----------
function vPre() {
  const P = IS.pre;
  const list = INV.outs.filter(o => o.kind === 'pre' && !o.settled).sort((a, b) => a.date.localeCompare(b.date));
  const q = list.reduce((s, o) => s + o.qty, 0), cost = list.reduce((s, o) => s + outNums(o).cogs, 0);
  const matchTbl = (M, kind) => M && M.rows.length ? `<div class="tbl"><table><thead><tr><th class="l">${kind} 줄</th><th class="l">품번</th><th class="l">사이즈</th><th>판매가</th><th class="l">맞춘 우선출고</th></tr></thead><tbody>${M.rows.map((r, i) => `<tr><td class="l small">${i + 1}</td><td class="l">${esc(r.code)}</td><td class="l">${esc(r.size)}</td><td>${won(r.price)}</td><td class="l">${r.outId ? `<span class="pill ok">맞춤</span> ${esc(itName(itemOf(INV.outs.find(o => o.id === r.outId)?.itemId)))} · ${esc(INV.outs.find(o => o.id === r.outId)?.date || '')}` : `<span class="pill bad">못 찾음</span>${kind === '포이즌' ? ` <select data-k="pzLink" data-c="${esc(r.code)}"><option value="">상품 연결 (다음부터 자동)</option>${INV.items.map(it => opt(it.id, `${it.code} ${itName(it)}`)).join('')}</select>` : ''}`}</td></tr>`).join('')}</tbody></table></div><div class="row-btns"><button type="button" class="primary" data-a="${kind === '크림' ? 'kreamApply' : 'pzApply'}"${M.rows.some(r => r.outId) ? '' : ' disabled'}>맞춘 ${M.rows.filter(r => r.outId).length}건 정산 완료</button></div>` : '';
  return `${head('우선출고 정산', '먼저 내보내고 판매가가 나중에 정해진 출고를 정산해요. 판매가를 넣으면 수수료·마진이 계산돼요.')}${flash()}
  <div class="kgrid k3">${card('정산 대기', list.length + '건', list.length ? 'warn' : '')}${card('수량', q + '개')}${card('매입 원가 합계', won(cost))}</div>
  <div class="panel"><div class="toolbar"><h2>정산 대기 목록</h2><div class="row-btns"><input type="date" data-k="preDate" value="${esc(P.date || today())}" title="정산일"><button type="button" class="primary" data-a="preSettle">선택 ${[...P.sel].filter(id => list.some(o => o.id === id)).length}건 정산</button></div></div>
    <div class="tbl"><table><thead><tr><th><input type="checkbox" data-k="preAll" aria-label="전체 선택"></th><th class="l">출고일</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>매입 원가 (개당)</th><th class="l">매출처</th><th>판매가 (개당)</th><th>예상 마진</th><th></th></tr></thead><tbody>${list.map(o => { const n = outNums(o); const pr = num(P.price[o.id]); const fee = partnerFee(partnerOf(o.partnerId), pr); const mg = pr ? (pr - fee) * o.qty - n.cogs - n.ship : null; return `<tr><td><input type="checkbox" data-k="preSel" data-i="${o.id}"${P.sel.has(o.id) ? ' checked' : ''}></td><td class="l">${o.date}${dday(o.date) <= -14 ? ' <span class="pill warn">2주+</span>' : ''}</td><td class="l name"><b>${esc(itName(itemOf(o.itemId)))}</b><span class="code">${esc(itemOf(o.itemId)?.code || '')}</span></td><td class="l">${esc(o.size)}</td><td>${o.qty}</td><td>${won(n.unitCost)}</td><td class="l">${esc(partnerOf(o.partnerId)?.name || '')}</td><td><input inputmode="numeric" class="cost-in" data-k="prePrice" data-i="${o.id}" value="${esc(P.price[o.id] || '')}"></td><td data-mg="${o.id}" class="${mg > 0 ? 'pos' : mg < 0 ? 'neg' : ''}">${mg == null ? '–' : wonS(mg)}</td><td><button type="button" class="ghost tiny" data-a="preOne" data-id="${o.id}">정산</button></td></tr>`; }).join('') || '<tr><td colspan="10" class="empty">정산 대기 중인 우선출고가 없어요</td></tr>'}</tbody></table></div></div>
  <div class="igrid2"><div class="panel"><h2>크림 대량 정산</h2><p class="hint">크림 판매내역을 엑셀에서 복사해 붙여넣거나 한 줄에 하나씩 <b>품번 사이즈 판매가</b>로 적어요. 품번·사이즈가 같은 우선출고 중 오래된 것부터 맞춰요.</p>
      <textarea data-k="kreamText" rows="5" placeholder="DD1391-100  270  139000&#10;MR530KA	260	99,000">${esc(P.kreamText || '')}</textarea><div class="row-btns"><button type="button" class="ghost" data-a="kreamMatch">맞춰 보기</button></div>${matchTbl(P.kream, '크림')}</div>
    <div class="panel"><h2>포이즌 정산</h2><p class="hint">포이즌 판매자센터에서 받은 엑셀을 올려요. 품번이 다르게 적힌 상품은 한 번 연결해 두면 다음부터 자동으로 맞춰요.</p>
      <label class="drop small-drop"><input type="file" accept=".xlsx,.xlsm,.csv" data-k="pzFile" hidden><b>포이즌 엑셀 올리기</b>${P.pzFile ? `<span class="small">${esc(P.pzFile)}</span>` : ''}</label>${P.pzMsg ? `<p class="hint neg">${esc(P.pzMsg)}</p>` : ''}${matchTbl(P.poizon, '포이즌')}</div></div>`;
}
function parseSaleLines(text) {
  const out = [];
  for (const line of String(text || '').split(/\n/)) {
    const t = line.trim(); if (!t) continue;
    const parts = t.split(/\t|\s{2,}|,(?=\s)|\s+/).map(s => s.trim()).filter(Boolean);
    const nums = parts.map(s => num(s)).filter((n, i) => /^[\d,]+원?$/.test(parts[i]) && n >= 1000);
    const price = nums.length ? nums[nums.length - 1] : 0;
    const code = parts.find(s => /[A-Za-z]/.test(s) && /\d/.test(s) && s.length >= 4) || '';
    const size = parts.find(s => s !== code && !(/^[\d,]+원?$/.test(s) && num(s) >= 1000) && /^(\d{2,3}(\.5)?|[XSML]{1,4}|XXL|FREE|\d?XL)$/i.test(s)) || '';
    if (code && price) out.push({ code, size, price });
  }
  return out;
}
function matchPre(rows, prefer) {
  const used = new Set();
  for (const r of rows) {
    const itemIds = new Set(INV.items.filter(it => codeKey(it.code) === codeKey(r.code)).map(it => it.id));
    if (r.itemId) itemIds.add(r.itemId);
    const cand = INV.outs.filter(o => o.kind === 'pre' && !o.settled && !used.has(o.id) && itemIds.has(o.itemId) && (!r.size || String(o.size).toUpperCase() === String(r.size).toUpperCase()))
      .sort((a, b) => ((partnerOf(b.partnerId)?.name === prefer) - (partnerOf(a.partnerId)?.name === prefer)) || a.date.localeCompare(b.date));
    r.outId = cand[0] ? cand[0].id : '';
    if (r.outId) used.add(r.outId);
  }
  return rows;
}
async function settleOuts(pairs, date) {
  let n = 0;
  for (const [id, price] of pairs) { const o = INV.outs.find(x => x.id === id); if (!o || o.settled || !price) continue; o.price = price; o.settled = true; o.settleDate = date || today(); n++; }
  await invSave(); return n;
}
async function pzLoad(file) {
  const P = IS.pre; P.pzFile = file.name; P.pzMsg = '';
  try {
    const rows = await XL.readFile(file);
    const hi = rows.findIndex(r => r.some(v => /货号|품번|article|style|모델|sku/i.test(String(v))) && r.some(v => /尺码|사이즈|size|규격/i.test(String(v))));
    if (hi < 0) throw new Error('품번·사이즈 칸을 못 찾았어요');
    const H = rows[hi].map(v => String(v));
    const ci = re => H.findIndex(h => re.test(h));
    const cCode = ci(/货号|품번|article|style|모델|sku/i), cSize = ci(/尺码|사이즈|size|규격/i), cPrice = ci(/정산|결제|실수령|settle|结算|금액|price|가격/i);
    const out = [];
    for (const r of rows.slice(hi + 1)) {
      const raw = String(r[cCode] || '').trim(); if (!raw) continue;
      const mapped = INV.poizonMap[codeKey(raw)];
      out.push({ code: raw, size: String(r[cSize] ?? '').replace(/\s*(KR|EU|US|mm)$/i, '').trim(), price: num(r[cPrice]), itemId: mapped || '' });
    }
    P.poizon = { rows: matchPre(out.filter(r => r.price), '포이즌') };
    if (!P.poizon.rows.length) P.pzMsg = '금액이 있는 줄이 없어요';
  } catch (e) { P.pzMsg = e.message; P.poizon = null; }
  renderInv();
}

// ---------- 반품 · 교환 ----------
function vRet(C) {
  const T = IS.ret;
  let body = '';
  if (T === 'buy') {
    const L = INV.lots.filter(l => !l.confirmed && C.left.get(l.id) > 0 && !['return'].includes(l.src)).sort((a, b) => (a.returnDue || '9').localeCompare(b.returnDue || '9'));
    body = `<div class="toolbar"><p class="hint">매입한 상품을 반품하거나 사이즈를 교환해요. 구매확정하면 목록에서 빠져요.</p><button type="button" class="ghost" data-a="retConfirmSoon">마감 임박(D-2 이내·지남) 일괄 확정</button></div>
    <div class="tbl"><table><thead><tr><th class="l">반품 기한</th><th class="l">입고일</th><th class="l">상품</th><th class="l">사이즈</th><th>남은 수량</th><th>매입가</th><th class="l">매입처</th><th></th></tr></thead><tbody>${L.map(l => { const d = l.returnDue ? dday(l.returnDue) : null; const cls = d == null ? 'mute' : d < 0 ? 'mute' : d <= 2 ? 'bad' : d <= 5 ? 'warn' : 'ok'; return `<tr><td class="l"><span class="pill ${cls}">${d == null ? '없음' : d < 0 ? '지남' : 'D-' + d}</span> <span class="small">${esc(l.returnDue || '')}</span></td><td class="l">${l.date}</td><td class="l name"><b>${esc(itName(itemOf(l.itemId)))}</b></td><td class="l">${esc(l.size)}</td><td>${C.left.get(l.id)}</td><td>${won(l.cost)}</td><td class="l">${esc(partnerOf(l.partnerId)?.name || '')}</td><td><div class="act"><button type="button" class="ghost" data-a="lotRet" data-id="${l.id}">반품</button><button type="button" class="ghost" data-a="lotEx" data-id="${l.id}">교환</button><button type="button" class="ghost" data-a="lotOk" data-id="${l.id}">확정</button></div></td></tr>`; }).join('') || '<tr><td colspan="8" class="empty">반품·교환할 매입이 없어요</td></tr>'}</tbody></table></div>`;
  } else {
    const L = INV.outs.filter(o => o.settled && !o.confirmed && o.qty - (o.retQty || 0) > 0).sort((a, b) => b.settleDate.localeCompare(a.settleDate));
    body = `<p class="hint">판매한 상품이 반품되면 재고로 돌아와요. 판매 후 가격을 깎아 준 경우 '할인'으로 넣어요. 판매확정하면 목록에서 빠져요.</p>
    <div class="tbl"><table><thead><tr><th class="l">정산일</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>판매가</th><th>마진</th><th class="l">매출처</th><th></th></tr></thead><tbody>${L.map(o => { const n = outNums(o); return `<tr><td class="l">${o.settleDate}</td><td class="l name"><b>${esc(itName(itemOf(o.itemId)))}</b></td><td class="l">${esc(o.size)}</td><td>${n.net}${o.retQty ? ` <span class="small">(반품 ${o.retQty})</span>` : ''}</td><td>${won(o.price)}${o.disc ? `<div class="small">할인 −${won(o.disc)}</div>` : ''}</td><td class="${n.margin >= 0 ? 'pos' : 'neg'}">${wonS(n.margin)}</td><td class="l">${esc(partnerOf(o.partnerId)?.name || '')}</td><td><div class="act"><button type="button" class="ghost" data-a="outRet" data-id="${o.id}">반품</button><button type="button" class="ghost" data-a="outDisc" data-id="${o.id}">할인</button><button type="button" class="ghost" data-a="outOk" data-id="${o.id}">확정</button></div></td></tr>`; }).join('') || '<tr><td colspan="8" class="empty">판매 반품·할인 처리할 건이 없어요</td></tr>'}</tbody></table></div>`;
  }
  return `${head('반품 · 교환', `반품 기한이 가까우면 색이 바뀌어요: 빨강 2일 이하 · 주황 5일 이하 · 초록 6일 이상`)}${flash()}
  <div class="subtabs"><button type="button" data-a="retTab" data-v="buy" aria-selected="${T === 'buy'}">매입 반품 · 교환</button><button type="button" data-a="retTab" data-v="sell" aria-selected="${T === 'sell'}">판매 반품 · 할인</button></div>${body}`;
}

// ---------- 장부 · 정산 ----------
function ledgerRows() {
  const R = [];
  const nm = (id, sz, q) => `${itName(itemOf(id))} ${sz} ×${q}`;
  for (const l of INV.lots) {
    if (l.src === 'exchange' || l.src === 'return' || l.src === 'adjust') continue;
    const p = partnerOf(l.partnerId), pay = payOf(l.payId);
    R.push({ date: l.date, kind: '매입', desc: nm(l.itemId, l.size, l.qty), partner: p?.name || '', partnerId: l.partnerId, pay: pay?.name || '', payId: l.payId || '', amount: -l.cost * l.qty, memo: l.memo || '', vatIn: p && p.tax === '과세' && !(pay && pay.proof === false) ? l.cost * l.qty : 0 });
    for (const e of l.events || []) if (e.t === '반품') R.push({ date: e.d, kind: '매입반품', desc: nm(l.itemId, l.size, e.q), partner: p?.name || '', partnerId: l.partnerId, pay: pay?.name || '', payId: l.payId || '', amount: l.cost * e.q, memo: '', vatIn: p && p.tax === '과세' && !(pay && pay.proof === false) ? -l.cost * e.q : 0 });
  }
  for (const o of INV.outs) {
    if (!o.settled) continue;
    const p = partnerOf(o.partnerId); const fee = o.fee !== '' && o.fee != null ? +o.fee : partnerFee(p, o.price);
    const base = { partner: p?.name || '', partnerId: o.partnerId, pay: '', payId: '', memo: o.memo || '' };
    R.push({ ...base, date: o.settleDate, kind: '매출', desc: nm(o.itemId, o.size, o.qty), amount: o.price * o.qty, vatOut: p && p.tax === '과세' ? o.price * o.qty : 0 });
    if (fee) R.push({ ...base, date: o.settleDate, kind: '수수료', desc: nm(o.itemId, o.size, o.qty), amount: -fee * o.qty, vatIn: fee * o.qty });
    if (+o.ship) R.push({ ...base, date: o.date, kind: '택배비', desc: nm(o.itemId, o.size, o.qty), amount: -o.ship });
    for (const e of o.events || []) {
      if (e.t === '반품') { R.push({ ...base, date: e.d, kind: '매출반품', desc: nm(o.itemId, o.size, e.q), amount: -e.total, vatOut: p && p.tax === '과세' ? -e.gross : 0 }); if (e.feeBack) R.push({ ...base, date: e.d, kind: '수수료', desc: '반품 수수료 환급', amount: e.feeBack, vatIn: -e.feeBack }); }
      if (e.t === '할인') R.push({ ...base, date: e.d, kind: '할인', desc: nm(o.itemId, o.size, e.q), amount: -e.total, vatOut: p && p.tax === '과세' ? -e.total : 0, memo: e.memo || '' });
    }
  }
  for (const m of INV.ledger) R.push({ date: m.date, kind: m.io === 'in' ? '수기 수입' : '수기 지출', desc: m.desc, partner: m.partner || '', partnerId: '', pay: payOf(m.payId)?.name || '', payId: m.payId || '', amount: m.io === 'in' ? +m.amount : -m.amount, memo: m.memo || '', id: m.id, vatIn: m.io === 'out' && m.vat ? +m.amount : 0, vatOut: m.io === 'in' && m.vat ? +m.amount : 0 });
  return R.sort((a, b) => b.date.localeCompare(a.date));
}
function vLedger() {
  const F = IS.lg; if (!F.from) { F.from = monthStart(); F.to = monthEnd(); }
  const all = ledgerRows().filter(r => inRange(r.date, F.from, F.to));
  const rows = all.filter(r => (!F.kind || r.kind.startsWith(F.kind)) && (!F.partner || r.partner === F.partner) && (!F.pay || r.payId === F.pay));
  let margin = 0;
  for (const o of INV.outs) if (o.settled && inRange(o.settleDate, F.from, F.to)) margin += outNums(o).margin;
  const cash = all.filter(r => !r.kind.startsWith('수기') && r.kind !== '택배비').reduce((s, r) => s + r.amount, 0);
  const extra = all.filter(r => r.kind.startsWith('수기') || r.kind === '택배비').reduce((s, r) => s + r.amount, 0);
  const pages = Math.max(1, Math.ceil(rows.length / F.size)); if (F.page >= pages) F.page = pages - 1;
  const view = rows.slice(F.page * F.size, F.page * F.size + F.size);
  const y = +today().slice(0, 4);
  const kinds = ['매출', '매입', '수수료', '택배비', '매출반품', '매입반품', '할인', '수기'];
  return `${head('장부 · 정산', '매출·매입·수수료·택배비·반품이 자동으로 들어오고, 그 밖의 돈은 수기로 넣어요.', `<button type="button" class="primary" data-a="manual">수기 입력</button><button type="button" class="ghost" data-a="ledgerXl">엑셀 다운로드</button>`)}${flash()}
  <div class="filters"><select data-k="lgQuick"><option value="">기간 빠른 선택</option>${[0, 1, 2].map(i => { const d = new Date(today().slice(0, 7) + '-01T00:00:00'); d.setMonth(d.getMonth() - i); const s = fmtD(d); return opt('m' + s, `${s.slice(0, 4)}년 ${+s.slice(5, 7)}월`); }).join('')}${[y, y - 1].map(v => opt('y' + v, `${v}년 전체`)).join('')}</select>
    <input type="date" data-k="lg" data-f="from" value="${F.from}"><span class="hint">~</span><input type="date" data-k="lg" data-f="to" value="${F.to}">
    <select data-k="lg" data-f="kind"><option value="">구분 전체</option>${kinds.map(k => opt(k, k, F.kind === k)).join('')}</select>
    <select data-k="lg" data-f="partner"><option value="">거래처 전체</option>${[...new Set(all.map(r => r.partner).filter(Boolean))].map(p => opt(p, p, F.partner === p)).join('')}</select>
    <select data-k="lg" data-f="pay"><option value="">결제수단 전체</option>${INV.pays.map(p => opt(p.id, p.name, F.pay === p.id)).join('')}</select></div>
  <div class="kgrid k3">${card('판매 마진', wonS(margin), margin >= 0 ? 'pos' : 'neg', '판매 − 수수료 − 매입원가 − 택배비 (정산일 기준)')}${card('현금 흐름', wonS(cash), cash >= 0 ? 'pos' : 'neg', '실제 정산 받은 돈 − 실제 매입한 돈 (반품 포함)')}${card('부대비용', wonS(extra), extra >= 0 ? 'pos' : 'neg', '수기 수입·지출 + 택배비')}</div>
  <div class="tbl"><table><thead><tr><th class="l">날짜</th><th class="l">구분</th><th class="l">내용</th><th class="l">거래처</th><th class="l">결제수단</th><th>금액</th><th class="l">메모</th><th></th></tr></thead><tbody>${view.map(r => `<tr><td class="l">${r.date}</td><td class="l"><span class="pill ${r.amount >= 0 ? 'ok' : 'mute'}">${r.kind}</span></td><td class="l">${esc(r.desc)}</td><td class="l">${esc(r.partner)}</td><td class="l">${esc(r.pay)}</td><td class="${r.amount >= 0 ? 'pos' : 'neg'}"><b>${r.amount >= 0 ? '+' : ''}${wonS(r.amount)}</b></td><td class="l small">${esc(r.memo)}</td><td>${r.id ? `<button type="button" class="ghost tiny" data-a="manualDel" data-id="${r.id}">삭제</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">이 기간에 기록이 없어요</td></tr>'}</tbody></table></div>
  <div class="toolbar"><span class="hint">${rows.length}건 · 합계 ${wonS(rows.reduce((s, r) => s + r.amount, 0))}</span><div class="row-btns"><select data-k="lgSize">${[10, 50, 100].map(n => opt(n, n + '개씩', F.size === n)).join('')}</select><button type="button" class="ghost" data-a="lgPage" data-v="-1"${F.page ? '' : ' disabled'}>이전</button><span class="hint">${F.page + 1} / ${pages}</span><button type="button" class="ghost" data-a="lgPage" data-v="1"${F.page + 1 < pages ? '' : ' disabled'}>다음</button></div></div>`;
}

// ---------- 부가세 예상 ----------
function vVat() {
  const V = IS.vat; const t = today();
  if (!V.year) { V.year = +t.slice(0, 4); V.half = +t.slice(5, 7) <= 6 ? 1 : 2; }
  const R = ledgerRows(); const months = [];
  for (let m = (V.half === 1 ? 1 : 7); m < (V.half === 1 ? 7 : 13); m++) {
    const k = `${V.year}-${String(m).padStart(2, '0')}`;
    const rs = R.filter(r => r.date.startsWith(k));
    const outT = rs.reduce((s, r) => s + (r.vatOut || 0), 0) / 11, inT = rs.reduce((s, r) => s + (r.vatIn || 0), 0) / 11;
    months.push({ m, outT: Math.round(outT), inT: Math.round(inT) });
  }
  const so = months.reduce((s, x) => s + x.outT, 0), si = months.reduce((s, x) => s + x.inT, 0), diff = so - si;
  const mx = Math.max(1, ...months.flatMap(x => [x.outT, x.inT]));
  return `${head('부가세 예상', '반기마다 매출세액(판매할 때 받은 부가세)과 매입세액(사거나 수수료 낼 때 낸 부가세)을 비교해요. 일반과세자 기준이에요.')}${flash()}
  <div class="filters"><select data-k="vatYear">${[+t.slice(0, 4), +t.slice(0, 4) - 1, +t.slice(0, 4) - 2].map(y => opt(y, y + '년', V.year === y)).join('')}</select><select data-k="vatHalf">${opt(1, '상반기 (1~6월)', V.half === 1)}${opt(2, '하반기 (7~12월)', V.half === 2)}</select></div>
  <div class="kgrid k3">${card('매출세액', won(so), '', '과세 매출처 판매금액 ÷ 11')}${card('매입세액', won(si), '', '과세 매입처 매입 + 수수료 + 증빙 있는 수기 지출 ÷ 11')}${card(diff >= 0 ? '납부 예상' : '환급 예상', won(Math.abs(diff)), diff >= 0 ? 'neg' : 'pos', diff >= 0 ? '매출세액이 더 많아요' : '매입세액이 더 많아서 돌려받아요')}</div>
  <div class="mgrid">${months.map(x => `<div class="box"><h3>${x.m}월</h3><div class="vbar"><span style="width:${x.outT / mx * 100}%" class="vo"></span></div><div class="small">매출세액 ${won(x.outT)}</div><div class="vbar"><span style="width:${x.inT / mx * 100}%" class="vi"></span></div><div class="small">매입세액 ${won(x.inT)}</div>${x.outT || x.inT ? `<b class="${x.outT - x.inT > 0 ? 'neg' : 'pos'}">${x.outT - x.inT > 0 ? '납부' : '환급'} ${won(Math.abs(x.outT - x.inT))}</b>` : '<b class="small">기록 없음</b>'}</div>`).join('')}</div>
  <p class="hint">포이즌처럼 '영세'로 둔 매출처(수출)는 매출세액이 0원이라 매입세액만큼 환급에 유리해요. 결제수단을 '부가세 증빙 없음'으로 둔 매입은 매입세액에서 빠져요. 여기 금액은 참고용 추정치라 실제 신고는 세무사와 확인하세요.</p>`;
}

// ---------- 백업 · 초기화 ----------
function vReset() {
  return `${head('백업 · 초기화', '재고관리 데이터는 이 PC 크림스캐너에만 저장돼요. 정기적으로 백업 파일을 받아 두세요.')}${flash()}
  <div class="igrid2"><div class="panel"><h2>백업</h2><p class="hint">상품·재고·입출고·장부·기본정보 전부를 파일 하나로 받아요. 다른 PC에서 '백업 불러오기'로 그대로 옮길 수 있어요.</p>
      <div class="row-btns"><button type="button" class="primary" data-a="backup">백업 파일 받기</button><label class="ghost filebtn">백업 불러오기<input type="file" accept=".json" data-k="restore" hidden></label></div></div>
    <div class="panel"><h2>데이터 초기화</h2><p class="hint neg">되돌릴 수 없어요. 먼저 백업 파일을 받아 두세요.</p>
      <label class="chk"><input type="radio" name="rs" value="all" data-k="rsKind"${IS.rs === 'all' ? ' checked' : ''}> 상품 + 재고 전체 삭제 <span class="small">(기본정보는 남아요)</span></label>
      <label class="chk"><input type="radio" name="rs" value="stock" data-k="rsKind"${IS.rs === 'stock' ? ' checked' : ''}> 재고만 삭제 <span class="small">(상품은 남기고 입출고·장부 기록 삭제 — 새 시즌 시작할 때)</span></label>
      <label class="chk"><input type="radio" name="rs" value="base" data-k="rsKind"${IS.rs === 'base' ? ' checked' : ''}> 기본정보만 처음 상태로</label>
      <label>확인 문구 입력 — <b>${{ all: '전체삭제', stock: '재고삭제', base: '삭제' }[IS.rs || 'all']}</b><input data-k="rsText" autocomplete="off"></label>
      <div class="row-btns"><button type="button" class="primary danger" data-a="resetRun">삭제 실행</button></div></div></div>`;
}

// ---------- 대화창 ----------
function invDialog(title, bodyHTML, onOk, okLabel = '저장') {
  const d = $('#invDlg');
  d.innerHTML = `<form method="dialog" class="dlg"><h3>${esc(title)}</h3><div class="dlg-body">${bodyHTML}</div><p class="hint neg dlg-msg"></p><div class="row-btns end"><button value="cancel" class="ghost" formnovalidate>취소</button><button value="ok" class="primary">${esc(okLabel)}</button></div></form>`;
  const f = d.querySelector('form');
  f.addEventListener('submit', async e => {
    if (e.submitter && e.submitter.value === 'cancel') return;
    e.preventDefault();
    const err = await onOk(Object.fromEntries(new FormData(f)), f);
    if (err) { f.querySelector('.dlg-msg').textContent = err; return; }
    d.close();
  });
  d.showModal();
  const first = f.querySelector('input:not([readonly]),select'); if (first) first.focus();
}
function partnerDialog(p) {
  const P = p || { kind: 'buy', name: '', biz: '', tax: '과세', feeMode: 'custom', feeRate: 0, feeFix: 0, vat: '포함', returnDays: INV.opt.returnDays };
  invDialog(p ? '거래처 수정' : '거래처 추가', `<div class="dgrid">
    <label>구분${p ? ' (등록 후 못 바꿔요)' : ''}<select name="kind"${p ? ' disabled' : ''}>${opt('buy', '매입처 (사 오는 곳)', P.kind === 'buy')}${opt('sell', '매출처 (파는 곳)', P.kind === 'sell')}</select></label>
    <label>거래처명 *<input name="name" required value="${esc(P.name)}"></label>
    <label>상호 (사업자 이름)<input name="biz" value="${esc(P.biz || '')}"></label>
    <label>과세 구분<select name="tax">${['과세', '영세', '면세'].map(t => opt(t, t === '영세' ? '영세 (수출 · 포이즌 등)' : t, P.tax === t)).join('')}</select></label>
    <label data-buy>반품 기한 (입고일부터, 일)<input type="number" min="0" name="returnDays" value="${P.returnDays ?? INV.opt.returnDays}"></label>
    <label data-sell>수수료 방식<select name="feeMode">${opt('kream', '크림 (설정의 계산식)', P.feeMode === 'kream')}${opt('custom', '직접 입력', P.feeMode === 'custom')}${opt('none', '수수료 없음', P.feeMode === 'none')}</select></label>
    <label data-sell>수수료율 (%)<input type="number" step="0.1" min="0" name="feeRate" value="${P.feeRate ?? 0}"></label>
    <label data-sell>고정 수수료 (원)<input type="number" min="0" name="feeFix" value="${P.feeFix ?? 0}"></label>
    <label data-sell>VAT<select name="vat">${opt('포함', 'VAT 포함 (위 금액 그대로)', P.vat !== '별도')}${opt('별도', 'VAT 별도 (위 금액 + 10%)', P.vat === '별도')}</select></label></div>`, async fd => {
    const name = String(fd.name || '').trim(); if (!name) return '거래처명을 넣어 주세요';
    if (INV.partners.some(x => x.name === name && x !== p)) return '같은 이름의 거래처가 있어요';
    const kind = p ? p.kind : fd.kind;
    const o = p || { id: uid() };
    Object.assign(o, { kind, name, biz: fd.biz || '', tax: fd.tax || '과세' });
    if (kind === 'buy') o.returnDays = Math.max(0, Math.round(num(fd.returnDays)));
    else Object.assign(o, { feeMode: fd.feeMode, feeRate: num(fd.feeRate), feeFix: num(fd.feeFix), vat: fd.vat });
    if (!p) INV.partners.push(o);
    await invSave(); IS.msg = `${name} 저장했어요`; renderInv();
  });
  const dlg = $('#invDlg'), k = dlg.querySelector('[name=kind]');
  const sync = () => { const sell = (p ? p.kind : k.value) === 'sell'; dlg.querySelectorAll('[data-sell]').forEach(e => e.hidden = !sell); dlg.querySelectorAll('[data-buy]').forEach(e => e.hidden = sell); };
  k.addEventListener('change', sync); sync();
}

// ---------- 이벤트 ----------
async function invAct(a, el) {
  const id = el.dataset.id, C = invCalc();
  IS.msg = '';
  switch (a) {
    case 'nav': return go(el.dataset.v);
    case 'ordQuick': {
      if (!HAS_CHROME || !chrome.scripting) { IS.msg = '크림스캐너 안에서만 돼요'; return renderInv(); }
      IS.msg = '구매처 주문을 불러오는 중이에요… 사이트마다 작은 창이 열렸다 닫혀요. 끝나면 여기에 재고가 보여요.'; renderInv();
      return queueJob(async () => { const r = await ordSync({ auto: true, quiet: true }); IS.msg = IS.ms.msg || (r ? `자동 입고 ${r.auto}건` : ''); if (r && r.left) IS.msg += ` — 품번·사이즈를 못 읽은 ${r.left}건은 '구매처 주문 입고'에서 확인해 주세요`; renderInv(); }, { label: '구매처 주문 동기화' });
    }
    case 'sendMobile': { await sendToWeb(false); IS.msg = ($('#sendMsg') && $('#sendMsg').textContent) || ''; return renderInv(); }
    case 'quick': IS.io.mode = el.dataset.v; IS.io.msg = ''; return go('io');
    case 'baseTab': IS.base = el.dataset.v; return renderInv();
    case 'partnerEdit': return partnerDialog(partnerOf(id));
    case 'partnerDel': {
      const p = partnerOf(id);
      if (INV.lots.some(l => l.partnerId === id) || INV.outs.some(o => o.partnerId === id)) { IS.msg = `${p.name}은(는) 입출고 기록이 있어서 못 지워요`; return renderInv(); }
      return invDialog('거래처 삭제', `<p>${esc(p.name)}을(를) 지울까요?</p>`, async () => { INV.partners = INV.partners.filter(x => x !== p); await invSave(); renderInv(); }, '삭제');
    }
    case 'catDel': { const c = el.dataset.c; if (INV.items.some(i => i.cat === c)) { IS.msg = `'${c}' 분류를 쓰는 상품이 있어서 못 지워요`; return renderInv(); } delete INV.cats[c]; await invSave(); return renderInv(); }
    case 'subDel': { const c = el.dataset.c, s = el.dataset.s; INV.cats[c] = INV.cats[c].filter(x => x !== s); await invSave(); return renderInv(); }
    case 'brandDel': INV.brands = INV.brands.filter(x => x !== el.dataset.s); await invSave(); return renderInv();
    case 'payEdit': {
      const p = payOf(id) || { type: '카드', name: '', last4: '', proof: true };
      return invDialog(id ? '결제수단 수정' : '결제수단 추가', `<div class="dgrid"><label>종류<select name="type">${['카드', '계좌', '현금', '포인트·적립금'].map(t => opt(t, t, p.type === t)).join('')}</select></label><label>이름 *<input name="name" required value="${esc(p.name)}" placeholder="예: 현대카드, 신한 사업자통장"></label><label>끝 4자리 (선택)<input name="last4" maxlength="4" inputmode="numeric" value="${esc(p.last4 || '')}"></label><label>부가세 증빙<select name="proof">${opt('1', '있음 (카드·현금영수증·세금계산서)', p.proof !== false)}${opt('0', '없음 (매입세액 공제 안 됨)', p.proof === false)}</select></label></div>`, async fd => {
        const name = String(fd.name || '').trim(); if (!name) return '이름을 넣어 주세요';
        const last4 = String(fd.last4 || '').replace(/\D/g, '').slice(-4);
        const o = payOf(id) || { id: uid() }; Object.assign(o, { type: fd.type, name, last4, proof: fd.proof !== '0' });
        if (!payOf(id)) INV.pays.push(o); await invSave(); renderInv();
      });
    }
    case 'payDel': { if (INV.lots.some(l => l.payId === id) || INV.ledger.some(m => m.payId === id)) { IS.msg = '이 결제수단을 쓴 기록이 있어서 못 지워요'; return renderInv(); } INV.pays = INV.pays.filter(x => x.id !== id); await invSave(); return renderInv(); }
    case 'courierEdit': {
      const c = INV.couriers.find(x => x.id === id) || { name: '', box: { 극소: '', 소: '', 중: '', 대: '', 특대: '' } };
      return invDialog(id ? '택배사 수정' : '택배사 추가', `<div class="dgrid"><label class="wide">택배사명 *<input name="name" required value="${esc(c.name)}"></label>${Object.keys(c.box).map(b => `<label>${b} 박스 (원)<input type="number" min="0" name="b_${b}" value="${esc(c.box[b])}"></label>`).join('')}</div>`, async fd => {
        const name = String(fd.name || '').trim(); if (!name) return '택배사명을 넣어 주세요';
        const o = INV.couriers.find(x => x.id === id) || { id: uid(), box: {} };
        o.name = name; for (const b of ['극소', '소', '중', '대', '특대']) o.box[b] = fd['b_' + b] === '' ? '' : num(fd['b_' + b]);
        if (!INV.couriers.includes(o)) INV.couriers.push(o); await invSave(); renderInv();
      });
    }
    case 'courierDel': INV.couriers = INV.couriers.filter(x => x.id !== id); await invSave(); return renderInv();
    case 'itemOpen': IS.items.open = IS.items.open === id ? '' : id; return renderInv();
    case 'itemEdit': return openItemDialog(itemOf(id), el.dataset.then === 'io' ? it => { IS.io.q = ''; IS.io.msg = `${itName(it)} — 사이즈를 고르세요`; ioAddRow(it, ''); } : null);
    case 'itemDel': {
      const it = itemOf(id);
      // 3.7.9: 입출고 기록이 있어도 지울 수 있어요 — 이 상품의 입고·출고 기록도 같이 지워요 (잘못 들어온 주문 정리용)
      const L = INV.lots.filter(l => l.itemId === id), O = INV.outs.filter(o => o.itemId === id);
      const nIn = L.reduce((s2, l) => s2 + l.qty, 0), nOut = O.reduce((s2, o) => s2 + o.qty, 0), fromOrd = L.filter(l => l.srcKey).length;
      const body = L.length || O.length
        ? `<p><b>${esc(itName(it))}</b> (${esc(it.code)})을(를) 지울까요?</p><p>이 상품의 <b>입고 ${L.length}건(${nIn}개)</b>${O.length ? `과 <b>출고 ${O.length}건(${nOut}개)</b>` : ''}도 같이 지워져요. 재고·매입·매출 장부에서 모두 빠지고 되돌릴 수 없어요.</p>${fromOrd ? `<p class="small">구매처 주문에서 들어온 입고 ${fromOrd}건은 기억해 둬서 다음 자동입고 때 다시 안 들어와요.</p>` : ''}`
        : `<p>${esc(itName(it))} (${esc(it.code)})을(를) 지울까요?</p>`;
      return invDialog('상품 삭제', body, async () => {
        const keys = L.map(l => l.srcKey).filter(Boolean);
        if (keys.length) INV.skipKeys = [...new Set([...(INV.skipKeys || []), ...keys])].slice(-5000);
        INV.lots = INV.lots.filter(l => l.itemId !== id); INV.outs = INV.outs.filter(o => o.itemId !== id); INV.items = INV.items.filter(x => x !== it);
        if (IS.items.open === id) IS.items.open = '';
        await invSave(); IS.msg = `${itName(it)}을(를) 지웠어요${L.length || O.length ? ` (입고 ${L.length}건${O.length ? `, 출고 ${O.length}건` : ''} 포함)` : ''}`; renderInv();
      }, '삭제');
    }
    case 'itemIn': case 'itemOut': { const it = itemOf(id); IS.io.mode = a === 'itemIn' ? 'in' : 'out'; IS.io.msg = `${itName(it)} — 사이즈를 고르세요`; ioAddRow(it, ''); return go('io'); }
    case 'sizeSortAll': INV.items.forEach(it => it.sizes.sort(sizeSort)); await invSave(); IS.msg = `상품 ${INV.items.length}종의 사이즈를 정렬했어요`; return renderInv();
    case 'itemsXl': {
      const rows = [['품번', '상품명', '브랜드', '대분류', '소분류', '사이즈', '재고', '평균 매입가', '재고 금액', '바코드']];
      for (const it of itemsFiltered(C)) { const st = itemStock(it, C); for (const s of it.sizes) { const x = st.by[s]; rows.push([it.code, it.name, it.brand, it.cat, it.sub, s, x ? x.qty : 0, x ? Math.round(x.value / x.qty) : '', x ? Math.round(x.value) : 0, (it.barcodes || {})[s] || '']); } }
      return xlDownload([{ name: '재고', rows, widths: [16, 30, 12, 8, 10, 8, 6, 12, 12, 16] }], `크림스캐너_재고_${today()}.xlsx`);
    }
    case 'ioMode': IS.io.mode = el.dataset.v; IS.io.msg = ''; IS.io.partnerId = ''; saveDraft(); return renderInv();
    case 'ioBc': IS.io.bc = !IS.io.bc; IS.io.q = ''; return renderInv();
    case 'ioMulti': IS.io.multi = !IS.io.multi; return renderInv();
    case 'ioPick': { const it = itemOf(id); IS.io.q = ''; IS.io.msg = ''; ioAddRow(it, it.sizes.length === 1 ? it.sizes[0] : ''); return renderInv(); }
    case 'ioDel': IS.io.rows = IS.io.rows.filter(r => r.key !== el.dataset.i); saveDraft(); return renderInv();
    case 'ioClear': IS.io.rows = []; IS.io.msg = ''; saveDraft(); return renderInv();
    case 'ioSave': return ioSave();
    case 'lotDel': return lotDelete(id, C, m => { IS.msg = m; });
    case 'histDel': {
      if (el.dataset.k === 'lot') {
        return lotDelete(id, C, m => { IS.io.msg = m; });
      }
      const o = INV.outs.find(x => x.id === id);
      if ((o.events || []).length) { IS.io.msg = '반품·할인 처리된 출고는 못 지워요'; return renderInv(); }
      return invDialog('출고 삭제', `<p>${esc(itName(itemOf(o.itemId)))} ${esc(o.size)} ×${o.qty} 출고를 지울까요? 재고로 돌아가요.</p>`, async () => { INV.outs = INV.outs.filter(x => x !== o); await invSave(); renderInv(); }, '삭제');
    }
    case 'xlTpl': return xlTemplate();
    case 'xlAll': { const X = IS.xl; const ok = X.rows.filter(r => !r.err); const all = ok.every(r => r.sel); ok.forEach(r => r.sel = !all); return renderInv(); }
    case 'xlSave': return xlSave();
    case 'goAcct': return route('acct');
    case 'msSync': { if (!HAS_CHROME || !chrome.scripting) { IS.msg = '크림스캐너 안에서만 돼요'; return renderInv(); } IS.ms.days = +(document.querySelector('[data-k=msDays]') || {}).value || 90; return queueJob(() => ordSync(), { label: '구매처 주문 동기화' }); }
    case 'msAll': { const M = IS.ms; const L = ordRows().filter(x => !x.done && !x.cancel && (!M.site || x.site === M.site)); const all = L.every(x => M.sel.has(x.key)); L.forEach(x => all ? M.sel.delete(x.key) : M.sel.add(x.key)); return renderInv(); }
    case 'msSave': return msSave();
    case 'preOne': case 'preSettle': {
      const P = IS.pre; const ids = a === 'preOne' ? [id] : [...P.sel];
      const pairs = ids.map(i => [i, num(P.price[i])]);
      const miss = pairs.filter(([, p]) => !p).length;
      if (!ids.length) { IS.msg = '정산할 줄을 골라 주세요'; return renderInv(); }
      if (miss) { IS.msg = `판매가가 비어 있는 줄이 ${miss}개 있어요`; return renderInv(); }
      const n = await settleOuts(pairs, P.date || today()); ids.forEach(i => { P.sel.delete(i); delete P.price[i]; });
      IS.msg = `${n}건 정산했어요. 장부에 매출·수수료로 들어갔어요.`; return renderInv();
    }
    case 'kreamMatch': { const P = IS.pre; const rows = parseSaleLines(P.kreamText); P.kream = { rows: matchPre(rows, '크림') }; if (!rows.length) IS.msg = '읽을 줄이 없어요. 한 줄에 품번 사이즈 판매가 순서로 적어 주세요'; return renderInv(); }
    case 'kreamApply': case 'pzApply': {
      const P = IS.pre, M = a === 'kreamApply' ? P.kream : P.poizon;
      const n = await settleOuts(M.rows.filter(r => r.outId).map(r => [r.outId, r.price]), P.date || today());
      M.rows = M.rows.filter(r => !r.outId); IS.msg = `${n}건 정산했어요${M.rows.length ? ` · 못 맞춘 ${M.rows.length}줄은 남겨 뒀어요` : ''}`;
      if (a === 'kreamApply' && !M.rows.length) P.kreamText = '';
      return renderInv();
    }
    case 'retTab': IS.ret = el.dataset.v; return renderInv();
    case 'lotOk': { const l = INV.lots.find(x => x.id === id); l.confirmed = true; (l.events = l.events || []).push({ t: '확정', d: today() }); await invSave(); IS.msg = '구매확정했어요'; return renderInv(); }
    case 'retConfirmSoon': {
      const L = INV.lots.filter(l => !l.confirmed && C.left.get(l.id) > 0 && l.returnDue && dday(l.returnDue) <= 2);
      if (!L.length) { IS.msg = '마감 임박 건이 없어요'; return renderInv(); }
      return invDialog('일괄 구매확정', `<p>반품 마감이 2일 이내이거나 지난 매입 ${L.length}건을 구매확정할까요? 확정하면 반품·교환을 못 해요.</p>`, async () => { L.forEach(l => { l.confirmed = true; (l.events = l.events || []).push({ t: '확정', d: today() }); }); await invSave(); IS.msg = `${L.length}건 확정했어요`; renderInv(); }, '확정');
    }
    case 'lotRet': case 'lotEx': {
      const l = INV.lots.find(x => x.id === id), max = C.left.get(id), it = itemOf(l.itemId);
      return invDialog(a === 'lotRet' ? '매입 반품' : '매입 교환 (사이즈 바꾸기)', `<p class="hint">${esc(itName(it))} ${esc(l.size)} · 남은 ${max}개</p><div class="dgrid"><label>수량<input type="number" name="q" min="1" max="${max}" value="1" required></label><label>처리일<input type="date" name="d" value="${today()}"></label>${a === 'lotEx' ? `<label class="wide">바꿀 사이즈<input name="s" list="exSizes" required><datalist id="exSizes">${it.sizes.filter(s => s !== l.size).map(s => `<option value="${esc(s)}">`).join('')}</datalist></label>` : ''}</div>`, async fd => {
        const q = Math.round(num(fd.q)); if (!(q >= 1 && q <= max)) return `1~${max}개 사이로 넣어 주세요`;
        l.events = l.events || [];
        if (a === 'lotRet') { l.retQty = (l.retQty || 0) + q; l.events.push({ t: '반품', d: fd.d || today(), q }); IS.msg = `${q}개 반품 처리했어요. 장부에 매입반품(+${won(l.cost * q)})으로 들어갔어요.`; }
        else {
          const s = String(fd.s || '').trim(); if (!s || s === l.size) return '다른 사이즈를 넣어 주세요';
          if (!it.sizes.includes(s)) it.sizes.push(s);
          l.exQty = (l.exQty || 0) + q; l.events.push({ t: '교환', d: fd.d || today(), q, to: s });
          INV.lots.push({ ...l, id: uid(), at: Date.now(), size: s, qty: q, retQty: 0, exQty: 0, events: [], src: 'exchange', exFrom: l.id, memo: `${l.size} → ${s} 교환` });
          IS.msg = `${l.size} → ${s} ${q}개 교환했어요`;
        }
        await invSave(); renderInv();
      }, a === 'lotRet' ? '반품' : '교환');
    }
    case 'outOk': { const o = INV.outs.find(x => x.id === id); o.confirmed = true; (o.events = o.events || []).push({ t: '확정', d: today() }); await invSave(); IS.msg = '판매확정했어요'; return renderInv(); }
    case 'outRet': case 'outDisc': {
      const o = INV.outs.find(x => x.id === id), n = outNums(o);
      return invDialog(a === 'outRet' ? '판매 반품 (재고로 돌아와요)' : '판매 후 할인', `<p class="hint">${esc(itName(itemOf(o.itemId)))} ${esc(o.size)} · 판매 ${n.net}개 · ${won(o.price)}</p><div class="dgrid">${a === 'outRet' ? `<label>반품 수량<input type="number" name="q" min="1" max="${n.net}" value="1"></label><label>수수료 환급<select name="fb">${opt('1', '받음 (크림 취소 등)', true)}${opt('0', '못 받음')}</select></label>` : `<label>개당 할인 금액 (원)<input type="number" name="amt" min="1" required></label><label>메모<input name="memo"></label>`}<label>처리일<input type="date" name="d" value="${today()}"></label></div>`, async fd => {
        o.events = o.events || [];
        if (a === 'outRet') {
          const q = Math.round(num(fd.q)); if (!(q >= 1 && q <= n.net)) return `1~${n.net}개 사이로 넣어 주세요`;
          const price = o.price - (o.disc || 0);
          o.retQty = (o.retQty || 0) + q;
          o.events.push({ t: '반품', d: fd.d || today(), q, total: price * q, gross: price * q, feeBack: fd.fb === '1' ? n.fee * q : 0 });
          INV.lots.push({ id: uid(), at: Date.now(), date: fd.d || today(), itemId: o.itemId, size: o.size, qty: q, cost: Math.round(n.unitCost), partnerId: '', payId: '', memo: '판매 반품으로 돌아온 재고', src: 'return', srcKey: o.id, returnDue: '', confirmed: true, retQty: 0, exQty: 0, events: [] });
          IS.msg = `${q}개 반품 — 재고로 돌아왔어요`;
        } else {
          const amt = Math.round(num(fd.amt)); if (!(amt > 0)) return '할인 금액을 넣어 주세요';
          o.disc = (o.disc || 0) + amt; o.events.push({ t: '할인', d: fd.d || today(), q: n.net, total: amt * n.net, memo: fd.memo || '' });
          IS.msg = `개당 ${won(amt)} 할인 반영했어요`;
        }
        await invSave(); renderInv();
      }, a === 'outRet' ? '반품' : '할인 반영');
    }
    case 'manual': return invDialog('수기 입력', `<div class="dgrid"><label>구분<select name="io">${opt('out', '지출')}${opt('in', '수입')}</select></label><label>날짜<input type="date" name="date" value="${today()}"></label><label class="wide">내용 *<input name="desc" required placeholder="예: 박스·테이프 구입, 포인트 적립"></label><label>금액 (원) *<input type="number" name="amount" min="1" required></label><label>거래처<input name="partner"></label><label>결제수단<select name="payId"><option value="">–</option>${INV.pays.map(p => opt(p.id, p.name)).join('')}</select></label><label>부가세 증빙<select name="vat">${opt('0', '없음')}${opt('1', '있음 (부가세 포함 금액)')}</select></label><label class="wide">메모<input name="memo"></label></div>`, async fd => {
      const amount = Math.round(num(fd.amount)); if (!String(fd.desc || '').trim() || !(amount > 0)) return '내용과 금액을 넣어 주세요';
      INV.ledger.push({ id: uid(), date: fd.date || today(), io: fd.io, desc: fd.desc.trim(), amount, partner: fd.partner || '', payId: fd.payId || '', vat: fd.vat === '1', memo: fd.memo || '' });
      await invSave(); IS.msg = '장부에 넣었어요'; renderInv();
    });
    case 'manualDel': INV.ledger = INV.ledger.filter(m => m.id !== id); await invSave(); return renderInv();
    case 'lgPage': IS.lg.page = Math.max(0, IS.lg.page + +el.dataset.v); return renderInv();
    case 'ledgerXl': {
      const F = IS.lg; const R = ledgerRows().filter(r => inRange(r.date, F.from, F.to) && (!F.kind || r.kind.startsWith(F.kind)) && (!F.partner || r.partner === F.partner) && (!F.pay || r.payId === F.pay));
      return xlDownload([{ name: '장부', rows: [['날짜', '구분', '내용', '거래처', '결제수단', '금액', '메모'], ...R.map(r => [r.date, r.kind, r.desc, r.partner, r.pay, r.amount, r.memo])], widths: [12, 10, 40, 14, 14, 12, 24] }], `크림스캐너_장부_${F.from}_${F.to}.xlsx`);
    }
    case 'backup': return download(JSON.stringify({ app: '크림스캐너-재고관리', at: new Date().toISOString(), inv: INV }), `크림스캐너_재고관리_백업_${today()}.json`, 'application/json');
    case 'resetRun': {
      const kind = IS.rs || 'all', need = { all: '전체삭제', stock: '재고삭제', base: '삭제' }[kind];
      if ((IS.rsText || '').trim() !== need) { IS.msg = `확인 문구 '${need}'를 정확히 넣어 주세요`; return renderInv(); }
      const D = INV_DEF();
      if (kind === 'all') Object.assign(INV, { items: [], lots: [], outs: [], ledger: [], poizonMap: {}, skipKeys: [] });
      else if (kind === 'stock') Object.assign(INV, { lots: [], outs: [], ledger: [], skipKeys: [] });
      else Object.assign(INV, { partners: D.partners.concat(INV.partners.filter(p => !D.partners.some(d => d.id === p.id) && (INV.lots.some(l => l.partnerId === p.id) || INV.outs.some(o => o.partnerId === p.id)))), pays: INV.pays.filter(p => INV.lots.some(l => l.payId === p.id)), couriers: D.couriers, cats: D.cats, brands: D.brands, opt: D.opt });
      IS.rsText = ''; await invSave(); IS.msg = kind === 'base' ? '기본정보를 처음 상태로 돌렸어요 (기록에 쓰인 거래처·결제수단은 남겨요)' : '삭제했어요';
      return renderInv();
    }
  }
}
async function invInput(el, ev) {
  const k = el.dataset.k, v = el.type === 'checkbox' ? el.checked : el.value;
  const live = ev.type === 'input';
  switch (k) {
    case 'itemsQ': IS.items.q = v; if (live) { clearTimeout(invInput.t); invInput.t = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=itemsQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, 250); } return;
    case 'itemsBrand': IS.items.brand = v; break;
    case 'itemsCat': IS.items.cat = v; break;
    case 'itemsOnly': IS.items.only = v; break;
    case 'stockSet': {
      if (live) return; const it = itemOf(el.dataset.id); const d = await stockSet(el.dataset.id, el.dataset.s, v);
      IS.msg = d ? `${itName(it)} ${el.dataset.s} 재고를 ${Math.max(0, Math.floor(+v || 0))}개로 고쳤어요 (${d > 0 ? '+' : ''}${d})` : ''; return renderInv();
    }
    case 'bc': {
      if (live) return; const it = itemOf(el.dataset.id); it.barcodes = it.barcodes || {}; it.barcodes[el.dataset.s] = v.trim(); await invSave();
      const cnt = {}; for (const x of INV.items) for (const b of Object.values(x.barcodes || {})) if (b) cnt[b] = (cnt[b] || 0) + 1;
      document.querySelectorAll('[data-k=bc]').forEach(e => e.classList.toggle('dup', !!e.value && cnt[e.value.trim()] > 1));
      return;
    }
    case 'opt': if (live) return; INV.opt[el.dataset.o] = Math.max(0, Math.round(num(v))); await invSave(); return;
    case 'io': IS.io[el.dataset.f] = v; saveDraft(); if (live) return; break;
    case 'ioRow': {
      const r = IS.io.rows.find(x => x.key === el.dataset.i); if (!r) return; r[el.dataset.f] = v; saveDraft();
      if (el.dataset.f === 'size' && !live) break;
      // 칸을 옮겨 다닐 때 화면을 다시 그리면 커서가 사라져서, 합계만 고쳐요
      const io = IS.io, sum = $('#ioSum'); if (sum) sum.textContent = `${io.rows.length}줄 · ${io.rows.reduce((t, x) => t + (+x.qty || 0), 0)}개${io.mode === 'pre' ? '' : ` · 합계 ${won(io.rows.reduce((t, x) => t + num(x.price) * (+x.qty || 0), 0))}`}`;
      return;
    }
    case 'ioQ': {
      IS.io.q = v; if (IS.io.bc || !live) return;
      clearTimeout(invInput.t); invInput.t = setTimeout(() => { renderInv(); const e = $('#ioQ'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, 200); return;
    }
    case 'xlRow': { const r = IS.xl.rows.find(x => x.k === el.dataset.i); r[el.dataset.f] = el.dataset.f === 'cost' ? num(v) : v; if (live || el.dataset.f !== 'sel') return; break; }
    case 'xlBulk': { if (live || !v) return; IS.xl.rows.filter(r => r.sel && !r.err).forEach(r => r[el.dataset.f] = v); break; }
    case 'xlFile': if (el.files[0]) return xlLoad(el.files[0]); return;
    case 'ms': IS.ms[el.dataset.f] = v; break;
    case 'msSel': { v ? IS.ms.sel.add(el.dataset.i) : IS.ms.sel.delete(el.dataset.i); const b = document.querySelector('[data-a=msSave]'); if (b) b.textContent = `선택 ${ordRows().filter(x => !x.done && !x.cancel && IS.ms.sel.has(x.key)).length}건 입고 등록`; return; }
    case 'ordSite': v ? IS.ms.sites.add(el.dataset.i) : IS.ms.sites.delete(el.dataset.i); INV.opt.ordSites = [...IS.ms.sites]; await invSave(); return;
    case 'autoIn': INV.opt.autoIn = v; await invSave(); IS.msg = v ? '이제 동기화하면 품번·사이즈·매입가를 읽은 주문은 바로 입고해요' : '자동 입고를 껐어요'; break;
    case 'autoHours': INV.opt.autoHours = +v; await invSave(); await setOrderAlarm(); IS.msg = +v ? `${+v}시간마다 구매처 주문을 확인해요${INV.opt.autoIn ? ' (자동 입고 켜짐)' : ' — 바로 재고에 넣으려면 \'동기화하면 바로 재고에 넣기\'도 켜 주세요'}` : '자동 동기화를 껐어요'; break;
    case 'ordCancel': IS.ms.showCancel = v; break;
    case 'ordEdit': { (IS.ms.edit[el.dataset.i] = IS.ms.edit[el.dataset.i] || {})[el.dataset.f] = v; return; }
    case 'msDays': IS.ms.days = +v; return;
    case 'preDate': IS.pre.date = v; return;
    case 'prePrice': {
      IS.pre.price[el.dataset.i] = v; if (live) return;
      if (num(v)) { IS.pre.sel.add(el.dataset.i); const c = document.querySelector(`[data-k=preSel][data-i="${el.dataset.i}"]`); if (c) c.checked = true; }
      const o = INV.outs.find(x => x.id === el.dataset.i), cell = document.querySelector(`[data-mg="${el.dataset.i}"]`);
      if (o && cell) { const n = outNums(o), pr = num(v), mg = pr ? (pr - partnerFee(partnerOf(o.partnerId), pr)) * o.qty - n.cogs - n.ship : null; cell.textContent = mg == null ? '–' : wonS(mg); cell.className = mg > 0 ? 'pos' : mg < 0 ? 'neg' : ''; }
      const b = document.querySelector('[data-a=preSettle]'); if (b) b.textContent = `선택 ${IS.pre.sel.size}건 정산`;
      return;
    }
    case 'preSel': { v ? IS.pre.sel.add(el.dataset.i) : IS.pre.sel.delete(el.dataset.i); const b = document.querySelector('[data-a=preSettle]'); if (b) b.textContent = `선택 ${IS.pre.sel.size}건 정산`; return; }
    case 'preAll': INV.outs.filter(o => o.kind === 'pre' && !o.settled).forEach(o => v ? IS.pre.sel.add(o.id) : IS.pre.sel.delete(o.id)); break;
    case 'kreamText': IS.pre.kreamText = v; return;
    case 'pzFile': if (el.files[0]) return pzLoad(el.files[0]); return;
    case 'pzLink': { if (!v) return; INV.poizonMap[codeKey(el.dataset.c)] = v; await invSave(); const M = IS.pre.poizon; M.rows.forEach(r => { if (codeKey(r.code) === codeKey(el.dataset.c)) r.itemId = v; }); matchPre(M.rows.filter(r => !r.outId), '포이즌'); break; }
    case 'lg': IS.lg[el.dataset.f] = v; IS.lg.page = 0; if (live && el.type !== 'date') return; break;
    case 'lgQuick': { if (v[0] === 'm') { IS.lg.from = monthStart(v.slice(1)); IS.lg.to = monthEnd(v.slice(1)); } else if (v[0] === 'y') { IS.lg.from = v.slice(1) + '-01-01'; IS.lg.to = v.slice(1) + '-12-31'; } IS.lg.page = 0; break; }
    case 'lgSize': IS.lg.size = +v; IS.lg.page = 0; break;
    case 'vatYear': IS.vat.year = +v; break;
    case 'vatHalf': IS.vat.half = +v; break;
    case 'rsKind': IS.rs = v; break;
    case 'rsText': IS.rsText = v; return;
    case 'restore': {
      const f = el.files[0]; if (!f) return;
      try {
        const o = JSON.parse(await f.text()); if (!o || !o.inv || !Array.isArray(o.inv.items)) throw new Error('크림스캐너 재고관리 백업 파일이 아니에요');
        return invDialog('백업 불러오기', `<p>${esc(f.name)} (${esc(String(o.at || '').slice(0, 10))})으로 지금 데이터를 <b>모두 바꿀까요?</b> 지금 데이터는 사라져요.</p>`, async () => { INV = Object.assign(INV_DEF(), o.inv); await invSave(); IS.msg = `백업을 불러왔어요 — 상품 ${INV.items.length}종`; renderInv(); }, '바꾸기');
      } catch (e) { IS.msg = '불러오기 실패: ' + e.message; }
      break;
    }
    default: return;
  }
  renderInv();
}
async function invKey(el, ev) {
  const k = el.dataset.k;
  if (ev.key !== 'Enter' && !(k === 'ioQ' && ev.key === 'Escape')) return;
  if (['catAdd', 'subAdd', 'brandAdd'].includes(k)) {
    ev.preventDefault(); const v = el.value.trim(); if (!v) return;
    if (k === 'catAdd') { if (!INV.cats[v]) INV.cats[v] = []; }
    else if (k === 'subAdd') { const c = el.dataset.c; if (!INV.cats[c].includes(v)) INV.cats[c].push(v); }
    else if (!INV.brands.includes(v)) INV.brands.push(v);
    await invSave(); renderInv();
    const again = document.querySelector(`[data-k="${k}"]${el.dataset.c ? `[data-c="${CSS.escape(el.dataset.c)}"]` : ''}`); if (again) again.focus();
    return;
  }
  if (k !== 'ioQ') return;
  ev.preventDefault();
  const io = IS.io;
  if (ev.key === 'Escape') { io.bc = false; io.q = ''; return renderInv(); }
  const q = el.value.trim(); if (!q) return;
  if (io.bc) {
    const hit = findBarcode(q);
    if (hit) { ioAddRow(hit.it, hit.size); io.msg = `✓ ${itName(hit.it)} ${hit.size}`; beep(true); }
    else { io.msg = `모르는 바코드 ${q} — 상품 · 재고에서 사이즈 칸에 바코드를 넣어 주세요`; beep(false); }
    io.q = ''; renderInv(); const e = $('#ioQ'); if (e) e.focus(); return;
  }
  const exact = INV.items.find(it => codeKey(it.code) === codeKey(q)) || (findBarcode(q) || {}).it;
  const it = exact || ioSearch(q)[0];
  if (!it) { io.msg = `'${q}' 상품이 없어요. 새 상품으로 등록하세요`; return renderInv(); }
  const bc = findBarcode(q);
  ioAddRow(it, bc ? bc.size : it.sizes.length === 1 ? it.sizes[0] : ''); io.q = ''; io.msg = ''; renderInv();
  const e = $('#ioQ'); if (e) e.focus();
}

async function invInit() {
  const saved = await store.get('inv', null);
  INV = Object.assign(INV_DEF(), saved || {});
  INV.opt = Object.assign(INV_DEF().opt, INV.opt || {});
  if (!(INV.opt.optV >= 2)) { INV.opt.autoIn = true; INV.opt.optV = 2; }   // 2.6: 자동 입고 기본으로 켬
  ordCache = await store.get('ordCache', {});
  const d = await store.get('invDraft', null);
  if (d) Object.assign(IS.io, d);
  const main = $('#invMain');
  $('#invNav').addEventListener('click', e => { const b = e.target.closest('[data-v]'); if (b) go(b.dataset.v); });
  main.addEventListener('click', e => {
    const el = e.target.closest('[data-a]'); if (!el || !main.contains(el)) return;
    if (el.tagName === 'TR' && e.target.closest('button,input,select,a,label')) return;
    invAct(el.dataset.a, el).catch(err => { IS.msg = '오류: ' + err.message; renderInv(); });
  });
  main.addEventListener('input', e => { const el = e.target.closest('[data-k]'); if (el && (el.type !== 'checkbox' && el.type !== 'radio' && el.tagName !== 'SELECT' && el.type !== 'file')) invInput(el, e); });
  main.addEventListener('change', e => { const el = e.target.closest('[data-k]'); if (el) invInput(el, e); });
  main.addEventListener('keydown', e => { const el = e.target.closest('[data-k]'); if (el) invKey(el, e); });
  main.addEventListener('dragover', e => { const z = e.target.closest('[data-drop],.drop'); if (z) { e.preventDefault(); z.classList.add('over'); } });
  main.addEventListener('dragleave', e => { const z = e.target.closest('.drop'); if (z) z.classList.remove('over'); });
  main.addEventListener('drop', e => { const z = e.target.closest('.drop'); if (!z) return; e.preventDefault(); z.classList.remove('over'); const f = e.dataTransfer.files[0]; if (!f) return; if (z.querySelector('[data-k=pzFile]')) pzLoad(f); else xlLoad(f); });
}

// ---------- 휴대폰으로 보낼 재고 요약 (웹페이지 저장 공간 문서 하나에 들어가게 짧게) ----------
function invMobileSummary() {
  if (!INV.items.length && !INV.lots.length) return null;
  const C = invCalc(), t = today();
  const stock = INV.items.map(it => { const st = itemStock(it, C); const sz = {}; for (const s of it.sizes) if (st.by[s]) sz[s] = st.by[s].qty; return { c: it.code, n: itName(it), q: st.qty, v: Math.round(st.value), s: sz, o: it.sizes.filter(s => sz[s]) }; })
    .filter(x => x.q > 0).sort((a, b) => b.v - a.v).slice(0, 600);
  const pre = INV.outs.filter(o => o.kind === 'pre' && !o.settled).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 200)
    .map(o => ({ d: o.date, n: itName(itemOf(o.itemId)), c: itemOf(o.itemId)?.code || '', s: o.size, q: o.qty, p: partnerOf(o.partnerId)?.name || '', cost: Math.round(outNums(o).unitCost) }));
  const soon = INV.lots.filter(l => !l.confirmed && C.left.get(l.id) > 0 && l.returnDue && dday(l.returnDue) <= Math.max(INV.opt.soon, 7)).sort((a, b) => a.returnDue.localeCompare(b.returnDue)).slice(0, 200)
    .map(l => ({ due: l.returnDue, n: itName(itemOf(l.itemId)), s: l.size, q: C.left.get(l.id), p: partnerOf(l.partnerId)?.name || '', cost: l.cost }));
  const months = [];
  const d0 = new Date(t.slice(0, 7) + '-01T00:00:00');
  for (let i = 5; i >= 0; i--) { const d = new Date(d0); d.setMonth(d.getMonth() - i); const s = fmtD(d); const f = monthFigures(monthStart(s), monthEnd(s)); months.push({ m: s.slice(0, 7), sold: f.sold, rev: Math.round(f.rev), buy: Math.round(f.buy), fees: Math.round(f.fees), margin: Math.round(f.margin) }); }
  let qty = 0, value = 0; for (const s of C.stock.values()) { qty += s.qty; value += s.value; }
  return { at: Date.now(), skus: stock.length, qty, value: Math.round(value), months, stock, pre, soon, soonDays: INV.opt.soon };
}
