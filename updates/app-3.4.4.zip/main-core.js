'use strict';
/* 크림스캐너 본체 (3.1.1부터 자동 업데이트로 바뀌는 부분)
   웨일 확장 프로그램이 쓰던 chrome.* 기능(저장소·작업 창·사이트 읽기·알림·예약·업데이트)을 이 프로그램 안에서 해 줘요. */
module.exports = function (ctx) {
const { app, BrowserWindow, ipcMain, Notification, Tray, Menu, shell, session, nativeImage, webContents, net, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { BUNDLED, ROOT, VER, ICON, UA, cmpVer } = ctx;
const PART = 'persist:shop';
// ---------- 3.0.1: 프로그램 안에서 업데이트 (화면·기능 파일만 바꾸는 작은 업데이트) ----------
// %APPDATA%\\KreamScanner\\app-update 에 더 새 버전이 있으면 그걸 써요. 설치 파일을 다시 받을 필요가 없어요.
const _cmpVerUnused = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
const UPD = () => path.join(app.getPath('userData'), 'app-update');

// 아주 작은 zip 풀기 (업데이트 파일 전용)
function unzip(buf) {
  const zlib = require('zlib'), out = [];
  let eocd = buf.length - 22; while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  if (eocd < 0) throw new Error('zip 파일이 아니에요');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip 목록이 깨졌어요');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), loff = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8');
    p += 46 + nlen + elen + clen;
    if (name.endsWith('/')) continue;
    const ds = loff + 30 + buf.readUInt16LE(loff + 26) + buf.readUInt16LE(loff + 28);
    const raw = buf.slice(ds, ds + csize);
    out.push({ name, data: method === 0 ? raw : zlib.inflateRawSync(raw) });
  }
  return out;
}
function applyUpdate(bytes) {
  const files = unzip(Buffer.from(bytes));
  const vf = files.find(f => /(^|\/)version\.json$/.test(f.name)); if (!vf) throw new Error('크림스캐너 업데이트 파일이 아니에요 (version.json 없음)');
  const base = vf.name.replace(/version\.json$/, '');
  const ver = JSON.parse(vf.data.toString('utf8')).version;
  if (!files.some(f => f.name === base + 'app.html')) throw new Error('업데이트 파일에 화면 파일이 없어요');
  if (cmpVer(ver, VER) <= 0) throw new Error(`이미 ${VER} 버전이에요 (업데이트 파일은 ${ver})`);
  const tmp = UPD() + '.tmp'; fs.rmSync(tmp, { recursive: true, force: true });
  for (const f of files) {
    if (!f.name.startsWith(base)) continue;
    const rel = f.name.slice(base.length); if (!rel || rel.includes('..')) continue;
    const dst = path.join(tmp, rel); fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.writeFileSync(dst, f.data);
  }
  fs.rmSync(UPD(), { recursive: true, force: true }); fs.renameSync(tmp, UPD());
  return ver;
}


// ---------- 저장소 (chrome.storage.local 대신 JSON 파일) ----------
let DATA = {}, saveT = null;
const dataFile = () => path.join(app.getPath('userData'), 'kream-data.json');
function loadData() {
  for (const f of [dataFile(), dataFile() + '.bak']) {
    try { DATA = JSON.parse(fs.readFileSync(f, 'utf8')); return; } catch (e) {}
  }
  DATA = {};
}
function flush() {
  clearTimeout(saveT); saveT = null;
  const f = dataFile(), tmp = f + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(DATA));
    try { if (fs.existsSync(f)) fs.copyFileSync(f, f + '.bak'); } catch (e) {}
    fs.renameSync(tmp, f);
  } catch (e) { console.error('save failed', e); }
}
const saveSoon = () => { if (!saveT) saveT = setTimeout(flush, 400); };

// ---------- 창 ----------
let appWin = null, tray = null, quitting = false;
const appFile = () => path.join(ROOT, 'app.html');
const isAppUrl = u => /(^|\/)app\.html(\?|$)/.test(String(u)) || String(u).startsWith(pathToFileURL(appFile()).href);

function createAppWin(query, show) {
  const w = new BrowserWindow({
    width: 1480, height: 940, minWidth: 900, minHeight: 600, show: show !== false, icon: ICON, title: '크림스캐너', autoHideMenuBar: true, backgroundColor: '#f3f4f2',
    webPreferences: { preload: path.join(ROOT, 'app-preload.js'), contextIsolation: false, sandbox: false, nodeIntegration: false, backgroundThrottling: false, additionalArguments: ['--kc-root=' + ROOT, '--kc-ver=' + VER] }
  });
  w.loadFile(appFile(), { search: query ? String(query).replace(/^\?/, '') : '' });
  w.webContents.setWindowOpenHandler(({ url }) => { openLink(url); return { action: 'deny' }; });
  w.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); openLink(url); } });
  return w;
}
function showMain() {
  if (!appWin || appWin.isDestroyed()) {
    appWin = createAppWin('', true);
    appWin.on('close', e => { if (!quitting) { e.preventDefault(); appWin.hide(); trayHint(); } });
  }
  if (appWin.isMinimized()) appWin.restore();
  appWin.show(); appWin.focus();
}
let hinted = false;
function trayHint() { if (hinted) return; hinted = true; notify('크림스캐너는 계속 실행 중이에요', '오른쪽 아래 작업 표시줄의 크림스캐너 아이콘에서 다시 열거나 종료할 수 있어요. 자동 동기화·가격 추적은 켜 둔 동안 돌아가요.'); }

// 쇼핑몰 창(작업 창 · 로그인 창): 로그인은 persist:shop 에 저장돼요
function shopWin(url, opts) {
  opts = opts || {};
  const w = new BrowserWindow({
    width: opts.width || 1180, height: opts.height || 900, show: !opts.background, icon: ICON, autoHideMenuBar: true, title: opts.title || '크림스캐너',
    webPreferences: { partition: PART, preload: path.join(ROOT, 'work-preload.js'), contextIsolation: true, sandbox: false, nodeIntegration: false, backgroundThrottling: false, additionalArguments: ['--kc-root=' + ROOT] }
  });
  if (opts.background) bgHide(w);
  else if (opts.focused === false) w.showInactive();
  w.webContents.setWindowOpenHandler(() => ({ action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, icon: ICON, webPreferences: { partition: PART } } }));
  const wcid = w.webContents.id;
  w.webContents.on('did-start-navigation', (e) => { if (e.isMainFrame && !e.isSameDocument) domReady.set(wcid, false); });
  w.webContents.on('dom-ready', () => { setTimeout(() => domReady.set(wcid, true), 1200); });   // 화면이 그려지면 '완료'로 봐요 (광고 로딩은 안 기다려요)
  w.on('closed', () => domReady.delete(wcid));
  // 3.4.4: 화면이 비어 있을 때 원인을 알 수 있게 응답 코드·실패 이유를 적어 둬요
  w.webContents.on('did-navigate', (e, u, code, st) => navInfo.set(wcid, { url: u, code, st }));
  w.webContents.on('did-fail-load', (e, code, desc, u, main) => { if (main && code !== -3) navInfo.set(wcid, { url: u, fail: code + ' ' + desc }); });
  w.on('closed', () => navInfo.delete(wcid));
  if (url) w.loadURL(url).catch(() => {});
  return w;
}
const domReady = new Map();
const navInfo = new Map();
// 3.4.1: 작업 창을 뒤에서 실행 — 창은 그대로 그려지게(사이트가 정상 동작하게) 모든 모니터 바깥에 두고, 작업 표시줄·포커스도 안 가져가요.
// 직접 봐야 할 때(확인 화면·보안문자 등) windows.update(focused) 가 오면 화면 가운데로 꺼내요.
function bgHide(w) {
  try {
    const ds = screen.getAllDisplays();
    const x = Math.max(...ds.map(d => d.bounds.x + d.bounds.width)) + 400, y = Math.min(...ds.map(d => d.bounds.y));
    w.__bg = true; w.setSkipTaskbar(true); w.setPosition(x, y); w.showInactive(); w.setPosition(x, y);
  } catch (e) { w.showInactive(); }
}
function bgShow(w) {
  if (!w.__bg) return;
  w.__bg = false; w.setSkipTaskbar(false);
  try { const d = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).workArea; const [bw, bh] = w.getSize(); w.setPosition(Math.round(d.x + (d.width - bw) / 2), Math.round(d.y + Math.max(0, (d.height - bh) / 2))); } catch (e) { w.center(); }
}
function openLink(url) {
  if (!/^https?:/i.test(url)) return;
  if (/claude\.ai|claude\.com/i.test(url)) return shell.openExternal(url);   // 휴대폰용 페이지는 원래 쓰던 브라우저로
  shopWin(url, { title: '크림스캐너 — 브라우저' });
}

// ---------- 알림 ----------
function notify(title, body, onClick) {
  try { const n = new Notification({ title, body, icon: ICON }); n.on('click', onClick || showMain); n.show(); } catch (e) {}
}

// ---------- 예약 (chrome.alarms 대신) ----------
const timers = new Map();
function alarmFire(name) {
  if (name === 'kc-track') createAppWin('?track=1', false);
  if (name === 'ks-orders') createAppWin('?orders=1', false);
}
function alarmSchedule(name, a) {
  const old = timers.get(name); if (old) { clearTimeout(old.t); clearInterval(old.i); }
  const period = Math.max(1, +a.periodInMinutes || 0) * 60000, first = Math.max(1, +a.delayInMinutes || +a.periodInMinutes || 1) * 60000;
  const rec = { t: null, i: null };
  rec.t = setTimeout(() => { alarmFire(name); if (a.periodInMinutes) rec.i = setInterval(() => alarmFire(name), period); }, first);
  timers.set(name, rec);
}
function alarmsRestore() { for (const [n, a] of Object.entries(DATA.__alarms || {})) alarmSchedule(n, { ...a, delayInMinutes: a.periodInMinutes }); }

// ---------- 사이트 메시지 (chrome.tabs.sendMessage 대신) ----------
let msgSeq = 0; const waiting = new Map();
ipcMain.on('kc-reply', (e, id, resp) => { const w = waiting.get(id); if (w) { waiting.delete(id); w(resp); } });

const wcOf = id => { const wc = webContents.fromId(+id); if (!wc || wc.isDestroyed()) throw new Error('No tab with id: ' + id); return wc; };
const winOf = id => { const w = BrowserWindow.fromId(+id); if (!w || w.isDestroyed()) throw new Error('No window with id: ' + id); return w; };

const API = {
  storage: {
    get(keys) {
      if (keys == null) return { ...DATA, __alarms: undefined };
      if (typeof keys === 'string') return keys in DATA ? { [keys]: DATA[keys] } : {};
      if (Array.isArray(keys)) return Object.fromEntries(keys.filter(k => k in DATA).map(k => [k, DATA[k]]));
      return Object.fromEntries(Object.entries(keys).map(([k, d]) => [k, k in DATA ? DATA[k] : d]));
    },
    set(obj) { for (const [k, v] of Object.entries(obj || {})) { if (v === undefined) delete DATA[k]; else DATA[k] = v; } saveSoon(); return true; },
    remove(keys) { for (const k of [].concat(keys)) delete DATA[k]; saveSoon(); return true; }
  },
  windows: {
    create(o) { const w = shopWin(o.url, { width: o.width, height: o.height, focused: o.focused, background: !!o.background }); return { id: w.id, tabs: [{ id: w.webContents.id }] }; },
    get(id) { const w = winOf(id); return { id: w.id, focused: w.isFocused(), state: w.isMinimized() ? 'minimized' : 'normal', background: !!w.__bg }; },
    update(id, o) { const w = winOf(id); if (o && o.focused) bgShow(w); if (o && (o.state === 'normal' || o.focused)) { if (w.isMinimized()) w.restore(); if (!w.__bg) w.show(); } if (o && o.focused) w.focus(); return { id: w.id }; },
    remove(id) { const w = winOf(id); w.destroy(); return true; }
  },
  tabs: {
    get(id) { const wc = wcOf(id); const w = BrowserWindow.fromWebContents(wc); return { id: wc.id, url: wc.getURL(), status: !wc.isLoading() || domReady.get(wc.id) ? 'complete' : 'loading', windowId: w ? w.id : -1, active: true, nav: navInfo.get(wc.id) || null }; },
    update(id, o) { const wc = wcOf(id); if (o && o.url) wc.loadURL(o.url).catch(() => {}); if (o && o.muted !== undefined) wc.setAudioMuted(!!o.muted); return { id: wc.id }; },
    create(o) {
      const url = String(o && o.url || '');
      if (isAppUrl(url)) { const q = url.includes('?') ? url.slice(url.indexOf('?')) : ''; if (!q) { showMain(); return { id: appWin.webContents.id }; } const w = createAppWin(q, o.active !== false); return { id: w.webContents.id }; }
      if (/claude\.ai|claude\.com/i.test(url)) { shell.openExternal(url); return { id: -1 }; }
      const w = shopWin(url, { title: '크림스캐너 — 브라우저' }); return { id: w.webContents.id, windowId: w.id };
    },
    query() { return BrowserWindow.getAllWindows().map(w => ({ id: w.webContents.id, url: w.webContents.getURL(), windowId: w.id })); },
    sendMessage(id, msg) {
      const wc = wcOf(id), mid = ++msgSeq;
      return new Promise((res, rej) => {
        const to = setTimeout(() => { waiting.delete(mid); rej(new Error('응답 없음')); }, 60000);
        waiting.set(mid, r => { clearTimeout(to); if (r && r.__kcNoListener) rej(new Error('Could not establish connection. Receiving end does not exist.')); else res(r); });
        wc.send('kc-msg', mid, msg);
      });
    }
  },
  scripting: {
    async executeScript(o) {
      const wc = wcOf(o.target && o.target.tabId);
      const code = `(${o.func}).apply(null, ${JSON.stringify(o.args || [])})`;
      // 3.1.1: wc.executeJavaScript는 페이지가 '다 불러질 때까지' 기다려서, 광고·추적 때문에 로딩이 안 끝나는 쇼핑몰(지그재그 등)에서 멈췄어요.
      //        mainFrame.executeJavaScript는 바로 실행돼요.
      const result = await wc.mainFrame.executeJavaScript(code, true);
      return [{ result: result === undefined ? null : result }];
    }
  },
  notifications: { create(id, o) { notify(o.title || '크림스캐너', o.message || ''); return id; } },
  alarms: {
    create(name, a) { DATA.__alarms = { ...(DATA.__alarms || {}), [name]: { periodInMinutes: a.periodInMinutes, delayInMinutes: a.delayInMinutes } }; saveSoon(); alarmSchedule(name, a); return true; },
    clear(name) { const old = timers.get(name); if (old) { clearTimeout(old.t); clearInterval(old.i); timers.delete(name); } if (DATA.__alarms) { delete DATA.__alarms[name]; saveSoon(); } return true; }
  },
  app: {
    focusMain() { showMain(); return true; },
    info() { return { version: VER, bundled: app.getVersion(), updated: ROOT !== BUNDLED, platform: process.platform }; },
    applyUpdate(bytes) { const v = applyUpdate(bytes); setTimeout(() => { quitting = true; flush(); app.relaunch(); app.exit(0); }, 800); return v; },
    resetUpdate() { fs.rmSync(UPD(), { recursive: true, force: true }); setTimeout(() => { quitting = true; flush(); app.relaunch(); app.exit(0); }, 800); return app.getVersion(); }
  }
};
ipcMain.handle('kc', async (e, ns, method, args) => {
  const f = API[ns] && API[ns][method];
  if (!f) throw new Error(`지원하지 않는 기능: ${ns}.${method}`);
  return f.apply(API[ns], args || []);
});
ipcMain.on('kc-sync', (e, what) => { e.returnValue = what === 'root' ? ROOT : app.getVersion(); });

// ---------- 3.1: 자동 업데이트 (GitHub 릴리스) ----------
// 켤 때와 6시간마다 새 버전이 있는지 보고, 화면·기능 파일 업데이트는 혼자 받아서 바꿔요.
// 프로그램 뼈대(설치 파일)까지 바뀐 버전이면 설치 파일 받기 버튼을 띄워요.
const UPDATE_URL = process.env.KC_UPDATE_URL || 'https://raw.githubusercontent.com/chldydrnr2-eng/kream-scanner/main/updates/latest.json';
let updState = { state: 'idle', version: '', msg: '' };
function updBroadcast() { for (const w of BrowserWindow.getAllWindows()) { try { if (!w.isDestroyed() && w.webContents.getURL().startsWith('file:')) w.webContents.send('kc-update', updState); } catch (e) {} } }
async function checkUpdate(manual) {
  try {
    updState = { state: 'checking', version: VER, msg: '' }; if (manual) updBroadcast();
    const r = await net.fetch(UPDATE_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error('업데이트 정보를 못 받았어요 (' + r.status + ')');
    const j = await r.json();
    if (!j.version || cmpVer(j.version, VER) <= 0) { updState = { state: 'latest', version: VER, msg: '' }; if (manual) updBroadcast(); return updState; }
    if (j.shell && cmpVer(j.shell, app.getVersion()) > 0) { updState = { state: 'installer', version: j.version, url: j.installer, msg: j.notes || '' }; updBroadcast(); return updState; }
    const z = await net.fetch(j.appZip, { cache: 'no-store' });
    if (!z.ok) throw new Error('업데이트 파일을 못 받았어요 (' + z.status + ')');
    const v = applyUpdate(Buffer.from(await z.arrayBuffer()));
    updState = { state: 'ready', version: v, msg: j.notes || '' };
    updBroadcast();
    // 창이 안 보이면(트레이에서 도는 중) 하던 일이 없을 때 바로 다시 켜요
    if (!appWin || appWin.isDestroyed() || !appWin.isVisible()) setTimeout(() => restartForUpdate(), 3000);
    else notify('크림스캐너 새 버전 ' + v, '업데이트를 받아 두었어요. 화면 위쪽 \'지금 다시 시작\'을 누르거나, 다음에 켤 때 적용돼요.');
    return updState;
  } catch (e) { updState = { state: 'error', version: VER, msg: String(e.message || e) }; if (manual) updBroadcast(); return updState; }
}
// 3.4.2: 로그인 유지 — 쇼핑몰이 '창 닫으면 지워지는 로그인 쿠키'를 주면, 프로그램을 껐다 켜거나(업데이트 재시작 포함) 할 때 로그인이 풀려요.
//        그런 쿠키를 30일짜리로 바꿔 저장해요 (크롬의 '로그인 상태 유지'와 같은 효과). 로그아웃하면 사이트가 지우는 대로 지워져요.
function keepLogins(ses) {
  ses.cookies.on('changed', (e, c, cause, removed) => {
    if (removed || !c || !c.session || !c.domain) return;
    try {
      const host = c.domain.replace(/^\./, '');
      const d = { url: (c.secure ? 'https://' : 'http://') + host + (c.path || '/'), name: c.name, value: c.value, path: c.path || '/', secure: !!c.secure, httpOnly: !!c.httpOnly, expirationDate: Math.floor(Date.now() / 1000) + 30 * 86400 };
      if (!c.hostOnly) d.domain = c.domain;
      if (c.sameSite && c.sameSite !== 'unspecified' && (c.sameSite !== 'no_restriction' || c.secure)) d.sameSite = c.sameSite;
      ses.cookies.set(d).catch(() => {});
    } catch (x) {}
  });
}
function flushCookies() { try { return Promise.race([session.fromPartition(PART).cookies.flushStore(), new Promise(r => setTimeout(r, 1500))]); } catch (e) { return Promise.resolve(); } }
async function restartForUpdate() { quitting = true; flush(); await flushCookies(); app.relaunch({ args: process.argv.slice(1).filter(a => a !== '--hidden').concat(appWin && appWin.isVisible() ? [] : ['--hidden']) }); app.exit(0); }
// 3.2: 로그인 상태를 보이지 않는 창으로 바로 확인 (작업 창·대기열과 따로)
API.app.probe = async o => {
  const w = new BrowserWindow({ show: false, width: 1200, height: 900, webPreferences: { partition: PART, contextIsolation: true, sandbox: true, backgroundThrottling: false } });
  w.webContents.setAudioMuted(true);
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-prevent-unload', e => e.preventDefault());
  try {
    await new Promise(res => { const t = setTimeout(res, 15000); w.webContents.once('dom-ready', () => { clearTimeout(t); setTimeout(res, 900); }); w.loadURL(o.url).catch(() => res()); });
    return await Promise.race([w.webContents.mainFrame.executeJavaScript(`(${o.func})()`, true), new Promise(r => setTimeout(() => r(null), 15000))]);
  } catch (e) { return null; }
  finally { try { w.destroy(); } catch (e) {} }
};
// 3.4.4: 사이트 화면이 비어서 나올 때 — 그 사이트의 서비스워커·캐시만 지워요 (로그인 쿠키는 그대로)
API.app.fixSite = async origin => {
  const ses = session.fromPartition(PART);
  try { await ses.clearStorageData({ origin, storages: ['serviceworkers', 'cachestorage'] }); } catch (e) {}
  try { await ses.clearCache(); } catch (e) {}
  return true;
};
API.app.checkUpdate = () => checkUpdate(true);
API.app.updateState = () => updState;
API.app.restartNow = () => { setTimeout(restartForUpdate, 300); return true; };
API.app.openInstaller = url => { shell.openExternal(url || 'https://github.com/chldydrnr2-eng/kream-scanner/tree/main/updates'); return true; };

// ---------- 시작 ----------
app.on('second-instance', () => showMain());
app.on('activate', () => showMain());   // 맥: Dock 아이콘을 누르면 다시 열기
app.on('before-quit', () => { quitting = true; flush(); try { session.fromPartition(PART).cookies.flushStore(); } catch (e) {} });
app.on('window-all-closed', () => { /* 트레이에 남아요 */ });
app.whenReady().then(() => {
  loadData();
  const shop = session.fromPartition(PART);
  shop.setUserAgent(UA);
  shop.setPermissionRequestHandler((wc, perm, cb) => cb(perm === 'notifications' ? false : perm === 'clipboard-sanitized-write'));
  keepLogins(shop);
  try {
    tray = new Tray(nativeImage.createFromPath(ICON).resize({ width: 16, height: 16 }));
    tray.setToolTip('크림스캐너');
    const menu = () => Menu.buildFromTemplate([
      { label: '크림스캐너 열기', click: showMain },
      { label: 'Windows 시작할 때 실행', type: 'checkbox', checked: app.getLoginItemSettings().openAtLogin, click: it => app.setLoginItemSettings({ openAtLogin: it.checked, args: ['--hidden'] }) },
      { type: 'separator' },
      { label: '종료', click: () => { quitting = true; app.quit(); } }
    ]);
    tray.setContextMenu(menu()); tray.on('click', showMain);
  } catch (e) {}
  alarmsRestore();
  setTimeout(() => checkUpdate(false), 8000); setInterval(() => checkUpdate(false), 6 * 3600000);
  if (!process.argv.includes('--hidden')) showMain();
  else { appWin = createAppWin('', false); appWin.on('close', e => { if (!quitting) { e.preventDefault(); appWin.hide(); } }); }
});

};
