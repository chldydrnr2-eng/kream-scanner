'use strict';
/* 개선판 1-3 · 1-3-1 · 1-6 — 소싱 실행 엔진 (결과 화면은 srcres.js 의 renderSrcResult 가 #srcResult 를 채워요)
   저장: srcRun(실행 상태 · 이어서 하기 cursor) · srcRows(결과, 품번 하나 = 행 하나) · srcScheds(예약 여러 개) · srcScope(수집 범위) · srcCalc(수익 계산)
   흐름(상품 소싱): 켜 둔 매입처 모듈마다 목록(품목 · 브랜드 · 페이지)을 끝까지(상한) 넘겨 수집 → 품번으로 합침 → KREAM · POIZON 시세 조회
   기존 '크림 인기 상품 · 무신사 랭킹 · 사이트 랭킹 · 키워드 · 목록 조사'는 [지금 실행 ▾]의 '인기 상품 소싱 · 품번 조회'로 그대로 돌리고, 결과를 srcRows 로 옮겨요.
   사이트 접속은 전부 SE_IO 를 거쳐요 — 시험 때는 SE_IO 를 가짜 함수로 바꿔 흐름(수집 → 조회 → 저장 → 중단 → 다시 켜기 → 이어서 하기)을 봐요. */

// ---------- 기준값 ----------
const SE_KINDS = { product: '상품 소싱', popular: '인기 상품 소싱', collect: '매입처만 수집', code: '품번 조회' };
const SE_KIND_SUB = { product: '켜 둔 매입처 상품을 전부 모아 시세와 비교해요', popular: '크림 인기 상품 · 랭킹 · 키워드에서 출발해요', collect: '시세 조회 없이 매입처 상품만 모아요', code: '넣은 품번 · 링크만 조사해요' };
const SE_POP = { kream: '크림 인기 상품', ms: '무신사 랭킹', rank: '렉스몬드·4910·W컨셉·지그재그 랭킹', kw: '키워드' };
const SE_CATS = { shoes: ['신발', '신발'], wear: ['의류', '의류'], bag: ['가방·잡화', '가방'], beauty: ['화장품', '화장품'] };
const SE_GRPS = { direct: '직매입', official: '공식몰', mall: '입점몰', rare: '수익 드문 곳' };
const SE_BRANDS = ['나이키', '조던', '아디다스', '뉴발란스', '아식스', '오니츠카타이거', '푸마', '컨버스', '반스', '살로몬', '호카', '노스페이스'];
const SE_SELLERS = { kream: 'KREAM', poizon: 'POIZON' };
// 설정 › 수집 범위의 주요 브랜드 칩 (25번 순서)
const SE_BRANDS_UI = ['나이키', '아디다스', '뉴발란스', '아식스', '푸마', '반스', '컨버스', '호카', '살로몬', '크록스', '버켄스탁', '어그', '닥터마틴', '리복', '언더아머', '스케쳐스'];
// 판매처는 POIZON · KREAM 차례로 보여요 (01번)
const seSellTxt = a => ['poizon', 'kream'].filter(k => (a || []).includes(k)).map(k => SE_SELLERS[k]).join(' · ');
// 기존 매입처 목록(app.js SRC_SITES)에 묶음을 붙여요. 여기 없는 곳은 '준비 중'
const SE_GRP = { nike: 'official', adidas: 'official', nb: 'official', asics: 'official', puma: 'official', converse: 'official', vans: 'official', tnf: 'official',
  musinsa: 'direct', rexmonde: 'direct', lotte: 'direct', ssg: 'direct', abc: 'direct', gs: 'direct', shoemarker: 'direct',
  coupang: 'mall', gmarket: 'mall', '11st': 'mall', zigzag: 'mall', '4910': 'mall', wconcept: 'mall',
  '29cm': 'rare', ssf: 'rare', ably: 'rare' };
// 목록 다음 쪽 주소의 이름 (확인 못 한 곳은 page — 같은 상품만 다시 나오면 거기서 멈춰요)
const SE_PG = { ssf: 'currentPage', '11st': 'pageNo', shoemarker: 'page', lotte: 'page', ssg: 'page', gmarket: 'p' };
// 나머지 매입처는 srcsup.js(SE_SUP) — 처음 수집할 때 검색 주소를 스스로 찾아요
const SE_SOON = [['lotte-m', '롯데ON 일반 판매자', 'mall'], ['ssg-m', 'SSG 일반 판매자', 'mall']];
const SE_SCOPE_DEF = { cats: ['shoes', 'wear', 'bag', 'beauty'], brands: [], groups: { official: true, direct: true, mall: false, rare: false }, mine: [], off: [], maxPages: 20, maxItems: 3000 };
const SE_CALC_DEF = { sellers: ['kream'], minWon: 0, minRate: 0, min30: 5, unknownStock: false, vatRefund: true, rec: { div: 3, max: 5, bidHalf: true } };
// 10장: 사이트마다 요청 간격(ms). 3.36.9: KREAM 시세 조회는 창 3개로 동시에 — 간격은 창 전체를 합쳐서 지켜요(페이지 열기 1.2~1.8초에 1번)
const SE_GAP = { kream: 1200, poizon: 3500, def: 2500 };
const SE_KW = 3;                 // 시세 조회 동시 창 수
const SE_KTTL = 6 * 3600e3;      // 같은 품번 KREAM 결과를 다시 쓰는 시간
// 모델 번호(품번)처럼 생긴 것만 KREAM 에서 찾아요 — 숫자만 있는 건 매입처 상품 번호라서 빼요(예: 무신사 4371012)
const seModel = c => { const s = String(c || '').trim(); return /[A-Z]/i.test(s) ? /\d/.test(s) && s.replace(/[^0-9A-Z]/gi, '').length >= 5 : /[-\s]/.test(s) && /\d{3,}/.test(s); };

const SE = { scope: { ...SE_SCOPE_DEF }, calc: { ...SE_CALC_DEF }, run: null, rows: [], idx: new Map(), scheds: [], busy: false, stop: false, gen: 0,
  supUrl: {}, saveT: null, dirty: new Set(), rq: new Map(), rqBusy: false, lastReq: {}, msg: '', cap: null, tick: null, legacy: null,
  slots: [], kpid: null, kcache: new Map(), kSlow: 1, kOk: 0, kFail: 0, cMsg: '', qMsg: '' };

// ---------- 매입처 모듈 ----------
// 공통 인터페이스: { k, label, grp, ready, brand?, listUrl(q, page) → 주소, stock?(buy) → 사이즈별 재고 }
// 목록은 기존 '전체 매입처 찾기'의 카드 읽기(kcFind)로 읽고 상품명 · 사진 · 링크 글자에서 품번을 뽑아요(codeCands).
function seMods() {
  const out = [];
  const sites = typeof SRC_SITES !== 'undefined' ? SRC_SITES : [];
  for (const s of sites) {
    const grp = SE_GRP[s.k]; if (!grp) continue;
    const pk = SE_PG[s.k] || 'page';
    out.push({ k: s.k, label: s.label, grp, ready: true, brand: s.brand || null, trust: s.split ? s.trust : null,
      listUrl: (q, page) => { const u = s.url(encodeURIComponent(q)); return page > 1 ? u + (u.includes('?') ? '&' : '?') + pk + '=' + page : u; },
      stock: s.k === 'musinsa' ? 'musinsa' : null });
  }
  if (typeof SE_SUP !== 'undefined') for (const [k, label, grp, home, brand, hint] of SE_SUP) {
    out.push({ k, label, grp, ready: true, sup: true, home, hint: hint || '', brand: brand || null,
      listUrl: (q, page) => { const t = (SE.supUrl[k] || {}).url; if (!t) return ''; const u = t.replace('{q}', encodeURIComponent(q)); return page > 1 ? u + (u.includes('?') ? '&' : '?') + 'page=' + page : u; } });
  }
  for (const [k, label, grp] of SE_SOON) out.push({ k, label, grp, ready: false });
  for (const [i, m] of (SE.scope.mine || []).entries()) {
    if (!m || m.k || !/^https?:\/\//.test(m.url || '')) continue;
    out.push({ k: 'mine' + i, label: m.label || '내 매입처', grp: 'mine', ready: true, mine: true, on: m.on !== false,
      listUrl: (q, page) => { const u = String(m.url).replace(/\{q\}/g, encodeURIComponent(q)); return page > 1 ? u + (u.includes('?') ? '&' : '?') + 'page=' + page : u; } });
  }
  return out;
}
// 이번 실행에 쓸 모듈 — groups: 묶음 켜기(설정) 또는 예약의 묶음 배열
function seActiveMods(groups) {
  const g = Array.isArray(groups) ? Object.fromEntries(Object.keys(SE_GRPS).map(k => [k, groups.includes(k)])) : (SE.scope.groups || {});
  const off = new Set(SE.scope.off || []), mk = new Set((SE.scope.mine || []).filter(x => x && x.k && x.on !== false).map(x => x.k));
  return seMods().filter(m => m.ready && (m.mine ? m.on : mk.has(m.k) || (!off.has(m.k) && g[m.grp])));
}
function seGrpCount(grp) { const all = seMods().filter(m => m.grp === grp), off = new Set(SE.scope.off || []); return { on: all.filter(m => m.ready && !off.has(m.k)).length, all: all.length }; }

// ---------- 사이트 접속 (시험 때 바꿔 끼워요) ----------
const seKey = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
const SE_IO = {
  // 목록 한 쪽 → { cards:[{text, alt, hrefs, url, price, img, soldOut}] }
  async list(mod, url) { const tabId = await srcNav(url); return await srcRead(tabId); },
  // 품번 → { pid, raw, img, name } | { need:true, cands:[…] } | null
  // 3.36.9: 돌려주는 값 { pid, raw, … } | { skip } | { nocode } | null(못 찾음). slot = 이 조회 전용 창, tm = 단계별 시간(ms)
  async kream(row, pre, slot, tm) {
    tm = tm || {};
    const codes = (row.codes || [row.code]).filter(seModel).slice(0, 2);
    if (!codes.length) return { nocode: true };
    if (!SE.kpid) { try { SE.kpid = (await store.get('srcKPid', {})) || {}; } catch (e) { SE.kpid = {}; } }
    for (const code of codes) {
      const K = seKey(code), hit = SE.kpid[K];
      let list;
      if (hit && hit.card && Date.now() - hit.at < 3 * 864e5) list = [hit.card];   // 3일 안에 찾은 품번은 검색을 건너뛰어요
      else {
        await seGap('kream', tm); let t = Date.now();
        // KREAM 검색 화면은 '다 불러옴' 신호가 20초 넘게 안 오는 일이 많아요(실측 11/21) — 주소가 이 품번으로 바뀌고 문서가 왔거나 1.2초 지나면 바로 읽어요
        let since = 0; const want = encodeURIComponent(code);
        const tabId = await srcNav(`https://kream.co.kr/search?keyword=${want}`, slot, { ready: x => { if (!String(x.url || '').includes('keyword=' + want)) return false; since = since || Date.now(); return !!x.dom || Date.now() - since > 1200; } });
        tm.search = (tm.search || 0) + (Date.now() - t); t = Date.now();
        const [r] = await execT({ target: { tabId }, func: kcList, args: [5, true] });
        tm.list = (tm.list || 0) + (Date.now() - t);
        list = (r && r.result) || []; if (!list.length) continue;
      }
      // 3.36.9: 검색 카드만 봐도 못 남길 상품이면 거래 내역을 안 받아요
      const skip = pre ? seKreamPre(list, row, pre) : ''; if (skip) return { skip };
      await seGap('kream', tm);
      const p = { id: 'se' + list[0].pid, pid: list[0].pid, cost: 0, size: '', raw: null };
      await collectOne(p, { days: 90, maxPages: 4, fast: true, slot, tm });
      const info = (p.raw && p.raw.info) || {};
      const kc = String(info.code || '').split(/[\/,]/).map(seKey).filter(Boolean);
      const keep = () => { SE.kpid[K] = { at: Date.now(), card: list[0] }; SE.kpidDirty = true; };
      if (kc.some(c => c === K || c.includes(K) || K.includes(c) && c.length >= 6)) { keep(); return { pid: list[0].pid, raw: p.raw, img: list[0].img, name: info.name || list[0].name }; }
      // 앞 6자리(모델)는 같은데 색 번호가 다르면 '확인 필요' — 사용자가 매입처 사진으로 같은 상품을 골라요
      if (K.length >= 6 && kc.some(c => c.slice(0, 6) === K.slice(0, 6))) { keep(); return { pid: list[0].pid, raw: p.raw, img: list[0].img, name: info.name || list[0].name, close: true }; }
    }
    return null;
  },
  // 품번 → { url, sizes:{ '250': {price} } } | null
  async poizon(row, slot) {
    const code = (row.codes || [row.code]).filter(seModel)[0] || row.code;
    const tabId = await srcNav(`https://kr.poizon.com/search?keyword=${encodeURIComponent(code)}`, slot);
    await sleep(1500);
    const [r] = await execT({ target: { tabId }, func: kcPoizonLinks, args: [] });
    for (const l of ((r && r.result) || []).slice(0, 2)) {
      await seGap('poizon');
      const t2 = await srcNav(l.url, slot);
      const [z] = await execT({ target: { tabId: t2 }, func: kcPoizon, args: [] });
      const res = z && z.result; if (!res || !res.sizes.length) continue;
      if (!seKey(res.title + ' ' + res.name).includes(seKey(code))) continue;
      const sizes = {}; for (const s of res.sizes) if (s.price) sizes[s.kr] = { price: s.price, n30: null, trades: null };
      return { url: res.url, sizes };
    }
    return null;
  },
  // 매입처 사이즈별 재고 → { total, by } | null (지금은 무신사만 — 무신사 화면이 쓰는 주소)
  async stock(buy, slot) {
    const m = String(buy.url || '').match(/musinsa\.com\/(?:app\/goods|products)\/(\d+)/); if (!m) return null;
    const tabId = await srcNav(buy.url, slot);
    const [r] = await execT({ target: { tabId }, func: kcMsStock, args: [m[1]] });
    const res = r && r.result; if (!res || !res.sizes) return null;
    const by = {}; let total = 0;
    for (const s of res.sizes) { if (s.out) continue; const q = s.qty != null ? s.qty : (s.min || 1); by[s.size || s.label] = q; total += q; }
    return { total, by };
  },
  // 3.36.8: 매입처 상품 화면의 '로그인 없이 보이는' 쿠폰·혜택가 → { price|null, label, login, first } | null (content/find.js kcBenefit)
  async benefit(b, slot) {
    const tabId = await srcNav(b.url, slot);
    let last = null;
    for (const w of [1500, 2500]) { await sleep(w); const [r] = await execT({ target: { tabId }, func: kcBenefit, args: [{ ref: b.price }] }); last = (r && r.result) || last; if (last && last.price) break; }
    return last;
  },
  ready() { return HAS_CHROME && !!chrome.scripting; }
};
// 검색 카드(누적 거래 · 최저 즉시 구매가)로 거르기 — 카드가 여러 개면 모두 걸려야 건너뛰어요
// 누적 거래가 30일 판매 기준보다 적으면 30일 기준을 넘을 수 없고, 매입가가 최저 구매가의 1.5배 이상이면 어느 사이즈로도 남기 어려워요
function seKreamPre(list, row, pre) {
  const buy = Math.min(...(row.buy || []).map(b => +b.price).filter(x => x > 0)), min30 = +pre.min30 || 0, n = v => (+v || 0).toLocaleString('ko-KR');
  const why = list.map(c => {
    if (min30 > 0 && c.tx && +c.trades < min30) return `KREAM 누적 거래 ${n(c.trades)}건뿐이라 30일 판매 ${min30}건 기준에 못 미쳐서 시세 조회를 건너뛰었어요`;
    if (c.price && isFinite(buy) && buy >= c.price * 1.5) return `매입가 ${n(buy)}원이 KREAM 최저 구매가 ${n(c.price)}원보다 1.5배 이상 비싸서 시세 조회를 건너뛰었어요`;
    return '';
  });
  return why.every(Boolean) ? why[0] : '';
}
// 팔리는 상품인지 (KREAM 30일 거래가 있거나 POIZON 노출가가 있음)
function seSells(row) { return !!(row && (row.kream && Object.values(row.kream.sizes || {}).some(s => s.n30 > 0) || row.poizon && Object.keys(row.poizon.sizes || {}).length)); }
// 화면 쿠폰·혜택가 읽기 — 싼 매입처 2곳(다시 조회에서 고른 곳은 늘), 쿠폰 40%를 받아도 못 남길 곳·검색 주소는 건너뛰고, 같은 가격이면 12시간 안엔 다시 안 읽어요
const SE_SEARCH_URL = /[?&](q|keyword|query|searchWord|schWord|search_keyword|search_text|SearchWord|kwd)=/i;
async function seBenefitRow(row, o) {
  o = o || {};
  const sellMax = Math.max(0, ...Object.values((row.kream && row.kream.sizes) || {}).map(s => Math.max(+s.ask || 0, +s.bid || 0)), ...Object.values((row.poizon && row.poizon.sizes) || {}).map(s => +s.price || 0));
  const cand = (row.buy || []).filter(b => b && b.on !== false && b.price > 0 && /^https?:\/\//.test(b.url || '') && !SE_SEARCH_URL.test(b.url) && b.price * 0.6 <= sellMax).sort((a, b) => a.price - b.price);
  const pick = cand.slice(0, 2);
  if (o.site) { const x = cand.find(b => b.site === o.site); if (x && !pick.includes(x)) pick.push(x); }
  for (const b of pick) {
    const z = b.benefit; if (z && z.base === b.price && Date.now() - z.at < 12 * 3600e3 && !(o.force && o.site === b.site)) continue;
    if (!o.force && seStopped()) break;
    try { await seGap(b.site); const r = await SE_IO.benefit(b, o.slot && o.slot.b); if (r) b.benefit = { price: r.price || null, label: r.label || '', base: b.price, at: Date.now(), login: !!r.login, all: !!r.all, pay: +r.pay || 0 }; } catch (e) {}
  }
}
// 3.36.9: 여러 창이 동시에 불러도 차례로 자리를 잡아요 · KREAM 이 거절하면 늦춰요
async function seGap(key, tm) {
  const gap = (SE_GAP[key] || SE_GAP.def) * (key === 'kream' ? SE.kSlow || 1 : 1), now = Date.now();
  const at = Math.max(now, SE.lastReq[key] || 0, key === 'kream' ? SE.restUntil || 0 : 0);
  SE.lastReq[key] = at + gap + Math.random() * gap * 0.5;
  if (at > now) await sleep(at - now);
  if (tm) tm.gap = (tm.gap || 0) + (Date.now() - now);
}
// KREAM 이 거절하면 간격을 두 배로(최대 4배), 20개 연속 괜찮으면 조금씩 되돌려요
function seKOk(ok) {
  if (ok) { if (++SE.kOk >= 20 && SE.kSlow > 1) { SE.kSlow = Math.max(1, SE.kSlow / 1.5); SE.kOk = 0; } }
  else { SE.kOk = 0; SE.kSlow = Math.min(4, (SE.kSlow || 1) * 2); }
}

// ---------- KREAM 원자료 → 사이즈별 숫자 ----------
function seKreamSizes(raw) {
  const sizes = {}; if (!raw) return sizes;
  const now = raw.ts || Date.now(), D = 864e5, day = t => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  const get = o => (sizes[o] = sizes[o] || { n14: 0, n30: 0, n90: 0, nFast30: 0, last: null, lastT: 0, ask: null, bid: null, asks: 0, asks5: 0, trades: [] });
  for (const s of raw.sales || []) {
    if (!s.t || !s.p) continue; const x = get(s.o || 'ONE'), age = now - s.t;
    if (age <= 14 * D) x.n14++;
    if (age <= 30 * D) { x.n30++; if (s.f) x.nFast30++; }
    if (age <= 90 * D) { x.n90++; if (x.trades.length < 40) x.trades.push({ d: day(s.t), p: s.p, size: s.o || '' }); }
    if (s.t > x.lastT) { x.lastT = s.t; x.last = day(s.t); }
  }
  for (const a of raw.asks || []) { const x = get(a.o || 'ONE'); if (x.ask == null || a.p < x.ask) x.ask = a.p; }
  for (const a of raw.asks || []) { const x = get(a.o || 'ONE'), q = a.q || 1; x.asks += q; if (x.ask != null && a.p <= x.ask * 1.05) x.asks5 += q; }
  for (const b of raw.bids || []) { const x = get(b.o || 'ONE'); if (x.bid == null || b.p > x.bid) x.bid = b.p; }
  const keys = Object.keys(sizes);
  if (keys.length === 1) { const x = sizes[keys[0]]; if (x.ask == null && raw.buyNow) x.ask = raw.buyNow; if (x.bid == null && raw.sellNow) x.bid = raw.sellNow; }
  for (const x of Object.values(sizes)) { delete x.lastT; x.trades.sort((a, b) => (a.d < b.d ? 1 : -1)); }
  return sizes;
}

// ---------- 결과 행 저장 ----------
function seRowsIndex() { SE.idx = new Map(SE.rows.map((r, i) => [r.id, i])); }
function seRowGet(id) { const i = SE.idx.get(id); return i == null ? null : SE.rows[i]; }
function seRowPut(row) {
  const i = SE.idx.get(row.id);
  if (i == null) { SE.idx.set(row.id, SE.rows.length); SE.rows.push(row); } else SE.rows[i] = row;
  row.at = Date.now(); SE.dirty.add(row.id); seSaveSoon();
}
// 최대 2초에 한 번 저장 + 'src:rows' 이벤트 (결과 화면이 다시 그려요)
function seSaveSoon(now) {
  if (SE.saveT && !now) return;
  clearTimeout(SE.saveT);
  SE.saveT = setTimeout(seFlush, now ? 0 : 2000);
}
// 결과 화면이 고친 행(사진 고르기 · 실행에 포함 토글)은 store 에 먼저 들어가요 — 더 새 행이면 그쪽 칸을 받아요
function seMergeRes(stored, ids) {
  const want = ids && ids.length ? new Set(ids) : null; const got = [];
  for (const s of Array.isArray(stored) ? stored : []) {
    if (!s || (want && !want.has(s.id))) continue;
    const m = seRowGet(s.id); if (!m || !((s.at || 0) > (m.at || 0))) continue;
    for (const k of ['need', 'cands', 'picked', 'buy', 'fav', 'hide']) if (k in s) m[k] = s[k];
    m.at = s.at; got.push(s.id);
  }
  return got;
}
async function seFlush() {
  SE.saveT = null;
  try { seMergeRes(await store.get('srcRows', []), null); } catch (e) {}
  const ids = [...SE.dirty]; SE.dirty.clear();
  try { await store.set('srcRows', SE.rows); } catch (e) { console.warn(e); }
  if (SE.run) { if (ids.length) SE.run.lastAt = Date.now(); try { await store.set('srcRun', SE.run); } catch (e) {} }
  if (ids.length) { try { window.dispatchEvent(new CustomEvent('src:rows', { detail: { ids } })); } catch (e) {} }
  sePaint();
}
async function seRunSave() { if (SE.run) await store.set('srcRun', SE.run); sePaint(); }

// ---------- 실행 ----------
function seCritSnap(sellers, groups) {
  const c = SE.calc, mods = seActiveMods(groups);
  return { sellers: (sellers && sellers.length ? sellers : c.sellers).slice(), minWon: +c.minWon || 0, minRate: +c.minRate || 0, min30: +c.min30 || 0, unknownStock: !!c.unknownStock,
    cats: (SE.scope.cats || []).slice(), brands: (SE.scope.brands || []).slice(), groups: Array.isArray(groups) ? groups.slice() : Object.keys(SE_GRPS).filter(k => (SE.scope.groups || {})[k]),
    sites: mods.length, maxPages: Math.max(1, Math.min(100, +SE.scope.maxPages || 20)), maxItems: Math.max(50, Math.min(20000, +SE.scope.maxItems || 3000)) };
}
function seCritTxt(c) {
  c = c || seCritSnap();
  const first = (c.sellers || []).includes('poizon') ? 'POIZON' : 'KREAM';
  return [seSellTxt(c.sellers), `최소 수익 ${(+c.minWon || 0).toLocaleString('ko-KR')}원`, c.minRate ? `최소 수익률 ${c.minRate}%` : '', `${first} 30일 ${+c.min30 || 0}개 이상`].filter(Boolean).join(' · ');
}
// o = { kind, sellers?, groups?, sub?, kw?, list?, sched? }
async function seStart(o) {
  o = o || {}; const kind = SE_KINDS[o.kind] ? o.kind : 'product';
  if (SE.busy) return seSay('이미 실행 중이에요');
  if (typeof opsBlock === 'function' && OPS.halt) return seSay('긴급 정지 중이라 실행하지 않았어요 — 설정 › 일반에서 다시 시작해 주세요');
  if (typeof canUse === 'function' && !canUse('find')) return seSay('이 이용권에서는 소싱을 쓸 수 없어요');
  const crit = seCritSnap(o.sellers, o.groups);
  if ((kind === 'product' || kind === 'collect') && !crit.sites) return seSay('켜 둔 매입처가 없어요 — 설정 › 수집 범위에서 묶음을 켜 주세요');
  if ((kind === 'product' || kind === 'collect') && !crit.cats.length) return seSay('품목을 하나 이상 골라 주세요 — 설정 › 수집 범위');
  if (kind === 'code' && !String(o.list || '').trim()) return seSay('조사할 품번을 넣어 주세요');
  if (kind === 'popular' && o.sub === 'kw' && !String(o.kw || '').trim()) return seSay('검색할 키워드를 넣어 주세요');
  if (!SE_IO.ready()) return seSay('킥스캔 프로그램 안에서만 실행할 수 있어요');
  const mods = seActiveMods(o.groups);
  SE.run = { id: 'r' + Date.now(), kind, sub: o.sub || '', kw: o.kw || '', list: o.list || '', sched: o.sched || null, startedAt: Date.now(), endedAt: null, state: 'run', crit, stage: kind === 'popular' || kind === 'code' ? 'legacy' : 'collect',
    sites: kind === 'product' || kind === 'collect' ? mods.map(m => ({ k: m.k, label: m.label, done: false, n: 0 })) : [],
    counts: { sites: kind === 'product' || kind === 'collect' ? mods.length : 0, sitesDone: 0, items: 0, quoted: 0, quoteTotal: 0, kream: 0, poizon: 0, pages: 0 },
    cursor: { si: 0, qi: 0, page: 1, ri: 0 }, spent: 0, err: '', why: '' };
  // 새 실행은 결과를 새로 채워요. '신규 수익 상품' 표시를 위해 예전 firstAt 은 따로 기억해요
  await seKeepFirst();
  // 3.36.9: 지난 결과 중 6시간 안의 KREAM 결과는 같은 품번에 다시 써요
  try { const prev = (await store.get('srcRows', [])) || []; SE.kcache = new Map(prev.filter(r => r && r.id && r.kream && r.kream.at && !r.kream.skip && Date.now() - r.kream.at < SE_KTTL).map(r => [r.id, { kream: r.kream, pid: r.pid, kimg: r.kimg, kname: r.kname, need: !!r.need && !r.picked, needWhy: r.needWhy || '', cands: r.cands || [] }])); } catch (e) { SE.kcache = new Map(); }
  SE.rows = []; seRowsIndex(); await store.set('srcRows', SE.rows);
  try { window.dispatchEvent(new CustomEvent('src:rows', { detail: { ids: [], reset: true } })); } catch (e) {}
  await seRunSave(); seRender();
  return seGo();
}
async function seResume() {
  const R = SE.run; if (!R || R.state !== 'stop' || SE.busy) return;
  R.state = 'run'; R.err = ''; R.why = ''; R.stoppedAt = null;
  if (R.stage === 'legacy') {
    // 예전 찾기의 남은 후보: 이 창에 있으면 그대로, 없으면(껐다 켬) 저장해 둔 것. 그것도 없으면 같은 조건으로 다시 돌리고 모인 결과에 합쳐요
    if (typeof fdResume !== 'undefined' && !fdResume) { try { const sv = await store.get('srcLegacyRes', null); if (sv && sv.run === R.id && sv.res) fdResume = sv.res; } catch (e) {} }
    await seRunSave();
    return seGo(typeof fdResume !== 'undefined' && !!fdResume);
  }
  await seRunSave();
  return seGo();
}
function seGo(legacyResume) {
  SE.busy = true; SE.stop = false; seRender();
  const legacy = SE.run.stage === 'legacy';
  seSay(jobBusy ? '앞의 작업이 끝나면 시작해요…' : '');
  const body = async () => {
    SE.gen = jobGen; SE.runT0 = Date.now();
    try {
      if (SE.run.stage === 'legacy') await seLegacy(SE.run, legacyResume);
      else {
        // 3.36.9: 매입처 수집이 끝나길 기다리지 않고, 수집된 상품부터 바로 시세를 조회해요
        if (SE.run.stage === 'collect' && SE.run.kind === 'collect') await seCollect();
        else if (SE.run.stage === 'collect') {
          let col = true, cErr = null;
          const pc = seCollect().catch(e => { cErr = e; SE.stop = true; }).finally(() => { col = false; });
          await Promise.all([pc, seQuote(() => col)]);
          if (cErr) throw cErr;
        }
        if (SE.run.stage === 'quote' && SE.run.kind !== 'collect' && !seStopped()) await seQuote();
      }
      if (seStopped()) { SE.run.state = 'stop'; SE.run.stoppedAt = SE.run.lastAt || Date.now(); if (!SE.run.why) SE.run.why = SE.run.err ? 'err' : 'user'; seSay('멈췄어요 — [이어서 하기]로 이어서 할 수 있어요'); }
      else { SE.run.state = 'done'; SE.run.stage = 'done'; SE.run.endedAt = Date.now(); await seFinishFirst(); seSay(`끝났어요 — 수집 상품 ${SE.run.counts.items.toLocaleString('ko-KR')}개${SE.run.counts.newProfit ? ` · 신규 수익 상품 ${SE.run.counts.newProfit}개` : ''}`); }
    } catch (e) { console.warn(e); SE.run.state = 'stop'; SE.run.stoppedAt = SE.run.lastAt || Date.now(); SE.run.why = 'err'; SE.run.err = String(e.message || e).slice(0, 160); seSay('멈췄어요: ' + SE.run.err); }
    finally {
      SE.run.spent = (SE.run.spent || 0) + (Date.now() - SE.runT0); SE.runT0 = 0;
      SE.busy = false; await seFlush(); await seRunSave(); seRender();
      try { await seHistSave(); } catch (e) { console.warn(e); }
      if (typeof work !== 'undefined' && work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
      await seSlotsClose(); SE.cMsg = ''; SE.qMsg = '';
      if (typeof renderSrcResult === 'function') { try { renderSrcResult(); } catch (e) { console.warn(e); } }
      seAfterRun();
    }
  };
  // 예전 실행 종류는 자기가 작업 줄(queueJob)에 서니까 여기서는 줄에 안 서요 (서로 기다리며 멈추지 않게)
  if (legacy) return body();
  return queueJob(body, { label: '소싱 실행', noTimeout: true, onSkip: () => { SE.busy = false; if (SE.run) { SE.run.state = 'stop'; seRunSave(); } seRender(); } });
}
function seStopped() { return SE.stop || SE.gen !== jobGen || (typeof OPS !== 'undefined' && OPS.halt); }
function seStopNow() {
  if (!SE.busy) return;
  SE.stop = true; if (SE.run) SE.run.why = 'user'; seSay('지금 하던 것까지만 하고 멈출게요…');
  if (SE.run && SE.run.stage === 'legacy') { const b = $('#btnFindStop'); if (b) b.click(); }
}

// 1) 매입처 수집: 모듈마다 (브랜드 × 품목) 목록을 페이지 끝까지(상한) 넘겨요
function seQueries(mod, crit) {
  const cats = crit.cats.map(k => (SE_CATS[k] || [k, k])[1]);
  if (mod.mine) return [''];
  if (mod.brand) {   // 브랜드 공식몰: 그 브랜드를 고른 경우(또는 전체)만, 품목 낱말로 찾아요
    if (crit.brands.length && !crit.brands.some(b => mod.brand.test(b))) return [];
    return cats;
  }
  const brands = crit.brands.length ? crit.brands : SE_BRANDS;
  return brands.flatMap(b => cats.map(c => `${b} ${c}`));
}
async function seCollect() {
  const R = SE.run, crit = R.crit, mods = seMods(), C = R.cursor;
  for (; C.si < R.sites.length; C.si++, C.qi = 0, C.page = 1) {
    const st = R.sites[C.si], mod = mods.find(m => m.k === st.k);
    if (st.done) continue;
    if (!mod || !mod.ready) { st.done = true; R.counts.sitesDone++; continue; }
    const qs = seQueries(mod, crit);
    if (mod.sup && qs.length && !(SE.supUrl[mod.k] || {}).url) {   // 처음 보는 매입처 — 홈페이지에서 검색 주소부터 찾아요
      const t = await seSupFind(mod, qs[0]); if (seStopped()) return;
      if (!t) { R.err = `${mod.label}: 검색 주소를 못 찾아서 건너뛰었어요`; st.done = true; R.counts.sitesDone++; await seRunSave(); continue; }
    }
    for (; C.qi < qs.length; C.qi++, C.page = 1) {
      const seen = new Set();
      for (; C.page <= crit.maxPages; C.page++) {
        if (seStopped()) return;
        if (R.counts.items >= crit.maxItems) break;
        seSayC(`${mod.label} · ${qs[C.qi] || '목록'} ${C.page}쪽 읽는 중`);
        await seGap(mod.k);
        let res;
        try { res = await SE_IO.list(mod, mod.listUrl(qs[C.qi], C.page)); } catch (e) { R.err = `${mod.label}: ${String(e.message || e).slice(0, 80)}`; break; }
        R.counts.pages++;
        const fresh = seTakeCards(mod, res, crit, qs[C.qi], seen);
        seRunSaveSoon();
        if (!fresh || (res && res.noResult)) break;   // 새 상품이 없으면 마지막 쪽
      }
      if (R.counts.items >= crit.maxItems) break;
    }
    if (seStopped()) return;
    st.done = true; R.counts.sitesDone++; await seRunSave();
  }
  R.stage = 'quote'; R.cursor.ri = 0; R.counts.quoteTotal = SE.rows.filter(r => r.code).length; seSayC(''); await seRunSave();
}
// 카드 → 행(품번 단위로 합쳐요). 새로 본 카드 수를 돌려줘요
function seTakeCards(mod, res, crit, q, seen) {
  let fresh = 0; const R = SE.run;
  const brandOf = q && crit.brands.length ? crit.brands.find(b => q.startsWith(b)) : (q ? SE_BRANDS.find(b => q.startsWith(b)) : '');
  const catOf = Object.keys(SE_CATS).find(k => q && q.endsWith(SE_CATS[k][1])) || (crit.cats[0] || '');
  for (const c of (res && res.cards) || []) {
    const key = c.url || (c.text || '').slice(0, 80); if (!key || seen.has(key)) continue; seen.add(key); fresh++;
    if (!c.price || c.soldOut) continue;
    if (mod.trust && !mod.trust(c.text || '', c.hrefs || '')) continue;
    const codes = typeof codeCands === 'function' ? codeCands(`${c.text || ''} ${c.alt || ''} ${String(c.hrefs || '').replace(/[\/_-]/g, ' ')}`) : [];
    const name = typeof srcName === 'function' ? srcName(c.alt && c.alt.length > 5 ? c.alt : c.text) : String(c.alt || c.text || '').slice(0, 90);
    if (!codes.length) continue;   // 품번이 안 보이면 시세와 맞출 수 없어요
    if (typeof accessoryLike === 'function' && accessoryLike(name, { name: '' })) continue;
    const id = seKey(codes[0]);
    const old = seRowGet(id);
    const row = old || { id, code: codes[0], codes: codes.slice(), name, brand: brandOf || '', cat: catOf, img: c.img || '', pid: null, firstAt: (SE.first || {})[id] || null, at: 0, need: false, cands: [], buy: [], kream: null, poizon: null, err: '' };
    for (const x of codes) if (!row.codes.includes(x)) row.codes.push(x);
    if (!row.img && c.img) row.img = c.img;
    const nums = [...String(c.text || '').matchAll(/(\d{1,3}(?:,\d{3})+)\s*원?/g)].map(m => +m[1].replace(/,/g, '')).filter(n => n >= 10000);
    const list = nums.length ? Math.max(...nums) : null;
    const b = row.buy.find(x => x.site === mod.k && x.url === c.url);
    const nb = { site: mod.k, label: mod.label, url: c.url || '', list: list && list > c.price ? list : null, price: c.price, stock: null, stockAt: null, on: true, name, img: c.img || '' };
    if (b) Object.assign(b, { price: nb.price, list: nb.list }); else row.buy.push(nb);
    row.buy.sort((a, z) => a.price - z.price);
    if (!old) { R.counts.items++; R.counts.quoteTotal = R.counts.items; }
    R.counts.cards = (R.counts.cards || 0) + 1;
    const st = R.sites.find(s => s.k === mod.k); if (st) st.n++;
    seRowPut(row);
  }
  return fresh;
}
// 2) 시세 조회: 품번마다 KREAM(사이즈별 14·30·90일 · 최근 거래 · 판매 입찰) · POIZON(사이즈별 노출가)
function seSayQ(t) { SE.qMsg = t || ''; seSay([SE.cMsg, SE.qMsg].filter(Boolean).join('   ·   ')); }
function seSayC(t) { SE.cMsg = t || ''; seSay([SE.cMsg, SE.qMsg].filter(Boolean).join('   ·   ')); }
function seSlot(w) { return SE.slots[w] = SE.slots[w] || { k: { winId: null, tabId: null, part: '' }, p: { winId: null, tabId: null, part: '' }, b: { winId: null, tabId: null, part: '' } }; }
async function seSlotsClose() {
  for (const s of SE.slots) for (const x of [s.k, s.p, s.b]) if (x && x.winId) { try { await chrome.windows.remove(x.winId); } catch (e) {} }
  SE.slots = [];
  if (SE.kpidDirty) { SE.kpidDirty = false; try { const e = Object.entries(SE.kpid || {}).sort((a, b) => b[1].at - a[1].at).slice(0, 8000); SE.kpid = Object.fromEntries(e); await store.set('srcKPid', SE.kpid); } catch (e) {} }
}
// 3.36.9: 창 SE_KW 개가 동시에 조회해요. collecting() = 매입처 수집이 아직 도는지 — 돌면 새 상품이 들어오길 기다리며 같이 조회해요
async function seQuote(collecting) {
  const R = SE.run, sellers = R.crit.sellers || ['kream'];
  collecting = collecting || (() => false);
  SE.qT0 = Date.now(); SE.qN0 = R.counts.quoted || 0; SE.qp = 0; SE.kFail = 0;
  const next = () => { while (SE.qp < SE.rows.length) { const r = SE.rows[SE.qp++]; if (r && r.code && r.quotedRun !== R.id) return r; } return null; };
  const worker = async w => {
    const slot = seSlot(w);
    while (!seStopped()) {
      const row = next();
      if (!row) { if (collecting()) { await sleep(700); continue; } break; }
      seSayQ(`시세 조회 중 — ${String(row.name || row.code).slice(0, 28)}`);
      const r1 = await seQuoteRow(row, sellers, { kf: SE.kFail, slot });
      if (r1 === 'halt') { seRowPut(row); break; }
      SE.kFail = r1;
      row.quotedRun = R.id;
      R.counts.quoted++; { const d = R.counts.quoted - SE.qN0; if (d >= 3) R.qPer = Math.round((Date.now() - SE.qT0) / d); }
      seRowPut(row); seRunSaveSoon();
      // 오래 도는 실행: KREAM 100개마다 모든 창이 15초 쉬어요
      const k100 = Math.floor((R.counts.kream || 0) / 100);
      if (k100 > (SE.rest100 || 0)) { SE.rest100 = k100; SE.restUntil = Date.now() + 15000; }
      // 결과 화면에서 다시 조회를 누른 행은 사이에 끼워서 해요 (첫 창이 맡아요)
      while (w === 0 && SE.rq.size && !seStopped()) { const [id, site] = SE.rq.entries().next().value; SE.rq.delete(id); const r2 = seRowGet(id); if (r2 && r2.code) { await seQuoteRow(r2, sellers, { site, force: true, slot }); seRowPut(r2); } }
    }
  };
  SE.rest100 = Math.floor((R.counts.kream || 0) / 100);
  await Promise.all(Array.from({ length: SE_KW }, (_, w) => worker(w)));
  seSayQ('');
}
// 한 행 조회 — 돌려주는 값: KREAM 연속 실패 수, 또는 'halt'(멈춰야 함)
async function seQuoteRow(row, sellers, o) {
  o = o || {}; const R = SE.run || { counts: {} }; let kFail = o.kf || 0;
  const errs = [];
  {
    const C = R.counts || {}, tm = {}, t0 = Date.now();
    // 3.36.9: 6시간 안에 조회한 같은 품번(지난 실행 결과)은 다시 쓰고 KREAM 에 안 물어봐요
    const hit = !o.force && SE.kcache.get(row.id);
    if (sellers.includes('kream') && hit && hit.kream) {
      Object.assign(row, { pid: hit.pid, kimg: hit.kimg, kname: hit.kname, kream: hit.kream }); if (!row.img && hit.kimg) row.img = hit.kimg;
      if (!row.picked) { row.need = !!hit.need; row.needWhy = hit.needWhy || ''; row.cands = hit.need ? (hit.cands || []) : []; }
      C.kcache = (C.kcache || 0) + 1;
    }
    else if (sellers.includes('kream')) {
      try {
        const k = await SE_IO.kream(row, o.force ? null : ((SE.run && SE.run.crit) || null), o.slot && o.slot.k, tm);
        row.needWhy = '';
        if (k && k.skip) { row.kream = { at: Date.now(), sizes: {}, skip: k.skip }; kFail = 0; C.kpre = (C.kpre || 0) + 1; }
        else if (k && k.raw) {
          row.pid = k.pid; if (k.img) row.kimg = k.img; if (!row.img && k.img) row.img = k.img; if (k.name) row.kname = k.name; row.kream = { at: Date.now(), sizes: seKreamSizes(k.raw) }; kFail = 0;
          if (k.close && !row.picked) { row.need = true; row.cands = row.buy.map(b => ({ site: b.site, label: b.label, url: b.url, img: b.img || row.img || '', name: b.name || row.name, price: b.price, list: b.list })); }
          else if (!row.picked) { row.need = false; row.cands = []; }
        }
        // 품번이 없거나 KREAM 에서 못 찾으면 '확인 필요' 탭으로 — 품번을 확인하고 [다시 조회]할 수 있어요
        else if (!row.picked) { row.kream = null; row.need = true; row.cands = []; row.needWhy = k && k.nocode ? '모델 번호(품번)가 안 보여서 KREAM 에서 찾지 못했어요' : `KREAM 에서 품번 ${row.code} 을(를) 못 찾았어요`; C.knone = (C.knone || 0) + 1; }
        else row.kream = null;
        if (!o.force) R.counts.kream = (R.counts.kream || 0) + 1;
        seKOk(true);
      } catch (e) {
        errs.push('KREAM ' + String(e.message || e).slice(0, 60));
        if (/거절|로그인|화면을 안 줬/.test(e.message || '')) { kFail++; seKOk(false); }
        if (kFail >= 3 && SE.run && !o.force) { SE.run.err = 'KREAM이 요청을 계속 거절해서 멈췄어요 — 몇 시간 뒤 [이어서 하기]를 눌러 주세요'; SE.stop = true; }
      }
    }
    if (!o.force && seStopped()) return 'halt';
    if (sellers.includes('poizon')) {
      try { await seGap('poizon'); const z = await SE_IO.poizon(row, o.slot && o.slot.p); row.poizon = z ? { at: Date.now(), url: z.url, sizes: z.sizes } : null; if (!o.force) R.counts.poizon = (R.counts.poizon || 0) + 1; }
      catch (e) { errs.push('POIZON ' + String(e.message || e).slice(0, 60)); }
    }
    // 팔리는 상품만 매입처 사이즈 재고를 봐요 (요청 아끼기) · 다시 조회에서 매입처를 고르면 그곳은 늘 봐요
    const sells = seSells(row);
    // 3.36.8: 매입가는 매입처 화면에 보이는 쿠폰·혜택가까지 반영 (사장님 11/21)
    let t = Date.now();
    if (sells || o.site) await seBenefitRow(row, o);
    tm.benefit = Date.now() - t; t = Date.now();
    for (const b of row.buy || []) {
      if (!sells && !(o.site && b.site === o.site)) continue;
      if (!o.force && seStopped()) break;
      const mod = seMods().find(m => m.k === b.site); if (!mod || !mod.stock) continue;
      try { await seGap(b.site); const s = await SE_IO.stock(b, o.slot && o.slot.b); if (s) { b.stock = s; b.stockAt = Date.now(); } } catch (e) {}
    }
    tm.stock = Date.now() - t;
    row.err = errs.join(' · ');
    // 단계별 시간 합계 (KREAM 에 실제로 물어본 행만) — 진행 줄 툴팁에 1개당 평균으로 보여요
    if (tm.page || tm.search) { const T = R.tm = R.tm || { n: 0 }; T.n++; tm.total = Date.now() - t0; for (const [k2, v] of Object.entries(tm)) T[k2] = (T[k2] || 0) + v; }
  }
  return kFail;
}
// 결과 화면의 [다시 조회] · [수익 상품 다시 확인] · 확인 필요 사진 고르기 → 그 행만 다시 조회해요
// opt.site = 매입처 키면 그 매입처 재고도 다시 봐요. 실행이 시세 조회 중이면 그 사이에 끼워서 해요
function srcRequote(ids, opt) {
  ids = (Array.isArray(ids) ? ids : [ids]).filter(Boolean); if (!ids.length) return;
  for (const id of ids) SE.rq.set(id, (opt && opt.site) || SE.rq.get(id) || '');
  if (SE.busy && SE.run && SE.run.stage === 'quote') { seSay(`다시 조회 ${SE.rq.size}개를 지금 실행 사이에 끼워서 해요`); return; }
  if (SE.rqBusy) return;
  SE.rqBusy = true; seSay(`다시 조회 ${SE.rq.size}개 — ${jobBusy ? '앞의 작업이 끝나면 시작해요' : '시작해요'}`);
  queueJob(async () => { try { await seRequoteRun(); } finally { SE.rqBusy = false; await seFlush(); } }, { label: '소싱 다시 조회', onSkip: () => { SE.rqBusy = false; } });
}
async function seRequoteRun() {
  try { seMergeRes(await store.get('srcRows', []), [...SE.rq.keys()]); } catch (e) {}
  const sellers = (SE.run && SE.run.crit && SE.run.crit.sellers) || SE.calc.sellers || ['kream'];
  while (SE.rq.size) {
    if (typeof OPS !== 'undefined' && OPS.halt) return;
    const [id, site] = SE.rq.entries().next().value; SE.rq.delete(id);
    const row = seRowGet(id); if (!row || !row.code) continue;
    seSay(`다시 조회 — ${String(row.name || row.code).slice(0, 28)}`);
    await seQuoteRow(row, sellers, { site, force: true });
    seRowPut(row);
  }
  seSay('다시 조회했어요');
}
window.addEventListener('src:requote', e => { const d = (e && e.detail) || {}; srcRequote(d.ids || [], { site: d.site }); });
window.addEventListener('src:rows', async e => { const d = (e && e.detail) || {}; if (d.from !== 'res') return; try { seMergeRes(await store.get('srcRows', []), d.ids); } catch (x) {} });
let seRunT = null;
function seRunSaveSoon() { if (seRunT) return; seRunT = setTimeout(() => { seRunT = null; seRunSave(); }, 2000); }

// 3) 기존 실행 종류(인기 상품 소싱 · 품번 조회) — 예전 화면(숨김)의 실행을 그대로 쓰고 결과를 srcRows 로 옮겨요
async function seLegacy(R, resume) {
  const src = R.kind === 'code' ? 'list' : (SE_POP[R.sub] ? R.sub : 'kream');
  // 크림 수집 결과(사이즈별 거래)를 잡아 두려고 collectOne 을 잠깐 감싸요
  const cap = new Map(), orig = window.collectOne;
  window.collectOne = async function (p) { const r = await orig.apply(this, arguments); try { if (p && p.raw && p.pid) cap.set(String(p.pid), p.raw); } catch (e) {} return r; };
  SE.cap = cap;
  try {
    if (!resume) {
      const catMap = { shoes: ['shoes'], wear: ['outer', 'top', 'bottom'] };
      let cats = R.crit.cats.flatMap(k => catMap[k] || []); if (!cats.length) cats = ['shoes'];
      const mw = $('#f_minWon'), mp = $('#f_minPct'); if (mw) mw.value = R.crit.minWon ? R.crit.minWon.toLocaleString('ko-KR') : ''; if (mp) mp.value = R.crit.minRate || '';
      fdLoad({ src, cats, cand: FO.cand, min7: FO.min7, market: (R.crit.groups || []).includes('mall'), kw: R.kw, list: R.list });
      const t0 = Date.now();
      $('#fdGo').click();
      await sleep(400);
      if ($('#btnFindStop').hidden && !$(FD_SRC[src][0]).disabled && !(finder.at >= t0)) throw new Error(($('#fText') && $('#fText').textContent) || '시작하지 못했어요');
    } else $('#fdResume').click();
    let lastAt = 0, idle = 0, liveAt = 0;
    const liveSave = async () => { if (typeof fdLive === 'undefined' || !fdLive || fdLive.at === liveAt) return; liveAt = fdLive.at; try { await store.set('srcLegacyRes', { run: R.id, res: fdLive }); } catch (e) {} };
    // 예전 실행이 끝날 때까지 기다리며 결과를 모이는 대로 옮겨요
    while (true) {
      await sleep(1500);
      const busy = !$('#btnFindStop').hidden || $(FD_SRC[src][0]).disabled;
      const t = $('#fText') ? $('#fText').textContent : ''; if (t) seSay(t);
      const bar = $('#fBar'); R.legacyPct = bar ? parseFloat(bar.style.width) || 0 : 0;
      if (finder.at && finder.at !== lastAt) { lastAt = finder.at; seFromFinder(); }
      if (!busy) { if (++idle >= 2) break; } else idle = 0;
      seRunSaveSoon();
      if (Date.now() - (R.liveT || 0) > 20000) { R.liveT = Date.now(); await liveSave(); }
    }
    if (finder.at && finder.at !== lastAt) seFromFinder();
    if (finder.stage === '중지') SE.stop = true;
    try { await store.set('srcLegacyRes', typeof fdResume !== 'undefined' && fdResume ? { run: R.id, res: fdResume } : null); } catch (e) {}
    // 3.36.8: 인기 상품 소싱도 팔리는 상품은 매입처 상품 화면의 쿠폰·혜택가를 읽어 매입가에 반영해요
    for (const row of SE.rows) {
      if (seStopped()) break; if (!seSells(row)) continue;
      seSay(`쿠폰·혜택가 확인 — ${String(row.name || row.code).slice(0, 28)}`);
      await seBenefitRow(row, {}); seRowPut(row); seRunSaveSoon();
    }
  } finally { window.collectOne = orig; SE.cap = null; }
}
// 예전 찾기 결과(finder.items) → 행
function seFromFinder() {
  const R = SE.run, cap = SE.cap || new Map();
  for (const it of finder.items || []) {
    const code = String(it.code || '').split(/[\/,]/)[0].trim();
    const id = seKey(code) || (it.pid ? 'K' + it.pid : ''); if (!id) continue;
    const old = seRowGet(id);
    const raw = it.pid ? cap.get(String(it.pid)) : null;
    const sites = ((it.src && it.src.sites) || []).filter(s => s.level && s.min && s.tier !== 'platform');
    const buy = sites.map(s => ({ site: s.k, label: s.label, url: (s.items && s.items[0] && s.items[0].url) || s.searchUrl || '', list: null, price: s.min, stock: null, stockAt: null, on: true, name: (s.items && s.items[0] && s.items[0].name) || '', img: (s.items && s.items[0] && s.items[0].img) || '', weak: s.level === 'weak' }))
      .sort((a, b) => a.price - b.price);
    // 모델명만 맞은 매입처(품번이 안 보임)는 '확인 필요' — 사진으로 같은 상품을 골라요
    const weak = buy.filter(b => b.weak), strong = buy.filter(b => !b.weak);
    const row = Object.assign(old || { id, firstAt: (SE.first || {})[id] || null, need: false, cands: [], poizon: null }, {
      code, codes: String(it.code || '').split(/[\/,]/).map(s => s.trim()).filter(Boolean), name: it.name || code, brand: '', cat: it.cat || '', img: it.img || '', pid: it.pid || null,
      buy: old && old.picked ? old.buy : strong, kream: raw ? { at: Date.now(), sizes: seKreamSizes(raw) } : (old && old.kream) || null, err: it.err || '' });
    if (!(old && old.picked)) { row.need = !strong.length && weak.length > 0; row.cands = row.need ? weak.map(b => ({ site: b.site, label: b.label, url: b.url, img: b.img || row.img || '', name: b.name || row.name, price: b.price })) : []; }
    if (!old) R.counts.items++;
    seRowPut(row);
  }
  R.counts.quoted = R.counts.items; R.counts.quoteTotal = R.counts.items;
}

// '신규 수익 상품' — 처음 수익 상품이 된 시각(firstAt)을 기억해요 (계산은 결과 화면의 srcCalcRow)
async function seKeepFirst() {
  const F = SE.first || (await store.get('srcFirst', {})) || {};
  for (const r of SE.rows) if (r.firstAt && !F[r.id]) F[r.id] = r.firstAt;
  SE.first = F; await store.set('srcFirst', F);
}
async function seFinishFirst() {
  if (typeof srcCalcRow !== 'function') return;
  let nNew = 0; const calc = { ...SE.calc, ...((await store.get('srcCalc', {})) || {}) };
  const d = new Date(), env = { kFee: p => (typeof feeOf === 'function' ? feeOf(p) : Math.floor(p * 0.066)), pFee: p => (typeof pzFee === 'function' ? pzFee(p) : Math.floor(p * 0.1)),
    ship: typeof S !== 'undefined' ? (+S.ship || 0) : 0, pShip: 0, today: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` };
  for (const r of SE.rows) {
    let ok = false; try { const c = srcCalcRow(r, calc, env); ok = !!(c && c.profitable && !r.need); } catch (e) {}
    if (ok && !r.firstAt) { r.firstAt = Date.now(); nNew++; SE.dirty.add(r.id); }
  }
  SE.run.counts.newProfit = nNew;
  await seKeepFirst();
}

// ---------- 예약 (srcScheds, 여러 개) ----------
const SE_SCHED_DEF = { name: '', kind: 'product', sites: 'follow', sellers: ['kream'], mode: 'time', time: '03:00', days: [], every: 1, unit: 'h', max: 10, notify: 'new', on: true, last: 0, since: 0, n: 0 };
const seJsDays = d => (d && d.length ? d : [1, 2, 3, 4, 5, 6, 7]).map(x => +x % 7);
const seEveryH = sc => Math.max(1, +sc.every || 1) * (sc.unit === 'd' ? 24 : 1);
function seSchedNext(sc, now) {
  if (!sc.on) return null;
  if (sc.mode === 'interval') { if ((sc.n || 0) >= (sc.max || 50)) return null; return +sc.last ? +sc.last + seEveryH(sc) * 3600e3 : (+sc.since || now); }
  return typeof schedNext === 'function' ? schedNext({ time: sc.time, days: seJsDays(sc.days) }, now) : null;
}
function seSchedDue(sc, now) {
  if (!sc.on) return null;
  if (sc.mode === 'interval') { const t = seSchedNext(sc, now); return t != null && t <= now ? t : null; }
  return typeof schedDue === 'function' ? schedDue({ on: true, time: sc.time, days: seJsDays(sc.days), since: sc.since, last: sc.last }, now) : null;
}
async function seSchedSave() { await store.set('srcScheds', SE.scheds); sePaint(); }
async function seSchedTick() {
  if (SE.busy || document.body.classList.contains('lic-locked')) return;
  if (typeof canUse === 'function' && !canUse('find')) return;
  const now = Date.now();
  const sc = SE.scheds.find(s => seSchedDue(s, now) != null); if (!sc) return;
  if (typeof opsBlock === 'function' && opsBlock('sched')) return;
  const due = seSchedDue(sc, now);
  // 놓친 예약 실행이 꺼져 있으면 10분 넘게 지난 예약은 건너뛰어요 (설정 › 일반)
  if (typeof OPP !== 'undefined' && OPP.catchUp === false && now - due > 600e3) { sc.last = now; if (sc.mode === 'interval') sc.n = (sc.n || 0) + 1; await seSchedSave(); return; }
  if (typeof opsDefer === 'function' && await opsDefer(due)) return;
  if (typeof jobBusy !== 'undefined' && jobBusy) return;   // 다른 작업이 끝나면 다음 확인 때 돌려요
  sc.last = now; sc.n = (sc.n || 0) + 1; await seSchedSave();
  await seStart({ kind: sc.kind, sellers: sc.sellers, groups: sc.sites === 'follow' ? null : sc.sites, sub: sc.sub, kw: sc.kw, list: sc.list, sched: sc.id });
}
function seAfterRun() {
  const R = SE.run; if (!R || !R.sched) return;
  const sc = SE.scheds.find(s => s.id === R.sched); if (!sc) return;
  if (R.state !== 'done') { sc.lastFail = { at: Date.now(), why: R.err || '중간에 멈췄어요' }; seSchedSave(); if (sc.notify !== 'none' && typeof fdNotify === 'function') fdNotify(`소싱 예약 — ${sc.name || SE_KINDS[sc.kind]} 멈춤`, R.err || '중간에 멈췄어요. 소싱 화면에서 [이어서 하기]를 눌러 주세요'); return; }
  if (sc.lastFail) { delete sc.lastFail; seSchedSave(); }
  const n = R.counts.newProfit || 0;
  if (sc.notify === 'always' || (sc.notify === 'new' && n > 0)) { if (typeof fdNotify === 'function') fdNotify(`소싱 끝 — ${sc.name || SE_KINDS[sc.kind]}`, `${n ? `신규 수익 상품 ${n}개 · ` : ''}수집 상품 ${R.counts.items.toLocaleString('ko-KR')}개`); }
}
// 예전 소싱 예약(findSched 하나)을 새 예약으로 한 번 옮겨요
async function seMigrate() {
  if (await store.get('srcSchedMig', false)) return;
  const old = await store.get('findSched', null);
  if (!old) { await store.set('srcSchedMig', true); return; }
  const c = old.cond || {};
  if (old.on || (old.days && old.days.length && old.time && old.since)) {
    const kind = c.src === 'list' ? 'code' : 'popular';
    SE.scheds.push({ ...SE_SCHED_DEF, id: 's' + Date.now(), name: '기존 소싱 예약', kind, sub: c.src === 'list' ? '' : (SE_POP[c.src] ? c.src : 'kream'), kw: c.kw || '', list: c.list || '',
      sites: c.market ? ['direct', 'official', 'mall'] : ['direct', 'official'], mode: 'time', time: old.time || '09:00', days: (old.days || []).map(d => (+d === 0 ? 7 : +d)), on: !!old.on, since: old.since || Date.now(), last: old.last || 0 });
    await store.set('srcScheds', SE.scheds);
  }
  await store.set('findSched', { ...old, on: false });
  await store.set('srcSchedMig', true);
  try { if (typeof FS !== 'undefined') FS.on = false; } catch (e) {}
}

// ---------- 화면 ----------
function seSay(t) { SE.msg = t || ''; const m = $('#seMsg'); if (m) { m.textContent = SE.msg; m.hidden = !SE.msg; } }
const seDur = ms => { const m = Math.max(0, Math.round(ms / 60000)); return m >= 60 ? `${Math.floor(m / 60)}시간${m % 60 ? ` ${m % 60}분` : ''}` : `${m}분`; };
// 경과 · 걸린 시간 (01번 '17분 54초' · 03번 '15시간 47분')
const seDur2 = ms => { const s = Math.max(0, Math.round((+ms || 0) / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return h ? `${h}시간 ${m}분` : `${m}분 ${s % 60}초`; };
const se2 = n => String(n).padStart(2, '0');
const seT0 = t => { const d = new Date(t || Date.now()); return `${d.getMonth() + 1}.${se2(d.getDate())} ${se2(d.getHours())}:${se2(d.getMinutes())}`; };
const seHm = t => new Date(t || Date.now()).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
function sePct(R) {
  if (!R) return 0;
  if (R.state === 'done') return 100;
  if (R.stage === 'legacy') return Math.round(R.legacyPct || 0);
  const c = R.counts || {}, siteP = c.sites ? (c.sitesDone + (R.stage === 'collect' && R.cursor && R.cursor.qi ? 0.5 : 0)) / c.sites : 1;
  if (R.kind === 'collect') return Math.min(99, Math.round(siteP * 100));
  const qT = c.quoteTotal || c.items || 0, qP = qT ? Math.min(1, c.quoted / qT) : 0;
  // 3.36.9: 수집하면서 조회도 하니까, 수집 중엔 조회한 몫도 조금씩 올라가요
  return Math.min(99, Math.round(R.stage === 'collect' ? siteP * 30 + qP * siteP * 70 : 30 + qP * 70));
}
function seEta(R) {
  if (!R || R.state !== 'run') return '';
  const p = sePct(R), el = (R.spent || 0) + (SE.busy && SE.runT0 ? Date.now() - SE.runT0 : 0);
  // 3.36.9: 시세 조회는 이 단계에서 잰 상품당 시간으로 (전엔 매입처 수집 시간까지 나눠서 49시간처럼 나왔어요) · 3개 넘게 조회하기 전엔 안 보여요
  if (R.stage === 'quote') { const left = (R.counts.quoteTotal || R.counts.items) - R.counts.quoted; return left > 0 && R.qPer ? '약 ' + seDur(left * R.qPer) : ''; }
  if (p >= 3 && el > 60000) return '약 ' + seDur(el / p * (100 - p));
  return '';
}
// 진행 줄 (01 · 03번) — 왼쪽: 상태 · 시작 · 경과 · 매입처 · 판매처 · 수집 상품 / 오른쪽: KREAM 조회 · 단계 · 매입처 n/N곳 · 수집 상품 · % · 남은 시간
// live = 지금 실행(소싱 실행 화면), 아니면 지난 실행(소싱 이력)
function seProgParts(R, live) {
  const c = R.counts || {}, n = v => (+v || 0).toLocaleString('ko-KR'), crit = R.crit || {};
  const el = (R.spent || 0) + (live && SE.busy && SE.runT0 ? Date.now() - SE.runT0 : 0);
  const fail = live ? SE.rows.filter(r => r && r.err).length : (+R.fail || 0);
  let st;
  if (R.state === 'run') st = `<b class="se-st se-run">● ${live && !SE.busy ? '대기 중' : '실행 중'}</b>`;
  else if (R.state === 'done') st = '<b class="se-st se-done">● 완료</b>';
  else st = `<b class="se-st se-stop">${['중단', R.why === 'off' ? '킥스캔 꺼짐' : R.why === 'err' ? '오류로 멈춤' : '', fail ? `수집 실패 상품 ${n(fail)}개` : ''].filter(Boolean).join(' · ')}</b>`;
  const kindTxt = R.kind === 'product' ? '' : (SE_KINDS[R.kind] || '') + (R.kind === 'popular' ? ` (${SE_POP[R.sub] || SE_POP.kream})` : '');
  const cardTip = c.cards ? `매입처에서 읽은 상품 ${n(c.cards)}개 → 같은 품번을 합쳐 품번 ${n(c.items)}개` : '같은 품번은 하나로 합쳐 세요';
  const L = [st, kindTxt ? `<span>${esc(kindTxt)}</span>` : '', `<span>${seT0(R.startedAt)} 시작 · ${seDur2(el)}</span>`, c.sites ? `<span>매입처 ${n(c.sites)}곳</span>` : '',
    R.kind !== 'collect' ? `<span>${esc(seSellTxt(crit.sellers))}</span>` : '', `<span title="${esc(cardTip)}">수집 상품 ${n(c.items)}개</span>`].filter(Boolean).join('');
  const p = sePct(R), Rt = [], sellers = crit.sellers || [], tot = c.quoteTotal || c.items || 0;
  const it = (t, tip) => Rt.push(tip ? `<span class="se-tip" title="${esc(tip)}">${esc(t)}</span>` : esc(t));
  if (R.state === 'run') it(R.stage === 'collect' ? (R.kind === 'collect' ? '매입처 수집 중' : '매입처 수집 · 시세 조회 중') : R.stage === 'quote' ? '시세 조회 중' : R.kind === 'code' ? '품번 조회 중' : '인기 상품 수집 중');
  if (c.sites) it(`매입처 ${n(c.sitesDone)}/${n(c.sites)}곳`, '수집을 마친 매입처 / 켜 둔 매입처');
  if (R.kind !== 'collect' && R.stage !== 'legacy') {
    const T = R.tm || {}, avg = k => T.n && T[k] ? (T[k] / T.n / 1000).toFixed(1) + '초' : '';
    const steps = [['gap', '간격 대기'], ['search', '검색 열기'], ['list', '검색 읽기'], ['page', '상품 페이지 열기'], ['heal', '빈 화면 확인'], ['ask', '화면과 주고받기'], ['ready', '페이지 준비'], ['btn', '거래 내역 버튼'], ['sales', '체결 거래'], ['more', '더 불러오기'], ['asks', '판매 입찰'], ['bids', '구매 입찰'], ['benefit', '매입처 쿠폰'], ['stock', '매입처 재고']]
      .map(([k, l]) => avg(k) && `${l} ${avg(k)}`).filter(Boolean).join(' · ');
    const tip = [`조회할 품번 ${n(tot)}개 중 ${n(c.quoted)}개 조회 끝 — 같은 품번은 한 번만 조회해요`,
      [sellers.includes('kream') ? `KREAM ${n(c.kream)}개` : '', sellers.includes('poizon') ? `POIZON ${n(c.poizon)}개` : ''].filter(Boolean).join(' · '),
      [c.kpre ? `검색 카드로 거른 품번 ${n(c.kpre)}개` : '', c.kcache ? `6시간 안 결과를 다시 쓴 품번 ${n(c.kcache)}개` : '', c.knone ? `KREAM 에 없어 확인 필요로 보낸 품번 ${n(c.knone)}개` : ''].filter(Boolean).join(' · '),
      `창 ${SE_KW}개로 동시에 조회${R.qPer ? ` · 1개당 ${(R.qPer / 1000).toFixed(1)}초` : ''}`,
      steps ? `KREAM 에 물어본 ${n(T.n)}개의 한 개당 평균(창 하나 기준): ${steps}${T.total ? ` · 합계 ${avg('total')}` : ''}` : ''].filter(Boolean).join('\n');
    it(`시세 조회 ${n(c.quoted)} / ${n(tot)} 품번`, tip);
  }
  const tail = R.state === 'done' ? '' : [`${p}%`, live ? seEta(R) : ''].filter(Boolean).join(' · ');
  return { L, R: Rt.join(' · ') + (tail ? ` <span class="se-pc">${esc(tail)}</span>` : ''), p };
}
// 안내 줄('수집 중이에요' · 주황 '마지막 재고 재확인 전에 중단됐어요' + [수익 상품 다시 확인])은 결과 상자(srcres.js)가 run.state · run.stoppedAt 으로 그려요
function sePaint() {
  const R = SE.run;
  const crit = $('#seCrit'); if (crit) crit.innerHTML = `<b>이 실행의 기준</b> ${esc(seCritTxt(R && R.state !== 'done' && R.crit ? R.crit : null))}`;
  const go = $('#seGo'), more = $('#seGoMore'), rs = $('#seResume'), st = $('#seStop'), sb = $('#seSchedBtn');
  if (go) { go.disabled = SE.busy; more.disabled = SE.busy; }
  if (st) st.disabled = !SE.busy;
  if (rs) { const can = !SE.busy && R && R.state === 'stop'; rs.disabled = !can; rs.title = can ? `${SE_KINDS[R.kind]} — 멈춘 곳부터 이어서 해요` : '중단된 실행이 없어요'; }
  if (sb) { const n = SE.scheds.filter(s => s.on).length; sb.querySelector('.se-n').textContent = n ? String(n) : ''; }
  const box = $('#seProg'); if (!box) return;
  if (!R) { box.hidden = true; return; }
  box.hidden = false;
  const P = seProgParts(R, true);
  // 툴팁을 보는 동안엔 그 칸을 다시 그리지 않아요 (1초마다 다시 그리면 툴팁이 사라져서)
  const put = (id, h) => { const el = $(id); if (el && !el.matches(':hover') && el.innerHTML !== h) el.innerHTML = h; };
  put('#seProgL', P.L); put('#seProgR', P.R); $('#seBar').style.width = P.p + '%';
  box.classList.toggle('stop', R.state === 'stop');
  if (R.err && !SE.busy && !SE.msg) seSay(R.err);
  if (SE.busy && typeof jobSay === 'function') jobSay(`${P.p}%`);
}
function seRender() { sePaint(); }
// 수익 계산(결과 화면의 srcCalcRow)으로 수익 상품 고르기 — 소싱 이력 · [수익 상품 다시 확인]에 써요
function seCalcEnv() {
  const d = new Date();
  return { kFee: p => (typeof feeOf === 'function' ? feeOf(p) : Math.floor(p * 0.066)), pFee: p => (typeof pzFee === 'function' ? pzFee(p) : Math.floor(p * 0.1)),
    ship: typeof S !== 'undefined' ? (+S.ship || 0) : 0, pShip: 0, today: `${d.getFullYear()}-${se2(d.getMonth() + 1)}-${se2(d.getDate())}` };
}
async function seCalcCfg() { return { ...SE.calc, ...((await store.get('srcCalc', {})) || {}) }; }
function seProfitIds(rows, calc) {
  if (typeof srcCalcRow !== 'function') return [];
  const env = seCalcEnv();
  return (rows || []).filter(r => { try { const c = srcCalcRow(r, calc, env); return !!(c && c.profitable && !r.need); } catch (e) { return false; } }).map(r => r.id);
}
function seMenuHTML() {
  const it = (k, sub, extra) => `<button type="button" role="menuitem" data-sego="${k}"${sub ? ` data-sub="${sub}"` : ''}><b>${extra || SE_KINDS[k]}</b><small>${esc(sub ? '' : SE_KIND_SUB[k])}</small></button>`;
  return it('product') + `<div class="se-mg"><span>${SE_KINDS.popular}</span>${Object.entries(SE_POP).map(([k, l]) => `<button type="button" role="menuitem" data-sego="popular" data-sub="${k}">${esc(l)}</button>`).join('')}</div>`
    + it('collect') + it('code');
}
// 키워드 · 품번 넣기 (작은 창)
function seAsk(kind, sub) {
  const d = $('#seDlg'); if (!d) return;
  const isKw = kind === 'popular' && sub === 'kw';
  d.innerHTML = `<form class="dlg" id="seAskF"><h3>${isKw ? '키워드로 인기 상품 소싱' : '품번 조회'}</h3>
    ${isKw ? '<label>키워드<input id="seAskIn" placeholder="예: 뉴발란스 530, 아식스 젤" autocomplete="off"></label>' : '<label>품번 · 크림 링크 · 상품번호 · 상품명 (한 줄에 하나, 최대 100개)<textarea id="seAskIn" rows="7" placeholder="MR530KA&#10;https://kream.co.kr/products/28260"></textarea></label>'}
    <p class="hint dlg-msg" id="seAskMsg"></p>
    <div class="row-btns"><button type="button" class="ghost" data-sedlg="close">취소</button><button type="button" class="primary" data-sedlg="ask">실행</button></div></form>`;
  d.dataset.kind = kind; d.dataset.sub = sub || '';
  d.showModal(); setTimeout(() => { const i = $('#seAskIn'); if (i) i.focus(); }, 50);
}

// ---------- 소싱 이력 (23 · 24번) — store 'srcHist'(최근 30건) + 'srcHistRows_'+id(그때 결과 사본) ----------
const SH = { list: null, sort: 't', dir: -1, open: null };
async function seHistSave() {
  const R = SE.run; if (!R || R.state === 'run') return;
  const e = { id: R.id, kind: R.kind, sub: R.sub || '', startedAt: R.startedAt, endedAt: R.endedAt || Date.now(), lastAt: R.lastAt || Date.now(), stoppedAt: R.state === 'stop' ? R.stoppedAt || R.lastAt || Date.now() : null, state: R.state, why: R.why || '', err: R.err || '', stage: R.stage,
    crit: R.crit, counts: { ...(R.counts || {}) }, tm: R.tm || null, qPer: R.qPer || 0, spent: R.spent || 0, sites: (R.sites || []).length, n: SE.rows.length, profit: seProfitIds(SE.rows, await seCalcCfg()).length, fail: SE.rows.filter(r => r && r.err).length };
  let H = (await store.get('srcHist', [])) || []; if (!Array.isArray(H)) H = [];
  H = [e, ...H.filter(h => h && h.id !== e.id)].sort((a, b) => b.startedAt - a.startedAt);
  const drop = H.slice(30); H = H.slice(0, 30);
  await store.set('srcHist', H);
  await store.set('srcHistRows_' + e.id, SE.rows);
  for (const d of drop) { try { await store.set('srcHistRows_' + d.id, null); } catch (x) {} }
  SH.list = H;
  if (typeof curView !== 'undefined' && curView === 'srchist' && !SH.open) shRender();
}
function shListHTML() {
  const n = v => (+v || 0).toLocaleString('ko-KR');
  const key = { t: h => h.startedAt || 0, kind: h => SE_KINDS[h.kind] || '', sites: h => (h.counts || {}).sites || 0, sell: h => seSellTxt((h.crit || {}).sellers), items: h => (h.counts || {}).items || 0, profit: h => +h.profit || 0, dur: h => (h.state === 'done' ? h.spent || 0 : -1) }[SH.sort] || (h => h.startedAt);
  const H = (SH.list || []).slice().sort((a, b) => { const x = key(a), y = key(b); return (typeof x === 'string' ? x.localeCompare(y) : x - y) * SH.dir; });
  const th = (k, t, cls) => `<th class="${cls || ''}${SH.sort === k ? ' on' : ''}" aria-sort="${SH.sort === k ? (SH.dir < 0 ? 'descending' : 'ascending') : 'none'}"><button type="button" data-shs="${k}">${t}<i>${SH.sort === k ? (SH.dir < 0 ? '▼' : '▲') : '⁝'}</i></button></th>`;
  return `<div class="box sh-box"><h3>지난 실행 <span class="sh-n">${H.length}건</span></h3>
    ${H.length ? `<div class="sh-tw"><table class="sh-tbl"><thead><tr>${th('t', '시작')}${th('kind', '종류')}${th('sites', '매입처', 'r')}${th('sell', '판매처')}${th('items', '수집 상품', 'r')}${th('profit', '수익 상품', 'r')}${th('dur', '걸린 시간', 'r')}</tr></thead><tbody>
      ${H.map(h => `<tr data-shid="${esc(h.id)}" tabindex="0"><td>${seT0(h.startedAt)}</td><td>${esc(SE_KINDS[h.kind] || h.kind)}</td><td class="r">${(h.counts || {}).sites ? n(h.counts.sites) + '곳' : '–'}</td><td>${esc(seSellTxt((h.crit || {}).sellers) || '–')}</td>
        <td class="r">${n((h.counts || {}).items)}</td><td class="r sh-pos">${n(h.profit)}</td><td class="r">${h.state === 'done' ? seDur2(h.spent) : '–'}</td></tr>`).join('')}</tbody></table></div>`
      : '<p class="sh-empty">아직 지난 실행이 없어요 — 소싱 실행이 끝나거나 중단되면 여기에 남아요</p>'}</div>`;
}
async function shRender() {
  if (!$('#shList')) return;
  if (!SH.list) { SH.list = (await store.get('srcHist', [])) || []; if (!Array.isArray(SH.list)) SH.list = []; }
  if (SH.open && SH.list.some(h => h.id === SH.open)) return shOpen(SH.open);
  SH.open = null; $('#shOne').hidden = true; $('#shList').hidden = false;
  $('#shList').innerHTML = shListHTML();
}
async function shOpen(id) {
  const h = (SH.list || []).find(x => x.id === id); if (!h) return;
  SH.open = id; $('#shList').hidden = true; $('#shOne').hidden = false;
  const P = seProgParts(h, false);
  $('#shProgL').innerHTML = P.L; $('#shProgR').innerHTML = P.R; $('#shBar').style.width = P.p + '%';
  $('#shProg').classList.toggle('stop', h.state === 'stop');
  const rows = (await store.get('srcHistRows_' + id, [])) || [];
  const m = $('#shResult'); m.innerHTML = '';
  // 결과 상자는 결과 화면 담당(srcres.js)의 renderSrcResult 가 그려요 — 읽기 전용으로
  if (typeof renderSrcResult === 'function') { try { await renderSrcResult({ mount: m, rows, run: h, readonly: true }); } catch (e) { console.warn(e); } }
  if (!m.children.length) m.innerHTML = `<div class="box sh-wait">결과 화면 준비 중 — 이 실행의 상품 ${rows.length.toLocaleString('ko-KR')}개</div>`;
}
function shBind() {
  const L = $('#shList'); if (!L) return;
  L.addEventListener('click', e => {
    const s = e.target.closest('[data-shs]'); if (s) { const k = s.dataset.shs; if (SH.sort === k) SH.dir = -SH.dir; else { SH.sort = k; SH.dir = k === 'kind' || k === 'sell' ? 1 : -1; } L.innerHTML = shListHTML(); return; }
    const r = e.target.closest('[data-shid]'); if (r) shOpen(r.dataset.shid);
  });
  L.addEventListener('keydown', e => { if (e.key !== 'Enter') return; const r = e.target.closest('[data-shid]'); if (r) shOpen(r.dataset.shid); });
  $('#shBack').addEventListener('click', () => { SH.open = null; shRender(); });
}

// ---------- 예약 팝업 (20 · 21 · 22번) ----------
let seEdit = null;
const seWhen = t => { if (!t) return '–'; const d = new Date(t); return `${d.getMonth() + 1}. ${d.getDate()}. (${'일월화수목금토'[d.getDay()]}) ${d.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}`; };
const seDaysTxt = d => (!d || !d.length || d.length === 7 ? '매일' : [7, 1, 2, 3, 4, 5, 6].filter(x => d.includes(x)).map(x => '일월화수목금토'[x % 7]).join('·'));
function seSchedHead() { return '<div class="se-sdh"><h3>예약 실행</h3><button type="button" class="se-x" data-sedlg="close" aria-label="닫기">✕</button></div>'; }
function seSchedList() {
  const d = $('#seDlg'); if (!d) return;
  const L = SE.scheds, oo = b => (b ? '켜짐' : '꺼짐'), P = typeof OPP !== 'undefined' ? OPP : {};
  const when = s => s.mode === 'interval' ? `${s.every}${s.unit === 'd' ? '일' : '시간'}마다 · 최대 ${s.max}번${s.n ? ` (${s.n}번 함)` : ''}` : `${seDaysTxt(s.days)} ${s.time}`;
  const clock = typeof ico === 'function' ? ico('clock') : '';
  d.innerHTML = `<div class="dlg se-sd">${seSchedHead()}
    <div class="se-sbox">${L.length ? `<div class="se-sl">${L.map(s => `<div class="se-si"><label class="dl-sw${s.on ? ' on' : ''}"><input type="checkbox" data-seon="${s.id}"${s.on ? ' checked' : ''} hidden><i></i></label>
      <div class="se-sim"><b>${esc(s.name || SE_KINDS[s.kind])}</b><small>${esc(SE_KINDS[s.kind])}${s.kind === 'popular' ? ` · ${esc(SE_POP[s.sub] || SE_POP.kream)}` : ''} · ${esc(when(s))} · 다음 ${esc(seWhen(seSchedNext(s, Date.now())))}${s.lastFail ? ' · <em class="neg">지난번 멈춤</em>' : ''}</small></div>
      <button type="button" class="linkbtn" data-seed="${s.id}">고치기</button><button type="button" class="linkbtn" data-sedel="${s.id}">지우기</button></div>`).join('')}</div>
      <div class="row-btns se-sl-new"><button type="button" class="primary" data-sedlg="new">예약 만들기</button></div>`
    : `<div class="se-empty"><span class="se-eico">${clock}</span><b>아직 예약이 없어요</b><p>상품 소싱 · 인기 상품 소싱 · 매입처만 수집 · 품번 조회를 정한 시각이나 간격으로 자동 실행해요. 그 시각에 PC 와 프로그램이 켜져 있어야 해요.</p><button type="button" class="primary" data-sedlg="new">예약 만들기</button></div>`}</div>
    <p class="se-sfoot">놓친 예약 실행 ${oo(P.catchUp !== false)} · PC 사용 중이면 예약 연기 ${oo(P.idleDefer !== false)}. <button type="button" class="linkbtn se-gen" data-sedlg="gen">설정 › 일반에서 바꾸기</button></p></div>`;
  if (!d.open) d.showModal();
}
function seSchedForm(sc) {
  const d = $('#seDlg'); if (!d) return;
  seEdit = sc ? { ...SE_SCHED_DEF, ...sc } : { ...SE_SCHED_DEF, sellers: SE.calc.sellers.slice(), id: '' };
  const s = seEdit;
  const tg = (type, attr, on, label, extra) => `<label class="se-tg"><input type="${type}" ${attr}${on ? ' checked' : ''}${extra || ''}><span>${label}</span></label>`;
  d.innerHTML = `<form class="dlg se-sd" id="seSF">${seSchedHead()}
    <div class="se-fh"><button type="button" class="ghost small" data-sedlg="list">← 예약 목록</button><b>${s.id ? '예약 고치기' : '예약 만들기'}</b></div>
    <label class="se-lab">이름<input id="seS_name" value="${esc(s.name)}" placeholder="새벽 신발 세일" autocomplete="off"></label>
    <div class="se-f"><span class="se-fl">실행 종류</span><div class="se-chips">${Object.entries(SE_KINDS).map(([k, l]) => tg('radio', `name="seS_kind" value="${k}"`, s.kind === k, l)).join('')}</div></div>
    <div class="se-f" data-seshow="popular"><span class="se-fl">출발점</span><select id="seS_sub">${Object.entries(SE_POP).map(([k, l]) => `<option value="${k}"${(s.sub || 'kream') === k ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select><input id="seS_kw" value="${esc(s.kw || '')}" placeholder="키워드" autocomplete="off"></div>
    <div class="se-f" data-seshow="code"><span class="se-fl">품번</span><textarea id="seS_list" rows="3" placeholder="한 줄에 하나">${esc(s.list || '')}</textarea></div>
    <div class="se-f se-ft"><span class="se-fl" id="seS_siteN"></span><div class="se-fc"><div class="se-chips">${tg('checkbox', 'id="seS_follow"', s.sites === 'follow', '켜 둔 매입처 따라가기')}</div>
      <small class="se-sub">그 밖의 매입처</small><div class="se-chips">${['direct', 'official', 'mall'].map(k => tg('checkbox', `data-sesite="${k}"`, s.sites === 'follow' ? !!(SE.scope.groups || {})[k] : Array.isArray(s.sites) && s.sites.includes(k), `${SE_GRPS[k]} <em data-segn="${k}"></em>`)).join('')}</div></div></div>
    <div class="se-f"><span class="se-fl">판매처</span><div class="se-chips">${['poizon', 'kream'].map(k => tg('checkbox', `data-sesell="${k}"`, (s.sellers || []).includes(k), SE_SELLERS[k])).join('')}</div></div>
    <div class="se-f"><span class="se-fl">실행 시각</span><div class="se-chips">${tg('radio', 'name="seS_mode" value="time"', s.mode !== 'interval', '정한 시각')}${tg('radio', 'name="seS_mode" value="interval"', s.mode === 'interval', '간격')}</div></div>
    <div class="se-f se-ft" data-semode="time"><span class="se-fl"></span><div class="se-sub2"><label class="se-lab">시각<input type="time" id="seS_time" value="${esc(s.time || '03:00')}"></label>
      <div class="se-lab"><span id="seS_dayL">요일 · 매일</span><div class="se-chips se-days">${[7, 1, 2, 3, 4, 5, 6].map(v => tg('checkbox', `data-seday="${v}"`, (s.days || []).includes(v), '일월화수목금토'[v % 7])).join('')}</div></div></div></div>
    <div class="se-f se-ft" data-semode="interval"><span class="se-fl"></span><div class="se-sub2"><div class="se-lab">간격<div class="se-iv"><input type="number" id="seS_every" min="1" max="168" value="${+s.every || 1}"><select id="seS_unit"><option value="h"${s.unit !== 'd' ? ' selected' : ''}>시간마다</option><option value="d"${s.unit === 'd' ? ' selected' : ''}>일마다</option></select></div></div>
      <label class="se-lab">횟수 (최대 50)<input type="number" id="seS_max" min="1" max="50" value="${+s.max || 10}"></label></div></div>
    <div class="se-f"><span class="se-fl">완료 후 알림</span><select id="seS_notify"><option value="new"${s.notify === 'new' ? ' selected' : ''}>신규 수익 상품이 있을 때 알림</option><option value="always"${s.notify === 'always' ? ' selected' : ''}>끝나면 늘 알림</option><option value="none"${s.notify === 'none' ? ' selected' : ''}>알리지 않기</option></select></div>
    <p class="hint dlg-msg" id="seS_msg"></p>
    <div class="se-ffoot"><span class="se-next" id="seS_next"></span><span class="topsp"></span><button type="button" class="ghost" data-sedlg="list">취소</button><button type="button" class="primary" data-sedlg="save">예약 등록</button></div></form>`;
  if (!d.open) d.showModal();
  seSchedFormSync();
}
function seSchedFormRead() {
  const s = seEdit, d0 = $('#seSF'), q = x => d0.querySelector(x); if (!d0) return s;
  s.name = q('#seS_name').value.trim(); s.kind = (q('[name=seS_kind]:checked') || {}).value || 'product';
  s.sub = q('#seS_sub').value; s.kw = q('#seS_kw').value.trim(); s.list = q('#seS_list').value.trim();
  s.sites = q('#seS_follow').checked ? 'follow' : [...d0.querySelectorAll('[data-sesite]')].filter(e => e.checked).map(e => e.dataset.sesite);
  s.sellers = [...d0.querySelectorAll('[data-sesell]')].filter(e => e.checked).map(e => e.dataset.sesell);
  s.mode = (q('[name=seS_mode]:checked') || {}).value || 'time'; s.time = q('#seS_time').value || '03:00';
  s.days = [...d0.querySelectorAll('[data-seday]')].filter(e => e.checked).map(e => +e.dataset.seday).sort();
  s.every = Math.max(1, Math.min(168, +q('#seS_every').value || 1)); s.unit = q('#seS_unit').value === 'd' ? 'd' : 'h';
  s.max = Math.max(1, Math.min(50, +q('#seS_max').value || 10)); s.notify = q('#seS_notify').value;
  return s;
}
function seSchedFormSync() {
  const d0 = $('#seSF'); if (!d0) return; const s = seSchedFormRead();
  d0.querySelectorAll('[data-seshow]').forEach(e => { e.hidden = e.dataset.seshow !== s.kind; });
  d0.querySelector('#seS_kw').hidden = s.sub !== 'kw';
  d0.querySelectorAll('[data-semode]').forEach(e => { e.hidden = e.dataset.semode !== s.mode; });
  const follow = s.sites === 'follow';
  d0.querySelectorAll('[data-sesite]').forEach(e => { e.disabled = follow; if (follow) e.checked = !!(SE.scope.groups || {})[e.dataset.sesite]; });
  const groups = follow ? null : s.sites, act = seActiveMods(groups), crit = { ...seCritSnap(null, groups) };
  d0.querySelectorAll('[data-segn]').forEach(e => { const k = e.dataset.segn, c = seGrpCount(k), on = d0.querySelector(`[data-sesite="${k}"]`).checked; e.textContent = `${on ? c.on : 0}/${c.all}`; });
  d0.querySelector('#seS_siteN').textContent = `매입처 ${act.length} · 수집 ${act.filter(m => seQueries(m, crit).length).length}`;
  d0.querySelector('#seS_dayL').textContent = `요일 · ${seDaysTxt(s.days)}`;
  const nx = seSchedNext({ ...s, on: true, since: Date.now(), last: 0, n: 0 }, Date.now());
  d0.querySelector('#seS_next').textContent = `다음 실행 ${seWhen(nx)}`;
}
async function seSchedFormSave() {
  const s = seSchedFormRead(), msg = $('#seS_msg');
  const bad = !s.sellers.length && s.kind !== 'collect' ? '판매처를 하나 이상 골라 주세요'
    : Array.isArray(s.sites) && !s.sites.length ? '매입처 묶음을 하나 이상 골라 주세요' : s.kind === 'code' && !s.list ? '조사할 품번을 넣어 주세요' : s.kind === 'popular' && s.sub === 'kw' && !s.kw ? '키워드를 넣어 주세요' : '';
  if (bad) { msg.textContent = bad; return; }
  s.since = Date.now();
  if (s.id) { const i = SE.scheds.findIndex(x => x.id === s.id); if (i >= 0) SE.scheds[i] = { ...SE.scheds[i], ...s, n: s.mode === SE.scheds[i].mode ? SE.scheds[i].n : 0, last: s.mode === SE.scheds[i].mode ? SE.scheds[i].last : 0 }; }
  else SE.scheds.push({ ...s, id: 's' + Date.now(), on: true, last: 0, n: 0 });
  await seSchedSave(); seSchedList();
}

// ---------- 설정 화면 (25 ~ 28번) — 탭: 일반 · 수집 범위 · 수익 계산 · 판매 설정 ----------
// 수집 범위 · 수익 계산은 [저장]을 눌러야 저장(ST.dScope · ST.dCalc 초안), 매입처 실행 포함 · 일반 · 판매 설정은 바꾸면 바로 저장
const ST = { tab: 'gen', dScope: null, dCalc: null, dirty: false, gx: {} };
const ST_FOOT = { gen: '이 PC 에만 적용돼요 — 바꾸면 바로 저장돼요.', scope: '품목 · 브랜드 · 한도는 [저장]으로 저장돼요 · 매입처(실행 포함)는 바꾸면 바로 저장돼요.',
  calc: '수익 상품 기준 · 매입가 할인은 [저장]으로 저장돼요 — 다음 실행과 결과 화면이 같은 값을 써요.', sell: '바꾸면 바로 저장돼요.' };
const ST_DISC = [['coupon', '상품 쿠폰', '상품에 붙은 쿠폰을 매입가에서 빼요'], ['cart', '장바구니 · 중복 쿠폰', '장바구니 · 중복 쿠폰을 매입가에서 빼요'], ['point', '적립금 선할인', '적립금을 먼저 쓰는 할인을 빼요'], ['pay', '결제 즉시할인', '카드 · 간편결제 즉시할인을 빼요']];
const stSw = (k, on, label) => `<button type="button" class="dl-sw st-sw2${on ? ' on' : ''}" data-stk="${k}" role="switch" aria-checked="${!!on}" aria-label="${esc(label)}"><i></i></button>`;
const stQ = t => `<i class="se-q" title="${esc(t)}">?</i>`;
async function stDraftReset() {
  const sc = SE.scope, c = SE.calc;
  ST.dScope = { cats: (sc.cats || []).slice(), brands: (sc.brands || []).slice(), maxPages: +sc.maxPages || 20, maxItems: +sc.maxItems || 3000 };
  const disc = ((await store.get('srcCalc', {})) || {}).disc || {}, on = disc.on || {};
  ST.dCalc = { minWon: +c.minWon || 0, minRate: +c.minRate || 0, min30: +c.min30 || 0, unknownStock: !!c.unknownStock, vatRefund: c.vatRefund !== false, rec: { ...SE_CALC_DEF.rec, ...(c.rec || {}) },
    disc: Object.fromEntries(ST_DISC.map(([k]) => [k, on[k] !== false])) };
  ST.dirty = false;
}
function stScopeHTML() {
  const d = ST.dScope, sc = SE.scope, mods = seMods(), off = new Set(sc.off || []);
  const act = seActiveMods(), crit = { ...seCritSnap(), cats: d.cats, brands: d.brands };
  const coll = act.filter(m => seQueries(m, crit).length), miss = act.filter(m => !seQueries(m, crit).length);
  const sumR = [d.brands.length ? d.brands.slice(0, 3).join(' · ') + (d.brands.length > 3 ? ` 외 ${d.brands.length - 3}` : '') : '전체 브랜드', ...d.cats.map(k => (SE_CATS[k] || [k])[0])].join(' · ');
  const chk = miss.length ? `<p class="st-chk warn">고른 브랜드 · 품목과 어긋난 매입처 ${miss.length}곳은 이번 실행에서 빠져요 — ${esc(miss.slice(0, 4).map(m => m.label).join(' · '))}${miss.length > 4 ? ' 외' : ''}</p>`
    : '<p class="st-chk"><b>✓</b> 고른 브랜드 · 품목과 어긋난 내 매입처가 없어요</p>';
  const brandsAll = [...new Set([...SE_BRANDS_UI, ...d.brands])];
  const siteRow = m => `<label class="se-site${m.ready ? '' : ' soon'}"><input type="checkbox" data-sesoff="${esc(m.k)}"${m.ready && !off.has(m.k) ? ' checked' : ''}${m.ready ? '' : ' disabled'}><span>${esc(m.label)}</span>${m.ready ? (m.sup ? ((SE.supUrl[m.k] || {}).url ? '' : (SE.supUrl[m.k] || {}).fail ? '<em title="홈페이지에서 검색칸을 못 찾았어요. 7일 뒤 다시 찾아요. 급하면 내 매입처에 검색 주소를 넣어 주세요">검색 못 찾음</em>' : '<em title="처음 수집할 때 홈페이지에서 검색 주소를 찾아요">첫 실행 때 연결</em>') : '') : '<em>준비 중</em>'}</label>`;
  const gDesc = (k, n) => ({ official: `${n}곳 · 브랜드 공식 온라인몰`, direct: `${n}곳 · 상품을 직접 사서 파는 편집숍 · 백화점`, mall: `${n}곳 · 일반 판매자가 섞여 기본은 꺼짐`, rare: `값이 정가에 가까워 수익 상품이 드문 곳 ${n}곳 — 기본은 제외` }[k]);
  const gName = { official: '공식몰', direct: '직매입', mall: '입점몰', rare: '수익 상품이 드문 매입처' };
  const mine = sc.mine || [];
  const mineRow = (m, i) => { const mod = m.k ? mods.find(x => x.k === m.k) : null; return `<div class="st-row"><div class="st-l"><b>${esc(m.label || m.url || '')}</b><small>${m.k ? `${esc(SE_GRPS[mod && mod.grp] || '')} · 묶음이 꺼져 있어도 실행에 포함해요` : esc(String(m.url || '').replace(/^https?:\/\//, '').slice(0, 60))}</small></div><button type="button" class="linkbtn" data-stmdel="${i}">지우기</button>${stSw('mine:' + i, m.on !== false, '실행에 포함')}</div>`; };
  return `<div class="st-card st-sum"><div class="st-sumh"><span class="st-sl">이번 실행 범위</span><b class="st-big">수집 ${coll.length}곳</b><small>실행 포함 ${act.length}곳 중</small><span class="topsp"></span><span class="st-sumr">${esc(sumR)}</span></div>${chk}</div>
  <div class="st-cols"><div class="st-col">
    <div class="st-hrow"><h3 class="st-h">무엇을 수집할까요</h3><small class="st-sm">공용</small></div>
    <h4 class="st-h4">품목 ${stQ('고른 품목의 상품만 매입처 목록에서 모아요')}</h4>
    <div class="st-card"><div class="st-row"><div class="st-l"><b>수집할 품목</b><small>많이 고를수록 실행이 길어져요</small></div><div class="se-chips">${Object.entries(SE_CATS).map(([k, v]) => `<label class="se-tg"><input type="checkbox" data-stcat="${k}"${d.cats.includes(k) ? ' checked' : ''}><span>${v[0]}</span></label>`).join('')}</div></div></div>
    <h4 class="st-h4">브랜드 ${stQ(`전체면 주요 브랜드 ${SE_BRANDS.length}개를 차례로 찾아요. 고르면 고른 브랜드만 찾아요`)}</h4>
    <div class="st-card st-plain">
      <div class="st-row"><div class="st-l st-k"><small>고른 브랜드</small></div><div class="st-grow">${d.brands.length ? `<div class="se-chips">${d.brands.map(b => `<span class="st-pick">${esc(b)}<button type="button" data-stbrx="${esc(b)}" aria-label="${esc(b)} 빼기">✕</button></span>`).join('')}</div>` : '<span class="st-val">전체 브랜드 — 매입처에 있는 모든 브랜드를 수집해요</span>'}</div><button type="button" class="ghost small" id="stBrAll"${d.brands.length ? '' : ' disabled'}>전체 브랜드로</button></div>
      <div class="st-row st-top"><div class="st-l st-k"><small>주요 브랜드</small></div><div class="se-chips st-grow">${brandsAll.map(b => `<label class="se-tg"><input type="checkbox" data-stbr="${esc(b)}"${d.brands.includes(b) ? ' checked' : ''}><span>${esc(b)}</span></label>`).join('')}</div></div>
      <div class="st-row st-top"><div class="st-l st-k"><small>찾기</small></div><div class="st-grow"><input id="stBrFind" class="se-in wide" placeholder="브랜드 이름 — 한글 · 영문" autocomplete="off"><small class="st-sm st-blk">주요 브랜드에 없는 브랜드는 이름으로 찾아요 (Enter)</small></div></div>
    </div>
    <h4 class="st-h4">한도 ${stQ('사이트에 부담을 덜 주려고 요청 사이를 2.5초 넘게 띄워요')}</h4>
    <div class="st-card"><div class="st-row"><div class="st-l"><b>목록당 페이지</b><small>목록 하나에서 넘길 최대 페이지 수</small></div><label class="st-num"><input type="number" data-stn="maxPages" min="1" max="100" value="${d.maxPages}"><span>쪽까지</span></label></div>
      <div class="st-row"><div class="st-l"><b>한 번 실행에 모을 상품</b><small>넘으면 모으기를 멈추고 시세 조회로 넘어가요</small></div><label class="st-num"><input type="number" data-stn="maxItems" min="50" max="20000" step="50" value="${d.maxItems}"><span>개까지</span></label></div></div>
  </div><div class="st-col">
    <div class="st-hrow"><h3 class="st-h">어디서 수집할까요</h3><small class="st-sm">실행 포함은 이 PC</small></div>
    <div class="st-hrow"><h4 class="st-h4">내 매입처 ${stQ('이름으로 등록하면 그 매입처를 묶음과 상관없이 실행에 포함해요. 목록 주소(https://…)를 넣으면 그 주소를 읽어요 — 주소 안 {q} 자리에 브랜드 · 품목 낱말이 들어가요')}</h4><span class="topsp"></span><input id="stMineIn" class="se-in" placeholder="매입처 이름 (예: 무신사)" autocomplete="off"><button type="button" class="ghost small" id="stMineAdd">등록</button></div>
    ${mine.length ? `<div class="st-card">${mine.map(mineRow).join('')}</div>` : '<p class="st-sm">아직 없어요 — 위 칸에 매입처 이름을 넣어 등록하면 여기서 하나씩 실행에 포함 · 제외하고 내 할인을 넣어요.</p>'}
    <p class="st-sm st-msg" id="stMineMsg"></p>
    <h4 class="st-h4">그 밖의 매입처 ${stQ('묶음을 켜면 그 묶음의 매입처를 모두 수집해요. [매입처 보기]에서 하나씩 끌 수 있어요')}</h4>
    <div class="st-card">${['official', 'direct', 'mall', 'rare'].map(k => { const all = mods.filter(m => m.grp === k); return `<div class="st-row"><div class="st-l"><b>${gName[k]}</b><small>${gDesc(k, all.length)}</small></div><button type="button" class="linkbtn st-gx" data-stgx="${k}" aria-expanded="${!!ST.gx[k]}">매입처 보기</button>${stSw('grp:' + k, !!(sc.groups || {})[k], gName[k])}</div>
      ${ST.gx[k] ? `<div class="st-sites">${all.map(siteRow).join('')}</div>` : ''}`; }).join('')}</div>
  </div></div>`;
}
function stCalcHTML() {
  const d = ST.dCalc, sel = SE.calc.sellers || [], first = sel.includes('poizon') ? 'POIZON' : 'KREAM';
  const num = (k, v, unit, mode) => `<label class="st-num"><input data-stc="${k}" inputmode="${mode || 'numeric'}" value="${v}"><span>${unit}</span></label>`;
  return `<div class="st-cols"><div class="st-col">
    <h3 class="st-h">수익 상품 기준 ${stQ('사이즈마다 이 기준을 넘는 것만 수익 상품으로 남겨요')}</h3>
    <div class="st-card">
      <div class="st-row"><div class="st-l"><b>판매하는 곳</b><small>이 판매처의 시세와 비교해요 · 바꾸기는 판매 설정 탭</small></div><span class="st-val">${esc(seSellTxt(sel))}</span></div>
      <div class="st-row"><div class="st-l"><b>최소 수익</b><small>수익이 이 금액보다 많은 사이즈만 · 0원은 손해만 빼요</small></div>${num('minWon', d.minWon, '원')}</div>
      <div class="st-row"><div class="st-l"><b>최소 수익률</b><small>매입가 대비 · 0% 는 따지지 않아요</small></div>${num('minRate', d.minRate, '%', 'decimal')}</div>
      <div class="st-row"><div class="st-l"><b>${first} 30일 판매</b><small>상품 전체(모든 사이즈 합)</small></div>${num('min30', d.min30, '개 이상')}</div>
      <div class="st-row"><div class="st-l"><b>재고 미확인 사이즈도 포함 ${stQ('매입처가 사이즈별 재고를 보여 주지 않는 사이즈도 수익 상품에 넣어요')}</b></div>${stSw('unk', d.unknownStock, '재고 미확인 사이즈도 포함')}</div>
      <div class="st-row"><div class="st-l"><b>POIZON 부가세 환급 반영 ${stQ("POIZON(해외)에 팔면 매입가에 든 부가세(매입가 ÷ 11)를 돌려받아 수익에 더해요. 환급 전 금액은 '현금'으로 따로 보여요")}</b></div>${stSw('vat', d.vatRefund, 'POIZON 부가세 환급 반영')}</div>
      <div class="st-row"><div class="st-l"><b>권장 수량 ${stQ('사이즈마다 30일 판매량을 나눈 값을 사요(최대 개수까지). 판매 입찰이 30일 판매보다 많으면 절반만 사요')}</b><small>판매 입찰이 많으면 절반</small></div>
        <label class="st-num"><em>30일 판매 ÷</em><input type="number" data-stc="div" min="1" max="30" value="${+d.rec.div || 3}"></label><label class="st-num"><em>최대</em><input type="number" data-stc="max" min="1" max="50" value="${+d.rec.max || 5}"><span>개</span></label>${stSw('half', d.rec.bidHalf !== false, '판매 입찰이 많으면 절반')}</div>
    </div>
  </div><div class="st-col">
    <h3 class="st-h">매입가 할인 ${stQ('켠 할인만 매입가에서 빼요. 매입처마다 할인 값은 결과의 매입가 펼치기 › 내 할인에서 정해요')}</h3>
    <div class="st-card">${ST_DISC.map(([k, l, t]) => `<div class="st-row"><div class="st-l"><b>${l} ${stQ(t)}</b></div>${stSw('disc:' + k, d.disc[k], l)}</div>`).join('')}</div>
    <p class="st-sm">상품 쿠폰 → 장바구니 쿠폰 → 등급 할인 → 적립금 선할인 → 결제 즉시할인 차례로 넣어요.</p>
  </div></div>`;
}
function stSellPaint() {
  const box = $('#stSellers'); if (!box) return;
  const sel = SE.calc.sellers || [];
  box.innerHTML = ['poizon', 'kream'].map(k => `<label class="se-tg"><input type="checkbox" data-stsell="${k}"${sel.includes(k) ? ' checked' : ''}><span>${SE_SELLERS[k]}</span></label>`).join('');
  const S0 = typeof S !== 'undefined' ? S : {};
  const f = $('#stFeeTxt'); if (f) f.textContent = `KREAM (판매가 × ${+S0.rate || 0}% + ${(+S0.base || 0).toLocaleString('ko-KR')}원) × 1.1 · 최대 ${(+S0.max || 0).toLocaleString('ko-KR')}원${sel.includes('poizon') ? ' · POIZON 판매가 기준 수수료표' : ''}`;
  const ab = $('#stAutoBid'); if (ab) ab.textContent = typeof AB !== 'undefined' && AB.run ? '켜짐' : '꺼짐';
}
function stSwSync() {
  document.querySelectorAll('#settings .st-sw[data-sw]').forEach(b => { const s = $('#' + b.dataset.sw), on = !!s && s.value === '1'; b.classList.toggle('on', on); b.setAttribute('aria-checked', String(on)); });
  document.querySelectorAll('#settings [data-seg]').forEach(g => { const s = $('#' + g.dataset.seg); g.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(!!s && +s.value === +b.dataset.v))); });
}
function stFoot() {
  const t = $('#stFootTxt'); if (t) t.textContent = ST_FOOT[ST.tab] || '';
  const staged = ST.tab === 'scope' || ST.tab === 'calc';
  const u = $('#stUndo'), s = $('#stSave'); if (!u) return;
  u.hidden = s.hidden = !staged; u.disabled = s.disabled = !ST.dirty;
}
function stPaint() {
  if (!ST.dScope) return;
  if (ST.tab === 'scope') { const a = $('#stScope'); if (a) { const f = document.activeElement && document.activeElement.id; a.innerHTML = stScopeHTML(); if (f === 'stBrFind' || f === 'stMineIn') { const i = $('#' + f); if (i) i.focus(); } } }
  if (ST.tab === 'calc') { const a = $('#stCalc'); if (a) a.innerHTML = stCalcHTML(); }
  if (ST.tab === 'sell') stSellPaint();
  stFoot();
}
async function stTab(t) {
  if (!['gen', 'scope', 'calc', 'sell'].includes(t)) t = 'gen';
  ST.tab = t;
  if (!ST.dScope) await stDraftReset();
  document.querySelectorAll('#settings [data-stt]').forEach(b => b.setAttribute('aria-selected', String(b.dataset.stt === t)));
  document.querySelectorAll('#settings [data-stp]').forEach(p => { p.hidden = p.dataset.stp !== t; });
  try { localStorage.setItem('ks:stTab', t); } catch (e) {}
  stPaint(); stSwSync();
}
function stDirty() { ST.dirty = true; stFoot(); }
async function stSave() {
  const d = ST.dScope, c = ST.dCalc;
  SE.scope = { ...SE.scope, cats: d.cats.slice(), brands: d.brands.slice(), maxPages: Math.max(1, Math.min(100, +d.maxPages || 20)), maxItems: Math.max(50, Math.min(20000, +d.maxItems || 3000)) };
  await store.set('srcScope', SE.scope);
  Object.assign(SE.calc, { minWon: Math.round(+c.minWon || 0), minRate: Math.min(1000, +c.minRate || 0), min30: Math.round(+c.min30 || 0), unknownStock: !!c.unknownStock, vatRefund: !!c.vatRefund,
    rec: { div: Math.max(1, +c.rec.div || 3), max: Math.max(1, +c.rec.max || 5), bidHalf: c.rec.bidHalf !== false } });
  await seCalcSave(c.disc);
  ST.dirty = false; stPaint(); sePaint();
  const t = $('#stFootTxt'); if (t) t.textContent = '저장했어요 — 다음 실행부터 이 기준으로 해요';
}
async function stUndo() { await stDraftReset(); stPaint(); }
async function seScopeSave() { await store.set('srcScope', SE.scope); stPaint(); sePaint(); }
// 할인(disc)은 결과 화면 담당 — 켜기/끄기(disc.on)의 상품 쿠폰 · 장바구니 · 적립금 · 결제 즉시할인 칸만 고치고 나머지 disc 는 그대로 둬요
async function seCalcSave(discOn) {
  const prev = (await store.get('srcCalc', {})) || {}; const mine = { ...SE.calc }; delete mine.disc;
  const next = { ...prev, ...mine };
  if (discOn) { const disc = { ...(prev.disc || {}) }; disc.on = { ...(disc.on || {}) }; for (const [k] of ST_DISC) if (k in discOn) disc.on[k] = !!discOn[k]; next.disc = disc; }
  await store.set('srcCalc', next); sePaint();
  try { window.dispatchEvent(new CustomEvent('src:calc')); } catch (e) {}
}
function stBind() {
  const set = $('#settings'); if (!set || set.dataset.stb) return; set.dataset.stb = '1';
  set.addEventListener('click', async e => {
    const tb = e.target.closest('[data-stt]'); if (tb) return stTab(tb.dataset.stt);
    // 일반: 스위치 · 화면 크기 → 숨긴 select 를 바꾸고 change 를 보내요 (ops.js · app.js 가 저장)
    const sw = e.target.closest('.st-sw[data-sw]');
    if (sw) { const s = $('#' + sw.dataset.sw); if (!s) return; s.value = s.value === '1' ? '0' : '1'; s.dispatchEvent(new Event('change', { bubbles: true })); stSwSync(); setTimeout(stSwSync, 600); return; }
    const sg = e.target.closest('[data-seg] button');
    if (sg) { const s = $('#' + sg.closest('[data-seg]').dataset.seg); if (!s) return; s.value = sg.dataset.v; s.dispatchEvent(new Event('change', { bubbles: true })); stSwSync(); setTimeout(stSwSync, 600); return; }
    if (e.target.closest('#stUndo')) return stUndo();
    if (e.target.closest('#stSave')) return stSave();
    if (e.target.closest('#stAcct')) { set.hidden = true; $('#btnSettings').setAttribute('aria-expanded', 'false'); return route('acct'); }
    if (e.target.closest('#stAutoBidGo')) { set.hidden = true; $('#btnSettings').setAttribute('aria-expanded', 'false'); return route('kauto'); }
    // 수집 범위 · 수익 계산 스위치
    const k2 = e.target.closest('[data-stk]');
    if (k2) {
      const k = k2.dataset.stk;
      if (k.startsWith('grp:')) { const g = k.slice(4); SE.scope.groups = { ...SE.scope.groups, [g]: !(SE.scope.groups || {})[g] }; return seScopeSave(); }
      if (k.startsWith('mine:')) { const m = (SE.scope.mine || [])[+k.slice(5)]; if (m) { m.on = m.on === false; return seScopeSave(); } return; }
      const c = ST.dCalc;
      if (k === 'unk') c.unknownStock = !c.unknownStock; else if (k === 'vat') c.vatRefund = !c.vatRefund; else if (k === 'half') c.rec.bidHalf = c.rec.bidHalf === false;
      else if (k.startsWith('disc:')) c.disc[k.slice(5)] = !c.disc[k.slice(5)];
      k2.classList.toggle('on'); k2.setAttribute('aria-checked', String(k2.classList.contains('on'))); return stDirty();
    }
    const gx = e.target.closest('[data-stgx]'); if (gx) { ST.gx[gx.dataset.stgx] = !ST.gx[gx.dataset.stgx]; return stPaint(); }
    if (e.target.closest('#stBrAll')) { ST.dScope.brands = []; stDirty(); return stPaint(); }
    const bx = e.target.closest('[data-stbrx]'); if (bx) { ST.dScope.brands = ST.dScope.brands.filter(b => b !== bx.dataset.stbrx); stDirty(); return stPaint(); }
    const md = e.target.closest('[data-stmdel]'); if (md) { SE.scope.mine.splice(+md.dataset.stmdel, 1); return seScopeSave(); }
    if (e.target.closest('#stMineAdd')) return stMineAdd();
  });
  set.addEventListener('change', async e => {
    const t = e.target, d = ST.dScope;
    if (t.dataset.stcat) { d.cats = [...set.querySelectorAll('[data-stcat]')].filter(x => x.checked).map(x => x.dataset.stcat); stDirty(); return stPaint(); }
    if (t.dataset.stbr) { const b = t.dataset.stbr; d.brands = t.checked ? [...new Set([...d.brands, b])] : d.brands.filter(x => x !== b); stDirty(); return stPaint(); }
    if (t.dataset.stn) { d[t.dataset.stn] = +t.value || 0; return stDirty(); }
    if (t.dataset.sesoff) { const off = new Set(SE.scope.off || []); if (t.checked) off.delete(t.dataset.sesoff); else off.add(t.dataset.sesoff); SE.scope.off = [...off]; return seScopeSave(); }
    if (t.dataset.stsell) { const s = [...set.querySelectorAll('[data-stsell]')].filter(x => x.checked).map(x => x.dataset.stsell); if (!s.length) { t.checked = true; return; } SE.calc.sellers = s; await seCalcSave(); return stSellPaint(); }
    if (/^s_(rate|base|max)$/.test(t.id)) setTimeout(stSellPaint, 300);
  });
  set.addEventListener('input', e => {
    const t = e.target; if (!t.dataset.stc) return;
    const v = Math.max(0, +String(t.value).replace(/[^\d.]/g, '') || 0), c = ST.dCalc, k = t.dataset.stc;
    if (k === 'div' || k === 'max') c.rec[k] = v; else c[k] = v;
    stDirty();
  });
  set.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    if (e.target.id === 'stBrFind') { e.preventDefault(); const v = e.target.value.trim(); if (v) { ST.dScope.brands = [...new Set([...ST.dScope.brands, v])]; stDirty(); stPaint(); } }
    if (e.target.id === 'stMineIn') { e.preventDefault(); stMineAdd(); }
  });
  // 설정 열 때 · 바깥에서 값이 바뀔 때 스위치를 다시 맞춰요
  $('#btnSettings').addEventListener('click', () => setTimeout(() => { if (set.hidden) return; if (!ST.dirty) stDraftReset().then(stPaint); stTab(ST.tab); setTimeout(stSwSync, 400); setTimeout(stSwSync, 1500); }, 0));
  setInterval(() => { if (!set.hidden && ST.tab === 'gen') stSwSync(); }, 1500);
  let t0 = 'gen'; try { t0 = localStorage.getItem('ks:stTab') || 'gen'; } catch (e) {}
  stTab(t0);
}
// 내 매입처 등록: 아는 매입처 이름이면 그곳을 실행에 포함, https:// 주소면 그 목록 주소를 읽어요
async function stMineAdd() {
  const i = $('#stMineIn'), msg = $('#stMineMsg'), v = (i && i.value || '').trim(); if (!v) return i && i.focus();
  const mine = SE.scope.mine || (SE.scope.mine = []);
  if (/^https?:\/\//.test(v)) mine.push({ label: v.replace(/^https?:\/\/(www\.)?/, '').split('/')[0], url: v, on: true });
  else {
    const low = v.toLowerCase().replace(/\s/g, ''), mods = seMods().filter(m => !m.mine && m.ready);
    const m = mods.find(x => x.label.toLowerCase().replace(/\s/g, '') === low) || mods.find(x => x.label.toLowerCase().replace(/\s/g, '').includes(low));
    if (!m) { if (msg) msg.textContent = `'${v}' 매입처를 찾지 못했어요 — 목록 주소(https://…)를 넣으면 그 주소를 읽어요`; return; }
    if (mine.some(x => x.k === m.k)) { if (msg) msg.textContent = `${m.label}은(는) 이미 등록돼 있어요`; return; }
    mine.push({ label: m.label, k: m.k, on: true });
  }
  await seScopeSave();
}
function seOpenSettings(tab) {
  const p = $('#settings'); if (p && p.hidden) $('#btnSettings').click();
  stTab(tab || 'calc');
  setTimeout(() => { if (p) p.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 60);
}

function seCss() {
  if ($('#seCss')) return;
  const st = document.createElement('style'); st.id = 'seCss';
  st.textContent = `
.se-head{display:flex;align-items:center;gap:12px;margin:0 0 14px}.se-head h2:empty{display:none}
.se-top{display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;gap:8px;margin-left:auto}
.se-split{position:relative;display:inline-flex}
.se-split #seGo{border-top-right-radius:0;border-bottom-right-radius:0}
.se-split .se-more{border-top-left-radius:0;border-bottom-left-radius:0;padding:0 10px;margin-left:1px;min-width:0}
.se-menu{position:absolute;right:0;top:calc(100% + 6px);z-index:40;min-width:290px;background:var(--panel);border:1px solid var(--line);border-radius:12px;box-shadow:var(--shadow);padding:6px;display:grid;gap:2px}
.se-menu button{display:grid;text-align:left;gap:2px;border:0;background:none;padding:8px 10px;border-radius:8px;color:var(--ink);cursor:pointer;font-size:13px}
.se-menu button:hover,.se-menu button:focus-visible{background:var(--soft)}
.se-menu small{color:var(--sub);font-size:11.5px}
.se-mg{display:grid;gap:0;padding:4px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
.se-mg>span{font-size:13px;font-weight:700;padding:6px 10px 2px}
.se-mg button{padding:5px 10px 5px 22px;font-size:12.5px;color:var(--sub)}
.se-n:empty{display:none}.se-n{margin-left:6px;font-size:11px;padding:1px 6px;border-radius:99px;background:var(--acc-bg);color:var(--acc)}
.se-crit{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--sub);margin:-4px 0 12px}
.se-crit #seCrit{flex:1;min-width:0}.se-crit #seCrit b{color:var(--ink);font-weight:700;margin-right:4px}
.se-prog{border:1px solid var(--line);border-radius:12px;background:var(--panel);padding:10px 14px 0;margin-bottom:12px;display:grid;grid-template-columns:1fr auto;gap:6px 14px;font-size:12.5px;overflow:hidden;box-shadow:var(--shadow)}
.se-pl{display:flex;flex-wrap:wrap;align-items:center;gap:4px 14px;color:var(--sub)}
.se-pr{color:var(--ink);text-align:right;align-self:center}.se-pr .se-pc{color:var(--sub);margin-left:6px}
.se-pr .se-tip{cursor:help;border-bottom:1px dotted var(--line)}
.se-prog .se-bar{grid-column:1/-1;height:3px;margin:4px -14px 0;background:var(--soft);overflow:hidden}
.se-prog .se-bar span{display:block;height:100%;background:var(--g-brand,var(--acc));transition:width .4s}
body.sr-split .se-prog{grid-template-columns:1fr}body.sr-split .se-prog .se-pr{text-align:left;justify-self:start}
.se-st{font-weight:700}.se-st.se-run{color:var(--ok)}.se-st.se-stop{color:var(--warn)}.se-st.se-done{color:var(--ink)}
.se-note{display:flex;flex-wrap:wrap;align-items:center;gap:10px;font-size:12.5px;color:var(--sub);margin:0 0 10px}
.se-note.warn{color:var(--warn)}
.se-msg{font-size:12.5px;color:var(--sub);margin:-4px 0 8px}
.se-q{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;border:1px solid var(--line);font-size:10.5px;font-style:normal;font-weight:600;color:var(--sub);cursor:help;margin-left:4px;vertical-align:middle}
.se-tg{display:inline-flex;position:relative;cursor:pointer}
.se-tg input{position:absolute;opacity:0;width:1px;height:1px;pointer-events:none}
.se-tg span{display:inline-flex;align-items:center;gap:4px;height:30px;padding:0 12px;border-radius:99px;border:1.5px solid var(--line);background:var(--panel);font-size:12.5px;font-weight:700;color:var(--sub)}
.se-tg span em{font-style:normal;font-weight:600;opacity:.85}
.se-tg:has(input:checked) span{background:var(--g-brand,var(--acc));border-color:transparent;color:#fff}
.se-tg:has(input:disabled) span{opacity:.6;cursor:default}
.se-tg:has(input:focus-visible) span{outline:2px solid var(--acc);outline-offset:2px}
.se-f{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:10px 0}
.se-f.se-ft{align-items:flex-start}
.se-fl{width:110px;flex:0 0 110px;font-size:13px;font-weight:700;color:var(--sub)}
.se-ft .se-fl{padding-top:6px}
.se-fc{display:grid;gap:6px}.se-sub{font-size:11.5px;color:var(--sub)}
.se-sub2{display:flex;flex-wrap:wrap;gap:14px;align-items:flex-end}
.se-lab{display:grid;gap:6px;font-size:12px;color:var(--sub);font-weight:600}
.se-iv{display:flex;gap:8px}.se-iv input{width:110px}
.se-chips{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.se-days .se-tg span{width:34px;justify-content:center;padding:0;border-radius:8px}
.se-in{height:32px;border:1px solid var(--line);border-radius:8px;padding:0 10px;background:var(--field,var(--panel));color:var(--ink);font-size:12.5px;width:180px}
.se-in.wide{width:100%;max-width:320px}
.se-site{display:inline-flex;gap:4px;align-items:center}
.se-site.soon{color:var(--sub)}.se-site em{font-style:normal;font-size:11px;padding:0 6px;border-radius:99px;background:var(--soft)}
#seDlg{width:min(740px,calc(100vw - 32px))}
.se-sd{display:grid;gap:4px}
.se-sdh{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.se-x{border:0;background:none;color:var(--acc);font-size:16px;cursor:pointer;padding:4px 6px;border-radius:6px}
.se-x:hover{background:var(--soft)}
.se-sbox{border:1px solid var(--line);border-radius:12px;padding:12px}
.se-sl{display:grid;gap:6px}
.se-sl-new{margin-top:10px}
.se-si{display:flex;align-items:center;gap:10px;border:1px solid var(--line);border-radius:10px;padding:8px 12px}
.se-sim{flex:1;display:grid;gap:2px}.se-sim small{color:var(--sub)}
.se-empty{text-align:center;padding:30px 10px;display:grid;gap:10px;justify-items:center}
.se-empty .se-eico svg{width:30px;height:30px;color:var(--sub)}
.se-empty b{font-size:15px}
.se-empty p{margin:0;color:var(--sub);font-size:13px;max-width:440px;line-height:1.6}
.se-sfoot{font-size:12.5px;color:var(--sub);margin:8px 0 0}
.se-gen{font-weight:700;color:var(--acc);font-size:12.5px}
.se-fh{display:flex;align-items:center;gap:10px;margin:0 0 6px}.se-fh b{font-size:15px}
.se-ffoot{display:flex;align-items:center;gap:8px;margin-top:10px}
.se-next{font-size:12.5px;color:var(--sub)}
#seSF .se-f select{width:auto;min-width:220px;flex:0 0 auto}
#seSF .se-iv select{min-width:130px}
#seDlg textarea,#seDlg input:not([type=checkbox]):not([type=radio]),#seDlg select{font:inherit}
/* 소싱 이력 */
.sh-box h3{display:flex;align-items:baseline;gap:6px}.sh-n{font-size:12.5px;font-weight:500;color:var(--sub)}
.sh-tw{overflow-x:auto}
.sh-tbl{width:100%;border-collapse:collapse;font-size:13px}
.sh-tbl th{font-size:12px;font-weight:600;color:var(--sub);text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);white-space:nowrap}
.sh-tbl th button{border:0;background:none;color:inherit;font:inherit;cursor:pointer;display:inline-flex;gap:4px;align-items:center;padding:0}
.sh-tbl th i{font-style:normal;opacity:.55;font-size:10.5px}.sh-tbl th.on{color:var(--ink)}.sh-tbl th.on i{opacity:1}
.sh-tbl td{padding:10px;border-bottom:1px solid var(--line);white-space:nowrap;text-align:left}
.sh-tbl th:nth-child(2){width:45%}
.sh-tbl .r,.sh-tbl td.r{text-align:right}.sh-tbl th.r button{flex-direction:row}
.sh-tbl tbody tr{cursor:pointer}.sh-tbl tbody tr:hover,.sh-tbl tbody tr:focus-visible{background:var(--row-hover,var(--soft));outline:0}
.sh-pos{color:var(--ok);font-weight:700}
.sh-empty{color:var(--sub);font-size:13px;margin:10px 0}
.sh-top{margin-bottom:12px}
.sh-wait{color:var(--sub);font-size:13px}
/* 설정 탭 (25 ~ 28번) */
#settings{gap:0;padding-bottom:0;scroll-margin-top:150px}
#whaleRow{flex-wrap:wrap}#whaleRow .st-l{flex:1 1 100%}#whaleRow .st-btns{flex:1 1 100%;justify-content:flex-start}#whaleRow select{max-width:100%;flex:1}
.st-head{display:flex;align-items:flex-end;gap:22px;border-bottom:1px solid var(--line);margin:-2px 0 18px}
.st-head h2{margin:0 0 10px}
.st-tabs{display:flex;gap:4px}
.st-tabs button{border:0;background:none;padding:8px 12px 10px;font-size:13.5px;font-weight:600;color:var(--sub);cursor:pointer;border-bottom:2.5px solid transparent;margin-bottom:-1px}
.st-tabs button[aria-selected="true"]{color:var(--ink);font-weight:750;border-bottom-color:var(--acc)}
.st-tabs button:hover{color:var(--ink)}
.st-cols{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 26px;align-items:start}
.st-cols.one{grid-template-columns:minmax(0,820px)}
@media (max-width:1000px){.st-cols{grid-template-columns:1fr}}
.st-col{display:grid;gap:10px;align-content:start}
.st-h{font-size:14px;font-weight:750;margin:6px 0 0;display:flex;align-items:center}
.st-h4{font-size:13px;font-weight:700;margin:6px 0 0;display:flex;align-items:center}
.st-hrow{display:flex;align-items:center;gap:8px}.st-hrow .st-h,.st-hrow .st-h4{margin-top:6px}
.st-card{border:1px solid var(--line);border-radius:12px;background:var(--soft);overflow:hidden}
.st-row{display:flex;align-items:center;gap:12px;padding:11px 14px;border-top:1px solid var(--line)}
.st-row:first-child{border-top:0}
.st-row.st-top{align-items:flex-start}
.st-l{flex:1;min-width:0;display:grid;gap:2px}.st-l b{font-size:13px;font-weight:700;display:flex;align-items:center}.st-l small{font-size:11.5px;color:var(--sub);line-height:1.45}
.st-l.st-k{flex:0 0 84px}
.st-grow{flex:1;min-width:0}
.st-plain{background:none}
.st-val{font-size:12.5px;color:var(--sub)}
.st-num{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--sub)}
.st-num em{font-style:normal}
.st-num input{width:96px;height:32px;text-align:right;font:inherit;font-size:13px}
.st-row select{width:auto;max-width:360px}
.st-btns{display:flex;flex-wrap:wrap;gap:6px;align-items:center;justify-content:flex-end}
.st-hsel{display:none}
.st-sw,.st-sw2{flex:0 0 auto}
.st-sw[aria-checked="true"] i,.st-sw2.on i{background:var(--g-brand)}
.st-sw[aria-checked="true"] i::after,.st-sw2.on i::after{transform:translateX(16px)}
.st-seg{display:inline-flex;border:1px solid var(--line);border-radius:8px;overflow:hidden}
.st-seg button{border:0;background:none;padding:6px 12px;font-size:12.5px;color:var(--sub);cursor:pointer;border-left:1px solid var(--line)}
.st-seg button:first-child{border-left:0}
.st-seg button[aria-pressed="true"]{color:var(--ink);font-weight:750;box-shadow:inset 0 -2px 0 var(--acc)}
.st-misc{padding:12px 14px;display:grid;gap:10px;background:none}
.st-sum{padding:14px 16px;display:grid;gap:8px;margin-bottom:16px}
.st-sumh{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.st-sl{font-size:13px;font-weight:700}.st-big{font-size:19px;font-weight:800;background:var(--g-brand);-webkit-background-clip:text;background-clip:text;color:transparent}
.st-sumh small,.st-sumr{font-size:12px;color:var(--sub)}
.st-chk{margin:0;font-size:12.5px;color:var(--sub)}.st-chk b{color:var(--ok);margin-right:4px}.st-chk.warn{color:var(--warn)}
.st-sm{font-size:11.5px;color:var(--sub);margin:0;font-weight:500}.st-blk{display:block;margin-top:6px}
.st-msg:empty{display:none}
.st-pick{display:inline-flex;align-items:center;gap:4px;height:28px;padding:0 6px 0 12px;border-radius:99px;background:var(--g-brand);color:#fff;font-size:12.5px;font-weight:700}
.st-pick button{border:0;background:none;color:inherit;cursor:pointer;font-size:11px;padding:2px 4px}
.st-sites{display:flex;flex-wrap:wrap;gap:6px 14px;padding:4px 14px 12px 14px;font-size:12.5px;border-top:1px dashed var(--line)}
.st-gx{font-size:12px;color:var(--sub)}
.st-foot{position:sticky;bottom:0;z-index:5;display:flex;align-items:center;gap:8px;margin:20px -20px 0;padding:12px 20px;border-top:1px solid var(--line);background:var(--panel);border-radius:0 0 var(--r-l,16px) var(--r-l,16px)}
.st-foot .hint{font-size:12px}
`;
  document.head.appendChild(st);
}
function seBind() {
  seCss();
  if (!$('#seDlg')) { const d = document.createElement('dialog'); d.id = 'seDlg'; d.className = 'invdlg'; document.body.appendChild(d); }
  const menu = $('#seMenu'); menu.innerHTML = seMenuHTML();
  const closeMenu = () => { menu.hidden = true; $('#seGoMore').setAttribute('aria-expanded', 'false'); };
  $('#seGo').addEventListener('click', () => seStart({ kind: 'product' }));
  $('#seGoMore').addEventListener('click', e => { e.stopPropagation(); menu.hidden = !menu.hidden; $('#seGoMore').setAttribute('aria-expanded', String(!menu.hidden)); });
  document.addEventListener('click', e => { if (!menu.hidden && !e.target.closest('#seMenu')) closeMenu(); });
  menu.addEventListener('click', e => {
    const b = e.target.closest('[data-sego]'); if (!b) return; closeMenu();
    const k = b.dataset.sego, sub = b.dataset.sub || '';
    if (k === 'code' || (k === 'popular' && sub === 'kw')) return seAsk(k, sub);
    seStart({ kind: k, sub });
  });
  $('#seResume').addEventListener('click', () => seResume());
  $('#seStop').addEventListener('click', () => seStopNow());
  $('#seSchedBtn').addEventListener('click', () => seSchedList());
  $('#seCritGo').addEventListener('click', () => seOpenSettings('calc'));
  const d = $('#seDlg');
  d.addEventListener('click', async e => {
    if (e.target === d) return d.close();
    const a = e.target.closest('[data-sedlg]');
    if (a) {
      const k = a.dataset.sedlg;
      if (k === 'close') return d.close();
      if (k === 'new') return seSchedForm(null);
      if (k === 'list') return seSchedList();
      if (k === 'save') return seSchedFormSave();
      if (k === 'gen') { d.close(); return seOpenSettings('gen'); }
      if (k === 'ask') { const v = ($('#seAskIn').value || '').trim(); if (!v) { $('#seAskMsg').textContent = '내용을 넣어 주세요'; return; } d.close(); return d.dataset.kind === 'code' ? seStart({ kind: 'code', list: v }) : seStart({ kind: 'popular', sub: 'kw', kw: v }); }
    }
    const ed = e.target.closest('[data-seed]'); if (ed) return seSchedForm(SE.scheds.find(s => s.id === ed.dataset.seed));
    const del = e.target.closest('[data-sedel]'); if (del) { SE.scheds = SE.scheds.filter(s => s.id !== del.dataset.sedel); await seSchedSave(); return seSchedList(); }
  });
  d.addEventListener('change', async e => {
    const on = e.target.closest('[data-seon]');
    if (on) { const s = SE.scheds.find(x => x.id === on.dataset.seon); if (s) { s.on = on.checked; if (s.on) { s.since = Date.now(); s.n = 0; s.last = 0; } await seSchedSave(); seSchedList(); } return; }
    if ($('#seSF')) seSchedFormSync();
  });
  d.addEventListener('input', () => { if ($('#seSF')) seSchedFormSync(); });
  // 엔터를 눌러도 화면이 새로고침되지 않게 (키워드 창은 엔터 = 실행)
  d.addEventListener('submit', e => { e.preventDefault(); if (e.target.id === 'seAskF' && e.target.querySelector('input#seAskIn')) { const b = d.querySelector('[data-sedlg="ask"]'); if (b) b.click(); } });
  shBind(); stBind();
  // 1초마다 경과 시간 · 남은 시간
  setInterval(() => { if (SE.busy) sePaint(); }, 1000);
}

async function seInit() {
  if (!$('#seGo')) return;
  SE.scope = { ...SE_SCOPE_DEF, ...((await store.get('srcScope', {})) || {}) }; SE.scope.groups = { ...SE_SCOPE_DEF.groups, ...(SE.scope.groups || {}) };
  SE.calc = { ...SE_CALC_DEF, ...((await store.get('srcCalc', {})) || {}) }; SE.calc.rec = { ...SE_CALC_DEF.rec, ...(SE.calc.rec || {}) };
  SE.rows = (await store.get('srcRows', [])) || []; if (!Array.isArray(SE.rows)) SE.rows = []; seRowsIndex();
  SE.scheds = (await store.get('srcScheds', [])) || []; if (!Array.isArray(SE.scheds)) SE.scheds = [];
  SE.first = (await store.get('srcFirst', {})) || {};
  SE.supUrl = (await store.get('srcSupUrl', {})) || {};
  SE.run = (await store.get('srcRun', null)) || null;
  // 프로그램이 꺼져서 끊긴 실행은 '중단 · 킥스캔 꺼짐'으로 — [이어서 하기]로 이어서 하고, 소싱 이력에도 남겨요
  if (SE.run && SE.run.state === 'run') {
    SE.run.state = 'stop'; SE.run.why = 'off'; SE.run.lastAt = SE.run.lastAt || SE.run.startedAt; SE.run.stoppedAt = SE.run.lastAt;
    await store.set('srcRun', SE.run);
    try { await seHistSave(); } catch (e) { console.warn(e); }
  }
  await seMigrate();
  seBind(); sePaint(); seSay(SE.msg);
  if (typeof renderSrcResult === 'function') { try { renderSrcResult(); } catch (e) { console.warn(e); } }
  if (!/[?&](orders|track)=1/.test(location.search)) { setTimeout(seSchedTick, 20000); SE.tick = setInterval(seSchedTick, 60000); }
}
window.addEventListener('DOMContentLoaded', () => { setTimeout(() => { seInit().catch(e => console.warn('srceng', e)); }, 0); });
