/* 킥스캔 — 매입 등록 창 (줍픽 재고 › 매입 등록 팝업)
   - 위 탭: 직접 등록(한 상품씩) · 일괄 등록(여러 상품을 한 번에: 바코드로 담기 · 엑셀 붙여넣기)
   - 공통 줄: 매장 · 매입일 · ☐ POIZON 창고 보관 재고 · ☐ KREAM 창고 보관 재고 · 반품 기한은 브랜드가 정해요(stock.js retDaysOf)
   - 바코드로 담기: 바코드나 품번을 입력하고 Enter — 핸드 스캐너는 어느 칸에 커서가 있어도 바로 담겨요 · 같은 사이즈를 또 찍으면 수량 +1
   - 엑셀 붙여넣기: 머리글째 붙여넣기 · 열 A 품번 · B 사이즈 · C 수량 · D 매입가 · E 색 · F 매입일 · G 매장 · [예시 넣기] [대조해 보기]
   만든 매입은 INV.lots 에 src 'manual' 로 들어가요 — 저장하면 자동 판매 등록(rules.js)이 새 매입을 찾아요. */
const BR = { open: false, tab: 'one', sub: 'bc', part: '', date: '', wh: '', q: '', hit: null, sizes: [], cart: [], paste: '', parsed: null, msg: '', scan: '', scanT: 0 };
const brBuyParts = () => INV.partners.filter(p => p.kind === 'buy');
const brEl = () => document.getElementById('brDlg');
function brOpen(tab) {
  Object.assign(BR, { open: true, tab: tab || BR.tab || 'one', date: BR.date || today(), msg: '', hit: null, sizes: [], q: '' });
  if (!brBuyParts().some(p => p.id === BR.part)) BR.part = (brBuyParts()[0] || {}).id || '';
  let d = brEl(); if (!d) { d = document.createElement('div'); d.id = 'brDlg'; d.className = 'br-ov'; document.body.appendChild(d); brBind(d); }
  d.hidden = false; brPaint();
  setTimeout(() => { const i = d.querySelector('[data-br-in=q]'); if (i) i.focus(); }, 50);
}
function brClose() { BR.open = false; const d = brEl(); if (d) d.hidden = true; }
// 품번 · 바코드로 상품 찾기 → { it, size } | { it } | null
function brFind(q) {
  q = String(q || '').trim(); if (!q) return null;
  const b = typeof findBarcode === 'function' ? findBarcode(q) : null; if (b) return b;
  const k = codeKey(q); const it = INV.items.find(x => String(x.code || '').split('/').some(c => codeKey(c) === k));
  return it ? { it } : null;
}
function brNewItem(code, name, brand) {
  const it = { id: uid(), code: String(code || '').trim().toUpperCase(), name: String(name || '').trim() || String(code || '').trim(), brand: String(brand || '').trim(), cat: '', sub: '', sizes: [], barcodes: {}, memo: '', created: Date.now() };
  INV.items.unshift(it); if (it.brand && INV.brands && !INV.brands.includes(it.brand)) INV.brands.push(it.brand);
  return it;
}
function brLot(it, size, qty, cost, date, partId, memo) {
  const p = partnerOf(partId), d = date || BR.date || today();
  const l = { id: uid(), at: Date.now() + Math.random(), date: d, itemId: it.id, size: String(size), qty: +qty || 1, cost: +cost || 0, partnerId: partId || '', payId: '', memo: memo || '', src: 'manual',
    returnDue: BR.wh ? '' : addDays(d, typeof retDaysOf === 'function' ? retDaysOf(p, it) : (p && p.returnDays != null ? +p.returnDays : +INV.opt.returnDays)), retQty: 0, exQty: 0, events: [] };
  if (BR.wh) l.wh = BR.wh;   // 창고 보관 재고(이미 POIZON · KREAM 창고에 있음) — 반품 기한 없음
  INV.lots.push(l); if (!(it.sizes || []).includes(String(size))) (it.sizes = it.sizes || []).push(String(size));
  return l;
}

// ---------- 화면 ----------
function brCommon() {
  const ps = brBuyParts();
  return `<div class="br-common">
    ${ps.length ? `<label>매장<select data-br-in="part">${ps.map(p => `<option value="${p.id}"${p.id === BR.part ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}</select></label>` : '<span class="br-warn">등록된 매장이 없어요 — 매입은 매장에 붙어요</span>'}
    <button type="button" class="ghost small" data-br="store">매장 추가</button>
    <label>매입일<input type="date" data-br-in="date" value="${esc(BR.date)}"></label>
    <label class="chk"><input type="checkbox" data-br-in="whp"${BR.wh === 'poizon' ? ' checked' : ''}> POIZON 창고 보관 재고</label>
    <label class="chk"><input type="checkbox" data-br-in="whk"${BR.wh === 'kream' ? ' checked' : ''}> KREAM 창고 보관 재고</label>
    <span class="small">반품 기한은 브랜드가 정해요</span></div>`;
}
function brOne() {
  const h = BR.hit;
  const found = h && h.it ? `<div class="br-hit"><b>${esc(itName(h.it))}</b> <span class="small mono">${esc(h.it.code || '')}</span>
      <table class="main br-t"><thead><tr><th class="l">사이즈</th><th>수량</th><th>개당 매입가</th><th></th></tr></thead><tbody>
      ${BR.sizes.map((r, i) => `<tr><td class="l"><input data-br-row="size" data-i="${i}" value="${esc(r.size)}" placeholder="예: 270" class="mini" style="width:90px"></td><td><input type="number" min="1" data-br-row="qty" data-i="${i}" value="${r.qty}" class="mini" style="width:70px"></td><td><input type="number" step="1000" data-br-row="cost" data-i="${i}" value="${r.cost}" class="mini" style="width:110px" placeholder="매입가"></td><td><button type="button" class="x" data-br="rowDel" data-i="${i}" aria-label="빼기">×</button></td></tr>`).join('')}
      </tbody></table><div class="row-btns"><button type="button" class="ghost small" data-br="rowAdd">+ 사이즈 더하기</button><span class="topsp"></span><button type="button" class="primary" data-br="oneSave">매입 등록</button></div></div>`
    : h && h.none ? `<div class="br-hit"><p class="small">'${esc(h.none)}' 상품이 아직 없어요 — 새로 만들어 등록해요</p><div class="row-btns"><input data-br-in="nName" placeholder="상품명" class="mini" style="width:240px"><input data-br-in="nBrand" placeholder="브랜드" class="mini" style="width:120px"><button type="button" class="ghost small" data-br="newItem">상품 만들기</button></div></div>` : '';
  return `<div class="br-search"><input data-br-in="q" value="${esc(BR.q)}" placeholder="품번 또는 바코드 — 예: DJ3524-001" autocomplete="off"><button type="button" class="ghost" data-br="find">찾기</button></div>
    <p class="small">핸드 스캐너로 바코드(박스 · 택)를 찍어도 바로 찾아요.</p>${found}`;
}
function brBc() {
  const sum = BR.cart.reduce((t, r) => t + (+r.qty || 0), 0);
  return `<div class="br-search"><input data-br-in="q" value="${esc(BR.q)}" placeholder="바코드나 품번을 입력하고 Enter" autocomplete="off"><button type="button" class="ghost" data-br="bcAdd">찾기</button>${BR.cart.length ? '<button type="button" class="ghost" data-br="cartClear">그만두기</button>' : ''}</div>
    <p class="small">핸드 스캐너로 찍으면 바로 담겨요 — 어느 칸에 커서가 있어도 돼요. 같은 사이즈를 또 찍으면 수량이 하나씩 늘어요.</p>
    ${BR.cart.length ? `<table class="main br-t"><thead><tr><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>개당 매입가</th><th></th></tr></thead><tbody>
      ${BR.cart.map((r, i) => `<tr><td class="l">${esc(r.it ? itName(r.it) : r.code)}${r.it ? '' : ' <span class="pill warn">새 상품</span>'}</td><td class="l"><input data-br-cart="size" data-i="${i}" value="${esc(r.size || '')}" class="mini" style="width:80px"${r.fixed ? ' readonly' : ''}></td><td><input type="number" min="1" data-br-cart="qty" data-i="${i}" value="${r.qty}" class="mini" style="width:64px"></td><td><input type="number" step="1000" data-br-cart="cost" data-i="${i}" value="${r.cost || ''}" class="mini" style="width:110px" placeholder="매입가"></td><td><button type="button" class="x" data-br="cartDel" data-i="${i}" aria-label="빼기">×</button></td></tr>`).join('')}
      </tbody></table><div class="row-btns"><span class="small">${BR.cart.length}가지 · ${sum}개</span><span class="topsp"></span><button type="button" class="primary" data-br="cartSave">${sum}개 매입 등록</button></div>`
    : '<div class="br-empty"><b>바코드(박스 · 택)를 차례로 찍거나 품번을 입력하세요</b><span class="small">영수증 사진 인식은 아직 안 돼요 — 영수증의 품번을 입력해 주세요.</span></div>'}`;
}
const BR_EX = '품번\t사이즈\t수량\t매입가\t색\t매입일\t매장\nDD1391-100\t270\t2\t89000\t\t\t\nCW2288-111\t265\t1\t99000\t화이트\t\t';
function brParse(txt) {
  const lines = String(txt || '').split(/\r?\n/).map(l => l.split('\t').map(c => c.trim())).filter(r => r.some(Boolean));
  if (!lines.length) return [];
  const head = lines[0].join(' ');
  const body = /품번|사이즈|수량|매입가/.test(head) ? lines.slice(1) : lines;
  const dt = s => { s = String(s || '').trim(); let m = s.match(/^(\d{4})[-./](\d{1,2})[-./](\d{1,2})/) || s.match(/^(\d{2})[.](\d{1,2})[.](\d{1,2})/); if (!m) return ''; const y = m[1].length === 2 ? '20' + m[1] : m[1]; return `${y}-${String(m[2]).padStart(2, '0')}-${String(m[3]).padStart(2, '0')}`; };
  return body.map(c => {
    const code = c[0] || '', f = brFind(code), part = c[6] ? (INV.partners.find(p => p.name === c[6]) || null) : null;
    return { code, size: c[1] || '', qty: Math.max(1, Math.floor(+String(c[2] || '1').replace(/[^\d]/g, '') || 1)), cost: +String(c[3] || '').replace(/[^\d]/g, '') || 0, color: c[4] || '', date: dt(c[5]), store: c[6] || '', part, it: f ? f.it : null,
      why: !code ? '품번이 없어요' : !(c[1]) ? '사이즈가 없어요' : !String(c[3] || '').replace(/[^\d]/g, '') ? '매입가가 없어요' : c[6] && !part ? `매장 '${c[6]}'이 없어요 — 매장 사전에서 넣어 주세요` : '' };
  });
}
function brPaste() {
  const P = BR.parsed;
  return `<p class="small">엑셀에서 머리글 행까지 복사해 붙여넣으세요. 매입일 · 매장 칸이 있으면 행마다 그 값으로 등록해요. 열 A 품번 · B 사이즈 · C 수량 · D 매입가 · E 색(선택) · F 매입일(선택) · G 매장(선택)</p>
    <textarea data-br-in="paste" rows="7" class="br-paste" placeholder="여기에 붙여넣기">${esc(BR.paste)}</textarea>
    <div class="row-btns"><button type="button" class="ghost small" data-br="example">예시 넣기</button><button type="button" class="ghost small" data-br="check">대조해 보기</button><span class="small">붙여넣으면 킥스캔 상품과 비교해요</span></div>
    ${P ? `<table class="main br-t"><thead><tr><th class="l">품번</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>매입가</th><th class="l">매입일 · 매장</th><th class="l">상태</th></tr></thead><tbody>
      ${P.map(r => `<tr><td class="l mono">${esc(r.code)}</td><td class="l">${r.it ? esc(itName(r.it)) : '<span class="pill warn">새 상품</span>'}</td><td class="l">${esc(r.size)}</td><td>${r.qty}</td><td>${won(r.cost)}</td><td class="l small">${esc(r.date || BR.date)} · ${esc(r.store || (partnerOf(BR.part) || {}).name || '')}</td><td class="l">${r.why ? `<span class="pill bad">${esc(r.why)}</span>` : '<span class="pill ok">준비됨</span>'}</td></tr>`).join('')}
      </tbody></table><div class="row-btns"><span class="small">준비된 ${P.filter(r => !r.why).length}줄 · 빈칸 있음 ${P.filter(r => r.why).length}줄</span><span class="topsp"></span><button type="button" class="primary" data-br="pasteSave"${P.some(r => !r.why) ? '' : ' disabled'}>준비된 ${P.filter(r => !r.why).reduce((t, r) => t + r.qty, 0)}개 매입 등록</button></div>` : ''}`;
}
function brPaint() {
  const d = brEl(); if (!d || !BR.open) return;
  const body = BR.tab === 'one' ? brOne() : `<div class="subtabs br-sub"><button type="button" data-br="sub" data-v="bc" aria-selected="${BR.sub === 'bc'}">바코드로 담기</button><button type="button" data-br="sub" data-v="paste" aria-selected="${BR.sub === 'paste'}">엑셀 붙여넣기</button></div>${BR.sub === 'paste' ? brPaste() : brBc()}`;
  d.innerHTML = `<div class="br-box" role="dialog" aria-modal="true" aria-label="매입 등록"><div class="br-head"><h3>매입 등록</h3><button type="button" class="sr-x" data-br="close" aria-label="닫기">✕</button></div>
    <div class="subtabs"><button type="button" data-br="tab" data-v="one" aria-selected="${BR.tab === 'one'}">직접 등록 <small>한 상품씩</small></button><button type="button" data-br="tab" data-v="bulk" aria-selected="${BR.tab === 'bulk'}">일괄 등록 <small>여러 상품을 한 번에</small></button></div>
    ${brCommon()}${BR.msg ? `<p class="iflash">${esc(BR.msg)}</p>` : ''}<div class="br-body">${body}</div></div>`;
}

// ---------- 동작 ----------
function brScan(code) {
  code = String(code || '').trim(); if (!code) return;
  const f = brFind(code);
  if (f && f.size) { const same = BR.cart.find(r => r.it === f.it && r.size === f.size); if (same) same.qty++; else BR.cart.push({ it: f.it, code: f.it.code, size: f.size, qty: 1, cost: '', fixed: true }); BR.msg = `${itName(f.it)} ${f.size} 담았어요`; }
  else if (f) { BR.cart.push({ it: f.it, code: f.it.code, size: '', qty: 1, cost: '' }); BR.msg = `${itName(f.it)} — 사이즈를 넣어 주세요`; }
  else { BR.cart.push({ it: null, code, size: '', qty: 1, cost: '' }); BR.msg = `'${code}' 상품이 없어요 — 새 상품으로 담았어요(사이즈 · 매입가를 넣어 주세요)`; }
  BR.q = ''; brPaint(); const i = brEl().querySelector('[data-br-in=q]'); if (i) i.focus();
}
async function brSaveDone(n, what) { await invSave(); BR.msg = `${n}개 매입을 등록했어요${what ? ' — ' + what : ''}`; try { renderInv(); } catch (e) {} brPaint(); }
async function brAct(a, el) {
  const i = +el.dataset.i;
  switch (a) {
    case 'close': return brClose();
    case 'tab': BR.tab = el.dataset.v; BR.msg = ''; break;
    case 'sub': BR.sub = el.dataset.v; BR.msg = ''; break;
    case 'store': if (typeof storeDictOpen === 'function') storeDictOpen(); return;
    case 'find': { const f = brFind(BR.q); if (!f) { BR.hit = { none: BR.q.trim() }; BR.sizes = []; } else { BR.hit = f; BR.sizes = [{ size: f.size || '', qty: 1, cost: '' }]; } BR.msg = ''; break; }
    case 'newItem': { const n = brEl().querySelector('[data-br-in=nName]'), b = brEl().querySelector('[data-br-in=nBrand]'); const it = brNewItem(BR.hit.none, n && n.value, b && b.value); BR.hit = { it }; BR.sizes = [{ size: '', qty: 1, cost: '' }]; break; }
    case 'rowAdd': BR.sizes.push({ size: '', qty: 1, cost: (BR.sizes[BR.sizes.length - 1] || {}).cost || '' }); break;
    case 'rowDel': BR.sizes.splice(i, 1); break;
    case 'oneSave': {
      if (!BR.part) { BR.msg = '매장을 먼저 넣어 주세요'; break; }
      const ok = BR.sizes.filter(r => String(r.size).trim() && +r.qty > 0 && +r.cost > 0);
      if (!ok.length) { BR.msg = '사이즈 · 수량 · 매입가를 넣어 주세요'; break; }
      for (const r of ok) brLot(BR.hit.it, String(r.size).trim(), r.qty, r.cost, BR.date, BR.part);
      const n = ok.reduce((t, r) => t + +r.qty, 0); BR.hit = null; BR.sizes = []; BR.q = ''; return brSaveDone(n, '재고 현황에 들어갔어요');
    }
    case 'bcAdd': return brScan(BR.q);
    case 'cartDel': BR.cart.splice(i, 1); break;
    case 'cartClear': BR.cart = []; BR.msg = ''; break;
    case 'cartSave': {
      if (!BR.part) { BR.msg = '매장을 먼저 넣어 주세요'; break; }
      const bad = BR.cart.find(r => !String(r.size || '').trim() || !(+r.cost > 0)); if (bad) { BR.msg = `${bad.it ? itName(bad.it) : bad.code}: 사이즈와 매입가를 넣어 주세요`; break; }
      let n = 0; for (const r of BR.cart) { const it = r.it || brNewItem(r.code, r.code, ''); brLot(it, String(r.size).trim(), r.qty, r.cost, BR.date, BR.part); n += +r.qty; }
      BR.cart = []; return brSaveDone(n);
    }
    case 'example': BR.paste = BR_EX; BR.parsed = null; break;
    case 'check': BR.parsed = brParse(BR.paste); if (!BR.parsed.length) BR.msg = '붙여넣은 줄이 없어요'; break;
    case 'pasteSave': {
      const P = (BR.parsed || []).filter(r => !r.why); if (!P.length) break;
      const partId = r => r.part ? r.part.id : BR.part; if (P.some(r => !partId(r))) { BR.msg = '매장을 먼저 넣어 주세요'; break; }
      let n = 0; for (const r of P) { const it = r.it || brFind(r.code)?.it || brNewItem(r.code, r.code, ''); brLot(it, r.size, r.qty, r.cost, r.date || BR.date, partId(r), r.color ? '색 ' + r.color : ''); n += r.qty; }
      BR.parsed = null; BR.paste = ''; return brSaveDone(n);
    }
  }
  brPaint();
}
function brBind(d) {
  d.addEventListener('click', e => { if (e.target === d) return brClose(); const b = e.target.closest('[data-br]'); if (b) brAct(b.dataset.br, b).catch(x => { BR.msg = '오류: ' + x.message; brPaint(); }); });
  d.addEventListener('input', e => {
    const t = e.target;
    if (t.dataset.brIn === 'q') BR.q = t.value; else if (t.dataset.brIn === 'paste') { BR.paste = t.value; BR.parsed = null; }
    else if (t.dataset.brRow) BR.sizes[+t.dataset.i][t.dataset.brRow] = t.value;
    else if (t.dataset.brCart) BR.cart[+t.dataset.i][t.dataset.brCart] = t.dataset.brCart === 'qty' ? Math.max(1, +t.value || 1) : t.value;
  });
  d.addEventListener('change', e => {
    const t = e.target, k = t.dataset.brIn;
    if (k === 'part') BR.part = t.value; else if (k === 'date') BR.date = t.value || today();
    else if (k === 'whp' || k === 'whk') { BR.wh = t.checked ? (k === 'whp' ? 'poizon' : 'kream') : ''; brPaint(); }
  });
  d.addEventListener('keydown', e => {
    if (e.key === 'Escape') return brClose();
    if (e.key === 'Enter' && e.target.dataset.brIn === 'q') { e.preventDefault(); if (BR.tab === 'one') brAct('find', e.target); else brScan(BR.q); }
  });
  // 핸드 스캐너: 어느 칸에 커서가 있어도 빠른 연속 입력 + Enter 면 바로 담아요 (바코드로 담기 탭)
  document.addEventListener('keydown', e => {
    if (!BR.open || BR.tab !== 'bulk' || BR.sub !== 'bc' || e.target.dataset && e.target.dataset.brIn === 'q') return;
    const now = Date.now();
    if (e.key === 'Enter') { if (BR.scan.length >= 6 && now - BR.scanT < 80) { e.preventDefault(); const c = BR.scan; BR.scan = ''; brScan(c); } BR.scan = ''; return; }
    if (e.key.length === 1) { BR.scan = now - BR.scanT < 80 ? BR.scan + e.key : e.key; BR.scanT = now; }
  }, true);
}
