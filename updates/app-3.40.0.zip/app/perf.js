/* 킥스캔 — 소싱 성과 (줍픽 소싱 › 성과: 매입 내역 · 매입처별 · 점검표 · 습관 점검)
   소싱 이력(srcHist + srcHistRows_*)의 수익 상품 품번과 그때 시각을 모아서, 그 뒤 30일 안에 재고관리에 들어온 같은 품번 매입을 '소싱 매입'으로 봐요.
   카드: 소싱 매입 · 판매 · 판매 수익 · 재고 · 이용권 요금 대비 */
const PF = { at: 0, seen: null, tab: 'buy', busy: false };
async function pfLoad() {
  if (PF.busy) return; PF.busy = true;
  const seen = new Map();   // codeKey → { at 처음 수익 상품으로 본 때, name, buy 그때 매입가, site }
  try {
    const H = (await store.get('srcHist', [])) || [];
    for (const h of H) {
      const rows = (await store.get('srcHistRows_' + h.id, [])) || [];
      for (const r of rows) if (r && r.prof && r.code) { const k = codeKey(r.code), b = (r.buy || [])[0]; const o = seen.get(k); if (!o || h.startedAt < o.at) seen.set(k, { at: h.startedAt, name: r.name || r.code, buy: b ? b.price : null, site: b ? b.label : '' }); }
    }
    for (const r of (typeof SE !== 'undefined' ? SE.rows : [])) if (r && r.prof && r.code) { const k = codeKey(r.code); if (!seen.has(k)) { const b = (r.buy || [])[0]; seen.set(k, { at: (SE.run && SE.run.startedAt) || Date.now(), name: r.name || r.code, buy: b ? b.price : null, site: b ? b.label : '' }); } }
  } catch (e) {}
  PF.seen = seen; PF.at = Date.now(); PF.busy = false;
  if (typeof curView !== 'undefined' && curView === 'perf') renderX();
}
function pfData() {
  if (!PF.seen || typeof INV === 'undefined') return null;
  const C = invCalc(), lots = [];
  for (const l of INV.lots) {
    if (/^(adjust|exchange|return|import)$/.test(l.src || '')) continue;
    const it = itemOf(l.itemId); if (!it) continue;
    const k = String(it.code || '').split('/').map(codeKey).find(c => PF.seen.has(c)); if (!k) continue;
    const s = PF.seen.get(k); if ((l.at || 0) < s.at || (l.at || 0) > s.at + 30 * 864e5) continue;
    lots.push({ l, it, s, left: C.left.get(l.id) || 0 });
  }
  const ids = new Set(lots.map(x => x.l.id));
  let soldQ = 0, rev = 0, margin = 0;
  for (const o of INV.outs) { const cs = (o.costs || []).filter(c => ids.has(c.lotId)); if (!cs.length || !o.settled) continue; const q = cs.reduce((t, c) => t + c.qty, 0), x = outNums(o); const share = q / (o.qty || 1); soldQ += q; rev += x.rev * share; margin += (x.margin || 0) * share; }
  const buyQ = lots.reduce((t, x) => t + (+x.l.qty || 0), 0), buyAmt = lots.reduce((t, x) => t + (+x.l.qty || 0) * (+x.l.cost || 0), 0);
  const leftQ = lots.reduce((t, x) => t + x.left, 0), leftAmt = lots.reduce((t, x) => t + x.left * (+x.l.cost || 0), 0);
  return { lots, buyQ, buyAmt, soldQ, rev, margin, leftQ, leftAmt };
}
function vPerf() {
  if (!PF.seen) { pfLoad(); return `${xHead('성과', '소싱으로 찾은 수익 상품을 실제로 사서 얼마나 팔고 남겼는지 봐요.')}<div class="panel dl-empty"><span>소싱 이력을 모으는 중이에요…</span></div>`; }
  const D = pfData(); if (!D) return `${xHead('성과', '')}<div class="panel dl-empty"><span>재고관리를 먼저 열어 주세요</span></div>`;
  const plan = (typeof LICST !== 'undefined' && LICST && (LICST.price || LICST.amount)) || 0;
  const cards = `<div class="kgrid stk-cards">${card('소싱 매입', `${D.buyQ}개`, 'warn', won(D.buyAmt))}${card('판매', `${D.soldQ}개`, 'acc', `소진율 ${D.buyQ ? Math.round(D.soldQ / D.buyQ * 100) : 0}% · 매출 ${won(Math.round(D.rev))}`)}${card('판매 수익', wonS(Math.round(D.margin)), D.margin >= 0 ? 'pos' : 'neg', '수수료 · 매입가 뺀 손익')}${card('재고', `${D.leftQ}개`, '', won(D.leftAmt))}${card('이용권 요금 대비', plan ? `${Math.round(D.margin / plan * 10) / 10}배` : '–', '', plan ? `요금 ${won(plan)}` : '이용권 요금 정보가 없어요')}</div>`;
  const tabs = [['buy', '매입 내역'], ['site', '매입처별'], ['check', '점검표'], ['habit', '습관 점검']];
  let body = '';
  if (PF.tab === 'buy') body = `<div class="tbl"><table class="main"><thead><tr><th class="l">매입일</th><th class="l">상품</th><th class="l">사이즈</th><th>수량</th><th>매입가</th><th>소싱 때 매입가</th><th class="l">소싱에서 본 날</th><th>남은 재고</th></tr></thead><tbody>${D.lots.sort((a, b) => (b.l.at || 0) - (a.l.at || 0)).map(x => `<tr><td class="l">${esc(x.l.date || '')}</td><td class="l">${esc(itName(x.it))}</td><td class="l">${esc(x.l.size)}</td><td>${x.l.qty}</td><td>${won(x.l.cost)}</td><td>${x.s.buy ? won(x.s.buy) : '–'}</td><td class="l">${new Date(x.s.at).toLocaleDateString('ko-KR')}</td><td>${x.left}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">소싱 결과의 수익 상품을 [매입 등록]으로 넣으면 여기서 판매 · 판매 수익까지 집계해요.</td></tr>'}</tbody></table></div>`;
  else if (PF.tab === 'site') {
    const G = {}; for (const x of D.lots) { const k = (partnerOf(x.l.partnerId) || {}).name || x.s.site || '매입처 없음'; const g = G[k] = G[k] || { n: 0, amt: 0, left: 0 }; g.n += +x.l.qty || 0; g.amt += (+x.l.qty || 0) * (+x.l.cost || 0); g.left += x.left; }
    body = `<div class="tbl"><table class="main"><thead><tr><th class="l">매입처</th><th>매입 수량</th><th>매입액</th><th>남은 재고</th><th>소진율</th></tr></thead><tbody>${Object.entries(G).sort((a, b) => b[1].amt - a[1].amt).map(([k, g]) => `<tr><td class="l">${esc(k)}</td><td>${g.n}개</td><td>${won(g.amt)}</td><td>${g.left}개</td><td>${g.n ? Math.round((g.n - g.left) / g.n * 100) : 0}%</td></tr>`).join('') || '<tr><td colspan="5" class="empty">기록이 없어요</td></tr>'}</tbody></table></div>`;
  } else if (PF.tab === 'check') {
    const C = invCalc(), bids = new Set((typeof abList !== 'undefined' ? abList : []).filter(a => !a.gone).map(a => codeKey(a.code || '')));
    const notListed = D.lots.filter(x => x.left > 0 && !String(x.it.code || '').split('/').some(c => bids.has(codeKey(c))));
    const dueSoon = D.lots.filter(x => x.left > 0 && x.l.returnDue && dday(x.l.returnDue) >= 0 && dday(x.l.returnDue) <= 3);
    const dearer = D.lots.filter(x => x.s.buy && +x.l.cost > x.s.buy * 1.03);
    const item = (ok, t, d) => `<li class="${ok ? 'ok' : 'bad'}"><b>${ok ? '✓' : '!'} ${t}</b><span class="small">${d}</span></li>`;
    body = `<ol class="vp-prep">${item(!notListed.length, '산 재고를 판매 등록했어요', notListed.length ? `판매 입찰이 없는 소싱 재고 ${notListed.length}건 — 재고 현황에서 [KREAM 에 올리기]` : '소싱 재고가 모두 판매 등록돼 있어요')}${item(!dueSoon.length, '반품 기한 확인', dueSoon.length ? `반품 기한 3일 안 남은 소싱 재고 ${dueSoon.length}건 — 안 팔릴 것 같으면 반품을 생각해 보세요` : '급한 반품 기한이 없어요')}${item(!dearer.length, '소싱 때 가격으로 샀어요', dearer.length ? `소싱 때보다 3% 넘게 비싸게 산 매입 ${dearer.length}건 — 쿠폰 · 할인을 다시 확인해 보세요` : '소싱 때 매입가와 비슷하게 샀어요')}</ol>`;
  } else {
    const days = []; for (const o of INV.outs) { if (!o.settled) continue; for (const c of o.costs || []) { const x = D.lots.find(y => y.l.id === c.lotId); if (x) days.push(Math.max(0, Math.round((new Date((o.settleDate || o.date) + 'T00:00:00') - new Date(x.l.date + 'T00:00:00')) / 864e5))); } }
    const avg = days.length ? Math.round(days.reduce((t, d) => t + d, 0) / days.length) : null;
    body = `<div class="vp-why"><p><b>매입 → 판매 평균 ${avg == null ? '–' : avg + '일'}</b> (${days.length}건 기준)</p><p><b>소진율 ${D.buyQ ? Math.round(D.soldQ / D.buyQ * 100) : 0}%</b> — 30% 미만이면 살 때 한 번 더 생각해 보고, 70% 이상이면 더 사도 되는 쪽이에요.</p><p><b>개당 수익 ${D.soldQ ? wonS(Math.round(D.margin / D.soldQ)) : '–'}</b> — 소싱 결과에서 본 개당 수익과 비교해 보세요.</p></div>`;
  }
  return `${xHead('성과', '소싱으로 찾은 수익 상품을 실제로 사서 얼마나 팔고 남겼는지 봐요 — 소싱에서 수익 상품으로 본 뒤 30일 안에 산 같은 품번 기준', '<button type="button" class="ghost" data-x="pfReload">↻ 다시 모으기</button>')}
  ${cards}<div class="subtabs">${tabs.map(([k, t]) => `<button type="button" data-x="pfTab" data-i="${k}" aria-selected="${PF.tab === k}">${t}</button>`).join('')}</div>${body}`;
}
(function pfWire() {
  if (typeof X_VIEWS !== 'undefined') X_VIEWS.perf = () => vPerf();
  if (typeof xAct === 'function') { const x0 = xAct; xAct = async function (a, el) { if (a === 'pfTab') { PF.tab = el.dataset.i; return renderX(); } if (a === 'pfReload') { PF.seen = null; return pfLoad(); } return x0(a, el); }; }
})();
