/* 킥스캔 — 재고 (줍픽 오피스 재고: 재고 현황 · 매입 내역 · 반품·반출)
   inv.js 의 데이터(INV.lots · INV.items · INV.partners) · 계산(invCalc · itemRetDue · retOpen) · 시세(mkt.js mktSize)를 그대로 써요.
   - 재고 현황: 카드 4(매입 원가 · 예상 판매가 · 예상 손익 · 반품 임박 7일) · 칩 전체/반품 임박/반품 불가 · 매장 · 검색 · 같은 상품 한 줄(펼치면 입고별)
                선택 → [KREAM 에 올리기](자동 판매 등록 규칙으로) · 입고별 [반품] [폐기] [기타 반출]
   - 매입 내역: 기간 칩 · 카드(건수 · 매입액 · 매장 수) · 주별 막대(색 = 매장, 12개월 · 전체는 달마다) · 표
   - 반품·반출: 아울렛 반품 · 폐기 · 기타 반출 · 카드(회수 금액 · 반품 수량 · 반품 많은 매장) · 표 */
const STK_PER = [['d30', '30일'], ['m3', '3개월'], ['m12', '12개월'], ['all', '전체']];
const STK_COLORS = ['#2f6bff', '#16a34a', '#f59e0b', '#db2777', '#7c3aed', '#0891b2', '#dc2626', '#65a30d', '#9333ea', '#ea580c'];
const stkS = () => IS.stk || (IS.stk = { tab: 'now', chip: 'all', part: '', q: '', open: {}, sel: {}, per: 'm3', out: '반품', allOpen: false, act: null });
const stkPartName = id => { const p = id && partnerOf(id); return p ? p.name : '매장 없음'; };
const stkCode = it => String((it && it.code) || '').split('/')[0];
function stkSince(per) { const d = new Date(today() + 'T00:00:00'); if (per === 'd30') d.setDate(d.getDate() - 30); else if (per === 'm3') d.setMonth(d.getMonth() - 3); else if (per === 'm12') d.setMonth(d.getMonth() - 12); else return ''; return fmtD(d); }
const stkBuyLot = l => !/^(adjust|exchange|return)$/.test(l.src || '');

// ---------- 재고 현황 ----------
function stkRows(C) {
  const S0 = stkS(), q = S0.q.trim().toLowerCase(), soon = +((INV.opt && INV.opt.soon) || 7);
  const by = new Map();
  for (const l of INV.lots) {
    const left = C.left.get(l.id) || 0; if (left <= 0) continue;
    if (S0.part && l.partnerId !== S0.part) continue;
    const it = itemOf(l.itemId); if (!it) continue;
    if (q && ![itName(it), it.code, l.size].join(' ').toLowerCase().includes(q)) continue;
    const k = l.itemId + '|' + l.size; const g = by.get(k) || { k, it, size: l.size, qty: 0, cost: 0, lots: [], due: null, noRet: false };
    g.qty += left; g.cost += left * (+l.cost || 0); g.lots.push({ l, left });
    if (retOpen(l, C)) { const d = dday(l.returnDue); if (d >= 0 && (g.due == null || d < g.due)) g.due = d; } else g.noRet = true;
    by.set(k, g);
  }
  let rows = [...by.values()];
  for (const g of rows) { const m = typeof mktSize === 'function' ? mktSize(g.it, g.size) : null; g.m = m; g.sell = m ? m.net * g.qty : null; g.profit = m ? g.sell - g.cost : null; }
  if (S0.chip === 'due') rows = rows.filter(g => g.due != null && g.due <= soon);
  if (S0.chip === 'noret') rows = rows.filter(g => g.due == null);
  return rows.sort((a, b) => (a.due ?? 999) - (b.due ?? 999) || itName(a.it).localeCompare(itName(b.it)) || String(a.size).localeCompare(String(b.size), 'ko', { numeric: true }));
}
function stkNow(C) {
  const S0 = stkS(), rows = stkRows(C), soon = +((INV.opt && INV.opt.soon) || 7);
  const all = (() => { const s = { ...S0 }; IS.stk = { ...S0, chip: 'all', q: '', part: '' }; const r = stkRows(C); IS.stk = s; return r; })();
  const qty = all.reduce((t, g) => t + g.qty, 0), cost = all.reduce((t, g) => t + g.cost, 0), kinds = new Set(all.map(g => g.it.id)).size;
  const mk = all.filter(g => g.m), mq = mk.reduce((t, g) => t + g.qty, 0), sell = mk.reduce((t, g) => t + g.sell, 0), prof = mk.reduce((t, g) => t + g.profit, 0);
  const dueN = all.filter(g => g.due != null && g.due <= soon).reduce((t, g) => t + g.qty, 0);
  const last = Math.max(0, ...all.map(g => (g.m && g.m.at) || 0));
  const parts = [...new Set(INV.lots.filter(l => (C.left.get(l.id) || 0) > 0).map(l => l.partnerId || ''))];
  const selN = Object.values(S0.sel).filter(Boolean).length;
  const chip = (k, t) => `<button type="button" class="chip${S0.chip === k ? ' on' : ''}" data-a="stkChip" data-v="${k}">${t}</button>`;
  const lotLine = ({ l, left }) => {
    const act = S0.act && S0.act.lot === l.id ? S0.act : null;
    return `<tr class="stk-lot"><td></td><td class="l" colspan="2"><span class="small">${esc(l.date || '')} 입고 · ${esc(stkPartName(l.partnerId))}${l.memo ? ' · ' + esc(String(l.memo).slice(0, 30)) : ''}</span></td><td>${left}개</td><td>${won(+l.cost || 0)}</td><td colspan="2"></td>
      <td class="l">${retOpen(l, C) ? `<span class="small">반품 기한 ${esc(l.returnDue)}</span>` : '<span class="small">반품 불가</span>'}
        <span class="stk-acts"><button type="button" class="ghost tiny" data-a="stkSell" data-id="${l.id}" title="이 재고를 팔았어요 — 출고(판매)로 넣어요">판매</button><button type="button" class="ghost tiny" data-a="stkWh" data-id="${l.id}" title="KREAM 보관 판매 창고로 보내요 — 우선출고로 넣어요">창고로</button>${['반품', '폐기', '기타 반출'].map(t => `<button type="button" class="ghost tiny" data-a="stkAct" data-id="${l.id}" data-v="${t}">${t}</button>`).join('')}</span>
        ${act ? `<span class="stk-actf"><input type="number" min="1" max="${left}" value="1" data-k="stkActQ" class="mini" style="width:60px"> 개 <input data-k="stkActMemo" class="mini" placeholder="메모(선택)" style="width:140px"><button type="button" class="primary tiny" data-a="stkActGo" data-id="${l.id}">${esc(act.t)} 등록</button><button type="button" class="ghost tiny" data-a="stkActX">취소</button></span>` : ''}</td></tr>`;
  };
  const body = rows.map(g => {
    const open = S0.allOpen || S0.open[g.k];
    const due = g.due == null ? '<span class="small">–</span>' : g.due <= soon ? `<span class="pill bad">D-${g.due}</span>` : `<span class="small">D-${g.due}</span>`;
    return `<tr class="stk-g${open ? ' open' : ''}"><td><input type="checkbox" data-a="stkSel" data-v="${esc(g.k)}"${S0.sel[g.k] ? ' checked' : ''} aria-label="선택"></td>
      <td class="l"><button type="button" class="stk-n" data-a="stkOpen" data-v="${esc(g.k)}">${open ? '▾' : '▸'} <b>${esc(itName(g.it))}</b></button></td><td class="l mono">${esc(stkCode(g.it))}</td><td class="l"><b>${esc(g.size)}</b> · ${g.qty}개</td>
      <td>${won(g.cost / g.qty)}</td><td>${g.m ? `${won(g.m.net)} <span class="small">${g.m.best === 'poizon' ? 'POIZON' : 'KREAM'}</span>` : '<span class="small">시세 없음</span>'}</td>
      <td class="${g.profit > 0 ? 'pos' : g.profit < 0 ? 'neg' : ''}">${g.profit != null ? wonS(Math.round(g.profit)) : '–'}</td><td class="l">${due}</td></tr>${open ? g.lots.map(lotLine).join('') : ''}`;
  }).join('');
  return `<div class="kgrid stk-cards">${card('매입 원가', won(cost), '', `보유 ${qty}개 · ${kinds}가지`)}${card('→ 예상 판매가', mq ? won(sell) : '–', 'acc', mq ? `시세 있는 ${mq}개 · 재고마다 수익이 더 큰 판매처의 가격에서 수수료를 뺀 실수령` : '가격 새로고침을 눌러 주세요')}${card('= 예상 손익', mq ? wonS(Math.round(prof)) : '–', prof > 0 ? 'pos' : prof < 0 ? 'neg' : '', '예상 판매가 − 매입 원가')}${card('반품 임박', dueN + '개', dueN ? 'warn' : '', `아울렛 반품 기한 ${soon}일 이내`)}</div>
  <div class="stk-bar"><b>목록</b> <span class="small">${new Set(rows.map(g => g.it.id)).size}가지 · ${rows.reduce((t, g) => t + g.qty, 0)}개</span>
    ${chip('all', '전체')}${chip('due', '반품 임박')}${chip('noret', '반품 불가')}
    <select data-k="stkPart"><option value="">매장 전체</option>${parts.map(p => `<option value="${esc(p)}"${S0.part === p ? ' selected' : ''}>${esc(stkPartName(p))}</option>`).join('')}</select>
    <input data-k="stkQ" value="${esc(S0.q)}" placeholder="상품명 · 품번 · 사이즈" class="stk-q">
    <span class="topsp"></span><span class="small">${selN}가지 선택</span><button type="button" class="primary small" data-a="stkKream"${selN ? '' : ' disabled'}>KREAM 에 올리기</button><button type="button" class="ghost small" data-a="stkSelX"${selN ? '' : ' disabled'}>선택 해제</button><button type="button" class="ghost small" data-a="stkAllOpen">${S0.allOpen ? '모두 접기' : '모두 펼치기'}</button></div>
  <div class="tbl"><table class="main stk-t"><thead><tr><th></th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th>매입 원가</th><th>예상 판매가</th><th>예상 손익</th><th class="l">반품 임박</th></tr></thead>
  <tbody>${body || `<tr><td colspan="8" class="empty">조건에 맞는 재고가 없어요. [매입 등록]으로 매입을 넣으면 여기 쌓여요.</td></tr>`}</tbody></table></div>
  <p class="hint">가격은 크림 · 포이즌 동시 분석 시세를 써요${last ? ` — ${new Date(last).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })} 기준` : ''}. [KREAM 에 올리기]는 설정 › 판매 규칙의 자동 판매 등록 가격 규칙으로 걸어요.</p>`;
}

// ---------- 매입 내역 ----------
function stkBuys() {
  const S0 = stkS(), since = stkSince(S0.per), q = S0.q.trim().toLowerCase();
  return INV.lots.filter(l => stkBuyLot(l) && (!since || (l.date || '') >= since) && (!S0.part || l.partnerId === S0.part))
    .filter(l => { if (!q) return true; const it = itemOf(l.itemId); return [it ? itName(it) : '', it && it.code, l.size].join(' ').toLowerCase().includes(q); })
    .sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.at || 0) - (a.at || 0));
}
function stkChart(L) {
  if (!L.length) return '';
  const S0 = stkS(), monthly = S0.per === 'm12' || S0.per === 'all';
  const keyOf = d => { if (monthly) return d.slice(0, 7); const x = new Date(d + 'T00:00:00'); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return fmtD(x); };
  const parts = [...new Set(L.map(l => l.partnerId || ''))], col = p => STK_COLORS[parts.indexOf(p) % STK_COLORS.length];
  const B = new Map(); for (const l of L) { const k = keyOf(l.date || today()); const b = B.get(k) || {}; b[l.partnerId || ''] = (b[l.partnerId || ''] || 0) + (+l.cost || 0) * (+l.qty || 0); B.set(k, b); }
  const keys = [...B.keys()].sort(), max = Math.max(1, ...keys.map(k => Object.values(B.get(k)).reduce((t, v) => t + v, 0)));
  const W = 760, H = 150, bw = Math.max(6, Math.min(34, (W - 40) / keys.length - 6));
  const bars = keys.map((k, i) => { let y = H - 20; const x = 30 + i * ((W - 40) / keys.length); const segs = Object.entries(B.get(k)).map(([p, v]) => { const h = Math.max(1, v / max * (H - 30)); y -= h; return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" fill="${col(p)}" rx="2"><title>${esc(stkPartName(p))} ${won(v)}</title></rect>`; }).join('');
    return segs + `<text x="${(x + bw / 2).toFixed(1)}" y="${H - 5}" text-anchor="middle" class="stk-ax">${monthly ? k.slice(2).replace('-', '.') : k.slice(5).replace('-', '/')}</text>`; }).join('');
  return `<div class="stk-chart"><div class="stk-ch-h"><b>매입 추이</b><span class="small">막대 하나 = ${monthly ? '한 달(신고 기준 월 소계)' : '일주일'} · 색 = 매장</span></div><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="매입 추이">${bars}</svg>
    <div class="stk-leg">${parts.map(p => `<span><i style="background:${col(p)}"></i>${esc(stkPartName(p))}</span>`).join('')}</div></div>`;
}
function stkBuy() {
  const S0 = stkS(), L = stkBuys(), amt = L.reduce((t, l) => t + (+l.cost || 0) * (+l.qty || 0), 0), stores = new Set(L.map(l => l.partnerId || '')).size;
  const parts = [...new Set(INV.lots.filter(stkBuyLot).map(l => l.partnerId || ''))];
  return `<div class="stk-bar">${STK_PER.map(([k, t]) => `<button type="button" class="chip${S0.per === k ? ' on' : ''}" data-a="stkPer" data-v="${k}">${t}</button>`).join('')}
    <select data-k="stkPart"><option value="">매장 전체</option>${parts.map(p => `<option value="${esc(p)}"${S0.part === p ? ' selected' : ''}>${esc(stkPartName(p))}</option>`).join('')}</select><input data-k="stkQ" value="${esc(S0.q)}" placeholder="상품명 · 품번 · 사이즈" class="stk-q"><span class="topsp"></span><button type="button" class="ghost small" data-a="stkXlsBuy">엑셀 내려받기</button></div>
  <div class="kgrid stk-cards">${card('매입 건수', L.length + '건', '', `${L.reduce((t, l) => t + (+l.qty || 0), 0)}개`)}${card('매입액 합계', won(amt), 'acc', '선택한 기간 · 매장 기준')}${card('매장', stores + '곳', '')}</div>
  ${stkChart(L)}
  <div class="tbl"><table class="main"><thead><tr><th class="l">매입일</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">매장</th><th>수량</th><th>개당 매입가</th><th>매입액</th><th class="l">반품 기한</th></tr></thead><tbody>
  ${L.slice(0, 500).map(l => { const it = itemOf(l.itemId); return `<tr><td class="l">${esc(l.date || '')}</td><td class="l">${esc(it ? itName(it) : '')}</td><td class="l mono">${esc(stkCode(it))}</td><td class="l">${esc(l.size)}</td><td class="l">${esc(stkPartName(l.partnerId))}</td><td>${+l.qty || 0}</td><td>${won(+l.cost || 0)}</td><td>${won((+l.cost || 0) * (+l.qty || 0))}</td><td class="l">${esc(l.returnDue || '–')}</td></tr>`; }).join('') || '<tr><td colspan="9" class="empty">[매입 등록]을 누르면 여기 쌓입니다. 여러 건을 한 번에 넣으려면 엑셀 대량 입고 · 붙여넣기를 쓰세요.</td></tr>'}
  </tbody></table></div>`;
}

// ---------- 반품·반출 ----------
function stkOuts() {
  const S0 = stkS(), since = stkSince(S0.per), out = [];
  for (const l of INV.lots) for (const e of l.events || []) {
    const t = e.t === '반품' ? '반품' : e.t === '폐기' ? '폐기' : e.t === '기타 반출' ? '기타 반출' : null; if (!t) continue;
    if (since && (e.d || '') < since) continue;
    out.push({ l, e, t, it: itemOf(l.itemId) });
  }
  return out.sort((a, b) => (b.e.d || '').localeCompare(a.e.d || ''));
}
function stkOut() {
  const S0 = stkS(), all = stkOuts(), L = all.filter(x => x.t === S0.out), q = S0.q.trim().toLowerCase();
  const LL = q ? L.filter(x => [x.it ? itName(x.it) : '', x.it && x.it.code, x.l.size, x.e.memo].join(' ').toLowerCase().includes(q)) : L;
  const ret = all.filter(x => x.t === '반품'), back = ret.reduce((t, x) => t + (+x.l.cost || 0) * (+x.e.q || 0), 0), rq = ret.reduce((t, x) => t + (+x.e.q || 0), 0);
  const byP = {}; for (const x of ret) byP[x.l.partnerId || ''] = (byP[x.l.partnerId || ''] || 0) + (+x.e.q || 0);
  const topP = Object.entries(byP).sort((a, b) => b[1] - a[1])[0];
  const cnt = t => all.filter(x => x.t === t).length;
  return `<div class="stk-bar">${['반품', '폐기', '기타 반출'].map(t => `<button type="button" class="chip${S0.out === t ? ' on' : ''}" data-a="stkOutT" data-v="${t}">${t === '반품' ? '아울렛 반품' : t} ${cnt(t)}</button>`).join('')}<span class="stk-sep"></span>
    ${STK_PER.map(([k, t]) => `<button type="button" class="chip${S0.per === k ? ' on' : ''}" data-a="stkPer" data-v="${k}">${t}</button>`).join('')}<span class="topsp"></span><button type="button" class="ghost small" data-a="stkXlsOut">엑셀 내려받기</button></div>
  <p class="hint">등록은 재고 현황에서 그 재고를 펼쳐 [반품] [폐기] [기타 반출]로 해요.</p>
  <div class="kgrid stk-cards">${card('회수 금액', won(back), 'acc', '매입가 기준 · 부가세 매입액에서 빠져요')}${card('반품 수량', rq + '개', '')}${card('반품이 가장 많은 매장', topP ? esc(stkPartName(topP[0])) : '–', '', topP ? `${topP[1]}개` : '')}</div>
  <div class="stk-bar"><b>${S0.out === '반품' ? '아울렛 반품 내역' : S0.out + ' 내역'}</b> <span class="small">${LL.length}건</span>${S0.out === '반품' ? '<button type="button" class="ghost tiny" data-a="nav" data-v="ana">반품률 ›</button>' : ''}<input data-k="stkQ" value="${esc(S0.q)}" placeholder="상품명 · 품번 · 사이즈 · 메모" class="stk-q"></div>
  <div class="tbl"><table class="main"><thead><tr><th class="l">날짜</th><th class="l">상품</th><th class="l">품번</th><th class="l">사이즈</th><th class="l">매장</th><th>수량</th><th>매입가</th><th class="l">메모</th></tr></thead><tbody>
  ${LL.map(x => `<tr><td class="l">${esc(x.e.d || '')}</td><td class="l">${esc(x.it ? itName(x.it) : '')}</td><td class="l mono">${esc(stkCode(x.it))}</td><td class="l">${esc(x.l.size)}</td><td class="l">${esc(stkPartName(x.l.partnerId))}</td><td>${+x.e.q || 0}</td><td>${won(+x.l.cost || 0)}</td><td class="l">${esc(x.e.memo || (x.e.auto === 'cancel' ? '주문 취소' : ''))}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">기록이 없어요</td></tr>'}
  </tbody></table></div>`;
}

function vStock(C) {
  const S0 = stkS(), tabs = [['now', '재고 현황'], ['buy', '매입 내역'], ['out', '반품·반출']];
  let pAt = 0; try { const C0 = invCalc(); for (const it of INV.items) { if (!(itemStock(it, C0).qty > 0)) continue; const h = typeof mktEntry === 'function' ? mktEntry(it) : null; if (h && h.at > pAt) pAt = h.at; } } catch (e) {}
  const right = `<span class="small">${IS.mkt ? `가격 확인 중 ${IS.mkt.i}/${IS.mkt.n}` : pAt ? `가격 ${typeof lkAgo === 'function' ? lkAgo(pAt) : ''}` : '가격 없음'}</span><button type="button" class="ghost" data-a="mktAll">${IS.mkt ? '멈추기' : `↻ 가격 새로고침 · ${pAt ? (typeof lkAgo === 'function' ? lkAgo(pAt) : '') : '아직 안 함'}`}</button><button type="button" class="ghost" data-a="stkXlsNow">엑셀 내려받기</button><button type="button" class="ghost" data-a="stkTab" data-v="imp">재고 가져오기</button><button type="button" class="primary" data-a="stkBuyReg">매입 등록</button>`;
  const body = S0.tab === 'imp' && typeof stkImp === 'function' ? stkImp() : S0.tab === 'buy' ? stkBuy() : S0.tab === 'out' ? stkOut() : stkNow(C);
  return `${head('재고', '보유 재고 · 매입 내역 · 반품과 반출을 한 곳에서 봐요.', right)}${typeof flash === 'function' ? flash() : ''}
  ${S0.tab === 'imp' ? '' : `<div class="subtabs">${tabs.map(([k, t]) => `<button type="button" data-a="stkTab" data-v="${k}" aria-selected="${S0.tab === k}">${t}</button>`).join('')}</div>`}${body}`;
}

// ---------- 동작 ----------
function stkCsv(rows, name) { const csv = '﻿' + rows.map(r => r.map(v => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(',')).join('\r\n'); download(csv, `${name}_${today()}.csv`, 'text/csv;charset=utf-8'); }
async function stkAct(a, el) {
  const S0 = stkS(), v = el.dataset.v, C = invCalc();
  if (a.startsWith('stkImp') && typeof stkImpAct === 'function') return stkImpAct(a, el);
  switch (a) {
    case 'stkTab': S0.tab = v; S0.q = ''; break;
    case 'stkChip': S0.chip = v; break;
    case 'stkPer': S0.per = v; break;
    case 'stkOutT': S0.out = v; break;
    case 'stkOpen': S0.open[v] = !S0.open[v]; break;
    case 'stkAllOpen': S0.allOpen = !S0.allOpen; if (!S0.allOpen) S0.open = {}; break;
    case 'stkSel': S0.sel[v] = !!el.checked; break;
    case 'stkSelX': S0.sel = {}; break;
    case 'stkAct': S0.act = { lot: el.dataset.id, t: v }; break;
    case 'stkActX': S0.act = null; break;
    case 'stkActGo': {
      const l = INV.lots.find(x => x.id === el.dataset.id); if (!l || !S0.act) break;
      const left = C.left.get(l.id) || 0, q = Math.floor(+(($('[data-k=stkActQ]') || {}).value) || 0), memo = String(($('[data-k=stkActMemo]') || {}).value || '').trim();
      if (!(q >= 1 && q <= left)) { IS.msg = `수량을 1~${left}개로 넣어 주세요`; break; }
      l.events = l.events || [];
      if (S0.act.t === '반품') { l.retQty = (l.retQty || 0) + q; l.events.push({ t: '반품', d: today(), q, memo }); IS.msg = `${q}개 반품 처리했어요. 장부에 매입반품(+${won((+l.cost || 0) * q)})으로 들어갔어요.`; }
      else { l.outQty = (l.outQty || 0) + q; l.events.push({ t: S0.act.t, d: today(), q, memo }); IS.msg = `${q}개 ${S0.act.t}로 뺐어요 (매입가 ${won((+l.cost || 0) * q)})`; }
      S0.act = null; await invSave(); break;
    }
    case 'stkKream': {
      const keys = Object.keys(S0.sel).filter(k => S0.sel[k]); if (!keys.length) break;
      if (typeof ALQ === 'undefined') { IS.msg = '자동 판매 등록을 쓸 수 없어요'; break; }
      let n = 0;
      for (const k of keys) {
        const [itemId, size] = [k.slice(0, k.indexOf('|')), k.slice(k.indexOf('|') + 1)];
        const lots = INV.lots.filter(l => l.itemId === itemId && l.size === size && (C.left.get(l.id) || 0) > 0).sort((a, b) => (b.at || 0) - (a.at || 0));
        const l = lots[0]; if (!l) continue; const it = itemOf(itemId);
        ALQ = ALQ.filter(q => !(q.lotId === l.id && /wait|fail|skip|note/.test(q.st)));
        ALQ.push({ lotId: l.id, at: Date.now() - 10 * 60e3, name: itName(it), code: stkCode(it), size, qty: lots.reduce((t, x) => t + (C.left.get(x.id) || 0), 0), cost: +l.cost || 0, st: 'wait', manual: true }); n++;
      }
      await alSave(); S0.sel = {};
      IS.msg = `${n}가지를 KREAM 에 올릴게요 — 판매처 연동 › 자동 판매 등록에서 진행을 볼 수 있어요 (거는 방식: ${(typeof AB_MODE !== 'undefined' && AB_MODE[abOpt.mode]) || abOpt.mode})`;
      try { alTick(); } catch (e) {}
      break;
    }
    case 'stkSell': case 'stkWh': {
      // 줄별 [판매] · [창고로]: 입출고 화면을 출고(판매) · 우선출고(보관 판매로 보냄)로 열고 이 재고를 한 줄 넣어 둬요 — 판매가 · 판매처를 넣고 [등록]
      const l = INV.lots.find(x => x.id === el.dataset.id), it = l && itemOf(l.itemId); if (!it) break;
      IS.io.mode = a === 'stkSell' ? 'out' : 'pre'; IS.io.msg = ''; IS.io.rows = []; if (a === 'stkWh') { const k = INV.partners.find(p => p.id === 'p-kream') || INV.partners.find(p => p.kind === 'sell' && /크림|kream/i.test(p.name)); if (k) IS.io.partnerId = k.id; } if (typeof ioAddRow === 'function') ioAddRow(it, l.size);
      return go('io');
    }
    case 'stkStoreDict': return storeDictOpen();
    case 'stkBuyReg': if (typeof brOpen === 'function') brOpen(); return;
    case 'stkXlsNow': { const rows = stkRows(C); stkCsv([['상품', '품번', '사이즈', '잔여', '개당 매입 원가', '예상 판매가(실수령)', '예상 손익', '반품 임박(일)'], ...rows.map(g => [itName(g.it), stkCode(g.it), g.size, g.qty, Math.round(g.cost / g.qty), g.m ? g.m.net : '', g.profit != null ? Math.round(g.profit) : '', g.due ?? ''])], '재고현황'); return; }
    case 'stkXlsBuy': stkCsv([['매입일', '상품', '품번', '사이즈', '매장', '수량', '개당 매입가', '매입액', '반품 기한'], ...stkBuys().map(l => { const it = itemOf(l.itemId); return [l.date, it ? itName(it) : '', stkCode(it), l.size, stkPartName(l.partnerId), l.qty, l.cost, (+l.cost || 0) * (+l.qty || 0), l.returnDue || '']; })], '매입내역'); return;
    case 'stkXlsOut': stkCsv([['구분', '날짜', '상품', '품번', '사이즈', '매장', '수량', '매입가', '메모'], ...stkOuts().map(x => [x.t, x.e.d, x.it ? itName(x.it) : '', stkCode(x.it), x.l.size, stkPartName(x.l.partnerId), x.e.q, x.l.cost, x.e.memo || ''])], '반품반출'); return;
  }
  renderInv();
}
function stkInput(el, ev) {
  const S0 = stkS(), k = el.dataset.k, v = el.value;
  if (k === 'stkQ') { S0.q = v; clearTimeout(stkInput.t); stkInput.t = setTimeout(() => { renderInv(); const e = document.querySelector('[data-k=stkQ]'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }, ev.type === 'input' ? 300 : 0); return; }
  if (k === 'stkPart') { S0.part = v; renderInv(); }
  if (k.startsWith('stkImp') && typeof stkImpInput === 'function') return stkImpInput(el, ev);
}

// ---------- C10 반품 기한 자동 · C12 매장 사전 ----------
// 오프라인 매장(매장 사전에서 고른 곳, store:true)은 브랜드별 반품 기한: 나이키 · 조던 +13일, 아디다스 +15일, 그 밖 14일 (줍픽 가이드)
// 온라인 몰 · 직접 만든 거래처는 거래처의 반품 기한(없으면 기본값)
function retDaysOf(p, it) {
  if (p && p.store) { const b = `${(it && it.brand) || ''} ${(it && it.name) || ''}`; return /나이키|nike|조던|jordan/i.test(b) ? 13 : /아디다스|adidas/i.test(b) ? 15 : 14; }
  return p && p.returnDays != null ? +p.returnDays : +INV.opt.returnDays;
}
// 매장 사전 — 아울렛 · 백화점 · 팩토리 스토어 지점 (고르기만 해서 같은 매장이 두 번 생기지 않게)
const STORE_DICT = {
  '롯데프리미엄아울렛': ['파주점', '김해점', '이천점', '동부산점', '기흥점', '타임빌라스(의왕)'],
  '롯데아울렛': ['광명점', '고양점', '수완점', '남악점', '청주점', '군산점', '김포공항점', '서울역점'],
  '신세계사이먼 프리미엄 아울렛': ['여주', '파주', '부산', '시흥'],
  '현대프리미엄아울렛': ['김포점', '송도점', '대전점', '스페이스원(남양주)'],
  '현대시티아울렛': ['동대문점', '가산점', '가든파이브점'],
  '모다아울렛': ['부천점', '대구점', '평택점', '청주점'],
  '뉴코아아울렛': ['강남점', '평촌점', '일산점', '인천점', '부천점'],
  'NC백화점': ['강서점', '송파점', '불광점', '신구로점'],
  '세이브존': ['노원점', '화정점', '해운대점', '대전점'],
  '마리오아울렛': ['가산점'],
  '나이키 팩토리 스토어': ['(지점 직접 입력)'],
  '아디다스 팩토리 아울렛': ['(지점 직접 입력)']
};
function storeDictHTML(q) {
  q = String(q || '').trim().toLowerCase();
  const have = new Set(INV.partners.map(p => p.name));
  const rows = [];
  for (const [g, L] of Object.entries(STORE_DICT)) for (const b of L) { const name = /직접 입력/.test(b) ? g : `${g} ${b}`; if (q && !name.toLowerCase().includes(q)) continue; rows.push(name); }
  return rows.map(n => `<label class="sd-row${have.has(n) ? ' have' : ''}"><input type="checkbox" name="sd" value="${esc(n)}"${have.has(n) ? ' disabled checked' : ''}> ${esc(n)}${have.has(n) ? ' <span class="small">이미 있어요</span>' : ''}</label>`).join('') || '<p class="small">찾는 매장이 없어요 — [거래처 추가]로 직접 만들어 주세요</p>';
}
function storeDictOpen() {
  invDialog('매장 사전에서 고르기', `<p class="hint">아울렛 · 백화점 · 팩토리 스토어 지점을 골라 매입처로 넣어요. 같은 매장이 두 번 생기지 않게 고르기만 해요. 고른 매장의 반품 기한은 브랜드별로 자동이에요(나이키 · 조던 +13일, 아디다스 +15일, 그 밖 14일).</p>
    <input name="sdq" placeholder="매장 · 지점 찾기" autocomplete="off"><div class="sd-list">${storeDictHTML('')}</div>`, async (fd, form) => {
    const pick = [...form.querySelectorAll('input[name=sd]:checked:not(:disabled)')].map(x => x.value);
    if (!pick.length) return '매장을 하나 이상 골라 주세요';
    for (const name of pick) if (!INV.partners.some(p => p.name === name)) INV.partners.push({ id: uid(), kind: 'buy', name, biz: '', tax: '과세', store: true, returnDays: null });
    await invSave(); IS.msg = `매장 ${pick.length}곳을 넣었어요`; renderInv();
  });
  const q = document.querySelector('#invDlg input[name=sdq]'), box = document.querySelector('#invDlg .sd-list');
  if (q && box) q.addEventListener('input', () => { const keep = new Set([...box.querySelectorAll('input[name=sd]:checked:not(:disabled)')].map(x => x.value)); box.innerHTML = storeDictHTML(q.value); box.querySelectorAll('input[name=sd]').forEach(x => { if (keep.has(x.value)) x.checked = true; }); });
}

// C3: 재고 가격은 6시간에 한 번 저절로 새로고침해요 (소싱 · 긴급 정지 · 판매처 연동 끄기 중엔 쉬어요)
setInterval(() => {
  try {
    if (!(window.kcApp && window.kcApp.ops) || typeof invMktRefresh !== 'function' || IS.mkt) return;
    if ((typeof SE !== 'undefined' && SE.busy) || (typeof OPS !== 'undefined' && OPS.halt) || (typeof LKP !== 'undefined' && LKP.off)) return;
    const C = invCalc(); const stale = INV.items.some(it => it.code && itemStock(it, C).qty > 0 && !(mktEntry(it) && Date.now() - mktEntry(it).at < MKT_FRESH));
    if (stale) invMktRefresh();
  } catch (e) {}
}, 30 * 60e3);
