'use strict';
/* 킥스캔 — 오늘 살 것 (11/25 사장님 «리셀에 시간을 엄청 쓰고 싶지 않아 — 자동화가 목표»)
   소싱 결과(srcRows) 중 지금 살 만한 수익 상품만 한 화면에 모아요 — 사장님은 결제만
   - 빼는 것: 재고가 남아 있는 품번 · [샀어요] 누른 것 · 쇼핑몰 주문과 이어진 구매 기록 · [안 살래요](7일) · 시세 확인이 오래된 것(기본 48시간)
   - 하루 예산(기본 100만 원 · 0 = 제한 없음) 안에서 예상 수익 큰 순 · 상품당 최대 수량(기본 2개, 수익 큰 사이즈부터) — 넘는 건 '예산 넘는 상품'
   - 새로 생기면 알림 종 · 윈도우 알림 · 폰 알림(push.js 종류 'buy') — 폰 앱 › 살 것 탭에서도 봐요(ks_doc job 'tbuy')
   - 폰에서 [샀어요] · [안 살래요] → ks_doc job 'tbact-…'(by phone) → cloud.js clApply → tbPhoneAct
   저장: 'tbCfg' { budget, per, maxAge, on } · 'tbState' { done: {ck: {at, day, cost, q, name}}, skip: {ck: 까지}, sent: {ck: at}, base, hash, syncAt } */

let TBC = { budget: 1000000, per: 2, maxAge: 48, on: true };
let TBS = { done: {}, skip: {}, sent: {}, base: 0, hash: '', syncAt: 0 };
let TBL = null;            // 마지막 계산 { pick, over, spent, budget, at, srcAt }
const TBMAP = new Map();   // 카드 id → { r, C } ([구매 ↗] · [샀어요] 때 구매 기록에 써요)
const TB_SKIP = 7 * 864e5, TB_DONE = 14 * 864e5;
const tbCk = c => typeof codeKey === 'function' ? codeKey(c || '') : String(c || '').replace(/[^A-Z0-9]/gi, '').toUpperCase();
const tbDay = (t = Date.now()) => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const tbWon = n => n == null || isNaN(n) ? '–' : Math.round(n).toLocaleString('ko-KR') + '원';
const tbHere = () => typeof curMode !== 'undefined' && curMode === 'inv' && typeof invView !== 'undefined' && invView === 'tbuy';

// 재고가 남아 있는 품번
function tbOwn() {
  const out = new Set();
  try {
    if (typeof INV === 'undefined' || typeof invCalc !== 'function') return out;
    const C = invCalc(), byId = new Map(INV.items.map(i => [i.id, i]));
    for (const l of INV.lots) if ((C.left.get(l.id) || 0) > 0) { const it = byId.get(l.itemId); if (it) for (const c of String(it.code || '').split('/')) { const k = tbCk(c); if (k) out.add(k); } }
  } catch (e) {}
  return out;
}
// 산 것: [샀어요] · 쇼핑몰 주문과 이어진 구매 기록 · [매입 등록]으로 넣은 구매 기록 (14일 안)
function tbBought(ck) {
  const d = TBS.done[ck]; if (d && Date.now() - d.at < TB_DONE) return true;
  return typeof BI !== 'undefined' && (BI.L || []).some(i => i.ck === ck && (i.linkedQ > 0 || i.st === 'manual' || i.st === 'linked') && Date.now() - i.at < TB_DONE);
}
const tbOpened = ck => typeof BI !== 'undefined' && (BI.L || []).some(i => i.ck === ck && i.st === 'open' && Date.now() - i.at < 3 * 864e5);
const tbSpent = () => Object.values(TBS.done).filter(d => d.day === tbDay()).reduce((t, d) => t + (+d.cost || 0), 0);

async function tbList() {
  const out = { pick: [], over: [], spent: tbSpent(), budget: +TBC.budget || 0, at: Date.now(), srcAt: 0 };
  if (typeof srcCalcRow !== 'function') return out;
  const rows = (await store.get('srcRows', [])) || [];
  const calc = typeof seCalcCfg === 'function' ? await seCalcCfg() : ((await store.get('srcCalc', {})) || {});
  const env = typeof seCalcEnv === 'function' ? seCalcEnv() : undefined;
  if (typeof biLoad === 'function') { try { await biLoad(); } catch (e) {} }
  const own = tbOwn(), now = Date.now(), maxAge = Math.max(1, +TBC.maxAge || 48) * 3600e3, per = Math.max(1, +TBC.per || 2), L = [], seen = new Set();
  TBMAP.clear();
  for (const r of Array.isArray(rows) ? rows : []) {
    if (!r || !r.code) continue;
    out.srcAt = Math.max(out.srcAt, r.at || 0);
    if (r.need || r.none || r.hide || now - (r.at || 0) > maxAge) continue;
    const ck = tbCk(r.code); if (!ck || seen.has(ck) || own.has(ck) || tbBought(ck) || (TBS.skip[ck] || 0) > now) continue;
    let C; try { C = srcCalcRow(r, calc, env); } catch (e) { continue; }
    if (!C || !C.profitable || !C.rec.length) continue;
    // 상품당 최대 수량만큼 — 개당 수익이 큰 사이즈부터
    let left = per; const sizes = [];
    for (const x of C.rec.slice().sort((a, b) => ((b.best && b.best.profit) || 0) - ((a.best && a.best.profit) || 0))) {
      if (left <= 0) break; const q = Math.min(x.q, left); if (q <= 0) continue; left -= q;
      sizes.push({ size: String(x.size), q, buy: x.buy, profit: x.best ? x.best.profit : null, seller: x.best ? x.best.seller : '', url: (x.offer && x.offer.url) || '' });
    }
    if (!sizes.length) continue;
    const b = C.offer || (r.buy || [])[0] || {};
    const x = { id: r.id, ck, code: r.code, name: r.name || r.code, brand: r.brand || '', img: r.img || '', site: b.label || b.site || '', url: sizes[0].url || b.url || '', unit: C.buy, sizes,
      q: sizes.reduce((t, s) => t + s.q, 0), cost: sizes.reduce((t, s) => t + s.q * (+s.buy || 0), 0), profit: sizes.reduce((t, s) => t + s.q * (+s.profit || 0), 0),
      avg: C.avg, n30: C.n30All, seller: (C.sellers || [])[0] || sizes[0].seller || '', at: r.at || 0, opened: tbOpened(ck) };
    seen.add(ck); TBMAP.set(r.id, { r, C }); L.push(x);
  }
  L.sort((a, b) => b.profit - a.profit || (b.avg || 0) - (a.avg || 0));
  let room = out.budget ? Math.max(0, out.budget - out.spent) : Infinity;
  for (const x of L) { if (x.cost <= room) { out.pick.push(x); room -= x.cost; } else out.over.push(x); }
  return out;
}

// ---------- 화면 ----------
function tbCard(x, over) {
  const sl = x.seller === 'poizon' ? 'POIZON' : x.seller === 'kream' ? 'KREAM' : '';
  const age = x.at ? (typeof lkAgo === 'function' ? lkAgo(x.at) : '') : '';
  const id = esc(x.id);
  return `<div class="rl-card tb-card${over ? ' over' : ''}"><div class="rl-top">${x.img ? `<img class="rl-img" src="${esc(x.img)}" alt="" loading="lazy">` : '<span class="rl-img"></span>'}<div class="rl-h"><span class="rl-brand">${esc(x.brand)}${x.opened ? ' <em class="tb-tag">구매 창 열었어요</em>' : ''}</span><b>${esc(x.name)}</b><span class="rl-code">${esc(x.code)}</span></div></div>
    <dl class="rl-dl"><dt>매입처</dt><dd>${esc(x.site || '–')} · ${tbWon(x.unit)}</dd><dt>살 사이즈</dt><dd>${x.sizes.map(s => `${esc(s.size)} ×${s.q}`).join(' · ')}</dd>
      <dt>매입 금액</dt><dd>${tbWon(x.cost)}</dd><dt>예상 수익</dt><dd class="tb-pf">${tbWon(x.profit)} <span class="small">개당 ${tbWon(x.avg)}${sl ? ' · ' + sl : ''}</span></dd><dt>30일 판매</dt><dd>${(+x.n30 || 0).toLocaleString('ko-KR')}개</dd></dl>
    <div class="rl-foot"><span class="small">${age ? `시세 ${esc(age)}` : ''}</span><span class="topsp"></span><button type="button" class="ghost small" data-a="tbSkip" data-v="${id}" title="7일 동안 안 보여요">안 살래요</button><button type="button" class="ghost small" data-a="tbDone" data-v="${id}">샀어요</button>${x.url ? `<a class="primary small tb-buy" href="${esc(x.url)}" target="_blank" rel="noopener" data-tbbuy="${id}">구매 ↗</a>` : ''}</div></div>`;
}
function vTbuy() {
  if (!IS.tbBusy && (!TBL || Date.now() - TBL.at > 60e3)) setTimeout(() => tbCheck('view').catch(() => {}), 0);
  const D = TBL || { pick: [], over: [], spent: tbSpent(), budget: +TBC.budget || 0 };
  const sc = D.pick.reduce((t, x) => t + x.cost, 0), sp = D.pick.reduce((t, x) => t + x.profit, 0);
  const today = Object.entries(TBS.done).filter(([, d]) => d.day === tbDay());
  const nPh = typeof pushCount === 'function' ? pushCount() : 0;
  const sum = `<div class="tb-sum"><b>${D.pick.length}개</b><span>매입 ${tbWon(sc)}</span><span class="tb-pf">예상 수익 ${tbWon(sp)}</span><span class="small">${D.budget ? `하루 예산 ${tbWon(D.budget)} · 오늘 산 것 ${tbWon(D.spent)}` : '예산 제한 없음'} · 상품당 최대 ${+TBC.per || 2}개</span></div>`;
  const empty = `<div class="panel dl-empty"><span>${!TBL ? '계산하는 중이에요…' : D.over.length ? '오늘 예산 안에 드는 상품이 없어요 — 아래 예산 넘는 상품을 보거나 [설정]에서 예산을 늘려 주세요' : `지금 살 만한 수익 상품이 없어요${TBL.srcAt ? ` — 마지막 소싱 결과 ${esc(typeof lkAgo === 'function' ? lkAgo(TBL.srcAt) : '')}` : ''}. 소싱 예약을 켜 두면 새로 찾는 대로 여기에 채워지고 알려 드려요`}</span>${TBL && !D.over.length ? '<button type="button" class="ghost" data-a="tbFind">소싱으로 가기</button>' : ''}</div>`;
  return `${head('오늘 살 것', '소싱 결과에서 지금 살 만한 수익 상품만 모았어요. 결제만 하시면 돼요 — 산 건 [샀어요], 안 살 건 [안 살래요]. 쇼핑몰 주문이 들어오면 재고에 자동으로 이어져요.', `<button type="button" class="ghost" data-a="tbLoad"${IS.tbBusy ? ' disabled' : ''}>${IS.tbBusy ? '계산 중…' : '↻ 다시 계산'}</button><button type="button" class="primary" data-a="tbCfg">설정</button>`)}
  ${sum}
  <div class="ev-grid rl-grid">${D.pick.length ? D.pick.map(x => tbCard(x)).join('') : empty}</div>
  ${D.over.length ? `<details class="tb-more"><summary>예산 넘는 상품 ${D.over.length}개</summary><div class="ev-grid rl-grid">${D.over.map(x => tbCard(x, true)).join('')}</div></details>` : ''}
  ${today.length ? `<details class="tb-more"><summary>오늘 산 것 ${today.length}개 · ${tbWon(D.spent)}</summary><div class="tb-done">${today.map(([ck, d]) => `<div><span>${esc(d.name || ck)}${d.q ? ` · ${d.q}개` : ''} · ${tbWon(d.cost)}${d.from === 'phone' ? ' · 폰' : ''}</span><button type="button" class="linkbtn" data-a="tbUndo" data-v="${esc(ck)}">되돌리기</button></div>`).join('')}</div></details>` : ''}
  <p class="hint">수익 상품 기준은 설정 › 상품 소싱 기준과 같아요 · 재고가 남은 품번 · 산 것 · [안 살래요](7일) · 시세가 ${+TBC.maxAge || 48}시간 넘은 것은 빼요 · 새 상품은 알림 종 · 윈도우 알림 · 폰 알림(${nPh ? `켠 폰 ${nPh}대` : '폰 앱 › 살 것 탭에서 [알림 켜기]'})으로 알려요</p>`;
}

async function tbAct(a, el) {
  const v = el.dataset.v;
  switch (a) {
    case 'tbLoad': return tbCheck('view');
    case 'tbFind': return route('find');
    case 'tbDone': case 'tbSkip': {
      const x = TBL && [...TBL.pick, ...TBL.over].find(y => y.id === v); if (!x) return;
      if (a === 'tbDone') {
        TBS.done[x.ck] = { at: Date.now(), day: tbDay(), cost: x.cost, q: x.q, name: String(x.name).slice(0, 60) };
        const m = TBMAP.get(x.id); if (m && typeof biRecord === 'function') { try { await biRecord(m.r, m.C, null, 'buy'); } catch (e) {} }   // 쇼핑몰 주문이 들어오면 이 기록과 이어져요
        IS.msg = `샀어요로 옮겼어요 — ${x.name}`;
      } else { TBS.skip[x.ck] = Date.now() + TB_SKIP; IS.msg = `7일 동안 안 보여요 — ${x.name}`; }
      await store.set('tbState', TBS); return tbCheck('act');
    }
    case 'tbUndo': delete TBS.done[v]; await store.set('tbState', TBS); return tbCheck('act');
    case 'tbCfg': {
      const nPh = typeof pushCount === 'function' ? pushCount() : 0;
      invDialog('오늘 살 것 설정', `<p class="hint">소싱 결과의 수익 상품 중 이 조건으로 '오늘 살 것'을 골라요. 새 상품이 생기면 알림 종 · 윈도우 알림 · 폰 알림으로 알려요(밤 10시~아침 8시는 윈도우 · 폰 알림을 쉬어요).</p>
        <div class="dgrid"><label>하루 예산(원 · 0 = 제한 없음)<input name="budget" type="number" min="0" step="10000" value="${+TBC.budget || 0}"></label>
        <label>상품당 최대 수량<input name="per" type="number" min="1" max="20" value="${+TBC.per || 2}"></label>
        <label>시세가 이 시간보다 오래되면 빼기(시간)<input name="maxAge" type="number" min="1" max="336" value="${+TBC.maxAge || 48}"></label></div>
        <div class="ev-favs"><label class="chip${TBC.on ? ' on' : ''}"><input type="checkbox" name="on"${TBC.on ? ' checked' : ''}> 새 상품 알림 켜기</label></div>
        <p class="small">폰 알림: ${nPh ? `켠 폰 ${nPh}대` : '아직 켠 폰이 없어요 — 폰 앱(킥스캔 계정으로 로그인) › 살 것 탭 › [알림 켜기]'}</p>
        ${nPh ? '<button type="button" class="ghost small" data-tbtest="1">폰으로 시험 알림 보내기</button> <span class="small" data-tbtmsg></span>' : ''}`, async fd => {
        const budget = Math.max(0, Math.round(+fd.budget || 0)), per = Math.round(+fd.per || 0), maxAge = Math.round(+fd.maxAge || 0);
        if (per < 1 || per > 20) return '상품당 최대 수량은 1~20개로 넣어 주세요';
        if (maxAge < 1 || maxAge > 336) return '시간은 1~336 사이로 넣어 주세요';
        TBC = { budget, per, maxAge, on: fd.on === 'on' }; await store.set('tbCfg', TBC);
        IS.msg = '오늘 살 것 설정을 바꿨어요'; tbCheck('cfg');
      });
      const tb = document.querySelector('#invDlg [data-tbtest]');
      if (tb) tb.addEventListener('click', async () => {
        const m = document.querySelector('#invDlg [data-tbtmsg]'); tb.disabled = true; if (m) m.textContent = '보내는 중…';
        const r = typeof pushSend === 'function' ? await pushSend('buy', '킥스캔 시험 알림 — 오늘 살 것', '새 수익 상품이 생기면 이렇게 알려 드려요. 누르면 살 것 탭이 열려요', './?t=buy', 'test-' + Date.now(), true) : null;
        if (m) m.textContent = r && r.ok ? `폰 ${r.ok}대에 보냈어요` : `못 보냈어요${r && r.why ? ' — ' + r.why : ''}`; tb.disabled = false;
      });
      return;
    }
  }
}
// [구매 ↗] → 구매 기록(쇼핑몰 주문 자동 연결 · 3일 뒤 '구매하셨나요?')
document.addEventListener('click', e => {
  const a = e.target.closest && e.target.closest('[data-tbbuy]'); if (!a || typeof biRecord !== 'function') return;
  const m = TBMAP.get(a.dataset.tbbuy); if (m) biRecord(m.r, m.C, null, 'buy').catch(() => {});
}, true);

// ---------- 다시 계산 · 새 상품 알림 · 폰에 올리기 ----------
function tbToast(title, body) {
  const cr = window.chrome && chrome.notifications && chrome.notifications.create;
  if (cr) { try { chrome.notifications.create('tb-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title, message: body.slice(0, 220), priority: 1 }); } catch (e) {} }
  // 위쪽 종(app.js topExtras)이 윈도우 알림을 감싸 이미 종에 넣어요 — 못 감쌌을 때만 직접
  if (!(cr && cr.__ks) && typeof notiAdd1 === 'function') notiAdd1(title, body.replace(/\n/g, ' · ')).then(() => { try { notiBadge(); } catch (e) {} });
}
async function tbNotify(fresh) {
  const title = `오늘 살 것 새 상품 ${fresh.length}개`;
  const body = fresh.slice(0, 3).map(x => `${x.name} — ${x.sizes.map(s => s.size).join('·')} · 예상 수익 ${tbWon(x.profit)}`).join('\n') + (fresh.length > 3 ? `\n외 ${fresh.length - 3}개 — 오늘 살 것에서 보기` : '');
  tbToast(title, body);
  if (typeof pushSend === 'function') { try { await pushSend('buy', title, body, './?t=buy', 'buy-' + Date.now()); } catch (e) {} }
}
async function tbPhoneSync() {
  if (!TBL || typeof clRpc !== 'function' || (typeof clOn === 'function' && !clOn())) return;
  const over = new Set(TBL.over.map(x => x.id));
  const items = [...TBL.pick, ...TBL.over].slice(0, 40).map(x => ({ id: x.id, ck: x.ck, code: x.code, name: String(x.name).slice(0, 80), brand: x.brand, img: x.img, site: x.site, url: x.url, unit: x.unit,
    sizes: x.sizes.map(s => ({ size: s.size, q: s.q, url: s.url && s.url !== x.url ? s.url : '' })), q: x.q, cost: x.cost, profit: x.profit, avg: x.avg, n30: x.n30, seller: x.seller, at: x.at, over: over.has(x.id) ? 1 : 0 }));
  const data = { type: 'tbuy', items, budget: TBL.budget, spent: TBL.spent, per: +TBC.per || 2, srcAt: TBL.srcAt, status: 'done' };
  const s = JSON.stringify(data), h = typeof clHash === 'function' ? clHash(s) : String(s.length);
  if (h === TBS.hash && Date.now() - (TBS.syncAt || 0) < 6 * 3600e3) return;
  await clRpc('ks_doc_put', { p_docs: [{ kind: 'job', id: 'tbuy', data: { ...data, at: Date.now() }, by: 'pc', at: new Date().toISOString() }] });
  TBS.hash = h; TBS.syncAt = Date.now(); await store.set('tbState', TBS);
}
async function tbCheck(why) {
  if (IS.tbBusy) return; IS.tbBusy = true;
  try {
    TBL = await tbList();
    const now = Date.now();
    for (const k of Object.keys(TBS.sent)) if (now - TBS.sent[k] > 3 * 864e5) delete TBS.sent[k];
    for (const k of Object.keys(TBS.skip)) if (TBS.skip[k] < now) delete TBS.skip[k];
    for (const k of Object.keys(TBS.done)) if (now - TBS.done[k].at > TB_DONE) delete TBS.done[k];
    const fresh = TBL.pick.filter(x => !TBS.sent[x.ck]);
    for (const x of fresh) TBS.sent[x.ck] = now;
    // 처음 한 번은 지금 있는 것만 기억해요(업데이트 직후 한꺼번에 울리지 않게)
    if (!TBS.base) TBS.base = now; else if (fresh.length && TBC.on) await tbNotify(fresh);
    await store.set('tbState', TBS);
    try { await tbPhoneSync(); } catch (e) {}
  } catch (e) { console.warn('todaybuy', e); }
  finally { IS.tbBusy = false; }
  if (tbHere() || why === 'view' || why === 'act' || why === 'cfg') { try { if (tbHere()) renderInv(); } catch (e) {} }
}
// 폰 앱 › 살 것 탭 [샀어요] · [안 살래요] (cloud.js clApply 가 불러요)
async function tbPhoneAct(d) {
  const ck = tbCk(d.ck || d.code); if (!ck) return;
  if (d.act === 'done') {
    const x = TBL && [...TBL.pick, ...TBL.over].find(y => y.ck === ck);
    TBS.done[ck] = { at: Date.now(), day: tbDay(), cost: x ? x.cost : (+d.cost || 0), q: x ? x.q : (+d.q || 0), name: String((x && x.name) || d.name || ck).slice(0, 60), from: 'phone' };
    const m = x && TBMAP.get(x.id); if (m && typeof biRecord === 'function') { try { await biRecord(m.r, m.C, null, 'buy'); } catch (e) {} }
  } else if (d.act === 'skip') TBS.skip[ck] = Date.now() + TB_SKIP;
  else if (d.act === 'undo') delete TBS.done[ck];
  await store.set('tbState', TBS);
  tbCheck('phone').catch(() => {});
}

(async function tbBoot() {
  try { TBC = { ...TBC, ...((await store.get('tbCfg', null)) || {}) }; TBS = { ...TBS, ...((await store.get('tbState', null)) || {}) }; } catch (e) {}
  setTimeout(() => tbCheck('boot').catch(() => {}), 50e3);
  setInterval(() => tbCheck('tick').catch(() => {}), 30 * 60e3);
  // 소싱이 도는 동안 결과가 바뀌면 5분에 한 번 다시 계산 — 새 수익 상품을 실행이 끝나기 전에도 알려요
  window.addEventListener('src:rows', () => { if (tbBoot.t) return; tbBoot.t = setTimeout(() => { tbBoot.t = null; tbCheck('rows').catch(() => {}); }, 5 * 60e3); });
})();
