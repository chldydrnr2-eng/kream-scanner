'use strict';
/* 킥스캔 본체 (3.1.1부터 자동 업데이트로 바뀌는 부분)
   웨일 확장 프로그램이 쓰던 chrome.* 기능(저장소·작업 창·사이트 읽기·알림·예약·업데이트)을 이 프로그램 안에서 해 줘요. */
module.exports = function (ctx) {
const { app, BrowserWindow, ipcMain, Notification, Tray, Menu, shell, session, nativeImage, webContents, net, screen, powerSaveBlocker, powerMonitor } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { BUNDLED, ROOT, VER, cmpVer } = ctx;
// 3.11.1: 새 KS 아이콘은 업데이트 폴더에 들어 있어요 — 있으면 그걸 창·알림·트레이 아이콘으로 써요
const ICON = (() => { try { const p = path.join(ROOT, 'icons', '256.png'); if (fs.existsSync(p)) return p; } catch (e) {} return ctx.ICON; })();
// 3.6.0: 브라우저 정보는 실제 엔진 버전에 맞춰요 (예전 설치본의 고정값 Chrome/130 대신)
const UA = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${String(process.versions.chrome || '130').split('.')[0]}.0.0.0 Safari/537.36`;
app.userAgentFallback = UA;
const PART = 'persist:shop';
// 3.8.0: 같은 쇼핑몰의 다른 아이디는 따로 저장 공간(persist:shop-zigzag-2 …)을 써요 — 로그인이 서로 안 섞이게
const PART_RE = /^persist:shop-[a-z0-9-]{1,40}$/;
const partOf = p => (typeof p === 'string' && PART_RE.test(p)) ? p : PART;
const prepped = new Set();
function prepShop(p) {
  p = partOf(p); const s = session.fromPartition(p);
  if (prepped.has(p)) return s; prepped.add(p);
  s.setUserAgent(DATA.__shopUA || UA, 'ko-KR,ko,en-US,en');
  s.setPermissionRequestHandler((wc, perm, cb) => cb(perm === 'notifications' ? false : perm === 'clipboard-sanitized-write'));
  keepLogins(s);
  if (p !== PART) { const l = DATA.__parts || (DATA.__parts = []); if (!l.includes(p)) { l.push(p); saveSoon(); } }
  return s;
}
// ---------- 3.0.1: 프로그램 안에서 업데이트 (화면·기능 파일만 바꾸는 작은 업데이트) ----------
// %APPDATA%\\KreamScanner\\app-update 에 더 새 버전이 있으면 그걸 써요. 설치 파일을 다시 받을 필요가 없어요.
const _cmpVerUnused = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
const UPD = () => path.join(app.getPath('userData'), 'app-update');

// 아주 작은 zip 풀기 (업데이트 파일 전용)
function unzip(buf) {
  const zlib = require('zlib'), out = [];
  let eocd = buf.length - 22; while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  if (eocd < 0) throw new Error('zip 파일이 아니에요');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip 목록이 깨졌어요');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), loff = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8');
    p += 46 + nlen + elen + clen;
    if (name.endsWith('/')) continue;
    const ds = loff + 30 + buf.readUInt16LE(loff + 26) + buf.readUInt16LE(loff + 28);
    const raw = buf.slice(ds, ds + csize);
    out.push({ name, data: method === 0 ? raw : zlib.inflateRawSync(raw) });
  }
  return out;
}
// 3.13.0: 업데이트 파일 서명 확인 — 우리 서명 키로 만든 파일만 깔려요 (저장소가 털려도 남의 코드가 안 깔리게)
const UPD_PUB = '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEARI+38A4fTOnEz+f979PA5AvDIfC3D6Ef7y3Nns0zHBE=\n-----END PUBLIC KEY-----\n';
function updDigest(files, base) {
  const crypto = require('crypto');
  const lines = files.filter(f => f.name.startsWith(base) && f.name !== base + 'update.sig').map(f => f.name.slice(base.length) + '\0' + crypto.createHash('sha256').update(f.data).digest('hex')).sort();
  return Buffer.from(lines.join('\n'), 'utf8');
}
function updVerify(files, base) {
  const sf = files.find(f => f.name === base + 'update.sig');
  if (!sf) throw new Error('서명이 없는 업데이트 파일이라 설치하지 않았어요');
  let ok = false; try { ok = require('crypto').verify(null, updDigest(files, base), UPD_PUB, Buffer.from(sf.data.toString('utf8').trim(), 'base64')); } catch (e) { ok = false; }
  if (!ok) throw new Error('업데이트 파일 서명이 맞지 않아서 설치하지 않았어요 (파일이 바뀌었거나 공식 파일이 아니에요)');
}
function applyUpdate(bytes) {
  const files = unzip(Buffer.from(bytes));
  const vf = files.find(f => /(^|\/)version\.json$/.test(f.name)); if (!vf) throw new Error('킥스캔 업데이트 파일이 아니에요 (version.json 없음)');
  const base = vf.name.replace(/version\.json$/, '');
  const ver = JSON.parse(vf.data.toString('utf8')).version;
  if (!files.some(f => f.name === base + 'app.html')) throw new Error('업데이트 파일에 화면 파일이 없어요');
  if (cmpVer(ver, VER) <= 0) throw new Error(`이미 ${VER} 버전이에요 (업데이트 파일은 ${ver})`);
  updVerify(files, base);
  const tmp = UPD() + '.tmp'; fs.rmSync(tmp, { recursive: true, force: true });
  for (const f of files) {
    if (!f.name.startsWith(base)) continue;
    const rel = f.name.slice(base.length); if (!rel || rel.includes('..')) continue;
    const dst = path.join(tmp, rel); fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.writeFileSync(dst, f.data);
  }
  fs.rmSync(UPD(), { recursive: true, force: true }); fs.renameSync(tmp, UPD());
  return ver;
}


// ---------- 저장소 (chrome.storage.local 대신 JSON 파일) ----------
let DATA = {}, saveT = null;
const dataFile = () => path.join(app.getPath('userData'), 'kream-data.json');
function loadData() {
  for (const f of [dataFile(), dataFile() + '.bak']) {
    try { DATA = JSON.parse(fs.readFileSync(f, 'utf8')); return; } catch (e) {}
  }
  DATA = {};
}
function flush() {
  clearTimeout(saveT); saveT = null;
  const f = dataFile(), tmp = f + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(DATA));
    try { if (fs.existsSync(f)) fs.copyFileSync(f, f + '.bak'); } catch (e) {}
    fs.renameSync(tmp, f);
  } catch (e) { console.error('save failed', e); }
}
const saveSoon = () => { if (!saveT) saveT = setTimeout(flush, 400); };

// ---------- 창 ----------
let appWin = null, tray = null, quitting = false, trayMenu = () => {};
// 11/22: 트레이 상태(화면이 30초마다 알려 줘요) — 확인할 항목이 있으면 아이콘에 주황 점
let TRAY_ST = { warn: 0, last: 0, run: [] };
function trayImg(dot) {
  const img = nativeImage.createFromPath(ICON).resize({ width: 16, height: 16 });
  if (!dot) return img;
  try {
    const bmp = Buffer.from(img.toBitmap()), W = 16;   // BGRA
    for (let y = 9; y < 16; y++) for (let x = 9; x < 16; x++) { const dx = x - 12.5, dy = y - 12.5; if (dx * dx + dy * dy <= 11) { const i = (y * W + x) * 4; bmp[i] = 0x0b; bmp[i + 1] = 0x9e; bmp[i + 2] = 0xf5; bmp[i + 3] = 0xff; } }
    return nativeImage.createFromBitmap(bmp, { width: W, height: W });
  } catch (e) { return img; }
}
const appFile = () => path.join(ROOT, 'app.html');
const isAppUrl = u => /(^|\/)app\.html(\?|$)/.test(String(u)) || String(u).startsWith(pathToFileURL(appFile()).href);

// 11/22: 작업 표시줄 아이콘을 exe(킥스캔 아이콘)로 못 박아요 — 윈도우가 같은 앱 ID 에 예전 아이콘(Electron)을 기억하고 있어도 이 값을 써요
// 11/24: exe 경로 아이콘은 윈도우 아이콘 캐시에 예전 Electron 원자 아이콘이 남아 있으면 그걸 써요(창 · 앱 ID · 다시 실행 아이콘 다 맞는데도 원자) → 바로가기와 같은 kickscan.ico 파일(다른 경로라 캐시를 안 탐)로
const taskbarIco = () => { try { const f = path.join(app.getPath('userData'), 'kickscan.ico'); if (fs.existsSync(f)) return f; const src = path.join(ROOT, 'icons', 'app.ico'); if (fs.existsSync(src)) { fs.copyFileSync(src, f); return f; } } catch (e) {} return process.execPath; };
const taskbarIcon = w => { try { if (process.platform === 'win32' && app.isPackaged) w.setAppDetails({ appId: 'com.kreamscanner.app', appIconPath: taskbarIco(), appIconIndex: 0, relaunchCommand: '"' + process.execPath + '"', relaunchDisplayName: '킥스캔' }); } catch (e) {} };
function createAppWin(query, show) {
  const w = new BrowserWindow({
    width: 1480, height: 940, minWidth: 900, minHeight: 600, show: show !== false, icon: ICON, title: '킥스캔', autoHideMenuBar: true, backgroundColor: '#f3f4f2',
    webPreferences: { preload: path.join(ROOT, 'app-preload.js'), contextIsolation: false, sandbox: false, nodeIntegration: false, backgroundThrottling: false, additionalArguments: ['--kc-root=' + ROOT, '--kc-ver=' + VER] }
  });
  taskbarIcon(w);
  w.loadFile(appFile(), { search: query ? String(query).replace(/^\?/, '') : '' });
  w.webContents.setWindowOpenHandler(({ url }) => { openLink(url); return { action: 'deny' }; });
  w.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); openLink(url); } });
  w.webContents.on('did-finish-load', () => { try { w.webContents.setZoomFactor(zoomF()); } catch (e) {} });   // 개선판 1-11: 화면 크기
  return w;
}
// 개선판 1-11: 창을 닫으면 트레이에 남기(기본) 또는 프로그램 종료
// 윈도우 자동 실행은 '--hidden' 과 같이 등록해서, 확인할 때도 같은 값으로 물어야 맞게 나와요
const loginOn = () => { try { return app.getLoginItemSettings({ args: ['--hidden'] }).openAtLogin; } catch (e) { return false; } };
const zoomF = () => [0.9, 1, 1.1, 1.25].includes(+DATA.__zoom) ? +DATA.__zoom : 1;
function onMainClose(e) {
  if (quitting) return;
  if (DATA.__trayKeep === false) { quitting = true; return app.quit(); }
  e.preventDefault(); appWin.hide(); trayHint();
}
function showMain() {
  if (!appWin || appWin.isDestroyed()) {
    appWin = createAppWin('', true);
    appWin.on('close', onMainClose);
  }
  if (appWin.isMinimized()) appWin.restore();
  appWin.show(); appWin.focus();
}
let hinted = false;
function trayHint() { if (hinted) return; hinted = true; notify('킥스캔은 계속 실행 중이에요', '오른쪽 아래 작업 표시줄의 킥스캔 아이콘에서 다시 열거나 종료할 수 있어요. 자동 동기화·가격 추적은 켜 둔 동안 돌아가요.'); }

// 쇼핑몰 창(작업 창 · 로그인 창): 로그인은 persist:shop 에 저장돼요
function shopWin(url, opts) {
  opts = opts || {}; const part = partOf(opts.part); prepShop(part);
  const w = new BrowserWindow({
    width: opts.width || 1180, height: opts.height || 900, show: !opts.background, icon: ICON, autoHideMenuBar: true, title: opts.title || '킥스캔',
    webPreferences: { partition: part, preload: path.join(ROOT, 'work-preload.js'), contextIsolation: true, sandbox: false, nodeIntegration: false, backgroundThrottling: false, additionalArguments: ['--kc-root=' + ROOT] }
  });
  if (opts.background) bgHide(w);
  else if (opts.focused === false) w.showInactive();
  w.webContents.setWindowOpenHandler(() => ({ action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, icon: ICON, webPreferences: { partition: part, sandbox: false, contextIsolation: true, nodeIntegration: false } } }));   // 3.34: 여는 창과 sandbox를 맞춰야 로그인 팝업(네이버 등)이 원래 창으로 결과를 돌려줘요
  const wcid = w.webContents.id;
  w.webContents.on('did-start-navigation', (e) => { if (e.isMainFrame && !e.isSameDocument) domReady.set(wcid, false); });
  w.webContents.on('dom-ready', () => { setTimeout(() => domReady.set(wcid, true), 1200); });   // 화면이 그려지면 '완료'로 봐요 (광고 로딩은 안 기다려요)
  w.on('closed', () => domReady.delete(wcid));
  // 3.4.4: 화면이 비어 있을 때 원인을 알 수 있게 응답 코드·실패 이유를 적어 둬요
  w.webContents.on('did-navigate', (e, u, code, st) => navInfo.set(wcid, { url: u, code, st }));
  w.webContents.on('did-fail-load', (e, code, desc, u, main) => { if (main && code !== -3) navInfo.set(wcid, { url: u, fail: code + ' ' + desc }); });
  w.on('closed', () => navInfo.delete(wcid));
  if (url) w.loadURL(url).catch(() => {});
  return w;
}
const domReady = new Map();
const navInfo = new Map();
// 3.4.1: 작업 창을 뒤에서 실행 — 창은 그대로 그려지게(사이트가 정상 동작하게) 모든 모니터 바깥에 두고, 작업 표시줄·포커스도 안 가져가요.
// 직접 봐야 할 때(확인 화면·보안문자 등) windows.update(focused) 가 오면 화면 가운데로 꺼내요.
function bgHide(w) {
  try {
    const ds = screen.getAllDisplays();
    const x = Math.max(...ds.map(d => d.bounds.x + d.bounds.width)) + 400, y = Math.min(...ds.map(d => d.bounds.y));
    w.__bg = true; w.setSkipTaskbar(true); w.setPosition(x, y); w.showInactive(); w.setPosition(x, y);
  } catch (e) { w.showInactive(); }
}
function bgShow(w) {
  if (!w.__bg) return;
  w.__bg = false; w.setSkipTaskbar(false);
  try { const d = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).workArea; const [bw, bh] = w.getSize(); w.setPosition(Math.round(d.x + (d.width - bw) / 2), Math.round(d.y + Math.max(0, (d.height - bh) / 2))); } catch (e) { w.center(); }
}
function openLink(url) {
  if (!/^https?:/i.test(url)) return;
  if (/claude\.ai|claude\.com|(^|\.)kakao\.com\//i.test(url)) return shell.openExternal(url);   // 휴대폰용 페이지는 원래 쓰던 브라우저로
  shopWin(url, { title: '킥스캔 — 브라우저' });
}

// ---------- 알림 ----------
function notify(title, body, onClick) {
  try { const n = new Notification({ title, body, icon: ICON }); n.on('click', onClick || showMain); n.show(); } catch (e) {}
}

// ---------- 예약 (chrome.alarms 대신) ----------
const timers = new Map();
function alarmFire(name) {
  { const o = DATA.ops || {}; if (o.halt || o.vac) return; }   // 개선판 1-11: 긴급 정지 · 휴가 모드면 예약 작업(가격 추적 · 주문 자동 동기화)을 건너뛰어요
  if (name === 'kc-track') createAppWin('?track=1', false);
  if (name === 'ks-orders') createAppWin('?orders=1', false);
}
function alarmSchedule(name, a) {
  const old = timers.get(name); if (old) { clearTimeout(old.t); clearInterval(old.i); }
  const period = Math.max(1, +a.periodInMinutes || 0) * 60000, first = Math.max(1, +a.delayInMinutes || +a.periodInMinutes || 1) * 60000;
  const rec = { t: null, i: null };
  rec.t = setTimeout(() => { alarmFire(name); if (a.periodInMinutes) rec.i = setInterval(() => alarmFire(name), period); }, first);
  timers.set(name, rec);
}
function alarmsRestore() { for (const [n, a] of Object.entries(DATA.__alarms || {})) alarmSchedule(n, { ...a, delayInMinutes: a.periodInMinutes }); }

// ---------- 사이트 메시지 (chrome.tabs.sendMessage 대신) ----------
let msgSeq = 0; const waiting = new Map();
ipcMain.on('kc-reply', (e, id, resp) => { const w = waiting.get(id); if (w) { waiting.delete(id); w(resp); } });

const wcOf = id => { const wc = webContents.fromId(+id); if (!wc || wc.isDestroyed()) throw new Error('No tab with id: ' + id); return wc; };
const winOf = id => { const w = BrowserWindow.fromId(+id); if (!w || w.isDestroyed()) throw new Error('No window with id: ' + id); return w; };

const API = {
  storage: {
    get(keys) {
      if (keys == null) return { ...DATA, __alarms: undefined };
      if (typeof keys === 'string') return keys in DATA ? { [keys]: DATA[keys] } : {};
      if (Array.isArray(keys)) return Object.fromEntries(keys.filter(k => k in DATA).map(k => [k, DATA[k]]));
      return Object.fromEntries(Object.entries(keys).map(([k, d]) => [k, k in DATA ? DATA[k] : d]));
    },
    set(obj) { for (const [k, v] of Object.entries(obj || {})) { if (v === undefined) delete DATA[k]; else DATA[k] = v; } saveSoon(); return true; },
    remove(keys) { for (const k of [].concat(keys)) delete DATA[k]; saveSoon(); return true; }
  },
  windows: {
    create(o) { const w = shopWin(o.url, { width: o.width, height: o.height, focused: o.focused, background: !!o.background, part: o.part }); return { id: w.id, tabs: [{ id: w.webContents.id }] }; },
    get(id) { const w = winOf(id); return { id: w.id, focused: w.isFocused(), state: w.isMinimized() ? 'minimized' : 'normal', background: !!w.__bg }; },
    update(id, o) { const w = winOf(id); if (o && o.focused) bgShow(w); if (o && (o.state === 'normal' || o.focused)) { if (w.isMinimized()) w.restore(); if (!w.__bg) w.show(); } if (o && o.focused) w.focus(); return { id: w.id }; },
    remove(id) { const w = winOf(id); w.destroy(); return true; }
  },
  tabs: {
    get(id) { const wc = wcOf(id); const w = BrowserWindow.fromWebContents(wc); return { id: wc.id, url: wc.getURL(), status: !wc.isLoading() || domReady.get(wc.id) ? 'complete' : 'loading', dom: !!domReady.get(wc.id), windowId: w ? w.id : -1, active: true, nav: navInfo.get(wc.id) || null }; },
    update(id, o) { const wc = wcOf(id); if (o && o.url) wc.loadURL(o.url).catch(() => {}); if (o && o.muted !== undefined) wc.setAudioMuted(!!o.muted); return { id: wc.id }; },
    create(o) {
      const url = String(o && o.url || '');
      if (isAppUrl(url)) { const q = url.includes('?') ? url.slice(url.indexOf('?')) : ''; if (!q) { showMain(); return { id: appWin.webContents.id }; } const w = createAppWin(q, o.active !== false); return { id: w.webContents.id }; }
      if (/claude\.ai|claude\.com/i.test(url)) { shell.openExternal(url); return { id: -1 }; }
      const w = shopWin(url, { title: '킥스캔 — 브라우저', part: o && o.part }); return { id: w.webContents.id, windowId: w.id };
    },
    reload(id, o) { const wc = wcOf(id); domReady.set(wc.id, false); if (o && o.bypassCache) wc.reloadIgnoringCache(); else wc.reload(); return true; },
    query() { return BrowserWindow.getAllWindows().map(w => ({ id: w.webContents.id, url: w.webContents.getURL(), windowId: w.id })); },
    sendMessage(id, msg) {
      const wc = wcOf(id), mid = ++msgSeq;
      return new Promise((res, rej) => {
        const to = setTimeout(() => { waiting.delete(mid); rej(new Error('응답 없음')); }, 60000);
        waiting.set(mid, r => { clearTimeout(to); if (r && r.__kcNoListener) rej(new Error('Could not establish connection. Receiving end does not exist.')); else res(r); });
        wc.send('kc-msg', mid, msg);
      });
    }
  },
  scripting: {
    async executeScript(o) {
      const wc = wcOf(o.target && o.target.tabId);
      const code = `(${o.func}).apply(null, ${JSON.stringify(o.args || [])})`;
      // 3.1.1: wc.executeJavaScript는 페이지가 '다 불러질 때까지' 기다려서, 광고·추적 때문에 로딩이 안 끝나는 쇼핑몰(지그재그 등)에서 멈췄어요.
      //        mainFrame.executeJavaScript는 바로 실행돼요.
      const result = await wc.mainFrame.executeJavaScript(code, true);
      return [{ result: result === undefined ? null : result }];
    }
  },
  notifications: { create(id, o) { notify(o.title || '킥스캔', o.message || ''); return id; } },
  alarms: {
    create(name, a) { DATA.__alarms = { ...(DATA.__alarms || {}), [name]: { periodInMinutes: a.periodInMinutes, delayInMinutes: a.delayInMinutes } }; saveSoon(); alarmSchedule(name, a); return true; },
    clear(name) { const old = timers.get(name); if (old) { clearTimeout(old.t); clearInterval(old.i); timers.delete(name); } if (DATA.__alarms) { delete DATA.__alarms[name]; saveSoon(); } return true; }
  },
  app: {
    focusMain() { showMain(); return true; },
    info() { return { version: VER, bundled: app.getVersion(), updated: ROOT !== BUNDLED, platform: process.platform }; },
    // 3.13.0: 오류 보고서용 상태 (아이디·비밀번호·쿠키는 안 넣어요)
    diag() { const os = require('os'); const ago = t => t ? Math.round((Date.now() - t) / 1000) + '초 전' : '없음'; return { version: VER, bundled: app.getVersion(), updated: ROOT !== BUNDLED, electron: process.versions.electron, chrome: process.versions.chrome, os: `${process.platform} ${os.release()} ${process.arch}`, memMB: Math.round(process.memoryUsage().rss / 1048576), uptimeMin: Math.round(process.uptime() / 60), update: updState, whale: { via: kreamMode(), cdp: { on: cdpOpen(), browser: cdpBrowser(), err: CDP.lastErr || '', tabs: CDP.tabs.size, hide: { on: hideOn(), pid: HIDE.pid, fg: HIDE.fg.size, last: HIDE.last, ps: HIDE.ps ? (HIDE.ps.exitCode === null ? 'run' : 'exit ' + HIDE.ps.exitCode) : 'none', out: HIDE.out, err: HIDE.err } }, connected: whaleConnected(), extVer: KB.ver, lastPoll: ago(KB.last), oldExtPoll: ago(KB.oldLast), noKeyPoll: ago(KB.noKey), queue: KB.q.length, pending: KB.pend.size } }; },
    applyUpdate(bytes) { const v = applyUpdate(bytes); setTimeout(() => { quitting = true; flush(); app.relaunch(); app.exit(0); }, 800); return v; },
    resetUpdate() { fs.rmSync(UPD(), { recursive: true, force: true }); setTimeout(() => { quitting = true; flush(); app.relaunch(); app.exit(0); }, 800); return app.getVersion(); }
  }
};
// ---------- 3.13.0: 로그인 · 라이선스 (license.json 이 있을 때만 켜져요 — 없으면 지금처럼 그냥 써요) ----------
// 3.33: 업데이트 폴더(ROOT)에는 license.json 이 없어요 — 설치 폴더(BUNDLED) · 사용자 폴더 순서로도 찾아요
const LIC_CFG = (() => { for (const d of [ROOT, BUNDLED, app.getPath('userData')]) { try { const j = JSON.parse(fs.readFileSync(path.join(d, 'license.json'), 'utf8')); if (j && j.url && j.anon) return j; } catch (e) {} } return null; })();
const LIC_FILE = () => path.join(app.getPath('userData'), 'license-session.json');
const LIC_GRACE = 72 * 3600e3;   // 인터넷이 안 될 때 마지막 확인 뒤 3일까지는 그대로 써요
let LIC = { on: !!LIC_CFG, state: LIC_CFG ? 'checking' : 'off', email: '', plan: '', expires: '', msg: '' };
let licSess = null, licAccess = '', licAccessExp = 0;
// 3.36.2: 아이디 저장 · 자동 로그인 (자동 로그인을 끄면 로그인 정보를 이 PC에 남기지 않아서, 다음에 켤 때 다시 로그인해요)
const LIC_PREF_FILE = () => path.join(app.getPath('userData'), 'license-pref.json');
let licPref = (() => { try { const j = JSON.parse(fs.readFileSync(LIC_PREF_FILE(), 'utf8')); return { remember: j.remember !== false, auto: j.auto !== false, email: String(j.email || '') }; } catch (e) { return { remember: true, auto: true, email: '' }; } })();
function licPrefSave() { try { fs.writeFileSync(LIC_PREF_FILE(), JSON.stringify(licPref)); } catch (e) {} }
function licDevice() {
  const f = path.join(app.getPath('userData'), 'device-id.txt');
  try { const t = fs.readFileSync(f, 'utf8').trim(); if (/^[0-9a-f-]{36}$/.test(t)) return t; } catch (e) {}
  const t = require('crypto').randomUUID(); try { fs.writeFileSync(f, t); } catch (e) {} return t;
}
function licDeviceName() { const os = require('os'); return `${os.hostname()} (${process.platform === 'win32' ? 'Windows' : process.platform === 'darwin' ? 'Mac' : process.platform})`.slice(0, 80); }
function licLoad() {
  try {
    const raw = fs.readFileSync(LIC_FILE());
    const { safeStorage } = require('electron');
    const txt = raw[0] === 0x7b ? raw.toString('utf8') : safeStorage.decryptString(raw);
    licSess = JSON.parse(txt);
  } catch (e) { licSess = null; }
}
function licSave() {
  try {
    if (!licSess || licPref.auto === false) { fs.rmSync(LIC_FILE(), { force: true }); return; }
    const { safeStorage } = require('electron'); const txt = JSON.stringify(licSess);
    fs.writeFileSync(LIC_FILE(), safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(txt) : txt);
  } catch (e) {}
}
// 3.36.6(점검 D): 15초 안에 답이 없으면 끊고 '인터넷 연결 안 됨'으로 봐요 (서버가 멈춰도 '확인 중…'에서 안 멈추게)
const NET_TIMEOUT = 15000;
const netSignal = () => { try { return AbortSignal.timeout(NET_TIMEOUT); } catch (e) { return undefined; } };
async function licFetch(p, body, token) {
  const r = await net.fetch(LIC_CFG.url.replace(/\/$/, '') + p, { method: 'POST', signal: netSignal(), headers: Object.assign({ apikey: LIC_CFG.anon, 'content-type': 'application/json' }, token ? { authorization: 'Bearer ' + token } : (/^eyJ/.test(LIC_CFG.anon) ? { authorization: 'Bearer ' + LIC_CFG.anon } : {})), body: JSON.stringify(body || {}) });
  let j = null; try { j = await r.json(); } catch (e) {}
  return { ok: r.ok, status: r.status, j };
}
// 3.36.6: 로그인 서버 오류 코드 → 손님이 읽을 한국어 (Supabase Auth error_code)
const AUTH_WHY = {
  email_not_confirmed: '이메일 인증이 아직 안 됐어요 — 가입 메일의 링크를 눌러 주세요',
  invalid_credentials: '이메일 또는 비밀번호가 맞지 않아요',
  over_email_send_rate_limit: '메일을 너무 자주 보냈어요. 1시간쯤 뒤에 다시 해 주세요',
  over_request_rate_limit: '요청이 너무 많아요. 잠시 뒤에 다시 해 주세요',
  weak_password: '비밀번호가 너무 쉬워요. 영문과 숫자를 섞어 8자 이상으로 해 주세요',
  signup_disabled: '지금은 가입을 받지 않아요. 카카오 문의로 알려 주세요',
  user_already_exists: '이미 가입된 이메일이에요 — 로그인해 주세요',
  email_exists: '이미 가입된 이메일이에요 — 로그인해 주세요',
  email_address_invalid: '이메일 주소를 확인해 주세요',
  email_address_not_authorized: '이 이메일로는 메일을 보낼 수 없어요. 다른 이메일을 써 주세요',
  validation_failed: '입력한 내용을 확인해 주세요',
  user_banned: '이용이 정지된 계정이에요. 카카오 문의로 알려 주세요',
  user_not_found: '가입된 이메일이 아니에요'
};
const NET_MSG = '인터넷 연결을 확인해 주세요';
function authMsg(r, fallback) {
  const j = (r && r.j) || {}, code = j.error_code || j.code || '';
  if (AUTH_WHY[code]) return AUTH_WHY[code];
  const raw = String(j.msg || j.error_description || j.message || '');
  if (/not confirmed/i.test(raw)) return AUTH_WHY.email_not_confirmed;
  if (/already|registered|exists/i.test(raw)) return AUTH_WHY.user_already_exists;
  if (/rate limit/i.test(raw)) return AUTH_WHY.over_email_send_rate_limit;
  if (/password/i.test(raw) && /(weak|short|at least|characters)/i.test(raw)) return AUTH_WHY.weak_password;
  if (r && r.status >= 500) return '로그인 서버가 잠시 응답하지 않아요. 잠시 뒤에 다시 해 주세요';
  return fallback;
}
const LIC_WHY = { login: '로그인이 필요해요', no_license: '이 계정에는 이용권이 없어요', expired: '이용 기간이 끝났어요', device_limit: '이 계정은 다른 PC에서 쓰고 있어요' };
function licSet(st, extra) { LIC = { ...LIC, reason: '', graceUntil: 0, state: st, ...(extra || {}) }; for (const w of BrowserWindow.getAllWindows()) { try { if (!w.isDestroyed() && w.webContents.getURL().startsWith('file:')) w.webContents.send('kc-lic', LIC); } catch (e) {} } return LIC; }
async function licTokens(r) {
  const j = r.j || {}; if (!r.ok || !j.access_token) return false;
  licAccess = j.access_token; licAccessExp = Date.now() + ((+j.expires_in || 3600) - 60) * 1000;
  licSess = { ...(licSess || {}), refresh: j.refresh_token, email: (j.user && j.user.email) || (licSess && licSess.email) || '' }; licSave(); return true;
}
// 3.36.6: 만료 7 · 3 · 1일 전에 한 번씩 알려요 (새로 사서 만료일이 바뀌면 다시 셈)
function licExpNotice(exp) {
  try {
    const d = Math.ceil((new Date(exp) - Date.now()) / 864e5); if (!(d > 0 && d <= 7)) return;
    const t = [1, 3, 7].find(x => d <= x), key = exp + ':' + t; if (licSess.noticed === key) return; licSess.noticed = key;
    notify(`킥스캔 이용권이 ${d}일 남았어요`, '위쪽 \'이용권 구매\'에서 연장할 수 있어요. 연장한 기간은 남은 기간 뒤에 이어서 붙어요.');
  } catch (e) {}
}
async function licCheck() {
  if (!LIC_CFG) return licSet('off');
  if (!licSess || !licSess.refresh) return licSet('login', { msg: '' });
  try {
    if (!licAccess || Date.now() > licAccessExp) {
      const r = await licFetch('/auth/v1/token?grant_type=refresh_token', { refresh_token: licSess.refresh });
      if (!(await licTokens(r))) { if (r.status >= 400 && r.status < 500) { licSess = null; licSave(); return licSet('login', { msg: '다시 로그인해 주세요' }); } throw new Error('서버 응답 ' + r.status); }
    }
    const c = await licFetch('/rest/v1/rpc/ks_check', { p_device: licDevice(), p_name: licDeviceName() }, licAccess);
    if (!c.ok || !c.j) throw new Error('서버 응답 ' + c.status);
    const j = c.j;
    if (j.ok) { licSess.lastOk = Date.now(); licSess.plan = j.plan; licSess.expires = j.expires_at; licExpNotice(j.expires_at); licSave(); return licSet('ok', { email: licSess.email, plan: j.plan, expires: j.expires_at, msg: '' }); }
    // 3.36.6: 왜 막혔는지(reason)를 화면에 넘겨요 — PC 수 초과면 구매 대신 '다른 PC 해제'를 보여 줘요
    return licSet(j.reason === 'login' ? 'login' : 'blocked', { reason: j.reason || '', max: j.max || 0, email: licSess.email, plan: j.plan || (j.reason === 'device_limit' ? (licSess.plan || '') : ''), expires: j.expires_at || (j.reason === 'device_limit' ? (licSess.expires || '') : ''), msg: LIC_WHY[j.reason] || ('지금은 쓸 수 없는 계정이에요 (' + j.reason + ')') });
  } catch (e) {
    // 인터넷이 안 되면: 마지막 확인이 3일 안이고 기간이 남았으면 그대로 써요
    if (!licSess) return licSet('login', { msg: '' });
    const left = licSess.lastOk && Date.now() - licSess.lastOk < LIC_GRACE && (!licSess.expires || new Date(licSess.expires) > new Date());
    return licSet(left ? 'grace' : 'offline', { email: licSess.email || '', plan: licSess.plan || '', expires: licSess.expires || '', graceUntil: left ? licSess.lastOk + LIC_GRACE : 0, msg: left ? '인터넷 연결이 안 돼서 마지막 확인 기준으로 쓰고 있어요' : '이용권을 확인하지 못했어요 — ' + NET_MSG });
  }
}
const licOpen = () => !LIC.on || LIC.state === 'ok' || LIC.state === 'grace';
API.lic = {
  state() { return LIC; },
  async check() { return licCheck(); },
  async login(email, pw) {
    if (!LIC_CFG) return licSet('off');
    email = String(email || '').trim(); if (!email || !pw) return licSet('login', { msg: '이메일과 비밀번호를 넣어 주세요' });
    let r; try { r = await licFetch('/auth/v1/token?grant_type=password', { email, password: String(pw) }); } catch (e) { return licSet('login', { msg: NET_MSG + ' — 로그인 서버에 연결이 안 돼요' }); }
    if (!(await licTokens(r))) return licSet('login', { msg: authMsg(r, r.status === 400 ? '이메일 또는 비밀번호가 맞지 않아요' : '로그인 서버에 연결이 안 돼요. 잠시 뒤에 다시 해 주세요') });
    licSess.email = email; licSave(); if (licPref.remember) { licPref.email = email; licPrefSave(); } return licCheck();
  },
  pref() { return licPref; },
  setPref(p) {
    p = p || {}; if ('remember' in p) licPref.remember = !!p.remember; if ('auto' in p) licPref.auto = !!p.auto;
    if (!licPref.remember) licPref.email = ''; else if (p.email) licPref.email = String(p.email).trim();
    licPrefSave(); licSave(); return licPref;
  },
  async logout() { licSess = null; licAccess = ''; licSave(); return licSet(LIC_CFG ? 'login' : 'off', { email: '', plan: '', expires: '', msg: '' }); },
  async release() {   // 이 PC 등록 해제 (다른 PC로 옮길 때)
    if (!LIC_CFG || !licAccess) return false;
    try { await licFetch('/rest/v1/rpc/ks_release', { p_device: licDevice() }, licAccess); } catch (e) {}
    return API.lic.logout();
  },
  // 3.36.6: PC 수를 넘었을 때 — 이 PC 말고 다른 PC 등록을 지우고 여기서 써요 (서버 함수 ks_release_others 가 있어야 해요)
  // 11/22 (A8): 로그인된 기기 — 이 계정에 등록된 PC 목록(devices 표 · 본인 것만 읽기)
  async devices() {
    if (!LIC_CFG) return { ok: false, message: '로그인 서버가 설정돼 있지 않아요' };
    const tok = await licToken().catch(() => ''); if (!tok) return { ok: false, message: '다시 로그인해 주세요' };
    try {
      const r = await net.fetch(LIC_CFG.url.replace(/\/$/, '') + '/rest/v1/devices?select=device_id,name,first_seen,last_seen&order=last_seen.desc', { signal: AbortSignal.timeout(15000), headers: { apikey: LIC_CFG.anon, authorization: 'Bearer ' + tok } });
      const j = await r.json().catch(() => null);
      if (!r.ok || !Array.isArray(j)) return { ok: false, message: '기기 목록을 못 불러왔어요' };
      const me = licDevice();
      return { ok: true, list: j.map(d => ({ name: d.name || 'PC', me: d.device_id === me, first: d.first_seen, last: d.last_seen })) };
    } catch (e) { return { ok: false, message: NET_MSG }; }
  },
  async releaseOthers() {
    if (!LIC_CFG) return { ok: false, message: '로그인 서버가 설정돼 있지 않아요' };
    const tok = await licToken().catch(() => ''); if (!tok) return { ok: false, message: '다시 로그인해 주세요' };
    let r; try { r = await licFetch('/rest/v1/rpc/ks_release_others', { p_device: licDevice() }, tok); } catch (e) { return { ok: false, message: NET_MSG }; }
    if (r.status === 404 || (r.j && /PGRST202|could not find the function/i.test(JSON.stringify(r.j)))) return { ok: false, missing: true, message: '지금은 여기서 해제할 수 없어요 — 카카오 문의로 \'다른 PC 등록 해제\'를 요청해 주세요' };
    if (!r.ok) return { ok: false, message: '해제하지 못했어요. 잠시 뒤에 다시 해 주세요' };
    return { ok: true, st: await licCheck() };
  },
  async resetPw(email) {
    if (!LIC_CFG) return { ok: false, message: '로그인 서버가 설정돼 있지 않아요' };
    email = String(email || '').trim(); if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, message: '이메일 주소를 확인해 주세요' };
    let r; try { r = await licFetch('/auth/v1/recover?redirect_to=' + encodeURIComponent(siteUrl('reset/')), { email }); } catch (e) { return { ok: false, message: NET_MSG }; }
    return r.ok ? { ok: true, message: '비밀번호 재설정 메일을 보냈어요. 메일의 링크를 눌러 새 비밀번호를 정해 주세요' } : { ok: false, message: authMsg(r, '메일을 보내지 못했어요. 잠시 뒤에 다시 해 주세요') };
  }
};
// 3.36.6: 판매자 공개 페이지(GitHub Pages) — 가입 완료 · 비밀번호 재설정 · 약관 · shop.json
function siteUrl(p) { const b = String((LIC_CFG && LIC_CFG.site) || 'https://chldydrnr2-eng.github.io/kream-scanner/').replace(/\/?$/, '/'); const u = b + (p || ''); return LIC_CFG && LIC_CFG.anon && /^reset\//.test(p || '') ? u + '?k=' + encodeURIComponent(LIC_CFG.anon) : u; }
// shop.json = 판매자 공개 설정 { kakao, terms, privacy, refund, biz:{ name, ceo, regNo, mailOrderNo, addr, tel, email } }
// 켤 때 한 번 읽어서 이 PC에 저장해 둬요. 못 읽으면 저장해 둔 값을 써요 (그것도 없으면 화면이 예전 설정값을 써요).
const SHOP_FILE = () => path.join(app.getPath('userData'), 'shop-cache.json');
let SHOP = (() => { try { const j = JSON.parse(fs.readFileSync(SHOP_FILE(), 'utf8')); return j && typeof j === 'object' ? j : {}; } catch (e) { return {}; } })();
let shopRun = null;
function shopLoad() {
  if (shopRun) return shopRun;
  shopRun = (async () => {
    try {
      const u = process.env.KC_SHOP_URL || (LIC_CFG && LIC_CFG.shopUrl) || siteUrl('shop.json');
      const r = await net.fetch(u + (u.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store', signal: netSignal() });
      if (r.ok) { const j = await r.json(); if (j && typeof j === 'object' && !Array.isArray(j)) { SHOP = j; try { fs.writeFileSync(SHOP_FILE(), JSON.stringify(j)); } catch (e) {} } }
    } catch (e) {}
    return SHOP;
  })();
  return shopRun;
}
app.whenReady().then(() => shopLoad());
API.lic.shop = async () => { await Promise.race([shopLoad(), new Promise(r => setTimeout(r, 4000))]).catch(() => {}); return SHOP; };
// 3.39: POIZON 공식 오픈 API (open.poizon.com · 개발자 유형 'POIZON Seller') — 소싱 시세 조회용 읽기 전용
// App Key · App Secret 은 이 PC 에만 암호화해서 둬요(kream-data.json · 서버에 안 올리고, 화면에도 다시 안 보내요)
const PZ_FILE = () => path.join(app.getPath('userData'), 'poizon-key.bin');
const PZ_HOST = 'https://open.poizon.com/dop/api/v1/pop';
// 읽기 전용 주소만 허용 (11/24 승인 뒤 실제 호출 1건씩으로 확인한 것 — 메모는 진행상황.md)
//   batchPrice · price(출가 참고) = 권한 없음(400010004) · spu by-article-number = 404 → 부르면 '권한 없음'으로 기록만 해요
const PZ_READ = new Set(['/api/v1/intl-commodity/intl/sku/sku-basic-info/by-article-number', '/api/v1/intl-commodity/intl/sku/sku-basic-info/by-global-sku', '/api/v1/intl-commodity/intl/sku/sku-basic-info/by-barcodes', '/api/v1/recommend-bid/batchPrice', '/api/v1/recommend-bid/price', '/api/v1/intl/spu/spu-basic-info/by-article-number',
  '/api/v1/retrieve-bid/general-type-bidding-list', '/api/v1/retrieve-bid/general-type-bidding-list/simple', '/api/v1/retrieve-bid/deposit-type-bidding-list', '/api/v1/auto-follow-bidding/list',
  '/api/v2/order/generic_list', '/api/v2/order/getQcResultList', '/api/v1/bill/period_list', '/api/v1/bill/realtime_list', '/api/v1/bill/customer_return_list',
  '/api/v1/retrieve-deposit/list', '/api/v1/deposit/enterprise-stock-apply/pageQuery', '/api/v1/deposit/inbound/queryList', '/api/v1/deposit/inbound/queryInspectItemList']);
// GET 으로만 받는 주소 (POST 로 부르면 'Invalid request method')
const PZ_GET = new Set(['/api/v1/bill/period_list', '/api/v1/bill/realtime_list']);
// 바뀌는 목록(내 판매 · 주문 · 정산 · 보관)은 6시간 저장값을 안 써요 — 상품 · 시세 조회만 6시간
const PZ_LIVE = /retrieve-bid|auto-follow|\/order\/|\/bill\/|deposit/;
// 쓰기(판매 등록 · 수정 · 내리기 · 자동 입찰) — 저장값 · 재시도 없음. 수정하면 POIZON 이 출가 번호를 새로 줘요(옛 번호는 취소됨)
const PZ_WRITE = new Set(['/api/v1/submit-bid/normal-autonomous-bidding', '/api/v1/update-bid/normal-autonomous-bidding', '/api/v1/cancel-bid/cancel-bidding', '/api/v1/auto-follow-bidding/submit']);
const PZ_NAMES = { '/api/v1/recommend-bid/batchPrice': '사이즈별 최저가 (출가 참고 · 배치)', '/api/v1/recommend-bid/price': '사이즈별 최저가 (출가 참고)', '/api/v1/intl/spu/spu-basic-info/by-article-number': '품번으로 상품(SPU) 찾기' };
let PZK = null, pzLast = 0;
function pzLoad() {
  if (PZK) return PZK;
  try { const raw = fs.readFileSync(PZ_FILE()); const { safeStorage } = require('electron'); PZK = JSON.parse(raw[0] === 0x7b ? raw.toString('utf8') : safeStorage.decryptString(raw)); } catch (e) { PZK = null; }
  return PZK;
}
// 서명: 문서 'Authentication for Poizon Sellers' Step 4 — 빈 값 빼고 이름순 정렬 · Java URLEncoder 식 인코딩 · 끝에 App Secret · MD5 대문자 (문서 예시값과 같게 나오는 것 확인함)
const pzEnc = s => encodeURIComponent(String(s)).replace(/[!'()~]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase()).replace(/%20/g, '+');
const pzVal = v => Array.isArray(v) ? v.map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(',') : (v && typeof v === 'object') ? JSON.stringify(v) : String(v);
function pzSign(params, secret) {
  const keys = Object.keys(params).filter(k => k !== 'sign' && params[k] != null && params[k] !== '' && !(Array.isArray(params[k]) && !params[k].length)).sort();
  return require('crypto').createHash('md5').update(keys.map(k => pzEnc(k) + '=' + pzEnc(pzVal(params[k]))).join('&') + secret, 'utf8').digest('hex').toUpperCase();
}
// 3.39: 호출 한도(POIZON FAQ: 1초 5회 · 1분 300회 · 1시간 10,000회 · 하루 20,000회) — 1초 4회 이하로 맞추고 하루 사용량을 세요
const PZ_DAY_MAX = 20000, PZ_DAY_STOP = 19000, PZ_TTL = 6 * 3600e3;
const PZ_USE_FILE = () => path.join(app.getPath('userData'), 'poizon-usage.json');
const PZ_CACHE_FILE = () => path.join(app.getPath('userData'), 'poizon-cache.json');
let PZU = null, PZC = null, pzCacheT = null, pzWin = [];
let PZS = { status: '', err: '', at: 0, ip: '', noPerm: {} };   // noPerm: 권한 없음으로 막힌 주소 → 시각   // 마지막 호출 결과 — 설정 화면 'POIZON 연결: 대기 / 연결됨 / 오류'
const pzDay = () => new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 10);   // 한국 날짜
function pzUse() { if (!PZU) { try { PZU = JSON.parse(fs.readFileSync(PZ_USE_FILE(), 'utf8')); } catch (e) { PZU = {}; } } if (!PZU || PZU.day !== pzDay()) PZU = { day: pzDay(), n: 0 }; return PZU; }
function pzUseAdd() { const u = pzUse(); u.n++; try { fs.writeFileSync(PZ_USE_FILE(), JSON.stringify(u)); } catch (e) {} }
// 받은 결과는 6시간 다시 써요 (같은 품번은 소싱 한 번에 한 번만 불러요)
function pzCache() { if (!PZC) { try { PZC = JSON.parse(fs.readFileSync(PZ_CACHE_FILE(), 'utf8')) || {}; } catch (e) { PZC = {}; } } return PZC; }
function pzCacheSave() {
  clearTimeout(pzCacheT);
  pzCacheT = setTimeout(() => { try { const C = pzCache(), now = Date.now(), o = {}; Object.keys(C).filter(k => now - C[k].at < PZ_TTL).sort((a, b) => C[b].at - C[a].at).slice(0, 1500).forEach(k => { o[k] = C[k]; }); PZC = o; fs.writeFileSync(PZ_CACHE_FILE(), JSON.stringify(o)); } catch (e) {} }, 20000);
}
async function pzThrottle() {
  for (;;) {
    const now = Date.now(); pzWin = pzWin.filter(t => now - t < 3600e3);
    const m1 = pzWin.filter(t => now - t < 60e3);
    let wait = Math.max(0, pzLast + 250 - now);
    if (m1.length >= 290) wait = Math.max(wait, m1[0] + 60e3 - now);
    if (pzWin.length >= 9900) wait = Math.max(wait, pzWin[0] + 3600e3 - now);
    if (wait <= 0) break;
    if (wait > 120e3) throw new Error('POIZON 1시간 조회 한도에 가까워요 — 잠시 KREAM 만으로 계속해요');
    await new Promise(r => setTimeout(r, Math.min(wait, 5000)));
  }
  pzLast = Date.now(); pzWin.push(pzLast);
}
async function pzMyIp() {
  try { const ac = new AbortController(); setTimeout(() => ac.abort(), 5000); const t = (await (await fetch('https://api.ipify.org', { signal: ac.signal })).text()).trim(); return /^[\d.]{7,15}$|^[0-9a-f:]{3,39}$/i.test(t) ? t : ''; } catch (e) { return ''; }
}
// POIZON 오류를 한국어로 — 이유까지
async function pzErrTxt(code, msg, http) {
  const m = String(msg || ''), c = String(code || http || '');
  if (c === 'bid_price_above_cap' || /price set too high|价格设置过高/i.test(m)) return 'POIZON 가격 상한보다 높아요 — 가격을 낮춰서 다시 올려 주세요';
  if (c === '9172037' || /My Profile/i.test(m)) return 'POIZON 판매자 센터 › My Profile 에 발송 국가(Shipping Country/Region)를 먼저 넣어 주세요';
  if (/Listing has been canceled|已取消/i.test(m)) return '이미 내려간 판매예요';
  if (/Listing ID not found/i.test(m)) return 'POIZON 에 없는 판매 번호예요 — 목록을 새로 불러 주세요';
  if (c === '400010004' || /无权调用/.test(m)) return 'POIZON 권한 없음 — 이 기능의 API 권한이 없어요(승인된 권한 묶음에 없음)';
  if (/\bip\b|白名单|whitelist/i.test(m)) { const ip = PZS.ip || (PZS.ip = await pzMyIp()); return `이 PC의 인터넷 주소(IP)가 POIZON에 등록되지 않았어요. POIZON 콘솔 › IP Whitelist에 ${ip || '이 PC 의 공인 IP'}을(를) 추가하세요.`; }
  if (c === '401' || /签名|sign/i.test(m)) return 'POIZON 키가 맞지 않아요(서명 인증 실패) — App Key · App Secret 을 다시 확인해 주세요';
  if (/审核|review|audit|not (been )?approved|未上线|未审核|未通过/i.test(m)) return 'POIZON 앱이 아직 심사 중이에요 — 승인이 나면 다시 시작하지 않아도 다음 조회부터 POIZON 이 붙어요';
  if (c === '403' || /权限|无权|permission|forbidden|unauthori/i.test(m)) return `이 기능의 POIZON API 권한이 없어요 — POIZON 콘솔 › API Permission Package 에서 신청 · 승인을 확인해 주세요 (${m.slice(0, 60)})`;
  if (c === '429' || /限流|频繁|too many|rate limit/i.test(m)) return 'POIZON 호출 한도를 넘었어요 — 잠시 KREAM 만으로 계속해요';
  return `POIZON API 오류 ${c} — ${m.slice(0, 120)}`;
}
async function pzCall(p, body, fresh, write) {
  const K = pzLoad(); if (!K || !K.key || !K.secret) throw new Error('POIZON API 키가 없어요 — 설정 › 판매 설정에서 넣어 주세요');
  const ck = p + ' ' + JSON.stringify(body || {}), C = pzCache(), keep = !write && !PZ_LIVE.test(p);
  if (keep && !fresh && C[ck] && Date.now() - C[ck].at < PZ_TTL) return C[ck].data;
  if (PZS.noPerm[p] && Date.now() - PZS.noPerm[p] < 6 * 3600e3) throw new Error('POIZON 권한 없음 — 이 기능의 API 권한이 없어요(승인된 권한 묶음에 없음)');
  if (pzUse().n >= PZ_DAY_STOP) throw new Error(`POIZON 오늘 조회 한도(${PZ_DAY_MAX.toLocaleString('ko-KR')}회)에 가까워요 — 오늘은 KREAM 만으로 계속해요`);
  await pzThrottle(); pzUseAdd();
  const params = { language: 'ko', timeZone: 'Asia/Seoul', ...(body || {}), app_key: K.key, timestamp: Date.now() };
  params.sign = pzSign(params, K.secret);
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), 20000);
  try {
    const r = PZ_GET.has(p)
      ? await fetch(PZ_HOST + p + '?' + Object.keys(params).map(k => pzEnc(k) + '=' + pzEnc(pzVal(params[k]))).join('&'), { signal: ac.signal })
      : await fetch(PZ_HOST + p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(params), signal: ac.signal });
    const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch (e) {}
    // 오류 꼴이 두 가지: { code, msg } · { success: false, errors: [{ code, message }] } (판매 등록 가격 상한 등)
    const e0 = j && Array.isArray(j.errors) && j.errors[0];
    if (!j || e0 || (String(j.code) !== '200' && j.success !== true)) {
      const code = e0 ? e0.code : j && j.code, msg = await pzErrTxt(code, e0 ? e0.message : j ? j.msg : t.replace(/<[^>]+>/g, ' ').slice(0, 200), r.status);
      // 권한 없음 · 없는 주소(404)는 6시간 다시 안 불러요 — 설정 화면에 '권한 없음'으로 보여요
      if (String(code) === '400010004' || /无权调用/.test(String(j && j.msg)) || String(code) === '404') PZS.noPerm[p] = Date.now();
      else if (!write) PZS = { ...PZS, status: 'err', err: msg, at: Date.now() };
      const er = new Error(msg); er.pzCode = String(code || ''); throw er;
    }
    PZS = { ...PZS, status: 'on', err: '', at: Date.now() };
    if (keep) { C[ck] = { at: Date.now(), data: j.data }; pzCacheSave(); }
    return j.data;
  } catch (e) { if (e.name === 'AbortError') throw new Error('POIZON API 응답이 20초 넘게 없어요'); throw e; }
  finally { clearTimeout(to); }
}
// 11/22 영수증 사진 글자 인식: 윈도우에 들어 있는 글자 인식(Windows.Media.Ocr · 한국어)으로 — 인터넷 · 서버로 안 보내요(사진은 이 PC 안에서만)
// 들어오는 것: 그림 data URL(png · jpg) · 나가는 것: { ok, w, h, words: [[글자, x, y, 너비, 높이], …] } — 줄로 묶기 · 상품 고르기는 화면의 receipt.js
const OCR_PS = `param([string]$Path, [string]$Dst, [string]$Lang = 'ko')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | ? { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1' })[0]
function Await($op, [Type]$t) { $task = $asTask.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Path)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bmp = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new($Lang))
if (-not $eng) { $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if (-not $eng) { throw 'NO_OCR_LANG' }
$res = Await ($eng.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
$o = @{ w = $bmp.PixelWidth; h = $bmp.PixelHeight; lang = $eng.RecognizerLanguage.LanguageTag; words = @() }
foreach ($l in $res.Lines) { foreach ($wd in $l.Words) { $r = $wd.BoundingRect; $o.words += ,@($wd.Text, [int]$r.X, [int]$r.Y, [int]$r.Width, [int]$r.Height) } }
[IO.File]::WriteAllText($Dst, ($o | ConvertTo-Json -Depth 4 -Compress), (New-Object Text.UTF8Encoding $false))`;
API.ocr = {
  async read(dataUrl) {
    if (process.platform !== 'win32') return { ok: false, err: '영수증 글자 인식은 윈도우에서만 돼요' };
    const m = String(dataUrl || '').match(/^data:image\/(png|jpe?g|bmp);base64,(.+)$/i);
    if (!m) return { ok: false, err: '그림 파일(png · jpg)만 읽을 수 있어요' };
    const os = require('os'), dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kc-ocr-'));
    const ext = m[1].toLowerCase() === 'png' ? 'png' : m[1].toLowerCase() === 'bmp' ? 'bmp' : 'jpg';
    const img = path.join(dir, 'r.' + ext), ps = path.join(dir, 'ocr.ps1'), dst = path.join(dir, 'out.json');
    try {
      fs.writeFileSync(img, Buffer.from(m[2], 'base64')); fs.writeFileSync(ps, '﻿' + OCR_PS, 'utf8');
      const err = await new Promise(ok => {
        const p = require('child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', ps, '-Path', img, '-Dst', dst], { windowsHide: true, timeout: 60000 }, (e, so, se) => ok(e ? String(se || e.message || e) : ''));
        if (p.stdin) p.stdin.end();
      });
      if (!fs.existsSync(dst)) return { ok: false, err: /NO_OCR_LANG/.test(err) ? '윈도우 글자 인식용 한국어가 없어요 — 윈도우 설정 › 시간 및 언어 › 언어 › 한국어 › 언어 옵션에서 «광학 문자 인식»을 설치해 주세요' : '글자 인식을 못 했어요' + (err ? ' — ' + err.split('\n')[0].slice(0, 120) : '') };
      const j = JSON.parse(fs.readFileSync(dst, 'utf8'));
      return { ok: true, w: j.w, h: j.h, lang: j.lang, words: (j.words || []).filter(x => Array.isArray(x) && x.length === 5) };
    } catch (e) { return { ok: false, err: '글자 인식 오류 — ' + (e.message || e) }; }
    finally { try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {} }
  }
};
// 11/22 공유 바코드: 나이키 공식몰 KR 상품 정보(사이즈마다 GTIN) — 앱 화면(file://)에서는 나이키가 막아서(403) 여기서 받아요. 이 주소 하나 · 품번 꼴만 허용
API.nk = {
  async feed(code) {
    const c = String(code || '').trim().toUpperCase();
    if (!/^([A-Z]{2}\d{4}|\d{6})-\d{3}$/.test(c)) return { ok: false, err: '품번 꼴이 아니에요' };
    const u = 'https://api.nike.com/product_feed/threads/v2?filter=marketplace(KR)&filter=language(ko)&filter=channelId(d9a5bc42-4b9c-4976-858a-f159cf99c647)&filter=productInfo.merchProduct.styleColor(' + c + ')';
    let r; try { r = await net.fetch(u, { signal: AbortSignal.timeout(20000), headers: { accept: 'application/json', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36' } }); } catch (e) { return { ok: false, err: String(e.message || e) }; }
    if (!r.ok) return { ok: false, status: r.status, err: '나이키 응답 ' + r.status };
    let j; try { j = await r.json(); } catch (e) { return { ok: false, err: '나이키 응답을 못 읽었어요' }; }
    const out = { ok: true, name: '', sizes: {} };
    for (const o of j.objects || []) for (const pi of o.productInfo || []) {
      if (String((pi.merchProduct || {}).styleColor || '').toUpperCase() !== c) continue;
      out.name = out.name || (pi.productContent && pi.productContent.title) || '';
      for (const sk of pi.skus || []) {
        const kr = (sk.countrySpecifications || []).find(x => x.country === 'KR'), sz = String((kr && kr.localizedSize) || sk.nikeSize || '').trim(), g = String(sk.gtin || '').replace(/\D/g, '');
        if (sz && g.length >= 8 && g.length <= 14) out.sizes[sz] = g.padStart(14, '0');
      }
    }
    return out;
  }
};
API.pz = {
  // status: wait(키 없음) · set(키만 저장) · on(연결됨) · err(오류)
  state: async () => { const K = pzLoad(), set = !!(K && K.key && K.secret); return { set, tail: set ? K.key.slice(-4) : '', at: (K && K.at) || 0, status: set ? (PZS.status || 'set') : 'wait', err: set ? PZS.err : '', today: pzUse().n, max: PZ_DAY_MAX, noPerm: Object.keys(PZS.noPerm).map(p => PZ_NAMES[p] || p) }; },
  setKey: async (key, secret) => {
    key = String(key || '').trim(); secret = String(secret || '').trim();
    if (!/^[\w-]{8,}$/.test(key) || !/^[\w-]{8,}$/.test(secret)) throw new Error('App Key · App Secret 을 다시 확인해 주세요 (영문 · 숫자)');
    const { safeStorage } = require('electron'); const txt = JSON.stringify({ key, secret, at: Date.now() });
    fs.writeFileSync(PZ_FILE(), safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(txt) : txt); PZK = null; PZS = { ...PZS, status: '', err: '' };
    return API.pz.state();
  },
  clear: async () => { try { fs.rmSync(PZ_FILE(), { force: true }); } catch (e) {} PZK = null; PZS = { ...PZS, status: '', err: '' }; return API.pz.state(); },
  call: async (p, body, fresh) => { if (!PZ_READ.has(String(p))) throw new Error('킥스캔이 쓰지 않는 POIZON 주소예요'); return pzCall(String(p), body, !!fresh); },
  // 쓰기: 판매 등록 · 수정에는 요청 번호(requestId)를 새로 붙여요 — 같은 요청이 두 번 올라가지 않게. 보유 재고 확인은 화면에서
  write: async (p, body) => {
    p = String(p); if (!PZ_WRITE.has(p)) throw new Error('킥스캔이 쓰지 않는 POIZON 주소예요');
    const b = { ...(body || {}) };
    if (/submit-bid|update-bid/.test(p)) { if (!(+b.quantity >= 1) || !(+b.price > 0)) throw new Error('수량 · 가격을 확인해 주세요'); b.requestId = 'ks-' + Date.now() + '-' + require('crypto').randomBytes(4).toString('hex'); }
    return pzCall(p, b, true, true);
  },
};
// 11/22: 행사 (events.js · 줍픽 행사) — 신세계사이먼 프리미엄 아울렛 지점별 브랜드 할인(공개 sales-list). 화면에서는 다른 사이트를 못 불러서 본체가 대신 불러요
// 11/25: 롯데아울렛(롯데쇼핑 지점별 '쇼핑뉴스' — 요청 본문 cstrCd=지점번호) · 현대아울렛(ehyundai 지점별 쇼핑뉴스 — 지점 화면의 이번 주 DM 번호로) 추가
async function evGet(url, opt) {
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), 20000);
  try {
    const r = await fetch(url, { ...(opt || {}), headers: { 'User-Agent': UA, ...((opt && opt.headers) || {}) }, signal: ac.signal });
    if (!r.ok) throw new Error('행사를 못 받았어요 (HTTP ' + r.status + ')');
    return r;
  } finally { clearTimeout(to); }
}
const evPlain = s => String(s || '').replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim();
// "11.24(화)" 처럼 해가 없는 날짜 → 올해 (지금 달과 6달 넘게 차이 나면 작년 · 내년)
function evMD(m, d) {
  const now = new Date(Date.now() + 9 * 3600e3), y = now.getUTCFullYear(), cm = now.getUTCMonth() + 1;
  const yy = m - cm > 6 ? y - 1 : cm - m > 6 ? y + 1 : y;
  return `${yy}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
// 현대 쇼핑뉴스는 브랜드 칸이 없어요 — 제목 앞부분에서 브랜드만 떼요 ("[POP-UP] NBA 겨울 팝업" → NBA, "타미힐피거/락포트 특가전" → 타미힐피거/락포트)
function evHdBrand(nm) {
  const s = String(nm || '').replace(/\[(POP-?UP|팝업|수능[^\]]*|리빙[^\]]*|EVENT|이벤트|단독|NEW|SALE|HOT)\]\s*/gi, '').trim();
  const bm = s.match(/^[\[<]\s*([^\]>]{1,40}?)\s*[\]>]\s*(.*)$/); if (bm) return bm[1].trim();
  const STOP = /^(\d|UP|OFF|SALE|특가|할인|프로모션|세일|시즌|겨울|여름|봄|가을|신상|이월|기획|제안|팝업|POP|BLACK|FRIDAY|행사|페스티벌|위크|이번|최대|추가|특별|단독|기념|패밀리|수험|마감|X-?MAS|크리스마스|쇼핑|SPECIAL|PRICE|EVENT|이벤트|오픈|OPEN|\+|~|:)/i;
  const b = [];
  for (const t of s.split(' ')) { if (b.length && STOP.test(t)) break; b.push(t); if (b.length >= 3) break; }
  return b.join(' ').replace(/[\/·,:]+$/, '').trim() || s.slice(0, 20);
}
// 같은 지점에 제목 · 기간이 같은 글이 여러 번 올라오면 하나만 (현대 대전점 'GRAND OPENING' 여러 장)
const evUniq = L => { const seen = new Set(); return L.filter(x => { const k = String(x.title || '').replace(/\s+/g, '').toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; }); };
API.ev = {
  ss: async (code) => {
    code = String(code || '').replace(/\D/g, '').slice(0, 2); if (!code) throw new Error('지점 번호가 없어요');
    const q = encodeURIComponent(JSON.stringify({ searchStoreCode: code, rateKey: null, brandNameKeyword: '', language: '' }));
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), 20000);
    try {
      const r = await fetch(`https://www.premiumoutlets.co.kr/api/shopping-info/sales-list?q=${q}&currentPage=1&dataPerPage=300`, { headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36' }, signal: ac.signal });
      if (!r.ok) throw new Error('행사를 못 받았어요 (HTTP ' + r.status + ')');
      const d = await r.json();
      return (Array.isArray(d) ? d : []).map(x => { let ko = {}; try { ko = JSON.parse(x.transJson || '{}').ko || {}; } catch (e) {}
        return { id: x.id, brand: (x.brand && (x.brand.brandKorean || x.brand.brandEnglish)) || String(x.title || '').replace(/\(.*$/, ''), en: x.brand && x.brand.brandEnglish || '', title: String(ko.content || x.content || '').slice(0, 400), from: x.eventFrom || x.exposedFrom || '', to: x.eventTo || x.exposedTo || '', rate: x.discountRate || '', created: x.createdDt || '' }; });
    } finally { clearTimeout(to); }
  },
  // 롯데아울렛 · 롯데프리미엄아울렛: 지점 번호(4자리) → 쇼핑뉴스(패션 · 잡화 · 스포츠 · 아동만 — 식품 · 리빙은 빼요)
  lotte: async (code) => {
    code = String(code || '').replace(/\D/g, '').slice(0, 4); if (code.length !== 4) throw new Error('지점 번호가 없어요');
    const body = new URLSearchParams({ cntsTpCd: 'C00903', page: '1', size: '100', totalCnt: '0', cstrCd: code, ctegryLrclsCdList: '010000,020000,060000,090000,040000,050000,070000,080000' }).toString();
    const r = await evGet('https://www.lotteshopping.com/contents/shpgInfoList', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest', Referer: 'https://www.lotteshopping.com/contents/shpgInfo?cstrCd=' + code }, body });
    const h = await r.text(), out = [];
    for (const li of h.split(/<li class="content-item/).slice(1)) {
      const id = (li.match(/goUrl\('C00903',\s*'([A-Za-z0-9]+)'\)/) || [])[1]; if (!id) continue;
      const parts = String((li.match(/class="__title[^"]*"[^>]*>([\s\S]*?)<\/div>/) || [])[1] || '').split(/<br\s*\/?>/i).map(evPlain).filter(Boolean);
      let title = parts.join(' '), brand = '';
      const bm = title.match(/^\[([^\]]{1,40})\]\s*(.*)$/); if (bm) { brand = bm[1].trim(); title = bm[2].trim() || title; }
      const info = [...String((li.match(/class="__info"[^>]*>([\s\S]*?)<\/div>/) || [])[1] || '').matchAll(/<span[^>]*>([\s\S]*?)<\/span>/g)].map(m => evPlain(m[1])).filter(Boolean);
      const dm = evPlain((li.match(/class="__date"[^>]*>([\s\S]*?)<\/div>/) || [])[1] || '').match(/(\d{1,2})\.(\d{1,2})[^~]*~\s*(\d{1,2})\.(\d{1,2})/);
      const from = dm ? evMD(+dm[1], +dm[2]) : ''; let to = dm ? evMD(+dm[3], +dm[4]) : '';
      if (from && to && to < from) to = (+to.slice(0, 4) + 1) + to.slice(4);
      out.push({ id, brand: brand || evHdBrand(title), en: '', title: title.slice(0, 400), from, to, place: info.slice(1).filter(v => !/^(백화점|프리미엄 아울렛|아울렛|월드몰|에비뉴엘|쇼핑몰|타임빌라스)$/.test(v)).join(' · '), created: from });
    }
    return evUniq(out);
  },
  // 현대프리미엄아울렛 · 현대아울렛: 지점 번호(B00172000 꼴) → 지점 화면에서 이번 주 쇼핑뉴스 묶음 번호(D…)를 읽고 → 목록
  hd: async (code) => {
    code = String(code || '').trim(); if (!/^B\d{8}$/.test(code)) throw new Error('지점 번호가 없어요');
    const page = await (await evGet('https://www.ehyundai.com/newPortal/index.do?branchCd=' + code)).text();
    const dm = (page.match(/getContents\('(D\d+)'/) || [])[1]; if (!dm) return [];   // 이번 주 쇼핑뉴스가 아직 없는 지점
    const r = await evGet('https://www.ehyundai.com/newPortal/SN/GetCmsContentsAJX.do?apiID=ifAppHdcms012&param=' + encodeURIComponent(`mblDmCd=${dm}&evntCrdTypeCd=01&pageSize=100&page=1`), { headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest', Referer: 'https://www.ehyundai.com/newPortal/index.do?branchCd=' + code } });
    const j = await r.json(), L = j && j.result && Array.isArray(j.result.items) ? j.result.items : [];
    const d8 = v => { const m = String(v || '').match(/^(\d{4})(\d{2})(\d{2})/); return m ? `${m[1]}-${m[2]}-${m[3]}` : ''; };
    return evUniq(L.map(x => { const nm = String(x.evntCrdNm || '').replace(/\s+/g, ' ').trim(); return { id: x.evntCrdCd, brand: evHdBrand(nm), en: '', title: nm.slice(0, 400), from: d8(x.evntStrtDt), to: d8(x.evntEndDt), place: [x.evntFlrCd && x.evntFlrCd.label, x.evntPlceNm || (x.evntPlceCd && x.evntPlceCd.label)].filter(v => v && !/^(미입력|직접입력)$/.test(String(v).trim())).join(' '), created: d8(x.expsEvntStartDt) || d8(x.evntStrtDt) }; }).filter(x => x.id));
  },
};
// 11/25: 발매 (drops.js · 줍픽 발매) — 슈프라이즈 공개 목록(웹 화면이 부르는 것과 같은 주소): 진행 중 응모 · 선착순 + 발매 예정 상품
API.drop = {
  list: async () => {
    const A = 'https://api.shoeprize.com/api/v2', H = { headers: { Accept: 'application/json', Origin: 'https://www.shoeprize.com', Referer: 'https://www.shoeprize.com/' } };
    const get = async u => (await evGet(A + u, H)).json();
    const t = new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 10);
    const [R, P] = await Promise.all([get('/releases/?is_end=false&ordering=end_time,-id&page_size=100&page=1'), get(`/products/?first_release_date_gte=${t}&ordering=first_release_date&is_uncertain_date=false&is_active=true&is_official=true&page_size=60&page=1`)]);
    const link = p => p && p.permalink ? 'https://www.shoeprize.com/product/' + p.permalink : '';
    const rel = ((R && R.results) || []).map(x => { const p = x.product || {}, m = x.releaseMarket || {};
      return { id: x.id, pid: p.id, brand: p.brandName || '', name: p.name || '', en: p.nameEn || '', code: p.code || '', img: p.thumb || '', link: link(p), market: m.name || '', method: x.method || '', when: x.dateInfo || '', start: +x.startTimestamp || 0, end: +x.endTimestamp || 0, noEnd: !!x.isUndefinedEndTime,
        price: +x.salePrice || 0, cur: x.salePriceCurrency || '', sym: x.salePriceCurrencySymbol || '', region: x.region || '', kr: !!x.isDomesticSite, url: x.url || '', draw: x.type === 1, ship: x.shippingMethod || '', pay: x.payMethod || '' }; });
    const up = ((P && P.results) || []).map(p => ({ pid: p.id, brand: p.brandName || '', name: p.name || '', en: p.nameEn || '', code: p.code || '', img: p.thumb || '', link: link(p), date: p.releaseDate || p.firstReleaseDate || '', price: Math.round(+p.releasePrice || 0), priceTxt: p.price || '', cur: p.currency || '', sites: +p.releaseSiteCount || 0 }));
    return { at: Date.now(), rel, up };
  },
};
// 11/25: 폰 알림(웹 푸시) — 서버 함수 없이 PC 킥스캔이 폰 브라우저 푸시 서버로 바로 보내요 (RFC 8291 aes128gcm + VAPID)
//   키(P-256)는 이 PC 에 암호화 저장. 같은 계정의 다른 PC 와 같은 키를 쓰도록 화면(push.js)이 서버 문서(job/pushkey)로 나눠요 — 그 키로는 이 계정 폰에만 보낼 수 있어요
const PUSH_FILE = () => path.join(app.getPath('userData'), 'push-key.bin');
const pB64 = b => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const pB64d = s => Buffer.from(String(s || '').replace(/-/g, '+').replace(/_/g, '/'), 'base64');
let PUSHK = null;
function pushLoad() {
  if (PUSHK) return PUSHK;
  try { const raw = fs.readFileSync(PUSH_FILE()); const { safeStorage } = require('electron'); PUSHK = JSON.parse(raw[0] === 0x7b ? raw.toString('utf8') : safeStorage.decryptString(raw)); } catch (e) { PUSHK = null; }
  return PUSHK;
}
function pushSave(k) { const { safeStorage } = require('electron'); const txt = JSON.stringify({ x: k.x, y: k.y, d: k.d }); fs.writeFileSync(PUSH_FILE(), safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(txt) : txt); PUSHK = { x: k.x, y: k.y, d: k.d }; }
const pushPubOf = k => pB64(Buffer.concat([Buffer.from([4]), pB64d(k.x), pB64d(k.y)]));
const pushHkdf = (salt, ikm, info, n) => Buffer.from(require('crypto').hkdfSync('sha256', ikm, salt, info, n));
function pushJwt(aud, k) {
  const crypto = require('crypto');
  const h = pB64(JSON.stringify({ typ: 'JWT', alg: 'ES256' })), p = pB64(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: 'https://chldydrnr2-eng.github.io/kream-scanner/' }));
  const key = crypto.createPrivateKey({ key: { kty: 'EC', crv: 'P-256', x: k.x, y: k.y, d: k.d }, format: 'jwk' });
  return h + '.' + p + '.' + pB64(crypto.sign('sha256', Buffer.from(h + '.' + p), { key, dsaEncoding: 'ieee-p1363' }));
}
// 한 기기로 보내기 → 푸시 서버 응답 번호 (201 = 보냄, 404 · 410 = 그 폰이 알림을 껐거나 지움)
function pushEnc(sub, payload) {
  const crypto = require('crypto');
  const uaPub = pB64d(sub.keys && sub.keys.p256dh), auth = pB64d(sub.keys && sub.keys.auth);
  if (uaPub.length !== 65 || auth.length < 16) throw new Error('구독 정보가 이상해요');
  const ecdh = crypto.createECDH('prime256v1'); ecdh.generateKeys(); const asPub = ecdh.getPublicKey();
  const ikm = pushHkdf(auth, ecdh.computeSecret(uaPub), Buffer.concat([Buffer.from('WebPush: info\0'), uaPub, asPub]), 32);
  const salt = crypto.randomBytes(16);
  const cek = pushHkdf(salt, ikm, Buffer.from('Content-Encoding: aes128gcm\0'), 16), nonce = pushHkdf(salt, ikm, Buffer.from('Content-Encoding: nonce\0'), 12);
  const c = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const ct = Buffer.concat([c.update(Buffer.concat([Buffer.from(payload, 'utf8'), Buffer.from([2])])), c.final(), c.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPub.length]), asPub, ct]);
}
async function pushOne(sub, payload, k) {
  const ep = String((sub && sub.endpoint) || ''); if (!/^https:\/\/[^/]+\//.test(ep)) throw new Error('구독 주소가 이상해요');
  const r = await fetch(ep, { method: 'POST', headers: { TTL: '86400', Urgency: 'normal', 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', Authorization: `vapid t=${pushJwt(new URL(ep).origin, k)}, k=${pushPubOf(k)}` }, body: pushEnc(sub, payload), signal: AbortSignal.timeout(15000) });
  return r.status;
}
API.push = {
  // 공개 키(폰이 구독할 때 씀) — 없으면 새로 만들어요
  pub: async () => {
    let k = pushLoad();
    if (!k) { const { privateKey } = require('crypto').generateKeyPairSync('ec', { namedCurve: 'prime256v1' }); const j = privateKey.export({ format: 'jwk' }); k = { x: j.x, y: j.y, d: j.d }; pushSave(k); }
    return pushPubOf(k);
  },
  jwk: async () => { await API.push.pub(); const k = pushLoad(); return { x: k.x, y: k.y, d: k.d }; },
  // 다른 PC 가 먼저 만든 키를 받아 같이 써요
  use: async (k) => {
    if (!k || !k.x || !k.y || !k.d) throw new Error('푸시 키가 이상해요');
    require('crypto').createPrivateKey({ key: { kty: 'EC', crv: 'P-256', x: k.x, y: k.y, d: k.d }, format: 'jwk' });
    const cur = pushLoad(); if (!cur || cur.d !== k.d) pushSave(k);
    return pushPubOf(k);
  },
  // subs: [{ id, sub: { endpoint, keys: { p256dh, auth } } }] (한 번에 10대까지) · msg: { title, body, url, tag }
  send: async (subs, msg) => {
    const k = pushLoad(); if (!k) throw new Error('푸시 키가 없어요');
    const m = msg || {}, payload = JSON.stringify({ title: String(m.title || '킥스캔').slice(0, 80), body: String(m.body || '').slice(0, 240), url: String(m.url || '').slice(0, 300), tag: String(m.tag || '').slice(0, 60) });
    const out = [];
    for (const s of (subs || []).slice(0, 10)) { try { out.push({ id: s.id, status: await pushOne(s.sub, payload, k) }); } catch (e) { out.push({ id: s.id, err: String(e.message || e).slice(0, 120) }); } }
    return out;
  },
};
if (LIC_CFG) { app.whenReady().then(() => { licLoad(); licCheck(); setInterval(licCheck, 6 * 3600e3); }); }
// ---------- 3.33: 회원가입 · 이용권 결제 (토스페이먼츠 결제위젯) ----------
// license.json: { url, anon, tossClientKey, payPage?, payFn? } — tossClientKey 가 있어야 결제창이 켜져요.
// 결제 금액은 서버(ks-pay)가 정해요. 결제 창이 성공 페이지로 넘어오면 여기서 서버에 승인을 요청하고, 이용권을 다시 확인해요.
const PAY_PAGE = () => String((LIC_CFG && LIC_CFG.payPage) || 'https://chldydrnr2-eng.github.io/kream-scanner/pay/').replace(/\/?$/, '/');
const PAY_FN = () => (LIC_CFG && LIC_CFG.payFn) || (LIC_CFG.url.replace(/\/$/, '') + '/functions/v1/ks-pay');
async function licToken() {
  if (!LIC_CFG || !licSess || !licSess.refresh) return '';
  if (!licAccess || Date.now() > licAccessExp) { const r = await licFetch('/auth/v1/token?grant_type=refresh_token', { refresh_token: licSess.refresh }); if (!(await licTokens(r))) return ''; }
  return licAccess;
}
async function payCall(body) {
  let tok = ''; try { tok = await licToken(); } catch (e) { return { ok: false, message: NET_MSG }; }
  if (!tok) return { ok: false, message: '로그인이 필요해요' };
  let r; try { r = await net.fetch(PAY_FN(), { method: 'POST', signal: body && body.action === 'confirm' ? AbortSignal.timeout(60000) : netSignal(), headers: { apikey: LIC_CFG.anon, authorization: 'Bearer ' + tok, 'content-type': 'application/json' }, body: JSON.stringify(body) }); }
  catch (e) { return { ok: false, net: true, message: NET_MSG }; }
  let j = null; try { j = await r.json(); } catch (e) {}
  return j || { ok: false, message: '결제 서버가 응답하지 않아요. 잠시 뒤에 다시 해 주세요' };
}
let payWin = null;
Object.assign(API.lic, {
  payReady() { return !!(LIC_CFG && LIC_CFG.tossClientKey); },
  async orders() { return LIC_CFG ? payCall({ action: 'orders' }) : { ok: false }; },
  async signup(email, pw) {
    if (!LIC_CFG) return { ok: false, message: '로그인 서버가 설정돼 있지 않아요' };
    email = String(email || '').trim(); pw = String(pw || '');
    if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, message: '이메일 주소를 확인해 주세요' };
    if (pw.length < 8) return { ok: false, message: '비밀번호는 8자 이상으로 해 주세요' };
    let r; try { r = await licFetch('/auth/v1/signup?redirect_to=' + encodeURIComponent(siteUrl('welcome/')), { email, password: pw }); } catch (e) { return { ok: false, message: NET_MSG + ' — 가입 서버에 연결이 안 돼요' }; }
    const j = r.j || {};
    if (!r.ok) return { ok: false, message: authMsg(r, '가입하지 못했어요. 잠시 뒤에 다시 해 주세요') };
    // Supabase 는 이미 가입된 이메일이면(이메일 확인을 켠 경우) 오류 대신 빈 identities 를 줘요
    if (!j.access_token && Array.isArray(j.identities) && !j.identities.length) return { ok: false, message: AUTH_WHY.user_already_exists };
    if (j.access_token) { await licTokens(r); licSess.email = email; licSave(); if (licPref.remember) { licPref.email = email; licPrefSave(); } return { ok: true, st: await licCheck() }; }
    return { ok: true, confirm: true, message: '가입 확인 메일을 보냈어요. 메일의 링크를 누른 다음 로그인해 주세요.' };
  },
  async pay(plan, days) {
    if (!API.lic.payReady()) return { ok: false, message: '결제 준비가 아직 안 됐어요' };
    if (payWin && !payWin.isDestroyed()) { payWin.focus(); return { ok: false, message: '결제 창이 이미 열려 있어요' }; }
    const p = await payCall({ action: 'prepare', plan, days });
    if (!p || !p.ok) return { ok: false, message: (p && p.message) || '주문을 만들지 못했어요' };
    const base = PAY_PAGE();
    return new Promise(resolve => {
      let done = false; const fin = r => { if (!done) { done = true; resolve(r); } };
      const wp = { partition: 'persist:kcpay', contextIsolation: true, sandbox: true, nodeIntegration: false };
      const w = payWin = new BrowserWindow({ parent: appWin && !appWin.isDestroyed() ? appWin : undefined, width: 900, height: 840, minWidth: 760, minHeight: 700, title: '킥스캔 이용권 결제', icon: ICON, autoHideMenuBar: true, backgroundColor: '#f4f5fb', webPreferences: wp });
      w.webContents.setWindowOpenHandler(() => ({ action: 'allow', overrideBrowserWindowOptions: { parent: w, width: 760, height: 820, autoHideMenuBar: true, webPreferences: wp } }));   // 카드사 인증 창
      // 3.36.6: 결과를 보여 줄 때 창 제목도 바꿔요 (작업 표시줄에서 '결제 확인 중'으로 남지 않게)
      const say = (t, d, ok) => w.webContents.executeJavaScript(`(()=>{document.title=${JSON.stringify('킥스캔 — ' + t)};const s=document.getElementById('s');if(s)s.style.display='none';const t=document.getElementById('t'),d=document.getElementById('d');if(t){t.textContent=${JSON.stringify(t)};t.style.color=${JSON.stringify(ok ? '#0b7a4d' : '#b4371f')}}if(d){d.style.whiteSpace='pre-line';d.textContent=${JSON.stringify(d)};}})()`).then(() => { try { if (!w.isDestroyed()) w.setTitle('킥스캔 — ' + t); } catch (er) {} }).catch(() => {});
      const dueTxt = due => { const m = String(due || '').match(/(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d)/); return m ? `${+m[2]}월 ${+m[3]}일 ${m[4]}:${m[5]}까지` : ''; };
      w.webContents.on('did-navigate', async (e, url) => {
        if (done || !url) return;
        if (url.startsWith(base + 'success.html')) {
          const u = new URL(url);
          let r; try { r = await payCall({ action: 'confirm', paymentKey: u.searchParams.get('paymentKey'), orderId: u.searchParams.get('orderId'), amount: +u.searchParams.get('amount') }); } catch (er) { r = { ok: false, message: er.message }; }
          if (r.ok && r.status === 'done') { await licCheck().catch(() => {}); await say('결제가 완료됐어요', '이용권이 반영됐어요. 이 창은 곧 닫혀요.', true); }
          else if (r.ok && r.status === 'waiting') {   // 가상계좌: 입금할 계좌를 보여 주고 창을 닫지 않아요 (같은 내용이 킥스캔 구매창에도 남아요)
            r.amount = r.amount || p.amount; r.dueText = dueTxt(r.due);
            await say('입금을 기다리고 있어요', [r.account ? `${r.bank ? r.bank + ' ' : ''}${r.account}` : '입금 계좌는 토스페이먼츠 안내 문자 · 메일에서 확인해 주세요', `입금할 금액 ${Number(r.amount || 0).toLocaleString('ko-KR')}원`, r.dueText ? `입금 기한 ${r.dueText}` : '', '입금하면 이용권이 자동으로 반영돼요. 이 창은 닫아도 돼요.'].filter(Boolean).join('\n'), true);
          }
          else await say('결제를 확인하지 못했어요', (r.message || '') + ' — 카드 승인이 됐다면 판매자에게 문의해 주세요.', false);
          fin(r); if (r.ok && r.status === 'done') setTimeout(() => { try { if (!w.isDestroyed()) w.close(); } catch (er) {} }, 2500);
        } else if (url.startsWith(base + 'fail.html')) {
          const u = new URL(url); fin({ ok: false, code: u.searchParams.get('code') || '', message: u.searchParams.get('message') || '결제가 끝나지 않았어요' });
        }
      });
      w.on('closed', () => { payWin = null; fin({ ok: false, cancel: true, message: '결제 창을 닫았어요' }); });
      w.loadURL(base + '?' + new URLSearchParams({ ck: LIC_CFG.tossClientKey, cust: p.customerKey, oid: p.orderId, amt: String(p.amount), name: p.orderName }).toString()).catch(() => {});
    });
  }
});

// ---------- 3.37: 휴대폰 보기 — 킥스캔 계정의 요약(실적 · 판매 · 재고 · 시세)을 서버 표 ks_snap 에 올려요 ----------
// 휴대폰 웹앱(사이트 m/)이 같은 계정으로 로그인해서 읽기만 해요. 표는 docs/supabase/phone-setup.sql.
// 실패해도 앱 동작에는 영향 없게 조용히 상태만 적어요. 표가 아직 없으면(404) '서버 준비 전'으로 두고 6시간마다만 다시 시도해요.
const SNAP_KINDS = ['summary', 'sales', 'stock', 'market'];
const SNAP_MAX = 900 * 1024;            // 서버 제한(1MB)보다 조금 작게 — 넘으면 목록을 뒤에서부터 줄여서 올려요
const SNAP_RETRY = 6 * 3600e3;
const SNAP_FILE = () => path.join(app.getPath('userData'), 'snap-state.json');
let SNAP = (() => { try { const j = JSON.parse(fs.readFileSync(SNAP_FILE(), 'utf8')); return { at: +j.at || 0, err: String(j.err || ''), missing: +j.missing || 0, email: String(j.email || ''), kinds: j.kinds && typeof j.kinds === 'object' ? j.kinds : {} }; } catch (e) { return { at: 0, err: '', missing: 0, email: '', kinds: {} }; } })();
const snapSave = () => { try { fs.writeFileSync(SNAP_FILE(), JSON.stringify(SNAP)); } catch (e) {} };
let snapChain = Promise.resolve();
// 큰 목록(배열)을 반씩 줄여서 크기 안에 맞춰요. 줄였으면 data._cut = { 목록이름: 원래 개수 } 를 남겨요
function snapFit(data) {
  let s = JSON.stringify(data == null ? {} : data);
  if (Buffer.byteLength(s) <= SNAP_MAX) return { s, cut: false };
  const d = JSON.parse(s), cut = {};
  const arrs = []; (function walk(o, p) { for (const k of Object.keys(o)) { const v = o[k]; if (Array.isArray(v) && v.length) arrs.push([o, k, p + k]); else if (v && typeof v === 'object') walk(v, p + k + '.'); } })(d, '');
  for (let i = 0; i < 40 && Buffer.byteLength(s) > SNAP_MAX; i++) {
    const big = arrs.filter(([o, k]) => o[k].length > 1).sort((a, b) => JSON.stringify(b[0][b[1]]).length - JSON.stringify(a[0][a[1]]).length)[0];
    if (!big) break;
    const [o, k, name] = big; if (!(name in cut)) cut[name] = o[k].length;
    o[k] = o[k].slice(0, Math.max(1, Math.floor(o[k].length / 2)));
    d._cut = cut; s = JSON.stringify(d);
  }
  if (Buffer.byteLength(s) > SNAP_MAX) return { s: JSON.stringify({ _cut: { all: 1 }, _tooBig: true }), cut: true };
  return { s, cut: true };
}
// access token(JWT) 안의 사용자 id — 못 읽으면 서버 기본값(auth.uid())에 맡겨요
function snapUid(tok) { try { const p = JSON.parse(Buffer.from(String(tok).split('.')[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')); return /^[0-9a-f-]{36}$/i.test(p.sub || '') ? p.sub : ''; } catch (e) { return ''; } }
async function snapReq(method, p, body, tok) {
  const r = await net.fetch(LIC_CFG.url.replace(/\/$/, '') + p, { method, signal: netSignal(), headers: { apikey: LIC_CFG.anon, authorization: 'Bearer ' + tok, 'content-type': 'application/json', prefer: 'resolution=merge-duplicates,return=minimal' }, body: body == null ? undefined : body });
  let t = ''; try { t = await r.text(); } catch (e) {}
  return { ok: r.ok, status: r.status, t };
}
function snapNote(err, extra) { SNAP = { ...SNAP, err: err || '', ...(extra || {}) }; snapSave(); }
async function snapPutNow(kind, data) {
  if (!LIC_CFG) return { ok: false, skip: 'off' };
  if (!SNAP_KINDS.includes(kind)) return { ok: false, skip: 'kind' };
  if (!licSess || !licSess.refresh) return { ok: false, skip: 'login' };
  if (SNAP.missing && Date.now() - SNAP.missing < SNAP_RETRY) return { ok: false, skip: 'missing' };
  let tok = ''; try { tok = await licToken(); } catch (e) { snapNote(NET_MSG); return { ok: false, err: NET_MSG }; }
  if (!tok) { snapNote('로그인이 필요해요'); return { ok: false, skip: 'login' }; }
  const { s, cut } = snapFit(data), uid = snapUid(tok), now = new Date().toISOString();
  const row = `{${uid ? `"user_id":${JSON.stringify(uid)},` : ''}"kind":${JSON.stringify(kind)},"data":${s},"updated_at":${JSON.stringify(now)}}`;
  let r;
  for (let i = 0; i < 2; i++) {
    try { r = await snapReq('POST', '/rest/v1/ks_snap?on_conflict=user_id,kind', row, tok); } catch (e) { snapNote(NET_MSG); return { ok: false, err: NET_MSG }; }
    if (r.status !== 401 || i) break;
    licAccess = ''; try { tok = await licToken(); } catch (e) { tok = ''; } if (!tok) break;   // 토큰이 막 만료됐으면 한 번만 새로 받아서 다시
  }
  if (r.status === 404 || /PGRST205|42P01|relation .*ks_snap.* does not exist|Could not find the table/i.test(r.t)) { snapNote('서버 준비 전', { missing: Date.now() }); return { ok: false, missing: true }; }
  if (!r.ok) { const m = r.status === 401 || r.status === 403 ? '로그인이 필요해요' : '올리지 못했어요 (서버 응답 ' + r.status + ')'; snapNote(m); return { ok: false, status: r.status, err: m }; }
  const at = Date.now();
  SNAP.kinds[kind] = { at, bytes: Buffer.byteLength(s), cut };
  snapNote('', { at, missing: 0, email: licSess.email || '' });
  return { ok: true, at, bytes: Buffer.byteLength(s), cut };
}
Object.assign(API.lic, {
  // 한 번에 하나씩 차례로 올려요 (화면이 여러 개를 한꺼번에 불러도 겹치지 않게)
  // 3.37: 시세 공유 (docs/supabase/price-share.sql) — 정해 둔 함수 4개만 불러요. 로그인 안 했으면 skip
  async share(fn, args) {
    // 11/22: + PC ⇄ 서버 ⇄ 폰 동기화 (docs/supabase/sync-setup.sql)
    if (!['ks_kmap_get', 'ks_kmap_put', 'ks_kprice_get', 'ks_kprice_put', 'ks_doc_put', 'ks_doc_get', 'ks_doc_count'].includes(fn)) return { ok: false, skip: 'fn' };
    if (!LIC_CFG || !licSess || !licSess.refresh) return { ok: false, skip: 'login' };
    for (let i = 0; i < 2; i++) {
      let tok = ''; try { tok = await licToken(); } catch (e) {} if (!tok) return { ok: false, skip: 'login' };
      let r; try { r = await net.fetch(LIC_CFG.url.replace(/\/$/, '') + '/rest/v1/rpc/' + fn, { method: 'POST', signal: AbortSignal.timeout(20000), headers: { apikey: LIC_CFG.anon, authorization: 'Bearer ' + tok, 'content-type': 'application/json' }, body: JSON.stringify(args || {}) }); }
      catch (e) { return { ok: false, err: NET_MSG }; }
      if (r.status === 401 && !i) { licAccess = ''; continue; }
      let t = ''; try { t = await r.text(); } catch (e) {}
      if (!r.ok) return { ok: false, status: r.status, err: t.slice(0, 160) };
      try { return { ok: true, data: JSON.parse(t || 'null') }; } catch (e) { return { ok: true, data: null }; }
    }
    return { ok: false, skip: 'login' };
  },
  snapPut(kind, data) { const run = snapChain.then(() => snapPutNow(String(kind || ''), data)).catch(e => { snapNote(String((e && e.message) || e).slice(0, 120)); return { ok: false }; }); snapChain = run; return run; },
  snapState() {
    const login = !!(licSess && licSess.refresh), mine = !SNAP.email || !licSess || SNAP.email === licSess.email;
    return { on: !!LIC_CFG, login, at: mine ? SNAP.at : 0, err: SNAP.err, missing: !!SNAP.missing, retryAt: SNAP.missing ? SNAP.missing + SNAP_RETRY : 0, kinds: mine ? SNAP.kinds : {}, url: siteUrl('m/') };
  },
  // '휴대폰 보기에 올리기'를 끄면 서버에 올린 내 요약도 지워요
  async snapClear() {
    if (!LIC_CFG || !licSess || !licSess.refresh) return { ok: false, skip: 'login' };
    let tok = ''; try { tok = await licToken(); } catch (e) { return { ok: false, err: NET_MSG }; }
    if (!tok) return { ok: false, skip: 'login' };
    let r; try { r = await snapReq('DELETE', '/rest/v1/ks_snap?kind=in.(' + SNAP_KINDS.join(',') + ')', null, tok); } catch (e) { return { ok: false, err: NET_MSG }; }
    if (r.ok || r.status === 404) { SNAP = { at: 0, err: '', missing: 0, email: '', kinds: {} }; snapSave(); return { ok: true }; }
    return { ok: false, status: r.status, err: '지우지 못했어요 (서버 응답 ' + r.status + ')' };
  }
});

// 로그인 안 됐으면 크림·쇼핑몰 작업(창 열기·읽기·매크로)은 막아요. 저장소·업데이트·로그인 기능은 열어 둬요.
const LIC_FREE = new Set(['lic', 'app', 'storage']);
ipcMain.handle('kc', async (e, ns, method, args) => {
  if (!licOpen() && (!LIC_FREE.has(ns) || (ns === 'app' && ['probe', 'clearLogin', 'fixSite', 'setUA', 'setSsrStrip'].includes(method)))) throw new Error('로그인이 필요해요 — ' + (LIC.msg || '킥스캔 계정으로 로그인해 주세요'));
  const f = API[ns] && API[ns][method];
  if (!f) throw new Error(`지원하지 않는 기능: ${ns}.${method}`);
  return f.apply(API[ns], args || []);
});
ipcMain.on('kc-sync', (e, what) => { e.returnValue = what === 'root' ? ROOT : app.getVersion(); });

// ---------- 3.1: 자동 업데이트 (GitHub 릴리스) ----------
// 켤 때와 6시간마다 새 버전이 있는지 보고, 화면·기능 파일 업데이트는 혼자 받아서 바꿔요.
// 프로그램 뼈대(설치 파일)까지 바뀐 버전이면 설치 파일 받기 버튼을 띄워요.
const UPDATE_URL = process.env.KC_UPDATE_URL || 'https://raw.githubusercontent.com/chldydrnr2-eng/kream-scanner/main/updates/latest.json';
let updState = { state: 'idle', version: '', msg: '' };
function updBroadcast() { for (const w of BrowserWindow.getAllWindows()) { try { if (!w.isDestroyed() && w.webContents.getURL().startsWith('file:')) w.webContents.send('kc-update', updState); } catch (e) {} } }
// 3.36.3: 확인이 겹치지 않게 (시작 화면 확인 + 8초 뒤 자동 확인이 같은 파일을 두 번 받던 것) · 받아 둔 게 있으면 다시 받지 않아요
let updRun = null;
function checkUpdate(manual) {
  if (updState.state === 'ready') { if (manual) updBroadcast(); return Promise.resolve(updState); }
  if (updRun) { if (manual) updBroadcast(); return updRun; }
  updRun = checkUpdate0(manual).finally(() => { updRun = null; }); return updRun;
}
async function checkUpdate0(manual) {
  try {
    updState = { state: 'checking', version: VER, msg: '' }; if (manual) updBroadcast();
    // 3.10.27: raw 주소는 5분 정도 예전 내용을 줄 수 있어요 → GitHub에서 바로 읽고, 안 되면 raw로
    let j = null;
    if (!process.env.KC_UPDATE_URL) { try { const a = await net.fetch('https://api.github.com/repos/chldydrnr2-eng/kream-scanner/contents/updates/latest.json?ref=main&t=' + Date.now(), { cache: 'no-store', headers: { accept: 'application/vnd.github.raw+json', 'user-agent': 'KreamScanner' } }); if (a.ok) j = JSON.parse(await a.text()); } catch (e) { j = null; } }
    if (!j || !j.version) {
      const r = await net.fetch(UPDATE_URL + '?t=' + Date.now(), { cache: 'no-store', signal: netSignal() });
      if (!r.ok) throw new Error('업데이트 정보를 받지 못했어요. 잠시 뒤에 다시 해 주세요');
      j = await r.json();
    }
    if (!j.version || cmpVer(j.version, VER) <= 0) { updState = { state: 'latest', version: VER, msg: '' }; if (manual) updBroadcast(); return updState; }
    if (j.shell && cmpVer(j.shell, app.getVersion()) > 0) { updState = { state: 'installer', version: j.version, url: j.installer, msg: j.notes || '', notes: Array.isArray(j.changes) ? j.changes : String(j.notes || '').split(/\s*·\s*/).filter(Boolean) }; updBroadcast(); return updState; }
    // 3.17.0: 받는 동안 몇 % 받았는지 화면에 보내요 (시작 화면의 필수 업데이트 막대)
    const notes = Array.isArray(j.changes) ? j.changes : String(j.notes || '').split(/\s*·\s*/).filter(Boolean);
    updState = { state: 'downloading', version: j.version, pct: 0, msg: j.notes || '', notes }; updBroadcast();
    const z = await net.fetch(j.appZip, { cache: 'no-store' });
    if (!z.ok) throw new Error('업데이트 파일을 못 받았어요 (' + z.status + ')');
    const total = +z.headers.get('content-length') || 0, parts = []; let got = 0, lastPct = -1;
    if (z.body && z.body.getReader) { const rd = z.body.getReader(); for (;;) { const { done, value } = await rd.read(); if (done) break; parts.push(Buffer.from(value)); got += value.length; const pct = total ? Math.min(99, Math.floor(got / total * 100)) : 50; if (pct >= lastPct + 4) { lastPct = pct; updState = { ...updState, pct }; updBroadcast(); } } }
    else parts.push(Buffer.from(await z.arrayBuffer()));
    const v = applyUpdate(Buffer.concat(parts));
    updState = { state: 'ready', version: v, msg: j.notes || '', notes, pct: 100 };
    updBroadcast();
    // 창이 안 보이면(트레이에서 도는 중) 하던 일이 없을 때 바로 다시 켜요
    if ((!appWin || appWin.isDestroyed() || !appWin.isVisible()) && !(payWin && !payWin.isDestroyed())) setTimeout(() => restartForUpdate(), 3000);
    // 3.36.3: 로그인 화면이면(아직 하는 일이 없으니) 바로 다시 켜서 적용해요 — 그사이 로그인했으면 기다려요
    else if (LIC.on && !licOpen() && !(payWin && !payWin.isDestroyed())) setTimeout(() => { if (!licOpen() && !(payWin && !payWin.isDestroyed())) restartForUpdate(); else notify('킥스캔 새 버전 ' + v, '업데이트를 받아 두었어요. 화면 위쪽 「지금 다시 시작」을 누르거나, 다음에 켤 때 적용돼요.'); }, 2500);
    else notify('킥스캔 새 버전 ' + v, '업데이트를 받아 두었어요. 화면 위쪽 \'지금 다시 시작\'을 누르거나, 다음에 켤 때 적용돼요.');
    return updState;
  } catch (e) { const m = String(e.message || e); updState = { state: 'error', version: VER, msg: /net::|fetch failed|failed to fetch|abort|timeout|timed out/i.test(m) ? NET_MSG : /JSON|Unexpected token/i.test(m) ? '업데이트 정보를 읽지 못했어요. 잠시 뒤에 다시 해 주세요' : m }; if (manual) updBroadcast(); return updState; }
}
// 3.4.2: 로그인 유지 — 쇼핑몰이 '창 닫으면 지워지는 로그인 쿠키'를 주면, 프로그램을 껐다 켜거나(업데이트 재시작 포함) 할 때 로그인이 풀려요.
//        그런 쿠키를 30일짜리로 바꿔 저장해요 (크롬의 '로그인 상태 유지'와 같은 효과). 로그아웃하면 사이트가 지우는 대로 지워져요.
// 3.4.6: 값이 토큰(JWT)인 쿠키는 토큰 만료 시각까지만 저장해요 (만료된 크림 토큰이 남아서 크림이 빈 화면·오류를 주던 문제)
function jwtExp(v) {
  try { const m = decodeURIComponent(String(v || '')).match(/eyJ[\w-]+\.([\w-]+)\.[\w-]*/); if (!m) return 0; const j = JSON.parse(Buffer.from(m[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')); return +j.exp || 0; } catch (e) { return 0; }
}
const cookieUrl = c => (c.secure ? 'https://' : 'http://') + c.domain.replace(/^\./, '') + (c.path || '/');
function keepLogins(ses) {
  ses.cookies.on('changed', (e, c, cause, removed) => {
    if (removed || !c || !c.session || !c.domain) return;
    // 3.34: '로그아웃 표시' 값(false 등)은 오래 저장하지 않아요
    if (!c.value || /^(false|null|undefined|0)$/i.test(c.value)) return;
    try {
      const now = Math.floor(Date.now() / 1000), exp = jwtExp(c.value);
      if (exp && exp <= now) return;   // 이미 만료된 토큰은 오래 저장하지 않아요
      const d = { url: cookieUrl(c), name: c.name, value: c.value, path: c.path || '/', secure: !!c.secure, httpOnly: !!c.httpOnly, expirationDate: exp ? exp + 60 : now + 30 * 86400 };
      if (!c.hostOnly) d.domain = c.domain;
      if (c.sameSite && c.sameSite !== 'unspecified' && (c.sameSite !== 'no_restriction' || c.secure)) d.sameSite = c.sameSite;
      // 3.34: 저장하기 직전에 지금 값을 다시 봐요. 그사이 사이트가 새 값(예: 로그인 토큰)을 썼으면 옛 값으로 덮어쓰지 않아요.
      //       (예전엔 크림 로그인 직후 'false' 값이 늦게 다시 저장돼서 로그인 토큰을 지워 버렸어요 → 프로그램 안에서 크림 로그인이 안 되던 원인)
      ses.cookies.get({ url: d.url, name: c.name }).then(list => {
        const cur = list.find(x => x.name === c.name && x.domain === c.domain && (x.path || '/') === (c.path || '/'));
        if (!cur || !cur.session || cur.value !== c.value) return;
        return ses.cookies.set(d);
      }).catch(() => {});
    } catch (x) {}
  });
  // 켤 때: 이미 만료된 토큰 쿠키는 지워요 (사이트가 '로그인 풀림'으로 보고 다시 로그인하게)
  ses.cookies.get({}).then(list => { const now = Date.now() / 1000; for (const c of list) { const exp = jwtExp(c.value); if (exp && exp < now - 60) ses.cookies.remove(cookieUrl(c), c.name).catch(() => {}); } }).catch(() => {});
}
// 3.4.6: 다시 로그인하기 전에 그 사이트의 로그인 쿠키를 지워요 (꼬인 로그인 정리)
API.app.clearLogin = async o => {
  const ses = prepShop(o.part); const re = new RegExp(o.names || 'token|auth|session|strategy|ticketexpire', 'i'); let n = 0;
  for (const c of await ses.cookies.get({})) { const dm = c.domain.replace(/^\./, ''); if (o.exact ? dm !== o.domain : !dm.endsWith(o.domain)) continue; if (o.all || re.test(c.name)) { await ses.cookies.remove(cookieUrl(c), c.name).catch(() => {}); n++; } }
  return n;
};
function flushCookies() { try { return Promise.race([Promise.all([...new Set([PART, ...prepped])].map(p => session.fromPartition(p).cookies.flushStore().catch(() => {}))), new Promise(r => setTimeout(r, 1500))]); } catch (e) { return Promise.resolve(); } }
async function restartForUpdate() { quitting = true; flush(); await flushCookies(); app.relaunch({ args: process.argv.slice(1).filter(a => a !== '--hidden').concat(appWin && appWin.isVisible() ? [] : ['--hidden']) }); app.exit(0); }
// 3.2: 로그인 상태를 보이지 않는 창으로 바로 확인 (작업 창·대기열과 따로)
API.app.probe = async o => {
  prepShop(o.part); const w = new BrowserWindow({ show: false, width: 1200, height: 900, webPreferences: { partition: partOf(o.part), contextIsolation: true, sandbox: true, backgroundThrottling: false } });
  w.webContents.setAudioMuted(true);
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-prevent-unload', e => e.preventDefault());
  try {
    await new Promise(res => { const t = setTimeout(res, 15000); w.webContents.once('dom-ready', () => { clearTimeout(t); setTimeout(res, 900); }); w.loadURL(o.url).catch(() => res()); });
    return await Promise.race([w.webContents.mainFrame.executeJavaScript(`(${o.func})()`, true), new Promise(r => setTimeout(() => r(null), 15000))]);
  } catch (e) { return null; }
  finally { try { w.destroy(); } catch (e) {} }
};
// ---------- 3.7: 크림 작업은 웨일에서 (웨일 확장과 127.0.0.1로 연결) ----------
// 크림이 프로그램 안 브라우저의 로그인 요청을 막아서, 크림 화면 열기·읽기·매크로는 웨일(사장님 크림 로그인 그대로)에서 해요.
// 웨일 확장이 이 프로그램에 '할 일'을 물어보고(poll) 결과를 보내줘요(result). 창 번호는 1e9를 더해서 구분해요.
const RB = 1e9;
const KB = { q: [], waiters: [], pend: new Map(), seq: 0, last: 0, ver: '', port: 47615, launched: 0 };
// 3.13.0: 웨일 연결 암호 — 이 PC의 '크림스캐너 웨일 연결' 폴더에만 적어 두는 열쇠가 있어야 일을 주고받아요 (다른 확장이 끼어들지 못하게)
KB.token = (() => { const f = path.join(app.getPath('userData'), 'whale-key.txt'); try { const t = fs.readFileSync(f, 'utf8').trim(); if (/^[0-9a-f]{48}$/.test(t)) return t; } catch (e) {} const t = require('crypto').randomBytes(24).toString('hex'); try { fs.writeFileSync(f, t); } catch (e) {} return t; })();
KB.oldLast = 0; KB.oldReload = 0; KB.noKey = 0;
function kbWriteKey() { try { const d = extDir(); if (!fs.existsSync(path.join(d, 'manifest.json'))) return; const f = path.join(d, 'kc-token.json'); let cur = ''; try { cur = JSON.parse(fs.readFileSync(f, 'utf8')).k; } catch (e) {} if (cur !== KB.token) fs.writeFileSync(f, JSON.stringify({ k: KB.token })); } catch (e) {} }
const isKreamUrl = u => /^https?:\/\/([\w-]+\.)*kream\.co\.kr(\/|$|\?)/i.test(String(u || ''));
// 3.34: 크림 작업 방식 — cdp(기본: PC 브라우저를 킥스캔이 직접 조종) · whale(예전: 웨일·크롬 확장) · app(프로그램 안)
const kreamMode = () => ['cdp', 'whale', 'app'].includes(DATA.__kreamMode) ? DATA.__kreamMode : 'cdp';
const kreamViaWhale = () => kreamMode() !== 'app';
const isRemote = id => +id >= RB;
function kbFlush() {
  while (KB.waiters.length && KB.q.length) { const w = KB.waiters.shift(); clearTimeout(w.t); try { w.res.end(JSON.stringify(KB.q.splice(0))); } catch (e) {} }
}
function kbServer() {
  const srv = require('http').createServer((req, res) => {
    const origin = req.headers.origin || '', sfs = req.headers['sec-fetch-site'] || '';
    // 웨일 확장에서 온 요청만 받아요 (웹사이트가 보낸 요청은 막아요)
    if (!(/^chrome-extension:\/\//.test(origin) || (!origin && (!sfs || sfs === 'none')))) { res.writeHead(403); return res.end(); }
    if (origin) res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Content-Type', 'application/json');
    const u = req.url || '';
    const key = (u.match(/[?&]k=([0-9a-f]+)/) || [])[1] || '';
    if (key !== KB.token) {
      // 열쇠가 없거나 틀려요: 옛 버전 확장이면 새 파일로 다시 읽으라고만 하고, 다른 일은 안 줘요
      if (u.startsWith('/kc/poll')) {
        const v = (u.match(/[?&]v=([\w.]+)/) || [])[1] || ''; let mv = ''; try { mv = JSON.parse(fs.readFileSync(path.join(extDir(), 'manifest.json'), 'utf8')).version; } catch (e) {}
        KB.oldLast = Date.now(); if (v && mv && v === mv) KB.noKey = Date.now(); if (process.env.KC_DEBUG) console.error('[kb] nokey poll', v, mv, Date.now() - KB.oldReload);
        if (v && mv && v !== mv && Date.now() - KB.oldReload > 30000) { KB.oldReload = Date.now(); kbWriteKey(); return res.end(JSON.stringify([{ id: -1, op: 'reload', args: {} }])); }
        const t = setTimeout(() => { try { res.end('[]'); } catch (e) {} }, 20000); req.on('close', () => clearTimeout(t)); return;
      }
      return res.end('{}');
    }
    const fromB = uaBrowser(req.headers['user-agent']);
    if (fromB === 'whale') KB.sawWhale = Date.now();
    // 웨일을 골랐는데 최근에 웨일 이름표가 붙은 요청을 못 봤으면, 이름표만 보고 막지 않아요 (안전하게)
    const blockB = fromB && fromB !== curBrowser() && !(curBrowser() === 'whale' && fromB === 'chrome' && !(KB.sawWhale && Date.now() - KB.sawWhale < 120000));
    if (blockB) {
      KB.other = { b: fromB, t: Date.now() };
      if (u.startsWith('/kc/poll')) { const t = setTimeout(() => { try { res.end('[]'); } catch (e) {} }, 20000); req.on('close', () => clearTimeout(t)); return; }
      return res.end('{}');
    }
    if (u.startsWith('/kc/poll')) {
      KB.ever = true; if (!DATA.__extEver) { DATA.__extEver = Date.now(); saveSoon(); }
      KB.last = Date.now(); const v = (u.match(/[?&]v=([\w.]+)/) || [])[1]; if (v) KB.ver = v;
      if (KB.q.length) return res.end(JSON.stringify(KB.q.splice(0)));
      const w = { res, t: setTimeout(() => { KB.waiters = KB.waiters.filter(x => x !== w); KB.last = Date.now(); try { res.end('[]'); } catch (e) {} }, 20000) };
      KB.waiters.push(w); req.on('close', () => { clearTimeout(w.t); KB.waiters = KB.waiters.filter(x => x !== w); });
      return;
    }
    if (u.startsWith('/kc/result') && req.method === 'POST') {
      let b = ''; req.on('data', d => { b += d; if (b.length > 20e6) req.destroy(); });
      req.on('end', () => { try { const m = JSON.parse(b); const p = KB.pend.get(m.id); if (p) { KB.pend.delete(m.id); clearTimeout(p.t); m.ok ? p.res(m.value) : p.rej(new Error(m.error || '웨일 작업 실패')); } } catch (e) {} res.end('{}'); });
      return;
    }
    res.end('{}');
  });
  srv.on('error', e => console.error('웨일 연결 서버를 못 열었어요', e.message));
  srv.listen(KB.port, '127.0.0.1');
}
const whaleConnected = () => KB.waiters.length > 0 || Date.now() - KB.last < 25000;
// 3.16.0: 크롬도 지원 — 크림 작업을 할 브라우저(웨일/크롬)를 골라요
const BROWSERS = { whale: '웨일', chrome: '크롬' };
const curBrowser = () => DATA.__browser === 'chrome' ? 'chrome' : 'whale';
function browserPath(b) {
  const env = process.env, c = [];
  if (process.platform === 'darwin') c.push(b === 'chrome' ? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' : '/Applications/Naver Whale.app/Contents/MacOS/Naver Whale');
  for (const base of [env.ProgramFiles, env['ProgramFiles(x86)'], env.LOCALAPPDATA]) if (base) c.push(b === 'chrome' ? path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe') : path.join(base, 'Naver', 'Naver Whale', 'Application', 'whale.exe'));
  return c.find(f => { try { return fs.existsSync(f); } catch (e) { return false; } });
}
function whalePath() { return browserPath(curBrowser()); }
// 확장이 보낸 요청이 고른 브라우저에서 왔는지 (웨일은 이름표에 Whale이 들어 있어요)
const uaBrowser = ua => /Whale\//.test(String(ua || '')) ? 'whale' : /Chrome\//.test(String(ua || '')) ? 'chrome' : '';
async function ensureWhale() {
  if (whaleConnected()) return true;
  // 웨일이 꺼져 있으면 창 없이(백그라운드로) 켜요
  if (Date.now() - KB.launched > 60000) { const wp = whalePath(); if (wp) { try { require('child_process').spawn(wp, ['--no-startup-window'], { detached: true, stdio: 'ignore' }).unref(); KB.launched = Date.now(); } catch (e) {} } }
  for (let i = 0; i < 40 && !whaleConnected(); i++) await new Promise(r => setTimeout(r, 500));
  if (!whaleConnected() && Date.now() - KB.noKey < 60000) throw new Error(BROWSERS[curBrowser()] + ' 확장이 다른 폴더에서 올려져 있어서 연결 열쇠를 못 읽어요 — 설정 → \'연결 마법사\'에서 다시 올려 주세요');
  if (!whaleConnected()) { const bn = BROWSERS[curBrowser()]; if (KB.other && Date.now() - KB.other.t < 30000) throw new Error(`${BROWSERS[KB.other.b]}에 올린 확장이 연결하려고 해요. 크림 작업 브라우저를 ${BROWSERS[KB.other.b]}(으)로 바꾸거나 ${bn}에 확장을 올려 주세요 (설정 → 연결 마법사)`); throw new Error(`${bn}와(과) 연결이 안 돼요 — ${bn}을(를) 켜고 '킥스캔 연결' 확장이 켜져 있는지 확인해 주세요 (설정 → 연결 마법사)`); }
  return true;
}
// ---------- 3.34: 크림 작업은 PC에 깔린 브라우저(크롬 · 엣지 · 웨일)를 킥스캔이 직접 조종해요 (확장 설치 없음) ----------
// 크림 서버가 프로그램 안 브라우저의 '로그인한 요청'에는 10초 뒤 오류(500)를 줘요. 그래서 크림 일은 진짜 브라우저에서 해요.
// 킥스캔 전용 프로필(%APPDATA%\KreamScanner\kream-browser)로 브라우저를 켜고, 브라우저의 원격 조종 기능(DevTools 프로토콜, 이 PC 안 127.0.0.1)으로
// 창 열기 · 읽기 · 매크로를 해요. 예전 웨일 확장이 하던 일(winCreate · exec · send …)을 그대로 대신해요.
const CDPB = { chrome: '크롬', edge: '엣지', whale: '웨일' };
function cdpPath(b) {
  const env = process.env, c = [];
  if (process.platform === 'darwin') c.push({ chrome: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', edge: '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', whale: '/Applications/Naver Whale.app/Contents/MacOS/Naver Whale' }[b]);
  const rel = { chrome: ['Google', 'Chrome', 'Application', 'chrome.exe'], edge: ['Microsoft', 'Edge', 'Application', 'msedge.exe'], whale: ['Naver', 'Naver Whale', 'Application', 'whale.exe'] }[b];
  if (rel) for (const base of [env.ProgramFiles, env['ProgramFiles(x86)'], env.LOCALAPPDATA]) if (base) c.push(path.join(base, ...rel));
  if (process.platform === 'linux' && process.env.KC_CDP_EXE) c.unshift(process.env.KC_CDP_EXE);
  return c.find(f => { try { return f && fs.existsSync(f); } catch (e) { return false; } }) || '';
}
function cdpBrowser() {
  if (process.env.KC_CDP_EXE) return 'chrome';
  const want = DATA.__cdpB; if (want && CDPB[want] && cdpPath(want)) return want;
  return ['chrome', 'edge', 'whale'].find(b => cdpPath(b)) || '';
}
const cdpDir = () => process.env.KC_CDP_DIR || path.join(app.getPath('userData'), 'kream-browser');
const CDP = { ws: null, seq: 0, pend: new Map(), ready: null, tabs: new Map(), byTarget: new Map(), nid: 0, launchedAt: 0, ever: 0, lastErr: '' };
const cdpOpen = () => !!(CDP.ws && CDP.ws.readyState === 1);
function cdpSend(method, params, sessionId, ms) {
  return new Promise((res, rej) => {
    if (!cdpOpen()) return rej(new Error('브라우저 연결이 끊겼어요'));
    const id = ++CDP.seq, t = setTimeout(() => { CDP.pend.delete(id); rej(new Error('브라우저가 응답하지 않아요 (' + method + ')')); }, ms || 30000);
    CDP.pend.set(id, { res, rej, t });
    const m = { id, method, params: params || {} }; if (sessionId) m.sessionId = sessionId;
    CDP.ws.send(JSON.stringify(m));
  });
}
function cdpEvent(m) {
  const T = m.sessionId ? [...CDP.tabs.values()].find(x => x.sid === m.sessionId) : null;
  if (m.method === 'Target.detachedFromTarget' || m.method === 'Target.targetDestroyed') {
    const tid = m.params.targetId || (T && T.targetId); const id = CDP.byTarget.get(tid);
    if (m.method === 'Target.targetDestroyed' && id != null) { CDP.tabs.delete(id); CDP.byTarget.delete(tid); }
    return;
  }
  if (!T) return;
  const p = m.params || {};
  if (m.method === 'Page.frameNavigated' && !p.frame.parentId) { T.frameId = p.frame.id; T.url = p.frame.url; }
  else if (m.method === 'Page.frameStartedLoading' && (!T.frameId || p.frameId === T.frameId)) { T.status = 'loading'; T.dom = 0; }
  // 3.36.9: 문서(DOM)까지 받았는지도 따로 적어요 — KREAM 검색 화면은 load 가 20초 넘게 안 끝나는 일이 있어서, 카드만 읽을 땐 이걸로 충분해요
  else if (m.method === 'Page.domContentEventFired') T.dom = 1;
  else if (m.method === 'Page.loadEventFired') T.status = 'complete';
  else if (m.method === 'Page.navigatedWithinDocument' && (!T.frameId || p.frameId === T.frameId)) T.url = p.url;
  else if (m.method === 'Runtime.executionContextCreated') { const c = p.context; if (c.name === 'kc' && c.auxData && (!T.frameId || c.auxData.frameId === T.frameId)) T.kcCtx = c.id; }
  else if (m.method === 'Runtime.executionContextsCleared') T.kcCtx = 0;
  else if (m.method === 'Runtime.executionContextDestroyed' && p.executionContextId === T.kcCtx) T.kcCtx = 0;
}
// 브라우저가 이미 켜져 있으면(킥스캔을 다시 켠 경우) 그대로 붙고, 아니면 킥스캔 전용 프로필로 켜요
async function cdpConnectFile() {
  let txt = ''; try { txt = fs.readFileSync(path.join(cdpDir(), 'DevToolsActivePort'), 'utf8'); } catch (e) { return false; }
  const [port, wsPath] = txt.split(/\r?\n/); if (!+port || !wsPath) return false;
  return new Promise(res => {
    let ws; try { ws = new WebSocket(`ws://127.0.0.1:${+port}${wsPath}`); } catch (e) { return res(false); }
    const t = setTimeout(() => { try { ws.close(); } catch (e) {} res(false); }, 3000);
    ws.onopen = () => { clearTimeout(t); CDP.ws = ws; res(true); };
    ws.onerror = () => { clearTimeout(t); res(false); };
    ws.onclose = () => { if (CDP.ws === ws) { CDP.ws = null; for (const [, p] of CDP.pend) { clearTimeout(p.t); p.rej(new Error('브라우저가 닫혔어요')); } CDP.pend.clear(); CDP.tabs.clear(); CDP.byTarget.clear(); } };
    ws.onmessage = ev => {
      let m; try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : Buffer.from(ev.data).toString('utf8')); } catch (e) { return; }
      if (m.id) { const p = CDP.pend.get(m.id); if (!p) return; CDP.pend.delete(m.id); clearTimeout(p.t); m.error ? p.rej(new Error(m.error.message || '브라우저 오류')) : p.res(m.result || {}); return; }
      try { cdpEvent(m); } catch (e) {}
    };
  });
}
async function cdpStart() {
  if (cdpOpen()) return true;
  if (CDP.ready) return CDP.ready;
  CDP.ready = (async () => {
    if (await cdpConnectFile()) { await cdpAfterConnect(); return true; }
    const b = cdpBrowser(), exe = process.env.KC_CDP_EXE || cdpPath(b);
    if (!exe) throw new Error('크롬이나 엣지를 찾지 못했어요 — 크롬을 설치하거나, 설정 → 크림 작업에서 다른 방식을 골라 주세요');
    const dir = cdpDir(); fs.mkdirSync(dir, { recursive: true }); try { fs.unlinkSync(path.join(dir, 'DevToolsActivePort')); } catch (e) {}
    const args = ['--remote-debugging-port=0', '--user-data-dir=' + dir, '--no-first-run', '--no-default-browser-check', '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows', '--hide-crash-restore-bubble', '--mute-audio', '--window-size=1200,900'];
    if (hideOn()) args.push('--window-position=-32000,-32000');   // 3.35: 켤 때 첫 창이 화면에 번쩍이지 않게 (곧바로 숨겨요)
    if (process.env.KC_CDP_ARGS) args.push(...process.env.KC_CDP_ARGS.split(' ').filter(Boolean).map(decodeURIComponent));
    args.push('about:blank');
    require('child_process').spawn(exe, args, { detached: true, stdio: 'ignore' }).unref(); CDP.launchedAt = Date.now();
    for (let i = 0; i < 60; i++) { await new Promise(r => setTimeout(r, 250)); if (await cdpConnectFile()) { await cdpAfterConnect(true); return true; } }
    throw new Error((CDPB[b] || '브라우저') + '를 켜지 못했어요 — 이미 켜진 킥스캔 브라우저 창을 모두 닫고 다시 해 주세요');
  })();
  try { return await CDP.ready; } catch (e) { CDP.lastErr = e.message; throw e; } finally { CDP.ready = null; }
}
async function cdpAfterConnect(fresh) {
  HIDE.pid = 0; HIDE.last = '';
  CDP.ever = Date.now(); if (!DATA.__cdpEver) { DATA.__cdpEver = Date.now(); saveSoon(); }
  await cdpSend('Target.setDiscoverTargets', { discover: true }).catch(() => {});
  if (fresh) {   // 처음 켤 때 생긴 빈 창은 최소화해 둬요 (창을 다 닫으면 브라우저가 꺼져서, 하나는 남겨 둬요)
    try { const { targetInfos } = await cdpSend('Target.getTargets'); const t = targetInfos.find(x => x.type === 'page'); if (t) { const { windowId } = await cdpSend('Browser.getWindowForTarget', { targetId: t.targetId }); await cdpSend('Browser.setWindowBounds', { windowId, bounds: { windowState: 'minimized' } }); } } catch (e) {}
  }
}
// 크림 화면에 넣는 스크립트 (예전 확장의 content_scripts 와 같아요)
let CDP_SRC = null;
function cdpSources() {
  if (CDP_SRC) return CDP_SRC;
  const rd = f => { try { return fs.readFileSync(path.join(ROOT, 'content', f), 'utf8'); } catch (e) { return ''; } };
  const prod = "location.origin === 'https://kream.co.kr' && /^\\/products\\//.test(location.pathname)", my = "location.origin === 'https://kream.co.kr' && /^\\/my/.test(location.pathname)", sell = "(location.origin === 'https://kream.co.kr' && /^\\/sell\\//.test(location.pathname))";
  const shim = "globalThis.chrome = globalThis.chrome || {}; if (!chrome.runtime || !chrome.runtime.__kc) chrome.runtime = { __kc: 1, onMessage: { addListener(f) { (globalThis.__kcMsgL = globalThis.__kcMsgL || []).push(f); } } };";
  CDP_SRC = {
    main: `if (${prod}) {\n${rd('hook.js')}\n}\nif ((${my}) || ${sell}) {\n${rd('hook-my.js')}\n}`,   // 3.42: 판매 입찰 화면(/sell/)의 수수료 견적 응답도 받아 적어요
    iso: `${shim}\nif (${prod}) {\n${rd('core.js')}\n${rd('bridge.js')}\n}\nif (${my}) {\n${rd('bridge-my.js')}\n}`
  };
  // find.js 안의 기능들 (이름으로 불러 써요)
  const vm = require('vm'), box = {}; try { vm.runInNewContext(rd('find.js'), box, { timeout: 2000 }); } catch (e) { console.error('[cdp] find.js', e.message); }
  CDP_SRC.fn = {}; for (const k of Object.keys(box)) if (typeof box[k] === 'function') CDP_SRC.fn[k] = box[k].toString();
  return CDP_SRC;
}
async function cdpAttach(targetId) {
  const { sessionId } = await cdpSend('Target.attachToTarget', { targetId, flatten: true });
  const id = ++CDP.nid; const T = { id, targetId, sid: sessionId, status: 'loading', url: '', frameId: '', kcCtx: 0, use: Date.now(), busy: 0, bg: false };
  CDP.tabs.set(id, T); CDP.byTarget.set(targetId, id);
  const S = cdpSources();
  await cdpSend('Page.enable', {}, sessionId); await cdpSend('Runtime.enable', {}, sessionId);
  await cdpSend('Page.addScriptToEvaluateOnNewDocument', { source: S.main }, sessionId);
  await cdpSend('Page.addScriptToEvaluateOnNewDocument', { source: S.iso, worldName: 'kc' }, sessionId);
  try { const { frameTree } = await cdpSend('Page.getFrameTree', {}, sessionId); T.frameId = frameTree.frame.id; T.url = frameTree.frame.url; } catch (e) {}
  return T;
}
const cdpTab = id => { const T = CDP.tabs.get(+id); if (!T) throw new Error('창이 이미 닫혔어요'); T.use = Date.now(); return T; };
async function cdpWin(T) { const { windowId } = await cdpSend('Browser.getWindowForTarget', { targetId: T.targetId }); return windowId; }
// 3.35: 킥스캔이 조종하는 브라우저 창은 화면 · 작업 표시줄에서 완전히 숨겨요 (윈도우).
//       크림 로그인처럼 사람이 봐야 하는 창이 열려 있을 때만 보여 줘요. 브라우저 자체는 평범한 크롬 · 엣지 그대로예요 (위장 없음).
const HIDE = { ps: null, pid: 0, fg: new Set(), last: '', file: '', out: '', err: '' };
const HIDE_PS = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @"
using System; using System.Collections.Generic; using System.Runtime.InteropServices; using System.Text;
public static class KsWin {
  public delegate bool EP(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EP f, IntPtr l);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint c);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  static HashSet<IntPtr> hidden = new HashSet<IntPtr>();
  public static string Hide(uint pid) {
    int seen = 0, n = 0;
    EnumWindows((h, l) => { uint p; GetWindowThreadProcessId(h, out p); if (p != pid) return true; seen++; if (!IsWindowVisible(h) || GetWindow(h, 4) != IntPtr.Zero) return true;
      var sb = new StringBuilder(64); GetClassName(h, sb, 64); if (!sb.ToString().StartsWith("Chrome_WidgetWin")) return true;
      ShowWindow(h, 0); hidden.Add(h); n++; return true; }, IntPtr.Zero);
    return "hid " + n + "/" + seen + " total " + hidden.Count;
  }
  public static void Show() { foreach (var h in hidden) ShowWindow(h, 8); hidden.Clear(); }
}
"@
while ($true) { $l = [Console]::In.ReadLine(); if ($l -eq $null) { break }; $a = $l.Split(' '); if ($a[0] -eq 'hide') { [Console]::Out.WriteLine([KsWin]::Hide([uint32]$a[1])) } elseif ($a[0] -eq 'show') { [KsWin]::Show(); [Console]::Out.WriteLine('shown') } elseif ($a[0] -eq 'ping') { [Console]::Out.WriteLine('pong') }; [Console]::Out.Flush() }
[KsWin]::Show()
`;
const hideOn = () => process.platform === 'win32' && !process.env.KC_CDP_SHOW && DATA.__cdpShow !== true;
function hideSend(line) {
  if (!hideOn()) return;
  try {
    if (!HIDE.ps || HIDE.ps.exitCode !== null) {
      HIDE.file = path.join(app.getPath('userData'), 'kc-hide.ps1'); fs.writeFileSync(HIDE.file, '﻿' + HIDE_PS, 'utf8');
      HIDE.ps = require('child_process').spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', HIDE.file], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
      HIDE.ps.on('error', e => { HIDE.err = String(e.message || e); }); HIDE.ps.stdin.on('error', () => {});
      HIDE.ps.stdout.on('data', d => { HIDE.out = String(d).trim().split(/\r?\n/).pop().slice(0, 120); }); HIDE.ps.stderr.on('data', d => { HIDE.err = (HIDE.err + String(d)).slice(-400); });
    }
    HIDE.ps.stdin.write(line + '\n');
  } catch (e) {}
}
async function hidePid() {
  if (HIDE.pid) return HIDE.pid;
  try { const { processInfo } = await cdpSend('SystemInfo.getProcessInfo'); const b = (processInfo || []).find(x => x.type === 'browser'); HIDE.pid = b ? b.id : 0; } catch (e) {}
  return HIDE.pid;
}
async function hideTick() {
  if (!hideOn() || !cdpOpen()) return;
  for (const id of [...HIDE.fg]) if (!CDP.tabs.has(id)) HIDE.fg.delete(id);
  // 로그인 창: 크림에 로그인이 끝나면(로그인 화면을 벗어나면) 닫고 다시 숨겨요
  for (const id of HIDE.fg) { const T = CDP.tabs.get(id); if (T && T.login && T.url && /^https:\/\/kream\.co\.kr\//.test(T.url) && !/\/login/.test(T.url)) { if (!T.doneAt) T.doneAt = Date.now(); else if (Date.now() - T.doneAt > 2500) { HIDE.fg.delete(id); cdpClose(id).catch(() => {}); notify('크림 로그인 완료', '이제 크림 작업은 화면에 안 보이게 뒤에서 해요.'); } } }
  const want = HIDE.fg.size || Date.now() < (HIDE.peekUntil || 0) ? 'show' : 'hide';   // 11/22: 설정 [창 잠깐 보기]
  if (want === 'show') { if (HIDE.last !== 'show') hideSend('show'); }
  else { const pid = await hidePid(); if (pid) hideSend('hide ' + pid); }
  HIDE.last = want;
}
setInterval(() => { hideTick().catch(() => {}); }, 1200);
app.on('before-quit', () => { try { if (HIDE.ps) { HIDE.ps.stdin.write('show\n'); HIDE.ps.stdin.end(); } } catch (e) {} });
async function cdpFront(T) {
  T.bg = false; HIDE.fg.add(T.id); hideSend('show'); HIDE.last = 'show';
  try { const wid = await cdpWin(T); await cdpSend('Browser.setWindowBounds', { windowId: wid, bounds: { windowState: 'normal' } }); await cdpSend('Browser.setWindowBounds', { windowId: wid, bounds: { left: 120, top: 80 } }).catch(() => {}); } catch (e) {}
  try { await cdpSend('Target.activateTarget', { targetId: T.targetId }); } catch (e) {}
}
async function cdpNew(url, o) {
  await cdpStart();
  const bg = !!(o.bg && !o.focused);
  const tp = { url: 'about:blank', newWindow: true, background: bg, width: o.width || 1180, height: o.height || 900 };
  // 3.34.1: 뒤에서 쓰는 창은 처음부터 최소화로 만들어요 (화면에 잠깐 떴다 사라지지 않게). 옛 브라우저는 이 옵션을 몰라서 그땐 만든 뒤 최소화해요.
  let targetId; try { ({ targetId } = await cdpSend('Target.createTarget', bg ? { ...tp, windowState: 'minimized' } : tp)); } catch (e) { ({ targetId } = await cdpSend('Target.createTarget', tp)); }
  const T = await cdpAttach(targetId); T.bg = bg;
  if (bg) { try { await cdpSend('Browser.setWindowBounds', { windowId: await cdpWin(T), bounds: { windowState: 'minimized' } }); } catch (e) {} }
  else { T.login = /kream\.co\.kr\/login/.test(url); await cdpFront(T); }
  T.status = 'loading'; T.dom = 0; await cdpSend('Page.navigate', { url }, T.sid);
  if (bg) hideTick().catch(() => {});
  cdpGc(T.id).catch(() => {});
  return T;
}
// 뒤에서 쓰는 창이 쌓이지 않게: 4분 넘게 안 쓴 창은 닫고, 뒤 창은 최대 8개
// 3.36.9: 3개 → 8개. 소싱 시세 조회가 KREAM 창 3개 + 수집 창 + 쿠폰·재고 창을 같이 써서, 3개면 쓰던 창이 닫혀 매번 새로 열었어요(검색 1번에 20초)
async function cdpGc(keep) {
  const now = Date.now(), L = [...CDP.tabs.values()].filter(T => T.bg && T.id !== keep && !T.busy);
  for (const T of L) if (now - T.use > 4 * 60000) await cdpClose(T.id).catch(() => {});
  const live = [...CDP.tabs.values()].filter(T => T.bg && T.id !== keep && !T.busy).sort((a, b) => a.use - b.use);
  while (live.length > 7) await cdpClose(live.shift().id).catch(() => {});
}
async function cdpClose(id) {
  const T = CDP.tabs.get(+id); if (!T) return true;
  CDP.tabs.delete(T.id); CDP.byTarget.delete(T.targetId);
  // 마지막 창을 닫으면 브라우저가 꺼져요 → 그럴 땐 빈 화면으로 바꾸고 최소화해요
  try { const { targetInfos } = await cdpSend('Target.getTargets'); const pages = targetInfos.filter(x => x.type === 'page'); if (pages.length <= 1) { await cdpSend('Page.navigate', { url: 'about:blank' }, T.sid).catch(() => {}); await cdpSend('Browser.setWindowBounds', { windowId: await cdpWin(T), bounds: { windowState: 'minimized' } }).catch(() => {}); await cdpSend('Target.detachFromTarget', { sessionId: T.sid }).catch(() => {}); return true; } } catch (e) {}
  await cdpSend('Target.closeTarget', { targetId: T.targetId }).catch(() => {});
  return true;
}
async function cdpEval(T, expr, world, ms) {
  const p = { expression: expr, awaitPromise: true, returnByValue: true, userGesture: true };
  if (world !== 'MAIN') {
    if (!T.kcCtx) { try { const { executionContextId } = await cdpSend('Page.createIsolatedWorld', { frameId: T.frameId, worldName: 'kc' }, T.sid); T.kcCtx = executionContextId; await cdpSend('Runtime.evaluate', { expression: cdpSources().iso, contextId: executionContextId }, T.sid); } catch (e) {} }
    if (T.kcCtx) p.contextId = T.kcCtx;
  }
  const r = await cdpSend('Runtime.evaluate', p, T.sid, ms || 120000);
  if (r.exceptionDetails) throw new Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description || r.exceptionDetails.text || '스크립트 오류').split('\n')[0]);
  return r.result ? r.result.value : undefined;
}
async function cdpWaitDoc(T, ms) { const end = Date.now() + (ms || 15000); while (Date.now() < end && T.status !== 'complete' && CDP.tabs.has(T.id)) await new Promise(r => setTimeout(r, 300)); }
const CDP_OPS = {
  ping: async () => ({ ver: 'cdp' }),
  setMode: async () => 'min',
  reload: async () => true,
  winCreate: async a => { const T = await cdpNew(a.url, a); return { winId: T.id, tabId: T.id }; },
  winGet: async a => { const T = cdpTab(a.id); let state = 'normal'; try { ({ bounds: { windowState: state } } = await cdpSend('Browser.getWindowBounds', { windowId: await cdpWin(T) })); } catch (e) {} return { focused: false, state }; },
  winUpdate: async a => { const T = cdpTab(a.id); const wid = await cdpWin(T); if (a.focused) { await cdpFront(T); } else if (a.state) await cdpSend('Browser.setWindowBounds', { windowId: wid, bounds: { windowState: a.state } }).catch(() => {}); return true; },
  winRemove: async a => cdpClose(a.id),
  tabGet: async a => { const T = cdpTab(a.id); return { url: T.url, status: T.status, dom: !!T.dom, windowId: T.id }; },
  tabUpdate: async a => { const T = cdpTab(a.id); if (a.url) { T.status = 'loading'; T.dom = 0; await cdpSend('Page.navigate', { url: a.url }, T.sid); } return true; },
  tabReload: async a => { const T = cdpTab(a.id); T.status = 'loading'; T.dom = 0; await cdpSend('Page.reload', { ignoreCache: !!a.bypassCache }, T.sid); return true; },
  tabCreate: async a => { const T = await cdpNew(a.url, { focused: true }); return { tabId: T.id, winId: T.id }; },
  send: async a => {
    const T = cdpTab(a.id);
    // 화면이 다 뜨기 전이면 연결 스크립트가 아직 없을 수 있어요 → 잠깐 기다려요 (확장의 '받는 쪽 없음'과 같은 효과)
    const expr = `new Promise(res => { const L = globalThis.__kcMsgL || []; if (!L.length) return res({ __kcNoRecv: 1 }); let done = false, async = false; const reply = v => { if (!done) { done = true; res(v === undefined ? null : v); } }; for (const f of L) { try { if (f(${JSON.stringify(a.msg)}, {}, reply) === true) async = true; } catch (e) {} } if (!async && !done) res(null); })`;
    for (let i = 0; ; i++) {
      const v = await cdpEval(T, expr, 'ISOLATED', 360000);
      if (!(v && v.__kcNoRecv)) return v;
      if (i >= 20) throw new Error('Could not establish connection. Receiving end does not exist.');
      await new Promise(r => setTimeout(r, 500)); T.kcCtx = 0;
    }
  },
  exec: async a => {
    const T = cdpTab(a.id), src = cdpSources().fn[a.name];
    if (!src) throw new Error('킥스캔에 없는 기능이에요: ' + a.name);
    return cdpEval(T, `(${src}).apply(null, ${JSON.stringify(a.args || [])})`, a.world === 'MAIN' ? 'MAIN' : 'ISOLATED');
  },
  probe: async a => {
    const T = await cdpNew(a.url, { bg: true, width: 1100, height: 800 });
    try { await cdpWaitDoc(T, 15000); await new Promise(r => setTimeout(r, 900)); const src = cdpSources().fn[a.name]; if (!src) return null; return await cdpEval(T, `(${src})()`, 'ISOLATED'); }
    finally { cdpClose(T.id).catch(() => {}); }
  }
};
async function cdpOp(op, args, ms) {
  const f = CDP_OPS[op]; if (!f) throw new Error('모르는 작업: ' + op);
  const a = args || {}; const T = a.id != null ? CDP.tabs.get(+a.id) : null;
  if (T && (op === 'send' || op === 'exec')) T.busy++;
  try {
    return await Promise.race([f(a), new Promise((_, rej) => setTimeout(() => rej(new Error('브라우저가 응답하지 않아요 (' + op + ')')), ms || 60000))]);
  } catch (e) { CDP.lastErr = e.message; throw e; }
  finally { if (T && (op === 'send' || op === 'exec')) { T.busy = Math.max(0, T.busy - 1); T.use = Date.now(); } }
}
setInterval(() => { if (cdpOpen()) cdpGc().catch(() => {}); }, 30000);
app.on('before-quit', () => { try { if (cdpOpen()) CDP.ws.send(JSON.stringify({ id: ++CDP.seq, method: 'Browser.close' })); } catch (e) {} });
function rcall(op, args, ms) {
  return new Promise((res, rej) => {
    const id = ++KB.seq;
    const t = setTimeout(() => { KB.pend.delete(id); KB.q = KB.q.filter(c => c.id !== id); rej(new Error('웨일이 응답하지 않아요 (' + op + ')')); }, ms || 60000);
    KB.pend.set(id, { res, rej, t }); KB.q.push({ id, op, args: args || {} }); kbFlush();
  });
}
async function rc(op, args, ms) { if (kreamMode() === 'cdp') return cdpOp(op, args, ms); await ensureWhale(); return rcall(op, args, ms); }
const fnName = f => (String(f || '').match(/^\s*(?:async\s+)?function\s*\*?\s*([\w$]+)/) || [])[1] || '';
// 기존 기능을 감싸서, 크림 주소·웨일 창이면 웨일로 보내요
{
  const W = { ...API.windows }, T = { ...API.tabs }, S = { ...API.scripting }, probe0 = API.app.probe;
  API.windows.create = async o => {
    if (!(o && isKreamUrl(o.url) && kreamViaWhale())) return W.create(o);
    const r = await rc('winCreate', { url: o.url, focused: !!o.focused, bg: !!o.background, width: o.width, height: o.height });
    return { id: RB + r.winId, tabs: [{ id: RB + r.tabId }], remote: true };
  };
  API.windows.get = async id => { if (!isRemote(id)) return W.get(id); const r = await rc('winGet', { id: id - RB }); return { id, focused: r.focused, state: r.state, remote: true }; };
  API.windows.update = async (id, o) => { if (!isRemote(id)) return W.update(id, o); await rc('winUpdate', { id: id - RB, focused: !!(o && o.focused), state: o && o.state }); return { id }; };
  API.windows.remove = async id => { if (!isRemote(id)) return W.remove(id); await rc('winRemove', { id: id - RB }); return true; };
  API.tabs.get = async id => { if (!isRemote(id)) return T.get(id); const r = await rc('tabGet', { id: id - RB }); return { id, url: r.url, status: r.status, dom: !!r.dom, windowId: RB + r.windowId, active: true, nav: null, remote: true }; };
  API.tabs.update = async (id, o) => { if (!isRemote(id)) return T.update(id, o); if (o && (o.url || o.muted !== undefined)) await rc('tabUpdate', { id: id - RB, url: o.url, muted: o.muted }); return { id }; };
  API.tabs.reload = async (id, o) => { if (!isRemote(id)) return T.reload(id, o); await rc('tabReload', { id: id - RB, bypassCache: !!(o && o.bypassCache) }); return true; };
  API.tabs.create = async o => {
    if (!(o && isKreamUrl(o.url) && kreamViaWhale())) return T.create(o);
    const r = await rc('tabCreate', { url: o.url });
    return { id: RB + r.tabId, windowId: RB + r.winId, remote: true };
  };
  API.tabs.sendMessage = async (id, msg) => { if (!isRemote(id)) return T.sendMessage(id, msg); return rc('send', { id: id - RB, msg }, 360000); };
  API.scripting.executeScript = async o => {
    const id = o.target && o.target.tabId;
    if (!isRemote(id)) return S.executeScript(o);
    const name = o.name || fnName(o.func);
    if (!name) throw new Error('웨일 창에서는 이름 있는 기능만 실행할 수 있어요');
    const r = await rc('exec', { id: id - RB, name, args: o.args || [], world: o.world || 'ISOLATED' }, 120000);
    return [{ result: r === undefined ? null : r }];
  };
  API.app.probe = async o => {
    if (!(o && isKreamUrl(o.url) && kreamViaWhale())) return probe0(o);
    try { return await rc('probe', { url: o.url, name: fnName(o.func) }, 40000); } catch (e) { return null; }
  };
  API.app.whale = async () => {
    if (kreamMode() === 'cdp') { const b = cdpBrowser(); return { via: 'cdp', browser: b, browserName: CDPB[b] || '브라우저', connected: cdpOpen(), ever: !!DATA.__cdpEver, have: { chrome: !!cdpPath('chrome'), edge: !!cdpPath('edge'), whale: !!cdpPath('whale') }, err: CDP.lastErr || '', folder: extDir() }; }
    const b = curBrowser(); return { via: kreamMode(), browser: b, browserName: BROWSERS[b], connected: whaleConnected(), ver: KB.ver, folder: extDir(), installed: !!whalePath(), have: { whale: !!browserPath('whale'), chrome: !!browserPath('chrome') }, ever: !!DATA.__extEver, other: KB.other && Date.now() - KB.other.t < 30000 ? BROWSERS[KB.other.b] : '', noKey: Date.now() - KB.noKey < 60000, oldExt: Date.now() - KB.oldLast < 30000 }; };
  API.app.browserSet = async b => {
    if (kreamMode() === 'cdp') { if (CDPB[b] && b !== cdpBrowser()) { DATA.__cdpB = b; saveSoon(); try { if (cdpOpen()) CDP.ws.close(); } catch (e) {} } return cdpBrowser(); }
    DATA.__browser = b === 'chrome' ? 'chrome' : 'whale'; DATA.__kreamMode = 'whale'; KB.last = 0; saveSoon(); return curBrowser(); };
  API.app.browserLaunch = async page => {
    if (kreamMode() === 'cdp') { if (page !== 'kream') return false; const T = await cdpNew('https://kream.co.kr/login', { focused: true }); try { const wid = await cdpWin(T); await cdpSend('Browser.setWindowBounds', { windowId: wid, bounds: { windowState: 'normal' } }); } catch (e) {} return true; }
    const b = curBrowser(), wp = browserPath(b); if (!wp) return false; const url = page === 'kream' ? 'https://kream.co.kr/login' : (b === 'chrome' ? 'chrome://extensions' : 'whale://extensions'); require('child_process').spawn(wp, [url], { detached: true, stdio: 'ignore' }).unref(); return true; };
  API.app.openExt = async u => { u = String(u || ''); if (!/^https:\/\/[^\s]+$/i.test(u)) throw new Error('https 주소만 열 수 있어요'); await shell.openExternal(u); return true; };   // 3.17.1 카카오 문의·이용권 구매는 평소 쓰는 브라우저로
  API.app.extPathCopy = async () => { copyExt(true); try { require('electron').clipboard.writeText(extDir()); } catch (e) {} return extDir(); };
  API.app.whaleSet = async via => { DATA.__kreamMode = ['cdp', 'whale', 'app'].includes(via) ? via : 'cdp'; saveSoon(); return kreamMode(); };
  API.app.whaleOpenFolder = async () => { copyExt(true); shell.openPath(extDir()); return extDir(); };
  API.app.whaleLaunch = async () => API.app.browserLaunch('extensions');
}
// 웨일 확장 파일을 '문서\크림스캐너 웨일 연결' 폴더에 두고, 새 버전이면 바꿔요 (웨일에 한 번만 '압축해제된 확장 프로그램'으로 올리면 돼요)
function extDir() { return process.env.KC_EXT_DIR || path.join(app.getPath('documents'), '크림스캐너 웨일 연결'); }
function copyExt(force) {
  try {
    const src = path.join(ROOT, 'whale-ext'); if (!fs.existsSync(path.join(src, 'manifest.json'))) return false;
    const dst = extDir(); const sv = JSON.parse(fs.readFileSync(path.join(src, 'manifest.json'), 'utf8')).version;
    let dv = ''; try { dv = JSON.parse(fs.readFileSync(path.join(dst, 'manifest.json'), 'utf8')).version; } catch (e) {}
    if (!force && dv === sv) return false;
    fs.mkdirSync(dst, { recursive: true }); fs.cpSync(src, dst, { recursive: true, force: true });
    // 3.34: 예전 버전이 넣어 둔 화면 파일은 지워요 (연결 확장에는 화면이 없어요)
    for (const f of ['app.html', 'app.css', 'app.js', 'xlsx.js', 'inv.js', 'auto.js', 'guide.js', 'buy.js', 'acct.js', 'abid.js', '사용법.txt', 'guide', 'fonts']) if (!fs.existsSync(path.join(src, f))) { try { fs.rmSync(path.join(dst, f), { recursive: true, force: true }); } catch (e) {} }
    kbWriteKey();
    return true;
  } catch (e) { console.error('웨일 확장 복사 실패', e); return false; }
}
// 웨일 확장이 옛 버전이면 새 파일로 다시 읽게 해요
kbWriteKey(); setInterval(kbWriteKey, 15000);
setInterval(() => { try { const mv = JSON.parse(fs.readFileSync(path.join(extDir(), 'manifest.json'), 'utf8')).version; if (KB.ver && mv && KB.ver !== mv && whaleConnected() && !KB.reloading) { KB.reloading = true; rcall('reload', {}, 5000).catch(() => {}).finally(() => setTimeout(() => { KB.reloading = false; }, 30000)); } } catch (e) {} }, 15000);
// 3.4.4: 사이트 화면이 비어서 나올 때 — 그 사이트의 서비스워커·캐시만 지워요 (로그인 쿠키는 그대로)
API.app.fixSite = async o => {
  const origin = typeof o === 'string' ? o : o && o.origin; const ses = prepShop(o && o.part);
  try { await ses.clearStorageData({ origin, storages: ['serviceworkers', 'cachestorage'] }); } catch (e) {}
  try { await ses.clearCache(); } catch (e) {}
  return true;
};
// 3.4.8: 쇼핑몰 창의 브라우저 정보(User-Agent)를 바꿔요 (빈 값이면 기본으로)
API.app.setUA = o => { const ua = (o && o.ua) || ''; if (ua) DATA.__shopUA = ua; else delete DATA.__shopUA; saveSoon(); for (const p of new Set([PART, ...prepped])) session.fromPartition(p).setUserAgent(ua || UA, 'ko-KR,ko,en-US,en'); return ua || UA; };
API.app.setSsrStrip = on => { DATA.__kreamSsrStrip = !!on; saveSoon(); return !!on; };
// ---------- 개선판 1-11: 실행 편의 · 휴가 모드 · 긴급 정지 ----------
// 상태는 저장소 'ops' 칸(화면과 같이 써요): { vac: 휴가 모드, halt: 긴급 정지, haltAt }
const opsSend = st => { for (const w of BrowserWindow.getAllWindows()) { try { if (!w.isDestroyed() && isAppUrl(w.webContents.getURL())) w.webContents.send('kc-ops', st); } catch (e) {} } };
// 작업 중 절전 막기: 화면이 '지금 자동 작업 중'이라고 알려 준 동안만 켜요
const BUSY = new Set(); let psbId = -1;
function psbSync() {
  const want = BUSY.size > 0 && DATA.__noSleep !== false && !(DATA.ops || {}).halt;
  if (want && psbId < 0) { try { psbId = powerSaveBlocker.start('prevent-app-suspension'); } catch (e) {} }
  else if (!want && psbId >= 0) { try { powerSaveBlocker.stop(psbId); } catch (e) {} psbId = -1; }
}
ipcMain.on('kc-busy', (e, on) => {
  const wc = e.sender, id = wc.id;
  if (on) { if (!BUSY.has(id)) { BUSY.add(id); wc.once('destroyed', () => { BUSY.delete(id); psbSync(); }); } } else BUSY.delete(id);
  psbSync();
});
API.app.opsGet = () => ({ autoStart: loginOn(), trayKeep: DATA.__trayKeep !== false, noSleep: DATA.__noSleep !== false, sleepBlocked: psbId >= 0 && powerSaveBlocker.isStarted(psbId),
  zoom: zoomF(), cdpShow: DATA.__cdpShow === true, idle: (() => { try { return powerMonitor.getSystemIdleTime(); } catch (e) { return -1; } })(), ops: DATA.ops || {} });
API.app.opsSet = o => {
  o = o || {};
  if ('autoStart' in o) app.setLoginItemSettings({ openAtLogin: !!o.autoStart, args: ['--hidden'] });
  if ('trayKeep' in o) DATA.__trayKeep = !!o.trayKeep;
  if ('noSleep' in o) { DATA.__noSleep = !!o.noSleep; psbSync(); }
  if ('zoom' in o) { DATA.__zoom = [0.9, 1, 1.1, 1.25].includes(+o.zoom) ? +o.zoom : 1; for (const w of BrowserWindow.getAllWindows()) { try { if (!w.isDestroyed() && isAppUrl(w.webContents.getURL())) w.webContents.setZoomFactor(zoomF()); } catch (e) {} } }
  if ('cdpShow' in o) { DATA.__cdpShow = !!o.cdpShow; if (o.cdpShow) { try { if (HIDE.ps && HIDE.ps.exitCode === null) HIDE.ps.stdin.write('show'+String.fromCharCode(10)); } catch (e) {} } }
  saveSoon(); trayMenu(); return API.app.opsGet();
};
API.app.idle = () => { try { return powerMonitor.getSystemIdleTime(); } catch (e) { return -1; } };
// 긴급 정지: 저장소에 먼저 적고(예약이 새로 시작되지 않게) → 작업 창 · 뒤에서 연 킥스캔 창 · 브라우저 작업 탭을 닫고 → 화면에 알려요
API.app.opsHalt = async () => {
  const t0 = Date.now();
  DATA.ops = { ...(DATA.ops || {}), halt: true, haltAt: t0 }; flush();
  let closed = 0;
  for (const w of BrowserWindow.getAllWindows()) {
    if (w.isDestroyed() || w === appWin) continue;
    try { w.destroy(); closed++; } catch (e) {}
  }
  try { KB.q.splice(0); } catch (e) {}
  try { for (const T of [...CDP.tabs.values()]) if (T.bg && !T.login) { closed++; cdpClose(T.id).catch(() => {}); } } catch (e) {}
  psbSync(); trayMenu(); opsSend(DATA.ops);
  return { ok: true, closed, ms: Date.now() - t0 };
};
API.app.opsResume = () => { DATA.ops = { ...(DATA.ops || {}), halt: false, haltAt: 0 }; saveSoon(); trayMenu(); opsSend(DATA.ops); return DATA.ops; };
API.app.opsVac = on => { DATA.ops = { ...(DATA.ops || {}), vac: !!on }; saveSoon(); trayMenu(); opsSend(DATA.ops); return DATA.ops; };
// 시험용: 지금 열린 창 수 (킥스캔 화면 창 · 그 밖의 작업 창)
// 11/22: 숨겨 둔 작업 창을 잠깐(기본 10초) 보여 줘요 — 설정 › 일반 › 작업용 크롬 [창 잠깐 보기]
API.app.opsPeek = (sec) => { HIDE.peekUntil = Date.now() + Math.min(60, +sec || 10) * 1000; hideSend('show'); HIDE.last = 'show'; return { until: HIDE.peekUntil, hidden: hideOn() }; };
API.app.traySt = (st) => {
  const o = st || {}, was = TRAY_ST.warn > 0;
  TRAY_ST = { warn: Math.max(0, +o.warn || 0), last: +o.last || 0, run: Array.isArray(o.run) ? o.run.map(String).slice(0, 4) : [] };
  try { if (tray) { if (was !== TRAY_ST.warn > 0) tray.setImage(trayImg(TRAY_ST.warn > 0)); tray.setToolTip(TRAY_ST.warn ? `킥스캔 — 확인할 항목 ${TRAY_ST.warn}개` : '킥스캔 — 정상 작동 중'); trayMenu(); } } catch (e) {}
  return true;
};
API.app.opsWins = () => { let app0 = 0, work = 0; for (const w of BrowserWindow.getAllWindows()) { if (w.isDestroyed()) continue; try { if (isAppUrl(w.webContents.getURL())) app0++; else work++; } catch (e) { work++; } } return { app: app0, work, cdp: CDP.tabs.size }; };
API.app.checkUpdate = () => checkUpdate(true);
API.app.updateState = () => updState;
API.app.restartNow = () => { setTimeout(restartForUpdate, 300); return true; };
API.app.openInstaller = url => { shell.openExternal(url || 'https://github.com/chldydrnr2-eng/kream-scanner/tree/main/updates'); return true; };

// ---------- 시작 ----------
app.on('second-instance', () => showMain());
app.on('activate', () => showMain());   // 맥: Dock 아이콘을 누르면 다시 열기
app.on('before-quit', () => { quitting = true; flush(); for (const p of new Set([PART, ...prepped])) try { session.fromPartition(p).cookies.flushStore(); } catch (e) {} });
app.on('window-all-closed', () => { /* 트레이에 남아요 */ });
// 3.36.1: 예전 설치 파일(크림스캐너)로 설치한 PC도 바탕화면 · 시작 메뉴 바로가기와 '앱 목록' 이름을 킥스캔 · KS 아이콘으로 바꿔요
//         (프로그램 파일 자체의 아이콘은 새 설치 파일로 설치해야 바뀌어요)
function fixWinBrand() {
  if (process.platform !== 'win32' || !app.isPackaged) return;
  const exe = process.execPath, low = s => String(s || '').toLowerCase();
  const icoSrc = path.join(ROOT, 'icons', 'app.ico'), ico = path.join(app.getPath('userData'), 'kickscan.ico');
  try { if (fs.existsSync(icoSrc) && (!fs.existsSync(ico) || fs.statSync(ico).size !== fs.statSync(icoSrc).size)) fs.copyFileSync(icoSrc, ico); } catch (e) {}
  if (!fs.existsSync(ico)) return;
  const appData = app.getPath('appData');
  const dirs = [[app.getPath('desktop'), true], [path.join(appData, 'Microsoft', 'Windows', 'Start Menu', 'Programs'), true], [path.join(appData, 'Microsoft', 'Internet Explorer', 'Quick Launch', 'User Pinned', 'TaskBar'), false]];
  for (const [dir, rename] of dirs) {
    let list = []; try { list = fs.readdirSync(dir).filter(f => /\.lnk$/i.test(f)); } catch (e) { continue; }
    for (const f of list) {
      const p = path.join(dir, f); let l; try { l = shell.readShortcutLink(p); } catch (e) { continue; }
      if (low(l.target) !== low(exe)) continue;
      const opt = { target: exe, cwd: l.cwd || path.dirname(exe), args: l.args || '', description: '킥스캔', icon: ico, iconIndex: 0, appUserModelId: 'com.kreamscanner.app' };
      try {
        if (rename && f !== '킥스캔.lnk') { const np = path.join(dir, '킥스캔.lnk'); if (shell.writeShortcutLink(np, fs.existsSync(np) ? 'replace' : 'create', opt)) fs.unlinkSync(p); }
        else if (low(l.icon) !== low(ico)) shell.writeShortcutLink(p, 'update', { icon: ico, iconIndex: 0, description: '킥스캔' });   // 작업 표시줄 고정은 이름을 바꾸면 고정이 풀려서 아이콘만
      } catch (e) {}
    }
  }
  // 설정 > 앱 목록에 보이는 이름 · 아이콘 (이 PC 사용자 영역의 우리 설치 정보만)
  // reg 출력은 한글이 깨져 읽혀서, 한 번 바꿨으면 표시 파일(brand-fixed.txt)로 다시 안 해요
  const mark = path.join(app.getPath('userData'), 'brand-fixed.txt');
  try {
    if (fs.existsSync(mark) && fs.readFileSync(mark, 'utf8') === exe) return;
    const cp = require('child_process'), K = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\8bea58d5-8f6a-5565-97f6-aadc195df051';
    const q = cp.spawnSync('reg', ['query', K], { encoding: 'utf8', windowsHide: true });
    if (q.status === 0 && low(q.stdout).includes(low(path.dirname(exe)))) {
      fs.writeFileSync(mark, exe);
      const ver = (q.stdout.match(/DisplayVersion\s+REG_SZ\s+(\S+)/) || [])[1] || app.getVersion();
      cp.spawnSync('reg', ['add', K, '/v', 'DisplayName', '/t', 'REG_SZ', '/d', '킥스캔 ' + ver, '/f'], { windowsHide: true });
      cp.spawnSync('reg', ['add', K, '/v', 'DisplayIcon', '/t', 'REG_SZ', '/d', ico, '/f'], { windowsHide: true });
      cp.spawnSync('reg', ['add', K, '/v', 'Publisher', '/t', 'REG_SZ', '/d', '킥스캔', '/f'], { windowsHide: true });
    }
  } catch (e) {}
}
app.whenReady().then(() => {
  loadData();
  setTimeout(fixWinBrand, 8000);
  const shop = prepShop(PART);
  for (const p of DATA.__parts || []) try { prepShop(p); } catch (e) {}   // 다른 아이디 저장 공간도 만료 토큰 정리·로그인 유지
  try { kbServer(); copyExt(false); } catch (e) {}
  // 3.4.9: 로그인한 상태로 크림 상품 화면을 열면 크림 서버가 10초 뒤 빈 오류(500)를 줘요(이 PC·계정에서 확인).
  //        상품 화면 '문서' 요청에만 로그인 쿠키를 빼서 화면은 정상으로 받고, 거래 내역 등은 화면이 로그인 정보로 따로 불러와요.
  shop.webRequest.onBeforeSendHeaders({ urls: ['https://kream.co.kr/products/*'] }, (d, cb) => {
    try {
      if (d.resourceType === 'mainFrame' && DATA.__kreamSsrStrip === true) {   // 3.5.0: 기본은 끔 (상품 화면도 로그인 상태로)
        const h = d.requestHeaders; const k = Object.keys(h).find(x => x.toLowerCase() === 'cookie');
        if (k) { const kept = h[k].split(/;\s*/).filter(c => !/^(_token\.|_refresh_token\.|strategy=|login_type=|ticketExpire=)/.test(c)); if (kept.length) h[k] = kept.join('; '); else delete h[k]; }
        return cb({ requestHeaders: h });
      }
    } catch (e) {}
    cb({});
  });
  try {
    tray = new Tray(trayImg(false));
    tray.setToolTip('킥스캔');
    const ago = t => { if (!t) return '–'; const m = Math.floor((Date.now() - t) / 60e3); return m < 1 ? '방금' : m < 60 ? m + '분 전' : m < 1440 ? Math.floor(m / 60) + '시간 전' : Math.floor(m / 1440) + '일 전'; };
    const menu = () => Menu.buildFromTemplate([
      // 11/22 줍픽 트레이 작은 창: 정상 작동 중 / 확인할 항목 · 마지막 갱신 · 진행 중 작업 · 업데이트 [지금 적용]
      { label: TRAY_ST.warn ? `확인할 항목이 있어요 (${TRAY_ST.warn})` : '정상 작동 중이에요', enabled: false },
      { label: `마지막 갱신 ${ago(TRAY_ST.last)}`, enabled: false },
      { label: TRAY_ST.run && TRAY_ST.run.length ? `진행 중: ${TRAY_ST.run.slice(0, 2).join(' · ')}` : '진행 중인 작업 없음', enabled: false },
      ...(updState && updState.state === 'ready' ? [{ label: `업데이트 ${updState.version} — 지금 적용`, click: () => restartForUpdate() }] : []),
      { type: 'separator' },
      { label: '킥스캔 열기', click: showMain },
      { label: 'Windows 시작할 때 실행', type: 'checkbox', checked: loginOn(), click: it => app.setLoginItemSettings({ openAtLogin: it.checked, args: ['--hidden'] }) },
      { type: 'separator' },
      (DATA.ops || {}).halt ? { label: '자동 작업 다시 시작', click: () => API.app.opsResume() } : { label: '긴급 정지 (모든 자동 작업 멈춤)', click: () => API.app.opsHalt() },
      { type: 'separator' },
      { label: '종료', click: () => { quitting = true; app.quit(); } }
    ]);
    trayMenu = () => { try { tray.setContextMenu(menu()); } catch (e) {} };
    tray.setContextMenu(menu()); tray.on('click', showMain);
  } catch (e) {}
  alarmsRestore();
  setTimeout(() => checkUpdate(false), 8000); setInterval(() => checkUpdate(false), 6 * 3600000);
  if (!process.argv.includes('--hidden')) showMain();
  else { appWin = createAppWin('', false); appWin.on('close', onMainClose); }
});

};
