// 매입처 검색 결과 페이지에서 상품 카드 읽기 — chrome.scripting.executeScript로 주입 (이 함수 하나만 페이지에서 실행됨)
// 사이트마다 구조가 달라서 '사진 + 가격이 같이 들어 있는 가장 작은 덩어리'를 상품 카드로 봄.
function kcFind(opt) {
  const priceRe = /(\d{1,3}(?:,\d{3})+)\s*원?/g;
  const hasPrice = t => /\d{1,3}(?:,\d{3})+/.test(t);
  const bodyText = (document.body && document.body.innerText) || '';
  const noResult = /검색\s*결과가\s*없|결과가\s*없습니다|찾으시는\s*상품이\s*없|검색된\s*상품이\s*없|일치하는\s*상품이\s*없|총\s*0\s*(건|개)|0개의 상품/.test(bodyText);
  const seen = new Set(), bad = new Set(), cards = [];
  const PROD = /product|goods|item|catalog|\/p\/|\/t\/|\/pd\/|\.html|detail|prdtNo|itemId/i;
  // 여러 상품이 한 덩어리로 잡히면(가격이 사진 밖에 있는 사이트) 상품명과 가격이 섞이니까 버림
  const multi = el => {
    const ids = new Set([...el.querySelectorAll('a[href]')].filter(a => /^https?:/.test(a.href) && PROD.test(a.pathname + a.search) && !/search/i.test(a.pathname)).map(a => a.pathname + a.search.replace(/[?&](utm|ref|tr|src|area|click)[^&]*/g, '')));
    const imgs = [...el.querySelectorAll('img')].filter(i => i.getBoundingClientRect().width >= 60).length;
    return ids.size > 1 || imgs > 3;
  };
  const pick = el => {
    if (!el || seen.has(el)) return;
    if (bad.has(el)) return;
    if (multi(el)) { bad.add(el); return; }
    for (const s of seen) if (s.contains(el) || el.contains(s)) return;   // 겹치는 덩어리는 하나만
    seen.add(el);
    const raw = el.innerText || '';
    const text = raw.replace(/\s+/g, ' ').trim();
    // 카드 결제 예상가·적립금·보상금 같은 숫자는 판매가가 아니라서 빼고 계산
    const priceText = text.replace(/(예상가|결제\s*시|적립금?|보상|포인트|쿠폰\s*적용가?)[^\d]{0,12}\d{1,3}(?:,\d{3})+\s*원?/g, ' ');
    const nums = [...priceText.matchAll(priceRe)].map(m => +m[1].replace(/,/g, '')).filter(n => n >= 10000 && n < 20000000);
    const links = [...el.querySelectorAll('a[href]')].concat(el.closest('a[href]') ? [el.closest('a[href]')] : []).filter(x => /^https?:/.test(x.href));
    const a = links.find(x => /product|goods|item|catalog|\/p\/|\/t\/|\/pd\/|\.html|detail/i.test(x.pathname) && !/search/i.test(x.pathname));
    // 검색어가 붙은 주소(?keyword=)는 빼고 경로만 + 판매처 구분 값(siteNo 등)
    const hrefs = links.map(x => { let s = decodeURIComponent(x.pathname); for (const k of ['siteNo', 'mall_no', 'salestrNo']) { let v = ''; try { v = new URL(x.href).searchParams.get(k); } catch (e) {} if (v) s += ` ${k}=${v}`; } return s; }).join(' ').slice(0, 600);
    const img = el.querySelector('img');
    cards.push({ text: text.slice(0, 500), hrefs, url: a ? a.href.split('#')[0] : '', price: nums.length ? Math.min(...nums) : null,
      soldOut: /품절|sold\s?out|재고\s*없음|일시\s*품절/i.test(text), alt: img ? (img.alt || '').slice(0, 140) : '' });
  };
  for (const img of document.querySelectorAll('img')) {
    const r = img.getBoundingClientRect();
    if (r.width && r.width < 60) continue;   // 아이콘·로고 제외
    let e = img.parentElement;
    for (let i = 0; i < 9 && e && e !== document.body; i++) {
      const t = e.innerText || '';
      if (t.length > 900) break;
      if (hasPrice(t) && t.replace(/\s+/g, '').length > 8) { pick(e); break; }
      e = e.parentElement;
    }
    if (cards.length >= (opt && opt.max || 40)) break;
  }
  // 상품 상세로 바로 넘어간 경우(모델번호가 딱 맞으면 바로 상세로 가는 사이트가 있음)
  let page = null;
  const og = n => { const m = document.querySelector(`meta[property="${n}"]`); return m ? m.content : ''; };
  const h1 = document.querySelector('h1');
  const priceMeta = og('product:price:amount') || og('og:price:amount');
  const path = decodeURIComponent(location.pathname);
  page = { path, title: (og('og:title') || (h1 && h1.innerText) || document.title || '').slice(0, 160), price: priceMeta ? Math.round(+priceMeta) : null,
    text: ((h1 && h1.closest('section,main,div') || document.body).innerText || '').replace(/\s+/g, ' ').slice(0, 1500) };
  return { url: location.href, cards, noResult, page, ready: document.readyState };
}

// 크림 SHOP 목록(카테고리·인기순)에서 상품 카드 읽기 — 아래로 내리면서 max개까지
async function kcList(max) {
  const num = s => { const m = String(s || '').replace(/,/g, '').match(/([\d.]+)\s*(만|천)?/); return m ? Math.round(+m[1] * (m[2] === '만' ? 1e4 : m[2] === '천' ? 1e3 : 1)) : 0; };
  const read = () => {
    const out = new Map();
    for (const a of document.querySelectorAll('a[href*="/products/"]')) {
      const pid = (a.href.match(/products\/(\d+)/) || [])[1];
      if (!pid || out.has(pid)) continue;
      const t = (a.innerText || '').replace(/\s+/g, ' ').trim();
      if (!t || !/원/.test(t)) continue;
      const pr = (t.match(/([\d,]{4,})원/) || [])[1];
      const name = t.split(/\s[+-]?\d{1,3}%\s|\s[\d,]{4,}원/)[0].trim();
      const img = a.querySelector('img');
      out.set(pid, { pid, name: name.slice(0, 120), price: pr ? +pr.replace(/,/g, '') : null,
        trades: num((t.match(/거래\s*([\d.,]+\s*(만|천)?)/) || [])[1]), wish: num((t.match(/관심\s*([\d.,]+\s*(만|천)?)/) || [])[1]),
        fast: /빠른배송/.test(t), img: img ? img.currentSrc || img.src : '' });
    }
    return [...out.values()];
  };
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const none = () => /검색\s*결과가\s*없|결과가\s*없습니다|검색된\s*상품이\s*없/.test((document.body && document.body.innerText) || '');
  for (let i = 0; i < 20 && !read().length && !(i > 3 && none()); i++) await wait(500);
  let last = -1, same = 0;
  for (let i = 0; i < 40; i++) {
    const n = read().length;
    if (n >= max) break;
    if (n === last) { if (++same >= 4) break; } else same = 0;
    last = n;
    window.scrollTo(0, document.body.scrollHeight);
    await wait(900);
  }
  return read().slice(0, max);
}

// 무신사 주문 내역 읽기 — 아래로 내리면서 days일 전 주문까지
async function kcMusinsaOrders(days) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const cutoff = Date.now() - (days || 90) * 864e5;
  const toDate = s => { const m = String(s).match(/(\d{2})\.(\d{1,2})\.(\d{1,2})/); return m ? `20${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}` : ''; };
  const read = () => {
    const out = [];
    for (const a of document.querySelectorAll('a[href*="/order/order-detail/"]')) {
      const no = a.href.split('/').pop().split('?')[0];
      const title = a.closest('[class*="TitleSection"]');
      const g = title ? title.parentElement : a.parentElement;
      const lines = (g.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
      const date = toDate(lines.find(l => /^\d{2}\.\d{1,2}\.\d{1,2}/.test(l)) || '');
      const status = lines.find(l => /(준비|배송|완료|취소|반품|교환|확정|입금|결제)/.test(l) && !/주문 상세|요청|상세$/.test(l)) || '';
      const prods = [...new Set([...g.querySelectorAll('a[href*="/products/"]')].map(x => (x.href.match(/products\/(\d+)/) || [])[1]).filter(Boolean))];
      const items = [];
      lines.forEach((l, i) => {
        const m = l.match(/^(.*?)\s*\/\s*(\d+)개$/);
        if (!m) return;
        const price = +(lines.slice(i + 1, i + 3).find(x => /^[\d,]+원$/.test(x)) || '0').replace(/[^\d]/g, '');
        items.push({ brand: lines[i - 2] || '', name: lines[i - 1] || '', option: m[1], qty: +m[2], total: price, mid: prods[items.length] || prods[0] || '' });
      });
      out.push({ no, date, status, items });
    }
    return out;
  };
  let last = -1, same = 0;
  for (let i = 0; i < 60; i++) {
    const list = read();
    const oldest = list.length ? list[list.length - 1].date : '';
    if (oldest && new Date(oldest).getTime() < cutoff) break;
    if (list.length === last) { if (++same >= 4) break; } else same = 0;
    last = list.length;
    window.scrollTo(0, document.body.scrollHeight);
    await wait(1000);
  }
  return read().filter(o => !o.date || new Date(o.date).getTime() >= cutoff);
}

// 2.6.3: 무신사 상품번호 → 품번(styleNo). 주문 목록 상품명엔 품번이 없는 경우가 많아서 상품 정보를 따로 읽어요 (2026-11-12 확인)
async function kcMsStyles(ids) {
  const out = {};
  for (const id of ids || []) {
    try { const j = await (await fetch('https://goods-detail.musinsa.com/api2/goods/' + id, { credentials: 'include' })).json(); const d = (j && j.data) || {}; out[id] = String(d.styleNo || '').trim(); } catch (e) {}
  }
  return out;
}

// 무신사 랭킹 읽기 — 카테고리 탭을 누르고, 화면이 바뀌며 지워지는 목록을 내려가면서 모음
async function kcMusinsaRank(cat, max) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  if (cat) {
    const el = [...document.querySelectorAll('button')].find(x => (x.innerText || '').trim() === cat);
    if (el) { el.click(); await wait(2500); }
  }
  window.scrollTo(0, 0); await wait(800);
  const got = new Map();
  const grab = () => {
    for (const a of document.querySelectorAll('a[href*="/products/"]')) {
      const id = (a.href.match(/products\/(\d+)/) || [])[1];
      if (!id || got.has(id)) continue;
      let e = a; for (let k = 0; k < 6 && e && !/\d{1,3},\d{3}/.test(e.innerText || ''); k++) e = e.parentElement;
      const t = ((e || a).innerText || '').replace(/\s+/g, ' ').trim();
      const pr = (t.match(/([\d,]{4,})원/) || [])[1];
      if (!pr) continue;
      const img = (e || a).querySelector('img');
      got.set(id, { mid: id, text: t.slice(0, 200), price: +pr.replace(/,/g, ''), rank: +((t.match(/^(\d+)\s/) || [])[1] || 0), img: img ? img.currentSrc || img.src : '' });
    }
  };
  let stuck = 0, lastY = -1;
  for (let i = 0; i < 80 && got.size < max; i++) {
    grab();
    window.scrollBy(0, Math.round(innerHeight * 0.8)); await wait(700);
    if (scrollY === lastY) { if (++stuck >= 3) break; } else stuck = 0;
    lastY = scrollY;
  }
  grab();
  return [...got.values()].slice(0, max);
}

// ---------- 2.3: 포이즌 상품 페이지 사이즈별 가격 (kr.poizon.com/product/…) ----------
// 화면 글자에서 "사이즈: KR / 사이즈 가이드" 다음에 나오는 "사이즈 줄 → 가격 줄"을 읽어요. (2026-11 확인)
async function kcPoizon() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 20 && !/사이즈:\s*\S+\s*\n/.test(document.body.innerText); i++) await wait(400);
  const t = document.body.innerText;
  // 리뷰에도 '사이즈: KR 280' 같은 글이 있어서, 바로 다음 줄이 '사이즈 가이드'인 곳(구매 사이즈 고르는 칸)을 찾아요
  let i = t.search(/사이즈:\s*\S+\s*\n\s*사이즈 가이드/);
  if (i < 0) i = t.lastIndexOf('사이즈:');
  const sizes = [];
  if (i >= 0) {
    const lines = t.slice(i).split('\n').map(s => s.trim()).filter(Boolean).slice(0, 160);
    for (let k = 1; k < lines.length - 1; k++) {
      if (/^(발 길이|구매\s|관련 추천|정 사이즈)/.test(lines[k])) break;
      const pm = lines[k + 1].match(/^([\d,]+|--)\s*원$/);
      if (!pm || /원$/.test(lines[k]) || lines[k] === '사이즈 가이드' || lines[k].length > 24 || !/^[\dA-Z]/i.test(lines[k])) continue;
      sizes.push({ label: lines[k], kr: (lines[k].match(/^[\dA-Z.]+/i) || [lines[k]])[0], price: pm[1] === '--' ? null : +pm[1].replace(/,/g, '') });
      k++;
    }
  }
  const og = document.querySelector('meta[property="og:title"]');
  return { url: location.href, title: document.title, name: og ? og.content : '', sizes };
}
function kcPoizonLinks() {
  return [...document.querySelectorAll('a[href*="/product/"]')].map(a => ({ url: a.href.split('?')[0], text: (a.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 140) })).filter((x, i, arr) => x.text && arr.findIndex(y => y.url === x.url) === i).slice(0, 8);
}

// ---------- 2.3: 무신사 상품 사이즈별 재고·가격 (무신사 화면이 쓰는 주소, 2026-11 확인) ----------
async function kcMsStock(goodsNo) {
  const api = 'https://goods-detail.musinsa.com/api2/goods/' + goodsNo;
  const o = await (await fetch(api + '/options?goodsSaleType=SALE', { credentials: 'include' })).json();
  const d = o && o.data; if (!d) throw new Error('옵션을 못 읽었어요');
  const vals = (d.basic || []).flatMap(b => (b.optionValues || []).filter(v => !v.isDeleted).map(v => v.no));
  const inv = await (await fetch(api + '/options/v2/prioritized-inventories', { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ optionValueNos: vals }) })).json();
  const names = {}; for (const it of d.optionItems || []) if (!it.isDeleted) names[it.no] = { label: (it.optionValues || []).map(v => v.name).join(' / '), size: ((it.optionValues || []).slice(-1)[0] || {}).name || '', active: it.activated, extra: it.price || 0 };
  const sizes = ((inv && inv.data) || []).map(x => { const n = names[x.productVariantId] || {}; const dd = x.domesticDelivery || {}; return { id: x.productVariantId, label: n.label || String(x.productVariantId), size: n.size, out: !!x.outOfStock || n.active === false, qty: x.remainQuantity, extra: n.extra || 0, ship: dd.deliveryType || '', release: dd.willReleaseDate || '' }; });
  let meta = {};
  try { const nd = document.getElementById('__NEXT_DATA__'); const g = JSON.parse(nd.textContent).props.pageProps.meta.data; meta = { name: g.goodsNm, brand: g.brandInfo && (g.brandInfo.brandName || g.brandInfo.brand), price: g.goodsPrice, img: g.thumbnailImageUrl }; } catch (e) {}
  if (!meta.name) { const og = document.querySelector('meta[property="og:title"]'); meta.name = og ? og.content : document.title; }
  // 3.8.0: 주문 가능 수량 — 무신사는 남은 수량을 5개 이하일 때만 알려줘요(그 위는 '6개 이상'). 1회·아이디당 구매 제한도 같이 읽어요.
  let lim = {};
  try { const g = (await (await fetch(api, { credentials: 'include' })).json()).data || {}; const cap = [g.orderMaxQuantity, g.isLimitedQuantity || (g.limitScope && g.limitScope !== 'NONE') ? g.limitedMaxQuantity : 0].filter(v => v > 0 && v < 999); lim = { maxOrder: cap.length ? Math.min(...cap) : null, maxScope: g.limitScope && g.limitScope !== 'NONE' && g.limitScope !== 'PER_ORDER' ? 'id' : 'order' }; if (!meta.name && g.goodsNm) meta.name = g.goodsNm; } catch (e) {}
  for (const x of sizes) if (!x.out && x.qty == null) x.min = 6;
  return { site: 'musinsa', goodsNo: String(goodsNo), url: 'https://www.musinsa.com/products/' + goodsNo, ...meta, ...lim, sizes };
}
// ---------- 3.8.0: 지그재그 상품 옵션별 재고 (지그재그 화면이 쓰는 주소, 2026-11 확인) ----------
// 남은 수량은 적을 때만 숫자로 와요(많으면 비어 있음 = 넉넉함)
async function kcZzStock(id) {
  const q = `query GetCatalogProductDetailPageOption { pdp_option_info(catalog_product_id: "${String(id).replace(/\D/g, '')}") { catalog_product { id name shop_name maximum_order_quantity product_price { final_price } item_list { id name price final_price sales_status display_status remain_stock is_zigzin } } } }`;
  const r = await fetch('https://api.zigzag.kr/api/2/graphql/GetCatalogProductDetailPageOption', { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ query: q }) });
  const j = await r.json();
  const p = j && j.data && j.data.pdp_option_info && j.data.pdp_option_info.catalog_product;
  if (!p) throw new Error('지그재그 옵션을 못 읽었어요');
  const sizes = (p.item_list || []).filter(x => x.display_status !== 'HIDDEN').map(x => {
    const out = x.sales_status !== 'ON_SALE' || x.remain_stock === 0;
    return { id: x.id, label: x.name, size: String(x.name || '').split('/').pop().trim(), out, qty: out ? 0 : x.remain_stock ?? null, price: x.final_price || x.price || null, ship: x.is_zigzin ? '직진배송' : '' };
  });
  const mo = p.maximum_order_quantity;
  return { site: 'zigzag', goodsNo: String(p.id), url: 'https://zigzag.kr/catalog/products/' + p.id, name: p.name, brand: p.shop_name, price: { salePrice: p.product_price && p.product_price.final_price }, maxOrder: mo > 0 && mo < 999 ? mo : null, maxScope: 'order', sizes };
}
// ---------- 3.8.0: ABC마트·그랜드스테이지 상품 사이즈별 재고 (상품 화면에 들어 있는 재고 수량) ----------
async function kcArtStock(no) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const pick = () => [...document.querySelectorAll(`[data-product-option-name][data-product-no="${no}"]`)].filter(e => !/relation/.test(e.className || ''));
  for (let i = 0; i < 30 && !pick().length; i++) await wait(400);
  const els = pick(); if (!els.length) throw new Error('사이즈 정보를 못 찾았어요');
  const A = (e, k) => e.getAttribute('data-product-' + k);
  const seen = new Set(), sizes = [];
  for (const e of els) {
    const k = A(e, 'option-no') + '|' + A(e, 'option-name'); if (seen.has(k)) continue; seen.add(k);
    const q = +A(e, 'option-quantity'), mg = A(e, 'stock-mgmt-yn') !== 'N';
    const qty = !mg || q >= 9999 ? null : Math.max(0, q || 0);
    sizes.push({ id: A(e, 'option-no'), label: A(e, 'option-name'), size: A(e, 'option-name'), out: qty === 0, qty, extra: +A(e, 'option-price') || 0 });
  }
  const e0 = els[0], mx = +A(e0, 'max-buy-psblt-qty');
  return { site: 'abc', goodsNo: String(no), url: location.origin + '/product/new?prdtNo=' + no, name: A(e0, 'name') || document.title.split(' - ')[0], brand: A(e0, 'brand-name'), price: { salePrice: +A(e0, 'price') || null, normalPrice: +A(e0, 'normal-amt') || null }, maxOrder: A(e0, 'buy-limit-yn') === 'Y' && mx > 0 ? mx : null, maxScope: 'id', sizes };
}
// 3.8.0: 지그재그·ABC 검색 결과에서 상품 번호 모으기
async function kcShopSearch(site, max) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const re = site === 'zigzag' ? /\/catalog\/products\/(\d+)/ : /prdtNo=(\d{6,})|goProductDetail\('?(\d{6,})/;
  const links = () => [...document.querySelectorAll('a,[onclick]')].filter(a => re.test((a.getAttribute('href') || '') + (a.getAttribute('onclick') || '')));
  for (let i = 0; i < 20 && !links().length; i++) await wait(400);
  window.scrollTo(0, 2500); await wait(1200); window.scrollTo(0, 0);
  const out = new Map();
  // 상품 칸: 링크에서 위로 올라가며 가격(1,234)이 같이 보이는 첫 묶음
  const card = a => { let e = a; for (let i = 0; i < 7 && e; i++, e = e.parentElement) { const t = (e.innerText || '').replace(/\s+/g, ' ').trim(); if (/\d{1,3}(,\d{3})+/.test(t) && t.length > 8) return t; } return ''; };
  for (const a of links()) {
    const m = ((a.getAttribute('href') || '') + (a.getAttribute('onclick') || '')).match(re); const no = m && (m[1] || m[2]); if (!no) continue;
    const t = card(a);
    const cur = out.get(no) || { no, text: '' };
    if (t.length > cur.text.length) cur.text = t.slice(0, 160);
    out.set(no, cur);
  }
  return [...out.values()].filter(x => x.text).slice(0, max || 12).map(x => ({ ...x, url: site === 'zigzag' ? 'https://zigzag.kr/catalog/products/' + x.no : location.origin + '/product/new?prdtNo=' + x.no }));
}
async function kcMsSearch(max) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 16 && !document.querySelector('a[href*="/products/"]'); i++) await wait(400);
  await wait(800);
  const out = new Map();
  for (const a of document.querySelectorAll('a[href*="/products/"]')) {
    const no = (a.href.match(/products\/(\d+)/) || [])[1]; if (!no) continue;
    const box = a.closest('li,article,[class*=item],[class*=Item]') || a.parentElement;
    const t = (box ? box.innerText : a.innerText || '').replace(/\s+/g, ' ').trim();
    const cur = out.get(no) || { no, text: '' };
    if (t.length > cur.text.length) cur.text = t.slice(0, 160);
    const img = (box || a).querySelector('img'); if (img && !cur.img) cur.img = img.currentSrc || img.src;
    out.set(no, cur);
  }
  return [...out.values()].filter(x => x.text).slice(0, max || 12).map(x => ({ ...x, price: +((x.text.match(/([\d,]{4,})원/) || [])[1] || '0').replace(/,/g, '') || null }));
}

// ---------- 2.3: 크림 마이페이지 탭 돌기 (판매/구매/보관 내역) ----------
// 데이터는 hook-my.js 가 페이지 응답을 받아 적어요. 여기서는 탭을 차례로 누르고 아래로 내려서 다 불러오게만 해요.
async function kcKreamWalk(labels) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  await wait(1500);
  const done = [];
  const scrollAll = async () => { let h = 0; for (let i = 0; i < 12; i++) { window.scrollTo(0, document.body.scrollHeight); await wait(700); if (document.body.scrollHeight === h) break; h = document.body.scrollHeight; } };
  await scrollAll();
  for (const lb of labels || []) {
    const el = [...document.querySelectorAll('a,button,li,[role=tab]')].find(e => e.children.length < 6 && (e.innerText || '').replace(/\s+/g, ' ').trim().startsWith(lb));
    if (!el) continue;
    el.click(); done.push(lb); await wait(1800); await scrollAll();
  }
  return { url: location.href, done, text: document.body.innerText.slice(0, 3000) };
}

// ---------- 2.3.1: 무신사 '작성 가능한 후기' (무신사 후기 화면이 쓰는 주소, 2026-11 확인) ----------
async function kcMsReviews(from, to) {
  const base = 'https://goods.musinsa.com/api2/review/v1/mypage';
  const cnt = await (await fetch(base + '/reviews/status-count', { credentials: 'include' })).json();
  const list = [];
  for (let page = 1; page <= 10; page++) {
    const j = await (await fetch(`${base}/orders?page=${page}&size=20&searchFromYmd=${from}&searchToYmd=${to}&timestamp=${Date.now()}`, { credentials: 'include' })).json();
    const d = (j && j.data) || {};
    list.push(...(d.list || []));
    if (!d.hasNextPage) break;
  }
  return { count: cnt && cnt.data, list, login: !/로그인 \/ 회원가입/.test(document.body.innerText) };
}

// ---------- 2.4: 구매처 주문 내역 읽기 (여러 쇼핑몰 공통) ----------
// 주문 내역 화면에서 '상품 사진 + 가격'이 같이 있는 가장 작은 덩어리를 상품 한 줄로 보고,
// 그 안이나 위쪽 묶음에서 주문일·상태·수량·옵션·주문번호를 찾아요. 사이트마다 화면이 달라서 결과는 미리보기에서 확인해요.
async function kcOrders(opt) {
  opt = opt || {};
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const DATE = /(20\d\d|(?<![\d,])\d\d)\s*[.\-\/년]\s*(\d{1,2})\s*[.\-\/월]\s*(\d{1,2})(?![\d,])/;   // 2026.11.11 · 26.11.11 · 2026년 11월 11일
  const PRICE = /([\d]{1,3}(?:,\d{3})+|\d{4,})\s*원/g;
  const STATUS = /(취소\s*(처리\s*)?중|결제\s*취소|반품\s*(처리\s*|진행\s*)?중|환불\s*(처리\s*)?중|주문\s*확인\s*중|주문\s*확인|결제\s*확인|발송\s*대기|주문\s*접수|주문\s*완료|결제\s*완료|입금\s*대기|입금\s*확인|상품\s*준비\s*중|배송\s*준비\s*중|발송\s*준비|출고\s*완료|배송\s*시작|배송\s*중|배송\s*완료|구매\s*확정|구매\s*결정|취소\s*완료|취소\s*요청|취소\s*접수|주문\s*취소|반품\s*완료|반품\s*요청|반품\s*접수|교환\s*완료|교환\s*요청|환불\s*완료)/;
  const EMPTY = /(주문|구매)\s*내역이\s*없|내역이\s*없습니다|주문하신\s*상품이\s*없/;
  const BTN = /^(장바구니|장바구니 담기|배송\s*조회|주문\s*상세|주문\s*상세보기|상세\s*보기|리뷰|후기|문의|재구매|다시 구매|구매확정|구매 확정|교환|반품|취소|주문\s*·\s*배송\s*취소|배송지 변경|영수증|선물|더보기|판매자 문의|문의하기)/;
  for (let i = 0; i < 24; i++) { const t = document.body.innerText; if (DATE.test(t) && PRICE.test(t) || EMPTY.test(t)) break; PRICE.lastIndex = 0; await wait(500); }
  PRICE.lastIndex = 0;
  for (let i = 0; i < (opt.scroll || 3); i++) { window.scrollTo(0, document.body.scrollHeight); await wait(900); }
  window.scrollTo(0, 0);
  const vis = el => { const r = el.getBoundingClientRect(); return r.width >= 36 && r.height >= 36; };
  const skipArea = el => el.closest('header,footer,nav,[class*=gnb],[class*=Gnb],[class*=footer],[class*=Footer],[class*=recommend],[class*=Recommend],[class*=banner],[class*=Banner]');
  const hasPrice = t => { PRICE.lastIndex = 0; return PRICE.test(t); };
  const used = [];
  const cards = [];
  for (const img of document.querySelectorAll('img')) {
    if (!vis(img) || skipArea(img)) continue;
    let el = img.parentElement;
    for (let d = 0; d < 9 && el && el !== document.body; d++, el = el.parentElement) {
      const t = el.innerText || '';
      if (t.length > 1600) { el = null; break; }
      if (hasPrice(t) && t.replace(/\s+/g, '').length > 8) break;
    }
    if (!el || el === document.body || used.some(u => u.contains(el) || el.contains(u))) continue;
    if ([...el.querySelectorAll('img')].filter(vis).length > 2) continue;   // 여러 상품이 한 덩어리면 건너뜀
    used.push(el); cards.push({ el, img });
  }
  const dateNodes = []; { const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { const m = n.nodeValue.match(DATE); if (m && !(n.parentElement && n.parentElement.closest('header,footer,select,option,input,[class*=calendar],[class*=Calendar],[class*=period],[class*=Period]'))) dateNodes.push({ n, t: m[0] }); } }
  const dEls = [...document.querySelectorAll('[data-kc-durl]')];
  const stNodes = []; { const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { const v = n.nodeValue.trim(); if (!v || v.length > 30) continue; const m = v.match(STATUS); if (!m || (n.parentElement && n.parentElement.closest('button,[role=button],header,footer,select,option'))) continue;
    // 배송 단계 표시(배송준비 · 배송중 · 배송완료가 나란히 있는 진행 막대)는 상태가 아니에요
    let bar = false; for (let i = 0, a = n.parentElement; i < 3 && a && a !== document.body; i++, a = a.parentElement) { const t = a.innerText || ''; const g = new RegExp(STATUS.source, 'g'); if (t.length < 50 && (t.match(g) || []).length >= 2 && t.replace(g, '').replace(/\s+/g, '').length <= 8) { bar = true; break; } }
    if (!bar) stNodes.push({ n, m }); } }
  const up = (el, re, n) => { for (let i = 0, a = el; i < (n || 6) && a && a !== document.body; i++, a = a.parentElement) { const m = (a.innerText || '').match(re); if (m) return { m, a }; } return null; };
  const rows = [];
  for (const { el, img } of cards) {
    const text = (el.innerText || '').trim();
    const lines = text.split('\n').map(s => s.trim()).filter(Boolean);
    // 날짜: 덩어리 안에 없으면 화면 순서상 이 상품 바로 앞에 나온 날짜(주문 묶음 머리)
    let date = '';
    const dm = text.match(DATE);
    if (dm) date = dm[0];
    else { let last = ''; for (const dn of dateNodes) { if (dn.n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) last = dn.t; else break; } date = last; }
    const d = date.match(DATE); const ymd = d ? `${d[1].length === 2 ? '20' + d[1] : d[1]}-${d[2].padStart(2, '0')}-${d[3].padStart(2, '0')}` : '';
    // 상태: '구매확정'처럼 버튼에 적힌 글자보다 화면에 적힌 상태를 먼저 봐요
    // 2.6.2: 쿠팡처럼 한 주문 안에 상태가 여러 개(배송중 · 취소완료 · 상품준비중…)인 곳은, 이 상품 바로 앞에 적힌 상태가 이 상품 것이에요.
    //        (같은 주문 묶음 날짜 뒤에 있는 것만, 버튼 글자는 빼고)
    const inSt = stNodes.find(x => el.contains(x.n));
    let near = null;
    if (!inSt) { const gd = dateNodes.filter(dn => (dn.n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) && !el.contains(dn.n)).pop();
      for (const x of stNodes) { if (!(x.n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) || el.contains(x.n)) break; if (!gd || (gd.n.compareDocumentPosition(x.n) & Node.DOCUMENT_POSITION_FOLLOWING)) near = x; } }
    let btnHit = null;
    const stOf = root => { const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { const m = n.nodeValue.match(STATUS); if (!m) continue; if (n.parentElement && n.parentElement.closest('button,[role=button]')) { btnHit = btnHit || m; continue; } return m; } return null; };
    let st = stOf(el); for (let i = 0, a2 = el.parentElement; !st && i < 4 && a2 && a2 !== document.body; i++, a2 = a2.parentElement) st = stOf(a2);
    if (!st) st = btnHit;
    if (inSt) st = inSt.m; else if (near) st = near.m;
    const ono = (text.match(/주문\s*번호\s*[:：]?\s*([0-9A-Z\-]{6,})/i) || ((up(el, /주문\s*번호\s*[:：]?\s*([0-9A-Z\-]{6,})/i, 6) || {}).m) || [])[1] || '';
    const paid = text.match(/(결제|판매|주문|구매|실결제)\s*금액[^\d]{0,12}([\d,]{4,})\s*원/);
    PRICE.lastIndex = 0; const prices = [...text.matchAll(PRICE)].map(m => +m[1].replace(/,/g, '')).filter(n => n >= 100);
    const price = paid ? +paid[2].replace(/,/g, '') : prices.length ? prices[prices.length - 1] : null;
    const qLine = lines.find(l => /^\d{1,3}\s*개$/.test(l));
    const qm = text.match(/수량\s*[:：]?\s*(\d{1,3})/) || (qLine && qLine.match(/(\d+)/)) || text.match(/(?:^|\s|\/|\))(\d{1,3})\s*개(?!입|월)(?!\S)/m);   // 3.10.14: 지그재그 '240 (34,000원)2개'처럼 괄호 바로 뒤 수량도 읽어요
    const nameCands = lines.filter(l => !DATE.test(l) && !STATUS.test(l) && !BTN.test(l) && !/^[\d,]+\s*원/.test(l) && !/^(수량|옵션|주문\s*번호|판매금액|결제금액|배송비|할인|쿠폰|정상가|판매가|도착|내일|오늘)/.test(l) && /[가-힣A-Za-z]/.test(l) && l.length >= 4);
    const alt = (img.alt || '').trim();
    let name = alt.length > 6 && !/^(상품|이미지|product|image|thumbnail|썸네일)/i.test(alt) ? alt : (nameCands.sort((a, b) => b.length - a.length)[0] || '');
    let optLine = lines.find(l => /^(옵션|사이즈|size|색상|컬러)\s*[:：]?/i.test(l) || / \/ |:\s*\S/.test(l) && l !== name && l.length < 80) || '';
    if (!optLine) { const nx = lines[lines.indexOf(name) + 1] || ''; if (nx && nx.length < 60 && !DATE.test(nx) && !STATUS.test(nx) && !BTN.test(nx) && !/^[\d,]+\s*원|^(수량|판매금액|결제금액|배송|도착|내일|오늘)/.test(nx)) optLine = nx; }
    const a = el.querySelector('a[href]') || el.closest('a[href]');
    // 주문상세 주소: 이 상품 안에 있거나, 같은 주문 묶음 머리(사이에 다른 날짜가 없는 바로 앞)에 있는 '주문상세'
    let det = el.querySelector('[data-kc-durl]');
    if (!det) { let last = null; for (const x of dEls) { if (x.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) last = x; else break; }
      if (last && !dateNodes.some(dn => (last.compareDocumentPosition(dn.n) & Node.DOCUMENT_POSITION_FOLLOWING) && (dn.n.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) && !el.contains(dn.n))) det = last; }
    rows.push({ detail: det ? det.dataset.kcDurl : '', date: ymd, status: st ? st[0].replace(/\s+/g, '') : '', name: name.slice(0, 160), opt: optLine.replace(/^(옵션|사이즈|size)\s*[:：]?\s*/i, '').slice(0, 80), qty: qm ? +qm[1] : 1, price, orderNo: ono, url: a ? a.href : '', text: text.slice(0, 400) });
  }
  const body = document.body.innerText;
  return { url: location.href, title: document.title, rows, empty: EMPTY.test(body) && !rows.length, loginNeeded: /로그인|login/i.test(location.href) || (/아이디|비밀번호/.test(body) && /로그인/.test(body) && !rows.length) };
}

// ---------- 2.6.1: 주문 목록의 '주문상세' 주소 표시 (사이트 화면 쪽에서 실행: world MAIN) ----------
// 링크면 그 주소, 쿠팡처럼 주문번호가 화면 데이터에만 있으면 주소 틀(tpl)에 넣고, 지그재그처럼 누르면 새 창이 뜨는 곳은
// 새 창을 막고 열려던 주소만 받아 둬요. 표시는 data-kc-durl 속성으로 남겨서 kcOrders가 읽어요. (2026-11-11 지그재그·쿠팡·G마켓 확인)
async function kcTagDetails(tpl, scroll) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 20 && !/주문\s*상세|상세\s*보기/.test(document.body.innerText); i++) await wait(500);
  for (let i = 0; i < (scroll || 0); i++) { window.scrollTo(0, document.body.scrollHeight); await wait(900); }
  window.scrollTo(0, 0);
  const RE = /^(주문\s*상세(\s*보기)?|상세\s*보기)$/;
  const els = [...document.querySelectorAll('a,button,span,div,p,strong')].filter(e => e.childElementCount <= 2 && RE.test((e.innerText || '').trim()) && !e.closest('header,footer,nav'));
  const list = els.filter(e => !els.some(o => o !== e && e.contains(o)));
  const idOf = el => {
    for (let d = 0, a = el; d < 10 && a; d++, a = a.parentElement) {
      const k = Object.keys(a).find(k => k.startsWith('__reactFiber')); if (!k) continue;
      let f = a[k];
      for (let j = 0; j < 8 && f; j++, f = f.return) {
        const p = f.memoizedProps; if (!p || typeof p !== 'object') continue;
        for (const v of [p, p.order, p.data, p.item]) { if (!v || typeof v !== 'object') continue; const id = v.orderId ?? v.orderNo ?? v.orderNumber ?? v.order_number ?? v.ordNo; if (id != null && /^[\w-]{5,}$/.test(String(id))) return String(id); }
      }
    }
    return '';
  };
  const orig = window.open, caught = []; let n = 0, moved = false;
  window.open = u => { caught.push(String(u)); return null; };
  try {
    for (const el of list) {
      if (el.dataset.kcDurl) { n++; continue; }
      const a = el.closest('a[href]'); const h = a ? a.getAttribute('href') || '' : '';
      if (a && h && !/^(javascript:|#)/.test(h)) { el.dataset.kcDurl = a.href; n++; continue; }
      if (tpl) { const id = idOf(el); if (id) { el.dataset.kcDurl = tpl.replace('{id}', id); n++; } continue; }
      const before = location.href; caught.length = 0;
      el.click(); await wait(150);
      if (location.href !== before) { moved = true; break; }   // 같은 창에서 넘어가는 곳은 더 누르지 않아요
      if (caught[0]) { el.dataset.kcDurl = new URL(caught[0], location.href).href; n++; }
    }
  } finally { window.open = orig; }
  return { n, total: list.length, moved };
}

// ---------- 2.6.1: 주문상세 화면에서 실제 결제한 금액 읽기 ----------
// 우선순위: 즉시 할인가(무신사 카드 즉시할인) → 최종 결제금액 → 총 결제금액 → 실결제금액 → 결제 금액
// (2026-11-11 확인: 지그재그 '총 결제 금액', 쿠팡 '총 결제금액', G마켓 '총 결제금액', 무신사 '결제 금액'·'즉시 할인가')
async function kcOrderPaid() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 30 && !/결제\s*금액|결제금액/.test(document.body.innerText); i++) await wait(500);
  await wait(400);
  const lines = document.body.innerText.split('\n').map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const num = s => { const m = String(s).match(/^(-?)\s*(\d{1,3}(?:,\d{3})+|\d+)\s*원?$/); return m ? +m[2].replace(/,/g, '') * (m[1] ? -1 : 1) : null; };
  const after = re => {
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(re); if (!m) continue;
      const rest = lines[i].slice(m[0].length).trim();
      const cands = [rest, ...lines.slice(i + 1, i + 4)];
      for (let j = 0; j < cands.length; j++) {
        const c = cands[j]; if (!c) continue;
        if (/^\d{1,3}\s*%$/.test(c) || /^\d{1,3}\s*개$/.test(c)) continue;
        const v = num(c); if (v != null) return { v, label: m[0] };
        if (j > 0) break;
      }
    }
    return null;
  };
  const P = [/^즉시\s*할인가/, /^(총\s*)?최종\s*결제\s*금액/, /^총\s*결제\s*금액/, /^실\s*결제\s*금액/, /^결제\s*금액/];
  let paid = null; for (const re of P) { paid = after(re); if (paid && paid.v > 0) break; paid = null; }
  const goods = after(/^(총\s*)?상품\s*(금액|가격|합계)/);
  const ship = (lines.find(l => /^배송비/.test(l)) || '').includes('무료') ? { v: 0 } : after(/^배송비/);
  let points = 0;
  lines.forEach((l, i) => { if (/^(적립금|포인트|마일리지|쿠팡캐시|스마일캐시|캐시|예치금|머니)\s*(사용)?$/.test(l)) { const v = num(lines[i + 1] || ''); if (v && v < 0) points += -v; } });
  const ono = (document.body.innerText.match(/주문\s*번호\s*[:：]?\s*([0-9A-Z-]{6,})/i) || [])[1] || '';
  const body = document.body.innerText;
  return { url: location.href, paid: paid ? paid.v : 0, label: paid ? paid.label : '', goods: goods ? goods.v : 0, ship: ship ? ship.v : 0, points, orderNo: ono, loginNeeded: /login|로그인/i.test(location.pathname) || (/아이디|비밀번호/.test(body) && /로그인/.test(body) && !paid) };
}

// ---------- 2.5.1: ABC마트·그랜드스테이지 상품 화면에서 스타일코드 읽기 ("스타일코드 : HV8150 색상코드 : 003" → HV8150-003) ----------
async function kcArtCode() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 16 && !/스타일\s*코드/.test(document.body.innerText); i++) await wait(400);
  const t = document.body.innerText;
  const st = (t.match(/스타일\s*코드\s*[:：]?\s*([A-Z0-9][A-Z0-9-]{2,})/i) || [])[1] || '';
  const co = (t.match(/색상\s*코드\s*[:：]?\s*([A-Z0-9]{2,4})\b/i) || [])[1] || '';
  return { style: st, color: co, code: st && /^\d{3}$/.test(co) && !st.includes('-') ? `${st}-${co}` : st };
}

// ---------- 2.6: 크림 보관 신청 (보관 상품 선택 → 사이즈 수량 → 신청 계속) — 2026-11-11 화면 확인 ----------
// 보관 상품 선택 화면(/search/stock)에서 모델번호로 검색해서 그 상품을 눌러요. 상품 번호는 바뀐 주소(/inventory/번호)에서 읽어요.
async function kcStockFind(codes) {
  // 3.7.5: 모델번호가 여러 개('A/B/C')면 하나씩 검색하고, 하이픈·띄어쓰기 차이는 무시해요. 못 찾으면 검색 결과 후보를 알려줘요.
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const key = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
  const list = [...new Set([].concat(codes || []).flatMap(c => String(c).split('/')).map(c => c.trim()).filter(c => key(c).length >= 4))];
  const want = new Set(list.map(key));
  let inp = null; for (let i = 0; i < 20 && !(inp = document.querySelector('input[placeholder*="모델번호"],input[type=search]')); i++) await wait(300);
  if (!inp) return { error: '검색칸을 못 찾았어요' };
  const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  const cands = [];
  const tokens = a => a.innerText.split(/[\n/,]+/).map(x => key(x)).filter(Boolean);
  for (const code of list) {
    inp.focus(); set.call(inp, code); inp.dispatchEvent(new Event('input', { bubbles: true }));
    await wait(250);
    inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    inp.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    let a = null;
    for (let i = 0; i < 16; i++) { await wait(400); const hits = [...document.querySelectorAll('a.item_link')].filter(x => tokens(x).some(t => want.has(t)));
      // 3.10.36: 모델번호가 '똑같은' 상품만 — 앞뒤 글자가 다른 건 색상이 다른 상품일 수 있어서(예: 블랙/화이트) 절대 고르지 않아요.
      //          같은 모델번호 상품이 여러 개(색상별)면 고르지 않고 멈춰요 → 크림 상품 링크를 직접 넣어야 해요.
      if (hits.length > 1) { const names = hits.map(x => x.innerText.split('\n').map(s => s.trim()).filter(Boolean).slice(0, 3).join(' · ').slice(0, 60)); return { found: false, ambiguous: true, tried: list, cands: names.slice(0, 4) }; }
      a = hits[0]; if (a) break; }
    if (a) { const name = a.innerText.split('\n').map(s => s.trim()).filter(Boolean).slice(1, 3).join(' / '); setTimeout(() => a.click(), 50); return { found: true, name, by: code }; }
    for (const x of [...document.querySelectorAll('a.item_link')].slice(0, 3)) { const t = x.innerText.split('\n').map(s => s.trim()).filter(Boolean).slice(0, 3).join(' · ').slice(0, 60); if (t && !cands.includes(t)) cands.push(t); }
  }
  return { found: false, tried: list, cands: cands.slice(0, 3) };
}
// 3.10.26: 보관 신청 화면 위쪽 글자 · 크림 모델번호 · 영문 상품명 (모델번호 모양이 다를 때 확인용)
function kcStockHead() {
  const head = document.body.innerText.slice(0, 1500);
  const lines = head.split('\n').map(s => s.trim()).filter(Boolean);
  let code = ''; const i = lines.findIndex(l => /^모델\s*번호/.test(l)); if (i >= 0) code = (lines[i].replace(/^모델\s*번호\s*:?\s*/, '') || lines[i + 1] || '').trim();
  const en = lines.find(l => l.length >= 10 && /^[\x20-\x7E]+$/.test(l) && /[A-Za-z]{3}/.test(l) && !/kream|login|search/i.test(l)) || '';
  return { head, code, en };
}
function kcStockSizes() {
  return [...document.querySelectorAll('.inventory_size_item .size')].map(e => e.innerText.trim());
}
// MAIN world 에서 실행. 크림 보관 신청 2단계 (2026-11-11 화면 확인):
//  1) 사이즈별 + 버튼으로 수량 → '신청 계속'  2) 같은 주소에서 '신청 내역' 요약(신청 상품·모델번호, "270 X 1개", 신청 수량 N건, 총 결제금액)
//  3) '보증금 결제하기' (등록된 카드로 자동 결제). 요약이 기대값과 한 글자라도 다르면 누르지 않아요.
async function kcStockApply(size, qty, codes, final, gapSec, resume) {
  // 3.10.9: 한 번 실행은 전체 80초 안에 끝내요(프로그램이 기다리는 115초보다 짧게 — 넘으면 '결과 못 받음'으로 멈췄어요).
  //         새 실행이 시작되면 예전 실행은 바로 그만둬요(안 보이게 계속 돌다가 또 누르는 일 방지).
  const T_START = Date.now(), T_END = T_START + 80000;
  const RUN = Math.random().toString(36).slice(2); window.__kcRun = RUN;
  const alive = () => window.__kcRun === RUN && Date.now() < T_END;
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const key = s => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
  const norm = s => String(s || '').toUpperCase().replace(/\s+/g, '');
  window.__kcMsgs = []; window.__kcOkMsgs = [];
  // 3.8.8: '모델번호를 확인하셨나요?' 안내가 브라우저 기본 알림창으로 와도, 우리 모델번호가 적혀 있으면 '확인'으로 넘겨요
  const modelOk = m => /모델번호/.test(m) && codes.some(c => key(m).includes(key(c)));
  window.alert = m => { m = String(m); if (modelOk(m)) { window.__kcOkMsgs.push(m); return; } window.__kcMsgs.push(m); };
  window.confirm = m => { m = String(m); if (modelOk(m)) { window.__kcOkMsgs.push('[확인창] ' + m); return true; } window.__kcMsgs.push('[확인창] ' + m); return false; };   // 모르는 확인창은 '취소'
  const said = () => { const pop = [...document.querySelectorAll('[class*=toast],[class*=modal],[class*=layer],[class*=popup],[class*=alert],[class*=snackbar],[role=dialog],[role=alert]')].filter(e => e.offsetParent && (e.innerText || '').trim()).map(e => e.innerText.trim().replace(/\s+/g, ' ').slice(0, 160)); return [...window.__kcMsgs, ...pop].filter((x, i, a) => a.indexOf(x) === i).slice(0, 4); };
  // 3.9.7: resume = 이미 '보증금 결제하기' 화면에 있으면 처음으로 돌아가지 않고 그 화면에서 이어서 신청해요
  const resumePay = resume ? [...document.querySelectorAll('a,button')].find(b => /보증금\s*결제하기/.test(b.innerText || b.textContent || '')) : null;
  if (!resumePay) {
  try { sessionStorage.removeItem('kcFinal'); } catch (e) {}
  for (let i = 0; i < 25 && !document.querySelector('.inventory_size_item'); i++) await wait(300);
  const items = [...document.querySelectorAll('.inventory_size_item')];
  if (!items.length) return { error: '사이즈 고르는 화면이 아니에요', said: said() };
  // 0. 화면 위쪽 상품 모델번호가 맞는지
  const head = document.body.innerText.slice(0, 1500);
  if (!codes.some(c => key(head).includes(key(c)))) return { mismatch: `화면의 상품 모델번호가 ${codes.join('/')} 와 달라요` };
  const row = items.find(r => norm((r.querySelector('.size') || {}).innerText) === norm(size));
  if (!row) return { error: `사이즈 ${size} 칸이 없어요`, sizes: items.map(r => (r.querySelector('.size') || {}).innerText.trim()) };
  const btn = (r, k) => [...r.querySelectorAll('button')].find(b => b.querySelector('.ico-count-' + k));
  for (const r of items) { if (r === row) continue; const inp = r.querySelector('input'); for (let k = 0; k < 40 && inp && +inp.value > 0; k++) { btn(r, 'minus').click(); await wait(80); } }
  const inp = row.querySelector('input');
  for (let k = 0; k < 40 && +inp.value > qty; k++) { btn(row, 'minus').click(); await wait(80); }
  for (let k = 0; k < 40 && +inp.value < qty; k++) { btn(row, 'plus').click(); await wait(150); }
  await wait(300);
  const others = items.filter(r => r !== row && +(r.querySelector('input') || {}).value > 0).length;
  if (+inp.value !== qty || others) return { mismatch: `수량을 정확히 맞추지 못했어요 (${size}: ${inp.value}개, 다른 사이즈 ${others}칸)` };
  }
  // 3.8.7: 크림이 띄우는 확인 창 처리 — ① '모델번호를 정확히 확인하세요'(같은 디자인 다른 모델번호가 있는 상품)
  //        ② 결제 전 필수 동의 창. 창 안의 체크칸을 다 체크하고 확인 버튼을 눌러요.
  //        모델번호 창은 창에 적힌 모델번호가 우리 재고 모델번호와 같을 때만 넘어가요(다르면 멈춤).
  const vis = e => { const r = e.getBoundingClientRect(), st = getComputedStyle(e); return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none'; };
  const isOn = e => { const inp = e.matches && e.matches('input') ? e : e.querySelector && e.querySelector('input[type=checkbox]'); if (inp) return inp.checked; return e.getAttribute('aria-checked') === 'true' || /(^|[\s_-])(checked|is-checked|active|on)(\s|$)/.test(e.className || ''); };
  const LAYER_SEL = '[class*=layer],[role=dialog],[role=alertdialog],[class*=modal],[class*=sheet],[class*=popup],[class*=dialog],[class*=alert],[class*=toast],[class*=snackbar],[role=alert]';
  // 3.8.9: 크림 확인 창은 바깥 틀 크기가 0으로 잡히는 경우가 있어서(실제 화면 확인), 틀 안에 보이는 게 있으면 보이는 걸로 봐요
  const seen = e => e.offsetParent !== null || vis(e) || [...e.querySelectorAll('button,a,p,div,span')].some(c => { const r = c.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
  const doLayer = async (avoid, dry) => {   // avoid: 이 버튼이 들어 있는 큰 화면 묶음은 확인 창으로 보지 않아요(결제 버튼 두 번 누름 방지)
    const all = [...document.querySelectorAll('[aria-label="전체 동의 체크박스"],.all-agree-checkbox')].find(seen);
    // 3.9.9: 창 안쪽 목록(‘보기’ 링크만 있는 칸)을 창으로 잘못 고르지 않게, 확인·결제 버튼까지 들어 있는 가장 작은 묶음을 골라요
    // 3.10.6: 실제 크림 동의 창 시험에서 확인 — '[필수] … 동의 보기' 항목 줄이 버튼처럼 잡혀서 결제 버튼 대신 그 줄을 눌렀어요(→ 마지막 칸이 꺼짐).
    //         확인 버튼은 짧은 글(30자 안)이고 '[필수]·[선택]·보기'가 없는 진짜 버튼만 봐요.
    const OKB = e => { const tx = (e.innerText || '').replace(/\s+/g, ' ').trim(); return seen(e) && !!tx && tx.length <= 30 && !/\[(필수|선택)\]|보기|닫기|취소|자세히|약관|더보기|다시|변경|아니/.test(tx) && !e.closest('label') && !e.querySelector('input') && /결제|신청|동의|확인|계속|진행|^(예|네|다음)$/.test(tx); };
    const hasOk = l => [...l.querySelectorAll('button,a,[role=button]')].some(OKB);
    let layer = [...document.querySelectorAll(LAYER_SEL)].filter(seen)
      .filter(l => !(avoid && avoid.some(x => x && l.contains(x))) && /동의|모델번호를?\s*(정확히\s*)?확인|확인하셨나요/.test(l.innerText || '') && hasOk(l))
      .sort((a, b) => (a.innerText || '').length - (b.innerText || '').length)[0];
    if (!layer && all) { let p = all.parentElement; while (p && p !== document.body && !hasOk(p)) p = p.parentElement; if (p && p !== document.body && !(avoid && avoid.some(x => x && p.contains(x)))) layer = p; }
    if (!layer || (avoid && avoid.some(x => x && layer.contains(x)))) return null;
    const lt = layer.innerText || '';
    const titles = [...new Set(lt.split('\n').map(x => x.trim()).filter(x => x.length > 3 && x.length < 70 && !/닫기|결제하기|^보기$/.test(x)))].slice(0, 6);
    if (/모델번호/.test(lt)) {
      const shown = [...new Set((lt.match(/[A-Z0-9]{2,}[A-Z0-9]*(?:-[A-Z0-9]+)+/gi) || []))];
      if (!codes.some(c => key(lt).includes(key(c)))) return { fail: true, mismatch: true, why: `크림 확인 창의 모델번호(${shown.join(', ') || '안 보임'})가 재고 모델번호(${codes.join('/')})와 달라요` };
    }
    // 3.10.1: 체크칸 — 진짜 체크박스(input)가 있으면 그것만 기준으로 봐요(겉모양 칸까지 같이 누르면 두 번 눌려 다시 꺼질 수 있어요).
    //         안 켜지면 체크박스 → 글자(label) → 체크 모양 → 그 줄 순서로 눌러 보고, 켜지는 순간 멈춰요. 글 안의 링크(이용정책·보기)는 누르지 않아요.
    const okBtnL = () => [...layer.querySelectorAll('button,a,[role=button]')].filter(OKB).reverse()[0];
    const okReady = () => { const o = okBtnL(); return !!o && !o.disabled && o.getAttribute('aria-disabled') !== 'true' && !/disabled/.test(o.className || ''); };
    const hasInputs = !!layer.querySelector('input[type=checkbox]');
    const boxes = () => hasInputs ? [...layer.querySelectorAll('input[type=checkbox]')] : [...layer.querySelectorAll('[class*=checkbox]')].filter(e => !e.querySelector('[class*=checkbox]') && !e.closest('input'));
    let clicked = 0;
    // 3.10.3: 이미 다 체크돼서 버튼이 눌리는 상태면 아무것도 건드리지 않아요(다시 누르면 체크가 풀릴 수 있어요)
    const allBox = all && (all.matches('.all-agree-checkbox') ? all : all.querySelector('.all-agree-checkbox,input[type=checkbox],[class*=checkbox]') || all);
    if (!okReady() && allBox && !isOn(allBox)) { all.click(); clicked++; await wait(400); }
    if (!okReady()) for (const b of boxes()) {
      if (isOn(b)) continue; clicked++;
      const row = b.closest('li,[class*=item],[class*=agree]');
      const cands = [b, b.labels && b.labels[0], b.closest('label'), b.closest('[class*=checkbox]'), b.parentElement, row].filter(Boolean)
        .filter((x, i, a) => a.indexOf(x) === i && x.tagName !== 'A' && !x.closest('a'));
      for (const c of cands) { c.click(); await wait(250); if (isOn(b) || okReady()) break; }
      // 3.10.2: 크림 동의 칸은 <label> 안의 숨은 체크박스(v-model)예요. 그래도 안 켜지면 체크 상태를 직접 켜고 'change'를 알려요(크림 화면이 이 신호로 체크를 기억해요)
      if (!isOn(b) && b.matches('input') && !b.disabled) { b.checked = true; b.dispatchEvent(new Event('input', { bubbles: true })); b.dispatchEvent(new Event('change', { bubbles: true })); await wait(250); }
    }
    if (clicked) await wait(300);
    const left = boxes().filter(b => !isOn(b)).length;
    const ok = okBtnL();
    if (dry) {   // 시험: 체크만 해 보고 결제 버튼은 누르지 않고 창을 닫아요
      const res = { dry: true, ready: okReady(), states: boxes().map(isOn), left, titles, btn: ok ? (ok.innerText || '').trim() : '' };
      const cl = [...layer.querySelectorAll('button,a,[role=button]')].find(e => /닫기/.test((e.innerText || '') + (e.getAttribute('aria-label') || '')) || /close/.test(e.className || ''));
      if (cl) cl.click(); else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      await wait(500); res.closed = !document.body.contains(layer) || !seen(layer);
      return res;
    }
    if (!okReady()) return { fail: true, why: `확인 창을 넘기지 못했어요 (안 채운 체크칸 ${left}개)`, titles, html: layer.outerHTML.replace(/<svg[\s\S]*?<\/svg>/g, '<svg/>').replace(/\s(style|src|srcset|href)="[^"]*"/g, '').slice(0, 4000) };
    const html = layer.outerHTML.replace(/<svg[\s\S]*?<\/svg>/g, '<svg/>').replace(/\s(style|src|srcset|href)="[^"]*"/g, '').slice(0, 2500);
    ok.click(); window.__kcLastClick = Date.now(); await wait(150);
    return { ok: true, titles, html, btn: (ok.outerHTML || '').slice(0, 300) };
  };
  // 막혔을 때 그 화면의 안내 창 모양을 남겨요(크림 화면이 바뀌었을 때 고치려고 · 개인정보 없는 화면 구조만)
  const domSnap = () => { try { const c = [...document.querySelectorAll(LAYER_SEL)].filter(seen).filter(e => /모델번호|동의|확인/.test(e.innerText || '')).sort((a, b) => (b.innerText || '').length - (a.innerText || '').length)[0]; return c ? c.outerHTML.replace(/<svg[\s\S]*?<\/svg>/g, '<svg/>').replace(/\s(style|src|srcset|href)="[^"]*"/g, '').slice(0, 3000) : ''; } catch (e) { return ''; } };
  // 3.9.3: 크림 서버 응답을 같이 기록해요 (확인 창을 넘긴 뒤 왜 안 넘어가는지 보려고 · 주소와 상태 코드, 응답 앞부분만)
  const net = []; const seenMsg = new Set();
  if (!window.__kcFetchHooked) { window.__kcFetchHooked = true; const of = window.fetch; window.fetch = async function (i, o) { const u = String(typeof i === 'string' ? i : (i && i.url) || ''); const r = await of.apply(this, arguments); try { if (/inventor|review|stock|payment|order|deposit/i.test(u) && window.__kcNet) r.clone().text().then(t => window.__kcNet.push({ t: Date.now(), u: u.replace(/^https?:\/\/[^/]+/, '').split('?')[0], m: (o && o.method) || 'GET', s: r.status, b: t.slice(0, 300) })).catch(() => {}); } catch (e) {} return r; }; }
  window.__kcNet = net;
  const noteMsgs = () => { for (const x of said()) seenMsg.add(x); };
  const confirmed = [];
  const payBtn = () => [...document.querySelectorAll('a,button')].find(b => /보증금\s*결제하기/.test(b.innerText || b.textContent || ''));
  let pay = resumePay, regoes = 0;
  if (!pay) {
  const go = [...document.querySelectorAll('a,button')].find(b => /신청\s*계속/.test(b.innerText));
  if (!go) return { error: "'신청 계속' 버튼이 없어요" };
  if (go.disabled || go.classList.contains('disabled')) return { blocked: true, said: ["'신청 계속'이 눌리지 않는 상태"].concat(said()) };
  go.click();
  // 1단계 결과: 요약 화면(보증금 결제하기) 또는 막힘 안내
  const end1 = Math.min(Date.now() + 30000, T_END);
  let lastOk = 0;
  for (let layers = 0; Date.now() < end1 && alive();) {
    await wait(300); noteMsgs(); pay = payBtn(); if (pay || window.__kcMsgs.length) break;
    if (net.some(n => /review/.test(n.u) && n.s >= 400)) { await wait(400); noteMsgs(); break; }   // 크림이 신청을 거절함(예: 신규 보관 신청 제한 카테고리) → 이번 시도는 끝
    if (layers < 3) { const L = await doLayer([go]); if (L && L.fail) return L.mismatch ? { mismatch: L.why } : { blocked: true, step: 'confirm', said: [L.why].concat(L.titles || [], said()), dom: domSnap() }; if (L && L.ok) { layers++; lastOk = Date.now(); confirmed.push(...L.titles.slice(0, 2)); window.__kcLayerHtml = L.html; window.__kcLayerBtn = L.btn; } }
    // 3.9.0: 확인 창을 넘긴 뒤 같은 화면에 그대로 있으면(실제 크림 화면 확인) '신청 계속'을 한 번 더 눌러요 — 수량이 그대로인지 먼저 확인
    if (lastOk && Date.now() - lastOk > 9000 && regoes < 1) {
      const go2 = [...document.querySelectorAll('a,button')].find(b => /신청\s*계속/.test(b.innerText) && (b.offsetParent !== null || vis(b)));
      const row2 = [...document.querySelectorAll('.inventory_size_item')].find(r => norm((r.querySelector('.size') || {}).innerText) === norm(size));
      const others2 = [...document.querySelectorAll('.inventory_size_item')].filter(r => r !== row2 && +(r.querySelector('input') || {}).value > 0).length;
      if (go2 && row2 && +(row2.querySelector('input') || {}).value === qty && !others2 && !go2.disabled && !go2.classList.contains('disabled')) { regoes++; lastOk = 0; go2.click(); }
      else if (go2 && row2) { lastOk = 0; }
    }
  }
  confirmed.push(...window.__kcOkMsgs.map(m => m.slice(0, 60)));
  if (!pay) { const btnT = [...document.querySelectorAll('a,button')].filter(b => b.offsetParent !== null || vis(b)).map(b => (b.innerText || '').trim().replace(/\s+/g, ' ')).filter(t => t && t.length < 30).slice(-25); const srv = net.filter(n => n.s >= 400).map(n => { try { return JSON.parse(n.b).message; } catch (e) { return ''; } }).filter(Boolean); return { blocked: true, step: 1, said: [...new Set(srv.concat([...seenMsg].filter(x => !/모델번호를 확인하셨나요/.test(x)), said()))].slice(0, 4), net: net.slice(-6), dom: window.__kcLayerHtml || domSnap(), okBtn: window.__kcLayerBtn || '', confirmed, regoes, url: location.pathname, btns: btnT, text: (document.body.innerText || '').replace(/\s+/g, ' ').slice(0, 700) }; }
  }
  // 2단계 확인: 요약 내용이 기대값과 똑같은지 (모델번호·사이즈·수량·신청 건수·결제금액)
  const t = document.body.innerText;
  const a = t.indexOf('신청 상품'), b = t.indexOf('반송');
  const box = a >= 0 ? t.slice(a, b > a ? b : a + 400) : '';
  const lines = [...box.matchAll(/(?:^|\n)[ \t]*([^\n]*?\S)\s*X\s*(\d+)\s*개/g)].map(m => ({ s: m[1], q: +m[2] }));   // 3.7.5: 'US 7'처럼 띄어쓴 사이즈도
  const cnt = +((t.match(/신청\s*수량\s*(\d+)\s*건/) || [])[1] || 0);
  const total = +(((t.match(/총\s*결제\s*금액\s*([\d,]+)\s*원/) || [])[1] || '0').replace(/,/g, ''));
  const dep = +(((t.match(/보증금\s*\n?\s*([\d,]+)\s*원/) || [])[1] || '3000').replace(/,/g, ''));
  const problems = [];
  if (!codes.some(c => key(box).includes(key(c)))) problems.push('요약의 모델번호가 달라요');
  if (lines.length !== 1) problems.push(`요약에 사이즈 줄이 ${lines.length}개예요`);
  else { const ls = norm(lines[0].s), ns = norm(size); if (!(ls === ns || (ls.endsWith(ns) && !/[0-9A-Z.]$/.test(ls.slice(0, -ns.length))))) problems.push(`요약 사이즈가 ${lines[0].s}예요`); if (lines[0].q !== qty) problems.push(`요약 수량이 ${lines[0].q}개예요`); }
  if (!new RegExp('총\\s*' + qty + '\\s*개').test(box)) problems.push('요약의 총 개수가 달라요');
  if (cnt !== qty) problems.push(`신청 수량이 ${cnt}건이에요`);
  // 3.10.39: 2개씩 넣으면 크림이 '보증금'에 합계(6,000원)를 보여줘요 → 보증금이 1개 값이든 합계든 결제금액과 맞으면 통과 (개수는 위에서 따로 확인)
  if (!total || !(total === dep * qty || (total === dep && dep % qty === 0 && dep / qty >= 1000))) problems.push(`총 결제금액이 ${total.toLocaleString()}원이에요 (예상 ${(dep * qty).toLocaleString()}원)`);
  if (problems.length) return { mismatch: problems.join(' · ') };
  if (!final) return { ready: true, total };
  if (final === 'dry') {   // 3.10.4 시험: '보증금 결제하기'로 동의 창만 열어서 체크 → 결제 버튼이 눌리는 상태인지 보고 닫아요 (결제 안 함)
    const rounds = [];
    for (let k = 0; k < 2; k++) {   // 3.10.8: 열기 → 체크 → 닫기를 두 번 (거절 뒤 다시 열어 다시 체크하는 흐름 확인)
      (payBtn() || pay).click(); let D = null;
      for (let i = 0; i < 20 && !D; i++) { await wait(300); D = await doLayer([pay], true); }
      rounds.push(D || { noLayer: true, said: said() }); await wait(1000);
    }
    return { dryRun: true, total, result: rounds[0], rounds };
  }
  const before = location.href, beforeText = t.length;
  // 3.9.6: 마지막 단계(보증금 결제하기 → 필수 동의 → 신청)에서도 크림이 '신규 보관 신청이 제한된…'으로 거절할 수 있어요.
  //        그러면 이 화면에 그대로 있으면서 동의 체크 → 신청을 gap초(+0~2초)마다 다시 눌러요.
  //        크림이 '거절'이라고 분명히 알려줬을 때만 다시 누르고, 결과가 불분명하면 두 번 신청되지 않게 멈춰요.
  const DONE_RE = /신청이?\s*완료|완료되었습니다|신청되었습니다|보관\s*신청\s*완료|접수되었습니다|결제가?\s*완료/;
  // 3.10.0: 성공 판단 — ① 화면이 넘어감 ② '완료' 문구 ③ 마지막 신청 뒤 크림 서버가 신청을 받아줌(보관 신청 주소에 2xx 응답)
  let finalT0 = Infinity;
  const serverOk = () => !net.some(x => x.t >= finalT0 && x.s >= 400) && net.some(x => x.t >= finalT0 && Date.now() - x.t > 1500 && x.m !== 'GET' && x.s >= 200 && x.s < 300 && /inventor|stock|payment|deposit/.test(x.u) && !/review/.test(x.u));   // 2xx 뒤 1.5초 동안 거절이 없어야 성공
  const isDone = () => location.href !== before || DONE_RE.test(document.body.innerText) || /\/my\/inventory|complete|success|result/.test(location.pathname) || serverOk();
  const REJ_RE = /제한|불가|마감|잠시\s*후|다시\s*시도|초과|실패|할\s*수\s*없|없습니다/;
  const gapMs = Math.max(5, +gapSec || 7) * 1000;
  const endF = T_END - 12000;   // 마지막 한 번 누르고 결과 볼 시간(약 10초)을 남겨요
  let agreed = null, tries = 0, lastRej = '', quick = true;   // 3.10.3: 거절되면 1초 뒤 한 번 더 → 그다음 gap초 쉬기 (반복)
  const rejSince = (t0, toast0) => {
    const n = net.filter(x => x.t >= t0 && x.s >= 400 && x.m !== 'GET');
    if (n.length) { try { return JSON.parse(n[n.length - 1].b).message || `크림 거절 (${n[n.length - 1].s})`; } catch (e) { return `크림 거절 (${n[n.length - 1].s})`; } }
    const now = said().filter(x => !toast0.has(x) && REJ_RE.test(x) && !/동의|모델번호/.test(x));
    if (now.length) return now[0];
    const m = window.__kcMsgs.find(x => REJ_RE.test(x)); if (m) { window.__kcMsgs = []; return m; }
    return '';
  };
  const finalOnce = async () => {
    tries++; const t0 = Date.now(), toast0 = new Set(said()); window.__kcMsgs = []; finalT0 = t0;
    // 3.10.5: 결제(신청) 버튼을 누르기 직전 표시를 남겨요 — 성공하면 크림이 화면을 새로 읽어서 이 기능이 끊기는데, 그때 이 표시로 성공을 알아봐요
    const mark = rej => { try { sessionStorage.setItem('kcFinal', JSON.stringify({ t: t0, rej, size, qty })); } catch (e) {} };
    mark(0);
    let L = await doLayer([pay]);   // 동의 창이 아직 떠 있으면 바로 체크 → 신청
    if (!L) {
      const p2 = payBtn() || pay; p2.click();
      for (let i = 0; i < 14; i++) { await wait(300); if (isDone()) return { done: true }; const r0 = rejSince(t0, toast0); if (r0) { mark(1); return { rej: r0 }; } L = await doLayer([p2]); if (L) break; }
    }
    if (L && L.fail) { await wait(600); const L2 = await doLayer([pay]); if (L2 && !L2.fail) L = L2; else return { fail: L2 || L }; }   // 한 번 더 체크해 보고
    if (L) agreed = L.titles;
    for (let i = 0; i < 90; i++) { await wait(100); if (isDone()) return { done: true }; const r1 = rejSince(t0, toast0); if (r1) { mark(1); return { rej: r1 }; } }
    await wait(1200); if (isDone()) return { done: true };
    if (!payBtn() && !rejSince(t0, toast0)) return { done: true, guessed: true };   // 결제 화면이 사라졌고 거절 안내도 없으면 신청된 걸로 봐요
    return { unknown: true };
  };
  for (;;) {
    if (window.__kcRun !== RUN) return { blocked: true, step: 'final', said: ['다른 실행이 시작돼서 멈춤'], finalTries: tries };
    const r = await finalOnce();
    if (r.done) { if (r.guessed) confirmed.push('결제 화면이 넘어가서 신청 완료로 판단'); break; }
    if (r.fail) return { blocked: true, step: 'agree', said: [r.fail.why].concat(r.fail.titles || [], said()), dom: r.fail.html || '', finalTries: tries };
    if (r.unknown) return { submitted: true, done: false, total, finalTries: tries, agreed: confirmed.concat(agreed || []), url: location.href.split('?')[0], said: said() };
    lastRej = r.rej;
    const waitF = quick ? Math.max(0, 1000 - (Date.now() - (window.__kcLastClick || 0))) : gapMs + Math.random() * 2000; quick = !quick;   // 1초 = 앞에서 누른 때부터
    if (Date.now() + waitF + 2000 > endF) return { blocked: true, step: 'final', said: [lastRej], finalTries: tries, quickNext: quick, agreed: confirmed.concat(agreed || []) };
    const end = Date.now() + waitF; while (Date.now() < end) { await wait(250); if (window.__kcRun !== RUN) return { blocked: true, step: 'final', said: [lastRej], finalTries: tries }; }
    if (!payBtn() && !isDone()) return { blocked: true, step: 'final', said: [lastRej, '결제 화면이 사라졌어요'], finalTries: tries };
  }
  const after = document.body.innerText;
  return { submitted: true, done: true, total, finalTries: tries, agreed: confirmed.concat(agreed || []), url: location.href.split('?')[0], said: said(), changed: location.href !== before || after.length !== beforeText };
}

// ---------- 3.4: 판매입찰 가격 바꾸기 (MAIN world) ----------
// 크림 판매 흐름(2026-11 크림 웹 코드 확인): 판매 입찰은 ask-requests 화면 단계(가격 입력 → 확인)로 진행되고, 입찰 변경은 같은 흐름에 ask_id 를 붙여 열려요.
// 실제 변경 화면은 아직 못 봐서, 글자로 버튼을 찾고 마지막 버튼 전에 화면의 가격·사이즈가 넣은 값과 같은지 반드시 확인해요.
// o = { target, from, size, code, final, list }
async function kcAskChange(o) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const txt = e => (e.innerText || e.value || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
  const norm = s => String(s || '').toUpperCase().replace(/\s+/g, '');
  const fmt = n => Number(n).toLocaleString('ko-KR');
  const digits = s => +(String(s || '').replace(/[^\d]/g, '') || 0);
  window.__kcMsgs = [];
  window.alert = m => { window.__kcMsgs.push(String(m)); };
  window.confirm = m => { window.__kcMsgs.push('[확인창] ' + String(m)); return false; };
  const said = () => { const pop = [...document.querySelectorAll('[class*=toast],[class*=modal],[class*=layer],[class*=popup],[class*=alert],[class*=snackbar],[role=dialog],[role=alert]')].filter(e => e.offsetParent && (e.innerText || '').trim()).map(e => e.innerText.trim().replace(/\s+/g, ' ').slice(0, 160)); return [...window.__kcMsgs, ...pop].filter((x, i, a) => a.indexOf(x) === i).slice(0, 4); };
  const clickables = () => [...document.querySelectorAll('a,button,[role=button]')].filter(vis);
  const find = (re, not) => clickables().find(e => { const t = txt(e); return t.length < 30 && re.test(t) && !(not && not.test(t)); });
  const NOT = /주소|배송지|카드|계좌|결제\s*수단|프로필|비밀번호|알림|쿠폰/;
  const CHG = /입찰\s*(가격\s*)?(변경|수정)|판매\s*희망가\s*(변경|수정)|가격\s*(변경|수정)|^변경(하기)?$|^수정(하기)?$/;
  for (let i = 0; i < 20 && (!document.body || document.body.innerText.length < 200); i++) await wait(400);
  await wait(800);
  // 0. 목록에서 들어온 경우: 사이즈와 지금 입찰가가 같이 보이는 가장 작은 줄을 눌러요
  if (o.list) {
    const cands = [...document.querySelectorAll('a,li,[role=button],div')].filter(e => vis(e) && e.innerText && e.innerText.length < 400)
      .filter(e => { const t = e.innerText; return t.includes(fmt(o.from)) && norm(t).includes(norm(o.size)); });
    const row = cands.sort((a, b) => a.innerText.length - b.innerText.length)[0];
    if (!row) return { error: 'nochg', why: '목록에서 그 입찰(사이즈·가격)을 못 찾았어요', url: location.href };
    (row.closest('a') || row).click();
    for (let i = 0; i < 20 && !find(CHG, NOT); i++) await wait(400);
  }
  // 1. 입찰 변경 버튼
  let chg = null;
  for (let i = 0; i < 15 && !(chg = find(CHG, NOT)); i++) await wait(400);
  if (!chg) return { error: 'nochg', url: location.href, said: said() };
  // 상세 화면이면 사이즈·지금 가격이 맞는지 먼저 확인
  const pageT = document.body.innerText;
  if (!norm(pageT).includes(norm(o.size))) return { mismatch: `화면에 사이즈 ${o.size}가 안 보여요` };
  chg.click();
  // 2. 가격 칸
  let inp = null;
  for (let i = 0; i < 25 && !inp; i++) {
    await wait(400);
    const all = [...document.querySelectorAll('input')].filter(e => vis(e) && !e.readOnly && !e.disabled && /^(text|number|tel|)$/i.test(e.getAttribute('type') || 'text'));
    inp = all.find(e => /희망가|판매가|입찰가|가격|price/i.test((e.placeholder || '') + ' ' + (e.name || '') + ' ' + (e.getAttribute('aria-label') || '') + ' ' + ((e.closest('div,label,section') || {}).innerText || '').slice(0, 80))) || (all.length === 1 ? all[0] : null);
  }
  if (!inp) return { error: '가격 넣는 칸을 못 찾았어요', url: location.href, said: said() };
  const setV = v => { inp.focus(); const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); d.set.call(inp, ''); inp.dispatchEvent(new Event('input', { bubbles: true })); d.set.call(inp, String(v)); inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); inp.dispatchEvent(new Event('blur', { bubbles: true })); };
  setV(o.target); await wait(700);
  if (digits(inp.value) !== o.target) { setV(fmt(o.target)); await wait(700); }
  if (digits(inp.value) !== o.target) return { mismatch: `가격 칸에 ${inp.value}가 들어갔어요 (넣으려던 값 ${fmt(o.target)})` };
  // 3. 계속 → 확인 화면
  const NEXT = /^(판매\s*입찰\s*계속|입찰\s*계속|변경\s*계속|계속|다음|다음\s*단계)$/;
  const FINAL = /^(판매\s*입찰(하기)?|입찰\s*변경(하기)?|변경(하기|완료)|가격\s*변경(하기)?|확인)$/;
  const nx = find(NEXT);
  if (nx) {
    if (nx.disabled || nx.classList.contains('disabled')) return { blocked: true, said: ["'계속'이 눌리지 않는 상태"].concat(said()) };
    nx.click();
  }
  let fin = null;
  for (let i = 0; i < 25; i++) { await wait(400); fin = find(FINAL, NOT); if ((fin && fin !== nx) || window.__kcMsgs.length) break; }
  if (!fin) return { blocked: true, step: 'review', said: said(), url: location.href };
  // 4. 확인 화면 검사: 새 가격과 사이즈가 보여야 하고, 모델번호를 알면 그것도
  const t = document.body.innerText;
  const problems = [];
  if (!t.includes(fmt(o.target))) problems.push(`확인 화면에 ${fmt(o.target)}원이 안 보여요`);
  if (!norm(t).includes(norm(o.size))) problems.push(`확인 화면에 사이즈 ${o.size}가 안 보여요`);
  const code = String(o.code || '').split('/').map(c => c.trim()).find(c => /\d/.test(c));
  if (code && !norm(t).includes(norm(code))) problems.push(`확인 화면에 모델번호 ${code}가 안 보여요`);
  if (problems.length) return { mismatch: problems.join(' · ') };
  if (!o.final) return { ready: true };
  // 필수 동의 체크 (판매 입찰 확인 화면의 안내 동의)
  for (const c of [...document.querySelectorAll('input[type=checkbox]')].filter(c => !c.checked && !c.disabled)) { const lb = c.closest('label') || c.parentElement; (vis(c) ? c : lb).click(); await wait(120); }
  await wait(400);
  if (fin.disabled || fin.classList.contains('disabled')) return { blocked: true, step: 'final', said: ['마지막 버튼이 눌리지 않는 상태 (동의 체크 확인 필요)'].concat(said()) };
  const before = location.href;
  fin.click();
  for (let i = 0; i < 40; i++) { await wait(300); if (location.href !== before || window.__kcMsgs.length || !document.body.contains(fin) || /완료|변경되었습니다|입찰되었습니다|등록되었습니다/.test(document.body.innerText)) break; }
  await wait(1200);
  const after = document.body.innerText;
  const done = /입찰\s*(이\s*)?(완료|변경)|변경\s*(이\s*)?완료|변경되었습니다|입찰되었습니다|등록되었습니다|판매\s*입찰\s*완료/.test(after);
  return { submitted: true, done, url: location.href.split('?')[0], said: said() };
}

// ---------- 2.7: 로그인 상태 · 자동 로그인 (계정 연결) ----------
// 화면이 로그인 화면인지 봐요: 주소에 login/signin, 보이는 비밀번호 칸, '로그인이 필요' 문구. '로그아웃'이 보이면 로그인된 상태.
async function kcLoginState() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 16 && (!document.body || document.body.innerText.length < 150) && !(i >= 3 && document.readyState === 'complete'); i++) await wait(400);
  await wait(300);
  const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const t = document.body ? document.body.innerText : '';
  const pw = [...document.querySelectorAll('input[type=password]')].filter(vis).length;
  const loginUrl = /(log-?in|sign-?in|\/auth\/|member\/login|memberlogin|account\/login)/i.test(location.href);
  const logout = /로그아웃|log\s*out|sign\s*out/i.test(t);
  // 3.8.1: '로그인 / 회원가입' 버튼만 보이는 마이페이지(4910 등)도 로그인 안 된 걸로 봐요
  const loginBtn = [...document.querySelectorAll('a,button')].some(e => vis(e) && /^로그인\s*\/\s*회원가입$/.test((e.innerText || '').trim()));
  const askLogin = /로그인\s*(이\s*)?필요|로그인\s*후\s*이용|로그인\s*해\s*주세요|로그인하세요/.test(t) || loginBtn;
  const captcha = /자동\s*입력\s*방지|보안\s*문자|captcha|로봇이\s*아닙니다|인증\s*번호|본인\s*인증|휴대폰\s*인증|2단계\s*인증|새로운\s*기기/i.test(t) || [...document.querySelectorAll('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],[class*=captcha i] img,img[class*=captcha i],[id*=captcha i] img')].some(vis);
  return { url: location.href, needLogin: pw > 0 || (loginUrl && !logout) || (askLogin && !logout), pw, captcha };
}
// 로그인 화면에서 아이디·비밀번호를 넣고 로그인 버튼을 눌러요 (사이트 화면 쪽에서 실행: world MAIN)
// 보안문자·인증이 보이면 넣지 않고 멈춰요. 아이디 로그인 칸이 숨어 있으면('이메일로 로그인' 등) 한 번 눌러서 열어 봐요.
async function kcLoginFill(id, pw) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const txt = e => (e.innerText || e.value || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
  const OPEN = /^(이메일|아이디|ID|일반\s*회원|통합\s*회원|이메일\s*로그인|아이디\s*로그인|이메일로\s*(로그인|시작|계속)|아이디로\s*로그인|다른\s*방법으로\s*로그인|이메일\/아이디)/i;
  let pwEl = null, opened = 0;
  for (let i = 0; i < 24; i++) {
    pwEl = [...document.querySelectorAll('input[type=password]')].find(vis);
    if (pwEl) break;
    if ((i === 4 || i === 10) && opened < 2) { const b = [...document.querySelectorAll('a,button,[role=button],label')].find(e => vis(e) && OPEN.test(txt(e))); if (b) { b.click(); opened++; } }
    await wait(500);
  }
  const body = document.body ? document.body.innerText : '';
  if (!pwEl) return { ok: false, why: /로그아웃/.test(body) && !/(log-?in|sign-?in)/i.test(location.href) ? 'already' : 'nopw' };
  // 3.29.2: 숨겨 둔 보안문자 칸(G마켓은 로그인 화면에 늘 숨겨 둬요)은 보안문자로 보지 않아요 — 화면에 보일 때만
  const capVis = [...document.querySelectorAll('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],[class*=captcha i] img,img[class*=captcha i],[id*=captcha i] img')].some(vis);
  if (capVis || [...document.querySelectorAll('p,span,div,label,strong,em')].some(e => !e.children.length && vis(e) && /자동\s*입력\s*방지|보안\s*문자|로봇이\s*아닙니다/.test(e.innerText || ''))) return { ok: false, why: 'captcha' };
  // 3.29.2: 로그인 버튼이 들어 있는 곳까지 위로 올라가며 찾아요 (G마켓은 비밀번호 칸 바로 위 상자에 버튼이 없어요)
  const LBTN = /^(로그인|로그인하기|LOGIN|Log\s*in|Sign\s*in)$/i;
  const hasBtn = el => [...el.querySelectorAll('button,input[type=submit],input[type=button],a,[role=button]')].some(e => vis(e) && (LBTN.test(txt(e)) || (e.getAttribute('type') || '').toLowerCase() === 'submit'));
  let scope = pwEl.form;
  if (!scope || !hasBtn(scope)) { scope = null; for (let x = pwEl.parentElement; x && x !== document.body; x = x.parentElement) { if (hasBtn(x)) { scope = x; break; } } }
  scope = scope || document.body;
  const cands = [...scope.querySelectorAll('input')].filter(e => vis(e) && /^(text|email|tel|)$/i.test(e.getAttribute('type') || 'text') && !e.readOnly);
  let idEl = cands.filter(e => e.compareDocumentPosition(pwEl) & Node.DOCUMENT_POSITION_FOLLOWING).pop() || cands[0];
  if (!idEl) idEl = [...document.querySelectorAll('input')].filter(e => vis(e) && /^(text|email|tel|)$/i.test(e.getAttribute('type') || 'text')).filter(e => e.compareDocumentPosition(pwEl) & Node.DOCUMENT_POSITION_FOLLOWING).pop();
  if (!idEl) return { ok: false, why: 'nopw' };
  const setV = (el, v) => { el.focus(); const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); d.set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); el.dispatchEvent(new Event('blur', { bubbles: true })); };
  setV(idEl, id); await wait(150); setV(pwEl, pw); await wait(400);
  // 3.4.2: '로그인 상태 유지 · 자동 로그인' 체크가 있으면 켜요 (껐다 켜도 로그인이 안 풀리게)
  try {
    const KEEP = /(로그인\s*(상태\s*)?유지|자동\s*로그인|로그인\s*기억|keep\s*(me\s*)?(logged|signed)|remember\s*me|stay\s*signed)/i;
    for (const cb of document.querySelectorAll('input[type=checkbox]')) {
      if (cb.checked) continue;
      const lab = (cb.labels && cb.labels[0]) || cb.closest('label') || cb.parentElement;
      const t = ((lab && lab.innerText) || '') + ' ' + (cb.getAttribute('aria-label') || '') + ' ' + (cb.id || '') + ' ' + (cb.name || '');
      if (!KEEP.test(t) && !/(keep|auto_?login|autologin|remember|persist)/i.test((cb.id || '') + (cb.name || ''))) continue;
      const lv = lab && vis(lab) ? lab : null;
      if (vis(cb)) cb.click(); else if (lv) lv.click(); else { cb.checked = true; cb.dispatchEvent(new Event('change', { bubbles: true })); }
      await wait(150);
      if (!cb.checked) { cb.checked = true; cb.dispatchEvent(new Event('input', { bubbles: true })); cb.dispatchEvent(new Event('change', { bubbles: true })); }
    }
  } catch (e) {}
  const btns = [...scope.querySelectorAll('button,input[type=submit],a,[role=button]')].filter(vis);
  const after = e => !!(pwEl.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING), inNav = e => !!e.closest('header,nav,[class*=gnb i],[class*=header i]');
  const btn = btns.find(e => LBTN.test(txt(e)) && after(e) && !inNav(e)) || btns.find(e => /^(로그인|로그인하기|LOGIN|Log in|Sign in|확인)$/i.test(txt(e)) && !inNav(e)) || btns.find(e => (e.getAttribute('type') || '').toLowerCase() === 'submit' && !inNav(e));
  if (btn) btn.click();
  else if (pwEl.form) { if (pwEl.form.requestSubmit) pwEl.form.requestSubmit(); else pwEl.form.submit(); }
  else { pwEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true })); }
  return { ok: true, clicked: btn ? txt(btn).slice(0, 20) : 'enter' };
}

// ---------- 3.3: 아무 화면의 표 읽기 (크림 판매자 센터처럼 아직 구조를 모르는 화면용) ----------
function kcTableRead() {
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const T = s => (s || '').replace(/\s+/g, ' ').trim();
  let best = null;
  for (const t of document.querySelectorAll('table')) { if (!vis(t)) continue; const n = t.querySelectorAll('tbody tr').length || t.querySelectorAll('tr').length - 1; if (!best || n > best.n) best = { t, n }; }
  if (best && best.n > 0) {
    const head = [...best.t.querySelectorAll('thead th, thead td')].map(x => T(x.innerText));
    const trs = [...best.t.querySelectorAll('tbody tr')].length ? [...best.t.querySelectorAll('tbody tr')] : [...best.t.querySelectorAll('tr')].slice(1);
    return { url: location.href, title: document.title, kind: 'table', head, rows: trs.filter(vis).map(tr => [...tr.children].map(td => T(td.innerText))).slice(0, 500) };
  }
  const rr = [...document.querySelectorAll('[role=row]')].filter(vis);
  if (rr.length > 1) { const cells = r => [...r.querySelectorAll('[role=cell],[role=gridcell],[role=columnheader]')].map(c => T(c.innerText)); return { url: location.href, title: document.title, kind: 'grid', head: cells(rr[0]), rows: rr.slice(1).map(cells).slice(0, 500) }; }
  const items = [...document.querySelectorAll('li,[class*=item],[class*=Item],[class*=row],[class*=Row],[class*=card],[class*=Card]')].filter(e => vis(e) && /[\d,]{3,}\s*원/.test(e.innerText) && e.innerText.length < 500);
  const top = items.filter(e => !items.some(o => o !== e && e.contains(o)));
  return { url: location.href, title: document.title, kind: 'list', head: [], rows: top.slice(0, 300).map(e => [T(e.innerText)]) };
}
// ---------- 3.3: 무신사 후기 — 내 후기 화면에서 그 주문의 '후기 작성'을 눌러요 (world MAIN) ----------
async function kcMsReviewOpen(no, name) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const BTN = /^(후기\s*(작성|쓰기)(하기)?|리뷰\s*(작성|쓰기)(하기)?|작성하기)$/;
  const find = () => [...document.querySelectorAll('a,button,[role=button]')].filter(e => vis(e) && BTN.test((e.innerText || '').replace(/\s+/g, ' ').trim()));
  // 3.36.1: 머리글에도 '후기' 글자가 있어서 그걸로는 목록이 다 그려졌는지 몰라요 — 버튼이 나올 때까지(최대 12초) 기다려요
  let btns = [];
  for (let i = 0; i < 30 && !(btns = find()).length; i++) await wait(400);
  const key = [String(no || ''), String(name || '').slice(0, 14)].filter(Boolean);
  let hit = null;
  for (const b of btns) { let a = b; for (let d = 0; d < 7 && a; d++, a = a.parentElement) { const t = a.innerText || ''; if (key.some(k => k && t.includes(k))) { hit = b; break; } } if (hit) break; }
  if (!hit && btns.length === 1) hit = btns[0];
  if (!hit) return { ok: false, why: btns.length ? 'match' : 'nobtn', n: btns.length };
  const href = hit.closest('a[href]') && hit.closest('a[href]').href;
  hit.click();
  return { ok: true, href: href || '' };
}
// 후기 화면에 내가 쓴 글과 별점을 넣어요 (등록은 직접 눌러요)
async function kcReviewFill(text, stars) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  let ta = null;
  for (let i = 0; i < 30; i++) { ta = [...document.querySelectorAll('textarea')].filter(vis).sort((a, b) => b.getBoundingClientRect().height - a.getBoundingClientRect().height)[0]; if (ta) break; await wait(400); }
  if (!ta) return { ok: false, why: 'notext' };
  await wait(600);
  const setV = (el, v) => { el.focus(); const d = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value'); d.set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const press = el => { for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })); if (typeof el.click === 'function') el.click(); else el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); };
  let star = false;
  const n = Math.max(1, Math.min(5, +stars || 5));
  // 3.36.1: 무신사 별점 = StarScore__StarGroup 안 별 5개(숨은 input + 그림). 별 묶음은 '그림이 든 칸 5개'로 찾아요
  const sg = document.querySelector('[class*=StarScore__StarGroup]') || [...document.querySelectorAll('div,ul,fieldset')].filter(vis).find(g => g.children.length === 5 && [...g.children].every(c => c.querySelector('svg,img,i')) && /별점|어떠셨/.test((g.parentElement || g).innerText || ''));
  const lab = [...document.querySelectorAll('[aria-label],[title]')].filter(vis).find(e => new RegExp(`^\\s*(별점\\s*)?${n}\\s*(점|개|stars?)`).test(e.getAttribute('aria-label') || e.getAttribute('title') || ''));
  if (sg && sg.children[n - 1]) { const c = sg.children[n - 1]; press(c.querySelector('svg') || c); star = true; }
  else if (lab) { press(lab); star = true; }
  // 3.36.1: 만족도 질문(필수) — 질문마다 동그라미 5개, 맨 왼쪽이 가장 좋은 답(매우 만족 · 매우 가벼움 …)
  let sat = 0;
  const groups = [...document.querySelectorAll('[class*=Answer__AnswerGroup]')];
  for (const g of groups) { const b = g.querySelector('button'); if (b) { press(b); sat++; await wait(150); } }
  setV(ta, text);
  // 3.36.1: 필수 동의 (전체 동의하기 · 홍보 콘텐츠 사용 동의) — 동의 글이 붙은 체크칸만
  let agree = 0;
  const isOn = e => e.getAttribute('aria-checked') === 'true' || e.checked === true || e.getAttribute('data-state') === 'checked';
  for (let k = 0; k < 2; k++) {
    const boxes = [...document.querySelectorAll('button[role=checkbox],input[type=checkbox],[role=checkbox]')].filter(e => /동의/.test(((e.closest('label') || e.parentElement || {}).innerText || '') + ' ' + ((e.parentElement && e.parentElement.parentElement || {}).innerText || '')));
    const off = boxes.filter(e => !isOn(e));
    if (!off.length) { agree = boxes.length; break; }
    press(off[0]); await wait(300);
  }
  ta.scrollIntoView({ block: 'center' });
  return { ok: true, star, sat, satNeed: groups.length, agree, len: text.length };
}

// 3.16.1: 슈프라이즈 발매 정보 읽기 (공개된 발매 목록 화면을 사람처럼 열어서 카드만 읽어요)
async function kcShoePrize() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 30 && !document.querySelector('a.c-card__link'); i++) { if (/등록된 발매 정보가 없습니다/.test(document.body ? document.body.innerText : '')) break; await wait(500); }
  // 아래로 내려가며 더 불러오기
  let last = -1;
  for (let i = 0; i < 12; i++) { const n = document.querySelectorAll('a.c-card__link').length; if (n === last) break; last = n; window.scrollTo(0, document.body.scrollHeight); await wait(900); }
  const T = (el, sel) => { const e = el.querySelector(sel); return e ? e.innerText.replace(/\s+/g, ' ').trim() : ''; };
  const items = [...document.querySelectorAll('a.c-card__link')].map(a => {
    const img = a.querySelector('img'), src = img ? (img.getAttribute('src') || '') : '';
    const code = (decodeURIComponent(src).match(/\/thumb\/([A-Za-z0-9]+(?:-[A-Za-z0-9]{2,4})?)-shoeprize/) || [])[1] || '';
    const det = [...a.querySelectorAll('.c-card__detail dd span, .c-card__detail dd')].map(e => e.children.length ? '' : e.innerText.trim()).filter(Boolean);
    return { href: new URL(a.getAttribute('href'), location.origin).href, brand: T(a, '.c-card__brand dd'), name: T(a, '.c-card__name dd') || (img && img.alt) || '', detail: [...new Set(det)].join(' · '), date: T(a, '.c-card__time dd') || T(a, '.c-card__date'), img: src, code: code.toUpperCase() };
  }).filter(x => x.name);
  return { url: location.href, items, empty: !items.length };
}

// 3.15.1: 후기 등록 버튼 누르기 — 확인창은 자동으로 '확인', 알림창 문구는 모아서 결과로 돌려줘요
async function kcReviewSubmit() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const msgs = []; window.__kcAlerts = msgs;
  try { window.alert = m => { msgs.push(String(m)); }; window.confirm = m => { msgs.push(String(m)); return true; }; } catch (e) {}
  const txt = e => (e.innerText || e.value || '').replace(/\s+/g, ' ').trim();
  const SUB = /^(후기\s*)?(등록|등록하기|작성\s*완료|작성하기|완료|저장)$/;
  const btn = [...document.querySelectorAll('button,a,[role=button],input[type=submit]')].filter(e => vis(e) && SUB.test(txt(e)) && !e.disabled && e.getAttribute('aria-disabled') !== 'true').pop();
  if (!btn) return { ok: false, msg: '등록 버튼을 못 찾음' };
  const before = location.href, ta0 = [...document.querySelectorAll('textarea')].filter(vis).length;
  btn.click();
  for (let i = 0; i < 25; i++) {
    await wait(400);
    // 확인 모달(등록하시겠어요? → 확인)
    const ok = [...document.querySelectorAll('button,[role=button]')].filter(e => vis(e) && /^(확인|등록|네|예)$/.test(txt(e)) && e !== btn && e.closest('[role=dialog],[class*=modal i],[class*=Modal],[class*=popup i],[class*=dialog i]'));
    if (ok.length) { ok[ok.length - 1].click(); await wait(800); }
    const body = document.body ? document.body.innerText : '';
    if (/등록(이)?\s*완료|등록되었습니다|작성(이)?\s*완료|감사합니다|적립(될|됩니다|예정)/.test(body + ' ' + msgs.join(' '))) return { ok: true, msg: '등록됨' };
    if (msgs.some(m => /(입력|작성)해\s*주세요|최소|이상\s*입력|선택해\s*주세요|실패|오류|불가/.test(m))) return { ok: false, msg: msgs.join(' / ').slice(0, 120) };
    if (location.href !== before && !/write|edit/i.test(location.pathname)) return { ok: true, msg: '등록됨 (화면 이동)' };
    if (ta0 && ![...document.querySelectorAll('textarea')].filter(vis).length) return { ok: true, msg: '등록됨 (작성 칸 닫힘)' };
  }
  return { ok: false, msg: msgs.length ? msgs.join(' / ').slice(0, 120) : '등록 결과를 확인 못 함 — 무신사 후기 화면에서 확인해 주세요' };
}

// 3.7: 화면이 비었는지 보기 (웨일 연결에서도 이름으로 불러요)
// 3.9.8: 보관 신청 결과 화면인지 (결제 후 화면이 넘어가서 결과를 못 받았을 때 확인용)
function kcStockAbort() { window.__kcRun = null; return true; }
function kcStockClearMark() { try { sessionStorage.removeItem('kcFinal'); } catch (e) {} return true; }
async function kcStockDoneCheck() {
  for (let i = 0; i < 20 && (!document.body || document.body.innerText.length < 100); i++) await new Promise(r => setTimeout(r, 300));
  const t = document.body ? document.body.innerText : '';
  const done = /신청이?\s*완료|완료되었습니다|신청되었습니다|보관\s*신청\s*완료|접수되었습니다|결제가?\s*완료/.test(t) || /complete|success|result|\/my\/inventory/.test(location.pathname);
  const pay = [...document.querySelectorAll('a,button')].some(b => /보증금\s*결제하기/.test(b.innerText || ''));
  let marker = null; try { marker = JSON.parse(sessionStorage.getItem('kcFinal') || 'null'); } catch (e) {}
  return { url: location.pathname, done: done && !pay, pay, marker, head: t.replace(/\s+/g, ' ').slice(0, 200) };
}
function kcPageInfo() { return { n: document.documentElement.outerHTML.length, title: document.title, url: location.href }; }

// ---------- 3.10.19/3.10.22: 크림 보관판매 내역 전부 읽기 (크림 마이페이지 → 보관판매가 쓰는 주소, 2026-11-16 확인) ----------
// 신청(발송요청·발송완료·입고대기·입고완료·검수 중·검수완료·창고이동) · 보관 중(판매대기·판매 중·판매완료…) · 종료(정산완료·취소완료·불합격 반송·회수완료)
// 한 줄 = 상품 1개. 읽기만 해요(신청·취소 없음).
// 3.10.22: 직접 요청이 막히면(Failed to fetch) 화면의 상태 버튼·쪽 번호를 눌러서 크림 화면이 스스로 불러온 응답을 모아요.
// 3.36.4: 크림 일반 판매 내역(종료 · 진행 중 탭) 전부 — 화면은 25건씩만 불러와서, 다음 쪽은 화면과 같은 머리글로 직접 받아요
async function kcKreamAsks(tab) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const re = new RegExp('/asks/?[?](.*&)?tab=' + tab + '(&|$)');
  let cap = null;
  for (let i = 0; i < 20 && !(cap = (window.__kcMyCap || []).find(c => re.test(c.url) && c.data && Array.isArray(c.data.items))); i++) await wait(500);
  if (!cap) return { error: '크림 판매 내역 화면을 못 읽었어요' };
  const H = Object.assign({ accept: 'application/json' }, window.__kcMyHdr || {});
  const base = new URL(cap.url, location.href);
  const pages = [cap.data]; let cur = cap.data.next_cursor, n = 0;
  while (cur && n++ < 40) {
    base.searchParams.set('cursor', cur); let d = null;
    for (const cred of ['include', 'omit']) { try { const r = await fetch(base.href, { credentials: cred, headers: H }); if (r.ok) { d = await r.json(); break; } } catch (e) {} }
    if (!d) return { pages, short: true, total: cap.data.total };
    pages.push(d); cur = d.next_cursor; await wait(250);
  }
  return { pages, total: cap.data.total };
}
// 3.36.5: 판매 건 상세를 페이지를 하나씩 열지 않고 화면과 같은 머리글로 바로 받아요 (한 건 3초 → 0.2초)
async function kcKreamAskDetails(ids) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  let cap = null;
  for (let i = 0; i < 20 && !(cap = (window.__kcMyCap || []).find(c => /\/asks\/?[?]/.test(c.url) && c.data)); i++) await wait(500);
  const H = Object.assign({ accept: 'application/json' }, window.__kcMyHdr || {});
  const b = cap ? new URL(cap.url, location.href) : new URL('https://kream.co.kr/api/o/asks/');
  const root = b.origin + b.pathname.replace(/\/asks\/?$/, '/asks/');
  const out = {}, fails = [];
  for (const id of ids || []) {
    let d = null;
    for (const cred of ['include', 'omit']) { try { const r = await fetch(root + id, { credentials: cred, headers: H }); if (r.ok) { d = await r.json(); break; } } catch (e) {} }
    if (!d || String(d.id) !== String(id)) { fails.push(id); continue; }
    const pb = d.price_breakdown || {}, rel = (d.product || {}).release || {}, op = d.product_option || {};
    out[id] = { status: d.status || '', status_display: d.status_display || '', price: +pb.price || +d.price || 0, payout: +pb.total_payout || 0, option: typeof d.option === 'string' ? d.option : '', opKey: op.key || '', opName: op.name_display || '', code: rel.style_code || '', name: rel.translated_name || rel.name || '', pid: d.product_id || '', date_paid: d.date_paid || '', date_updated: d.date_updated || '', date_created: d.date_created || '' };
    await wait(150);
  }
  return { out, fails, root };
}
async function kcKreamInvAll() {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 20 && !(window.__kcMyCap && window.__kcMyCap.length); i++) await wait(500);
  const KINDS = { requested: '신청', in_stock: '보관 중', finished: '종료' };
  const DEF = { requested: 'shipment_required', in_stock: 'in_storage', finished: 'payout_completed' };
  const map = it => { const rel = (it.product || {}).release || {}, op = it.product_option || {}; const pb = it.price_breakdown || {}; return { id: it.id, status: it.status || '', code: rel.style_code || '', name: rel.translated_name || rel.name || '', size: op.key || op.name_display || '', sizeName: op.name_display || '', pid: it.product_id || op.product_id || '', date: it.date_paid || it.date_updated || it.date_created || '', price: +pb.price || +it.price || 0, payout: +pb.total_payout || +it.total_payout || 0 }; };
  const capOf = (kind, status) => (window.__kcMyCap || []).filter(c => c.url.includes('/inventory/items/' + kind + '?') && new RegExp('[?&]status=' + status + '(&|$)').test(c.url) && c.data);
  const byId = new Map(), counts = {};
  const add = (kind, status, name, list) => { for (const it of list || []) { const m = map(it); m.kind = kind; m.statusName = name; if (!m.status) m.status = status; byId.set(m.id, m); } };
  // 2) 직접 요청 (화면과 같은 머리글) — 막히면 3)으로
  const H = Object.assign({ accept: 'application/json' }, window.__kcMyHdr || {});
  let direct = true;
  const get = async (kind, status, cursor) => {
    const u = `https://api.kream.co.kr/api/seller/inventory/items/${kind}?per_page=20&cursor=${cursor}&keyword=&status=${encodeURIComponent(status)}`;
    let last;
    for (const cred of ['omit', 'include']) { try { const r = await fetch(u, { credentials: cred, headers: H, mode: 'cors' }); if (r.ok) return r.json(); last = new Error('HTTP ' + r.status); } catch (e) { last = e; } }
    throw last;
  };
  // 1) 상태별 개수: 처음 화면이 불러온 응답에서 — 3.36.4: 화면이 안 불러온 탭(보관 중 · 종료)은 첫 쪽을 직접 받아서 (예전엔 '신청' 탭만 읽어서 판매된 보관 건을 못 가져왔어요)
  const sts = [];
  for (const kind of Object.keys(KINDS)) {
    const f = capOf(kind, DEF[kind])[0] || (window.__kcMyCap || []).find(c => c.url.includes('/inventory/items/' + kind + '?') && c.data && c.data.filters_extended);
    let fd = f && f.data;
    if (!(fd && fd.filters_extended)) { try { fd = await get(kind, DEF[kind], 1); } catch (e) {} }
    for (const x of (((fd && fd.filters_extended) || {}).status || [])) if (x && x.value) { counts[x.value] = { kind, name: x.name, count: +x.count || 0 }; sts.push({ kind, value: x.value, name: x.name, count: +x.count || 0 }); }
  }
  if (!sts.length) return { error: '크림 보관판매 화면을 못 읽었어요 (로그인 확인)', items: [], counts };
  for (const s of sts.filter(x => x.count > 0)) {
    if (!direct) break;
    try { let cur = 1, n = 0; while (n++ < 60) { const page = await get(s.kind, s.value, cur); add(s.kind, s.value, s.name, page.items); if (!page.next_cursor || !(page.items || []).length) break; cur = page.next_cursor; await wait(250); } }
    catch (e) { direct = false; }
  }
  if (direct) return { items: [...byId.values()], counts, via: 'api', at: Date.now() };
  // 3) 화면 버튼으로: 탭 → 상태 → 쪽 번호
  byId.clear();
  const clickText = lb => { const el = [...document.querySelectorAll('a,button,li,[role=tab],span,div')].find(e => e.children.length < 4 && (e.innerText || '').replace(/\s+/g, ' ').trim().startsWith(lb) && e.offsetParent !== null); if (el) { el.click(); return true; } return false; };
  const pageBtn = n => { const el = [...document.querySelectorAll('a,button,li')].find(e => (e.innerText || '').trim() === String(n) && e.offsetParent !== null && (e.closest('[class*=pagin],[class*=Pagin],nav,ul') || e.parentElement)); if (el) { el.click(); return true; } return false; };
  for (const s of sts.filter(x => x.count > 0)) {
    clickText(KINDS[s.kind]); await wait(1500);
    clickText(s.name); await wait(1800);
    const pages = Math.ceil(s.count / 20);
    for (let p = 2; p <= pages; p++) { if (!pageBtn(p)) break; await wait(1800); }
    for (const c of capOf(s.kind, s.value)) add(s.kind, s.value, s.name, c.data.items);
  }
  const items = [...byId.values()];
  const want = sts.reduce((a, x) => a + x.count, 0);
  return { items, counts, via: 'screen', at: Date.now(), short: items.length < want ? want - items.length : 0 };
}

// ---------- 3.10.45: 크림 판매 입찰 걸기 · 바꾸기 · 기한 연장 (크림 판매 화면 /sell/상품번호?size=사이즈[&ask=입찰번호], 2026-11-16 확인) ----------
// 화면: '판매 입찰 | 즉시 판매' 탭 → 판매 희망가 칸 → 입찰 마감기한(1일 3일 7일 30일 60일 90일 180일) → '판매 입찰 계속' → 확인 화면 → 마지막 버튼
// o = { price, days(0이면 그대로), size, final(true면 마지막 버튼까지), name }
// 안전장치: 사이즈가 화면에 없으면 · 가격 칸에 다른 값이 들어가면 · 확인 화면에 가격/사이즈/기한이 안 보이면 마지막 버튼을 누르지 않아요.
async function kcAskPlace(o) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const txt = e => (e.innerText || e.value || '').replace(/\s+/g, ' ').trim();
  const norm = s => String(s || '').toUpperCase().replace(/\s+/g, '');
  const fmt = n => Number(n).toLocaleString('ko-KR');
  const digits = s => +(String(s || '').replace(/[^\d]/g, '') || 0);
  window.__kcMsgs = [];
  window.alert = m => { window.__kcMsgs.push(String(m)); };
  window.confirm = m => { window.__kcMsgs.push('[확인창] ' + String(m)); return false; };
  const said = () => { const pop = [...document.querySelectorAll('[class*=toast],[class*=modal],[class*=layer],[class*=popup],[class*=alert],[class*=snackbar],[role=dialog],[role=alert]')].filter(e => e.offsetParent && (e.innerText || '').trim()).map(e => e.innerText.trim().replace(/\s+/g, ' ').slice(0, 160)); return [...window.__kcMsgs, ...pop].filter((x, i, a) => a.indexOf(x) === i).slice(0, 4); };
  const els = () => [...document.querySelectorAll('a,button,[role=button],[role=tab],li,label,span,div')].filter(e => vis(e) && e.children.length < 4);
  const exact = re => els().filter(e => re.test(txt(e))).sort((a, b) => txt(a).length - txt(b).length)[0];
  for (let i = 0; i < 25 && (!document.body || document.body.innerText.length < 200); i++) await wait(400);
  await wait(1200);
  if (/\/login/.test(location.pathname)) return { error: '크림 로그인이 필요해요' };
  if (!/\/sell\//.test(location.pathname)) return { error: '크림 판매 화면이 아니에요: ' + location.pathname };
  // 1. '판매 입찰' 탭 (즉시 판매 아님)
  const tab = exact(/^판매\s*입찰$/); if (tab) { tab.click(); await wait(700); }
  if (!/판매\s*희망가/.test(document.body.innerText)) return { error: "'판매 희망가' 칸이 안 보여요 (판매 입찰 탭을 못 열었어요)", said: said() };
  // 2. 사이즈 확인
  if (!norm(document.body.innerText).includes(norm(o.size))) return { mismatch: `화면에 사이즈 ${o.size}가 안 보여요` };
  // 3. 가격
  const inputs = [...document.querySelectorAll('input')].filter(e => vis(e) && !e.readOnly && !e.disabled && /^(text|number|tel|)$/i.test(e.getAttribute('type') || 'text'));
  const inp = inputs.find(e => /희망가|판매가|입찰가|가격|price/i.test((e.placeholder || '') + ' ' + (e.name || '') + ' ' + ((e.closest('div,label,section,dl') || {}).innerText || '').slice(0, 80))) || (inputs.length === 1 ? inputs[0] : null);
  if (!inp) return { error: '가격 넣는 칸을 못 찾았어요', said: said() };
  const setV = v => { inp.focus(); const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); d.set.call(inp, ''); inp.dispatchEvent(new Event('input', { bubbles: true })); d.set.call(inp, String(v)); inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); inp.dispatchEvent(new Event('blur', { bubbles: true })); };
  setV(o.price); await wait(700);
  if (digits(inp.value) !== +o.price) { setV(fmt(o.price)); await wait(700); }
  if (digits(inp.value) !== +o.price) return { mismatch: `가격 칸에 ${inp.value}가 들어갔어요 (넣으려던 값 ${fmt(o.price)})` };
  // 3.10.48: 크림은 가격을 넣고 '화면 빈 곳을 한 번 클릭'해야 가격이 확정되고 '판매 입찰 계속'이 열려요 (사장님 확인)
  const clickEmpty = async () => {
    inp.dispatchEvent(new FocusEvent('focusout', { bubbles: true })); inp.blur();
    const y = Math.round(innerHeight * 0.35); let el = document.elementFromPoint(6, y);
    if (!el || el.closest('a,button,input,select,textarea,[role=button],label')) el = document.body;
    for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window, clientX: 6, clientY: y }));
    await wait(700);
  };
  await clickEmpty();
  if (digits(inp.value) !== +o.price) return { mismatch: `가격 칸에 ${inp.value}가 들어갔어요 (넣으려던 값 ${fmt(o.price)})` };
  // 4. 입찰 마감기한
  if (o.days) { const d = exact(new RegExp('^' + o.days + '\\s*일$')); if (!d) return { error: `입찰 마감기한 ${o.days}일 버튼을 못 찾았어요` }; d.click(); await wait(600); if (!new RegExp(o.days + '\\s*일').test(document.body.innerText)) return { mismatch: `기한 ${o.days}일이 선택되지 않았어요` }; }
  // 5. 계속
  const btns = () => [...document.querySelectorAll('button,a,[role=button]')].filter(vis);
  const btnList = () => btns().map(e => txt(e)).filter(t => t && t.length < 40).slice(-30);
  // 3.10.46: '판매 입찰 계속' 버튼은 안에 글자 조각이 여럿이라 버튼 요소 기준으로 '계속'이 들어간 것을 찾아요
  // 3.10.47: 가격을 넣은 뒤 아래쪽 버튼이 늦게 나타나요 → 맨 아래로 내리고 최대 8초 기다리며 '계속'이 들어간 가장 작은 요소(태그 상관없이)를 찾아요
  await clickEmpty();
  let nx = null;
  for (let i = 0; i < 20 && !nx; i++) {
    window.scrollTo(0, document.body.scrollHeight); await wait(400);
    const cand = [...document.querySelectorAll('body *')].filter(e => { const t = txt(e); return t && t.length < 20 && /계속/.test(t) && !/즉시/.test(t) && vis(e); }).sort((a, b) => txt(a).length - txt(b).length || a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    nx = cand[0] ? (cand[0].closest('button,a,[role=button]') || cand[0]) : null;
  }
  if (!nx) { const hid = [...document.querySelectorAll('body *')].filter(e => /계속/.test(e.textContent || '') && (e.textContent || '').length < 30).slice(-4).map(e => { const r = e.getBoundingClientRect(), cs = getComputedStyle(e); return `${e.tagName}.${String(e.className).slice(0, 30)} ${Math.round(r.width)}x${Math.round(r.height)} ${cs.display}/${cs.visibility} '${(e.textContent || '').trim().slice(0, 20)}'`; });
    const fee = (document.body.innerText.match(/정산\s*금액[^\n]*\n?[^\n]*/) || [''])[0].replace(/\s+/g, ' ');
    return { error: "'판매 입찰 계속' 버튼을 못 찾았어요", said: said(), btns: btnList(), hid, input: inp.value, fee, url: location.href }; }
  if (nx.disabled || /disabled/.test(nx.className || '') || nx.getAttribute('aria-disabled') === 'true') return { blocked: true, said: ["'판매 입찰 계속'이 눌리지 않아요 (가격 확인 필요)"].concat(said()) };
  const before = location.href; nx.click();
  for (let i = 0; i < 30; i++) { await wait(400); if (location.href !== before || !document.body.contains(nx) || !vis(nx) || window.__kcMsgs.length) break; }
  await wait(1000);
  if (window.__kcMsgs.length && document.body.contains(nx) && vis(nx)) return { blocked: true, said: said() };
  // 6. 확인 화면 검사
  const t = document.body.innerText;
  const problems = [];
  if (!t.includes(fmt(o.price))) problems.push(`확인 화면에 ${fmt(o.price)}원이 안 보여요`);
  if (!norm(t).includes(norm(o.size))) problems.push(`확인 화면에 사이즈 ${o.size}가 안 보여요`);
  if (o.days && !new RegExp(o.days + '\\s*일').test(t)) problems.push(`확인 화면에 기한 ${o.days}일이 안 보여요`);
  if (problems.length) return { mismatch: problems.join(' · '), text: t.replace(/\s+/g, ' ').slice(0, 600), btns: btnList(), url: location.href };
  const FIN = /^(판매\s*입찰\s*하기|판매\s*입찰\s*등록|입찰\s*변경\s*하기|입찰\s*하기|변경\s*하기|판매\s*입찰\s*변경)$/;
  const fin = [...document.querySelectorAll('button,a,[role=button]')].filter(e => vis(e) && FIN.test(txt(e))).pop();
  if (!fin) return { blocked: true, step: 'review', said: ['확인 화면의 마지막 버튼을 못 찾았어요'].concat(said()), text: t.replace(/\s+/g, ' ').slice(0, 600), btns: btnList(), url: location.href };
  if (!o.final) return { ready: true, btn: txt(fin) };
  // 7. 동의 체크 → 마지막 버튼
  for (const c of [...document.querySelectorAll('input[type=checkbox]')].filter(c => !c.checked && !c.disabled)) { const lb = c.closest('label') || c.parentElement; (vis(c) ? c : lb).click(); await wait(150); }
  await wait(500);
  if (fin.disabled || /disabled/.test(fin.className || '') || fin.getAttribute('aria-disabled') === 'true') return { blocked: true, step: 'final', said: ['마지막 버튼이 눌리지 않아요 (동의 확인 필요)'].concat(said()) };
  const b2 = location.href; fin.click();
  for (let i = 0; i < 40; i++) { await wait(300); if (location.href !== b2 || window.__kcMsgs.length || !document.body.contains(fin) || /완료|등록되었|변경되었|입찰되었/.test(document.body.innerText)) break; }
  await wait(1500);
  const after = document.body.innerText;
  const done = /입찰\s*(이\s*)?(완료|변경|등록)|변경\s*(이\s*)?완료|변경되었습니다|입찰되었습니다|등록되었습니다|판매\s*입찰\s*완료/.test(after) || /\/my\/selling/.test(location.pathname);
  return { submitted: true, done, url: location.href.split('?')[0], said: said() };
}

// 3.26: 여러 쇼핑몰 공통 재고 읽기 — 구조화 데이터 · 옵션 라디오 · 선택 상자 · 드롭다운(눌러서 열기)에서 사이즈별 품절 여부를 읽어요. 나이키는 나이키 재고 API를 써요.
async function kcGenStock(site) {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const mev = t => { try { return new MouseEvent(t, { bubbles: true }); } catch (e) { const v = document.createEvent('MouseEvents'); v.initEvent(t, true, true); return v; } };
  const vis2 = e => !!(e.offsetParent || e.getClientRects().length);
  let fixed = false;
  const T0 = Date.now(), late = () => Date.now() - T0 > 28000;   // 한 상품에 30초 넘게 쓰지 않아요
  try { window.alert = () => {}; window.confirm = () => false; window.prompt = () => null; } catch (e) {}   // 옵션을 누를 때 뜨는 알림창 때문에 멈추지 않게
  const SZ = /^(?:[1-3]\d{2}(?:\.5)?(?:\s*mm)?|[1-9]\d(?:\.5)?|0[2-9]|[2-6]T|0?\d{2,3}\s*[\[(][A-Z0-9]{1,5}[\])]|(?:X{0,3}S|M|L|X{1,4}L|[2-5]XL)(?:\s*[\[(]\d{2,3}[\])])?|FREE|F|ONE\s?SIZE|OS|US\s?\d{1,2}(?:\.5)?|EU\s?\d{2}(?:\.5)?|[1-9]\d{2}\s*[\[(][A-Z0-9]{1,5}[\])])$/i;
  const clean = t => String(t || '').replace(/\s+/g, ' ').replace(/\s*[\[(]?(?:일시)?품절[\])]?\s*/g, ' ').replace(/\s*\(?(?:재고|잔여)\s*\d+\s*개?\)?/g, '').replace(/\s*[+＋]\s*[\d,]+원/g, '').replace(/\s*-\s*$/, '').trim();
  const soldTxt = t => /품절|sold\s?out|재고\s*없음|입고\s*예정|재?입고\s*알림|입고\s*시\s*알림|notify\s*me/i.test(String(t || ''));
  const soldCls = e => { if (e && e.hasAttribute && e.hasAttribute('aria-disabled')) return e.getAttribute('aria-disabled') === 'true'; let c = ''; for (let x = e, i = 0; x && i < 3; x = x.parentElement, i++) c += ' ' + (typeof x.className === 'string' ? x.className.split(/\s+/).filter(c => !c.includes(':') && !c.includes('[')).join(' ') : ''); return /sold|out-of-stock|is-out|unavailable|unselectable|is-disabled|\bdisabled\b|\bdim\b/i.test(c); };
  const qtyOf = t => { const m = String(t || '').match(/(?:재고|잔여|남은\s*수량)\s*:?\s*(\d+)\s*개?|(\d+)\s*개\s*남/); return m ? +(m[1] || m[2]) : null; };
  const meta = p => { const e = document.querySelector(`meta[property="${p}"],meta[name="${p}"]`); return e ? e.content : ''; };
  for (let i = 0; i < 20 && document.readyState !== 'complete'; i++) await wait(300);
  await wait(1200);
  const out = new Map(); const add = (label, o) => { label = clean(label); if (!label || label.length > 30 || !SZ.test(label)) return; const k = label.toUpperCase().replace(/\s+/g, ''); const x = out.get(k); if (x) { x.out = x.out && o.out; if (o.qty != null) x.qty = o.qty; if (o.note) x.note = o.note; } else out.set(k, { label, size: label, out: !!o.out, qty: o.qty ?? null, note: o.note || '' }); };
  let name = '', price = null, brand = '';
  // 나이키: 공식 재고 API (사이즈별 재고 많음 · 보통 · 적음 · 품절)
  if (/nike\.com$/.test(location.hostname)) {
    const m = location.pathname.match(/\/t\/[^/]*?-?([A-Za-z0-9]{6,9})\/([A-Z0-9]{5,8}-\d{3})/) || location.pathname.match(/\/t\/.*-([A-Za-z0-9]+)\/([A-Z0-9-]+)/);
    if (m) {
      const j = await (await fetch(`https://api.nike.com/discover/product_details_availability/v1/marketplace/KR/language/ko/consumerChannelId/d9a5bc42-4b9c-4976-858a-f159cf99c647/groupKey/${m[1]}`)).json();
      const LV = { HIGH: '많음', MEDIUM: '보통', LOW: '적음', OOS: '품절' };
      for (const x of (j.sizes || []).filter(x => x.productCode === m[2])) { const av = x.availability || {}; const lab = x.localizedLabel || x.label; const k = String(lab); out.set(k, { label: k, size: k, out: !av.isAvailable, qty: null, note: LV[av.ship] || av.ship || '' }); }
    }
  }
  // 1) JSON-LD
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    let j; try { j = JSON.parse(s.textContent); } catch (e) { continue; }
    for (const p of [].concat(j['@graph'] || j)) {
      if (!p || !/Product/i.test(String(p['@type']))) continue;
      name = name || p.name || ''; brand = brand || (p.brand && (p.brand.name || p.brand)) || '';
      for (const o of [].concat(p.offers && (p.offers.offers || p.offers) || [])) { if (!o) continue; price = price || +o.price || +o.lowPrice || null; if (out.size < 1 && o.name) add(o.name, { out: /OutOfStock|SoldOut/i.test(o.availability || '') }); }
      for (const v of [].concat(p.hasVariant || [])) { const o = v.offers || {}; if (v.size) add(String(v.size), { out: /OutOfStock|SoldOut/i.test(o.availability || '') }); }
    }
  }
  const skip = e => { if (e.closest('[id*="restock" i],[class*="restock" i],[id*="alarm" i],[class*="alarm" i],[class*="notify" i],[id*="notify" i]')) return true; const z = e.closest('table,[class*="ruler" i],[class*="guide" i],[class*="chart" i],[class*="review" i],header,footer,nav,[class*="recommend" i],[class*="related" i]'); if (!z) return false; if (z.tagName === 'TABLE' && /opt|order|buy|purchase/i.test(z.className + ' ' + z.id) && !z.parentElement.closest('[class*="guide" i],[class*="chart" i],[class*="ruler" i]')) return false; return true; };
  const scan = () => {
    // 라디오 · 체크 옵션 (라벨 글자 = 사이즈)
    for (const inp of document.querySelectorAll('input[type="radio"],input[type="checkbox"]')) {
      if (skip(inp)) continue;
      const lab = inp.labels && inp.labels[0] ? inp.labels[0].innerText.trim() : (inp.getAttribute('data-friendly-name') || inp.getAttribute('data-value') || '');
      if (!lab || !SZ.test(clean(lab.split('\n')[0]))) continue;
      const box = inp.closest('li,label,div') || inp;
      add(lab.split('\n')[0], { out: inp.disabled || /sold/i.test(inp.className) || soldCls(inp.labels && inp.labels[0] || box) || soldTxt(box.innerText), qty: qtyOf(box.innerText) });
    }
    // role=option · data-size 계열
    for (const e of document.querySelectorAll('[role="option"],[data-size],[data-info],[data-option-name],.menu__option,[class*="option-item" i],[class*="optionItem" i],[class*="size-item" i],[class*="sizeItem" i]')) {
      if (skip(e)) continue;
      const lab = e.getAttribute('data-info') || e.getAttribute('data-size') || e.getAttribute('data-option-name') || (e.innerText || '').split('\n')[0];
      const t = e.innerText || '';
      const fast = +(e.getAttribute('data-delibox-qty') || 0);
      add(lab, { out: e.getAttribute('aria-disabled') === 'true' || e.disabled || soldCls(e) || soldTxt(t), qty: qtyOf(t), note: /빠른|오늘|당일/.test(t) && fast ? `빠른배송 ${fast}개` : '' });
    }
    // 선택 상자
    for (const sel of document.querySelectorAll('select')) {
      if (skip(sel)) continue;
      const opts = [...sel.options].filter(o => o.value && !/선택|choose|select/i.test(o.text));
      const tok = t => { const c = clean(t); if (SZ.test(c)) return ['', c]; const parts = c.split(/\s*[_\/:|]\s*|\s+-\s+/).map(x => x.trim()).filter(Boolean); const last = parts[parts.length - 1]; return last && SZ.test(last) ? [parts.slice(0, -1).join(' '), last] : null; };
      const hits = opts.map(o => [o, tok(o.text)]).filter(x => x[1]);
      if (hits.length >= 2 && hits.length >= opts.length * 0.6 && !hits.every(x => /^0\d{2}$/.test(x[1][1]))) for (const [o, [pre, sz]] of hits) { const lab = pre ? pre + ' / ' + sz : sz, k = lab.toUpperCase().replace(/\s+/g, ''); out.set(k, { label: lab, size: sz, out: o.disabled || soldTxt(o.text), qty: qtyOf(o.text), note: '' }); }
    }
    // 버튼 · 목록
    if (out.size < 2) for (const b of document.querySelectorAll('[class*="option" i] button,[class*="option" i] li,[class*="size" i] button,[class*="size" i] li,[class*="variation" i] label,[class*="variation" i] button')) {
      if (skip(b)) continue; const t = (b.innerText || '').trim(); if (!t || t.length > 40) continue;
      add(t.split('\n')[0], { out: b.disabled || b.getAttribute('aria-disabled') === 'true' || !!b.querySelector('button:disabled,input:disabled,[aria-disabled="true"],[class*="soldout" i],[class*="sold-out" i],[class*="sold_out" i]') || soldCls(b) || soldTxt(t), qty: qtyOf(t) });
    }
  };
  // 롯데ON: 모델 → 사이즈 2단계 목록 (ul.selectLists)
  if (/lotteon\.com$/.test(location.hostname)) {
    const L = [...document.querySelectorAll('ul.selectLists')], cap = li => clean(((li.querySelector('.caption') || li).innerText || '').replace(/\[품절\]/g, '').split('\n')[0]);
    const L1 = L[0], L2 = L.find((u, i) => i > 0 && [...u.children].some(li => SZ.test(cap(li))));
    const put = (pre, li) => { const sz = cap(li); if (!SZ.test(sz)) return; const k = pre ? pre + ' / ' + sz : sz; out.set(k.toUpperCase(), { label: k, size: sz, out: /disabled|soldout/i.test(li.className) || /품절/.test(li.innerText), qty: qtyOf(li.innerText), note: '' }); };
    if (L1 && [...L1.children].some(li => SZ.test(cap(li)))) for (const li of L1.children) put('', li);
    else if (L1 && L2) for (const li of [...L1.children].slice(0, 20)) { if (late()) break;
      const model = cap(li).replace(/^\d+\.\s*/, '').replace(/_+$/, '').trim();
      if (/disabled/.test(li.className) || /품절/.test(li.innerText)) { out.set(('M:' + model).toUpperCase(), { label: model + ' (모델 전체 품절)', size: '-', out: true, qty: 0, note: '' }); continue; }
      (li.querySelector('a,button,label,input') || li).click(); await wait(700);
      for (const s2 of L2.children) if (!/displayNone/.test(s2.className)) put(model, s2);
    }
  }
  // 에이블리: 상품 화면에는 옵션이 없고 '구매하기'를 눌러야 옵션 창이 열려요 (결제 단계로는 가지 않아요)
  // 옵션 창은 두 가지 모양이에요: ① 칩(색상 · 사이즈 버튼)  ② 접히는 목록('사이즈 선택하기')
  if (/(^|\.)a-bly\.com$/.test(location.hostname)) {
    fixed = true;
    const PR = 'div.r-1loqt21';
    const press = b => { for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) { try { b.dispatchEvent(new (t.startsWith('pointer') && typeof PointerEvent === 'function' ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, pointerType: 'mouse', isPrimary: true })); } catch (e) { try { b.dispatchEvent(mev(t)); } catch (e2) {} } } try { b.click(); } catch (e) {} };
    const txt = e => (e.innerText || '').trim();
    const u0 = location.href;
    let buy = null; for (let i = 0; i < 20 && !buy; i++) { buy = [...document.querySelectorAll(PR)].find(e => vis2(e) && txt(e) === '구매하기'); if (!buy) await wait(300); }
    const wrapOf = () => [...document.querySelectorAll('.r-1kihuf0')].filter(w => vis2(w) && w.querySelector(PR) && !/구매하기|장바구니|선물하기/.test(txt(w))).pop();
    let W = null;
    if (buy) { press(buy); for (let i = 0; i < 15 && !W; i++) { await wait(300); if (location.href !== u0) break; W = wrapOf(); } }
    const groups = () => { const w = wrapOf(); if (!w) return [];
      const acc = [...w.children].filter(g => g.children[0] && g.children[0].matches(PR) && g.querySelector(PR));   // ② 접히는 목록: [머리줄, 목록]
      if (acc.length) return acc;
      const C = [...w.querySelectorAll('div')].filter(g => g.children.length === 2 && !g.children[0].matches(PR) && !g.children[0].querySelector(PR) && g.children[1].querySelector(PR) && txt(g.children[0]) && !/^수량/.test(txt(g.children[0])));   // ① 칩: [이름, 버튼들]
      return C.filter(g => !C.some(o => o !== g && o.contains(g))); };
    const isHead = (g, e) => e === g.children[0] || /선택하기$/.test(txt(e));
    const items = g => { const all = [...g.querySelectorAll(PR)].filter(e => !isHead(g, e) && txt(e) && !/^재입고 알림/.test(txt(e))); return all.filter(e => !all.some(o => o !== e && o.contains(e))); };
    const openG = async g => { if (items(g).length) return items(g); const h = g.children[0]; if (h && h.matches(PR)) { press(h); for (let i = 0; i < 8; i++) { await wait(250); if (items(g).length) break; } } return items(g); };
    const gray = e => { const leaf = [...e.querySelectorAll('div')].find(x => !x.children.length && txt(x)) || e; const m = getComputedStyle(leaf).color.match(/\d+/g); return !!m && +m[0] > 170 && +m[1] > 170 && +m[2] > 170; };
    const put = (pre, e) => { const L = txt(e).split('\n').map(x => x.trim()).filter(Boolean); let v = L[0]; if (!v) return; if (/^선택\s*없음$/.test(v)) { if (!pre) return; v = pre; pre = ''; } const lab = pre ? pre + ' / ' + v : v; const rest = L.slice(1).join(' '); const q = rest.match(/(\d+)\s*개\s*남/); out.set(lab.toUpperCase(), { label: lab, size: v, out: /(^|\s)(일시)?품절(\s|$)/.test(rest) || gray(e), qty: q ? +q[1] : null, note: /오늘\s*출발/.test(rest) ? '오늘출발' : '' }); };
    let G = groups();
    if (G.length === 1) {   // 칩 모양은 첫 옵션을 골라야 다음 옵션(사이즈)이 나타나요
      const its = await openG(G[0]), snap = its.map(e => e);
      const c = its.find(e => !/(^|\n)(일시)?품절(\n|$)/.test(txt(e)) && !gray(e));
      if (c && its.length <= 20) { press(c); await wait(800); G = groups(); }
      if (G.length < 2) { const g0 = groups()[0]; for (const e of (g0 ? await openG(g0) : snap.filter(e => e.isConnected))) put('', e); }
    }
    if (G.length >= 2) {
      const first = (await openG(G[0])).map(e => txt(e).split('\n')[0]).slice(0, 12);
      for (let ci = 0; ci < first.length && !late(); ci++) {
        G = groups(); if (!G.length) break;
        const e = (await openG(G[0])).find(x => txt(x).split('\n')[0] === first[ci]); if (!e) continue;
        if (/(^|\n)(일시)?품절(\n|$)/.test(txt(e)) || gray(e)) { out.set(('M:' + first[ci]).toUpperCase(), { label: first[ci] + ' (전체 품절)', size: '-', out: true, qty: 0, note: '' }); continue; }
        press(e); await wait(700);
        G = groups(); if (G.length < 2) continue;
        for (const s2 of await openG(G[1])) put(first.length > 1 ? first[ci] : '', s2);
      }
    }
    const ttl = meta('og:title') || document.title || ''; name = ttl.replace(/\s+-\s+에이블리.*$/, '').replace(/\s+-\s+[^-]{1,20}$/, '');
  }
  // 더현대Hi: '구매하기'를 누르면 아래에서 옵션 창(색상 → 사이즈 선택 상자)이 열려요. 로그인해야 열려요. (결제로는 가지 않아요)
  if (/(^|\.)thehyundai\.com$/.test(location.hostname)) {
    fixed = true;
    const txt = e => (e.innerText || '').trim();
    { const pr = document.querySelector('[class*="DetailPrice_root"]'); const N = pr ? (txt(pr).match(/\d{1,3}(?:,\d{3})+(?=\s*원)/g) || []) : []; if (N.length) price = +N[N.length - 1].replace(/,/g, ''); }
    let buy = null; for (let i = 0; i < 20 && !buy; i++) { buy = [...document.querySelectorAll('button')].find(e => vis2(e) && txt(e) === '구매하기'); if (!buy) await wait(300); }
    const box = () => document.querySelector('[class*="CtaDrawer_sec-option"]');
    if (buy) { buy.click(); for (let i = 0; i < 15 && !box(); i++) { await wait(300); if (/로그인이\s*필요한\s*서비스/.test(document.body.innerText)) break; } }
    if (!box() && /로그인이\s*필요한\s*서비스/.test(document.body.innerText)) { try { const c = [...document.querySelectorAll('button')].find(e => vis2(e) && txt(e) === '취소'); if (c) c.click(); } catch (e) {} return { site, needLogin: true, url: location.href, name: '', sizes: [], generic: true, price: { salePrice: price } }; }
    const cbs = () => box() ? [...box().querySelectorAll('[role=combobox]')] : [];
    const openCb = async cb => { if (cb.getAttribute('aria-expanded') !== 'true') cb.click(); for (let i = 0; i < 10; i++) { await wait(200); const o = [...cb.parentElement.querySelectorAll('[role=option]')]; if (o.length) return o; } return []; };
    const val = o => txt(o.querySelector('[class*="left"]') || o).split('\n')[0].replace(/\s*\[?품절\]?\s*$/, '').trim();
    const put = (pre, o) => { const v = val(o); if (!v) return; const all = txt(o); const lab = pre ? pre + ' / ' + v : v; const q = all.match(/(\d+)\s*개/); out.set(lab.toUpperCase(), { label: lab, size: v, out: o.getAttribute('aria-disabled') === 'true' || /품절/.test(all), qty: q ? +q[1] : null, note: '' }); };
    let C = cbs();
    if (C.length === 1) for (const o of await openCb(C[0])) put('', o);
    else if (C.length >= 2) {
      const first = (await openCb(C[0])).map(val).slice(0, 12);
      for (let ci = 0; ci < first.length && !late(); ci++) {
        C = cbs(); const o = (await openCb(C[0])).find(x => val(x) === first[ci]); if (!o) continue;
        if (o.getAttribute('aria-disabled') === 'true' || /품절/.test(txt(o))) { out.set(('M:' + first[ci]).toUpperCase(), { label: first[ci] + ' (전체 품절)', size: '-', out: true, qty: 0, note: '' }); continue; }
        o.click(); await wait(1000);
        C = cbs(); if (C.length < 2) continue;
        for (let k = 0; k < 10 && /disabled/.test(C[1].className); k++) await wait(250);
        for (const s2 of await openCb(C[1])) put(first.length > 1 ? first[ci] : '', s2);
      }
    }
    name = (meta('og:title') || document.title || '').replace(/\s*\|\s*더현대.*$/, '').trim();
  }
  if (!fixed && out.size < 2) scan();
  // 'multiselect' 목록 (하프클럽 등): 상자가 하나면 '색상 / 사이즈 / 품절임박 n개' 줄, 둘이면 색상 → 사이즈 순서로 골라 읽어요
  if (!fixed && out.size < 2 && document.querySelector('.multiselect-wrapper')) {
    const W = [...document.querySelectorAll('.multiselect-wrapper')].filter(w => vis2(w));
    const openMs = async w => { const box = w.closest('.multiselect') || w.parentElement || w; try { w.dispatchEvent(mev('mousedown')); } catch (e) {} try { w.focus(); } catch (e) {} for (let k = 0; k < 10; k++) { const o = [...box.querySelectorAll('.multiselect-option,.multiselect__option')]; if (o.length) return o; await wait(250); } return []; };
    const readOpt = (o, pre0) => { const L = (o.innerText || '').split(/\n|\s*\/\s*/).map(x => x.trim()).filter(Boolean); if (!L.length) return; const note = L.filter(x => /품절|임박|\d+\s*개/.test(x)).join(' '), main = L.filter(x => !/품절|임박|남음|\d+\s*개/.test(x)); const sz = clean(main[main.length - 1] || ''); if (!sz) return; const pre = [pre0, ...main.slice(0, -1)].filter(Boolean).join(' '); const lab = pre ? pre + ' / ' + sz : sz; const q = note.match(/(\d+)\s*개/); out.set(lab.toUpperCase(), { label: lab, size: sz.replace(/^0+(?=[A-Z])/, ''), out: /disabled/.test(o.className) || (/품절/.test(note) && !/임박/.test(note)), qty: q ? +q[1] : null, note: /임박/.test(note) ? '품절 임박' : '' }); };
    if (W.length === 1) for (const o of await openMs(W[0])) readOpt(o, '');
    else if (W.length >= 2) {
      const colors = (await openMs(W[0])).map(o => (o.innerText || '').split('\n')[0].trim()).slice(0, 12);
      for (let ci = 0; ci < colors.length && !late(); ci++) {
        const o = (await openMs(W[0])).find(x => (x.innerText || '').split('\n')[0].trim() === colors[ci]); if (!o) continue;
        if (/disabled/.test(o.className) || /품절/.test(o.innerText) && !/임박/.test(o.innerText)) { out.set(('M:' + colors[ci]).toUpperCase(), { label: colors[ci] + ' (전체 품절)', size: '-', out: true, qty: 0, note: '' }); continue; }
        try { o.dispatchEvent(mev('mousedown')); o.click(); } catch (e) {} await wait(600);
        for (const s2 of await openMs(W[1])) readOpt(s2, colors[ci]);
      }
    }
  }
  // 선택 상자 2개가 이어진 쇼핑몰 (색상을 고르면 다음 상자에 사이즈가 채워짐)
  if (!fixed && out.size < 2) {
    const sels = [...document.querySelectorAll('select')].filter(x => !skip(x) && !x.closest('[class*="review" i],[class*="sort" i]'));
    const real = o => o.value && !/선택|choose|select/i.test(o.text);
    for (let i = 0; i < sels.length - 1 && out.size < 2; i++) {
      const A = sels[i], B = sels[i + 1], ao = [...A.options].filter(real);
      if (!ao.length || ao.some(o => SZ.test(clean(o.text))) || [...B.options].filter(real).length > 0 && [...B.options].filter(real).some(o => SZ.test(clean(o.text)))) continue;
      for (const o of ao.slice(0, 15)) { if (late()) break;
        const pre = clean(o.text).replace(/\s*\(?품절\)?\s*/g, '').slice(0, 30);
        if (o.disabled || soldTxt(o.text)) { out.set(('M:' + pre).toUpperCase(), { label: pre + ' (전체 품절)', size: '-', out: true, qty: 0, note: '' }); continue; }
        A.value = o.value; { const ev = document.createEvent('HTMLEvents'); ev.initEvent('change', true, true); A.dispatchEvent(ev); } try { if (window.jQuery) window.jQuery(A).trigger('change'); } catch (e) {}
        for (let k = 0; k < 8; k++) { await wait(250); if ([...B.options].filter(real).length) break; }
        for (const b of [...B.options].filter(real)) { const sz = clean(b.text).split(/\s*[_\/:|]\s*/).pop(); if (!SZ.test(sz)) continue; const lab = pre + ' / ' + sz; out.set(lab.toUpperCase(), { label: lab, size: sz, out: b.disabled || soldTxt(b.text), qty: qtyOf(b.text), note: '' }); }
      }
    }
  }
  // 색상 → 사이즈처럼 단계별로 고르는 쇼핑몰 (버튼을 눌러 목록이 열리는 방식): 색상마다 사이즈 목록을 읽어요. 장바구니 · 구매는 누르지 않아요.
  if (!fixed && out.size < 2) {
    const GRP = /^(?:색상|컬러|COLOR|Color|사이즈|SIZE|Size|옵션|색상\s*선택|사이즈\s*선택|옵션\s*선택|컬러\s*선택)$/;
    const vis = e => !!(e.offsetParent || e.getClientRects().length);
    const groups = () => [...document.querySelectorAll('button,[role="button"],[role="combobox"]')].filter(b => vis(b) && !skip(b) && GRP.test((b.innerText || '').trim().split('\n')[0]));
    const items = () => [...document.querySelectorAll('li,[role="option"]')].filter(e => vis(e) && !skip(e) && (e.innerText || '').trim() && (e.innerText || '').trim().length < 60 && !e.querySelector('li'));
    const openList = async g => { const before = new Set(items()); for (const ev of ['pointerdown', 'mousedown', 'mouseup', 'click']) { try { g.dispatchEvent(mev(ev)); } catch (e) {} } for (let i = 0; i < 8; i++) { await wait(250); const n = items().filter(x => !before.has(x)); if (n.length) return n; } return []; };
    const isOut = e => { const b = e.matches('button') ? e : e.querySelector('button'); return !!(b && b.disabled) || e.getAttribute('aria-disabled') === 'true' || soldTxt(e.innerText); };
    let G = groups(); const si = G.findIndex(g => /사이즈|SIZE|Size/.test(g.innerText) || (G.length === 1 && /옵션/.test(g.innerText)));
    if (si >= 0) {
      const sizeRead = async prefix => { const g = groups()[si] || groups().find(x => /사이즈|SIZE|Size|옵션/.test(x.innerText)); if (!g) return; const L = await openList(g); for (const e of L) { const t = (e.innerText || '').trim().split('\n')[0]; if (GRP.test(t)) continue; const lab = clean(t); if (!SZ.test(lab)) continue; const k = (prefix ? prefix + ' / ' : '') + lab; out.set(k.toUpperCase(), { label: k, size: lab, out: isOut(e), qty: qtyOf(e.innerText), note: '' }); } try { document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } catch (e) {} };
      if (si === 0) await sizeRead('');
      else {
        const cg = G[0]; const colors = (await openList(cg)).filter(e => !GRP.test((e.innerText || '').trim().split('\n')[0])).slice(0, 12);
        const names = colors.map(e => clean((e.innerText || '').trim().split('\n')[0]).slice(0, 30));
        for (let ci = 0; ci < names.length && !late(); ci++) {
          if (ci) { const prev = names[ci - 1]; const g0 = [...document.querySelectorAll('button,[role="button"],[role="combobox"]')].find(b => vis(b) && !skip(b) && clean((b.innerText || '').trim().split('\n')[0]).slice(0, 30) === prev) || groups()[0]; if (!g0) break; const L = await openList(g0); const hit = L.find(e => clean((e.innerText || '').trim().split('\n')[0]).slice(0, 30) === names[ci]); if (!hit) continue; (hit.querySelector('button') || hit).click(); }
          else (colors[0].querySelector('button') || colors[0]).click();
          await wait(700); await sizeRead(names[ci]);
        }
      }
    }
  }
  // 드롭다운을 눌러야 목록이 나오는 쇼핑몰
  if (!fixed && out.size < 2) {
    const okOpen = e => { if (skip(e) || !e.offsetParent) return false; const t = (e.innerText || '').trim(); return t.length < 30 && /사이즈|옵션|SIZE|Size/.test(t) && !/가이드|guide|표|정보|조견/i.test(t); };
    const opener = [...document.querySelectorAll('.dropdown__control,[class*="select__control"],[class*="Select-control"],[role="combobox"]')].find(okOpen) || [...document.querySelectorAll('button,[role="button"],div[class*="select" i]')].find(okOpen);
    if (opener) { for (let k = 0; k < 2 && out.size < 2; k++) { for (const ev of ['pointerdown', 'mousedown', 'mouseup', 'click']) { try { opener.dispatchEvent(mev(ev)); } catch (e) {} } for (let i = 0; i < 10 && out.size < 2; i++) { await wait(400); scan(); } } }
  }
  { const og = meta('og:title'); name = name || (og && og.replace(/[\[\]\s]|W CONCEPT/gi, '').length > 4 ? og : '') || String(document.title || '').replace(/\s+[-|]\s+[^|]*$/, '') || (document.querySelector('h1') || {}).innerText || ''; }
  price = price || +String(meta('product:price:amount') || '').replace(/[^\d]/g, '') || null;
  if (!price) for (const e of document.querySelectorAll('[class*="price" i]')) { if (!vis2(e) || skip(e) || e.closest('a[href],li[class*="item" i],[class*="swiper" i],[class*="coupon" i],[class*="ship" i],[class*="deliv" i],[class*="total" i],[class*="point" i]')) continue; const m = (e.innerText || '').match(/\d{1,3}(?:,\d{3})+/); if (m && +m[0].replace(/,/g, '') >= 1000) { price = +m[0].replace(/,/g, ''); break; } }
  if (!price) { const m = (document.body.innerText.match(/([\d]{1,3}(?:,\d{3})+)\s*원/) || [])[1]; price = m ? +m.replace(/,/g, '') : null; }
  name = String(name).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
  const sizes = [...out.values()];
  return { site, goodsNo: location.pathname.split('/').filter(Boolean).pop() || '', url: location.href, name: String(name).trim().slice(0, 120), brand: String(brand || '').slice(0, 40), price: { salePrice: price }, sizes, generic: true, maxOrder: null };
}
