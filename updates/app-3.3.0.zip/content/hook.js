// 크림 상품 페이지가 스스로 불러오는 체결·판매입찰·구매입찰 데이터를 옆에서 받아 적어요.
// (크림에 따로 요청을 보내지 않고, 페이지가 받은 응답만 복사합니다)
(() => {
  if (window.__kcHooked) return;
  window.__kcHooked = true;
  const RE = /\/api\/p\/products\/(\d+)\/(sales|asks|bids)(?:\?|$)/;
  const post = (kind, url, data) => {
    try { window.postMessage({ __kc: 1, kind, url: String(url), data }, location.origin); } catch (e) {}
  };

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    const p = origFetch.call(window, input, init);
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || String(input);
      const m = url.match(RE);
      if (m) p.then(r => r.clone().json().then(j => post(m[2], url, j)).catch(() => {})).catch(() => {});
    } catch (e) {}
    return p;
  };

  const X = XMLHttpRequest.prototype;
  const open = X.open, send = X.send;
  X.open = function (method, url) { this.__kcUrl = String(url); return open.apply(this, arguments); };
  X.send = function () {
    const m = this.__kcUrl && this.__kcUrl.match(RE);
    if (m) this.addEventListener('load', () => {
      try { post(m[2], this.__kcUrl, JSON.parse(this.responseText)); } catch (e) {}
    });
    return send.apply(this, arguments);
  };
})();
