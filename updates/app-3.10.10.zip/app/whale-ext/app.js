'use strict';
/* 크림스캐너 — 내 상품(시세·마진) + 매출관리 */

// ---------- 저장소 (확장 프로그램 저장소, 테스트 때는 localStorage) ----------
const HAS_CHROME = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
const store = {
  async get(key, def) {
    if (HAS_CHROME) { const o = await chrome.storage.local.get(key); return o[key] === undefined ? def : o[key]; }
    try { const v = localStorage.getItem('kc:' + key); return v == null ? def : JSON.parse(v); } catch (e) { return def; }
  },
  async set(key, val) {
    if (HAS_CHROME) return chrome.storage.local.set({ [key]: val });
    try { localStorage.setItem('kc:' + key, JSON.stringify(val)); } catch (e) {}
  }
};

// 휴대폰·PC 같이 쓰는 웹페이지 (매출관리 + 시세 보기)
const WEB_URL = 'https://claude.ai/artifact/3eG9e8TAmbySMeufHBj6MN';
// mode: 내 판매 방식 — 'normal' 일반 판매 / 'fast' 보관 판매(빠른배송). 크림은 두 방식의 판매입찰이 따로 최저가 경쟁을 해요.
// win: 판매가 기준 기간(일) — 최근 win일 동안 실제 체결된 가격의 평균으로 판매가를 정해요.
const DEF_SETTINGS = { sv: 16, strongOnly: 1, trackHours: 0, trackMarket: true, ship: 0, rate: 6, base: 2500, max: 300000, min7: 168, days: 90, mode: 'normal', win: 14, bgWork: 1 };
const DEF_CLEAN = { loss: true, thin: false, thinMin: 5000, slow: true, none: true, nosrc: false };
const MODE_NAME = { normal: '일반 판매', fast: '보관 판매' };
const STATUSES = ['매입완료', '크림 발송', '판매 중', '판매완료', '정산완료'];
let S = { ...DEF_SETTINGS };
let products = [];   // {id, pid, cost, sizes, memo, rate, base, raw, at, err}
let records = [];    // 매출관리 기록
let openId = null;   // 펼쳐 둔 상품
let stopFlag = false;

const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const won = n => (n == null || isNaN(n)) ? '–' : Math.round(n).toLocaleString('ko-KR') + '원';
const sign = n => (n > 0 ? '+' : '') + won(n);
const mktText = m => !m ? '최근 거래 없음' : `${m.wide ? S.days : S.win}일 ${m.n}건 평균 · ${m.lo === m.hi ? won(m.lo) : won(m.lo).replace('원', '') + '~' + won(m.hi)}${m.mixed ? ' · 방식 구분 없이' : ''}`;
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
// 사이트에 알림창(alert)·팝업이 떠 있으면 읽기가 끝나지 않고 멈춰서, 90초가 지나면 포기하고 다음으로 넘어가요
function execT(o, ms) {
  return Promise.race([chrome.scripting.executeScript(o), new Promise((_, rej) => setTimeout(() => rej(new Error('사이트가 응답하지 않아요 (알림창·팝업이 떠 있을 수 있어요)')), ms || 90000))]);
}
const median = a => { if (!a.length) return 0; const b = [...a].sort((x, y) => x - y); const m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };

async function saveProducts() { await store.set('products', products); }
async function saveRecords() { await store.set('records', records); }

// 정품 매입처 바로 검색 — 각 사이트 검색창이 실제로 쓰는 주소를 확인해서 넣음 (2026-11 확인)
// 무신사는 모델번호로 안 잡히는 상품이 많아서 '상품명(브랜드+모델)' 검색을 같이 둠. W컨셉은 일반 판매자 비중이 커서 뺌.
function srcQueries(name, code) {
  const c = String(code || '').split(/[\/,]/).map(s => s.trim()).find(s => /[A-Za-z]/.test(s) && /\d/.test(s) && s.length >= 5) || '';
  const full = String(name || '').replace(/\s*-\s*(아시아|KR 사이즈).*$/, '').replace(/^\((W|M|GS|PS|TD)\)\s*/i, '').trim();
  const t = full.split(/\s+/).filter(Boolean);
  const k = t.findIndex((w, i) => i > 0 && /\d/.test(w));
  const short = (k > 0 && k < 4 ? t.slice(0, k + 1) : t.slice(0, 3)).join(' ');
  return { c, full, short };
}
function sourceLinks(name, code) {
  const { c, short } = srcQueries(name, code);
  const E = encodeURIComponent, q = E(c || short), qs = E(short);
  const L = [];
  if (c) L.push(['무신사 · 모델번호', `https://www.musinsa.com/search/goods?keyword=${q}`]);
  if (short) L.push(['무신사 · 상품명', `https://www.musinsa.com/search/goods?keyword=${qs}`]);
  L.push(['렉스몬드', `https://www.rexmonde.com/products/list?search_keyword=${q}`]);
  if (short) L.push(['29CM', `https://www.29cm.co.kr/store/search?keyword=${qs}`]);
  L.push(['롯데ON (롯데백화점·아울렛)', `https://www.lotteon.com/search/search/search.ecn?render=search&platform=pc&q=${q}`]);
  L.push(['SSF샵', `https://www.ssfshop.com/search/result?keyword=${q}`]);
  L.push(['신세계백화점', `https://department.ssg.com/search.ssg?target=all&query=${q}`]);
  L.push(['SSG', `https://www.ssg.com/search.ssg?target=all&query=${q}`]);
  L.push(['ABC마트', `https://abcmart.a-rt.com/display/search-word/result?searchWord=${q}`]);
  L.push(['그랜드스테이지', `https://grandstage.a-rt.com/display/search-word/result?searchWord=${q}`]);
  L.push(['슈마커', `https://www.shoemarker.co.kr/ASP/Product/SearchProductList.asp?SearchWord=${q}`]);
  if (c) {
    L.push(['쿠팡', `https://www.coupang.com/np/search?q=${q}`], ['G마켓', `https://www.gmarket.co.kr/n/search?keyword=${q}`], ['11번가', `https://search.11st.co.kr/Search.tmall?kwd=${q}`],
      ['W컨셉', `https://display.wconcept.co.kr/search?keyword=${q}`], ['지그재그', `https://zigzag.kr/search?keyword=${q}`], ['에이블리', `https://m.a-bly.com/search/search-result?query=${q}&search_type=DIRECT`], ['4910', `https://4910.kr/desktop/search?query=${q}&search_type=DIRECT`]);
  }
  const n = String(name || '');
  const B = [
    [/나이키|nike|조던|jordan/i, '나이키 공식몰', `https://www.nike.com/kr/w?q=${q}`],
    [/아디다스|adidas/i, '아디다스 공식몰', `https://www.adidas.co.kr/search?q=${q}`],
    [/뉴발란스|new balance/i, '뉴발란스 공식몰', `https://www.nbkorea.com/product/searchResult.action?schWord=${q}`],
    [/아식스|asics|오니츠카|onitsuka/i, '아식스 공식몰', `https://www.asics.co.kr/goods/search?search_text=${q}`],
    [/푸마|puma/i, '푸마 공식몰', `https://kr.puma.com/kr/ko/search?q=${q}`],
    [/컨버스|converse/i, '컨버스 공식몰', `https://www.converse.co.kr/product/search.html?keyword=${q}`],
    [/반스|vans/i, '반스 공식몰', `https://www.vans.co.kr/search?q=${q}`],
    [/노스페이스|north ?face/i, '노스페이스 공식몰', `https://www.thenorthfacekorea.co.kr/search?q=${q}`]
  ];
  for (const [re, label, url] of B) if (re.test(n)) L.push([label, url]);
  return L;
}
// 매입처 자동 찾기 결과 보여주기 (PC 확장 프로그램·웹페이지 공통)
const SRC_LEVEL = { strong: ['ok', '모델번호 일치'], weak: ['warn', '모델명 일치 · 번호 확인'] };
const srcTier = s => s.tier || 'trust';
function srcBest(src, tier) {
  return (src && src.sites || []).filter(s => s.level && srcTier(s) === tier && s.min).sort((a, b) => a.min - b.min)[0] || null;
}
function srcSummaryText(src) {
  if (!src || !src.sites) return '';
  const t = src.sites.filter(s => s.level && srcTier(s) === 'trust'), m = src.sites.filter(s => s.level && srcTier(s) === 'market');
  const bt = srcBest(src, 'trust'), bm = srcBest(src, 'market');
  const a = t.length ? `정품 유통 ${t.length}곳${bt ? ` · 최저 ${bt.label} ${won(bt.min)}` : ''}` : '정품 유통 매입처 없음';
  return a + (m.length ? ` / 오픈마켓 ${m.length}곳${bm ? ` 최저 ${won(bm.min)}` : ''}` : '');
}
function srcBoxHTML(src, be, name, code, btnClass, canSearch, sell) {
  const ago = src && src.at ? new Date(src.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' 확인' : '';
  const head = `<h3>매입처 — 파는 곳만 <span class="small sm">${ago}${be ? ` · 손익분기 ${won(be)}보다 싸면 남아요` : ''}</span></h3>`;
  const again = canSearch ? `<button type="button" class="${btnClass}" data-src="1">${src ? '다시 찾기' : '파는 곳 찾기'}</button>` : '';
  if (!src || !src.sites) return `<div class="box">${head}<p class="hint">${canSearch ? '아직 안 찾았어요. 아래 버튼을 누르면 매입처를 돌면서 이 상품을 파는 곳만 골라 보여줘요. (2~3분쯤)' : 'PC 크림스캐너에서 \'파는 곳 찾기\'를 하고 다시 보내면 여기 보여요.'}</p>${again}</div>`;
  const row = s => {
    const lv = SRC_LEVEL[s.level];
    const m = s.min && be != null ? be - s.min : null;
    const it = (s.items || [])[0] || {};
    return `<tr><td class="l"><b>${esc(s.label)}</b><div class="small sm">${esc((it.name || '').slice(0, 60))}${s.n > 1 ? ` 외 ${s.n - 1}개` : ''}</div></td>
      <td class="l"><span class="pill ${lv[0]}">${lv[1]}</span>${s.level === 'weak' && it.color ? ' <span class="small sm">색상도 일치</span>' : ''}${s.allSold ? ' <span class="pill bad">품절</span>' : ''}</td>
      <td><b>${won(s.min)}</b></td><td class="${m > 0 ? 'pos' : m != null ? 'neg' : ''}"><b>${m != null ? sign(m) : '–'}</b>${sell && s.min ? `<div class="small sm">크림가−매입가 ${sign(sell - s.min)}</div>` : ''}</td>
      <td><a class="${btnClass}" href="${esc(it.url || s.searchUrl)}" target="_blank" rel="noopener">열기</a></td></tr>`;
  };
  const ord = (a, b) => (lvRank(b) - lvRank(a)) || ((a.min || 9e9) - (b.min || 9e9));
  const T = src.sites.filter(s => s.level && srcTier(s) === 'trust').sort(ord);
  const M = src.sites.filter(s => s.level && srcTier(s) === 'market').sort(ord);
  const P = src.sites.filter(s => s.level && srcTier(s) === 'platform' && s.min);
  const plat = P.map(s => `<div class="small"><b>${esc(s.label)}</b> 지금 최저 ${won(s.min)}${sell ? ` — 크림 판매가 ${won(sell)}보다 ${sign(s.min - sell)}${s.min > sell * 1.1 ? ` · ${esc(s.label)}에 파는 게 나을 수 있어요` : ''}` : ''} <a href="${esc(((s.items || [])[0] || {}).url || s.searchUrl)}" target="_blank" rel="noopener">열기</a></div>`).join('');
  const errs = src.sites.filter(s => s.err).map(s => s.label);
  const thead = '<thead><tr><th class="l">파는 곳</th><th class="l">일치</th><th>최저가</th><th>그 값에 사면 순마진<small>크림가 − 수수료 − 매입가</small></th><th></th></tr></thead>';
  const sec = (title, note, rows) => rows.length ? `<div class="srcsec"><div class="srcsec-h">${title} <span class="small sm">${note}</span></div><div class="tblw" style="overflow-x:auto"><table class="sz srct">${thead}<tbody>${rows.map(row).join('')}</tbody></table></div></div>` : '';
  return `<div class="box">${head}
    ${T.length ? sec('<span class="pill ok">정품 유통</span>', '', T) : '<p class="hint"><b>정품 유통 매입처(백화점·아울렛·공식몰·편집숍)에서는 지금 이 상품을 팔지 않아요.</b></p>'}
    ${sec('<span class="pill warn">오픈마켓 · 판매자 확인</span>', '가품 주의 — 판매자가 공식스토어인지 꼭 확인', M)}
    ${plat ? `<div class="srcsec"><div class="srcsec-h"><span class="pill mute">다른 리셀 플랫폼</span> <span class="small sm">어디에 팔면 더 받나 비교</span></div>${plat}</div>` : ''}
    <p class="hint">${src.sites.filter(s => srcTier(s) !== 'platform').length}곳을 검색해서 파는 곳만 보여줘요.${errs.length ? ` (${errs.length}곳은 페이지가 안 열려 확인 못 함 — '다시 찾기')` : ''}</p>
    <p class="hint">가격은 검색 목록에 보이는 값(할인가)이에요. '택1' 상품은 제일 싼 옵션 가격일 수 있어요. 쿠폰·카드 할인, 사이즈 재고는 '열기'로 확인하세요.</p>
    ${again}</div>`;
}
const SOURCE_NAMES = ['무신사', '렉스몬드', '29CM', 'SSF샵', 'W컨셉', '쿠팡', 'G마켓', '11번가', 'SSG', '롯데ON', '지그재그', '에이블리', '4910', '롯데백화점', '롯데아울렛', '신세계백화점', '신세계아울렛', '현대백화점', '현대아울렛', 'ABC마트', '그랜드스테이지', '슈마커', '나이키 공식몰', '아디다스 공식몰', '뉴발란스 공식몰', '아식스 공식몰', '푸마 공식몰', '컨버스 공식몰', '반스 공식몰', '노스페이스 공식몰'];

// ---------- 수수료·마진 ----------
function feeOf(price, prod) {
  if (!price) return 0;
  const rate = prod && prod.rate != null && prod.rate !== '' ? +prod.rate : S.rate;
  const base = prod && prod.base != null && prod.base !== '' ? +prod.base : S.base;
  return Math.floor(Math.min((price * rate / 100 + base) * 1.1, S.max) / 10) * 10;
}

const SIZE_ORDER = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', '2XL', 'XXXL', '3XL', '4XL'];
function sizeSort(a, b) {
  const na = parseFloat(a), nb = parseFloat(b);
  if (!isNaN(na) && !isNaN(nb) && /^[\d.]+$/.test(a) && /^[\d.]+$/.test(b)) return na - nb;
  const ia = SIZE_ORDER.indexOf(String(a).toUpperCase()), ib = SIZE_ORDER.indexOf(String(b).toUpperCase());
  if (ia >= 0 && ib >= 0) return ia - ib;
  return String(a).localeCompare(String(b), 'ko');
}

// 수집 데이터 → 화면에 필요한 숫자
function analyze(prod) {
  const raw = prod.raw;
  if (!raw) return null;
  const now = raw.ts, D = 864e5;
  const sales = (raw.sales || []).filter(s => s.t && s.p);
  const in7 = sales.filter(s => now - s.t <= 7 * D);
  const inP = sales.filter(s => now - s.t <= S.days * D);
  const oldest = sales.length ? Math.min(...sales.map(s => s.t)) : now;
  // 불러온 거래가 7일을 못 채우면(너무 많이 팔리는 상품) 속도로 7일치를 추정
  let est7 = in7.length, estimated = false;
  if (sales.length >= 50 && now - oldest < 7 * D) {
    est7 = Math.round(sales.length / Math.max((now - oldest) / 36e5, 1) * 168);
    estimated = true;
  }
  const coversDays = Math.round((now - oldest) / D * 10) / 10;

  const map = {};
  const get = o => (map[o] = map[o] || { o, n7: 0, n7F: 0, nP: 0, sumP: 0, last: null, lastT: 0, minAsk: null, askQty: 0, minAskN: null, askQtyN: 0, minAskF: null, askQtyF: 0, maxBid: null, bidQty: 0 });
  for (const s of inP) { const x = get(s.o); x.nP++; x.sumP += s.p; if (s.t > x.lastT) { x.lastT = s.t; x.last = s.p; } }
  for (const s of in7) { const x = get(s.o); x.n7++; if (s.f) x.n7F++; }
  // 판매입찰을 일반 / 보관(빠른배송)으로 나눠서 최저가 계산 (예전에 모은 데이터는 구분이 없어서 전체로 봐요)
  const hasF = (raw.asks || []).some(a => a.f !== undefined);
  const mode = S.mode === 'fast' ? 'fast' : 'normal';
  for (const a of raw.asks || []) {
    const x = get(a.o), q = a.q || 1;
    if (a.f) { x.askQtyF += q; if (x.minAskF == null || a.p < x.minAskF) x.minAskF = a.p; }
    else { x.askQtyN += q; if (x.minAskN == null || a.p < x.minAskN) x.minAskN = a.p; }
  }
  for (const x of Object.values(map)) {
    if (!hasF) { x.minAsk = [x.minAskN, x.minAskF].filter(v => v != null).sort((a, b) => a - b)[0] ?? null; x.askQty = x.askQtyN + x.askQtyF; }
    else if (mode === 'fast') { x.minAsk = x.minAskF; x.askQty = x.askQtyF; }
    else { x.minAsk = x.minAskN; x.askQty = x.askQtyN; }
  }
  for (const b of raw.bids || []) { const x = get(b.o); x.bidQty += b.q || 1; if (x.maxBid == null || b.p > x.maxBid) x.maxBid = b.p; }
  const one = Object.keys(map).length === 1;
  if (one) { const x = Object.values(map)[0]; if (x.minAsk == null && raw.buyNow) x.minAsk = raw.buyNow; if (x.maxBid == null && raw.sellNow) x.maxBid = raw.sellNow; }

  const cost = +prod.cost || 0;
  // 판매가 = 최근 S.win일(7 또는 14일) 동안 내 판매 방식(일반/보관)으로 실제 체결된 가격의 평균.
  // 그 방식 거래가 3건이 안 되면 방식 구분 없이, 기간 안에 거래가 없으면 추이 기간 전체로 넓혀서 계산해요.
  const bySize = {};
  const sorted = [...sales].sort((a, b) => b.t - a.t);
  for (const s of sorted) (bySize[s.o] = bySize[s.o] || []).push(s);
  const win = (+S.win || 14) * D;
  const chanOf = arr => {
    if (!sales.some(s => s.f !== undefined)) return { arr, mixed: false };
    const want = mode === 'fast' ? 1 : 0;
    const c = arr.filter(s => (s.f ? 1 : 0) === want && now - s.t <= win);
    return c.length >= 3 ? { arr: arr.filter(s => (s.f ? 1 : 0) === want), mixed: false } : { arr, mixed: true };
  };
  const marketOf = all => {
    const { arr, mixed } = chanOf(all);
    let use = arr.filter(s => now - s.t <= win), wide = false;
    if (!use.length) { use = arr.filter(s => now - s.t <= S.days * D); wide = true; }
    if (!use.length) return null;
    const ps = use.map(s => s.p);
    const avg = ps.reduce((a, b) => a + b, 0) / ps.length;
    return { p: Math.floor(avg / 1000) * 1000, n: use.length, lo: Math.min(...ps), hi: Math.max(...ps), lastT: use[0].t, mixed, wide };
  };
  // 예상 판매가 = 최근 체결 평균. 최저 판매입찰·구매입찰은 참고로만 보여줘요.
  const expect = (minAsk, mkt) => {
    if (!mkt) return { sell: null, basis: '최근 체결 없음 · 판매가를 정할 수 없어요' };
    let basis = `최근 ${mkt.wide ? S.days : S.win}일 체결 평균`;
    if (minAsk && minAsk < mkt.p) basis += ` · 지금 판매입찰 ${won(minAsk)}이 더 쌈`;
    return { sell: mkt.p, basis };
  };
  const sizes = Object.values(map).sort((a, b) => sizeSort(a.o, b.o)).map(x => {
    x.avg = x.nP ? Math.round(x.sumP / x.nP) : null;
    x.mkt = marketOf(bySize[x.o] || []);
    const { sell, basis } = expect(x.minAsk, x.mkt);
    x.sell = sell; x.basis = basis;
    x.fee = feeOf(sell, prod); x.settle = sell ? sell - x.fee : null;
    x.be = x.settle != null ? x.settle - S.ship : null;
    x.margin = x.settle != null && cost ? x.settle - S.ship - cost : null;
    return x;
  });
  const med = median(sizes.filter(x => x.n7 > 0).map(x => x.n7));
  for (const x of sizes) {
    if (!x.n7) x.advice = ['비추', '최근 7일 거래 없음'];
    else if (cost && x.margin != null && x.margin <= 0) x.advice = ['비추', '손해'];
    else if (x.n7 >= med) x.advice = ['추천', '잘 팔림'];
    else x.advice = ['보통', ''];
    x.crowd = x.n7 && x.askQty > x.n7;
  }

  // 대표 판매가: 내가 정한 사이즈가 있으면 그 사이즈들, 없으면 전체에서 가장 싼 판매입찰
  const want = String(prod.sizes || '').split(/[,/\s]+/).map(s => s.trim().toUpperCase()).filter(Boolean);
  const pool = want.length ? sizes.filter(x => want.includes(String(x.o).toUpperCase())) : sizes;
  let head = null;
  const withAsk = pool.filter(x => x.minAsk);
  if (withAsk.length) head = withAsk.reduce((a, b) => (a.minAsk <= b.minAsk ? a : b));
  else if (pool.length) head = pool.filter(x => x.sell).sort((a, b) => b.sell - a.sell)[0] || null;
  // 상품 전체 시세: 고른 사이즈들(없으면 전체)의 최근 체결로 계산
  const poolSet = new Set(pool.map(x => x.o));
  const market = marketOf(sorted.filter(s => poolSet.has(s.o)));
  const minAskAll = withAsk.length ? Math.min(...withAsk.map(x => x.minAsk)) : null;
  const ex = pool.length === 1 ? { sell: pool[0].sell, basis: pool[0].basis } : expect(minAskAll, market);
  const sell = ex.sell;
  const basis = ex.basis;
  const fee = feeOf(sell, prod), settle = sell ? sell - fee : null;
  const be = settle != null ? settle - S.ship : null;
  const margin = settle != null && cost ? settle - S.ship - cost : null;

  // 일별 추이
  const days = S.days, buckets = [];
  const dayStart = t => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const end = dayStart(now);
  for (let i = days - 1; i >= 0; i--) buckets.push({ d: end - i * D, n: 0, sum: 0, min: null, max: null });
  for (const s of inP) {
    const idx = Math.round((dayStart(s.t) - buckets[0].d) / D);
    const b = buckets[idx]; if (!b) continue;
    b.n++; b.sum += s.p; b.min = b.min == null ? s.p : Math.min(b.min, s.p); b.max = b.max == null ? s.p : Math.max(b.max, s.p);
  }
  buckets.forEach(b => { b.avg = b.n ? Math.round(b.sum / b.n) : null; });
  const avgOf = arr => arr.length ? Math.round(arr.reduce((a, s) => a + s.p, 0) / arr.length) : null;
  const avg7 = avgOf(in7), avgPrev = avgOf(inP.filter(s => now - s.t > 7 * D));
  const trendPct = avg7 && avgPrev ? (avg7 - avgPrev) / avgPrev * 100 : null;

  let verdict;
  if (!sales.length) verdict = ['mute', '거래 없음'];
  else if (S.min7 && est7 < S.min7) verdict = ['warn', '매입 불필요 · 회전 느림'];
  else if (!cost) verdict = ['mute', '매입가 입력'];
  else if (margin > 0) verdict = ['ok', '남음'];
  else verdict = ['bad', '손해'];

  const fastShare = in7.length ? Math.round(in7.filter(s => s.f).length / in7.length * 100) : null;
  return { sizes, hasF, mode, fastShare, market, minAskAll, basis, est7, estimated, n7: in7.length, nP: inP.length, coversDays, sell, fee, settle, be, margin, head, buckets, avg7, avgPrev, trendPct, verdict, want };
}

function speedText(n, est) {
  if (!n) return ['slow', '7일간 거래 없음'];
  const t = n >= 168 ? `시간당 ${(n / 168).toFixed(1)}개` : `${(168 / n).toFixed(1)}시간에 1개`;
  return [n >= S.min7 || !S.min7 ? '' : 'slow', (est ? '약 ' : '') + t];
}

// ---------- 거래 추이 차트 (SVG) ----------
function chartSVG(a) {
  const W = 640, H = 200, P = { l: 52, r: 10, t: 12, b: 26 };
  const bs = a.buckets, n = bs.length;
  const pts = bs.filter(b => b.avg);
  if (!pts.length) return '<p class="hint">기간 안에 체결된 거래가 없어요.</p>';
  let lo = Math.min(...pts.map(b => b.min)), hi = Math.max(...pts.map(b => b.max));
  if (lo === hi) { lo -= 1000; hi += 1000; }
  const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const maxN = Math.max(...bs.map(b => b.n), 1);
  const x = i => P.l + (W - P.l - P.r) * (n === 1 ? 0.5 : i / (n - 1));
  const y = v => P.t + (H - P.t - P.b) * (1 - (v - lo) / (hi - lo));
  const barH = c => (H - P.t - P.b) * 0.35 * c / maxN;
  const bw = Math.max(2, (W - P.l - P.r) / n * 0.6);
  let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="일별 평균 체결가와 거래 수">`;
  for (let k = 0; k <= 3; k++) {
    const v = lo + (hi - lo) * k / 3, yy = y(v);
    s += `<line x1="${P.l}" x2="${W - P.r}" y1="${yy}" y2="${yy}" stroke="var(--line)" />`;
    s += `<text x="${P.l - 6}" y="${yy + 4}" font-size="10.5" text-anchor="end" fill="var(--sub)">${Math.round(v / 1000)}천</text>`;
  }
  bs.forEach((b, i) => { if (b.n) s += `<rect x="${x(i) - bw / 2}" y="${H - P.b - barH(b.n)}" width="${bw}" height="${barH(b.n)}" fill="var(--acc)" opacity=".18"><title>${new Date(b.d).getMonth() + 1}/${new Date(b.d).getDate()} · ${b.n}건</title></rect>`; });
  bs.forEach((b, i) => { if (b.n) s += `<line x1="${x(i)}" x2="${x(i)}" y1="${y(b.min)}" y2="${y(b.max)}" stroke="var(--acc)" opacity=".35" />`; });
  let d = '';
  bs.forEach((b, i) => { if (b.avg) d += (d ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(b.avg).toFixed(1); });
  s += `<path d="${d}" fill="none" stroke="var(--acc)" stroke-width="2" />`;
  bs.forEach((b, i) => { if (b.avg) s += `<circle cx="${x(i)}" cy="${y(b.avg)}" r="2.6" fill="var(--acc)"><title>${new Date(b.d).getMonth() + 1}/${new Date(b.d).getDate()} 평균 ${won(b.avg)} · ${b.n}건 (최저 ${won(b.min)} / 최고 ${won(b.max)})</title></circle>`; });
  [0, Math.floor((n - 1) / 2), n - 1].forEach(i => { const dt = new Date(bs[i].d); s += `<text x="${x(i)}" y="${H - 8}" font-size="10.5" text-anchor="${i === 0 ? 'start' : i === n - 1 ? 'end' : 'middle'}" fill="var(--sub)">${dt.getMonth() + 1}/${dt.getDate()}</text>`; });
  return s + '</svg>';
}

// ---------- 내 상품 화면 ----------
function renderMine() {
  const mh = $('#modeHint'); if (mh) mh.textContent = `최근 ${S.win}일 체결 평균 · ${MODE_NAME[S.mode === 'fast' ? 'fast' : 'normal']}`;
  const mh2 = $('#mktHint'); if (mh2) mh2.textContent = `최근 ${S.win}일 실제 팔린 가격 평균`;
  $('#mineCount').textContent = products.length ? products.length + '개' : '';
  $('#mineEmpty').hidden = products.length > 0;
  const rows = products.map(p => {
    const a = analyze(p);
    const info = (p.raw && p.raw.info) || {};
    const name = info.name || ('크림 상품 ' + p.pid);
    const img = info.img ? `<img class="thumb" src="${esc(info.img)}" alt="">` : '';
    const at = p.at ? new Date(p.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
    let cells;
    if (!a) {
      cells = `<td colspan="7" class="l small">${p.err ? '⚠️ ' + esc(p.err) : '아직 수집 전이에요. 전체 시세 수집 또는 오른쪽 수집 버튼을 누르세요.'}</td><td></td>`;
    } else {
      const [sc, st] = speedText(a.est7, a.estimated);
      cells = `
        <td><div class="n">${a.est7.toLocaleString('ko-KR')}건</div><div class="speed ${sc}">${st}</div></td>
        <td><div class="n">${won(a.market && a.market.p)}</div><div class="small">${mktText(a.market)}</div></td>
        <td><div class="big">${won(a.sell)}</div><div class="small">${esc(a.basis || '')}</div></td>
        <td><div class="n">${won(a.settle)}</div><div class="small">수수료 ${won(a.fee)}</div></td>
        <td><div class="big ${a.margin > 0 ? 'pos' : a.margin != null ? 'neg' : ''}">${a.margin != null ? sign(a.margin) : '–'}</div><div class="small">${a.margin != null && p.cost ? (a.margin / p.cost * 100).toFixed(1) + '%' : ''}</div></td>
        <td><div class="be">${won(a.be)}</div></td>
        <td><span class="pill ${a.verdict[0]}">${a.verdict[1]}</span></td>`;
    }
    return `<tr class="item" data-id="${p.id}">
      <td class="l name">${img}<b>${esc(name)}</b><span class="code">${esc(info.code || '')}${p.sizes ? ' · 사이즈 ' + esc(p.sizes) : ''}</span><div class="small">${at ? '수집 ' + at : ''}${p.memo ? ' · ' + esc(p.memo) : ''}</div>${p.src ? `<div class="small srcline ${p.src.sites.some(x => x.level && (x.tier || 'trust') === 'trust') ? '' : 'neg'}">${esc(srcSummaryText(p.src))}</div>` : ''}</td>
      <td><input class="cost-in" type="number" step="10" min="0" value="${p.cost || ''}" data-cost="${p.id}" aria-label="매입가"></td>
      ${cells}
      <td><div class="act"><button type="button" class="ghost" data-collect="${p.id}">수집</button><button type="button" class="ghost del" data-del="${p.id}" title="이 상품 삭제">삭제</button></div></td>
    </tr>` + (openId === p.id ? `<tr class="detail"><td colspan="10">${detailHTML(p, a)}</td></tr>` : '');
  });
  $('#mineRows').innerHTML = rows.join('');
  if (!$('#cleanBox').hidden) renderClean();
  // 상품 사진을 못 불러오면 빈 칸 대신 숨기기
  document.querySelectorAll('#mineRows img.thumb').forEach(img => img.addEventListener('error', () => { img.hidden = true; }, { once: true }));
}

function detailHTML(p, a) {
  const info = (p.raw && p.raw.info) || {};
  const opts = `<div class="box"><h3>이 상품 설정</h3><div class="opt-grid">
      <label>내 사이즈 (쉼표로)<input data-f="sizes" value="${esc(p.sizes || '')}" placeholder="비우면 전체"></label>
      <label>메모<input data-f="memo" value="${esc(p.memo || '')}"></label>
      <label>수수료율 (%) · 이 상품만<input data-f="rate" type="number" step="0.1" value="${p.rate ?? ''}" placeholder="${S.rate}"></label>
      <label>기본 수수료 (원) · 이 상품만<input data-f="base" type="number" step="10" value="${p.base ?? ''}" placeholder="${S.base}"></label>
    </div>
    <div class="row-btns" style="margin-top:10px">
      <a class="ghost" href="https://kream.co.kr/products/${esc(p.pid)}" target="_blank" rel="noopener">크림에서 보기</a>
      <button type="button" class="ghost del" data-del="${p.id}">삭제</button>
    </div></div>`;
  if (!a) return `<div class="det">${opts}</div>`;
  const trend = a.trendPct == null ? '' : `최근 7일 평균 ${won(a.avg7)} · 그 전보다 <b class="${a.trendPct >= 0 ? 'pos' : 'neg'}">${a.trendPct >= 0 ? '▲' : '▼'} ${Math.abs(a.trendPct).toFixed(1)}%</b>`;
  const kv = `<dl class="kv">
      <dt>발매가</dt><dd>${esc(info.relRaw || (info.rel ? won(info.rel) : '–'))}</dd>
      <dt>최근 7일 거래</dt><dd>${a.estimated ? '약 ' : ''}${a.est7.toLocaleString('ko-KR')}건${a.estimated ? ` (불러온 ${a.coversDays}일치로 추정)` : ''}</dd>
      <dt>최근 ${S.days}일 거래 (불러온 범위)</dt><dd>${a.nP.toLocaleString('ko-KR')}건${a.coversDays < S.days ? ` · ${a.coversDays}일치까지만 불러옴` : ''}</dd>
      <dt>내 판매 방식</dt><dd>${MODE_NAME[a.mode]}${a.hasF ? '' : ' <span class="small">(이 데이터는 구분 전이라 전체 기준 — 다시 수집하세요)</span>'}</dd>
      <dt>7일 체결 중 보관(빠른배송)</dt><dd>${a.fastShare == null ? '–' : a.fastShare + '%'}</dd>
      <dt>최근 ${S.win}일 체결 평균</dt><dd><b>${won(a.market && a.market.p)}</b> <span class="small">${mktText(a.market)}</span></dd>
      <dt>${MODE_NAME[a.mode]} 최저 판매입찰</dt><dd>${won(a.minAskAll)}</dd>
      <dt>예상 판매가</dt><dd><b>${won(a.sell)}</b><div class="small">${esc(a.basis || '')}</div></dd>
      <dt>수수료 / 발송비</dt><dd>${won(a.fee)} / ${won(S.ship)}</dd>
      <dt>손익분기 매입가</dt><dd class="be">${won(a.be)}</dd>
    </dl>`;
  const want = a.want;
  const sz = `<table class="sz"><thead><tr><th class="l">사이즈</th><th>7일 거래</th><th>최근 ${S.win}일 평균<small>건수</small></th><th>${S.days}일 평균가</th><th>일반 최저 (수량)</th><th>보관 최저 (수량)</th><th>최고 구매입찰</th><th>예상 판매가</th><th>예상 순마진</th><th>손익분기</th><th class="l">추천</th></tr></thead><tbody>${
    a.sizes.map(x => `<tr class="${want.includes(String(x.o).toUpperCase()) ? 'mine' : ''}">
      <td class="l"><b>${esc(x.o)}</b></td><td>${x.n7}건${x.n7F ? ` <span class="small">(보관 ${x.n7F})</span>` : ''}</td><td>${x.mkt ? won(x.mkt.p) + ` <span class="small">(${x.mkt.n})</span>` : '<span class="small">없음</span>'}</td><td>${won(x.avg)}</td>
      ${a.hasF ? [['N', 'normal'], ['F', 'fast']].map(([k, md]) => `<td class="${a.mode === md ? 'pickcol' : ''}">${x['minAsk' + k] ? won(x['minAsk' + k]) + ` <span class="small">(${x['askQty' + k]})</span>` : '<span class="small">없음</span>'}</td>`).join('')
        : `<td colspan="2">${x.minAsk ? won(x.minAsk) + ` <span class="small">(${x.askQty}, 구분 전)</span>` : '<span class="small">없음</span>'}</td>`}
      <td>${won(x.maxBid)}</td><td><b>${won(x.sell)}</b>${x.basis && !/최저 판매입찰/.test(x.basis) ? `<div class="small">${esc(x.basis)}</div>` : ''}</td>
      <td class="${x.margin > 0 ? 'pos' : x.margin != null ? 'neg' : ''}">${x.margin != null ? sign(x.margin) : '–'}</td><td class="be">${won(x.be)}</td>
      <td class="l"><span class="pill ${x.advice[0] === '추천' ? 'ok' : x.advice[0] === '비추' ? 'bad' : 'mute'}">${x.advice[0]}</span> <span class="small">${[x.advice[1], x.crowd ? '판매입찰 많음' : ''].filter(Boolean).join(' · ')}</span></td></tr>`).join('')
  }</tbody></table>`;
  return `<div class="det">
    <div class="det-top">
      <div class="box chart"><h3>최근 ${S.days}일 거래 추이 <span class="small">선: 일별 평균 체결가 · 막대: 거래 수</span></h3>${chartSVG(a)}<p class="hint">${trend}</p></div>
      <div class="box">${kv}</div>
    </div>
    ${srcBoxHTML(p.src, a.be, info.name, info.code, 'ghost', true, a.sell)}
    ${trackBoxHTML(p, a)}
    <div class="box" style="overflow-x:auto"><h3>사이즈별 정리 <span class="small">판매입찰은 싼 순서로 약 250건까지 불러와요. '없음'은 더 비싼 입찰만 있거나 입찰이 없는 거예요.</span></h3>${sz}</div>
    ${opts}
  </div>`;
}

// ---------- 수집 ----------
let work = { winId: null, tabId: null };
// 3.7: 크림 작업은 웨~일에서 해요(프로그램). 작업 창이 크림 ↔ 다른 쇼핑몰로 바뀌면 창을 새로 열어요 (웨~일 창 ↔ 프로그램 창)
const isKreamUrl = u => /^https?:\/\/([\w-]+\.)*kream\.co\.kr(\/|$|\?)/i.test(String(u || ''));
async function sameSide(url, W) { try { const t = await chrome.tabs.get((W || work).tabId); return isKreamUrl(t.url) === isKreamUrl(url); } catch (e) { return false; } }
// 웨일 확장으로 쓸 때는 프로그램 전용 옵션(background)을 빼요
function winOpts(o) { if (!(window.__KC_APP && window.kcApp)) { const { background, part, ...r } = o; return r; } if (!o.part) { const { part, ...r } = o; return r; } return o; }
// 3.8.0: 지금 작업 창이 쓸 로그인 저장 공간 (다른 아이디 주문 읽을 때만 바뀌어요)
let navPart = '';
// 3.4.5: 크림이 가끔 처음 열 때만 빈 화면(응답 500)을 줘요 — 새로고침하면 정상이라, 비어 있으면 새로고침해서 다시 받아요
async function kreamHeal(tabId) {
  const blank = async () => { try { const t = await chrome.tabs.get(tabId); if (!isKreamUrl(t.url)) return false; const [b] = await execT({ target: { tabId }, func: kcPageInfo }, 15000); return !!(b && b.result && b.result.n < 3000 && !b.result.title); } catch (e) { return false; } };
  for (let i = 0; i < 1; i++) {   // 3.5.0: 크림에 요청을 덜 보내게 새로고침은 한 번만
    if (!(await blank())) return true;
    try { await chrome.tabs.reload(tabId, { bypassCache: i > 0 }); } catch (e) { return false; }
    await sleep(1200);
    const end = Date.now() + 30000;
    while (Date.now() < end) { const t = await chrome.tabs.get(tabId).catch(() => null); if (!t) return false; if (t.status === 'complete') break; await sleep(400); }
  }
  return !(await blank());
}
async function workTab(url) {
  let alive = false;
  if (work.winId) { try { await chrome.windows.get(work.winId); alive = true; } catch (e) {} }
  if (alive && (!(await sameSide(url)) || (work.part || '') !== navPart)) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; alive = false; }
  if (!alive) {
    const w = await chrome.windows.create(winOpts({ url, type: 'popup', width: 1180, height: 900, focused: !+S.bgWork, background: !!+S.bgWork, part: navPart }));
    work = { winId: w.id, tabId: w.tabs[0].id, part: navPart };
  } else {
    await chrome.tabs.update(work.tabId, { url, active: true });
    if (!+S.bgWork) await chrome.windows.update(work.winId, { focused: true, state: 'normal' });
  }
  const end = Date.now() + 40000;
  await sleep(800);
  while (Date.now() < end) {
    const t = await chrome.tabs.get(work.tabId);
    if (t.status === 'complete' && (t.url || '').startsWith(url)) { await kreamHeal(work.tabId); return work.tabId; }
    await sleep(400);
  }
  throw new Error('크림 페이지가 열리지 않았어요');
}

function ask(tabId, msg, ms) {
  return Promise.race([
    chrome.tabs.sendMessage(tabId, msg),
    new Promise((_, rej) => setTimeout(() => rej(new Error('시간 초과')), ms))
  ]);
}

async function collectOne(p, opts) {
  const url = 'https://kream.co.kr/products/' + p.pid;
  const tabId = await workTab(url);
  // 3.4.5: 크림이 빈 화면(응답 500)을 주면 새로고침으로 다시 받아요. 그래도 비면 빈 결과로 덮어쓰지 않고 원인을 보여줘요
  if (!(await kreamHeal(tabId))) {
    let t = null; try { t = await chrome.tabs.get(tabId); } catch (e) {}
    const nv = t && t.nav; throw new Error(`크림이 화면을 안 줬어요${nv ? ` (응답 ${nv.fail || (nv.code + ' ' + (nv.st || ''))})` : ''} — 크림이 요청을 거절하는 중이에요. 몇 시간 뒤 다시 수집해 주세요 (이전 시세는 그대로)`);
  }
  let res, lastErr;
  for (let i = 0; i < 3; i++) {
    try { res = await ask(tabId, { cmd: 'kc-collect', opts: opts || { days: S.days, maxPages: Math.min(60, Math.max(10, Math.ceil(S.days / 3 * 2))) } }, 360000); break; }
    catch (e) { lastErr = e; await sleep(1500); }
  }
  if (!res) throw lastErr || new Error('응답 없음');
  if (res.error) throw new Error(res.error);
  if (!(res.info && res.info.name)) { let t = null; try { t = await chrome.tabs.get(tabId); } catch (e) {} const nv = t && t.nav; throw new Error(`크림 상품 화면을 못 읽었어요${nv ? ` (응답 ${nv.fail || (nv.code + ' ' + (nv.st || ''))})` : ''} — 이전 시세는 그대로 뒀어요`); }
  if (/login/.test(res.info && res.info.name || '')) throw new Error('크림 로그인이 필요해요');
  // 3.4.3: 거래 내역을 더 보려다 크림 로그인 화면으로 넘어갔으면 알려줘요
  try { const t = await chrome.tabs.get(tabId); if (/kream\.co\.kr\/login/.test(t.url || '') && !(res.sales || []).length) throw new Error('크림 로그인이 필요해요 — 계정 연결에서 크림 \'직접 로그인\'을 한 번 해 주세요'); } catch (e) { if (/로그인/.test(e.message)) throw e; }
  p.raw = res; p.at = Date.now(); p.err = null;
}

async function runCollect(list) {
  if (!HAS_CHROME) { alertBox('크림스캐너 안에서만 수집할 수 있어요'); return; }
  stopFlag = false;
  $('#btnCollectAll').disabled = true; $('#btnSrcAll').disabled = true; $('#btnStop').hidden = false; $('#progress').hidden = false;
  let done = 0, fail = 0;
  let kreamFail = 0;
  for (const p of list) {
    if (stopFlag) break;
    $('#progText').textContent = `${done + 1} / ${list.length} 수집 중${+S.bgWork ? ' — 뒤에서 실행 중이에요' : ' — 새로 열린 크림 창은 닫거나 최소화하지 마세요 (다른 창을 위에 띄우는 건 괜찮아요)'}`;
    $('#progBar').style.width = (done / list.length * 100) + '%';
    try { await collectOne(p); kreamFail = 0; }
    catch (e) { p.err = '수집 실패: ' + e.message; fail++; if (/비어서|못 불러왔|500/.test(e.message)) kreamFail++; }
    finally { if (work.tabId > 1e9) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; } }   // 3.7.1: 웨일 창은 상품마다 새로 (오래 숨겨 두면 웨일이 느리게 돌려서)
    done++;
    // 3.5.0: 크림이 연달아 거절하면(로그인 세션이 막힌 상태) 더 두드리지 않고 멈춰요
    if (kreamFail >= 2) { stopFlag = true; alertBox('크림이 크림스캐너의 로그인 요청을 계속 거절하고 있어서 수집을 멈췄어요. 한동안(몇 시간) 쉬었다가 다시 해 주세요. 그동안 이전 시세는 그대로 둬요.'); }
    await saveProducts(); renderMine();
    await sleep(1500 + Math.random() * 2000);
  }
  $('#progBar').style.width = '100%';
  $('#progText').textContent = (stopFlag ? `중지했어요 (${done}개 수집)` : `끝났어요 — ${done}개 중 ${done - fail}개 성공`) + ' · 휴대폰에서도 보려면 [휴대폰으로 보내기]';
  $('#btnCollectAll').disabled = false; $('#btnSrcAll').disabled = false; $('#btnStop').hidden = true;
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  setTimeout(() => { $('#progress').hidden = true; }, 6000);
}

// 수집·매입처 찾기는 같은 작업 창을 쓰니까 하나씩 차례로 (진행 중에 상품을 추가해도 꼬이지 않게)
let jobChain = Promise.resolve(), jobGen = 0;
// 한 작업이 20분 넘게 안 끝나면(창이 멈춤 등) 다음 작업이 영원히 기다리지 않게 넘어가요
let jobBusy = 0;
// 3.0.1: 지금 도는 작업·기다리는 작업을 위쪽 막대에 보여줘요 (버튼이 멈춘 것처럼 보이지 않게)
let jobNow = null, jobDetail = '';
const jobWait = [];
function jobChipRender() {
  const c = $('#jobChip'), b = $('#btnJobStop'); if (!c) return;
  if (!jobNow && !jobWait.length) { c.hidden = true; if (b) b.hidden = true; return; }
  c.hidden = false; if (b) b.hidden = false;
  c.textContent = `작업 중: ${jobNow || '준비'}${jobDetail ? ' — ' + jobDetail : ''}${jobWait.length ? ` · 대기 ${jobWait.length}개 (${jobWait.map(w => w.label).join(', ')})` : ''}`;
  c.title = c.textContent;
}
function jobSay(t) { jobDetail = String(t || '').slice(0, 60); jobChipRender(); }
function queueJob(fn, o) {
  const g = jobGen; o = o || {};
  const me = { label: o.label || '작업', onSkip: o.onSkip };
  jobWait.push(me); jobChipRender();
  if (jobBusy) { const m = $('#addMsg'); if (m) m.textContent = `앞의 작업(${jobNow || '작업'})이 끝나면 바로 시작해요. 오래 걸리면 위쪽 '중지'를 누르세요.`; const st = $('#btnStop'); if (st) st.hidden = false; }
  jobChain = jobChain.then(async () => {
    const wi = jobWait.indexOf(me); if (wi >= 0) jobWait.splice(wi, 1);
    if (g !== jobGen) { try { me.onSkip && me.onSkip(); } catch (e) {} jobChipRender(); return null; }
    jobBusy++; jobNow = me.label; jobDetail = ''; jobChipRender();
    try { return o.noTimeout ? await fn() : await Promise.race([fn(), new Promise(r => setTimeout(r, 20 * 60000))]); }
    catch (e) { console.warn(e); const m = $('#addMsg'); if (m) m.textContent = /context invalidated/i.test(e.message) ? '확장 프로그램이 업데이트됐어요. 이 탭을 닫고 크림스캐너를 다시 열어 주세요.' : '작업이 멈췄어요: ' + e.message; }
    finally { jobBusy--; if (!jobBusy) { jobNow = null; jobDetail = ''; } jobChipRender(); }
  });
  return jobChain;
}
// 위쪽 '중지': 지금 작업은 멈추고, 기다리던 작업도 모두 취소해요
async function jobStopAll() {
  stopFlag = true; jobGen++;
  const waiting = jobWait.splice(0); for (const w of waiting) { try { w.onSkip && w.onSkip(); } catch (e) {} }
  jobChain = Promise.resolve(); jobBusy = 0; jobNow = null; jobDetail = '';
  if (typeof SQ !== 'undefined') { SQ.run = false; if (SQ.work && SQ.work.winId) { try { await chrome.windows.remove(SQ.work.winId); } catch (e) {} SQ.work = { winId: null, tabId: null }; } }
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  if (typeof AC !== 'undefined') { AC.busy = new Set(); AC.wait = 0; if (typeof renderAcct === 'function') renderAcct(); }
  if (typeof XS !== 'undefined') { XS.busy = false; }
  jobChipRender();
}
// ---------- 정품 매입처 자동 찾기 ----------
// 각 사이트 검색 결과를 실제로 열어서, 이 상품(모델번호 또는 브랜드+모델명)이 있는 곳만 남김.
const BRAND_ALIAS = { '나이키': ['nike'], '조던': ['jordan', 'nike', '나이키'], '뉴발란스': ['newbalance'], '아디다스': ['adidas'], '아식스': ['asics'], '오니츠카타이거': ['onitsuka'],
  '푸마': ['puma'], '컨버스': ['converse'], '반스': ['vans'], '노스페이스': ['northface'], '살로몬': ['salomon'], '호카': ['hoka'], '리복': ['reebok'], '휠라': ['fila'] };
// tier: trust = 정품 유통(백화점·아울렛·공식몰·브랜드 편집숍) / market = 오픈마켓·입점 판매자(가품 주의, 판매자 확인)
// split: 한 사이트 안에 백화점 상품과 일반 판매자 상품이 섞인 곳 — trust()로 나눠서 두 줄로 보여줌
const SRC_SITES = [
  { k: 'musinsa', label: '무신사', tier: 'trust', kind: 'both', url: q => `https://www.musinsa.com/search/goods?keyword=${q}` },
  { k: 'rexmonde', label: '렉스몬드', tier: 'trust', kind: 'both', url: q => `https://www.rexmonde.com/products/list?search_keyword=${q}` },   // 오케이몰 새 이름. 모델번호가 맞으면 상품 상세로 바로 감
  { k: '29cm', label: '29CM', tier: 'trust', kind: 'both', url: q => `https://www.29cm.co.kr/store/search?keyword=${q}` },
  { k: 'ssf', label: 'SSF샵', tier: 'trust', kind: 'both', url: q => `https://www.ssfshop.com/search/result?keyword=${q}` },
  { k: 'lotte', label: '롯데백화점·아울렛 (롯데ON)', tier: 'trust', kind: 'both', url: q => `https://www.lotteon.com/search/search/search.ecn?render=search&platform=pc&q=${q}`,
    trust: (t, h) => /^(롯데백화점|롯데아울렛|롯데프리미엄아울렛|엘롯데)/.test(t) || /\/product\/LE\d/.test(h), split: { k: 'lotte-m', label: '롯데ON 일반 판매자' } },
  { k: 'ssg', label: '신세계백화점 (SSG)', tier: 'trust', kind: 'both', url: q => `https://www.ssg.com/search.ssg?target=all&query=${q}`,
    trust: (t, h) => /siteNo=6009/.test(h), split: { k: 'ssg-m', label: 'SSG 일반 판매자' } },   // 6009 = 신세계백화점
  { k: 'abc', label: 'ABC마트', tier: 'trust', kind: 'both', url: q => `https://abcmart.a-rt.com/display/search-word/result?searchWord=${q}` },
  { k: 'gs', label: '그랜드스테이지', tier: 'trust', kind: 'both', url: q => `https://grandstage.a-rt.com/display/search-word/result?searchWord=${q}` },
  { k: 'shoemarker', label: '슈마커', tier: 'trust', kind: 'both', url: q => `https://www.shoemarker.co.kr/ASP/Product/SearchProductList.asp?SearchWord=${q}` },
  { k: 'nike', label: '나이키 공식몰', tier: 'trust', kind: 'both', brand: /나이키|nike|조던|jordan/i, url: q => `https://www.nike.com/kr/w?q=${q}` },
  { k: 'adidas', label: '아디다스 공식몰', tier: 'trust', kind: 'both', brand: /아디다스|adidas/i, url: q => `https://www.adidas.co.kr/search?q=${q}` },
  { k: 'nb', label: '뉴발란스 공식몰', tier: 'trust', kind: 'both', brand: /뉴발란스|new balance/i, url: q => `https://www.nbkorea.com/product/searchResult.action?schWord=${q}` },
  { k: 'asics', label: '아식스 공식몰', tier: 'trust', kind: 'both', brand: /아식스|asics|오니츠카|onitsuka/i, url: q => `https://www.asics.co.kr/goods/search?search_text=${q}` },
  { k: 'puma', label: '푸마 공식몰', tier: 'trust', kind: 'both', brand: /푸마|puma/i, url: q => `https://kr.puma.com/kr/ko/search?q=${q}` },
  { k: 'converse', label: '컨버스 공식몰', tier: 'trust', kind: 'both', brand: /컨버스|converse/i, url: q => `https://www.converse.co.kr/product/search.html?keyword=${q}` },
  { k: 'vans', label: '반스 공식몰', tier: 'trust', kind: 'both', brand: /반스|vans/i, url: q => `https://www.vans.co.kr/search?q=${q}` },
  { k: 'tnf', label: '노스페이스 공식몰', tier: 'trust', kind: 'both', brand: /노스페이스|north ?face/i, url: q => `https://www.thenorthfacekorea.co.kr/search?q=${q}` },
  // 오픈마켓·입점 판매자 — 모델번호로만 검색 (상품명 검색은 엉뚱한 상품이 너무 많음)
  { k: 'coupang', label: '쿠팡', tier: 'market', kind: 'code', url: q => `https://www.coupang.com/np/search?q=${q}` },
  { k: 'gmarket', label: 'G마켓', tier: 'market', kind: 'code', url: q => `https://www.gmarket.co.kr/n/search?keyword=${q}` },
  { k: '11st', label: '11번가', tier: 'market', kind: 'code', url: q => `https://search.11st.co.kr/Search.tmall?kwd=${q}` },
  { k: 'wconcept', label: 'W컨셉', tier: 'market', kind: 'code', url: q => `https://display.wconcept.co.kr/search?keyword=${q}` },
  { k: 'zigzag', label: '지그재그', tier: 'market', kind: 'code', url: q => `https://zigzag.kr/search?keyword=${q}` },
  { k: 'ably', label: '에이블리', tier: 'market', kind: 'code', url: q => `https://m.a-bly.com/search/search-result?query=${q}&search_type=DIRECT` },
  { k: '4910', label: '4910', tier: 'market', kind: 'code', url: q => `https://4910.kr/desktop/search?query=${q}&search_type=DIRECT` },
  // 다른 리셀 플랫폼 — 매입처가 아니라 '어디에 팔면 더 받나' 비교용
  { k: 'soldout', label: '솔드아웃', tier: 'platform', kind: 'code', url: q => `https://www.soldout.co.kr/search/product/list?keyword=${q}` },
  { k: 'poizon', label: '포이즌', tier: 'platform', kind: 'code', url: q => `https://kr.poizon.com/search?keyword=${q}` }
];
const nrm = s => String(s || '').toLowerCase().replace(/[^0-9a-z가-힣]/g, '');
const COLOR_SKIP = /^(로우|하이|미드|og|레트로|우먼스|키즈|gs|ps|td|프리미엄|sp|qs|x|앤|and|남성|여성|공용|\(w\)|\(m\))$/i;
// 같은 모델이라도 와이드·키즈·여성용은 다른 상품이라, 크림 상품명과 맞는지 따로 봄
const VARIANTS = [/와이드|wide|\b2E\b|\b4E\b/i, /키즈|kids|주니어|junior|\(GS\)|\(PS\)|\(TD\)|토들러|베이비|인펀트/i, /\(W\)|우먼스|womens?\b/i];
const GENERIC = /^(부츠|운동화|스니커즈|워터프루프|러닝화|런닝화|샌들|슬리퍼|뮬|자켓|재킷|후드|후디|티셔츠|반팔|긴팔|팬츠|바지|셔츠|코트|패딩|베스트|니트|맨투맨|레더|가죽|스웨이드|캔버스|하이탑|미드탑|로우탑|-)$/;
function srcCtx(name, code, en) {
  const { c, full, short } = srcQueries(name, code);
  const st = short.split(/\s+/);
  const b = st[0] || '';
  const brandKeys = [nrm(b), ...(BRAND_ALIAS[b] || [])].filter(Boolean);
  const enB = nrm(String(en || '').split(/\s+/).slice(0, String(en || '').toLowerCase().startsWith('new balance') ? 2 : 1).join(''));
  if (enB.length >= 3) brandKeys.push(enB);
  // 크림 모델번호 칸에 여러 개가 있으면(예: TB010061713/TB110061713) 다 같은 상품으로 봄
  const codes = String(code || '').split(/[\/,]/).map(x => x.trim()).filter(x => /[A-Za-z0-9]/.test(x) && nrm(x).length >= 5);
  const base = String(name || '').replace(/\s+-\s+.*$/, '');
  const tail = base.split(/\s+/).slice(st.length).filter(w => !/\d/.test(w) && !COLOR_SKIP.test(w) && !GENERIC.test(w));
  return { c, short, name: String(name || ''), codeN: nrm(c), codesN: [...new Set(codes.map(nrm).concat(c ? [nrm(c)] : []))].filter(x => x.length >= 5),
    codes, brandKeys, model: st.slice(1).map(nrm).filter(Boolean),
    color: tail.slice(-2).map(nrm).filter(t => t.length >= 2),
    variant: VARIANTS.map(re => re.test(String(name || '') + ' ' + String(en || ''))) };
}
// 목록 글자에서 가격·할인율 같은 부분을 빼고 상품명만 남김
const srcName = t => String(t || '').replace(/(정상가|정찰가|할인가|판매가격?|최종가|할인율|최고판매가|쿠폰가?|프로모션.*$|지금 인기|좋아요 하기)/g, ' ').replace(/\d{1,3}(,\d{3})+\s*원?~?|\d+(\.\d+)?%|\[\d+%\]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 90);
// 신발끈·깔창·양말처럼 같은 모델명이 붙은 부속품은 매입처로 안 봄 (크림 상품 이름에 그 말이 있으면 예외)
const ACC_RE = /(신발끈|슈레이스|깔창|인솔|키링|클리너|슈케어|슈트리|지비츠|스티커|더스트백|빈박스|교체용\s*끈)/i;
function accessoryLike(text, ctx) { const m = String(text).match(ACC_RE); return !!m && !ctx.name.includes(m[1]); }
function matchSrc(res, ctx, site) {
  const out = [];
  // 크림 가격의 45%보다 싼 건 다른 상품(부속품·사은품·옵션 하나)일 가능성이 커서 뺌
  const tooCheap = pr => ctx.ref && pr && (pr < ctx.ref * 0.45 || pr > ctx.ref * 4);   // 너무 싸거나 너무 비싸면 다른 상품
  const brandOk = T => !!site.brand || ctx.brandKeys.some(k => T.includes(k));
  const judge = (T, cd) => {
    if (site.trust && !site.split && !site.trust(cd.text, cd.hrefs)) return null;
    if (!brandOk(T)) return null;
    if (ctx.codesN.some(cn => T.includes(cn))) return 'strong';
    // 모델명만 맞는 건 색상(크림 이름 끝 두 단어)과 와이드·키즈·여성용 구분까지 맞아야 인정
    const raw = cd.text + ' ' + cd.alt + ' ' + cd.hrefs;
    if (ctx.variant.some((v, i) => v !== VARIANTS[i].test(raw))) return null;
    if (ctx.model.length && ctx.model.every(t => T.includes(t)) && ctx.model.join('').length >= 2 && ctx.color.every(t => T.includes(t))) return 'weak';
    return null;
  };
  // 모델번호가 딱 맞아서 상품 상세로 바로 넘어간 경우
  // 검색 결과 페이지 제목에는 검색어(모델번호)가 그대로 들어가니까, 상세 페이지일 때만 인정
  const hasCode = x => ctx.codesN.some(cn => nrm(x).includes(cn));
  const pg = res.page, onDetail = pg && !res.noResult && (hasCode(pg.path) || (!/search|result|list|srch/i.test(pg.path) && hasCode(pg.title)));
  if (pg && ctx.codesN.length && onDetail && !res.cards.some(c => hasCode(c.text + ' ' + c.hrefs))) {
    const nums = [...String(res.page.text).matchAll(/(\d{1,3}(?:,\d{3})+)\s*원/g)].map(m => +m[1].replace(/,/g, '')).filter(n => n >= 10000);
    const price = res.page.price || (nums.length ? nums[0] : null);
    if (!site.trust && !tooCheap(price)) out.push({ lv: 'strong', ok: true, name: res.page.title, price, url: res.url, soldOut: /품절|sold\s?out/i.test(res.page.text.slice(0, 600)), color: false });
  }
  for (const cd of res.cards || []) {
    const raw = cd.text + ' ' + cd.alt + ' ' + cd.hrefs, T = nrm(raw);
    const lv = judge(T, cd); if (!lv) continue;
    if (accessoryLike(cd.text + ' ' + cd.alt, ctx) || tooCheap(cd.price)) continue;
    out.push({ lv, ok: !site.trust || site.trust(cd.text, cd.hrefs), name: srcName(cd.alt && cd.alt.length > 5 ? cd.alt : cd.text), price: cd.price, url: cd.url, soldOut: cd.soldOut, color: ctx.color.length > 0 && ctx.color.every(t => T.includes(t)) });
  }
  return out;
}
// 3.10.10: slot = 작업 창 자리. 보관 매크로는 자기 창(SQ.work)을 따로 써서 수집 같은 다른 작업과 같이 돌아요
async function srcNav(url, slot) {
  const W = slot || work, P = slot ? '' : navPart;   // 따로 쓰는 창은 다른 아이디 저장 공간을 안 써요
  let alive = false;
  if (W.winId) { try { await chrome.windows.get(W.winId); alive = true; } catch (e) {} }
  if (alive && (!(await sameSide(url, W)) || (W.part || '') !== P)) { try { await chrome.windows.remove(W.winId); } catch (e) {} Object.assign(W, { winId: null, tabId: null, part: '' }); alive = false; }
  if (!alive) {
    const w = await chrome.windows.create(winOpts({ url, type: 'popup', width: 1180, height: 900, focused: !+S.bgWork, background: !!+S.bgWork, part: P }));
    Object.assign(W, { winId: w.id, tabId: w.tabs[0].id, part: P });
  } else {
    await chrome.tabs.update(W.tabId, { url, active: true });
  }
  try { await chrome.tabs.update(W.tabId, { muted: true }); } catch (e) {}   // 2.6.3: 쇼핑몰 영상·광고 소리가 안 나게 작업 창은 음소거
  await sleep(700);
  const end = Date.now() + 20000;
  while (Date.now() < end) { const t = await chrome.tabs.get(W.tabId); if (t.status === 'complete') break; await sleep(300); }
  if (/^https:\/\/kream\.co\.kr\//.test(url)) await kreamHeal(W.tabId);
  return W.tabId;
}
async function srcRead(tabId) {
  // 결과가 늦게 그려지는 사이트가 많아서, 카드 수가 멈출 때까지(최대 9초) 몇 번 읽어 봄
  let last = null, prevN = -1;
  const end = Date.now() + 9000;
  await sleep(1200);
  while (Date.now() < end) {
    const [r] = await execT({ target: { tabId }, func: kcFind, args: [{ max: 40 }] });
    last = r && r.result;
    if (last && (last.noResult || (last.cards.length && last.cards.length === prevN))) break;
    prevN = last ? last.cards.length : -1;
    await sleep(900);
  }
  return last || { cards: [], noResult: true, page: null, url: '' };
}
// 예전에 저장된 매입처 결과에도 가격 기준을 다시 적용 — 크림가의 45%보다 싸거나 4배보다 비싼 건(부속품·쿠폰가·다른 상품) 빼고 최저가를 다시 계산
function srcSanitize(src, ref) {
  if (!src || !src.sites || !ref) return src;
  for (const r of src.sites) {
    if (r.tier === 'platform' || !Array.isArray(r.items) || !r.items.length) continue;
    const bad = x => x.price && (x.price < ref * 0.45 || x.price > ref * 4);
    if (!r.items.some(bad) && !(r.min && (r.min < ref * 0.45 || r.min > ref * 4))) continue;
    r.items = r.items.filter(x => !bad(x));
    const live = r.items.filter(x => !x.soldOut && x.price);
    r.min = live.length ? Math.min(...live.map(x => x.price)) : null;
    r.n = r.items.length;
    if (!r.items.length) r.level = null;
  }
  return src;
}
function srcRow(k, label, tier, url, items) {
  const r = { k, label, tier, searchUrl: url, level: null, items: [], n: 0, min: null };
  if (!items.length) return r;
  const lv = items.some(x => x.lv === 'strong') ? 'strong' : 'weak';
  // 리셀 플랫폼은 검색 첫 상품이 제일 정확해서 순서 그대로, 매입처는 싼 순
  const its = items.filter(x => x.lv === lv); if (tier !== 'platform') its.sort((a, b) => (a.soldOut - b.soldOut) || ((a.price || 9e9) - (b.price || 9e9)));
  const live = its.filter(x => !x.soldOut && x.price);
  return Object.assign(r, { level: lv, n: its.length, items: its.slice(0, 3).map(x => ({ name: x.name, price: x.price, url: x.url || url, soldOut: x.soldOut, color: x.color })),
    min: live.length ? live[0].price : null, allSold: !live.length && its.every(x => x.soldOut) });
}
const lvRank = r => (r.level === 'strong' ? 2 : r.level === 'weak' ? 1 : 0);
async function findOne(p, onStep, opt) {
  opt = opt || {};
  const info = (p.raw && p.raw.info) || {};
  const ctx = srcCtx(info.name, info.code, info.en);
  try { const a0 = analyze(p); ctx.ref = (a0 && (a0.sell || a0.minAskAll)) || (p.raw && p.raw.buyNow) || null; } catch (e) { ctx.ref = null; }
  const sites = SRC_SITES.filter(s => (!s.brand || s.brand.test((info.name || '') + ' ' + (info.en || ''))) && (!opt.keys || opt.keys.includes(s.k) || (s.brand && opt.brands)));
  const res = [];
  for (const site of sites) {
    if (stopFlag) break;
    const qs = [];
    if (site.kind !== 'name' && ctx.c) qs.push(ctx.c);
    if (site.kind !== 'name' && ctx.codes[1] && nrm(ctx.codes[1]) !== ctx.codeN) qs.push(ctx.codes[1]);   // 두 번째 모델번호도 검색
    if ((site.kind !== 'code' || !ctx.c) && ctx.short && !(opt.codeOnly && ctx.c)) qs.push(ctx.short);
    const first = site.url(encodeURIComponent(qs[0] || ctx.short));
    let A = srcRow(site.k, site.label, site.tier, first, []);
    let B = site.split ? srcRow(site.split.k, site.split.label, 'market', first, []) : null;
    try {
      for (const q of [...new Set(qs)]) {
        onStep && onStep(site.label);
        const url = site.url(encodeURIComponent(q));
        const got = matchSrc(await srcRead(await srcNav(url)), ctx, site).filter(x => !+S.strongOnly || x.lv === 'strong' || site.tier === 'platform');   // 기본: 모델번호가 보이는 상품만
        const a2 = srcRow(site.k, site.label, site.tier, url, site.split ? got.filter(x => x.ok) : got);
        if (lvRank(a2) > lvRank(A)) A = a2;
        if (B) { const b2 = srcRow(site.split.k, site.split.label, 'market', url, got.filter(x => !x.ok)); if (lvRank(b2) > lvRank(B)) B = b2; }
        if (A.level === 'strong' && (!B || B.level === 'strong')) break;   // 모델번호로 찾았으면 상품명 검색은 안 함
        if (A.level && (!B || B.level) ) break;
      }
    } catch (e) { A.err = String(e.message || e).slice(0, 80); if (B) B.err = A.err; }
    res.push(A); if (B) res.push(B);
  }
  p.src = { at: Date.now(), v: 2, sites: res, quick: !!opt.keys };
}
async function runSources(list) {
  if (!HAS_CHROME || !chrome.scripting) { alertBox('크림스캐너 안에서만 찾을 수 있어요'); return; }
  list = list.filter(p => p.raw && p.raw.info);
  if (!list.length) { alertBox('먼저 시세를 수집해 주세요 (상품 이름·모델번호가 필요해요).'); return; }
  stopFlag = false;
  $('#btnCollectAll').disabled = true; $('#btnSrcAll').disabled = true; $('#btnStop').hidden = false; $('#progress').hidden = false;
  let done = 0;
  for (const p of list) {
    if (stopFlag) break;
    const nm = ((p.raw.info.name || '') + '').slice(0, 30);
    await findOne(p, lab => {
      $('#progText').textContent = `${done + 1} / ${list.length} 정품 매입처 찾는 중 — ${nm} · ${lab} (새로 열린 창은 닫지 마세요)`;
    });
    done++;
    $('#progBar').style.width = (done / list.length * 100) + '%';
    await saveProducts(); renderMine();
  }
  $('#progBar').style.width = '100%';
  $('#progText').textContent = (stopFlag ? `중지했어요 (${done}개 완료)` : `끝났어요 — ${done}개 상품의 매입처를 찾았어요`) + ' · 휴대폰에서도 보려면 [휴대폰으로 보내기]';
  $('#btnCollectAll').disabled = false; $('#btnSrcAll').disabled = false; $('#btnStop').hidden = true;
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  setTimeout(() => { $('#progress').hidden = true; }, 6000);
}

// ---------- 아이템 찾기 ----------
// 1) 크림 SHOP 인기순 목록에서 거래가 많은 상품을 모으고  2) 상위 후보만 최근 체결을 수집해서 판매가·회전을 계산하고
// 3) 잘 팔리는 상품만 매입처를 빠르게(모델번호로) 찾아서  4) 크림 판매가보다 싸거나 비슷하게 살 수 있는 상품을 추천
const FIND_CATS = { shoes: ['신발', 44], outer: ['아우터', 49], top: ['상의', 50], bottom: ['하의', 51] };
const MARKET_KEYS = () => SRC_SITES.filter(x => x.tier === 'market').map(x => x.k);
const DEF_FIND = { cats: ['shoes', 'outer', 'top', 'bottom'], cand: 40, min7: 20, market: true, tol: 5 };
let finder = { at: null, opts: null, items: [], stage: '' };
let FO = { ...DEF_FIND };
function findOpts() {
  return { cats: Object.keys(FIND_CATS).filter(k => $('#f_' + k).checked), cand: +$('#f_cand').value, min7: +$('#f_min7').value, market: $('#f_market').checked, tol: 5 };
}
// 추천 점수 매기기: 크림 정산액(손익분기) − 매입 최저가
function judgeItem(it, opts) {
  srcSanitize(it.src, it.sell);
  const tiers = opts.market ? ['trust', 'market'] : ['trust'];
  const srcs = (it.src && it.src.sites || []).filter(s => s.level && s.min && tiers.includes(srcTier(s)));
  srcs.sort((a, b) => a.min - b.min);
  const best = srcs[0] || null, bestT = srcs.find(s => srcTier(s) === 'trust') || null;
  const margin = best && it.be != null ? it.be - best.min : null;
  let grade = 'none';
  if (best && it.sell) {
    if (margin > 0) grade = 'go';
    else if (best.min <= it.sell * (1 + opts.tol / 100)) grade = 'near';
    else grade = 'pricey';
  }
  return Object.assign(it, { best, bestT, margin, grade });
}
async function runFinder() {
  if (!HAS_CHROME || !chrome.scripting) { alertBox('크림스캐너 안에서만 찾을 수 있어요'); return; }
  const opts = findOpts();
  if (!opts.cats.length) { alertBox('카테고리를 하나 이상 골라 주세요'); return; }
  stopFlag = false;
  const prog = (pct, txt) => { $('#fProgress').hidden = false; $('#fBar').style.width = pct + '%'; $('#fText').textContent = txt; };
  $('#btnFind').disabled = true; $('#btnFindStop').hidden = false;
  try {
    // 1) 크림 목록
    let cands = [];
    const per = Math.max(40, Math.ceil(opts.cand * 2 / opts.cats.length));
    for (const [i, k] of opts.cats.entries()) {
      if (stopFlag) break;
      prog(2 + i * 3, `1단계 · 크림 ${FIND_CATS[k][0]} 인기 상품 모으는 중… (새로 열린 창은 닫지 마세요)`);
      const tabId = await srcNav(`https://kream.co.kr/search?tab=${FIND_CATS[k][1]}&sort=popular_score`);   // 인기순
      const [r] = await execT({ target: { tabId }, func: kcList, args: [per] });
      for (const c of (r && r.result) || []) cands.push({ ...c, cat: FIND_CATS[k][0] });
    }
    const seen = new Set();
    cands = cands.filter(c => c.price && !seen.has(c.pid) && seen.add(c.pid)).sort((a, b) => b.trades - a.trades).slice(0, opts.cand);
    if (!cands.length) throw new Error('크림 목록을 못 읽었어요. 크림에 로그인돼 있는지 확인해 주세요.');
    // 2) 최근 체결 (가볍게: 14일·입찰 목록 생략)
    const items = [];
    for (const [i, c] of cands.entries()) {
      if (stopFlag) break;
      prog(12 + i / cands.length * 43, `2단계 · 크림 최근 거래 확인 ${i + 1} / ${cands.length} — ${c.name.slice(0, 28)}`);
      const p = { id: 'f' + c.pid, pid: c.pid, cost: 0, size: '', raw: null };
      try { await collectOne(p, { days: Math.max(14, S.win), maxPages: 4, lite: true }); } catch (e) { continue; }
      const a = analyze(p); if (!a) continue;
      const info = p.raw.info || {};
      items.push({ pid: c.pid, cat: c.cat, img: c.img, trades: c.trades, listPrice: c.price, name: info.name || c.name, code: info.code || '', en: info.en || '', rel: info.rel || null,
        est7: a.est7, sell: a.sell, settle: a.settle, fee: a.fee, be: a.be, mkt: a.market && a.market.p, raw: p.raw });
      await sleep(800 + Math.random() * 1200);
    }
    // 3) 잘 팔리는 것만 매입처 찾기
    const hot = items.filter(it => it.est7 >= opts.min7 && it.sell && srcQueries(it.name, it.code).c).sort((a, b) => b.est7 - a.est7);
    for (const [i, it] of hot.entries()) {
      if (stopFlag) break;
      const tmp = { raw: it.raw };
      await findOne(tmp, lab => prog(55 + i / Math.max(hot.length, 1) * 43, `3단계 · 매입처 찾기 ${i + 1} / ${hot.length} — ${it.name.slice(0, 24)} · ${lab}`),
        { keys: SRC_SITES.filter(x => !x.brand).map(x => x.k).filter(k => opts.market || !MARKET_KEYS().includes(k)), brands: true, codeOnly: true });   // 매입처 찾기와 같은 모든 곳
      it.src = tmp.src;
    }
    // 4) 정리
    for (const it of items) { delete it.raw; judgeItem(it, opts); }
    finder = { at: Date.now(), opts, items, stage: stopFlag ? '중지' : '완료', counts: { list: cands.length, checked: items.length, hot: hot.length } };
    await store.set('finder', finder);
    prog(100, stopFlag ? '중지했어요 — 지금까지 찾은 것만 보여줘요' : '끝났어요');
  } catch (e) { prog(100, '멈췄어요: ' + e.message); }
  $('#btnFind').disabled = false; $('#btnFindStop').hidden = true;
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  renderFinder();
}
// 목록으로 조사: 크림 링크·상품번호·모델번호·상품명을 한 줄에 하나씩 받아서 하나씩 끝까지(크림 거래 → 매입처 전부) 조사
function parseFindList(text) {
  return [...new Set(String(text || '').split(/[\n\t]+/).map(s => s.trim()).filter(s => s.length >= 2 || /^\d+$/.test(s)))].slice(0, 100);
}
async function runFinderList() {
  if (!HAS_CHROME || !chrome.scripting) { alertBox('크림스캐너 안에서만 조사할 수 있어요'); return; }
  const lines = parseFindList($('#f_list').value);
  if (!lines.length) { alertBox('조사할 상품을 한 줄에 하나씩 넣어 주세요'); return; }
  const opts = findOpts();
  stopFlag = false;
  const prog = (pct, txt) => { $('#fProgress').hidden = false; $('#fBar').style.width = pct + '%'; $('#fText').textContent = txt; };
  $('#btnFind').disabled = true; $('#btnFindList').disabled = true; $('#btnFindStop').hidden = false;
  const items = [];
  const save = async (stage) => {
    items.forEach(it => judgeItem(it, opts));
    finder = { at: Date.now(), mode: 'list', opts, items: items.map(it => { const c = { ...it }; delete c.raw; return c; }), stage, counts: { list: lines.length, checked: items.length, hot: items.filter(x => x.src).length } };
    await store.set('finder', finder); renderFinder();
  };
  try {
    for (const [i, q] of lines.entries()) {
      if (stopFlag) break;
      const base = 100 * i / lines.length, step = 100 / lines.length;
      const it = { q, pid: null, name: q, code: '', cat: '목록', img: '', trades: 0, est7: 0, sell: null, settle: null, be: null };
      items.push(it);
      try {
        // 1) 크림 상품 찾기
        let pid = (q.match(/kream\.co\.kr\/products\/(\d+)/) || q.match(/^(\d{1,9})$/) || [])[1];
        if (!pid) {
          prog(base, `${i + 1} / ${lines.length} · 크림에서 '${q.slice(0, 24)}' 찾는 중`);
          const tabId = await srcNav(`https://kream.co.kr/search?keyword=${encodeURIComponent(q)}`);
          const [r] = await execT({ target: { tabId }, func: kcList, args: [1] });
          const c = ((r && r.result) || [])[0];
          if (!c) throw new Error('크림에서 이 상품을 못 찾았어요');
          pid = c.pid; it.img = c.img; it.trades = c.trades;
        }
        if (items.some(x => x !== it && String(x.pid) === String(pid))) throw new Error('위 목록과 같은 상품이라 건너뛰었어요');
        it.pid = pid;
        // 2) 크림 최근 거래
        prog(base + step * 0.1, `${i + 1} / ${lines.length} · 크림 최근 거래 확인 — ${q.slice(0, 28)}`);
        const p = { id: 'l' + pid, pid, cost: 0, size: '', raw: null };
        await collectOne(p, { days: Math.max(14, S.win), maxPages: 4, lite: true });
        const a = analyze(p); const info = p.raw.info || {};
        Object.assign(it, { name: info.name || q, code: info.code || '', img: it.img || info.img || '', est7: a ? a.est7 : 0, sell: a && a.sell, settle: a && a.settle, fee: a && a.fee, be: a && a.be });
        // 3) 매입처 전부
        const tmp = { raw: p.raw };
        await findOne(tmp, lab => prog(base + step * (0.3 + 0.7 * 0), `${i + 1} / ${lines.length} · 매입처 찾기 — ${it.name.slice(0, 24)} · ${lab}`),
          { keys: SRC_SITES.filter(x => !x.brand).map(x => x.k).filter(k => opts.market || !MARKET_KEYS().includes(k)), brands: true });
        it.src = tmp.src;
      } catch (e) { it.err = String(e.message || e).slice(0, 80); }
      await save('진행 중');
    }
    await save(stopFlag ? '중지' : '완료');
    prog(100, stopFlag ? '중지했어요 — 지금까지 조사한 것만 보여줘요' : `끝났어요 — ${items.length}개 조사`);
  } catch (e) { prog(100, '멈췄어요: ' + e.message); }
  $('#btnFind').disabled = false; $('#btnFindList').disabled = false; $('#btnFindStop').hidden = true;
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  renderFinder();
}
const GRADE = { go: ['ok', '추천 · 남음'], near: ['warn', '비슷 · 할인 받으면'], pricey: ['bad', '매입가 더 비쌈'], none: ['mute', '매입처 없음'] };
function updFindEta() {
  const o = findOpts();
  // 대략: 목록 30초/카테고리 + 후보당 크림 15초 + (잘 팔리는 절반 정도) 매입처 35초
  const per = o.market ? 120 : 65;   // 상품 하나 매입처 전부 도는 시간(초)
  const min = Math.round((o.cats.length * 30 + o.cand * 15 + o.cand * 0.5 * per) / 60);
  $('#fEta').textContent = `예상 ${min}분쯤 걸려요 · 그동안 작은 창이 열려요 (닫거나 최소화하지 마세요)`;
}
function renderFinder() {
  const F = finder;
  const when = F.at ? new Date(F.at).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
  if (F.mode === 'list') return renderFinderList(F, when);
  if (F.mode === 'musinsa' || F.mode === 'scan') { renderFinderMs(F, when); return; }
  $('#fMeta').textContent = F.at ? `${when} 분석 · 크림 인기 ${F.counts.list}개 → 최근 거래 확인 ${F.counts.checked}개 → 7일 ${F.opts.min7}건 이상 ${F.counts.hot}개 매입처 확인${F.stage === '중지' ? ' (중간에 중지)' : ''}` : '';
  if (!F.at) { $('#fRows').innerHTML = ''; $('#fEmpty').hidden = false; return; }
  $('#fEmpty').hidden = true;
  const order = { go: 0, near: 1, pricey: 2, none: 3 };
  const list = F.items.filter(it => it.est7 >= F.opts.min7 && it.src)
    .sort((a, b) => (order[a.grade] - order[b.grade]) || ((b.margin ?? -9e9) - (a.margin ?? -9e9)) || (b.est7 - a.est7));
  const rec = list.filter(it => it.grade === 'go' || it.grade === 'near').slice(0, 20);
  const rest = list.filter(it => !rec.includes(it)).slice(0, Math.max(0, 10 - rec.length));   // 추천이 10개가 안 되면 아깝게 떨어진 것도 보여줌
  const row = (it, i) => finderRow(it, i, F);
  $('#fRows').innerHTML = (rec.length ? rec.map(row).join('') : '<tr><td colspan="8" class="empty">조건을 통과한 추천 상품이 없어요. 아래는 가장 가까웠던 후보예요.</td></tr>')
    + (rest.length ? `<tr><td colspan="8" class="l small" style="background:var(--soft)"><b>아깝게 떨어진 후보</b> — 잘 팔리지만 매입처가 더 비싸거나 못 찾았어요</td></tr>` + rest.map((it, i) => row(it, rec.length + i)).join('') : '');
  $('#fCount').textContent = `추천 ${rec.length}개`;
}
function trackBoxHTML(p, a) {
  const log = (p.trackLog || []).slice(-6).reverse();
  return `<div class="box"><h3>가격 추적 <span class="small">${+S.trackHours ? `${S.trackHours}시간마다 매입처를 다시 찾아서 최저가가 내려가면 알림` : '설정에서 추적 간격을 정하면 자동으로 돌아요'}</span></h3>
    <div class="row-btns"><button type="button" class="${p.track ? 'primary' : 'ghost'}" data-track="${p.id}">${p.track ? '추적 중 — 끄기' : '이 상품 가격 추적 켜기'}</button><button type="button" class="ghost" data-tracknow="1">지금 한 번 확인</button></div>
    ${log.length ? `<div class="small" style="margin-top:6px">${log.map(l => `${new Date(l.t).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })} · ${l.min ? esc(l.label) + ' ' + won(l.min) : '못 찾음'}`).join('<br>')}</div>` : ''}</div>`;
}
function finderRow(it, i, F) {
  const mineSet = new Set(products.map(p => String(p.pid)));
    const g = GRADE[it.grade], b = it.best;
    return `<tr><td class="small">${i + 1}</td>
      <td class="l name">${it.img ? `<img class="thumb" src="${esc(it.img)}" alt="">` : ''}<b>${esc(it.name)}</b><span class="code">${esc(it.code)} · ${esc(it.cat)}</span></td>
      <td><span class="n">${(it.est7 || 0).toLocaleString('ko-KR')}건</span>${it.trades ? `<div class="small">누적 ${it.trades.toLocaleString('ko-KR')}</div>` : ''}${F.opts && (it.est7 || 0) < F.opts.min7 ? '<div class="small neg">회전 느림</div>' : ''}</td>
      <td><span class="big">${won(it.sell)}</span><div class="small">정산 ${won(it.settle)}</div></td>
      <td class="l">${b ? `<b>${esc(b.label)}</b> <span class="pill ${srcTier(b) === 'trust' ? 'ok' : 'warn'}">${srcTier(b) === 'trust' ? '정품 유통' : '오픈마켓'}</span><div class="n">${won(b.min)}</div>${it.bestT && it.bestT !== b ? `<div class="small">정품 유통 최저 ${esc(it.bestT.label)} ${won(it.bestT.min)}</div>` : ''}` : '<span class="small">못 찾음</span>'}</td>
      <td class="${it.margin > 0 ? 'pos' : it.margin != null ? 'neg' : ''}"><span class="big">${it.margin != null ? sign(it.margin) : '–'}</span>${b && it.sell ? `<div class="small">크림가−매입가 ${sign(it.sell - b.min)}<br>수수료 ${won(it.fee)}</div>` : ''}</td>
      <td><span class="pill ${g[0]}">${g[1]}</span></td>
      <td><div class="act"><a class="ghost" href="https://kream.co.kr/products/${esc(it.pid)}" target="_blank" rel="noopener">크림</a>${b ? `<a class="ghost" href="${esc((b.items[0] || {}).url || b.searchUrl)}" target="_blank" rel="noopener">매입처</a>` : ''}
        ${mineSet.has(String(it.pid)) ? '<span class="small">내 상품에 있음</span>' : `<button type="button" class="ghost" data-fadd="${esc(it.pid)}">내 상품에 추가</button>`}</div></td></tr>`;
}
function renderFinderMs(F, when) {
  $('#fMeta').textContent = F.mode === 'scan' ? `${when} ${F.scan} 분석 · ${F.counts.sites}곳에서 모델번호 있는 상품 ${F.counts.list}개 → 크림에 같은 상품 ${F.counts.hot}개${F.stage !== '완료' ? ` (${F.stage})` : ''}`
    : `${when} 무신사 랭킹 분석 · 랭킹 ${F.counts.list}개 → 크림에 같은 상품 ${F.counts.hot}개${F.stage !== '완료' ? ` (${F.stage})` : ''}`;
  $('#fEmpty').hidden = true;
  const order = { go: 0, near: 1, pricey: 2, none: 3 };
  const list = F.items.slice().sort((a, b) => (order[a.grade] - order[b.grade]) || ((b.margin ?? -9e9) - (a.margin ?? -9e9)) || (b.est7 - a.est7));
  $('#fRows').innerHTML = list.length ? list.map((it, i) => finderRow(it, i, F)).join('') : '<tr><td colspan="8" class="empty">아직 크림에서 같은 상품을 못 찾았어요.</td></tr>';
  $('#fCount').textContent = `남음 ${list.filter(x => x.grade === 'go').length}개 · 비슷 ${list.filter(x => x.grade === 'near').length}개 · 전체 ${list.length}개`;
}
function renderFinderList(F, when) {
  $('#fMeta').textContent = `${when} 목록 조사 · ${F.counts.checked} / ${F.counts.list}개${F.stage !== '완료' ? ` (${F.stage})` : ''}`;
  $('#fEmpty').hidden = true;
  const order = { go: 0, near: 1, pricey: 2, none: 3 };
  const ok = F.items.filter(it => !it.err).sort((a, b) => (order[a.grade] - order[b.grade]) || ((b.margin ?? -9e9) - (a.margin ?? -9e9)));
  const bad = F.items.filter(it => it.err);
  $('#fRows').innerHTML = ok.map((it, i) => finderRow(it, i, F)).join('')
    + bad.map(it => `<tr><td></td><td class="l" colspan="6"><b>${esc(it.q)}</b> <span class="small neg">${esc(it.err)}</span></td><td></td></tr>`).join('');
  $('#fCount').textContent = `목록 ${F.items.length}개 · 남음 ${ok.filter(x => x.grade === 'go').length}개 · 비슷 ${ok.filter(x => x.grade === 'near').length}개`;
}
async function finderAdd(pid) {
  const it = finder.items.find(x => String(x.pid) === String(pid)); if (!it) return;
  const p = { id: uid(), pid: it.pid, cost: it.best ? it.best.min : 0, size: '', memo: it.best ? `아이템 찾기 · ${it.best.label}` : '아이템 찾기', raw: null, at: null, added: Date.now(), src: it.src || null };
  products.unshift(p); await saveProducts(); renderMine(); renderFinder();
  queueJob(() => runCollect([p]));
}

// ---------- 무신사 구매내역 → 매입 장부 ----------
// 무신사 주문 내역을 읽어서 이 PC 매입 기록으로 넣어요(취소·반품 완료는 뺌). 같은 주문은 두 번 들어가지 않아요.
async function importMusinsaOrders(days) {
  if (!HAS_CHROME || !chrome.scripting) { alertBox('크림스캐너 안에서만 불러올 수 있어요'); return; }
  const msg = t => { $('#impMsg').textContent = t; };
  msg('무신사 주문 내역 여는 중… (작은 창이 열려요)');
  try {
    const tabId = await srcNav('https://www.musinsa.com/order/order-list');
    await sleep(1500);
    const [r] = await execT({ target: { tabId }, func: kcMusinsaOrders, args: [days] });
    const orders = (r && r.result) || [];
    if (!orders.length) throw new Error('주문을 못 읽었어요. 무신사에 로그인돼 있는지 확인해 주세요.');
    // 2.6.3: 상품명에 품번이 없으면 무신사 상품 정보에서 품번(styleNo)을 읽어요 (한 번 읽은 건 기억)
    const styles = (ordCache.msStyle = ordCache.msStyle || {});
    const need = [...new Set(orders.flatMap(o => o.items.map(it => it.mid)).filter(id => id && styles[id] == null))];
    if (need.length) { msg(`무신사 품번 읽는 중… (${need.length}개 상품)`); try { const [st] = await execT({ target: { tabId }, func: kcMsStyles, args: [need] }, 60000); Object.assign(styles, (st && st.result) || {}); } catch (e) {} }
    const codeOf = it => styles[it.mid] || msCode(`${it.name}`) || '';
    let add = 0, upd = 0, skip = 0, opened = 0, fixed = 0;
    // 2.6.1: 주문상세를 열어 실제 결제금액(쿠폰·적립금·카드 즉시할인 뺀 금액)을 읽어요. 한 번 읽은 주문은 기억해요.
    const paidOf = {};
    for (const [k, o] of orders.entries()) {
      if (/취소|반품/.test(o.status) && /완료|예정/.test(o.status)) continue;
      const url = `https://www.musinsa.com/order/order-detail/${o.no}`;
      const pc = (ordCache.paid = ordCache.paid || {}), c = pc[url];
      if (!(c && (c.paid > 0 || Date.now() - c.at < 864e5))) { if (opened >= PAID_MAX) continue; opened++; msg(`무신사 주문상세에서 결제금액 읽는 중… (${k + 1}/${orders.length})`); }
      try { const P = await readPaid(url); const sum = o.items.reduce((s, it) => s + (+it.total || 0), 0); if (P && P.paid > 0 && sum && P.paid / sum > 0.15 && P.paid / sum < 1.6) paidOf[o.no] = P.paid / sum; } catch (e) {}
    }
    await store.set('ordCache', ordCache);
    for (const o of orders) {
      o.items.forEach((it, i) => {
        const id = `ms-${o.no}-${i}`;
        const cancelled = /취소|반품/.test(o.status) && /완료|예정/.test(o.status);
        const ex = records.find(x => x.id === id);
        if (cancelled) { const ck = new Set(ordCache.cancelKeys || []); ck.add(id); ordCache.cancelKeys = [...ck].slice(-2000);   // 2.6.2: 재고에 이미 들어간 것도 빼려고 기억
          if (ex && ex.status === '매입완료' && !ex.sellPrice) { records = records.filter(x => x !== ex); upd++; } else skip++; return; }
        const memo = `무신사 주문 ${o.no} · ${o.status}`;
        const listUnit = it.qty ? Math.round(it.total / it.qty) : it.total, r = paidOf[o.no];
        const paidUnit = r ? Math.round(it.total * r / (it.qty || 1)) : null;
        if (ex) {
          if (!ex.code && codeOf(it)) ex.code = codeOf(it);
          if (ex.memo !== memo && /^무신사 주문/.test(ex.memo || '')) { ex.memo = memo; upd++; }
          if (paidUnit != null && !ex.paidOk) { if (+ex.cost === listUnit) { ex.listCost = listUnit; ex.cost = paidUnit; fixed++; } ex.paidOk = true; }   // 직접 고친 매입가는 그대로
          return;
        }
        records.unshift({ id, buyDate: o.date, name: `${it.brand} ${it.name}`.trim(), code: codeOf(it), pid: '', size: it.option, cost: paidUnit != null ? paidUnit : listUnit, listCost: listUnit, paidOk: paidUnit != null,
          buyFrom: '무신사', qty: it.qty || 1, soldQty: '', status: '매입완료', sellDate: '', sellPrice: '', fee: '', ship: '', memo, musinsaId: it.mid });
        add++;
      });
    }
    await saveRecords(); await store.set('ordCache', ordCache); renderSales();
    msg(`무신사 주문 ${orders.length}건 확인 — 새로 ${add}개 넣음${fixed ? ` · ${fixed}개 매입가를 실결제금액으로 고침` : ''}${upd ? ` · ${upd}개 상태 바꿈` : ''}${skip ? ` · 취소/반품 ${skip}개 뺌` : ''}. 휴대폰에서 보려면 '이 PC 기록을 웹으로 옮기기'를 누르세요.`);
  } catch (e) { msg('멈췄어요: ' + e.message); }
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
}

// ---------- 무신사 랭킹에서 찾기 ----------
const MS_CATS = { shoes: '신발', outer: '아우터', top: '상의', bottom: '바지' };
// 무신사 상품명에서 모델번호 뽑기: "… / MR530KA (SILVER)", "… / IH9080", "NS85S31A 눕시 뮬"
function msCode(text) {
  const t = String(text || '').toUpperCase();
  const after = [...t.matchAll(/\/\s*([A-Z0-9][A-Z0-9-]{4,})/g)].map(m => m[1]).filter(s => /\d/.test(s));
  if (after.length) return after[after.length - 1];
  const toks = (t.match(/\b[A-Z0-9-]{5,}\b/g) || []).filter(s => /[A-Z]/.test(s) && /\d/.test(s) && !/^(V\d+|\d+[A-Z]?)$/.test(s) && !/^\d{2}(FW|SS)$/.test(s));
  return toks[0] || '';
}
async function runMusinsaRank() {
  if (!HAS_CHROME || !chrome.scripting) { alertBox('크림스캐너 안에서만 찾을 수 있어요'); return; }
  const opts = findOpts();
  if (!opts.cats.length) { alertBox('카테고리를 하나 이상 골라 주세요'); return; }
  stopFlag = false;
  const prog = (pct, txt) => { $('#fProgress').hidden = false; $('#fBar').style.width = pct + '%'; $('#fText').textContent = txt; };
  $('#btnFind').disabled = true; $('#btnFindMs').disabled = true; $('#btnFindStop').hidden = false;
  const items = [];
  try {
    let cands = [];
    for (const [i, k] of opts.cats.entries()) {
      if (stopFlag) break;
      prog(2 + i * 3, `1단계 · 무신사 랭킹 ${MS_CATS[k]} 모으는 중…`);
      const tabId = await srcNav('https://www.musinsa.com/main/musinsa/ranking');
      const [r] = await execT({ target: { tabId }, func: kcMusinsaRank, args: [MS_CATS[k], Math.max(30, opts.cand)] });
      for (const c of (r && r.result) || []) { const code = msCode(c.text); if (code) cands.push({ ...c, code, cat: MS_CATS[k] }); }
    }
    const seen = new Set();
    cands = cands.filter(c => !seen.has(c.code) && seen.add(c.code)).slice(0, opts.cand);
    if (!cands.length) throw new Error('모델번호가 있는 랭킹 상품을 못 찾았어요.');
    for (const [i, c] of cands.entries()) {
      if (stopFlag) break;
      prog(15 + i / cands.length * 83, `2단계 · ${i + 1} / ${cands.length} 크림에서 확인 — ${c.code} (무신사 ${won(c.price)})`);
      try {
        const tabId = await srcNav(`https://kream.co.kr/search?keyword=${encodeURIComponent(c.code)}`);
        const [r] = await execT({ target: { tabId }, func: kcList, args: [1] });
        const k = ((r && r.result) || [])[0];
        if (!k) continue;
        const p = { id: 'm' + k.pid, pid: k.pid, cost: 0, size: '', raw: null };
        await collectOne(p, { days: Math.max(14, S.win), maxPages: 4, lite: true });
        const info = p.raw.info || {};
        if (!nrm(info.code).includes(nrm(c.code))) continue;   // 크림 첫 상품이 다른 상품이면 버림
        const a = analyze(p);
        const msUrl = `https://www.musinsa.com/products/${c.mid}`;
        const it = { pid: k.pid, cat: c.cat, img: k.img || c.img, trades: k.trades, name: info.name || k.name, code: info.code, est7: a ? a.est7 : 0, sell: a && a.sell, settle: a && a.settle, fee: a && a.fee, be: a && a.be,
          msRank: c.rank, src: { at: Date.now(), v: 2, sites: [{ k: 'musinsa', label: `무신사 (랭킹 ${c.rank || '-'}위)`, tier: 'trust', searchUrl: msUrl, level: 'strong', n: 1, min: c.price, items: [{ name: c.text.replace(/^\d+\s*(급상승|판매 [\d.]+[천만]?개)?\s*/, '').slice(0, 80), price: c.price, url: msUrl }] }] } };
        items.push(it); judgeItem(it, opts);
        finder = { at: Date.now(), mode: 'musinsa', opts, items, stage: '진행 중', counts: { list: cands.length, checked: i + 1, hot: items.length } };
        renderFinder();
        await sleep(600 + Math.random() * 900);
      } catch (e) { /* 이 상품은 건너뜀 */ }
    }
    finder = { at: Date.now(), mode: 'musinsa', opts, items, stage: stopFlag ? '중지' : '완료', counts: { list: cands.length, checked: cands.length, hot: items.length } };
    await store.set('finder', finder);
    prog(100, stopFlag ? '중지했어요' : `끝났어요 — 무신사 랭킹 ${cands.length}개 중 크림에 있는 ${items.length}개 비교`);
  } catch (e) { prog(100, '멈췄어요: ' + e.message); }
  $('#btnFind').disabled = false; $('#btnFindMs').disabled = false; $('#btnFindStop').hidden = true;
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  renderFinder();
}

// ---------- 다른 사이트 랭킹·키워드로 찾기 ----------
// 사이트 목록(랭킹 페이지 또는 키워드 검색)에서 모델번호가 보이는 상품을 모으고, 같은 모델번호를 크림에서 찾아 비교해요.
const RANK_SITES = [
  { k: 'rexmonde', label: '렉스몬드', tier: 'trust', url: 'https://www.rexmonde.com/products/list?item_type=RANK' },
  { k: '4910', label: '4910', tier: 'market', url: 'https://4910.kr/desktop/home?tab=ranking' },
  { k: 'wconcept', label: 'W컨셉', tier: 'market', url: 'https://display.wconcept.co.kr/rn/best' },
  // 지그재그는 웹 랭킹 페이지가 막혀 있어서, 카테고리 화면 위쪽의 '실시간 ○○ 랭킹'을 읽음
  { k: 'zigzag', label: '지그재그', tier: 'market', cats: { shoes: 582, outer: 436, top: 474, bottom: 547 }, url: id => `https://zigzag.kr/pages/srp-clp-category?category_id=${id}` }
];
// 상품명에서 모델번호 후보 뽑기 (괄호 안, '/' 뒤, 영문+숫자 5자 이상, 숫자만 6~10자리)
function codeCands(text) {
  const t = String(text || '').toUpperCase();
  const bad = s => /^\d+COLOR$/.test(s) || /^\d{2}(FW|SS|AW)$/.test(s) || /^V\d+$/.test(s) || /^(19|20)\d{2}$/.test(s) || /^\d{1,3}(,\d{3})+$/.test(s);
  const out = [];
  const push = s => { s = s.replace(/^[-_]+|[-_]+$/g, ''); if (s.length >= 5 && !bad(s) && !out.includes(s) && ((/[A-Z]/.test(s) && /\d/.test(s)) || /^\d{6,10}$/.test(s) || /^\d{5,8}-\d{2,4}$/.test(s))) out.push(s); };
  for (const m of t.matchAll(/\/\s*([A-Z0-9][A-Z0-9-]{4,})/g)) push(m[1]);
  for (const m of t.matchAll(/\(([A-Z0-9-]{5,})[),\s]/g)) push(m[1]);
  for (const m of t.matchAll(/\b[A-Z0-9][A-Z0-9-]{4,}\b/g)) push(m[0]);
  return out.slice(0, 3);
}
const kreamCache = new Map();   // 모델번호 → 크림 결과 (한 번 찾기 동안)
async function kreamByCode(code) {
  if (kreamCache.has(code)) return kreamCache.get(code);
  let res = null;
  try {
    const tabId = await srcNav(`https://kream.co.kr/search?keyword=${encodeURIComponent(code)}`);
    const [r] = await execT({ target: { tabId }, func: kcList, args: [1] });
    const k = ((r && r.result) || [])[0];
    if (k) {
      const p = { id: 'x' + k.pid, pid: k.pid, cost: 0, size: '', raw: null };
      await collectOne(p, { days: Math.max(14, S.win), maxPages: 4, lite: true });
      const info = p.raw.info || {};
      if (nrm(info.code).includes(nrm(code))) {
        const a = analyze(p);
        res = { pid: k.pid, img: k.img, trades: k.trades, name: info.name || k.name, code: info.code, est7: a ? a.est7 : 0, sell: a && a.sell, settle: a && a.settle, fee: a && a.fee, be: a && a.be };
      }
    }
  } catch (e) {}
  kreamCache.set(code, res);
  return res;
}
async function runSiteScan(mode) {
  if (!HAS_CHROME || !chrome.scripting) { alertBox('크림스캐너 안에서만 찾을 수 있어요'); return; }
  const opts = findOpts();
  const kw = ($('#f_kw').value || '').trim();
  if (mode === 'kw' && !kw) { alertBox('검색할 키워드를 넣어 주세요 (예: 뉴발란스 530, 아식스 젤, 노스페이스 눕시)'); return; }
  stopFlag = false; kreamCache.clear();
  const prog = (pct, txt) => { $('#fProgress').hidden = false; $('#fBar').style.width = pct + '%'; $('#fText').textContent = txt; };
  const btns = ['#btnFind', '#btnFindMs', '#btnFindRank', '#btnFindKw']; btns.forEach(b => $(b).disabled = true); $('#btnFindStop').hidden = false;
  const sites = mode === 'rank' ? RANK_SITES.filter(x => opts.market || x.tier === 'trust').flatMap(x => x.cats ? opts.cats.filter(c => x.cats[c]).map(c => ({ ...x, label: `${x.label} ${FIND_CATS[c][0]}`, url: x.url(x.cats[c]) })) : [x])
    : SRC_SITES.filter(x => !x.brand && x.tier !== 'platform' && !x.split && (opts.market || x.tier === 'trust')).map(x => ({ k: x.k, label: x.label, tier: x.tier, url: x.url(encodeURIComponent(kw)) }))
        .concat(SRC_SITES.filter(x => x.split).flatMap(x => [{ k: x.k, label: x.label, tier: 'trust', url: x.url(encodeURIComponent(kw)), trust: x.trust }].concat(opts.market ? [{ k: x.split.k, label: x.split.label, tier: 'market', url: x.url(encodeURIComponent(kw)), trust: x.trust, untrusted: true }] : [])));
  const seenUrl = new Set();
  try {
    // 1) 사이트마다 목록 읽기
    const cands = [];
    const visited = new Map();
    for (const [i, site] of sites.entries()) {
      if (stopFlag) break;
      prog(2 + i / sites.length * 25, `1단계 · ${site.label} ${mode === 'rank' ? '랭킹' : `'${kw}' 검색`} 읽는 중…`);
      let res = visited.get(site.url);
      if (!res) { const tabId = await srcNav(site.url); res = await srcRead(tabId); visited.set(site.url, res); }
      for (const c of res.cards || []) {
        if (!c.price || c.soldOut) continue;
        if (site.trust) { const ok = site.trust(c.text, c.hrefs); if (site.untrusted ? ok : !ok) continue; }
        const codes = codeCands(c.text + ' ' + c.alt + ' ' + c.hrefs.replace(/[\/_-]/g, ' '));
        if (!codes.length) continue;
        const key = site.k + '|' + (c.url || c.text.slice(0, 60));
        if (seenUrl.has(key)) continue; seenUrl.add(key);
        cands.push({ site, codes, price: c.price, url: c.url || site.url, name: srcName(c.alt && c.alt.length > 5 ? c.alt : c.text) });
      }
    }
    // 2) 모델번호마다 크림 찾기 (같은 모델번호는 한 번만)
    const byCode = new Map();
    let checked = 0;
    const todo = cands.slice(0, Math.max(opts.cand * 3, 60));
    const items = [];
    for (const c of todo) {
      if (stopFlag) break;
      if (items.length >= opts.cand && ![...byCode.keys()].some(k => c.codes.includes(k))) continue;
      let hit = null, code = null;
      for (const cd of c.codes) {
        if (byCode.has(cd)) { hit = byCode.get(cd); code = cd; break; }
        if (kreamCache.has(cd) && !kreamCache.get(cd)) continue;
        prog(28 + checked / todo.length * 70, `2단계 · 크림에서 ${cd} 찾는 중 (${c.site.label} ${won(c.price)}) · 찾은 상품 ${items.length}개`);
        const k = await kreamByCode(cd);
        if (k) { hit = { k, src: [] }; byCode.set(cd, hit); code = cd; items.push(hit); break; }
      }
      checked++;
      if (!hit) continue;
      const ref = hit.k.sell;
      if ((ref && c.price < ref * 0.45) || accessoryLike(c.name, { name: hit.k.name || '' })) continue;   // 부속품·다른 상품 가격은 뺌
      hit.src.push({ site: c.site, price: c.price, url: c.url, name: c.name });
    }
    // 3) 정리: 사이트별 최저가를 매입처로
    const out = items.filter(h => h.src.length).map(h => {
      const per = new Map();
      for (const s of h.src) { const o = per.get(s.site.k); if (!o || s.price < o.price) per.set(s.site.k, s); }
      const it = { ...h.k, cat: mode === 'rank' ? '랭킹' : kw, src: { at: Date.now(), v: 2, sites: [...per.values()].map(s => ({ k: s.site.k, label: s.site.label, tier: s.site.tier, searchUrl: s.site.url, level: 'strong', n: 1, min: s.price, items: [{ name: s.name, price: s.price, url: s.url }] })) } };
      return judgeItem(it, opts);
    });
    finder = { at: Date.now(), mode: 'scan', scan: mode === 'rank' ? '사이트 랭킹' : `'${kw}' 키워드`, opts, items: out, stage: stopFlag ? '중지' : '완료', counts: { list: cands.length, checked, hot: out.length, sites: sites.length } };
    await store.set('finder', finder);
    prog(100, stopFlag ? '중지했어요' : `끝났어요 — ${sites.length}곳에서 모델번호 있는 상품 ${cands.length}개, 크림에 있는 ${out.length}개`);
  } catch (e) { prog(100, '멈췄어요: ' + e.message); }
  btns.forEach(b => $(b).disabled = false); $('#btnFindStop').hidden = true;
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  renderFinder();
}

// ---------- 가격 추적 ----------
// 추적을 켠 상품은 정해 둔 간격마다 매입처를 다시 찾아서, 최저가가 내려가거나 손익분기보다 싸지면 윈도우 알림으로 알려줘요.
function bestOf(src, tiers) {
  const s = (src && src.sites || []).filter(x => x.level && x.min && tiers.includes(x.tier || 'trust')).sort((a, b) => a.min - b.min)[0];
  return s ? { label: s.label, min: s.min, url: ((s.items || [])[0] || {}).url || s.searchUrl } : null;
}
async function runTrack(auto, keepOpen) {
  const list = products.filter(p => p.track && p.raw && p.raw.info);
  if (!list.length) { if (!auto) alertBox('가격 추적을 켠 상품이 없어요 (상품을 펼쳐서 켜세요)'); return; }
  stopFlag = false;
  const tiers = S.trackMarket ? ['trust', 'market'] : ['trust'];
  const hits = [];
  for (const [i, p] of list.entries()) {
    if (stopFlag) break;
    const before = bestOf(p.src, tiers);
    const a = analyze(p);
    $('#progress').hidden = false; $('#progText').textContent = `가격 추적 ${i + 1} / ${list.length} — ${(p.raw.info.name || '').slice(0, 24)}`;
    await findOne(p, null, {});
    const now = bestOf(p.src, tiers);
    p.trackLog = (p.trackLog || []).concat([{ t: Date.now(), min: now ? now.min : null, label: now ? now.label : '' }]).slice(-60);
    if (now && (!before || now.min <= before.min - 1000 || (a && a.be != null && now.min < a.be && (!before || before.min >= a.be)))) {
      hits.push({ p, before, now, m: a && a.be != null ? a.be - now.min : null });
    }
    await saveProducts();
  }
  if (work.winId) { try { await chrome.windows.remove(work.winId); } catch (e) {} work = { winId: null, tabId: null }; }
  await store.set('trackAt', Date.now());
  for (const h of hits) {
    try {
      chrome.notifications.create('kc-' + h.p.id + '-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: `가격 내림 — ${(h.p.raw.info.name || '').slice(0, 30)}`,
        message: `${h.now.label} ${won(h.now.min)}${h.before ? ` (전에 ${won(h.before.min)})` : ''}${h.m != null ? ` · 순마진 ${sign(h.m)}` : ''}`, priority: 2 });
    } catch (e) {}
  }
  renderMine();
  $('#progText').textContent = `가격 추적 끝 — ${list.length}개 확인, 가격 내린 것 ${hits.length}개`;
  setTimeout(() => { $('#progress').hidden = true; }, 6000);
  if (auto && !keepOpen) setTimeout(() => window.close(), 3000);
}
async function setTrackAlarm() {
  if (!HAS_CHROME || !chrome.alarms) return;
  await chrome.alarms.clear('kc-track');
  if (+S.trackHours > 0) chrome.alarms.create('kc-track', { periodInMinutes: +S.trackHours * 60, delayInMinutes: +S.trackHours * 60 });
}

// ---------- 매출관리 ----------
// 수량: 매입 개수 / 판매 수량: 그중 팔린 개수 (비우면 판매가를 넣는 순간 전부 팔린 것으로 봐요)
// 매입가·판매가·수수료·발송비는 모두 '개당' 금액, 순이익은 팔린 개수만큼 합계
const qtyOf = r => Math.max(1, Math.round(+r.qty || 1));
const soldOf = r => !+r.sellPrice ? 0 : (r.soldQty === '' || r.soldQty == null ? qtyOf(r) : Math.min(qtyOf(r), Math.max(0, Math.round(+r.soldQty || 0))));
function recCalc(r) {
  const prod = products.find(p => p.pid && p.pid === r.pid);
  const sell = +r.sellPrice || 0;
  const fee = r.fee !== '' && r.fee != null ? +r.fee : (sell ? feeOf(sell, prod) : 0);
  const ship = r.ship !== '' && r.ship != null ? +r.ship : S.ship;
  const qty = qtyOf(r), sold = soldOf(r), cost = +r.cost || 0;
  const profit = sell && sold ? (sell - fee - ship - cost) * sold : null;
  return { sell, fee, ship, qty, sold, left: qty - sold, cost, profit };
}
const monthOf = r => (r.sellDate || r.buyDate || '').slice(0, 7);

// 예전 버전(1.4까지)에서 이 PC에 적어 둔 매출·매입 기록 — 지워지지 않고 그대로 있어요. 여기서 보이고, 웹으로 옮기거나 엑셀로 받을 수 있어요.
function renderSales() {
  const n = records.length;
  const b = $('#btnMoveRecs'); if (b) b.hidden = !n;
  $('#btnRecCsv').hidden = !n;
  $('#localRecs').hidden = !n;
  if (!n) { $('#localMsg').textContent = '이 PC(확장 프로그램)에 저장된 예전 매출·매입 기록은 없어요.'; return; }
  let cost = 0, profit = 0, sold = 0;
  const rows = records.map(r => {
    const c = recCalc(r); cost += c.cost * c.qty; if (c.profit != null) { profit += c.profit; sold += c.sold; }
    return `<tr><td class="l">${esc(r.buyDate || '')}</td><td class="l" style="white-space:normal;min-width:180px">${esc(r.name || (r.pid ? '크림 ' + r.pid : ''))}</td><td>${esc(r.size || '')}</td><td>${c.qty}</td>
      <td>${won(c.cost)}</td><td class="l">${esc(r.buyFrom || '')}</td><td class="l">${esc(r.status || '')}</td><td class="l">${esc(r.sellDate || '')}</td>
      <td>${c.sell ? won(c.sell) : '–'}</td><td>${c.sold}/${c.qty}</td><td class="${c.profit > 0 ? 'pos' : c.profit != null ? 'neg' : ''}">${c.profit != null ? sign(c.profit) : '–'}</td><td class="l" style="white-space:normal">${esc(r.memo || '')}</td></tr>`;
  }).join('');
  $('#localMsg').innerHTML = `<b>이 PC에 저장된 예전 매출·매입 기록 ${n}개가 그대로 있어요.</b> 매입 합계 ${won(cost)} · 판매 ${sold}개 순이익 ${sign(profit)}`;
  $('#localRows').innerHTML = rows;
}
function recCsv() {
  const head = ['매입일', '상품', '크림번호', '사이즈', '수량', '판매수량', '매입가(개당)', '매입처', '상태', '판매일', '판매가(개당)', '수수료(개당)', '발송비(개당)', '순이익', '메모'];
  const q = v => { const t = String(v ?? ''); return /[",\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t; };
  const lines = [head.join(',')].concat(records.map(r => { const c = recCalc(r); return [r.buyDate, r.name, r.pid, r.size, c.qty, c.sold, c.cost, r.buyFrom, r.status, r.sellDate, c.sell || '', c.sell ? c.fee : '', c.sell ? c.ship : '', c.profit ?? '', r.memo].map(q).join(','); }));
  download('\ufeff' + lines.join('\n'), `크림스캐너_매출매입_${today()}.csv`, 'text/csv');
}

function addRecord(pre) {
  records.unshift(Object.assign({ id: uid(), buyDate: today(), name: '', pid: '', size: '', cost: '', buyFrom: '', qty: 1, soldQty: '', status: '매입완료', sellDate: '', sellPrice: '', fee: '', ship: '', memo: '' }, pre || {}));
  saveRecords(); renderSales();
}

function csvExport() {
  const head = ['매입일', '상품', '크림번호', '사이즈', '수량', '매입가(개당)', '매입금액', '매입처', '상태', '판매일', '판매 수량', '남은 수량', '판매가(개당)', '수수료(개당)', '발송비(개당)', '순이익(합계)', '메모'];
  const lines = [head].concat(records.map(r => { const c = recCalc(r); return [r.buyDate, r.name, r.pid, r.size, c.qty, r.cost, c.cost * c.qty, r.buyFrom, r.status, r.sellDate, c.sold, c.left, r.sellPrice, c.sell ? c.fee : '', c.ship, c.profit ?? '', r.memo]; }));
  const csv = '﻿' + lines.map(l => l.map(v => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(',')).join('\r\n');
  download(csv, `크림_매출_${today()}.csv`, 'text/csv;charset=utf-8');
}
function download(text, name, type) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type }));
  a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

// ---------- 화면 틀: 왼쪽 메뉴 (자동화 모드 = 어두운 메뉴, 재고관리 모드 = 밝은 메뉴) ----------
// 3.2: 리셀올인원과 같은 순서·묶음 (세 번째 칸 = 아이콘)
const AUTO_MENU = [
  ['g', '계정'], ['acct', '계정 연결 · 로그인', 'key'],
  ['g', '데이터 분석'], ['dual', '크림 / 포이즌 동시 분석', 'scale'], ['find', '아이템 찾기 · 랭킹 분석', 'trophy'], ['msstock', '상품 재고조회', 'box'], ['mine', '내 상품 시세 · 마진', 'chart'],
  ['g', '나이키'], ['nike', '나이키 주문내역', 'bag'],
  ['g', '무신사'], ['orders', '주문내역 관리', 'down'], ['reviews', '자동 후기작성', 'spark'], ['mstrack', '상품 가격 · 재입고 추적', 'trend'],
  ['g', '크림 · 개인'], ['ksell', '일반판매 입찰 & 관리', 'gavel'], ['kauto', '자동 입찰', 'zap'], ['kinv', '보관판매 관리', 'archive'], ['kmacro', '보관판매 매크로', 'cube'], ['kship', '발송관리', 'truck'], ['khist', '판매 · 구매 내역', 'receipt'], ['kcancel', '취소 · 반송 관리', 'undo'],
  ['g', '크림 · 입점'], ['pbid', '일반판매 입찰 & 관리', 'gavel'], ['pinv', '보관판매 관리', 'archive'], ['pmacro', '보관판매 매크로', 'cube'], ['pship', '발송관리', 'truck'], ['psales', '판매내역', 'receipt'],
  ['g', '기록'], ['sales', '매출관리 (휴대폰 공유)', 'phone']
];
let curView = 'mine', curMode = 'auto';
// 3.2: 메뉴 아이콘 (선 아이콘, 24×24)
const ICONS = {
  key: '<circle cx="8" cy="15" r="4"/><path d="m10.8 12.2 8.7-8.7M16 7l3 3M14 9l2 2"/>',
  scale: '<path d="M12 3v18M5 7h14M5 7l-3 6a3.5 3.5 0 0 0 6 0zM19 7l-3 6a3.5 3.5 0 0 0 6 0zM8 21h8"/>',
  trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',
  box: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
  chart: '<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-6"/>',
  bag: '<path d="M6 7h12l1 14H5z"/><path d="M9 7a3 3 0 0 1 6 0"/>',
  down: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
  spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 17l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>',
  trend: '<path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
  gavel: '<path d="m14 4 6 6M11 7l6 6M4 20l7-7M8 11l5-5 5 5-5 5z"/>',
  archive: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10h14V9M10 13h4"/>',
  cube: '<path d="M12 2 3 7v10l9 5 9-5V7z"/><path d="m3 7 9 5 9-5M12 12v10"/>',
  truck: '<path d="M3 6h11v10H3zM14 9h4l3 3v4h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
  receipt: '<path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6M9 11h6M9 15h4"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
  phone: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
  home: '<path d="m3 11 9-8 9 8M5 9v12h14V9"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
  tag: '<path d="M3 3h8l10 10-8 8L3 11z"/><circle cx="7.5" cy="7.5" r="1.5"/>', swap: '<path d="M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/>',
  sheet: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M4 9h16M4 15h16M10 3v18"/>', cart: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l3 13h11l2-9H6"/>',
  zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>', ret: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>', book: '<path d="M4 4h7a3 3 0 0 1 3 3v14a2 2 0 0 0-2-2H4zM20 4h-5a3 3 0 0 0-3 3"/><path d="M20 4v15h-6"/>',
  percent: '<path d="M19 5 5 19"/><circle cx="7" cy="7" r="2.5"/><circle cx="17" cy="17" r="2.5"/>', shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/>',
  moon: '<path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10z"/>', swap2: '<path d="M4 7h13l-3-3M20 17H7l3 3"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'
};
const ico = n => `<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ICONS.box}</svg>`;
function sideBadge(k) {
  try {
    if (k === 'mstrack') return (+S.trackHours > 0 || (msTracks || []).some(t => t.on)) ? '<span class="sbadge on">ON</span>' : '<span class="sbadge off">OFF</span>';
    if (k === 'kauto') return typeof AB !== 'undefined' && AB.run ? '<span class="sbadge on">ON</span>' : '<span class="sbadge off">OFF</span>';
    if (k === 'kmacro') return SQ.run ? '<span class="sbadge on">ON</span>' : '<span class="sbadge off">OFF</span>';
    if (k === 'acct' && typeof acctState !== 'undefined') { const n = ACCTS.filter(A => (acctState[A.k] || {}).st === 'off' && acctData && acctData[A.k] && acctData[A.k].id).length; return n ? `<span class="sbadge n">${n}</span>` : ''; }
  } catch (e) {}
  return '';
}
function renderSide() {
  $('#autoNav').innerHTML = AUTO_MENU.map(([k, t, ic]) => k === 'g' ? `<div class="sgrp">${t}</div>` : `<button type="button" data-view="${k}" aria-current="${curMode === 'auto' && curView === k}">${ico(ic)}<span class="lbl">${t}</span>${sideBadge(k)}</button>`).join('');
  const cta = $('#btnSideAcct'); if (cta) cta.innerHTML = `${ico('user')} 계정 연결`;
  const ms = $('#btnModeSwap'); if (ms) ms.innerHTML = `${ico('swap2')} ${curMode === 'inv' ? '자동화로 전환' : '재고관리로 전환'}`;
  const tl = $('#themeLbl'); if (tl) tl.innerHTML = `${ico('moon')}다크 모드`;
  topStatus();
}
// 위쪽: 플랫폼 연결 상태 칩 (계정 연결에 저장했거나 확인한 곳만)
function topStatus() {
  const el = $('#topStat'); if (!el || typeof ACCTS === 'undefined') return;
  // 3.8.3: 같은 쇼핑몰 아이디 여러 개는 칩 하나로 묶어요 (예: 지그재그 7/8)
  const used = A => (acctState[A.k] && acctState[A.k].st) || (acctData && acctData[A.k] && acctData[A.k].id);
  const L = ACCTS.filter(A => !A.part && (used(A) || ACCTS.some(x => x.base === A.k && used(x)))).slice(0, 7);
  el.innerHTML = L.map(A => {
    const grp = [A, ...ACCTS.filter(x => x.base === A.k)].filter(used), sts = grp.map(x => (acctState[x.k] || {}).st), on = sts.filter(x => x === 'on').length;
    const st = sts.includes('off') ? 'off' : on && on === grp.length ? 'on' : '';
    const tip = grp.map(x => `${x.label}: ${(acctState[x.k] || {}).st === 'on' ? '로그인됨' : (acctState[x.k] || {}).st === 'off' ? '로그인 필요' : '확인 전'}`).join('\n');
    return `<button type="button" class="tchip ${st}" data-view="acct" title="${esc(tip)}">${esc(A.label.split(' ')[0])}${grp.length > 1 ? ` ${on}/${grp.length}` : ''}<i></i></button>`;
  }).join('');
  // 3.7: 웨~일 연결 상태 (크림 작업은 웨~일에서)
  const W = window.__KC_WHALE; if (W && W.via === 'whale') el.innerHTML = `<button type="button" class="tchip ${W.connected ? 'on' : 'off'}" data-view="acct" title="크림 작업은 웨~일에서 해요: ${W.connected ? '웨~일 연결됨' : '웨~일 연결 안 됨 (설정 → 웨~일 연결)'}">웨~일<i></i></button>` + el.innerHTML;
}
// 다크 모드 (이 PC에 기억)
function themeApply(t) { if (t) document.documentElement.setAttribute('data-theme', t); else document.documentElement.removeAttribute('data-theme'); const sw = $('#themeSw'); if (sw) sw.checked = t === 'dark' || (!t && matchMedia('(prefers-color-scheme: dark)').matches); }
function route(v) {
  v = String(v || 'mine');
  if (v.startsWith('inv:')) { curMode = 'inv'; const iv = v.slice(4); if (iv && INV_MENU.some(m => m[0] === iv)) { invView = iv; IS.msg = ''; } }
  else { curMode = 'auto'; curView = AUTO_MENU.some(m => m[0] === v) ? v : 'mine'; }
  document.body.classList.toggle('mode-inv', curMode === 'inv'); document.body.classList.toggle('mode-auto', curMode === 'auto');
  $('#autoNav').hidden = curMode !== 'auto'; $('#invNav').hidden = curMode !== 'inv';
  document.querySelectorAll('.modesw button').forEach(b => b.setAttribute('aria-pressed', b.dataset.mode === curMode));
  $('#modeChip').textContent = curMode === 'inv' ? '재고관리 모드' : '자동화 모드';
  const sec = curMode === 'inv' ? 'inv' : (['mine', 'find', 'sales'].includes(curView) ? curView : 'x');
  document.querySelectorAll('main > .tabpane').forEach(x => { x.hidden = x.id !== 'tab-' + sec; });
  renderSide();
  if (curMode === 'inv') renderInv();
  else {
    $('#viewTitle').textContent = (AUTO_MENU.find(m => m[0] === curView) || [])[1] || '';
    if (curView === 'find') renderFinder();
    if (curView === 'sales') renderSales();
    if (sec === 'x') renderX(curView);
  }
  try { localStorage.setItem('ks:view', curMode === 'inv' ? 'inv:' + invView : curView); } catch (e) {}
  window.scrollTo(0, 0);
}

// ---------- 이벤트 ----------
function bind() {
  document.querySelectorAll('.modesw button').forEach(b => b.addEventListener('click', () => route(b.dataset.mode === 'inv' ? 'inv:' + invView : curView)));
  $('#autoNav').addEventListener('click', e => { const b = e.target.closest('[data-view]'); if (b) route(b.dataset.view); });
  if ($('#btnSideAcct')) $('#btnSideAcct').addEventListener('click', () => route('acct'));
  if ($('#btnModeSwap')) $('#btnModeSwap').addEventListener('click', () => route(curMode === 'inv' ? curView : 'inv:' + invView));
  if ($('#topStat')) $('#topStat').addEventListener('click', e => { if (e.target.closest('[data-view]')) route('acct'); });
  { let t = null; try { t = localStorage.getItem('ks:theme'); } catch (e) {} themeApply(t); }
  if ($('#themeSw')) $('#themeSw').addEventListener('change', e => { const t = e.target.checked ? 'dark' : 'light'; try { localStorage.setItem('ks:theme', t); } catch (x) {} themeApply(t); });
  // 아이템 찾기
  for (const k of Object.keys(FIND_CATS)) $('#f_' + k).checked = FO.cats.includes(k);
  $('#f_cand').value = FO.cand; $('#f_min7').value = FO.min7; $('#f_market').checked = FO.market;
  $('#findForm').addEventListener('change', async () => { FO = findOpts(); await store.set('findOpts', FO); updFindEta(); if (finder.at) { finder.items.forEach(it => judgeItem(it, { ...finder.opts, market: FO.market })); renderFinder(); } });
  $('#btnFind').addEventListener('click', () => { FO = findOpts(); queueJob(() => runFinder()); $('#btnFind').disabled = true; $('#fProgress').hidden = false; $('#fText').textContent = '앞의 작업이 끝나면 시작해요…'; });
  $('#btnFindRank').addEventListener('click', () => { FO = findOpts(); queueJob(() => runSiteScan('rank')); $('#btnFindRank').disabled = true; $('#fProgress').hidden = false; $('#fText').textContent = '앞의 작업이 끝나면 시작해요…'; });
  // 확장 프로그램 화면은 HTML 안에 스크립트를 못 넣어서(보안 규칙) 여기서 막음 — 엔터를 쳐도 화면이 새로고침되지 않게
  $('#findForm').addEventListener('submit', e => { e.preventDefault(); if (document.activeElement === $('#f_kw')) $('#btnFindKw').click(); });
  $('#btnFindKw').addEventListener('click', () => { FO = findOpts(); queueJob(() => runSiteScan('kw')); $('#btnFindKw').disabled = true; $('#fProgress').hidden = false; $('#fText').textContent = '앞의 작업이 끝나면 시작해요…'; });
  $('#btnFindMs').addEventListener('click', () => { FO = findOpts(); queueJob(() => runMusinsaRank()); $('#btnFindMs').disabled = true; $('#fProgress').hidden = false; $('#fText').textContent = '앞의 작업이 끝나면 시작해요…'; });
  $('#btnImpMs').addEventListener('click', () => { $('#impMsg').textContent = '앞의 작업이 끝나면 시작해요…'; queueJob(() => importMusinsaOrders(+$('#impDays').value), { label: '무신사 주문 불러오기' }); });
  $('#btnFindList').addEventListener('click', () => { FO = findOpts(); queueJob(() => runFinderList()); $('#btnFindList').disabled = true; $('#fProgress').hidden = false; $('#fText').textContent = '앞의 작업이 끝나면 시작해요…'; });
  $('#f_list').addEventListener('input', () => { const n = parseFindList($('#f_list').value).length; $('#fListCount').textContent = n ? `${n}개 · 예상 ${Math.max(1, Math.round(n * (findOpts().market ? 2.3 : 1.4)))}분쯤` : ''; });
  $('#btnFindStop').addEventListener('click', () => { stopFlag = true; jobGen++; $('#fText').textContent = '지금 단계까지만 하고 멈출게요…'; });
  $('#fRows').addEventListener('click', e => { const b = e.target.closest('[data-fadd]'); if (b) { b.disabled = true; finderAdd(b.dataset.fadd); } });
  updFindEta();
  $('#btnSettings').addEventListener('click', () => { const p = $('#settings'); p.hidden = !p.hidden; $('#btnSettings').setAttribute('aria-expanded', !p.hidden); });
  for (const k of ['ship', 'rate', 'base', 'max', 'min7', 'days', 'mode', 'win', 'trackHours', 'strongOnly', 'bgWork']) {
    const el = $('#s_' + k); el.value = S[k];
    el.addEventListener('change', async () => { S[k] = k === 'mode' ? el.value : +el.value; await store.set('settings', S); if (k === 'trackHours') setTrackAlarm(); renderMine(); renderSales(); });
  }

  $('#addForm').addEventListener('submit', async e => {
    e.preventDefault();
    const link = $('#a_link').value.trim();
    const m = link.match(/kream\.co\.kr\/products\/(\d+)/) || link.match(/^(\d{1,9})$/);
    if (!m) { $('#addMsg').textContent = '크림 상품 링크(kream.co.kr/products/…)나 상품번호를 넣어 주세요.'; return; }
    const p = { id: uid(), pid: m[1], cost: +$('#a_cost').value || 0, sizes: $('#a_size').value.trim(), memo: $('#a_memo').value.trim(), raw: null, at: null, added: Date.now() };
    products.unshift(p); await saveProducts();
    $('#addForm').reset(); $('#addMsg').textContent = '추가했어요. 바로 시세를 수집할게요.';
    renderMine();
    if (HAS_CHROME) { queueJob(() => runCollect([p])); queueJob(() => (p.raw && products.includes(p) ? runSources([p]) : null)); }
  });

  $('#btnCollectAll').addEventListener('click', () => { if (products.length) queueJob(() => runCollect([...products]), { label: '전체 시세 수집' }); });
  $('#btnSrcAll').addEventListener('click', () => { if (products.length) queueJob(() => runSources([...products]), { label: '전체 매입처 찾기' }); });
  if ($('#btnJobStop')) $('#btnJobStop').addEventListener('click', () => { jobStopAll(); if (curMode === 'inv') renderInv(); else if (typeof renderX === 'function') renderX(); });
  $('#btnStop').addEventListener('click', () => { stopFlag = true; jobGen++; jobChain = Promise.resolve(); jobBusy = 0; jobWait.splice(0).forEach(w => { try { w.onSkip && w.onSkip(); } catch (e) {} }); jobNow = null; jobChipRender();   // 기다리던 작업도 취소, 멈춘 작업은 버리고 새로 시작할 수 있게
 $('#progText').textContent = '지금 상품까지만 하고 멈출게요…'; });

  $('#mineRows').addEventListener('click', e => {
    const t = e.target;
    if (t.closest('input,select,a,label,summary')) return;
    const c = t.closest('[data-collect]'); if (c) { const p = products.find(x => x.id === c.dataset.collect); queueJob(() => runCollect([p])); return; }
    const tr = t.closest('[data-track]');
    if (tr) { const p = products.find(x => x.id === tr.dataset.track); if (p) { p.track = !p.track; saveProducts(); renderMine(); } return; }
    if (t.closest('[data-tracknow]')) { const p = products.find(x => x.id === openId); if (p) { const was = p.track; p.track = true; queueJob(async () => { await runTrack(false); if (!was) { p.track = false; await saveProducts(); renderMine(); } }); } return; }
    if (t.closest('[data-src]')) { const p = products.find(x => x.id === openId); if (p) queueJob(() => runSources([p])); return; }
    const d = t.closest('[data-del]'); if (d) {
      if (!d.classList.contains('armed')) { d.classList.add('armed'); d.textContent = '한 번 더'; setTimeout(() => { if (d.isConnected) { d.classList.remove('armed'); d.textContent = '삭제'; } }, 4000); return; }
      products = products.filter(x => x.id !== d.dataset.del); if (openId === d.dataset.del) openId = null; saveProducts(); renderMine(); return;
    }
    if (t.closest('tr.detail')) return;
    const row = t.closest('tr.item'); if (row) { openId = openId === row.dataset.id ? null : row.dataset.id; renderMine(); }
  });
  $('#mineRows').addEventListener('change', async e => {
    const t = e.target;
    if (t.dataset.cost) { const p = products.find(x => x.id === t.dataset.cost); p.cost = +t.value || 0; }
    else if (t.dataset.f) { const p = products.find(x => x.id === openId); const v = t.value.trim(); p[t.dataset.f] = (t.dataset.f === 'rate' || t.dataset.f === 'base') ? (v === '' ? null : +v) : v; }
    else return;
    await saveProducts(); renderMine();
  });

  $('#btnSend').addEventListener('click', () => sendToWeb(false));
  $('#btnClean').addEventListener('click', () => { const b = $('#cleanBox'); b.hidden = !b.hidden; $('#btnClean').setAttribute('aria-expanded', !b.hidden); $('#cleanMsg').textContent = ''; if (!b.hidden) renderClean(); });
  $('#btnCleanGo').addEventListener('click', runClean);
  $('#cleanOpts').addEventListener('change', async e => {
    const t = e.target;
    if (t.dataset.ck) S.clean[t.dataset.ck] = t.checked;
    else if (t.dataset.thin != null) { S.clean.thinMin = Math.max(0, +t.value || 0); S.clean.thin = true; }
    else return;
    await store.set('settings', S); renderClean();
  });
  $('#btnOpenWeb').addEventListener('click', () => openWeb());
  $('#btnMoveRecs').addEventListener('click', () => sendToWeb(true));
  $('#btnRecCsv').addEventListener('click', recCsv);

  // 2.7.1: 전체 백업 = 이 PC에 저장된 모든 것(내 상품·매출·재고관리·무신사 추적·보관 신청 내역·설정…). 설치 프로그램으로 옮길 때도 이 파일 하나면 돼요.
  //        PIN 기억용 열쇠(acctKey)는 빼요. 계정 정보는 PIN으로 잠긴 채로 들어가요.
  $('#btnBackup').addEventListener('click', async () => {
    let all = {}; try { all = HAS_CHROME ? await chrome.storage.local.get(null) : {}; } catch (e) {}
    delete all.acctKey; delete all.__alarms;
    download(JSON.stringify({ v: 2, app: '크림스캐너-전체', at: new Date().toISOString(), settings: S, products, records, all }), `크림스캐너_전체백업_${today()}.json`, 'application/json');
  });
  // 3.0.1: 설치 프로그램 — 작은 업데이트 파일(zip)로 화면·기능 업데이트
  if (window.__KC_APP && window.kcApp) {
    // 3.7: 웨일 연결 (크림 작업을 웨일에서)
    if (window.kcApp.whale) {
      const wr = $('#whaleRow'); if (wr) wr.hidden = false;
      const wUpd = async () => { try { const w = await window.kcApp.whale(); window.__KC_WHALE = w; const sel = $('#s_whale'); if (sel) sel.value = w.via;
        const inf = $('#whaleInfo'); if (inf) inf.innerHTML = w.via !== 'whale' ? '크림 작업을 프로그램 안에서 해요.' : w.connected ? `<b style="color:var(--good,#16a34a)">● 웨~일 연결됨</b> (웨~일 확장 ${esc(w.ver || '')})` : `<b style="color:var(--bad,#dc2626)">● 웨~일 연결 안 됨</b> — 웨~일을 켜고, 아래 '확장 폴더 열기' 안내대로 한 번만 확장을 올려 주세요.`;
        topStatus(); } catch (e) {} };
      wUpd(); setInterval(wUpd, 8000);
      const sel = $('#s_whale'); if (sel) sel.addEventListener('change', async () => { await window.kcApp.whaleSet(sel.value); wUpd(); });
      const bf = $('#btnWhaleFolder'); if (bf) bf.addEventListener('click', async () => { const d = await window.kcApp.whaleOpenFolder(); await window.kcApp.whaleLaunch(); alertBox(`웨~일 확장 페이지와 폴더(${d})를 열었어요. 웨~일 확장 페이지에서 '개발자 모드' 켜기 → '압축해제된 확장 프로그램을 로드합니다' → 열린 폴더 선택.`); });
    }
    $('#appUpd').hidden = false;
    window.kcApp.info().then(i => { $('#appVerInfo').textContent = `지금 버전 ${i.version}${i.updated ? ` (설치한 버전 ${i.bundled}에서 업데이트됨)` : ''}`; $('#btnAppUpdReset').hidden = !i.updated; }).catch(() => {});
    $('#fileAppUpd').addEventListener('change', async e => {
      const f = e.target.files[0]; if (!f) return;
      try { const v = await window.kcApp.applyUpdate(new Uint8Array(await f.arrayBuffer())); alertBox(`${v} 버전으로 업데이트했어요. 프로그램이 다시 켜져요…`); $('#appVerInfo').textContent = `${v} 버전으로 업데이트 — 다시 켜는 중…`; }
      catch (err) { const m = String(err.message || err).replace(/^Error invoking remote method 'kc': (Error: )?/, ''); alertBox('업데이트 못 했어요: ' + m); $('#appVerInfo').textContent = '업데이트 못 했어요: ' + m; }
      e.target.value = '';
    });
    $('#btnAppUpdReset').addEventListener('click', () => window.kcApp.resetUpdate());
    // 3.1: 자동 업데이트 — 새 버전을 받으면 위쪽 막대로 알려 줘요
    const upd = st => {
      const b = $('#updBar'); if (!b || !st) return;
      if (st.state === 'ready') { b.hidden = false; b.innerHTML = `새 버전 <b>${esc(st.version)}</b>을 받아 두었어요. <button type="button" class="primary small" id="btnUpdRestart">지금 다시 시작</button> <span class="small">(안 누르면 다음에 켤 때 적용돼요)</span>`; }
      else if (st.state === 'installer') { b.hidden = false; b.innerHTML = `새 버전 <b>${esc(st.version)}</b>은 설치 파일로 업데이트해야 해요. <button type="button" class="primary small" id="btnUpdInst">설치 파일 받기</button> <span class="small">받은 파일을 실행하면 데이터는 그대로 두고 바뀌어요.</span>`; }
      else b.hidden = true;
      const info = $('#appVerInfo'); if (info) info.textContent = st.state === 'checking' ? '새 버전 확인 중…' : st.state === 'latest' ? `지금 버전 ${st.version} — 최신이에요` : st.state === 'error' ? `업데이트 확인 실패: ${st.msg}` : st.state === 'ready' ? `새 버전 ${st.version} 준비됨 — 다시 시작하면 적용돼요` : st.state === 'installer' ? `새 버전 ${st.version} — 설치 파일 필요` : info.textContent;
      const r = $('#btnUpdRestart'); if (r) r.onclick = () => window.kcApp.restartNow();
      const ins = $('#btnUpdInst'); if (ins) ins.onclick = () => window.kcApp.openInstaller(st.url);
    };
    window.kcApp.onUpdate(upd); window.kcApp.updateState().then(upd).catch(() => {});
    $('#btnAppUpdCheck').addEventListener('click', () => window.kcApp.checkUpdate().then(upd));
  }
  $('#fileRestore').addEventListener('change', async e => {
    const f = e.target.files[0]; if (!f) return;
    try {
      const j = JSON.parse(await f.text());
      // 전체 백업(v2): 저장된 것 전부를 그대로 넣고 다시 열어요
      if (j.v === 2 && j.all && typeof j.all === 'object') {
        const all = { ...j.all }; delete all.acctKey; delete all.__alarms;
        if (HAS_CHROME) await chrome.storage.local.set(all);
        alertBox('전체 백업을 불러왔어요. 화면을 다시 여는 중…'); setTimeout(() => location.reload(), 600); return;
      }
      // 재고관리 백업 파일을 여기서 넣어도 돼요
      if (j.inv && Array.isArray(j.inv.items)) { if (HAS_CHROME) await chrome.storage.local.set({ inv: j.inv }); alertBox('재고관리 백업을 불러왔어요. 화면을 다시 여는 중…'); setTimeout(() => location.reload(), 600); return; }
      if (j.settings) { S = { ...DEF_SETTINGS, ...j.settings }; S.clean = { ...DEF_CLEAN, ...(S.clean || {}) }; }
      if (Array.isArray(j.products)) products = j.products;
      if (Array.isArray(j.records)) records = j.records;
      await store.set('settings', S); await saveProducts(); await saveRecords();
      for (const k of Object.keys(DEF_SETTINGS)) { const el = $('#s_' + k); if (el) el.value = S[k]; }
      renderMine(); renderSales(); alertBox('백업을 불러왔어요.');
    } catch (err) { alertBox('백업 파일을 읽지 못했어요.'); }
  });
}
function alertBox(msg) { $('#addMsg').textContent = msg; }

// ---------- 수준 미달 정리 ----------
const CLEAN_LABEL = { loss: '손해 (순마진 0원 이하)', thin: '순마진이 적음', slow: '회전 느림', none: '거래 없음 · 수집 실패', nosrc: '정품 유통 매입처 없음 (파는 곳 찾기 결과)' };
function weakReasons(x, C) {
  // x = { none, est7, margin, cost } — 웹페이지와 같은 기준
  const r = [];
  if (x.src && x.src.sites && !x.src.sites.some(s => s.level && (s.tier || 'trust') === 'trust')) r.push('nosrc');
  if (x.none) return r.concat('none');
  if (x.cost && x.margin != null && x.margin <= 0) r.push('loss');
  if (x.cost && x.margin > 0 && x.margin < (+C.thinMin || 0)) r.push('thin');
  if (S.min7 && (x.est7 || 0) < S.min7) r.push('slow');
  return r;
}
function weakOfProduct(p) {
  const a = analyze(p);
  if (!a) return p.err ? weakReasons({ none: true, src: p.src }, S.clean) : [];   // 수집 전인 상품은 지우지 않음
  return weakReasons({ none: !a.n7 && !a.nP && a.verdict[1] === '거래 없음', est7: a.est7, margin: a.margin, cost: +p.cost || 0, src: p.src }, S.clean);
}
function cleanTargets() {
  const C = S.clean;
  return products.map(p => ({ p, r: weakOfProduct(p) })).filter(o => o.r.some(k => C[k]));
}
function renderClean() {
  const C = S.clean;
  const all = products.map(p => weakOfProduct(p));
  const cnt = k => all.filter(r => r.includes(k)).length;
  $('#cleanOpts').innerHTML = ['loss', 'thin', 'slow', 'none', 'nosrc'].map(k => `<label class="chk"><input type="checkbox" data-ck="${k}" ${C[k] ? 'checked' : ''}>
      <span>${k === 'thin' ? `순마진 <input type="number" class="mini" data-thin step="1000" min="0" value="${C.thinMin}">원 미만` : CLEAN_LABEL[k]}${k === 'slow' ? ` <span class="small">(최근 7일 ${S.min7}건 미만)</span>` : ''} <b>${cnt(k)}개</b></span></label>`).join('');
  const t = cleanTargets();
  $('#cleanList').innerHTML = t.length
    ? t.map(o => { const i = (o.p.raw && o.p.raw.info) || {}; return `<div>· ${esc(i.name || '크림 ' + o.p.pid)} <span class="small">— ${o.r.map(k => k === 'thin' ? '순마진 적음' : CLEAN_LABEL[k].split(' (')[0]).join(', ')}</span></div>`; }).join('')
    : '<div>고른 기준에 걸리는 상품이 없어요.</div>';
  const go = $('#btnCleanGo'); go.disabled = !t.length; go.classList.remove('armed'); go.textContent = t.length ? `${t.length}개 삭제` : '삭제할 상품 없음';
}
async function runClean() {
  const go = $('#btnCleanGo'); const t = cleanTargets(); if (!t.length) return;
  if (!go.classList.contains('armed')) { go.classList.add('armed'); go.textContent = `한 번 더 누르면 ${t.length}개 삭제`; return; }
  const ids = new Set(t.map(o => o.p.id));
  products = products.filter(p => !ids.has(p.id)); if (ids.has(openId)) openId = null;
  await saveProducts(); renderMine(); renderClean();
  $('#cleanMsg').textContent = `${ids.size}개 지웠어요. 휴대폰에도 반영하려면 '휴대폰으로 보내기'를 눌러 붙여넣으세요.`;
}

// ---------- 휴대폰으로 보내기 (웹페이지에 붙여넣기) ----------
function summary(p) {
  const a = analyze(p); const info = (p.raw && p.raw.info) || {};
  const o = { pid: String(p.pid), name: info.name || ('크림 ' + p.pid), code: info.code || '', img: info.img || '', cost: +p.cost || 0,
    sizesWant: p.sizes || '', memo: p.memo || '', at: p.at || null, rate: p.rate ?? null, base: p.base ?? null, rel: info.rel || null, relRaw: info.relRaw || '', err: p.err || '', added: p.added || 0,
    src: p.src ? { at: p.src.at, sites: p.src.sites.map(x => ({ k: x.k, label: x.label, tier: x.tier || 'trust', searchUrl: x.searchUrl, level: x.level, n: x.n, min: x.min, allSold: !!x.allSold, err: x.err || '', items: (x.items || []).slice(0, 2) })) } : null };
  if (!a) return Object.assign(o, { est7: 0, verdict: ['mute', p.err ? '수집 실패' : '수집 전'], sizes: [], days: [] });
  return Object.assign(o, {
    est7: a.est7, estimated: a.estimated, sell: a.sell, fee: a.fee, settle: a.settle, be: a.be, margin: a.margin,
    verdict: a.verdict, trendPct: a.trendPct == null ? null : Math.round(a.trendPct * 10) / 10, avg7: a.avg7,
    hasF: a.hasF, mode: a.mode, fastShare: a.fastShare, market: a.market, minAskAll: a.minAskAll, basis: a.basis,
    sizes: a.sizes.map(x => ({ o: x.o, mkt: x.mkt, basis: x.basis, n7: x.n7, n7F: x.n7F, avg: x.avg, last: x.last, minAsk: x.minAsk, askQty: x.askQty, minAskN: x.minAskN, askQtyN: x.askQtyN, minAskF: x.minAskF, askQtyF: x.askQtyF, maxBid: x.maxBid, sell: x.sell, margin: x.margin, be: x.be, advice: x.advice, crowd: !!x.crowd })),
    days: a.buckets.map(b => ({ d: b.d, n: b.n, avg: b.avg, min: b.min, max: b.max }))
  });
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch (e) {}
  const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select(); let ok = false; try { ok = document.execCommand('copy'); } catch (e) {} ta.remove(); return ok;
}
async function openWeb() {
  if (HAS_CHROME) { try { await chrome.tabs.create({ url: WEB_URL }); return; } catch (e) {} }
  window.open(WEB_URL, '_blank');
}
async function sendToWeb(withRecords) {
  const msgEl = withRecords ? $('#moveMsg') : $('#sendMsg');
  const payload = { kc: 1, sentAt: Date.now(), settings: S, products: withRecords ? [] : products.map(summary) };
  if (withRecords) { payload.records = records; payload.keepPrices = true; }
  const invSum = !withRecords && typeof invMobileSummary === 'function' ? invMobileSummary() : null;
  if (invSum) payload.inv = invSum;
  if (!withRecords && !products.length && !invSum) { msgEl.hidden = false; msgEl.textContent = '보낼 상품이 없어요. 먼저 상품을 추가하고 수집해 주세요.'; return; }
  if (!withRecords && !products.length) payload.invOnly = true;   // 재고만 보낼 때는 웹의 시세 목록을 건드리지 않아요
  const ok = await copyText(JSON.stringify(payload));
  msgEl.hidden = false;
  if (!ok) { msgEl.textContent = '복사하지 못했어요. 다시 눌러 주세요.'; return; }
  msgEl.textContent = withRecords
    ? `매출 기록 ${records.length}개를 복사했어요. 열린 웹페이지에서 Ctrl+V를 누르면 옮겨져요. (이미 옮긴 기록은 다시 들어가지 않아요)`
    : `${products.length ? `상품 ${products.length}개 시세` : ''}${products.length && invSum ? '와 ' : ''}${invSum ? `재고 ${invSum.skus}종 ${invSum.qty}개` : ''}를 복사했어요. 열린 웹페이지에서 Ctrl+V만 누르세요. 그다음엔 휴대폰 Claude 앱에서 '크림스캐너' 페이지를 열면 보여요.`;
  await openWeb();
}

// 화면에 필요한 다른 파일(inv.js·auto.js 등)까지 다 읽힌 뒤에 시작해요
document.addEventListener('DOMContentLoaded', async function init() {
  const saved = await store.get('settings', {});
  S = { ...DEF_SETTINGS, ...saved };
  // 1.6: 발송비는 포인트로 충당 → 기본 0원 (이전 버전의 3,000원 설정을 한 번만 0으로 바꿈)
  if (!(saved.sv >= 16)) { S.ship = 0; S.sv = 16; await store.set('settings', S); }
  // 3.4.7: 시세 수집 기간 기본을 최근 3개월(90일)로 (한 번만 바꿈)
  if (!(saved.dv >= 1)) { S.days = 90; S.dv = 1; await store.set('settings', S); }
  S.clean = { ...DEF_CLEAN, ...(S.clean || {}) };
  products = await store.get('products', []);
  records = await store.get('records', []);
  FO = { ...DEF_FIND, ...(await store.get('findOpts', {})) };
  if (S.trackHours === undefined) S.trackHours = 0;
  if (S.strongOnly === undefined) S.strongOnly = 1;
  finder = await store.get('finder', finder);
  for (const it of finder.items || []) judgeItem(it, { tol: 5, ...(finder.opts || FO), market: FO.market });
  for (const p of products) { try { const a0 = analyze(p); srcSanitize(p.src, (a0 && (a0.sell || a0.minAskAll)) || (p.raw && p.raw.buyNow)); } catch (e) {} }
  bind(); renderMine(); renderSales();
  await invInit();
  await autoInit();
  if (typeof acctInit === 'function') { await acctInit(); acctBind(); }
  $('#verTxt').textContent = $('#verChip').textContent = '버전 ' + (HAS_CHROME && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '');
  let first = new URLSearchParams(location.search).get('tab'); if (first === 'inv') first = 'inv:home';
  if (!first) { try { first = localStorage.getItem('ks:view'); } catch (e) {} }
  route(first || 'mine');
  if (new URLSearchParams(location.search).get('orders') === '1') queueJob(async () => {   // 자동 동기화 알람이 연 창
    try {
      const r = await ordSync({ quiet: true });
      if (r && (r.auto || r.back || r.left)) chrome.notifications.create('ks-ord-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: '크림스캐너 — 구매처 주문', message: `${r.auto ? `자동 입고 ${r.auto}건 · ` : ''}${r.back ? `취소·반품 ${r.back}개 재고에서 뺌 · ` : ''}확인 필요 ${r.left}건`, priority: 1 });
      // 2.7: 자동 로그인을 못 한 곳은 알려 줘요
      const off = typeof ACCTS !== 'undefined' ? ACCTS.filter(A => (acctState[A.k] || {}).st === 'off' && (IS.ms.sites || new Set()).has(A.k)).map(A => A.label) : [];
      if (off.length) chrome.notifications.create('ks-login-' + Date.now(), { type: 'basic', iconUrl: 'icons/128.png', title: '크림스캐너 — 로그인 필요', message: `${off.join(', ')} 로그인이 풀려 있어요. 계정 연결에서 로그인해 주세요.`, priority: 2 });
    } catch (e) {}
    setTimeout(() => window.close(), 3000);
  }, { label: '자동 주문 동기화' });
  if (new URLSearchParams(location.search).get('track') === '1') queueJob(async () => { await runTrack(true, true); await runMsTrack(true); setTimeout(() => window.close(), 3000); }, { label: '자동 가격 추적' });   // 알람이 연 창
});
