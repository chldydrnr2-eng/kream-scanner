// 크림 상품 페이지가 스스로 불러오는 체결·판매입찰·구매입찰 데이터를 옆에서 받아 적어요.
// (크림에 따로 요청을 보내지 않고, 페이지가 받은 응답만 복사합니다)
(() => {
  if (window.__kcHooked) return;
  window.__kcHooked = true;
  const RE = /\/api\/p\/products\/(\d+)\/(sales|asks|bids)(?:\?|$)/;
  const post = (kind, url, data) => {
    try { window.postMessage({ __kc: 1, kind, url: String(url), data }, location.origin); } catch (e) {}
  };

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    const p = origFetch.call(window, input, init);
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || String(input);
      const m = url.match(RE);
      if (m) p.then(r => r.clone().json().then(j => post(m[2], url, j)).catch(() => {})).catch(() => {});
    } catch (e) {}
    return p;
  };

  const X = XMLHttpRequest.prototype;
  const open = X.open, send = X.send;
  X.open = function (method, url) { this.__kcUrl = String(url); return open.apply(this, arguments); };
  X.send = function () {
    const m = this.__kcUrl && this.__kcUrl.match(RE);
    if (m) this.addEventListener('load', () => {
      try { post(m[2], this.__kcUrl, JSON.parse(this.responseText)); } catch (e) {}
    });
    return send.apply(this, arguments);
  };
})();

// 3.7.1: 화면에 안 보이는(최소화한) 창에서는 크림이 '아래로 내리면 더 불러오기'를 안 해요(화면 그리기를 멈춰서).
//        크림스캐너가 요청할 때만, 거래 내역 창 안의 '더 불러오기 표시'가 보인다고 페이지에 알려줘서 다음 목록을 불러오게 해요.
(() => {
  if (window.__kcIOHooked || typeof window.IntersectionObserver !== 'function') return;
  window.__kcIOHooked = true;
  const IO = window.IntersectionObserver;
  const live = new Set();
  class KcIO extends IO {
    constructor(cb, opt) { super(cb, opt); this.__kcCb = cb; this.__kcT = new Set(); live.add(this); }
    observe(t) { try { this.__kcT.add(t); } catch (e) {} return super.observe(t); }
    unobserve(t) { try { this.__kcT.delete(t); } catch (e) {} return super.unobserve(t); }
    disconnect() { try { this.__kcT.clear(); live.delete(this); } catch (e) {} return super.disconnect(); }
  }
  try { Object.defineProperty(KcIO, 'name', { value: 'IntersectionObserver' }); } catch (e) {}
  window.IntersectionObserver = KcIO;
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__kcKick !== 1) return;
    const root = document.querySelector('.drawer__content');
    for (const o of live) for (const t of o.__kcT) {
      if (root && !root.contains(t)) continue;
      const r = t.getBoundingClientRect();
      try { o.__kcCb([{ isIntersecting: true, intersectionRatio: 1, target: t, time: performance.now(), boundingClientRect: r, intersectionRect: r, rootBounds: null }], o); } catch (x) {}
    }
  });
})();
