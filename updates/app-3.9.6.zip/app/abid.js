'use strict';
/* 크림스캐너 3.4 — 자동 입찰 (판매입찰 최저가 따라가기)
   내 판매입찰(일반·보관)마다 하한가·낮출 폭을 정해 두면, 정한 간격마다 크림 최저 판매입찰을 확인해서
   누가 나보다 싸게 걸면 그 가격보다 '낮출 폭'만큼 낮게 내 입찰가를 바꿔요. 하한가 아래로는 절대 안 내려요.
   일반판매와 보관판매(빠른배송)는 크림에서 최저가 경쟁이 따로라서 따로 비교해요.

   가격 바꾸는 방식 (abOpt.mode)
   - notify : 알림만 (바꿀 가격을 알려 주고 직접 바꿔요)
   - review : 크림 변경 화면에서 새 가격을 넣고 최종 확인 화면까지만 가요. 마지막 버튼은 직접 눌러요. (처음 시험용)
   - auto   : 최종 확인 화면의 가격·사이즈가 넣은 값과 같을 때만 끝까지 눌러요. 다르면 멈추고 알려요. */

const AB = { run: false, msg: '', next: 0, busy: false };
let abList = [], abLog = [], abOpt = { gap: 10, mode: 'review', run: false, cap: 200 }, abToday = { d: '', n: 0 };
const AB_END = /종료|완료|체결|취소|만료|발송|검수|입고\s*대기|배송|정산|반송|불합격/;
const AB_MODE = { notify: '알림만', review: '확인 화면까지 (마지막 버튼은 직접)', auto: '끝까지 자동' };
const abSet = t => { AB.msg = t; const e = $('#abMsg'); if (e) { e.textContent = t; e.hidden = !t; } };
const abType = t => t === 'fast' ? '보관' : '일반';
const abRound = (n, up) => (up ? Math.ceil : Math.floor)((+n || 0) / 1000) * 1000;
async function abSave() { await store.set('abList', abList); await store.set('abOpt', abOpt); await store.set('abToday', abToday); }
async function abSaveLog() { abLog = abLog.slice(-500); await store.set('abLog', abLog); }
function abNotify(title, message, sticky) { try { chrome.notifications.create('ab-' + Date.now() + Math.random(), { type: 'basic', iconUrl: 'icons/128.png', title, message, priority: 2, requireInteraction: !!sticky }); } catch (e) {} }
function abRender() { if (typeof xView !== 'undefined' && xView === 'kauto') renderX(); try { renderSide(); } catch (e) {} }

// 상품의 매입가: 자동 입찰에 직접 넣은 값 → 내 상품 시세·마진에 넣어 둔 매입가
function abCost(it) {
  if (it.cost !== '' && it.cost != null && +it.cost > 0) return +it.cost;
  const p = (typeof products !== 'undefined' ? products : []).find(x => String(x.pid) === String(it.pid));
  return p && +p.cost > 0 ? +p.cost : 0;
}
function abNet(price, it) { const c = abCost(it); if (!price || !c) return null; return price - feeOf(price) - (+S.ship || 0) - c; }

// 수집한 크림 데이터에서 그 사이즈·판매 방식의 최저 판매입찰과 최근 체결 평균
function abMarket(raw, size, fast) {
  const k = ckey(size), now = raw.ts || Date.now(), D = 864e5;
  const asksAll = (raw.asks || []).filter(a => ckey(a.o) === k && a.p);
  const hasFA = (raw.asks || []).some(a => a.f !== undefined);
  const asks = hasFA ? asksAll.filter(a => !!a.f === fast) : asksAll;
  const minAsk = asks.length ? Math.min(...asks.map(a => a.p)) : null;
  const qtyAtMin = asks.filter(a => a.p === minAsk).reduce((s, a) => s + (a.q || 1), 0);
  const sales = (raw.sales || []).filter(s => s.t && s.p && ckey(s.o) === k);
  const hasFS = sales.some(s => s.f !== undefined);
  const avg = days => {
    let a = sales.filter(s => now - s.t <= days * D), mixed = false;
    if (hasFS) { const c = a.filter(s => !!s.f === fast); if (c.length >= 3) a = c; else mixed = true; }
    if (!a.length) return null;
    return { p: abRound(a.reduce((x, s) => x + s.p, 0) / a.length), n: a.length, mixed };
  };
  return { minAsk, qtyAtMin, mixedAsks: !hasFA, d7: avg(7), d14: avg(14) };
}

// ---------- 내 판매입찰 불러오기 (일반판매 '판매 입찰' + 보관판매) ----------
async function abLoadBids() {
  const got = {};
  for (const [page, v] of [['selling', 'ksell'], ['inventory', 'kinv']]) {
    xSet(`크림 ${KM[v].t} 읽는 중…${+S.bgWork ? '' : ' (작은 창이 열려요)'}`);
    const tabId = await srcNav('https://kream.co.kr/my/' + page);
    const walk = await inTab(tabId, kcKreamWalk, [KM[v].tabs]);
    if (/login/.test((walk && walk.url) || '')) throw new Error('크림 로그인이 필요해요 — 계정 연결에서 크림을 로그인해 주세요');
    const r = await Promise.race([chrome.tabs.sendMessage(tabId, { cmd: 'kc-my' }), sleep(15000).then(() => null)]).catch(() => null);
    XS.km[page] = { at: Date.now(), cap: (r && r.cap) || [], text: walk ? walk.text : '' };
    got[page] = kRows(XS.km[page].cap);
  }
  await store.set('kreamMy', XS.km);
  const fresh = [];
  for (const [page, type] of [['selling', 'normal'], ['inventory', 'fast']]) {
    for (const r of got[page] || []) {
      if (!r.pid || !r.price || !r.size || AB_END.test(String(r.status))) continue;
      fresh.push({ key: type + '|' + (r.id || r.pid + '-' + ckey(r.size) + '-' + r.price), askId: String(r.id || ''), type, pid: String(r.pid), name: r.name, code: r.code, size: String(r.size), price: +r.price, status: r.status, exp: r.exp });
    }
  }
  const old = new Map(abList.map(x => [x.key, x]));
  const next = fresh.map(f => { const o = old.get(f.key); return o ? { ...o, ...f, price: o.lastSet && Date.now() - o.lastSet < 120000 ? o.price : f.price, gone: false } : { ...f, on: false, floor: '', step: 1000, cost: '', st: '' }; });
  for (const o of abList) if (!next.some(n => n.key === o.key)) next.push({ ...o, on: false, gone: true, st: '크림에 이 입찰이 없어요 (체결·취소·만료)' });
  abList = next;
  await abSave();
  return fresh.length;
}

// ---------- 시세 확인 (가격은 안 바꿔요) ----------
async function abQuote(items) {
  const byPid = new Map(); for (const it of items) (byPid.get(it.pid) || byPid.set(it.pid, []).get(it.pid)).push(it);
  let i = 0;
  for (const [pid, L] of byPid) {
    i++; xSet(`크림 시세 확인 중… (${i}/${byPid.size})`); jobSay(`${i}/${byPid.size}`);
    const p = { id: 'ab', pid, raw: null };
    try { await collectOne(p, { days: Math.max(+S.win || 14, 14), maxPages: 4 }); }
    catch (e) { for (const it of L) it.st = '시세 확인 실패: ' + e.message; if (/로그인/.test(e.message)) throw e; continue; }
    for (const it of L) { it.mk = { ...abMarket(p.raw, it.size, it.type === 'fast'), at: Date.now() }; if (!it.name && p.raw.info) it.name = p.raw.info.name; }
    await abSave();
    await sleep(1500 + Math.random() * 2000);
  }
}

// 한 줄에 대해 할 일 정하기 → { act: 'none'|'lower'|'stop', target, why }
function abDecide(it) {
  const m = it.mk; if (!m) return { act: 'none', why: '시세 없음' };
  const floor = abRound(it.floor, true), step = Math.max(1000, abRound(it.step || 1000, true)), me = +it.price;
  if (!floor) return { act: 'none', why: '하한가를 정해 주세요' };
  if (m.minAsk == null) return { act: 'none', why: '다른 판매입찰 없음' };
  if (m.minAsk > me) return { act: 'none', why: '내가 최저가' };
  if (m.minAsk === me) return { act: 'none', why: m.qtyAtMin > 1 ? '최저가와 같은 가격 (같은 가격 입찰이 더 있어요)' : '내가 최저가' };
  // 누가 나보다 싸게 걸었어요
  if (m.minAsk <= floor) return { act: 'stop', why: `최저가 ${won(m.minAsk)}이 하한가 ${won(floor)} 이하라 더 안 내려요` };
  let target = abRound(m.minAsk - step);
  if (target < floor) target = floor;
  if (target >= me) return { act: 'none', why: '바꿀 필요 없음' };
  return { act: 'lower', target, why: `최저가 ${won(m.minAsk)} → ${won(target)}` };
}

// ---------- 크림에서 입찰가 바꾸기 ----------
async function abChange(it, target) {
  const final = abOpt.mode === 'auto';
  const lists = it.type === 'fast' ? ['https://kream.co.kr/my/inventory', ['보관 중']] : ['https://kream.co.kr/my/selling', ['판매 입찰']];
  let r = null;
  if (it.askId) {
    const tabId = await srcNav(`https://kream.co.kr/my/selling/${encodeURIComponent(it.askId)}`);
    await sleep(900);
    const [x] = await execT({ target: { tabId }, func: kcAskChange, args: [{ target, from: +it.price, size: it.size, code: it.code, final, list: false }], world: 'MAIN' }, 60000);
    r = x && x.result;
  }
  if (!r || r.error === 'nochg') {   // 상세 화면 주소가 다르면 목록에서 그 입찰을 눌러서 들어가요
    const tabId = await srcNav(lists[0]);
    await inTab(tabId, kcKreamWalk, [lists[1]]);
    const [x] = await execT({ target: { tabId }, func: kcAskChange, args: [{ target, from: +it.price, size: it.size, code: it.code, final, list: true }], world: 'MAIN' }, 60000);
    r = x && x.result;
  }
  return r || { error: '응답 없음' };
}

async function abApply(it, target, why) {
  const from = +it.price;
  // 안전장치: 하한가 아래, 1,000원 단위 아님, 한 번에 30% 넘게 내리는 건 하지 않아요
  const floor = abRound(it.floor, true);
  if (!(target >= floor && target % 1000 === 0 && target < from && from - target <= from * 0.3)) {
    it.on = false; it.st = `멈춤 — 바꿀 가격 ${won(target)}이 이상해요`; abNotify('자동 입찰 — 멈춤', `${it.name} ${it.size}: 바꿀 가격이 이상해서 멈췄어요`, true); return 'stop';
  }
  const d = today(); if (abToday.d !== d) abToday = { d, n: 0 };
  if (abToday.n >= abOpt.cap) { AB.run = false; abOpt.run = false; abSet(`오늘 최대 변경 횟수(${abOpt.cap}번)에 닿아서 멈췄어요`); return 'stop'; }
  const log = { t: Date.now(), key: it.key, name: it.name, size: it.size, type: it.type, from, to: target, why };
  if (abOpt.mode === 'notify') {
    if (it.told !== target) { abNotify(`입찰가 내려야 해요 — ${String(it.name).slice(0, 28)}`, `${abType(it.type)} ${it.size}: ${won(from)} → ${won(target)} (${why})`); it.told = target; abLog.push({ ...log, res: '알림만 (직접 바꿔야 해요)' }); }
    it.st = `${won(target)}으로 바꿔야 해요 (알림만)`; return 'told';
  }
  jobSay(`${it.size} ${won(from)} → ${won(target)}`);
  let r;
  try { r = await abChange(it, target); } catch (e) { r = { error: e.message }; }
  abToday.n++;
  const said = r && r.said ? r.said.join(' / ').slice(0, 100) : '';
  if (r && r.mismatch) {
    it.on = false; it.st = '멈춤 — ' + r.mismatch; abLog.push({ ...log, res: '확인 불일치로 안 바꿈: ' + r.mismatch });
    abNotify('자동 입찰 — 멈춤', `${it.name} ${it.size}: ${r.mismatch}`, true); return 'stop';
  }
  if (r && r.ready) {
    it.st = `확인 화면까지 갔어요 — 크림 창에서 ${won(target)} 확인 후 직접 눌러 주세요`; abLog.push({ ...log, res: '확인 화면까지 (마지막 버튼은 직접)' });
    try { await chrome.windows.update(work.winId, { focused: true, state: 'normal' }); } catch (e) {}
    work = { winId: null, tabId: null };   // 창을 닫지 않고 남겨 둬요
    abNotify('자동 입찰 — 확인해 주세요', `${it.name} ${it.size}: ${won(from)} → ${won(target)} 확인 화면을 띄웠어요`, true);
    AB.run = false; abOpt.run = false;
    abSet(`${it.name} ${it.size}: 크림 창에 ${won(target)} 확인 화면을 띄웠어요. 맞으면 마지막 버튼을 직접 누르고, 잘 되면 '끝까지 자동'으로 바꿔 주세요.`);
    return 'paused';
  }
  if (r && r.submitted && r.done) {
    it.price = target; it.lastSet = Date.now(); it.st = `${new Date().toLocaleTimeString('ko-KR')} ${won(from)} → ${won(target)} 바꿈`;
    abLog.push({ ...log, res: '바꿈' }); return 'done';
  }
  if (r && r.submitted) {   // 버튼은 눌렀는데 결과가 분명하지 않으면 두 번 바꾸지 않게 그 줄을 꺼요
    it.on = false; it.st = '버튼을 누른 뒤 결과 확인 필요 — 크림에서 입찰가를 확인해 주세요'; abLog.push({ ...log, res: '결과 확인 필요' + (said ? ': ' + said : '') });
    abNotify('자동 입찰 — 확인 필요', `${it.name} ${it.size}: 입찰가가 ${won(target)}으로 바뀌었는지 크림에서 확인해 주세요`, true); return 'stop';
  }
  const err = r && r.error === 'nochg' ? '크림에서 입찰 변경 버튼을 못 찾았어요' : (r && r.error) || '바꾸지 못했어요';
  it.st = '실패 — ' + err + (said ? ` (${said})` : ''); abLog.push({ ...log, res: '실패: ' + err });
  it.fail = (it.fail || 0) + 1;
  if (it.fail >= 3) { it.on = false; it.st += ' — 3번 실패해서 꺼요'; abNotify('자동 입찰 — 실패', `${it.name} ${it.size}: ${err}`, true); }
  return 'fail';
}

// ---------- 한 바퀴: 켠 줄만 시세 확인 → 필요하면 가격 바꾸기 ----------
async function abCycle() {
  const on = abList.filter(x => x.on && !x.gone);
  if (!on.length) { AB.run = false; abOpt.run = false; abSet('켠 줄이 없어서 멈췄어요'); return; }
  AB.busy = true; abRender();
  try {
    await abQuote(on);
    for (const it of on) {
      if (!AB.run) break;
      const d = abDecide(it);
      if (d.act === 'none') { it.st = d.why; continue; }
      if (d.act === 'stop') {
        it.on = false; it.st = '하한가 도달 · 멈춤 — ' + d.why;
        abLog.push({ t: Date.now(), key: it.key, name: it.name, size: it.size, type: it.type, from: +it.price, to: +it.price, why: d.why, res: '하한가 도달 · 멈춤' });
        abNotify(`하한가 도달 — ${String(it.name).slice(0, 28)}`, `${abType(it.type)} ${it.size}: ${d.why}`, true);
        continue;
      }
      const res = await abApply(it, d.target, d.why);
      await abSave(); await abSaveLog(); abRender();
      if (res === 'paused') return;
      await sleep(2000 + Math.random() * 2000);
    }
    await store.set('abAt', Date.now());
  } catch (e) {
    abSet('멈췄어요: ' + e.message);
    if (/로그인/.test(e.message)) { AB.run = false; abOpt.run = false; abNotify('자동 입찰 — 로그인 필요', '크림 로그인이 풀려서 자동 입찰을 멈췄어요', true); }
  } finally {
    AB.busy = false;
    if (work.winId) await closeWork();
    await abSave(); await abSaveLog(); abRender();
  }
}

async function abLoop() {
  if (AB.loop) return;
  AB.loop = true; AB.run = true; abOpt.run = true; await abSave(); abRender();
  try {
    while (AB.run) {
      await queueJob(() => abCycle(), { label: '자동 입찰' });
      if (!AB.run) break;
      const gap = (+abOpt.gap || 10) * 60000 * (0.9 + Math.random() * 0.2);
      AB.next = Date.now() + gap;
      abSet(`다음 확인 ${new Date(AB.next).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}`);
      abRender();
      while (AB.run && Date.now() < AB.next) await sleep(1000);
    }
  } finally { AB.loop = false; AB.next = 0; await abSave(); abRender(); }
}

// ---------- 화면 ----------
function vAutoBid() {
  const n = abList.filter(x => !x.gone).length, on = abList.filter(x => x.on && !x.gone).length;
  const rows = abList.map(it => {
    const m = it.mk || {}, floor = abRound(it.floor, true), cost = abCost(it);
    const netF = floor ? abNet(floor, it) : null, netNow = abNet(+it.price, it);
    const avg = (x, d) => x ? `<div>${d}일 <b>${won(x.p)}</b> <span class="small">${x.n}건${x.mixed ? '·혼합' : ''}</span></div>` : `<div class="small">${d}일 –</div>`;
    const dec = it.mk ? abDecide(it) : null;
    const rank = m.minAsk == null ? (it.mk ? '<span class="pill mute">입찰 없음</span>' : '–') : m.minAsk >= +it.price ? '<span class="pill ok">내가 최저가</span>' : `<span class="pill warn">${won(m.minAsk)}</span>`;
    return `<tr${it.gone ? ' class="mute"' : ''}><td><input type="checkbox" data-xk="abOn" data-i="${esc(it.key)}"${it.on ? ' checked' : ''}${it.gone ? ' disabled' : ''} aria-label="자동 입찰 켜기"></td>
      <td class="l name"><b>${esc(it.name || it.pid)}</b><span class="code">${esc(it.code || '')}</span></td><td class="l"><b>${esc(it.size)}</b></td>
      <td class="l"><span class="pill ${it.type === 'fast' ? 'ok' : 'mute'}">${abType(it.type)}</span></td>
      <td><b>${won(it.price)}</b>${netNow != null ? `<small class="${netNow < 0 ? 'neg' : ''}">순마진 ${sign(netNow)}</small>` : ''}</td>
      <td>${rank}</td><td>${avg(m.d7, 7)}${avg(m.d14, 14)}</td>
      <td><input type="number" class="num" step="1000" min="0" data-xk="abCost" data-i="${esc(it.key)}" value="${esc(it.cost !== '' && it.cost != null ? it.cost : '')}" placeholder="${cost ? cost.toLocaleString() : '매입가'}" aria-label="매입가"></td>
      <td><input type="number" class="num" step="1000" min="0" data-xk="abFloor" data-i="${esc(it.key)}" value="${esc(it.floor || '')}" placeholder="하한가" aria-label="하한가">${netF != null ? `<small class="${netF < 0 ? 'neg' : ''}">팔리면 순마진 ${sign(netF)}</small>` : ''}</td>
      <td><select data-xk="abStep" data-i="${esc(it.key)}" aria-label="낮출 폭">${[1000, 2000, 3000, 5000, 10000].map(v => opt(v, won(v), +(it.step || 1000) === v)).join('')}</select></td>
      <td class="l small">${esc(it.st || (dec ? dec.why : ''))}${it.mk ? `<small>${new Date(it.mk.at).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })} 확인</small>` : ''}</td>
      <td>${it.gone ? `<button type="button" class="x" data-x="abDel" data-i="${esc(it.key)}" aria-label="삭제">×</button>` : `<a class="ghost tiny" href="https://kream.co.kr/products/${esc(it.pid)}" target="_blank" rel="noopener">상품</a>`}</td></tr>`;
  }).join('');
  const d = today(), cnt = abToday.d === d ? abToday.n : 0;
  const head = xHead('자동 입찰', '내 판매입찰을 정한 간격마다 확인해서, 누가 나보다 싸게 걸면 그 가격보다 낮출 폭만큼 낮게 바꿔요. 하한가 아래로는 절대 안 내려요. 일반판매·보관판매는 최저가를 따로 비교해요.',
    `<button type="button" class="ghost" data-x="abLoad"${XS.busy || AB.busy ? ' disabled' : ''}>내 입찰 불러오기</button><button type="button" class="ghost" data-x="abQuote"${XS.busy || AB.busy || !n ? ' disabled' : ''}>시세만 확인</button>${AB.run ? '<button type="button" class="primary danger" data-x="abStop">자동 입찰 끄기</button>' : `<button type="button" class="primary" data-x="abStart"${on ? '' : ' disabled'}>자동 입찰 켜기</button>`}`);
  return `${head}
  <div class="kgrid k3">${card('상태', AB.run ? (AB.busy ? '확인 중' : '켜짐') : '꺼짐', AB.run ? 'pos' : '', AB.run && AB.next ? `다음 확인 ${new Date(AB.next).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}` : '')}${card('켠 입찰', `${on} / ${n}개`)}${card('오늘 바꾼 횟수', `${cnt}번`, '', `하루 최대 ${abOpt.cap}번`)}</div>
  <div class="panel"><div class="row-btns">
    <label>확인 간격<select data-xk="abGap">${[5, 10, 15, 30, 60].map(v => opt(v, v + '분마다' + (v === 10 ? ' (추천)' : ''), +abOpt.gap === v)).join('')}</select></label>
    <label>가격 바꾸는 방식<select data-xk="abMode">${Object.entries(AB_MODE).map(([k, t]) => opt(k, t, abOpt.mode === k)).join('')}</select></label>
    <label>하루 최대 변경<select data-xk="abCap">${[50, 100, 200, 500].map(v => opt(v, v + '번', +abOpt.cap === v)).join('')}</select></label>
  </div>
  <p class="iflash" id="abMsg"${AB.msg ? '' : ' hidden'}>${esc(AB.msg)}</p>
  ${abList.length ? `<div class="tbl abtbl"><table><thead><tr><th>켜기</th><th class="l">상품</th><th class="l">사이즈</th><th class="l">구분</th><th>내 입찰가</th><th>크림 최저가</th><th>체결 평균</th><th>매입가</th><th>하한가</th><th>낮출 폭</th><th class="l">상태</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`
    : '<p class="empty"><b>내 입찰 불러오기</b>를 누르세요. 크림의 일반판매 \'판매 입찰\'과 보관판매 입찰이 사이즈별로 들어와요. 그다음 <b>시세만 확인</b>을 누르면 최저가와 체결 평균이 채워져요.</p>'}
  <p class="hint">순서: ① 내 입찰 불러오기 → ② 시세만 확인 → ③ 체결 평균·순마진을 보고 줄마다 <b>하한가</b> 넣기 → ④ 켜기 체크 → ⑤ <b>자동 입찰 켜기</b>. 순마진 = 가격 − 수수료 − 발송비 − 매입가 (설정의 수수료·발송비 기준). 매입가 칸을 비우면 '내 상품 시세 · 마진'에 넣은 매입가를 써요.</p>
  <p class="hint"><b>가격 바꾸는 방식</b>: 처음에는 <b>확인 화면까지</b>로 한 번 돌려 보세요. 크림 창에 새 가격이 들어간 확인 화면을 띄우고 멈춰요. 가격·사이즈가 맞고 마지막 버튼으로 잘 바뀌면 <b>끝까지 자동</b>으로 바꾸면 돼요. 끝까지 자동에서도 확인 화면의 가격·사이즈가 넣은 값과 다르면 누르지 않고 멈춰요. 하한가에 닿거나 3번 실패하면 그 줄은 꺼지고 알림이 와요.</p>
  <p class="hint">크림 창은 뒤에서 열려서 화면에 안 보여요(설정 → 작업 창에서 바꿀 수 있어요). '확인 화면까지'일 때만 확인할 크림 창을 앞으로 띄워요. 크림스캐너가 켜져 있는 동안(창을 닫아도 트레이에 있으면) 계속 돌아요. PC가 꺼지거나 잠자기 상태면 멈춰요. 크림은 매크로를 허용하지 않아서, 너무 자주 확인하면 계정이 제한될 수 있어요.</p></div>
  ${vAbLog()}`;
}
function vAbLog() {
  const L = abLog.slice(-60).reverse();
  return `<div class="panel"><div class="toolbar"><h2>가격 바꾼 기록</h2><div class="row-btns">${abLog.length ? '<button type="button" class="ghost" data-x="abLogXl">엑셀</button><button type="button" class="ghost" data-x="abLogClear">기록 지우기</button>' : ''}</div></div>
  ${L.length ? `<div class="tbl"><table><thead><tr><th class="l">시각</th><th class="l">상품</th><th class="l">사이즈</th><th class="l">구분</th><th>전</th><th>후</th><th class="l">이유</th><th class="l">결과</th></tr></thead><tbody>${L.map(l => `<tr><td class="l small">${new Date(l.t).toLocaleString('ko-KR')}</td><td class="l">${esc(l.name)}</td><td class="l">${esc(l.size)}</td><td class="l">${abType(l.type)}</td><td>${won(l.from)}</td><td><b>${won(l.to)}</b></td><td class="l small">${esc(l.why || '')}</td><td class="l small">${esc(l.res || '')}</td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">아직 기록이 없어요.</p>'}</div>`;
}

async function abAct(a, el) {
  const it = abList.find(x => x.key === el.dataset.i);
  switch (a) {
    case 'abLoad': if (!needExt()) return; return xRun(async () => { const n = await abLoadBids(); xSet(n ? `판매입찰 ${n}개를 불러왔어요` : '진행 중인 판매입찰이 없어요 (일반판매 판매 입찰 · 보관판매 입찰)'); });
    case 'abQuote': if (!needExt()) return; return xRun(async () => { await abQuote(abList.filter(x => !x.gone)); xSet('시세를 채웠어요 — 체결 평균을 보고 하한가를 넣어 주세요'); });
    case 'abStart': {
      const bad = abList.filter(x => x.on && !x.gone && !(abRound(x.floor, true) > 0));
      if (bad.length) return abSet(`하한가를 안 넣은 줄이 ${bad.length}개 있어요 — 하한가를 넣거나 켜기를 풀어 주세요`);
      const over = abList.filter(x => x.on && !x.gone && abRound(x.floor, true) > +x.price);
      if (over.length) return abSet(`하한가가 지금 입찰가보다 높은 줄이 ${over.length}개 있어요 — 하한가를 확인해 주세요`);
      if (!needExt()) return;
      abSet(`켰어요 — ${abOpt.gap}분마다 확인해요 (${AB_MODE[abOpt.mode]})`); abLoop(); return abRender();
    }
    case 'abStop': AB.run = false; abOpt.run = false; await abSave(); abSet('자동 입찰을 껐어요'); return abRender();
    case 'abDel': abList = abList.filter(x => x !== it); await abSave(); return abRender();
    case 'abLogClear': abLog = []; await abSaveLog(); return abRender();
    case 'abLogXl': return xlDownload([{ name: '자동입찰기록', rows: [['시각', '상품', '사이즈', '구분', '전', '후', '이유', '결과'], ...abLog.map(l => [new Date(l.t).toLocaleString('ko-KR'), l.name, l.size, abType(l.type), l.from, l.to, l.why || '', l.res || ''])], widths: [20, 36, 8, 6, 10, 10, 30, 30] }], `크림_자동입찰기록_${today()}.xlsx`);
  }
}
async function abInput(el, ev) {
  const k = el.dataset.xk, it = abList.find(x => x.key === el.dataset.i);
  const v = el.type === 'checkbox' ? el.checked : el.value;
  if (k === 'abOn' && it) { if (v && !(abRound(it.floor, true) > 0)) { el.checked = false; return abSet('하한가를 먼저 넣어 주세요'); } it.on = v; it.fail = 0; if (v) it.st = ''; await abSave(); return abRender(); }
  if (ev.type !== 'change') return;
  if (k === 'abFloor' && it) { it.floor = v === '' ? '' : abRound(v, true); it.st = ''; await abSave(); return abRender(); }
  if (k === 'abCost' && it) { it.cost = v === '' ? '' : +v; await abSave(); return abRender(); }
  if (k === 'abStep' && it) { it.step = +v; await abSave(); return abRender(); }
  if (k === 'abGap') { abOpt.gap = +v; await abSave(); return abSet(`${v}분마다 확인해요${AB.run ? ' (다음 확인부터)' : ''}`); }
  if (k === 'abMode') { abOpt.mode = v; await abSave(); return abSet(v === 'auto' ? '끝까지 자동 — 확인 화면의 가격·사이즈가 맞을 때만 마지막 버튼까지 눌러요' : v === 'review' ? '확인 화면까지만 가고 마지막 버튼은 직접 눌러요' : '알림만 보내요'); }
  if (k === 'abCap') { abOpt.cap = +v; await abSave(); }
}
async function abInit() {
  abList = await store.get('abList', []); abLog = await store.get('abLog', []);
  abOpt = { ...abOpt, ...(await store.get('abOpt', {})) }; abToday = await store.get('abToday', abToday);
  // 프로그램을 다시 켜도 자동 입찰이 켜져 있었으면 1분 뒤 이어서 돌아요
  if (abOpt.run && abList.some(x => x.on && !x.gone) && HAS_CHROME) setTimeout(() => { if (!AB.run) abLoop(); }, 60000);
}
