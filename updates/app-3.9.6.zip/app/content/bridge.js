// 페이지에서 받아 적은 데이터를 모아 두었다가, '크림스캐너' 페이지가 요청하면 정리해서 돌려줘요.
(() => {
  const cap = { sales: [], asks: [], bids: [] };
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__kc !== 1) return;
    const list = cap[e.data.kind];
    if (list && e.data.data) list.push(e.data.data);
  });
  chrome.runtime.onMessage.addListener((msg, sender, send) => {
    if (!msg || msg.cmd !== 'kc-collect') return;
    KC.collect(window, document, cap, msg.opts)
      .then(send)
      .catch(err => send({ error: String(err && err.message || err) }));
    return true;
  });
})();
