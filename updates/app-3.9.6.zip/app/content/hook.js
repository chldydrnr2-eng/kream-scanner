// 크림 상품 페이지가 스스로 불러오는 체결·판매입찰·구매입찰 데이터를 옆에서 받아 적어요.
// (크림에 따로 요청을 보내지 않고, 페이지가 받은 응답만 복사합니다)
(() => {
  if (window.__kcHooked) return;
  window.__kcHooked = true;
  const RE = /\/api\/p\/products\/(\d+)\/(sales|asks|bids)(?:\?|$)/;
  const post = (kind, url, data) => {
    try { window.postMessage({ __kc: 1, kind, url: String(url), data }, location.origin); } catch (e) {}
  };

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    const p = origFetch.call(window, input, init);
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || String(input);
      const m = url.match(RE);
      if (m) {
        p.then(r => r.clone().json().then(j => post(m[2], url, j)).catch(() => {})).catch(() => {});
        // 3.7.3: 페이지가 이 목록을 부를 때 쓴 주소·헤더를 기억해 둬요 (숨은 창에서 다음 목록을 같은 방식으로 부르려고)
        try { const h = {}; new Headers((init && init.headers) || (input && input.headers) || {}).forEach((v, k) => { h[k] = v; }); last[m[2]] = { url: new URL(url, location.href).href, headers: h }; } catch (e) {}
      }
    } catch (e) {}
    return p;
  };
  const last = {};

  const X = XMLHttpRequest.prototype;
  const open = X.open, send = X.send;
  X.open = function (method, url) { this.__kcUrl = String(url); this.__kcH = {}; return open.apply(this, arguments); };
  const setH = X.setRequestHeader; X.setRequestHeader = function (k, v) { try { (this.__kcH = this.__kcH || {})[k] = v; } catch (e) {} return setH.apply(this, arguments); };
  X.send = function () {
    const m = this.__kcUrl && this.__kcUrl.match(RE);
    if (m) { try { last[m[2]] = { url: new URL(this.__kcUrl, location.href).href, headers: this.__kcH || {} }; } catch (e) {} }
    if (m) this.addEventListener('load', () => {
      try { post(m[2], this.__kcUrl, JSON.parse(this.responseText)); } catch (e) {}
    });
    return send.apply(this, arguments);
  };
  // 3.7.3: 크림스캐너가 '다음 목록'을 달라고 하면, 페이지가 쓰던 것과 같은 주소(커서만 다음 것)·헤더로 불러요.
  //        (화면이 안 보이는 창에서는 크림이 아래로 내려도 다음 목록을 안 불러서)
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__kcMore !== 1) return;
    const L = last[e.data.kind]; if (!L || !e.data.cursor) return;
    try {
      const u = new URL(L.url); u.searchParams.set('cursor', e.data.cursor);
      const h = { ...L.headers };
      // 요청 시각 헤더는 지금 시각으로 (페이지가 하는 것과 같은 형식)
      const dk = Object.keys(h).find(k => k.toLowerCase() === 'x-kream-client-datetime');
      if (dk) { const d = new Date(), p = n => String(n).padStart(2, '0'), o = -d.getTimezoneOffset(); h[dk] = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${o >= 0 ? '+' : '-'}${p(Math.floor(Math.abs(o) / 60))}${p(Math.abs(o) % 60)}`; }
      window.fetch(u.href, { headers: h });
    } catch (x) {}
  });
})();

// 3.7.1: 화면에 안 보이는(최소화한) 창에서는 크림이 '아래로 내리면 더 불러오기'를 안 해요(화면 그리기를 멈춰서).
//        크림스캐너가 요청할 때만, 거래 내역 창 안의 '더 불러오기 표시'가 보인다고 페이지에 알려줘서 다음 목록을 불러오게 해요.
(() => {
  if (window.__kcIOHooked || typeof window.IntersectionObserver !== 'function') return;
  window.__kcIOHooked = true;
  const IO = window.IntersectionObserver;
  const live = new Set();
  class KcIO extends IO {
    constructor(cb, opt) { super(cb, opt); this.__kcCb = cb; this.__kcT = new Set(); live.add(this); }
    observe(t) { try { this.__kcT.add(t); } catch (e) {} return super.observe(t); }
    unobserve(t) { try { this.__kcT.delete(t); } catch (e) {} return super.unobserve(t); }
    disconnect() { try { this.__kcT.clear(); live.delete(this); } catch (e) {} return super.disconnect(); }
  }
  try { Object.defineProperty(KcIO, 'name', { value: 'IntersectionObserver' }); } catch (e) {}
  window.IntersectionObserver = KcIO;
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__kcKick !== 1) return;
    const root = document.querySelector('.drawer__content');
    for (const o of live) for (const t of o.__kcT) {
      if (root && !root.contains(t)) continue;
      const r = t.getBoundingClientRect();
      try { o.__kcCb([{ isIntersecting: true, intersectionRatio: 1, target: t, time: performance.now(), boundingClientRect: r, intersectionRect: r, rootBounds: null }], o); } catch (x) {}
    }
  });
})();
