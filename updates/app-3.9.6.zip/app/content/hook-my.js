// 크림 마이페이지(판매·구매·보관 내역)가 스스로 불러오는 응답을 옆에서 받아 적어요. 크림에 따로 요청을 보내지 않아요.
(() => {
  if (window.__kcMyHooked) return;
  window.__kcMyHooked = true;
  const RE = /api\.kream\.co\.kr\/api\/(o|m|seller|settlement|my|p\/my|v\d\/my)\//;
  const SKIP = /notification|banner|recommend|popup|event/;
  const post = (url, data) => { try { window.postMessage({ __kcmy: 1, url: String(url).replace(/([?&])request_key=[^&]*/, '$1'), data }, location.origin); } catch (e) {} };
  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    const p = origFetch.call(window, input, init);
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || String(input);
      if (RE.test(url) && !SKIP.test(url)) p.then(r => r.clone().json().then(j => post(url, j)).catch(() => {})).catch(() => {});
    } catch (e) {}
    return p;
  };
  const X = XMLHttpRequest.prototype, open = X.open, send = X.send;
  X.open = function (m, url) { this.__kcMy = String(url); return open.apply(this, arguments); };
  X.send = function () {
    if (this.__kcMy && RE.test(this.__kcMy) && !SKIP.test(this.__kcMy)) this.addEventListener('load', () => { try { post(this.__kcMy, JSON.parse(this.responseText)); } catch (e) {} });
    return send.apply(this, arguments);
  };
})();
