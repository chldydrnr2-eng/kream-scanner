// 크림 상품 페이지에서 '거래 내역 더보기'를 열고, 체결 거래·판매 입찰·구매 입찰을 모아요.
// win/doc/cap 을 인자로 받아서, 확장 프로그램 안이든 테스트용 iframe이든 똑같이 동작해요.
var KC = KC || {};
KC.sleep = ms => new Promise(r => setTimeout(r, ms));
KC.vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
KC.num = s => +String(s || '').replace(/[^\d]/g, '') || 0;

KC.waitFor = async (fn, ms, step = 250) => {
  const end = Date.now() + ms;
  while (Date.now() < end) { const v = fn(); if (v) return v; await KC.sleep(step); }
  return fn();
};

KC.info = function (doc) {
  const text = doc.body ? doc.body.innerText : '';
  const flat = text.replace(/\s+/g, ' ');
  const meta = n => { const m = doc.querySelector(`meta[property="${n}"]`); return m ? m.content : ''; };
  let name = (doc.title || '').replace(/\s*(정품 안심 거래|추천 상품 시세 확인).*$/, '').replace(/\s*\|\s*KREAM\s*$/, '').trim();
  if (!name) name = meta('og:title');
  const code = ((text.match(/모델번호\s*\n?\s*([^\n]{2,60})/) || [])[1] || '').trim();
  // 발매가: "129,000원" 또는 "$40 (약 54,300원)" 형태
  let rel = null, relRaw = '';
  const r = flat.match(/발매가\s*(.{0,32}?)원/);
  if (r) {
    relRaw = (r[1] + '원').replace(/\s+/g, ' ').trim() + (/\(약/.test(r[1]) ? ')' : '');
    const nums = r[1].match(/[\d,]{4,}/g);
    if (nums) rel = KC.num(nums[nums.length - 1]);
  }
  const og = meta('og:title');
  const en = /^[A-Za-z(]/.test(og) ? og.trim() : ((flat.match(/발매가\s*[^가-힣]*?원\)?\s*(?:\d+%\s*)?[\d,]+원\s*[^A-Za-z]*?([A-Z][A-Za-z0-9'&().\-\/ ]{4,90}?)\s+\d\.\d/) || [])[1] || '').trim();
  return { name, en, code, rel, relRaw, img: meta('og:image') };
};

KC.drawer = doc => doc.querySelector('.drawer__content');

KC.clickTab = async function (doc, label) {
  const dr = KC.drawer(doc);
  if (!dr) return false;
  // 탭은 <li role=tab><a>판매 입찰</a></li> 구조라서 안쪽 링크를 눌러야 바뀌어요
  const c = [...dr.querySelectorAll('a,button,[role=tab]')].filter(e => (e.innerText || '').trim() === label && KC.vis(e));
  if (!c.length) return false;
  (c.find(e => e.tagName === 'A') || c.find(e => e.tagName === 'BUTTON') || c[0]).click();
  await KC.sleep(1500);
  return true;
};

KC.scrollDrawer = function (doc) {
  const dr = KC.drawer(doc);
  if (!dr) return;
  const list = [dr, ...dr.querySelectorAll('*')].filter(e => e.scrollHeight > e.clientHeight + 10);
  for (const e of list) e.scrollTop = e.scrollHeight;
  // 3.7.1: 화면에 안 보이는 창에서도 다음 목록을 불러오게 (hook.js가 받아서 처리)
  try { (doc.defaultView || window).postMessage({ __kcKick: 1 }, '*'); } catch (e) {}
};

// 화면에 보이는 체결 거래 줄을 직접 읽는 방법 (데이터를 못 받았을 때 대신 사용)
KC.domSales = function (doc, now) {
  const dr = KC.drawer(doc);
  if (!dr) return [];
  const t = dr.innerText.replace(/\s+/g, ' ');
  const rows = [];
  const re = /(\S+(?: SIZE)?) ([\d,]+)원 (빠른배송 )?(\d+분 전|\d+시간 전|\d+일 전|\d{2}\/\d{2}\/\d{2})/g;
  let m;
  while ((m = re.exec(t))) {
    const s = m[4]; let ts; let x;
    if ((x = s.match(/(\d+)분/))) ts = now - x[1] * 6e4;
    else if ((x = s.match(/(\d+)시간/))) ts = now - x[1] * 36e5;
    else if ((x = s.match(/(\d+)일/))) ts = now - x[1] * 864e5;
    else { const [y, mo, d] = s.split('/'); ts = new Date(2000 + +y, mo - 1, +d, 12).getTime(); }
    rows.push({ o: m[1], p: KC.num(m[2]), t: ts, f: m[3] ? 1 : 0 });
  }
  return rows;
};

KC.domAsks = function (doc) {
  const dr = KC.drawer(doc);
  if (!dr) return [];
  const t = dr.innerText.replace(/\s+/g, ' ');
  const out = [];
  const re = /(\S+(?: SIZE)?) ([\d,]+)원 (빠른배송 )?(\d+)(?= |$)/g;
  let m;
  while ((m = re.exec(t))) out.push({ o: m[1], p: KC.num(m[2]), q: +m[4], f: m[3] ? 1 : 0 });
  return out;
};

KC.flat = function (pages, kind) {
  const seen = new Set(); const out = [];
  for (const pg of pages) for (const it of (pg && pg.items) || []) {
    const row = kind === 'sales'
      ? { o: it.option, p: it.price, t: new Date(it.date_created).getTime(), f: it.is_immediate_delivery_item ? 1 : 0 }
      : { o: it.option, p: it.price, q: it.quantity || 1, f: it.is_immediate_delivery_item ? 1 : 0 };
    const k = JSON.stringify(row);
    if (!seen.has(k)) { seen.add(k); out.push(row); }
  }
  return out;
};

// opts: { days: 수집 기간(일), maxPages: 체결 거래 최대 페이지(50건씩), lite: true면 입찰 목록은 건너뜀(아이템 찾기용) }
KC.collect = async function (win, doc, cap, opts) {
  opts = Object.assign({ days: 30, maxPages: 10 }, opts || {});
  const now = Date.now();
  await KC.waitFor(() => doc.readyState === 'complete', 20000);
  await KC.sleep(1200);
  const info = KC.info(doc);
  const btn = await KC.waitFor(() => [...doc.querySelectorAll('button')].find(b => /거래 내역 더보기/.test(b.innerText) && KC.vis(b)), 12000);
  if (!btn) return { info, sales: [], asks: [], bids: [], source: 'none', note: '거래 내역 버튼을 못 찾았어요 (거래가 없는 상품일 수 있어요)', ts: now };
  btn.click();
  await KC.waitFor(() => cap.sales.length || KC.domSales(doc, now).length, 9000);

  // 3.4.6: 거래 내역 창이 '불러오는 중 문제가 생겼어요'면 크림 로그인이 꼬인 경우가 많아요 → 빈 결과 대신 알려줘요
  if (!cap.sales.length && !KC.domSales(doc, now).length) { const dt = (KC.drawer(doc) || doc.body).innerText || ''; if (/문제가\s*생겼|다시\s*시도/.test(dt)) return { error: '크림 거래 내역을 못 불러왔어요 — 크림이 요청을 거절하는 중이에요. 몇 시간 뒤 다시 수집해 주세요 (이전 시세는 그대로 뒀어요)' }; }
  let source = cap.sales.length ? 'api' : 'dom';
  // 3.7.2: 크림은 첫 50건을 화면용 데이터로, 그다음부터는 /sales 응답으로 줘요.
  //        화면이 안 보이는 창에서는 목록이 화면에 안 그려질 수 있어서, 첫 화면 줄 + 받아 둔 응답을 합쳐서 써요.
  const firstDom = KC.domSales(doc, now).length;
  const merged = () => {
    const d = KC.domSales(doc, now), a = KC.flat(cap.sales, 'sales');
    if (!a.length) return d;
    if (source === 'api') return a;
    if (d.length >= firstDom + a.length * 0.9) return d;   // 화면에 다 그려졌으면 화면 것
    return d.slice(0, firstDom).concat(a);
  };
  // 거래 내역 창 위쪽의 즉시 구매가(=최저 판매입찰) / 즉시 판매가(=최고 구매입찰)
  const head = (KC.drawer(doc) || doc.body).innerText.replace(/\s+/g, ' ');
  const buyNow = KC.num((head.match(/([\d,]+)원\s*즉시 구매가/) || [])[1]) || null;
  const sellNow = KC.num((head.match(/([\d,]+)원\s*즉시 판매가/) || [])[1]) || null;
  // 기간을 채울 때까지 더 불러오기
  let useMore = false;
  for (let i = 1; i < opts.maxPages; i++) {
    const rows = merged();
    const oldest = rows.length ? Math.min(...rows.map(r => r.t)) : now;
    const last = cap.sales[cap.sales.length - 1];
    if (now - oldest > opts.days * 864e5) break;
    if (last && !last.next_cursor) break;
    const bA = cap.sales.length, bD = KC.domSales(doc, now).length;
    let grew = false;
    if (!useMore) { KC.scrollDrawer(doc); grew = await KC.waitFor(() => cap.sales.length > bA || KC.domSales(doc, now).length > bD, 3500); }
    // 3.7.3: 화면이 안 보여서 페이지가 안 불러오면, 페이지가 쓰던 방식 그대로 다음 목록을 불러요 (한 번 그러면 계속 이 방식)
    if (!grew && last && last.next_cursor) { useMore = true; try { (doc.defaultView || window).postMessage({ __kcMore: 1, kind: 'sales', cursor: last.next_cursor }, '*'); } catch (e) {} grew = await KC.waitFor(() => cap.sales.length > bA, 8000); }
    if (!grew) break;
    await KC.sleep(300);
  }
  const sales = merged();
  if (cap.sales.length && source === 'dom') source = 'mixed';

  if (opts.lite) return { info, sales, asks: [], bids: [], buyNow, sellNow, source, ts: now, salesTotal: (cap.sales[0] && cap.sales[0].total) || null, lite: true };
  // 판매 입찰 (사이즈별 최저가·수량)
  // 판매 입찰 / 구매 입찰: 탭을 바꾸고 아래로 내려서 몇 페이지 더 불러오기
  const loadList = async (label, kind, scrolls) => {
    if (!(await KC.clickTab(doc, label))) return [];
    await KC.waitFor(() => KC.domAsks(doc).length, 5000);
    for (let i = 0; i < scrolls; i++) {
      const before = KC.domAsks(doc).length;
      KC.scrollDrawer(doc);
      if (!(await KC.waitFor(() => KC.domAsks(doc).length > before, 3500))) break;
    }
    const api = KC.flat(cap[kind], kind), dom = KC.domAsks(doc);
    return api.length >= dom.length ? api : dom;
  };
  const asks = await loadList('판매 입찰', 'asks', 4);
  const bids = await loadList('구매 입찰', 'bids', 2);
  return { info, sales, asks, bids, buyNow, sellNow, source, ts: now, salesTotal: (cap.sales[0] && cap.sales[0].total) || null };
};
