// 크림 마이페이지에서 받아 적은 응답을 모아 두었다가 '크림스캐너'가 달라고 하면 돌려줘요.
(() => {
  const cap = [];
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__kcmy !== 1) return;
    cap.push({ url: e.data.url, data: e.data.data, t: Date.now() });
    if (cap.length > 200) cap.shift();
  });
  chrome.runtime.onMessage.addListener((msg, sender, send) => {
    if (!msg || msg.cmd !== 'kc-my') return;
    send({ url: location.href, cap });
    return false;
  });
})();
